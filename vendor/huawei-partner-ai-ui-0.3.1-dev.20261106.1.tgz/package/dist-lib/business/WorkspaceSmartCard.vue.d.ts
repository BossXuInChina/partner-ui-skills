import { type IntelligenceItem, type IntelligenceLogo, type IntelligenceTag } from './workspaceIntelligence';
import type { WorkspaceNavigation } from '../host/businessAction';
type __VLS_Props = {
    title: string;
    items: readonly IntelligenceItem[];
    variant?: 'outlined' | 'embedded';
    tag?: IntelligenceTag;
    logo?: IntelligenceLogo;
};
declare var __VLS_13: {}, __VLS_20: {};
type __VLS_Slots = {} & {
    body?: (props: typeof __VLS_13) => any;
} & {
    footer?: (props: typeof __VLS_20) => any;
};
declare const __VLS_base: import("vue").DefineComponent<__VLS_Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    activate: () => any;
    navigate: (navigation: WorkspaceNavigation) => any;
}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{
    onActivate?: (() => any) | undefined;
    onNavigate?: ((navigation: WorkspaceNavigation) => any) | undefined;
}>, {
    logo: IntelligenceLogo;
    variant: "outlined" | "embedded";
    tag: IntelligenceTag;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
declare const __VLS_export: __VLS_WithSlots<typeof __VLS_base, __VLS_Slots>;
declare const _default: typeof __VLS_export;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
