export type BusinessColumn = {
    key: string;
    title: string;
};
