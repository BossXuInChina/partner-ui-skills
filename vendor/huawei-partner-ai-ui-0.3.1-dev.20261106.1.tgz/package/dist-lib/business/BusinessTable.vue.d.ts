import type { BusinessColumn } from './businessTable';
type __VLS_Props = {
    columns: BusinessColumn[];
    rows: Record<string, unknown>[];
    label?: string;
    rowKey?: string;
    minWidth?: number;
    fit?: boolean;
    ellipsis?: boolean;
    cellText?: (row: Record<string, unknown>, column: BusinessColumn) => string;
};
declare var __VLS_1: {
    row: Record<string, unknown>;
    column: BusinessColumn;
};
type __VLS_Slots = {} & {
    cell?: (props: typeof __VLS_1) => any;
};
declare const __VLS_base: import("vue").DefineComponent<__VLS_Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{}>, {
    label: string;
    rowKey: string;
    minWidth: number;
    fit: boolean;
    ellipsis: boolean;
    cellText: (row: Record<string, unknown>, column: BusinessColumn) => string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
declare const __VLS_export: __VLS_WithSlots<typeof __VLS_base, __VLS_Slots>;
declare const _default: typeof __VLS_export;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
