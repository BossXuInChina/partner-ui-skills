import { type CSSProperties, type Ref } from 'vue';
import type { ChatSidebarBehavior, ChatWindowMode } from '../ui/panel/chatWindow';
export interface AssistantHostLayoutOptions {
    open: Ref<boolean>;
    mode: Ref<ChatWindowMode>;
    /** Defaults to push; overlay keeps the business track at its full width. */
    sidebarBehavior?: Ref<ChatSidebarBehavior | undefined>;
    /** Fill this workspace while retaining the underlying window preference. */
    fullscreen?: Ref<boolean>;
    /** Complete product viewport width; optional for constrained/cross-origin embeds. */
    viewportWidth?: Ref<number | undefined>;
    /** Business flows in an ancestor scrollport while the assistant stays visible. */
    flow?: Ref<boolean | undefined>;
}
/** Apply workspaceStyle to the grid, assistantStyle to the permanently mounted aside. */
export declare function useAssistantHostLayout(workspace: Ref<HTMLElement | undefined>, options: AssistantHostLayoutOptions): {
    sidebarWidth: import("vue").ComputedRef<number>;
    squeezed: import("vue").ComputedRef<boolean>;
    workspaceStyle: import("vue").ComputedRef<{
        gridTemplateColumns: string;
        '--partner-host-workspace-width': string;
    }>;
    assistantStyle: import("vue").ComputedRef<CSSProperties>;
};
