# 可选宿主布局与业务区弹层（REQ-022）

2026-10-28：当前宿主合同以源码工作区为准，不能由既有0.3.0 ZIP/tarball推断。消费侧模块从 `src/index.ts` 导出，不修改 TinyRobot 源码，不依赖 demo/vendor。公司内网构建、平台注册 schema、真实 API 和内部正式 WorkbenchModal 尚未适配验收；下文标注历史的实现记录由后续修订补充。

## 新页面：组合宿主

```vue
<script setup lang="ts">
import { ref } from 'vue'
import { AssistantHostLayout, AgreementAssistantPanel,
  type ChatWindowMode, type ChatSidebarBehavior, type WorkspaceNavigation } from 'huawei-partner-ai-ui'
import 'huawei-partner-ai-ui/styles.css'
const open = ref(true), mode = ref<ChatWindowMode>('sidebar'), fullscreen = ref(false)
const sidebarBehavior = ref<ChatSidebarBehavior>('push') // 或 overlay，不挤压业务页
const page = ref('company')
function navigate(value: WorkspaceNavigation) {
  // 产品解析白名单目标、权限、未保存修改和路由失败；不把 target 当 URL。
  if (['company', 'agreement-renewals'].includes(value.target)) page.value = value.target
}
</script>
<template>
  <div style="height:100%;min-height:0">
    <AssistantHostLayout :open="open" :sidebar-behavior="sidebarBehavior" v-model:window-mode="mode" v-model:fullscreen="fullscreen">
      <template #navigation><!-- 产品导航，实际高度自动排除 --></template>
      <!-- 挂载当前业务页；此槽之外的 AI 实例保持挂载 -->
      <ProductBusinessPage :page="page" />
      <template #assistant="{ windowMode, fullscreen, toggleFullscreen, switchMode, dragStart, dragKeydown }">
        <AgreementAssistantPanel :adapter="adapter" :window-mode="windowMode" :fullscreen="fullscreen"
          @fullscreen-change="toggleFullscreen"
          @window-mode-change="switchMode" @window-drag-start="dragStart"
          @window-drag-keydown="dragKeydown" @workspace-navigate="navigate">
          <template #toolbar-end><button @click="open=false">收起助手</button></template>
        </AgreementAssistantPanel>
      </template>
    </AssistantHostLayout>
  </div>
</template>
```

`adapter`、业务页组件、入口和关闭后的焦点恢复由产品提供。Demo 默认显示本地交易智慧续签示例，顶部“首页”切换到公司信息，顶部“交易”返回示例；这只是演示导航，不代表正式产品路由。切换时助手保持挂载并保留草稿及消息。宿主高度必须由父容器确定，不按窗口模式切换 key/v-if。`open` 仅改变布局、显示与 inert，保留面板、输入草稿、消息、滚动及执行中的请求。默认使用本地 viewport 判断侧栏 420/480（1920 分界），被实际工作区宽度限制；嵌入的产品可传 `viewportWidth` 指定完整产品视口，组件不尝试越权读取跨域顶层窗口。悬浮保持既有 420px/910px 偏好及顶部移动、底部高度拉伸，实际尺寸受导航下工作区与 visualViewport 交集约束。

公共宿主的挤压、展开收起和悬浮切换沿用既有 200ms / cubic-bezier(0.2,0,0,1)。 覆盖式侧栏与挤压式使用相同的水平滑入/滑出轨迹、透明度和退出显隐时序：从工作区右侧外进入，关闭时滑回右侧外。两种侧栏使用同一右侧锚点与 `transform:translateX(侧栏宽度 + 24px)` 的关闭位移；仅挤压式的业务轨道执行网格动画，覆盖式保持业务区宽度不变。两者支持中途反转和reduced-motion。`--partner-host-motion-duration` / `--partner-host-motion-easing` 可在宿主上覆盖。aside 始终挂载，退出的 visibility 延后到过渡结束；快速反转不重建节点。抓取期间停用位移过渡，释放后恢复；reduced-motion 关闭过渡。此前 UiDialog 本身没有进退场动画，v0.4的工作区网格检查不能作为Drawer动效验证。REQ-022 v0.5为接入BusinessOverlayHost的区域Drawer补齐工作台规格：面板translateX(100%)↔0、区域蒙层opacity 0↔1，200ms / cubic-bezier(0.2,0,0,1)。先设置离屏/透明首帧，再show()和启动WAAPI，避免首帧直接呈现最终位置。真实退场DOM保留到动画完成，随后close()/释放局部inert/恢复焦点；旧对话框在退场时inert且aria-hidden，蒙层仍拦截指针以免穿透到重叠浮窗。快速重开同一个Drawer从当前绘制位置/透明度接续，取消旧动画/清理旧节点，剩余位移按200ms基准缩短；reduced-motion直接到终态，运行中切换也取消动画。用户在退场期间已把焦点移到导航/AI时不抢回焦点。历史v0.5中普通区域modal及未接入provider的global dialog保留旧关闭方式，WorkbenchModal当时未修改；当前全局动效与本地vendor适配以本文v0.6为准，内部正式WorkbenchModal仍待接入验收。宿主自有动画弹层应保留 Transition/after-leave 生命周期及结束后焦点恢复，不提前卸载。

## 现有产品：只接入宿主适配

### 侧栏布局选择

`AssistantHostLayout.sidebarBehavior?: ChatSidebarBehavior` 接受 `push | overlay`，默认 `push`，旧调用效果保持不变。它是宿主按页面选择的布局策略，不属于输入框的业务模式。

| 配置 | 展开侧栏时的业务区 | 窗口能力 |
| --- | --- | --- |
| `push` | 为右侧420/480px侧栏让出宽度 | 可切换或连续拖离为悬浮窗 |
| `overlay` | 保持完整业务宽度，侧栏覆盖工作区右侧 | 同样可切换或连续拖离为悬浮窗 |

覆盖式侧栏贴导航下工作区的右边界、占满工作区高度；不加模态遮罩，未覆盖的业务区可继续操作。关闭后恢复入口焦点由宿主负责。悬浮窗返回侧栏时沿用当前策略；全屏独立于此策略，退出后恢复进入前的窗口形态及侧栏策略。动态更新布局不重建面板、不重新发送请求，保留草稿、消息、阅读位置和正在编辑的业务弹层。

只复用 composable 的产品，将 `sidebarBehavior` ref 传给 `useAssistantHostLayout`，工作区绑定 `workspaceStyle.value`，aside 同时绑定 `{...layout.assistantStyle.value,...floating.style.value}`。两种侧栏的右侧定位与进退场位移由 `assistantStyle` 提供；仅挤压式预留网格宽度，覆盖式不预留。浮窗仍由 `useAssistantWindow` 管理，`ChatWindowMode` 仍为 `sidebar | floating`。

本地 Studio 与总览面板的完整场景通过“侧栏布局”选择器切换两种策略，仅调整宿主；一期预览同样可查看。独立助手全页示例没有业务宿主，因此不显示此选择器。

已核对锁定 TinyRobot 0.5.1 的公开 `LayoutAsideOptions.mode: dock | drawer`，原生支持两类侧栏。本工程继续使用已有宿主中最小的网格/定位分支，因为既有连续拖离、键盘移动/拉伸和导航下的工作区边界无法由当前原生 API 等效接管；依据仍为原宿主隔离验证。ChatPanel 内部继续复用 TrLayout，不新增一套面板或指针引擎。升级 TinyRobot 时复核上述缺口。

无需替换导航或业务页。保持 grid 工作区、独立 business 容器和 AI aside，并在共同 Vue 祖先使用：

```vue
<BusinessOverlayHost :region="businessRegion" :layer="1000">
  <div ref="workspace" class="product-workspace" :style="layout.workspaceStyle.value">
    <section ref="businessRegion" class="product-business"><!-- 原业务页面 --></section>
    <aside data-assistant-window :style="{...layout.assistantStyle.value,...floating.style.value}">
      <AgreementAssistantPanel :adapter="adapter" :window-mode="mode"
        @window-mode-change="mode=mode==='sidebar'?'floating':'sidebar'"
        @window-drag-start="floating.start" @window-drag-keydown="floating.keyboard" />
    </aside>
  </div>
</BusinessOverlayHost>
```

script 调用 `useAssistantHostLayout(workspace,{open,mode,sidebarBehavior?,viewportWidth?})` 和 `useAssistantWindow(workspace,mode,open)`。工作区需 `display:grid;position:relative;min-height:0`；业务轨道需 `min-width:0;min-height:0`；floating 的 aside 需 `position:absolute`，且提供现有显示/退出过渡、关闭 inert、导航层级和焦点恢复。尺寸 refs 与返回的 style refs 在 script/模板中按示例访问 `.value`。抓取包装层必须带 `data-assistant-window`，并作为传入 workspace 的直接子元素（与上例相同）。浮窗固定槽测量与 ResizeObserver 只读取该包装层里的 ChatPanel，业务槽内嵌的其他宿主不参与当前窗口的最小高度。高度拉伸入口使用 `resizeStart/resizeKeyboard`、`height/minimumHeight/resizeMaximum`，如公共宿主示例。关闭/模式切换不销毁同一面板。

`BusinessOverlayHost.region` 是**业务容器**，不含导航、AI 侧栏。provider 必须是弹层发起组件的 Vue 祖先；同一业务区使用一个 provider。默认 portal 到同一文档 body，以避免浮窗 overflow/stacking context 裁剪；fixed 边界实时测量实际 region 与 visualViewport 交集，监听祖先 resize、捕获 scroll、窗口及 visualViewport 变化。挤压过渡中的 region 尺寸通过 ResizeObserver 连续更新。默认层级1000，高于普通浮窗25；产品可用 layer 接入自己的层级表，需独立验证已有 top-layer/popover/跨文档覆盖关系。区域外透明且不命中，普通业务区弹层优先覆盖重叠浮窗；区域外导航和 AI 可继续操作。

区域弹层只使 business 容器 inert；恢复它此前的 inert 状态。嵌套弹层仅最上层接受交互，关闭后恢复下一层焦点；Tab 在当前弹层内循环，Escape 请求关闭（忙碌/脏草稿仍由调用者决定是否接受），退出后恢复仍连接且未 inert 的 opener。AI 或导航可主动取焦点，不做全局 focusin 劫持。区域 dialog 的 `aria-modal=false`，避免向辅助技术宣称整个页面不可用。

`UiDialog` 的 `scope` 为 `region | global`。省略时：有 provider 就区域化，没有 provider 则保留旧的全页 `showModal()`。显式 `region` 必须配置 provider；显式 `global` 使用真正 top layer/inert 语义。面板可传 `businessDialogScope` 覆盖全部默认业务弹层，通常省略即可。scope 和所有权需在打开前确定；不在已有编辑/忙碌操作期间切换。普通详情、续签确认、放弃草稿均随 provider 区域化；真正跨全页的确认独立用 `<UiDialog scope="global">`。Teleport 携带 theme 并复制打开时的 AI/Workbench 公共语义 token；打开期间动态主题/token 更改需关闭重开，尚不承诺实时主题同步。

## 产品接管业务操作

面板新增 `businessActionMode='default'|'host'`（默认default）和 `business-action(action)`：

```ts
type AgreementBusinessAction = { type:'open'|'renew'; agreement:Agreement }
```

default 模式保留内部详情编辑、草稿确认、续签、校验、重试和 adapter 调用；事件监听可记录业务意图，但不要另开弹层。产品希望使用现有 Drawer/弹窗时，必须明确设为 host：面板只发事件，不改变 selected/confirmation，不调用 updateAgreement/renewAgreement，避免两份弹层。事件中的记录为浅复制，不允许通过修改事件对象改变聊天记录。

host 模式由产品承担弹层/路由、权限、异步 busy/dirty 状态、重复保护、关闭拦截、草稿、焦点和接口错误。操作成功后可调用面板暴露的 `applyBusinessUpdate(updatedAgreement)` 同步卡片/表格/历史里的记录及续签按钮状态；它不会自动调用 API、导航或新建会话。`currentStatus/status` 继续只报告面板内部状态，宿主接管的编辑状态必须由产品合并，不会被面板猜测。

导航独立于上述所有权：TinyRobot 气泡事件 `workspace:navigate`，payload 为 `WorkspaceNavigation={target:string,params?:Record<string,string>}`，经校验后转发 `workspace-navigate`。targets 是产品注册键，params 仅字符串；不执行 location/window.open，不把发事件视为导航成功。产品必须解析白名单并显示失败结果/处理权限与未保存修改，保持 AI 实例不卸载。卡片外观与其内容由 REQ-023 独立任务交付。

## 明确边界

这些能力是可选消费模块，不自动拦截任意宿主的全局 dialog/portal。本地公司示例的 WorkbenchModal 采用下文v0.6的独立全局实现；内部正式WorkbenchModal要区域化时，内网团队应把其打开逻辑接入自己的区域容器或 host 模式，并核验它的 Teleport、top layer、焦点、动画与层级。尚未验证 TurboUI/Starling 的真实宿主、schema、真实业务 API、跨域协议、Windows/Safari/Firefox、软键盘真机与内部正式 WorkbenchModal。层级需由宿主统筹；业务区必须有非零可操作面积。

历史REQ-022源码阶段未构建 dist/dist-lib、不打包、不提交/push；当前构建与交付结果须以当次报告为准。源码独立消费检查 `node scripts/verify-host-source-consumer.mjs` 会复制公开模块闭包到临时工程、复用锁定依赖并做类型消费/产品边界校验，排除 demo/preview/data/mock/vendor；不等同正式构建产物消费或公司内网验收。

主原型入口是首页H0–H3回复H2段落中的卡片（REQ-023负责回复/renderer）。主demo现已监听workspace-navigate并按agreement-renewals白名单接入REQ-023的AgreementRenewalsWorkspace，传入status并聚焦真实标题；原公司组件通过v-show保留，顶部“首页”返回时恢复业务滚动，AI继续同一实例。智慧示例不显示单独的返回公司信息按钮；独立旧演示保留其返回入口。导航未知键/内部忙碌或脏草稿会显示失败；业务弹层的覆盖优先级由区域适配器提供。

区域Drawer的v-if退场由UiDialog内部适配：调用Vue3.5导出的setTransitionHooks在原生portal表面挂载leave回调，让真实节点等待WAAPI完成，不复制截图/DOM、不改业务状态或TinyRobot。该低层渲染生命周期适配必须随Vue升级复核；整个宿主被卸载时父容器可直接移除，不能承诺跨卸载保留视觉退场。动效私有模块src/ui/foundation/dialogMotion.ts不新增公开props/events。区域容器overflow:clip避免首帧离屏面板被程序化scrollIntoView滚回最终位置。

## REQ-022 v0.6：明确全局弹窗

v0.5保留global/WorkbenchModal原样的历史边界由用户最新授权取代。UiDialog global现在通过body portal保留native dialog及::backdrop，补200ms工作台modal淡入淡出和真实退场；全局模态直到退场结束才close/remove。未接入区域provider的旧消费仍是global语义，新增动效不会把区域业务操作全部提升为global。

本地主demo vendored WorkbenchModal改为full-document native modal shell，原表单内容、事件/尺寸配置/8px图标样式保留；遮罩与native inert一起覆盖导航、浮钮组和浮窗AI。没有靠提高z-index遮盖native top layer排序问题。退出/快速重开共享滚动租约和绘制opacity接续，避免提前解锁/旧焦点抢回；reduced-motion直接终态。已声明的aria-controls popup和注册feedback被接入native modal内部，避免普通body portal被native inert阻挡；任意第三方portal并不自动兼容。

背景Tooltip不再消费前景native global的Escape；前景自己的hint-first及普通区域策略保留。native modality是文档级：runtime iframe内覆盖整个主demo，而非跨iframe覆盖外Studio工具栏。内网产品仍需检验自己的portal、浏览器及加载协议；本地JS Workbench适配未导入正式产品闭包。


## 悬浮外观与示例一致性（REQ-008 v0.5 / REQ-027 v0.5）

实际demo宿主与AssistantHostLayout共同导入src/host/assistantWindow.css，在已有data-assistant-window/data-window-mode边界内共用私有token `--partner-host-floating-radius:24px`。浮窗外壳拥有唯一24px裁剪及白色底板，内部ChatPanel无边框/圆角；sidebar仍方角，菜单/其他卡片不受影响。不要将24px写到全局panel-radius，也不要从demo.css复制整套样式。

总览按可用宽度响应式展示完整高度案例，展开后适配当前浏览器真实可用区域，无左右画布定位/缩放。宿主仍以真实workspace与visualViewport交集夹限，保留拖动、底部覆盖式伸缩热区、动效和会话状态；伸缩热区不占额外布局高度，既有最小高度安全量独立保留。Workbench本地资产仅demo演示，非公司内部正式/批准源码，正式接入须替换批准组件与资产。


## 导航下工作区全屏（独立于 windowMode）

`AssistantHostLayout` 可选 `v-model:fullscreen`（布尔值，默认 false）。assistant 插槽新增 `fullscreen` / `toggleFullscreen`；将前者传给 `ChatPanel` 或 `AgreementAssistantPanel`，将 `fullscreen-change` 接到后者。未传面板 fullscreen 时不增加按钮，旧消费保持兼容。关闭助手会退出全屏；退出全屏仍保持进入前的 sidebar/floating，悬浮位置与手动高度在同一宿主内保存，工作区缩小时才按当前边界夹限。不要按全屏切换 key 或复制面板。

外壳绝对定位在 workspace 内，保留 navigation；全屏业务内容保持挂载并隐藏，避免键盘进入背后页面。业务 region 仍有完整工作区边界，既有区域 Drawer / Modal（默认层级1000）继续优先于 AI（25），全局 native Modal 继续隔离整个文档。未提高 AI 层级。菜单/提示先处理 Escape，打开或退场中的业务 dialog 阻止全屏退出；随后 Escape 退出全屏。公司示例再按 Escape 可收起助手。

正文与发送区共用 `--partner-ai-fullscreen-content-max-width:800px`（不含原有16/20px安全边距），可在面板 `.partner-ai` 根覆盖，如 `style="--partner-ai-fullscreen-content-max-width:960px"`。全屏欢迎卡组独立使用`--partner-ai-fullscreen-welcome-max-width:1040px`居中限宽；恰好三张卡片且实际安全内容宽度≥1040px时采用三列，每张336px、gap16。标题维持16/24、图标24px、卡内H24/V16，说明维持14/22；当前三张示例卡片恢复82px高，长标题/说明自然换行并增高，不裁切。不满足条件时回退既有纵向卡组（最大400px），侧栏与悬浮始终使用原布局。发送框仍固定底部。侧栏420/480px与浮窗420px规则保持不变。全屏隐藏拖拽、拉伸与侧栏/悬浮切换，独立按钮可退出；不调用浏览器 Fullscreen API。

复用宿主 composable 的既有产品可给 `useAssistantHostLayout` options 增加 `fullscreen` ref，给 `useAssistantWindow` 第四参数传同一 ref，并将 `data-fullscreen` 绑定到直属的 `data-assistant-window` 外壳；沿用 `assistantWindow.css`（由公共入口导入）。布局全屏时不挤压业务轨道，浮窗测量与手势暂停；退出重新测量工作区。真实接入示例见总览“面板 · 侧栏、悬浮与全屏”及公司主预览。

宽度重排时保留可见语义块及块内相对阅读偏移，底部阅读者继续跟随回复；草稿、输入滚动、历史与请求由原面板实例持有。超长单段按相对段落进度恢复，不承诺字符级定位；画布已无足够滚动空间时按原生边界夹限。

欢迎态（messages为空）统一隐藏SuggestionPills、阴影装饰与对应48px行高，首次打开与新建对话均适用；有消息后按原suggestionPills配置恢复。三列条件由具名welcome容器的CSS content box判断，不按浏览器宽度；1040px来自3×336px最小卡宽及两个16px间距；欢迎卡组与800px正文/发送框独立，后续气泡及表格视口不会继承欢迎宽度。自定义字体、长标题或卡内padding时应复核可读性。


## 本地完整预览与一期交付

公司Demo对原生输入编辑区域的Escape使用自有宿主捕获适配，绕开锁定Sender的默认keymap；有效提示、模式菜单、前景Dialog和全屏仍优先处理。此关闭策略属于公司示例，公共 `AssistantHostLayout.open` 仍由消费方控制，未新增自动关闭协议。

公司示例的浮钮锚定业务视口右侧，不受内容版心限宽；距业务视口右边32px、主组底边178px、返回顶部底边106px。覆盖式侧栏不会移动业务页面；挤压式仅在原页面位置超出剩余业务区时移动必要距离。公司分页保留独立安全留白，防止浮钮遮挡分页操作；该局部接入不改变AI组件Token或分页控件视觉规范。

本地默认演示保留全屏、收藏、历史置顶等完整能力；一期交付通过现有 `VITE_AI_DELIVERY` 构建标志或 Studio 的一期预览 provider 隐藏相应入口，不删除实现。接入时须分别检查完整演示与一期交付效果，不能把本地可见入口自动视为本期正式开放功能。

`AssistantHostLayout` 的可选 `flow`（默认 `false`）供外层已有滚动容器的页面使用：业务区自然展开，由宿主滚动；sidebar 固定在滚动视口内，使用 `--partner-host-flow-window-height` 指定可用高度。宿主需要提供有界滚动视口并排除导航高度；原固定高度宿主行为不变。
