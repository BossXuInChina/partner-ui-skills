# Huawei Partner AI UI

本软件使用 HarmonyOS Sans Fonts。Copyright 2021 Huawei Device Co., Ltd. 字体原件和许可仅用于独立预览，组件包不含字库，由宿主统一提供字体，参阅 [字体接入与许可](docs/FONTS.md)。

设计开发交接先读 [HANDOFF.md](docs/HANDOFF.md)，预览入口 `/overview.html`。组件总览、当前Demo与当前构建消费同一份组件源码；重新交付归档须以重新验证后的快照为准。

Workbench来源边界：本地harness的Demo vendor及Studio移植仅用于演示工具，非公司内部正式/批准的资产源码。AI产品内另有保留来源的自包含Tooltip、滚动等最小适配，不导入Demo闭包；历史设计参考不构成运行时Token依赖或公司生产批准。正式接入由内部团队确认批准资产，分类见[交付职责清单](docs/COMPONENTS.md)。

当前评审版本 **0.3.0**。最新启动、公开接口、Sender/欢迎态配置、AI语义token、定制/升级风险与交付边界以[DELIVERY.md](docs/DELIVERY.md)为准。首次进入默认欢迎态，新建取消旧流并清理会话；旧轮次来源与验证背景见[历史迭代记录](docs/CHANGELOG.md#readme-历史迭代归档)，旧候选尺寸不再作为当前规范。

AI UI 公共样式采用独立设计 Token，默认值与引用链在包内闭合，不再导入或读取 Workbench Token。业务 Demo 仍保留其 Workbench 资产。默认声明、最终参数、来源与宿主 CSS 隔离限制见 [AI_TOKENS.md](docs/AI_TOKENS.md)，本轮范围与证据见 [AI_TOKEN_INDEPENDENCE.md](docs/AI_TOKEN_INDEPENDENCE.md)。

演示宿主默认进入交易导航下的智慧续签作业区；通过顶部“首页”可进入复用的 Workbench 公司信息页，保留注册信息、伙伴联系人、伙伴地址交互。交易入口是本地演示导航，不代表正式业务路由。官网导航全宽，下方侧栏支持默认挤压式和覆盖式；完整页面视口1920px起外宽480px、安全内距20px，否则420px、安全内距16px，内距包含在外宽内。

## 启动与入口

Node.js ≥22.12.0、pnpm 11.19.0：

```sh
pnpm install --frozen-lockfile
pnpm dev
```

- 组件总览：<http://127.0.0.1:4178/overview.html>。
- 主预览：<http://127.0.0.1:4178/>，默认 R2 演示宿主。
- 独立场景：<http://127.0.0.1:4178/renderer.html>。
- 首轮独立聊天回归入口：<http://127.0.0.1:4178/?view=assistant>。
- 构建预览：`pnpm build` 后先停 dev，再运行 `pnpm preview`，同为 4178。

本机后台服务的启动、停止与日志说明见[本地开发](docs/dev-local.md)。

点击业务页右下角机器人按钮唤醒助手。挤压式收窄业务区，覆盖式保持业务宽度；两者使用相同进退场轨迹。顶部导航保持全宽，两区独立滚动，业务滚动条默认隐藏、交互时显现。Studio可切换侧栏布局；两种侧栏均可切换或拖出悬浮窗。助手保持挂载，隐藏时 inert/不可聚焦；切换保留消息、输入草稿、业务编辑、滚动和流式状态。支持键盘唤醒、Escape、关闭按钮及入口焦点恢复。

按钮组复用原 FloatingButton 样式：48px命中尺寸、8px圆角、4px上下padding及原阴影。按钮锚定业务视口右边32px、底边178px；返回顶部距主组24px、底距106px。覆盖式侧栏保持业务区位置；挤压式在原页面位置仍能完整容纳时不移动页面，否则仅移动避免裁切所需的距离。定位框不占布局空间且自身不拦截业务指针，实际按钮可交互。

用户指定的 100×100 透明机器人原图用于 AI 按钮；两份素材均通过正式 Library 引用流程获取、保留文件身份并查看。原图和参考图位于 `.artifacts/library-assets/`，SHA/版本记录在 `.artifacts/round2/library-assets.json`。

## 产品与演示边界

| 路径 | 用途 |
| --- | --- |
| `src/ui/` | 按 foundation / panel / messages / composer / history 组织的消费层 UI；公共出口以 src/index.ts 为准 |
| `src/business/AgreementAssistantPanel.vue` | 可独立嵌入的 AI 业务面板，无重复页面外壳 |
| `src/business/useAgreementPanel.ts` | 当前查询、编辑、确认与操作保护逻辑 |
| `src/adapters/contracts.ts` | 消费方传输和操作接口 |
| `src/index.ts` | 产品入口：面板、通用聊天、卡片/表格及接口 |
| `src/demo/` | R2 页面、网站导航、悬浮组、用户头像与选定 Workbench 源码；仅演示 |
| `src/preview/`、`src/App.vue` | iframe Studio 与场景切换；仅预览 |
| `src/data/`、`mockAdapter.ts` | 虚构数据/模拟操作；仅预览 |

完整的职责、公开入口、消费方式、类型与来源对照见 [COMPONENTS.md](docs/COMPONENTS.md)。`ChatPanel` 是通用呈现入口，业务团队通过现有 `renderers` 提供自己的业务卡；`AgreementAssistantPanel` 是现成的协议会话组合，`AgreementTable` 是公开协议领域组件，Demo虚构数据与Workbench状态标签不属于其产品交付。内部Sender/Prompts/Pills仍通过面板配置使用，不新增独立出口。

`RenewalAssistant` 整页仍供首轮回归入口使用，**不再从 0.2.0 产品入口导出**。产品用法：

```vue
<script setup lang="ts">
import { AgreementAssistantPanel, type AgreementAssistantAdapter } from 'huawei-partner-ai-ui'
import 'huawei-partner-ai-ui/styles.css'
const props = defineProps<{ adapter: AgreementAssistantAdapter }>()
</script>
<template>
  <div style="height: 700px">
    <AgreementAssistantPanel :adapter="props.adapter" theme="workbench" />
  </div>
</template>
```

`pnpm build` 输出 `dist/` 演示及 `dist-lib/` 产品。构建时记录真实产品模块闭包并拒绝 demo/preview/fixture/整页外壳进入产品；证据为 `.artifacts/build/product-boundary.json`。本地 tarball 独立消费测试检查 Vue 3.5.13、类型、构建和浏览器渲染，消费方需实现可取消流和服务端幂等。

## 依赖、来源与验证

维护工程 Vue/compiler-sfc 为 3.5.42，产品浏览器兼容 3.5.13–3.5.42；TinyRobot 0.5.1、kit 0.4.0、根 svgs 0.3.5 保持不变。当前依赖修订及仍待宿主处理的安全项见 [版本记录](docs/VERSIONS.md)；robot 内部依赖 svgs 0.5.1 正常并存。Workbench演示依赖采用本地自包含的选定源码/样式/资源闭包与声明边界，未依赖原工程运行。迁入的JS SFC不是完整TypeScript改写，以实际编译和浏览器行为验证；本工程UI、控制器和公共接口继续类型检查。

当前来源与本地适配差异见 [SOURCES.md](docs/SOURCES.md)和`src/demo/vendor/workbench/source-provenance.json`，包括导入路径、导航显示、原生弹层、悬浮按钮与分页避让接入。原Workbench工程只读，早期`.artifacts/round2/ported-sources.json`仅是当时来源证据。字体与许可仅作为预览可选资源保留，组件交付不含字库，见[FONTS.md](docs/FONTS.md)。

公司 TurboUI 7.1.0 / Starling pc-runtime 7.1.7、正式manifest + entry样例/schema、loader与真实宿主/API尚未验证；不预设index.json扫描或manifest.component字段，详见[INTEGRATION.md](docs/INTEGRATION.md)。当前查询仍使用虚构协议示例，并未接入联系人/地址真实业务。未执行真实业务操作；GitHub私有初始导入已单独完成，本轮不推送。人工视觉确认、Windows/其他浏览器和极窄移动端尚待后续验收。

## 长需求协作

在 [collaboration/README.md](collaboration/README.md) 查看索引和使用方法；消息排版草稿为 [REQ-001](collaboration/requests/REQ-001-message-typography/request.md)。用户编辑正文与迭代记录后，在聊天中指出编号与版本。草稿不会自动执行；协作目录只在源码工作区提供，不进入产品dist/tarball。

## AI UI 定制规范与组件总览

访问 `http://127.0.0.1:4178/overview.html`，或点击 Studio 顶部「AI UI 规范 ↗」。独立页面提供来源地图、现有语义token、可独立定位的组件/状态与设计开发接入片段；公开组件、面板配置、源码片段和仅Demo资产按交付职责区分。目录可搜索定位，示例不改业务demo样式。此页与示例数据仅在应用预览中，未进入公共库；API摘要不是公司平台注册manifest，内网构建与真实API仍待接入验证。需求与迭代见[REQ-027](collaboration/requests/REQ-027-ai-ui-overview/request.md)。

统一语义图标支持内网应用局部替换与默认回退：见 [图标接入文档](docs/ICONS.md)。公开入口提供 `AiIconProvider` / `AiIcon`，`ChatPanel` / `AgreementAssistantPanel` 支持 `icons`；规范总览示例 `/overview.html#icon-integration`。
