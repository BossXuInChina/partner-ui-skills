// Public data shapes mirror existing runtime behavior; no design/production approval.
export type TableRow = Record<string, unknown>;
export type TableRowKey = string | number;
export interface TableColumn {
  group?: { key: string; title: string };
  banded?: boolean;
  rowHeader?: boolean;
  key: string;
  title: string;
  field?: string | ((row: TableRow) => unknown);
  sortable?: boolean;
  filterable?: boolean;
  filtered?: boolean;
  primary?: boolean;
  ellipsis?: boolean;
  filterOptions?: TableFilterOption[];
  filterMultiple?: boolean;
  width?: string | number;
  minWidth?: string | number;
  maxWidth?: string | number;
  fixed?: 'left' | 'right';
  fluid?: boolean;
  align?: 'left' | 'center' | 'right' | 'start' | 'end';
  resizable?: boolean;
}
export interface TableRowGroup {
  columnKey: string;
  key: string | ((row: TableRow) => TableRowKey | null | undefined);
}
export type TableSort = { key: string; direction: 'asc' | 'desc' } | null;
export interface TableAction {
  id: string;
  label: string;
  type?: 'link' | 'action';
  href?: string;
  disabled?: boolean | ((row: TableRow) => boolean);
  [field: string]: unknown;
}
export interface TableCellScope {
  value: string;
  row: TableRow;
  column: TableColumn;
  rowIndex: number;
}
export interface TableHeaderScope {
  column: TableColumn;
}
export interface TableFilterOption {
  value: string | number;
  label: string;
  disabled?: boolean;
}
export type TableColumnFilters = Record<string, (string | number)[]>;
export interface TableColumnFilterChange {
  key: string;
  column: TableColumn;
  values: (string | number)[];
  columnFilters: TableColumnFilters;
  source: 'option' | 'reset-column' | 'reset-all';
}
export interface TableSelection {
  selectedRowKeys: TableRowKey[];
  selectedRows: TableRow[];
  source: string;
}
export type TableColumnWidths = Record<string, number>;
export interface TableColumnWidthChange {
  key: string | null;
  width: number | null;
  columnWidths: TableColumnWidths;
  source: 'pointer' | 'keyboard' | 'button' | 'reset';
}
export interface FormRule {
  required?: boolean;
  message?: string;
  trigger?: string | string[];
  validator?: (value: unknown, model: Record<string, unknown>) => string | boolean | void;
}
export interface FormValidation {
  valid: boolean;
  errors: FormFieldResult[];
}
export interface FormFieldResult {
  prop: string;
  status: '' | 'error';
  message: string;
}

export type AvatarSize = 24 | 40 | 48 | 60 | 80 | 120;
export type AvatarColor = 'default' | 'blue' | 'cyan' | 'indigo' | 'green' | 'orange' | 'purple';
export type AvatarGroupLayout = 'row' | 'multiline';
export interface AvatarGroupItem {
  id?: string | number;
  text?: string;
  color?: AvatarColor;
  src?: string;
  icon?: boolean;
  label?: string;
}

export interface TabItem {
  value: string | number;
  label: string;
  disabled?: boolean;
  closable?: boolean;
}

export type * from './card-blocks.js';
export type * from './home-blocks.js';

export interface FollowupRow {
  id: string;
  name: string;
  member: string[];
}
export interface FollowupMember {
  value: string;
  label: string;
  disabled?: boolean;
}
export interface ReadonlyField {
  key: string;
  label: string;
  value?: unknown;
  format?: (value: unknown) => string;
  tone?: string;
  copy?: boolean;
  size?: string;
  class?: string;
}
export interface TransactionStageItem {
  title: string;
  state?: string;
  clickable?: boolean;
  disabled?: boolean;
  [key: string]: unknown;
}

export interface StaticField {
  key: string;
  label: string;
  value?: unknown;
  format?: (value: unknown, model: Record<string, unknown>) => string | null | undefined;
  copy?: boolean;
  color?: 'primary' | 'secondary' | 'success' | 'error' | 'action';
  href?: string;
  target?: string;
}
