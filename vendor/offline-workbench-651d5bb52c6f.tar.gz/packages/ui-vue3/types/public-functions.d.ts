import type { Ref, ComputedRef, MaybeRefOrGetter } from 'vue';
export type WorkbenchJsonValue =
  string | number | boolean | null | WorkbenchJsonValue[] | { [key: string]: WorkbenchJsonValue };
export type WorkbenchQueryModel = Record<string, WorkbenchJsonValue>;
export declare const useQueryTransaction: (options: {
  fields: Array<string | { key: string; default?: WorkbenchJsonValue }>;
  scope?: MaybeRefOrGetter<unknown>;
  page?: Ref<number>;
  pageSize?: Ref<number>;
  total?: MaybeRefOrGetter<number>;
}) => {
  draft: WorkbenchQueryModel;
  applied: WorkbenchQueryModel;
  expanded: Ref<boolean>;
  confirm(): void;
  cancel(): void;
  reset(): void;
  remove(key: string): void;
};
export declare const useScopedSelection: <Id extends string | number>(options: {
  scope: MaybeRefOrGetter<unknown>;
  visibleIds: MaybeRefOrGetter<Id[]>;
  disabledIds?: MaybeRefOrGetter<Id[]>;
}) => {
  selectedIds: Ref<Id[]>;
  selectedCount: ComputedRef<number>;
  checked: ComputedRef<boolean>;
  indeterminate: ComputedRef<boolean>;
  toggle(id: Id, checked: boolean): void;
  toggleAll(checked: boolean): void;
  clear(): void;
};
export declare const useStageBrowsing: (options: {
  current: MaybeRefOrGetter<number>;
  count: MaybeRefOrGetter<number>;
  viewed?: MaybeRefOrGetter<number>;
}) => { viewedStage: Ref<number>; browse(index: number): void; goCurrent(): void };
export type WorkbenchSaveResult<T> = { ok: true; value: T } | { ok: false; error: unknown };
export declare const useEditTransaction: <T extends WorkbenchQueryModel>(options: {
  model: T;
  active: MaybeRefOrGetter<boolean>;
}) => {
  baseline: Ref<T>;
  dirty: ComputedRef<boolean>;
  leaveOpen: Ref<boolean>;
  pendingNavigation: Ref<(() => void) | null>;
  saving: Ref<boolean>;
  error: Ref<unknown>;
  reset(value: T): void;
  markSaved(): void;
  navigate(action: () => void): boolean;
  confirmLeave(): void;
  cancelLeave(): void;
  runSave<R>(action: () => R | Promise<R>): Promise<WorkbenchSaveResult<R>>;
};
export type WorkbenchContentState =
  | { kind: 'loading'; type: 'loading'; recovery: null }
  | { kind: 'error'; type: 'load-failed'; recovery: 'retry' }
  | { kind: 'content'; type: 'content'; recovery: null }
  | { kind: 'filtered'; type: 'no-results'; recovery: 'reset' }
  | { kind: 'future'; type: 'no-data'; recovery: 'go-current' }
  | { kind: 'empty'; type: 'no-data'; recovery: 'create' };
export declare const resolveContentState: (options?: {
  loading?: boolean;
  error?: unknown;
  count?: number;
  filtered?: boolean;
  future?: boolean;
}) => WorkbenchContentState;

export interface DraftCommitRecord {
  defaults?: Record<string, WorkbenchJsonValue>;
  draft?: Record<string, WorkbenchJsonValue> | null;
  arranged?: Record<string, WorkbenchJsonValue> | null;
  result?: string;
}
export type DraftCommitOutcome =
  | { ok: true }
  | { ok: false; reason: 'unavailable' | 'cancelled' | 'stale' | 'failed'; error?: unknown };
export declare const useDraftThenCommit: (initial?: DraftCommitRecord) => {
  record: Readonly<Ref<Readonly<DraftCommitRecord>>>;
  stage: ComputedRef<'pending' | 'draft' | 'arranged' | 'resulted'>;
  pending: Readonly<Ref<boolean>>;
  error: Readonly<Ref<unknown>>;
  saveDraft(value: Record<string, WorkbenchJsonValue>): boolean;
  commit(
    action: (
      draft: Record<string, WorkbenchJsonValue>,
    ) => Record<string, WorkbenchJsonValue> | Promise<Record<string, WorkbenchJsonValue>>,
    confirm?: (draft: Record<string, WorkbenchJsonValue>) => boolean | Promise<boolean>,
  ): Promise<DraftCommitOutcome>;
  updateResult(value: { status: string; result: string }): boolean;
  reset(value?: DraftCommitRecord): void;
};
