// Data contracts for the homepage Blocks registered on 2026-11-04.

export interface TabsHeaderItem {
  value: string | number;
  label: string;
  /** Optional count shown as a corner badge on the tab. */
  badge?: number;
  disabled?: boolean;
}

export interface FilterChipItem {
  value: string;
  label: string;
  /** Optional count appended as `label(count)`. */
  count?: number;
}

export interface PolicyLinkItem {
  label: string;
  href?: string;
}

export type InfoListTagStatus =
  'waiting' | 'info' | 'success' | 'warning' | 'alert' | 'error' | 'none';
export interface InfoListItem {
  title: string;
  href?: string;
  /** [label, status] pairs rendered as subtle status tags. */
  tags?: Array<[string, InfoListTagStatus]>;
  time: string;
}

export interface CertificationDetailsData {
  type: string;
  region: string;
  start: string;
  end: string;
  review: string;
}

export interface EventCalendarEvent {
  id: string | number;
  /** YYYY-MM-DD */
  date: string;
  title: string;
  type: string;
  time: string;
  place: string;
}
