export type CardVariant = 'display-white' | 'display-tinted' | 'operation' | 'navigation';
export type CardSize = 's' | 'm' | 'l' | 'xl' | 'xxl' | 'xxxl';
export type CardLayout = 'row' | 'multi' | 'column';
export interface CardAction {
  id: string;
  label: string;
  appearance?: 'primary' | 'secondary' | 'text' | 'icon';
  icon?: string;
  disabled?: boolean;
}
export type CardFooter =
  | { kind: 'metadata'; text: string }
  | {
      kind: 'progress';
      value: number;
      label?: string;
      expectedValue?: number;
      targetLabel?: string;
    };
export interface CardActionEvent {
  id: string;
  source: 'header' | 'actions';
  event: MouseEvent;
}
export interface CardBaseProps {
  title?: string;
  variant?: CardVariant;
  size?: CardSize;
  href?: string;
  target?: string;
  rel?: string;
  headerActions?: CardAction[];
  footer?: CardFooter | null;
  actions?: CardAction[];
}
export interface MetricItem {
  id: string;
  label: string;
  value?: string | number | null;
  truncate?: boolean;
}
export interface MetricCardProps extends CardBaseProps {
  variant?: 'display-white';
  layout?: CardLayout;
  items?: MetricItem[];
  labelPosition?: 'above' | 'below';
}
export interface InformationCardProps extends CardBaseProps {
  structure?: 'icon' | 'text-action';
  bodySize?: 14;
  description?: string;
  tags?: string[];
}
export interface MediaCardProps extends CardBaseProps {
  bodySize?: 14;
  description?: string;
  tags?: string[];
  mediaKind?: 'video' | 'image';
  mediaLabel?: string;
  badge?: string;
}
export interface QuickAppItem {
  id: string;
  label: string;
  icon?: string;
  href?: string;
  target?: string;
  rel?: string;
  disabled?: boolean;
}
export interface QuickAppCardProps extends CardBaseProps {
  variant?: 'display-white';
  layout?: CardLayout;
  items?: QuickAppItem[];
}
export interface QuickAppActivateEvent {
  item: QuickAppItem;
  event: MouseEvent;
}
