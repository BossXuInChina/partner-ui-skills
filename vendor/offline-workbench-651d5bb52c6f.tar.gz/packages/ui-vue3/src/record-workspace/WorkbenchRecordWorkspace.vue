<script setup>
import WorkbenchCheckbox from '../choice/WorkbenchCheckbox.vue';

defineProps({
  toolbarClass: { type: String, default: '' },
  selectedCount: { type: Number, default: 0 },
  selectableCount: { type: Number, default: 0 },
  checked: Boolean,
  indeterminate: Boolean,
});
const emit = defineEmits(['toggle-all']);
</script>

<template>
  <section class="record-workspace">
    <div
      class="record-toolbar"
      :class="toolbarClass"
    >
      <div class="record-toolbar__left">
        <slot name="filters" />
        <div class="record-toolbar__selection">
          <WorkbenchCheckbox
            :model-value="checked"
            :indeterminate="indeterminate"
            :disabled="!selectableCount"
            label="全选"
            @update:model-value="emit('toggle-all', $event)"
          />
          <span>已选择 {{ selectedCount }} 项</span>
        </div>
      </div>
      <div
        v-if="$slots.actions"
        class="record-toolbar__actions"
      >
        <slot name="actions" />
      </div>
    </div>
    <slot />
    <slot name="footer" />
  </section>
</template>

<style scoped>
.record-workspace {
  display: grid;
  gap: var(--wb-spacing-layout-content-gap);
  min-width: 0;
}
.record-toolbar,
.record-toolbar__left,
.record-toolbar__actions {
  display: flex;
  flex-wrap: wrap;
  min-width: 0;
}
.record-toolbar,
.record-toolbar__left {
  align-items: end;
}
.record-toolbar {
  gap: var(--wb-spacing-component-md);
}
.record-toolbar__left {
  column-gap: var(--wb-spacing-component-lg);
  row-gap: var(--wb-spacing-component-md);
}
.record-toolbar__actions {
  align-items: center;
  gap: var(--wb-spacing-component-sm);
  margin-inline-start: auto;
}
.record-toolbar__selection {
  display: flex;
  align-items: center;
  gap: var(--wb-spacing-component-md);
  min-block-size: var(--wb-asset-wb-button-height-32);
  color: var(--wb-color-text-secondary);
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
}
</style>
