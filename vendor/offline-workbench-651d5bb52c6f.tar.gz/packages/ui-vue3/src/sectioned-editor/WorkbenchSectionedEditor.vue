<script setup>
import WorkbenchCard from '../card/WorkbenchCard.vue';
import WorkbenchContentSection from '../content-section/WorkbenchContentSection.vue';

defineProps({
  sections: { type: Array, required: true },
});
</script>

<template>
  <div class="sectioned-editor">
    <WorkbenchCard
      v-for="section in sections"
      :key="section.id"
    >
      <WorkbenchContentSection :title="section.title">
        <template
          v-if="$slots[section.id + '-actions']"
          #actions
        >
          <slot
            :name="section.id + '-actions'"
            :section="section"
          />
        </template>
        <slot
          :name="section.id"
          :section="section"
        >
          <slot :section="section" />
        </slot>
        <template
          v-if="$slots[section.id + '-footer']"
          #footer
        >
          <slot
            :name="section.id + '-footer'"
            :section="section"
          />
        </template>
      </WorkbenchContentSection>
    </WorkbenchCard>
  </div>
</template>

<style scoped>
.sectioned-editor {
  display: grid;
  gap: var(--wb-spacing-layout-card-gap);
  min-inline-size: 0;
}
</style>
