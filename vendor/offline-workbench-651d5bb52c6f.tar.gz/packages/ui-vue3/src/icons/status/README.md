# 状态图标

来自 Pixso 图标库的「状态图标」页（258:63），与系统图标分开注册。

```vue
<script setup>
import { WorkbenchStatusIcon } from '@workbench/ui-vue3';
</script>

<template>
  <WorkbenchStatusIcon name="成功 · 线框_16px" label="成功" />
</template>
```

- 公开参数：`name`、`label`；兼容 `size` 仅选择同状态/样式的真实尺寸资产，不缩放。未声明的宽高/样式属性不会透传，配色由原始资产确定。
- 优先复制保留用途名的尺寸索引，例如 `成功 · 线框_16px`。旧 key（如 `alert-orange/cutout/24`）保留追溯和兼容；新名由统一索引生成器产生。
- 原始尺寸：12、14、16、20、24、40、48 px。选择不同名称代表选择另一份原始 SVG。
- 状态：`success`、`info`、`questionmark_circle`、`warning`、`alert-orange`、`alert-red`、`close_circle`。
- 样式：`outline`（线框）、`cutout`（填充镂空）、`solid`（填充白色符号）。
- 保留原始路径、viewBox、状态色和透明镂空；147 个版本经原尺寸和 4 倍渲染像素比对，无完全相同的重复项。
- Studio 图标库按原生尺寸显示，卡片是独立点击热区，复制调用不含缩放参数。尺寸来源、原名和冲突见统一 `../generated/index.json` 及 `../README.md`。

原始节点 ID、名称、颜色及渲染指纹记录在 `manifest.json`。
