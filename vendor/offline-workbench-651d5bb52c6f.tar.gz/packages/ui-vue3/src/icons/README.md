# Workbench 原生尺寸图标

五族图标清单与原始 SVG 是输入。`generated/index.json` 保留系统、状态、文件的完整证据；`generated/runtime/` 是五族选择和预计算画布数据，不含设计溯源。运行 `pnpm run icons:compile` 更新全部派生文件，`pnpm run icons:check` 检查索引和消费方。UI 构建检查派生文件是否过期，不自动修改 SVG 或清单。

公开组件通过分族 loader 按需导入原始 SVG，原生布局盒在资源加载前即建立。`data-icon-loading="true"` 表示资源仍在加载；加载失败通过 `data-icon-error` 诊断，不替换为其他图标。并发请求共享同一导入，换名和卸载会忽略迟到结果；可访问名称、原始绘制和尺寸规则保持不变。

`generated/compat/` 暂存 Studio 同步 `iconManifest` 展示和搜索所需的少量来源字段；它仍会随相应图标组件加载，不能称为已经完全移出运行路径。后续 Studio 应显式消费开发元数据再移除此兼容层。完整证据只由非组件的 `iconRegistry.js` 和维护门禁消费，公开组件依赖图不得重新引入原始清单或完整索引。

原生动态样式的精确迁移绑定位于包根 `native-geometry-bindings.json`，受 `check-design-literals` 校验。它只替换已有发布者的相同表达式，并锁定源码、解析器与分族运行数据 SHA；源码或几何数据变化后必须先复核原生尺寸及画布行为，不能自动重绑以消除失败。

公开名称保留现有用途名，在末尾补 `_14px` 或 `_16x12px`。原名内的尺寸字段统一为这个后缀，避免重复；旧节点冒号 ID 留在 `sourceNode`、`legacyKey` 中。`originalName` 原样保留清单记录的源名称（若源清单只保留加工名称，不声称已重新取得 Pixso 原文）。同名同尺寸仍有多个资产时 `alias=null`，列入 `nameConflicts`，不自动合并或拼随机编号。

```vue
<WorkbenchIcon name="/ic_public_plus_line_14px" color="var(--wb-color-icon-primary)" />
<WorkbenchStatusIcon name="成功 · 线框_14px" label="成功" />
<WorkbenchFileIcon name="文件/pdf_16px" label="PDF文件" />
```

`native.width/height` 与 SVG 导出画布、viewBox、名称尺寸分别管理。已有登记节点宽高和 SVG 内唯一、透明且直接位于根节点的源设计框一致时，采用登记/源框尺寸，证据为 `registered-and-source-frame`；导出画布因边界扩展而不同不会单独导致停用。出现额外嵌套画板则不擅自确定应取哪一框。SVG 数值导出宽高与登记一致可作为另一种证据；没有数值导出宽高但有可靠登记源节点时标为 `registered-source-node`。0.001px仅用于比较导出浮点序列化精度。

某些复合图标有明确既有几何合同，以完整导出画布为本体、登记尺寸作为内部锚框。此时源manifest以 `nativeSizeSource: "svg-export"` 显式说明，宽高仍从SVG读取，不复制维护一套数值。语言图标保留完整非方形画布和原有球心对齐；不得把它压成20×20。没有可核实依据的冲突才标unknown并通过 `data-icon-error`/控制台诊断停止渲染。

源设计框与导出画布不同的资产，布局盒使用源框尺寸，内部 SVG 保留原导出宽高与 viewBox，仅按源框在画布中的位置对齐，允许边界外溢。不得把完整导出画布压入较小的布局盒。viewBox 在这里仅用于定位已经确认的源框，不提供原生尺寸。浏览器对子像素尺寸的栅格化不代表允许消费方缩放。

viewBox只记录坐标系，不证明显示尺寸或光学校准。`namedSize`只是原名中的尺寸线索，不提供native数值；`sourceFrame`、`registered`、`exported`、`sourceViewBox`独立保留。`native.opticalSize`缺少设计声明时保持unknown。纯可读名称冲突不会禁止唯一旧key的原生尺寸调用；Studio可复制该旧调用并说明待补新名。

旧 key 继续追溯同一份资产。`size` 兼容参数仅接受正数或 px 数值，并且只能选择同一原始语义/状态/样式组中唯一的真实尺寸变体；不会把某个 SVG 缩放到请求值。缺少或有歧义时输出 `ICON_NATIVE_VARIANT_MISSING/AMBIGUOUS`，百分比、em、CSS变量等输出 `ICON_SIZE_NOT_NATIVE`。新 alias 已指定尺寸，不能再用 size 改成另一尺寸。优先直接复制带尺寸的新索引。

用户明确批准的替代在原记录登记 `replacementKey`、`replacementDecision` 与原因；原文件、节点、登记/导出尺寸继续保留。解析仅指向同家族唯一、已确认尺寸的真实目标，不允许循环/串联替代，也不允许旧key再用size选另一个尺寸。当前“导航图标/单色/名称=我的”按用户选择映射至 `/ic_public_person_filed#134:74`（16px filled），属于已批准样式变更；不自动合并两份同名人物资产。

Steps的图标仍由WorkbenchIcon统一管理，WorkbenchSteps仅负责状态映射。原生32px异常资产来自Pixso `.节点步骤指示` 的节点 `3:231246`，按1x原样导出，系统库以 `.节点步骤指示/组件尺寸=大尺寸, 进行状态=异常图标, 获焦状态=默认_32px` 检索和复制；不把24px提示资产放大到32px。

图标与点击热区分别管理。图标入口拒绝 style、width、height 等透传，以原生宽高及 min/max 尺寸固定本体；消费 CSS 不得改图标或其 SVG 的宽高、scale/zoom、stroke/fill/线宽。允许公开颜色参数或已有颜色 Token 调整原本可着色部分，纯旋转方向不属于缩放。外层按钮、间距和可点击区域可大于本体。图标库预览按原生尺寸显示，复制调用不带缩放参数。

`line` SVG 内部用 fill 描绘轮廓是合法资产结构；索引样式来自已有命名/状态元数据，不以 path 是否使用 fill 猜测。状态 solid/cutout 是独立合法变体。自绘操作图标是否替换仍按专项决策表逐项确认，本次索引改造不批准所有相似候选。
