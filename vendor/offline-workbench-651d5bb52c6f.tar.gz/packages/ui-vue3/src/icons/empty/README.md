# Workbench 空状态插画图标

独立登记空状态插画资产，来源为 Pixso `.插画` 组件集 `895:2408`。清单按语义和原生尺寸记录每个原始 SVG；不依赖系统、状态或文件图标索引。

```vue
<WorkbenchEmptyIcon type="no-data" :size="120" />
<WorkbenchEmptyIcon type="network-error" :size="64" label="网络异常" />
<WorkbenchEmptyIcon name="empty/coming-soon_240px" />
```

| 参数 | 说明 |
| --- | --- |
| `type` | `no-data`、`no-results`、`network-error`、`load-failed`、`forbidden`、`removed`、`expired`、`coming-soon`；默认 `no-data` |
| `size` | 仅接受 64、120、240；默认 120。7 种非网络异常图标以 64px SVG 按比例缩放；网络异常保留三个原生尺寸 |
| `name` | 可传 manifest 中的 `key` 或 `alias`；命名调用固定对应资源和原档尺寸 |
| `label` | 默认空。空时作为装饰图隐藏于辅助技术；设置后将内容作为替代文本 |

按 `type` 与 `size` 调用时，`no-data`、`no-results`、`load-failed`、`forbidden`、`removed`、`expired`、`coming-soon` 统一使用各自的 64px SVG viewBox，并由 `<img>` 的请求尺寸等比渲染至 64、120 或 240px。`network-error` 在三个尺寸下仍分别加载对应原生 SVG。通过 `name` 调用时仍使用 manifest 指定的独立原档，不进行替代或缩放。组件不透传消费方的 `style`、`width`、`height` 或其他绘制属性；外层布局负责控制间距。
