<script setup>
import { computed } from 'vue';
import WorkbenchDropdown from '../dropdown/WorkbenchDropdown.vue';
import WorkbenchCard from '../card/WorkbenchCard.vue';
import WorkbenchButton from '../button/WorkbenchButton.vue';
import WorkbenchCheckbox from '../choice/WorkbenchCheckbox.vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import WorkbenchTag from '../tag/WorkbenchTag.vue';
const props = defineProps({
  title: { type: String, required: true },
  href: String,
  status: { type: String, default: '' },
  tone: { type: String, default: 'info' },
  tags: { type: Array, default: () => [] },
  selectable: Boolean,
  selectDisabled: Boolean,
  selected: Boolean,
  selectLabel: { type: String, default: '' },
  favorite: Boolean,
  starred: Boolean,
  openOnTitle: Boolean,
  deletable: Boolean,
  actions: { type: Array, default: () => [] },
});
const emit = defineEmits(['select', 'favorite', 'open', 'delete', 'action']);
const menuItems = computed(() =>
  props.deletable
    ? [...props.actions, { id: 'delete', label: '删除', type: 'action' }]
    : props.actions,
);
function chooseAction(item) {
  if (item.id === 'delete') emit('delete');
  else emit('action', item);
}
function openTitle(event) {
  // Modified clicks retain the real deep link (e.g. open in a new tab).
  if (event.button || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
  event.preventDefault();
  emit('open');
}
function openCard(event) {
  if (
    !props.href ||
    event.defaultPrevented ||
    event.button ||
    event.metaKey ||
    event.ctrlKey ||
    event.shiftKey ||
    event.altKey
  )
    return;
  // The title link provides keyboard access while the card's controls and text remain usable.
  const controls =
    'a,button,input,select,textarea,label,summary,[role="button"],[role="checkbox"],[tabindex]:not([data-record-field-text]),[contenteditable]';
  // The event path retains the original button if Vue replaces the clicked icon.
  const path = event.composedPath();
  if (
    path
      .slice(0, path.indexOf(event.currentTarget))
      .some((node) => node instanceof Element && node.matches(controls)) ||
    window.getSelection()?.toString()
  )
    return;
  emit('open');
}
</script>

<template>
  <article
    class="record-card-entry"
    :class="{ 'is-interactive': href }"
    @click="openCard"
  >
    <WorkbenchCard
      variant="operation"
      class="record-card"
    >
      <div class="record-card__layout">
        <div
          v-if="selectable"
          class="record-card__check"
        >
          <WorkbenchCheckbox
            :model-value="selected"
            :disabled="selectDisabled"
            :aria-label="selectLabel || `选择BOQ ${title}`"
            @update:model-value="emit('select', $event)"
          />
        </div>
        <div class="record-card__content">
          <div class="record-card__header">
            <div class="record-card__identity">
              <h3>
                <a
                  v-if="href"
                  class="record-card__title-link"
                  :href="href"
                  @click="openTitle"
                  >{{ title }}</a
                >
                <WorkbenchButton
                  v-else-if="openOnTitle"
                  appearance="text"
                  text-layout="inline"
                  @click="emit('open')"
                >
                  <span class="record-card__title-text">{{ title }}</span>
                </WorkbenchButton>
                <template v-else>{{ title }}</template>
              </h3>
              <div
                v-if="status || tags.length || favorite"
                class="record-card__meta"
              >
                <WorkbenchTag
                  v-if="status"
                  :label="status"
                  variant="status-subtle"
                  :status="tone"
                />
                <WorkbenchTag
                  v-for="tag in tags"
                  :key="typeof tag === 'string' ? tag : tag.label"
                  :label="typeof tag === 'string' ? tag : tag.label"
                  :show-full="typeof tag === 'object' && tag.showFull"
                  variant="status-subtle"
                  :status="typeof tag === 'object' ? tag.tone || 'info' : 'info'"
                />
                <WorkbenchButton
                  v-if="favorite"
                  appearance="icon"
                  icon-layout="container"
                  size="24"
                  :aria-label="starred ? '取消收藏' : '收藏'"
                  :aria-pressed="starred"
                  @click="emit('favorite')"
                  ><template #icon
                    ><WorkbenchIcon
                      :name="starred ? '/ic_public_star_filed' : '/ic_public_star_line'"
                      :size="14"
                      :color="
                        starred ? 'var(--wb-color-warning)' : 'var(--wb-color-icon-primary)'
                      " /></template
                ></WorkbenchButton>
              </div>
            </div>
            <div
              v-if="$slots['header-actions'] || menuItems.length"
              class="record-card__actions"
            >
              <slot name="header-actions">
                <WorkbenchDropdown
                  :items="menuItems"
                  aria-label="操作"
                  @action="chooseAction"
                >
                  <template #trigger>操作</template>
                </WorkbenchDropdown>
              </slot>
            </div>
          </div>
          <div class="record-card__fields"><slot /></div>
          <footer
            v-if="$slots.footer || $slots.progress"
            class="record-card__footer"
          >
            <slot name="footer"><slot name="progress" /></slot>
          </footer>
        </div>
      </div>
    </WorkbenchCard>
  </article>
</template>

<style scoped>
/* Business-card affordance: keep the operation component and its controls intact. */
.record-card-entry {
  min-width: 0;
  margin: 0;
  border-radius: var(--wb-radius-lg);
}
.record-card-entry.is-interactive {
  cursor: pointer;
}
.record-card-entry.is-interactive:hover,
.record-card-entry.is-interactive:focus-within {
  box-shadow: var(--wb-shadow-md);
}
.record-card {
  padding: var(--wb-spacing-component-lg);
}
.record-card__layout {
  display: flex;
  align-items: center;
  gap: var(--wb-spacing-component-lg);
}
.record-card__check {
  display: flex;
  flex: none;
}
.record-card__content {
  flex: 1;
  min-width: 0;
}
.record-card__header {
  display: flex;
  min-width: 0;
  align-items: center;
  justify-content: space-between;
  gap: var(--wb-spacing-layout-content-gap);
}
.record-card__identity,
.record-card__meta {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--wb-spacing-component-sm);
  min-width: 0;
}
.record-card__identity h3 {
  margin: 0;
  color: var(--wb-color-text-primary);
  font-size: var(--wb-font-headline-s-font-size);
  font-weight: var(--wb-font-headline-s-font-weight);
  line-height: var(--wb-font-headline-s-line-height);
  overflow-wrap: anywhere;
  letter-spacing: var(--wb-font-headline-s-letter-spacing);
}
.record-card__title-link {
  color: inherit;
  text-decoration: none;
  text-decoration-thickness: var(--wb-asset-wb-link-underline-thickness);
  text-underline-offset: var(--wb-asset-wb-link-underline-offset);
}
.record-card__title-link:hover {
  color: var(--wb-color-link-hover);
  text-decoration: none;
}
.record-card__title-link:focus-visible {
  text-decoration: none;
  outline: var(--wb-asset-wb-link-focus-outline-width) solid var(--wb-color-border-focus);
  outline-offset: var(--wb-asset-wb-link-focus-outline-offset);
}
.record-card__title-link:active {
  color: var(--wb-color-link-active);
  text-decoration: none;
}
.record-card__title-text {
  color: var(--wb-color-text-primary);
  font-size: var(--wb-font-headline-s-font-size);
  font-weight: var(--wb-font-headline-s-font-weight);
  line-height: var(--wb-font-headline-s-line-height);
  letter-spacing: var(--wb-font-headline-s-letter-spacing);
  white-space: normal;
  overflow-wrap: anywhere;
}
.record-card__title-text:hover {
  color: var(--wb-color-link-hover);
  text-decoration: none;
}
.record-card__actions {
  flex: none;
  margin-inline-start: auto;
}
.record-card__fields {
  margin-block-start: var(--wb-spacing-layout-content-gap);
  min-width: 0;
}
.record-card__footer {
  min-width: 0;
}
@media (width < 768px) {
  .record-card__header {
    flex-wrap: wrap;
  }
}
</style>
