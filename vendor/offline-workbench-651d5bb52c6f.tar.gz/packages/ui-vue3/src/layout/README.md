# 图标与文字对齐

组件先使用 flex 的 align-items:center、完整 Foundation 字体组合、明确图标尺寸和 gap。SVG 使用块级盒，避免行内图片基线空隙。行框居中不代表字形墨迹居中，只有经确认的光学差异才使用本目录补偿。

导入 inline-label.css，在文字 span 添加 wb-inline-label，并在该 span 上设置 --inline-label-optical-offset 为自身资产 token。默认值为 0；局部赋值可避免组合组件间继承污染。只移动文字绘制位置，不改点击区域、行高或图标位置。

Button 当前使用已确认的 1px；其他组件不自动启用。禁止页面级 top/transform 修补，禁止把 Button 参数借给其他组件。原生 input/textarea 文本不能套文字 span，不对原生输入控件整体移动；应先检查行高、内边距和字体加载。

验收包含字体加载完成后的中文、英文、混排、12/14px、前置/后置图标、纯文字对照及深浅主题。公司内部框架适配时复用此流程与组件合同，重新测量实际字体与图标，不照搬偏移量。
