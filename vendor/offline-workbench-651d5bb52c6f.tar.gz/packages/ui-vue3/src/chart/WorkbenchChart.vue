<script setup>
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import { computed, onBeforeUnmount, onMounted, ref, useId, useSlots } from 'vue';
import {
  arcPath,
  axisTicks,
  barLayout,
  formatNumber,
  gaugeAngle,
  gaugeStart,
  gaugeSweep,
  linePoints,
  niceMax,
  polar,
  radarPoints,
  ringSegments,
  sectorPath,
  seriesColor,
  smoothPath,
  stackedMax,
} from './chartGeometry.js';

const props = defineProps({
  type: {
    type: String,
    default: 'bar',
    validator: (value) =>
      ['bar', 'line', 'area', 'bar-horizontal', 'donut', 'pie', 'gauge', 'radar'].includes(value),
  },
  appearance: {
    type: String,
    default: 'default',
    validator: (value) => ['default', 'analysis'].includes(value),
  },
  categories: { type: Array, default: () => [] },
  series: { type: Array, default: () => [] },
  height: { type: Number, default: 240 },
  unit: { type: String, default: '' },
  unitRight: { type: String, default: '' },
  max: Number,
  maxRight: Number,
  ticks: { type: Number, default: 5 },
  barWidth: { type: Number, default: 12 },
  showValues: Boolean,
  legend: { type: Boolean, default: true },
  tooltip: { type: Boolean, default: true },
  formatter: { type: Function, default: null },
  labelRotate: Boolean,
  centerValue: { type: [String, Number], default: '' },
  centerUnit: { type: String, default: '' },
  centerLabel: { type: String, default: '' },
  showPercent: Boolean,
  thickness: { type: Number, default: 0 },
  value: { type: Number, default: 0 },
  min: { type: Number, default: 0 },
  color: { type: String, default: '' },
  segments: { type: Array, default: () => [] },
  scaleLabels: { type: Array, default: () => [] },
  gaugeMarker: { type: Boolean, default: true },
  status: { type: String, default: '' },
  indicators: { type: Array, default: () => [] },
  ariaLabel: { type: String, default: '图表' },
});

const slots = useSlots();
const hasGaugeCenter = () => props.type === 'gauge' && Boolean(slots['gauge-center']);

const id = useId();
const root = ref(null);
const width = ref(480);
const hover = ref(-1);
const pointer = ref({ x: 0, y: 0 });
let observer = null;

onMounted(() => {
  const measure = () => {
    if (root.value?.clientWidth) width.value = root.value.clientWidth;
  };
  measure();
  if (typeof ResizeObserver !== 'undefined') {
    observer = new ResizeObserver(measure);
    observer.observe(root.value);
  }
});
onBeforeUnmount(() => observer?.disconnect());

const format = (value, series) =>
  props.formatter ? props.formatter(value, series) : formatNumber(value);
const paint = (color) => ({ fill: color });
const stroke = (color) => ({ stroke: color });
const isCartesian = computed(() => ['bar', 'line', 'area'].includes(props.type));
const isRing = computed(() => ['donut', 'pie'].includes(props.type));
const analysis = computed(
  () => props.appearance === 'analysis' && ['donut', 'gauge'].includes(props.type),
);

const legendItems = computed(() => {
  if (isRing.value)
    return props.series.map((item, index) => ({
      name: item.name,
      paint: paint(seriesColor(item, index)),
    }));
  if (props.type === 'gauge') return [];
  return props.series.map((item, index) => ({
    name: item.name,
    paint: paint(seriesColor(item, index)),
    line: (item.type ?? (props.type === 'bar' ? 'bar' : props.type)) !== 'bar',
  }));
});

/* Cartesian charts */
const leftSeries = computed(() => props.series.filter((item) => item.axis !== 'right'));
const rightSeries = computed(() => props.series.filter((item) => item.axis === 'right'));
const plot = computed(() => {
  const left = 40;
  const right = rightSeries.value.length ? 40 : 12;
  const bottom = props.labelRotate ? 48 : 28;
  return {
    x: left,
    y: 12,
    width: Math.max(10, width.value - left - right),
    height: Math.max(10, props.height - 12 - bottom),
  };
});
const leftMax = computed(
  () =>
    props.max ??
    niceMax(
      stackedMax(
        leftSeries.value.filter((item) => (item.type ?? props.type) === 'bar'),
        props.categories,
      ) || Math.max(0, ...leftSeries.value.flatMap((item) => item.data ?? [])),
      props.ticks,
    ),
);
const rightMax = computed(
  () =>
    props.maxRight ??
    niceMax(Math.max(0, ...rightSeries.value.flatMap((item) => item.data ?? [])), props.ticks),
);
const yTicks = computed(() =>
  axisTicks(leftMax.value, props.ticks).map((value) => ({
    value,
    label: formatNumber(value),
    right: formatNumber((rightMax.value / leftMax.value) * value),
    y:
      plot.value.y +
      plot.value.height -
      (leftMax.value > 0 ? (value / leftMax.value) * plot.value.height : 0),
  })),
);
const slot = computed(() => plot.value.width / Math.max(1, props.categories.length));
const xLabels = computed(() =>
  props.categories.map((label, index) => ({
    label,
    x: plot.value.x + slot.value * index + slot.value / 2,
  })),
);
const bars = computed(() => {
  const entries = props.series
    .map((item, index) => ({ item, index }))
    .filter(({ item }) => (item.type ?? props.type) === 'bar');
  if (!entries.length) return [];
  const layout = barLayout({
    categories: props.categories,
    series: entries.map(({ item }) => item),
    plot: plot.value,
    max: leftMax.value,
    barWidth: props.barWidth,
  });
  return layout.rects.map((rect) => {
    const source = entries[rect.seriesIndex];
    return {
      ...rect,
      seriesIndex: source.index,
      paint: paint(seriesColor(source.item, source.index)),
      label: format(rect.value, source.item),
    };
  });
});
const lines = computed(() =>
  props.series
    .map((item, index) => ({ item, index }))
    .filter(({ item }) => ['line', 'area'].includes(item.type ?? props.type))
    .map(({ item, index }) => {
      const max = item.axis === 'right' ? rightMax.value : leftMax.value;
      const points = linePoints({
        data: item.data,
        categories: props.categories,
        plot: plot.value,
        max,
      });
      const path = smoothPath(points);
      const bottom = plot.value.y + plot.value.height;
      const area =
        (item.type ?? props.type) === 'area' && points.length
          ? `${path} L${points.at(-1).x},${bottom} L${points[0].x},${bottom} Z`
          : '';
      const color = seriesColor(item, index);
      return {
        key: index,
        path,
        area,
        points,
        stroke: stroke(color),
        paint: paint(color),
        stopPaint: { stopColor: color },
        gradient: `${id}-area-${index}`,
      };
    }),
);
const tooltipRows = computed(() =>
  hover.value < 0
    ? []
    : props.series.map((item, index) => ({
        name: item.name,
        value: format(item.data?.[hover.value], item),
        paint: paint(seriesColor(item, index)),
      })),
);

/* Horizontal bars */
const horizontal = computed(() => {
  const labelWidth = 72;
  const valueWidth = 48;
  const area = {
    x: labelWidth,
    y: 8,
    width: Math.max(10, width.value - labelWidth - valueWidth),
    height: Math.max(10, props.height - 36),
  };
  const max =
    props.max ??
    niceMax(Math.max(0, ...props.series.flatMap((item) => item.data ?? [])), props.ticks);
  const rowHeight = area.height / Math.max(1, props.categories.length);
  const item = props.series[0] ?? { data: [] };
  const color = seriesColor(item, 0);
  return {
    area,
    ticks: axisTicks(max, props.ticks).map((value) => ({
      value,
      label: formatNumber(value),
      x: area.x + (max > 0 ? (value / max) * area.width : 0),
    })),
    rows: props.categories.map((label, index) => {
      const value = Number(item.data?.[index]) || 0;
      const barWidth = max > 0 ? (value / max) * area.width : 0;
      return {
        label,
        value: format(value, item),
        y: area.y + rowHeight * index + rowHeight / 2,
        x: area.x,
        width: barWidth,
        paint: paint(color),
      };
    }),
  };
});

/* Donut and pie */
const ringSize = computed(() => Math.min(props.height, width.value));
const ring = computed(() => {
  const size = ringSize.value;
  const hasElbows = analysis.value && props.showPercent && size >= 72 && width.value >= 140;
  const showCallouts = props.showPercent && (!analysis.value || hasElbows);
  // Reserve space for the elbow and percentage at the sides of a narrow plot.
  const outer = hasElbows
    ? Math.max(0, Math.min(size / 2 - 27, width.value / 2 - 61))
    : size / 2 - (showCallouts ? 36 : 4);
  const requestedThickness = props.thickness || Math.max(8, Math.round(outer * 0.16));
  const analysisThickness = Math.min(requestedThickness, Math.max(0, outer));
  const thick =
    props.type === 'pie' ? outer : analysis.value ? analysisThickness : requestedThickness;
  const radius = analysis.value ? Math.max(0, outer - thick / 2) : outer - thick / 2;
  const cx = width.value / 2;
  const cy = size / 2;
  const gap = analysis.value ? (2 * 180) / (Math.PI * Math.max(1, radius)) : 1.5;
  const segments = ringSegments(
    props.series,
    props.type === 'donut' && props.series.length > 1 ? gap : 0,
  ).map((segment) => {
    const item = props.series[segment.index];
    const color = seriesColor(item, segment.index);
    const anchor = polar(cx, cy, outer + (hasElbows ? 0 : 6), segment.mid);
    const knee = polar(cx, cy, outer + (hasElbows ? 16 : 18), segment.mid);
    const side = knee.x >= cx ? 'start' : 'end';
    const label = hasElbows
      ? {
          x: side === 'start' ? Math.min(knee.x + 8, width.value - 52) : Math.max(knee.x - 8, 52),
          y: knee.y,
        }
      : knee;
    const elbowX = side === 'start' ? Math.min(knee.x, label.x) : Math.max(knee.x, label.x);
    return {
      ...segment,
      name: item.name,
      path:
        props.type === 'pie'
          ? sectorPath(cx, cy, outer, segment.start, segment.end)
          : arcPath(cx, cy, radius, segment.start, segment.end),
      stroke: stroke(color),
      paint: paint(color),
      anchor,
      label,
      side,
      leader: hasElbows ? `${anchor.x},${anchor.y} ${elbowX},${knee.y} ${label.x},${label.y}` : '',
      percentText: `${(segment.percent * 100).toFixed((segment.percent * 100) % 1 ? 2 : 0)} %`,
    };
  });
  return { cx, cy, radius, thick, outer, segments, showCallouts };
});

/* Gauge */
// The analysis gauge follows the 214 × 195 reference canvas, including the pointer.
const gaugeAnalysisWidth = computed(() => Math.min(width.value, (props.height * 214) / 195));
const gauge = computed(() => {
  const size = analysis.value ? gaugeAnalysisWidth.value : Math.min(props.height, width.value);
  const geometryScale = analysis.value ? size / 214 : 1;
  const thick =
    (props.thickness || (analysis.value ? 18 : Math.max(8, Math.round(size * 0.07)))) *
    geometryScale;
  const radius = size / 2 - thick / 2 - (props.scaleLabels.length ? 22 : analysis.value ? 0 : 4);
  const cx = width.value / 2;
  const cy = analysis.value ? 116.6 * geometryScale : size / 2 + size * 0.04;
  const max = props.max ?? 100;
  const end = gaugeAngle(props.value, props.min, max);
  const color = props.color || 'var(--wb-color-info-primary)';
  const segments = props.segments.map((segment, index) => {
    const from = index ? props.segments[index - 1].to : props.min;
    return {
      key: index,
      path: arcPath(
        cx,
        cy,
        radius,
        gaugeAngle(from, props.min, max),
        gaugeAngle(segment.to, props.min, max),
      ),
      stroke: stroke(segment.color),
    };
  });
  const tip = polar(cx, cy, radius + thick / 2 + 4, end);
  const tipA = polar(cx, cy, radius + thick / 2 + 12, end - 4);
  const tipB = polar(cx, cy, radius + thick / 2 + 12, end + 4);
  const pointer = polar(cx, cy, radius + thick / 2 + 12 * geometryScale, end);
  // The reference silhouette already includes the pointer angle at 60%.
  const referenceAngle = 27;
  const scale = props.scaleLabels.map((label, index, list) => {
    const angle = gaugeStart + (gaugeSweep / Math.max(1, list.length - 1)) * index;
    return {
      label,
      ...polar(cx, cy, radius - thick / 2 - 14, angle),
      anchor: angle < -10 ? 'start' : angle > 10 ? 'end' : 'middle',
    };
  });
  return {
    cx,
    cy,
    radius,
    thick,
    track: arcPath(cx, cy, radius, gaugeStart, gaugeStart + gaugeSweep),
    value: arcPath(cx, cy, radius, gaugeStart, end),
    stroke: stroke(color),
    paint: analysis.value ? undefined : paint(color),
    marker: analysis.value
      ? 'M-3.7,-9.8 L10.2,-2.7 Q11.5,-2 10.1,-1.4 L-0.6,2.9 Q-2,3.5 -2.3,2 L-4.7,-9 Q-5,-10.5 -3.7,-9.8 Z'
      : `M${tip.x},${tip.y} L${tipA.x},${tipA.y} L${tipB.x},${tipB.y} Z`,
    markerTransform: analysis.value
      ? `translate(${pointer.x} ${pointer.y}) rotate(${end - referenceAngle}) scale(${geometryScale})`
      : undefined,
    segments,
    scale,
  };
});

/* Radar */
const radar = computed(() => {
  const size = Math.min(props.height, width.value);
  const cx = width.value / 2;
  const cy = size / 2;
  const radius = size / 2 - 28;
  const step = 360 / Math.max(1, props.indicators.length);
  const rings = [0.25, 0.5, 0.75, 1].map((ratio) =>
    props.indicators
      .map((_, index) => polar(cx, cy, radius * ratio, step * index))
      .map((point) => `${point.x},${point.y}`)
      .join(' '),
  );
  const axes = props.indicators.map((indicator, index) => {
    const end = polar(cx, cy, radius, step * index);
    const label = polar(cx, cy, radius + 14, step * index);
    return {
      key: index,
      end,
      label,
      name: indicator.name,
      anchor: Math.abs(label.x - cx) < 4 ? 'middle' : label.x > cx ? 'start' : 'end',
    };
  });
  const shapes = props.series.map((item, index) => {
    const points = radarPoints({ indicators: props.indicators, data: item.data, cx, cy, radius });
    const color = seriesColor(item, index);
    return {
      key: index,
      points,
      polygon: points.map((point) => `${point.x},${point.y}`).join(' '),
      stroke: stroke(color),
      paint: paint(color),
    };
  });
  return { cx, cy, rings, axes, shapes };
});

const svgHeight = computed(() => {
  if (isCartesian.value || props.type === 'bar-horizontal') return props.height;
  if (analysis.value && props.type === 'gauge') return (gaugeAnalysisWidth.value * 195) / 214;
  return Math.min(props.height, width.value);
});
const tooltipPosition = computed(() => ({
  left: `${pointer.value.x}px`,
  top: `${pointer.value.y}px`,
}));

function onMove(event) {
  if (!isCartesian.value || !props.tooltip || !props.categories.length) return;
  const rect = root.value.getBoundingClientRect();
  const x = event.clientX - rect.left;
  const index = Math.floor((x - plot.value.x) / slot.value);
  hover.value = index >= 0 && index < props.categories.length ? index : -1;
  pointer.value = {
    x: Math.min(x + 12, rect.width - 160),
    y: Math.max(0, event.clientY - rect.top - 24),
  };
}
</script>

<template>
  <figure
    ref="root"
    class="wb-chart"
    :class="['wb-chart--' + type, { 'is-analysis': analysis }]"
    :aria-label="hasGaugeCenter() ? undefined : ariaLabel"
    :role="hasGaugeCenter() ? undefined : 'img'"
    @mousemove="onMove"
    @mouseleave="hover = -1"
  >
    <div
      v-if="isCartesian && (unit || unitRight)"
      class="wb-chart__units"
    >
      <span>{{ unit }}</span
      ><span>{{ unitRight }}</span>
    </div>
    <svg
      class="wb-chart__svg"
      :width="width"
      :height="svgHeight"
      :viewBox="`0 0 ${width} ${svgHeight}`"
      :aria-hidden="hasGaugeCenter() ? undefined : true"
      :role="hasGaugeCenter() ? 'img' : undefined"
      :aria-label="hasGaugeCenter() ? ariaLabel : undefined"
    >
      <template v-if="isCartesian">
        <defs>
          <linearGradient
            v-for="item in lines"
            :id="item.gradient"
            :key="item.gradient"
            x1="0"
            y1="0"
            x2="0"
            y2="1"
          >
            <stop
              offset="0"
              class="wb-chart__stop-top"
              :style="item.stopPaint"
            />
            <stop
              offset="1"
              class="wb-chart__stop-bottom"
              :style="item.stopPaint"
            />
          </linearGradient>
        </defs>
        <g class="wb-chart__grid">
          <line
            v-for="tick in yTicks"
            :key="tick.value"
            :x1="plot.x"
            :x2="plot.x + plot.width"
            :y1="tick.y"
            :y2="tick.y"
          />
        </g>
        <g class="wb-chart__axis-label">
          <text
            v-for="tick in yTicks"
            :key="'l' + tick.value"
            :x="plot.x - 8"
            :y="tick.y"
            text-anchor="end"
            dominant-baseline="middle"
          >
            {{ tick.label }}
          </text>
          <template v-if="rightSeries.length">
            <text
              v-for="tick in yTicks"
              :key="'r' + tick.value"
              :x="plot.x + plot.width + 8"
              :y="tick.y"
              dominant-baseline="middle"
            >
              {{ tick.right }}
            </text>
          </template>
          <text
            v-for="(item, index) in xLabels"
            :key="'x' + index"
            :x="item.x"
            :y="plot.y + plot.height + 16"
            :text-anchor="labelRotate ? 'end' : 'middle'"
            :transform="
              labelRotate ? `rotate(-35 ${item.x} ${plot.y + plot.height + 16})` : undefined
            "
          >
            {{ item.label }}
          </text>
        </g>
        <rect
          v-if="hover >= 0"
          class="wb-chart__hover-band"
          :x="plot.x + slot * hover + slot * 0.2"
          :y="plot.y"
          :width="slot * 0.6"
          :height="plot.height"
        />
        <g>
          <rect
            v-for="item in bars"
            :key="item.key"
            class="wb-chart__bar"
            :x="item.x"
            :y="item.y"
            :width="item.width"
            :height="item.height"
            :style="item.paint"
          />
          <template v-if="showValues">
            <text
              v-for="item in bars"
              :key="'v' + item.key"
              class="wb-chart__value"
              :x="item.x + item.width / 2"
              :y="item.y - 6"
              text-anchor="middle"
            >
              {{ item.label }}
            </text>
          </template>
        </g>
        <g
          v-for="item in lines"
          :key="item.key"
        >
          <path
            v-if="item.area"
            class="wb-chart__area"
            :d="item.area"
            :fill="`url(#${item.gradient})`"
          />
          <path
            class="wb-chart__line"
            :d="item.path"
            :style="item.stroke"
          />
          <circle
            v-for="(point, index) in item.points"
            :key="index"
            class="wb-chart__point"
            :class="{ 'is-active': hover === index }"
            :cx="point.x"
            :cy="point.y"
            r="3"
            :style="item.stroke"
          />
        </g>
      </template>

      <template v-else-if="type === 'bar-horizontal'">
        <g class="wb-chart__grid">
          <line
            v-for="tick in horizontal.ticks"
            :key="tick.value"
            :x1="tick.x"
            :x2="tick.x"
            :y1="horizontal.area.y"
            :y2="horizontal.area.y + horizontal.area.height"
          />
        </g>
        <g class="wb-chart__axis-label">
          <text
            v-for="tick in horizontal.ticks"
            :key="'t' + tick.value"
            :x="tick.x"
            :y="horizontal.area.y + horizontal.area.height + 16"
            text-anchor="middle"
          >
            {{ tick.label }}
          </text>
          <text
            v-for="(item, index) in horizontal.rows"
            :key="'c' + index"
            :x="horizontal.area.x - 8"
            :y="item.y"
            text-anchor="end"
            dominant-baseline="middle"
          >
            {{ item.label }}
          </text>
        </g>
        <g>
          <rect
            v-for="(item, index) in horizontal.rows"
            :key="index"
            class="wb-chart__bar"
            :x="item.x"
            :y="item.y - barWidth / 2"
            :width="item.width"
            :height="barWidth"
            :style="item.paint"
          />
          <text
            v-for="(item, index) in horizontal.rows"
            :key="'v' + index"
            class="wb-chart__value"
            :x="item.x + item.width + 6"
            :y="item.y"
            dominant-baseline="middle"
          >
            {{ item.value }}
          </text>
        </g>
      </template>

      <template v-else-if="isRing">
        <circle
          v-if="type === 'donut' && !analysis"
          class="wb-chart__track"
          :cx="ring.cx"
          :cy="ring.cy"
          :r="ring.radius"
          :stroke-width="ring.thick"
        />
        <path
          v-for="item in ring.segments"
          :key="item.index"
          :class="type === 'pie' ? 'wb-chart__sector' : 'wb-chart__arc'"
          :d="item.path"
          :stroke-width="ring.thick"
          :style="type === 'pie' ? item.paint : item.stroke"
        />
        <template v-if="ring.showCallouts">
          <g
            v-for="item in ring.segments"
            :key="'p' + item.index"
            class="wb-chart__callout"
          >
            <polyline
              v-if="item.leader"
              :points="item.leader"
              fill="none"
            />
            <line
              v-else
              :x1="item.anchor.x"
              :y1="item.anchor.y"
              :x2="item.label.x"
              :y2="item.label.y"
            />
            <text
              :x="item.label.x + (item.side === 'start' ? 4 : -4)"
              :y="item.label.y"
              :text-anchor="item.side"
              dominant-baseline="middle"
            >
              {{ item.percentText }}
            </text>
          </g>
        </template>
      </template>

      <template v-else-if="type === 'gauge'">
        <path
          v-if="!gauge.segments.length"
          class="wb-chart__gauge-track"
          :d="gauge.track"
          :stroke-width="gauge.thick"
        />
        <path
          v-for="item in gauge.segments"
          :key="item.key"
          class="wb-chart__arc"
          :d="item.path"
          :stroke-width="gauge.thick"
          :style="item.stroke"
        />
        <path
          v-if="!gauge.segments.length"
          class="wb-chart__arc"
          :d="gauge.value"
          :stroke-width="gauge.thick"
          :style="gauge.stroke"
        />
        <path
          v-if="gaugeMarker"
          class="wb-chart__marker"
          :d="gauge.marker"
          :transform="gauge.markerTransform"
          :class="{ 'is-neutral': gauge.segments.length || analysis }"
          :style="gauge.segments.length ? undefined : gauge.paint"
        />
        <text
          v-for="(item, index) in gauge.scale"
          :key="'s' + index"
          class="wb-chart__scale"
          :x="item.x"
          :y="item.y"
          :text-anchor="item.anchor"
          dominant-baseline="middle"
        >
          {{ item.label }}
        </text>
      </template>

      <template v-else-if="type === 'radar'">
        <polygon
          v-for="(points, index) in radar.rings"
          :key="'g' + index"
          class="wb-chart__radar-ring"
          :points="points"
        />
        <line
          v-for="item in radar.axes"
          :key="'a' + item.key"
          class="wb-chart__radar-axis"
          :x1="radar.cx"
          :y1="radar.cy"
          :x2="item.end.x"
          :y2="item.end.y"
        />
        <g
          v-for="item in radar.shapes"
          :key="item.key"
        >
          <polygon
            class="wb-chart__radar-shape"
            :points="item.polygon"
            :style="item.paint"
          />
          <polygon
            class="wb-chart__radar-outline"
            :points="item.polygon"
            :style="item.stroke"
          />
          <circle
            v-for="(point, index) in item.points"
            :key="index"
            class="wb-chart__point is-active"
            :cx="point.x"
            :cy="point.y"
            r="3"
            :style="item.stroke"
          />
        </g>
        <text
          v-for="item in radar.axes"
          :key="'t' + item.key"
          class="wb-chart__axis-label wb-chart__radar-label"
          :x="item.label.x"
          :y="item.label.y"
          :text-anchor="item.anchor"
          dominant-baseline="middle"
        >
          {{ item.name }}
        </text>
      </template>
    </svg>

    <div
      v-if="hasGaugeCenter()"
      class="wb-chart__center wb-chart__center--custom-gauge"
    >
      <div class="wb-chart__center-content"><slot name="gauge-center" /></div>
    </div>
    <div
      v-else-if="(isRing && (centerValue !== '' || centerLabel)) || type === 'gauge'"
      class="wb-chart__center"
      :class="'wb-chart__center--' + type"
    >
      <div class="wb-chart__center-value">
        {{ type === 'gauge' && centerValue === '' ? format(value) : centerValue
        }}<small v-if="centerUnit">{{ centerUnit }}</small>
      </div>
      <div
        v-if="centerLabel"
        class="wb-chart__center-label"
      >
        {{ centerLabel }}
      </div>
      <span
        v-if="status"
        class="wb-chart__status"
        >{{ status }}</span
      >
    </div>

    <div
      v-if="tooltip && hover >= 0 && tooltipRows.length"
      class="wb-chart__tooltip"
      :style="tooltipPosition"
      role="status"
    >
      <div class="wb-chart__tooltip-title">{{ categories[hover] }}</div>
      <div
        v-for="(item, index) in tooltipRows"
        :key="index"
        class="wb-chart__tooltip-row"
      >
        <svg
          class="wb-chart__dot"
          viewBox="0 0 8 8"
          aria-hidden="true"
        >
          <circle
            cx="4"
            cy="4"
            r="4"
            :style="item.paint"
          />
        </svg>
        <span>{{ item.name }}</span
        ><strong>{{ item.value }}</strong>
      </div>
    </div>

    <figcaption
      v-if="legend && legendItems.length"
      class="wb-chart__legend"
    >
      <span
        v-for="(item, index) in legendItems"
        :key="index"
        class="wb-chart__legend-item"
      >
        <svg
          class="wb-chart__dot"
          viewBox="0 0 8 8"
          aria-hidden="true"
        >
          <circle
            cx="4"
            cy="4"
            r="4"
            :style="item.paint"
          /></svg
        >{{ item.name }}
      </span>
    </figcaption>
  </figure>
</template>

<style>
.wb-chart {
  position: relative;
  display: flex;
  flex-direction: column;
  min-width: 0;
  margin: 0;
  color: var(--wb-color-text-secondary);
  font-family: inherit;
  font-size: var(--wb-font-body-s-font-size);
  font-weight: var(--wb-font-body-s-font-weight);
  line-height: var(--wb-font-body-s-line-height);
  letter-spacing: var(--wb-font-body-s-letter-spacing);
}
.wb-chart__units {
  display: flex;
  justify-content: space-between;
  padding-bottom: var(--wb-spacing-component-xs);
  color: var(--wb-color-text-secondary);
}
.wb-chart__svg {
  display: block;
  overflow: visible;
}
.wb-chart__grid line {
  stroke: var(--wb-color-border-separator);
  stroke-dasharray: 0;
}
.wb-chart__axis-label,
.wb-chart__axis-label text,
.wb-chart__scale,
.wb-chart__callout text {
  fill: var(--wb-color-text-secondary);
  font-size: var(--wb-font-caption-m-font-size);
  font-weight: var(--wb-font-caption-m-font-weight);
  line-height: var(--wb-font-caption-m-line-height);
  letter-spacing: var(--wb-font-caption-m-letter-spacing);
}
.wb-chart__radar-label {
  fill: var(--wb-color-text-secondary);
}
.wb-chart__value {
  fill: var(--wb-color-text-primary);
  font-size: var(--wb-font-caption-m-font-size);
  font-weight: var(--wb-font-caption-m-font-weight);
  line-height: var(--wb-font-caption-m-line-height);
  letter-spacing: var(--wb-font-caption-m-letter-spacing);
}
.wb-chart__hover-band {
  fill: var(--wb-color-fill-hover);
}
.wb-chart__bar {
  rx: var(--wb-radius-xs);
}
.wb-chart__line {
  fill: transparent;
  stroke-width: 2;
  stroke-linecap: round;
}
.wb-chart__area {
  stroke: transparent;
}
.wb-chart__stop-top {
  stop-opacity: 0.28;
}
.wb-chart__stop-bottom {
  stop-opacity: 0.02;
}
.wb-chart__point {
  fill: var(--wb-color-surface-card-default);
  stroke-width: 2;
  opacity: 0;
}
.wb-chart__point.is-active {
  opacity: 1;
}
.wb-chart__track,
.wb-chart__gauge-track {
  fill: transparent;
  stroke: var(--wb-color-none-subtle);
}
.wb-chart__arc {
  fill: transparent;
  stroke-linecap: butt;
}
.wb-chart--gauge .wb-chart__arc,
.wb-chart--gauge .wb-chart__gauge-track {
  stroke-linecap: round;
}
.wb-chart__sector {
  stroke: var(--wb-color-surface-card-default);
  stroke-width: 1;
}
.wb-chart__marker.is-neutral {
  fill: var(--wb-color-text-primary);
}
.wb-chart__callout :is(line, polyline) {
  stroke: var(--wb-color-border-separator);
}
.wb-chart.is-analysis .wb-chart__callout text {
  fill: var(--wb-color-text-primary);
}
.wb-chart__radar-ring {
  fill: transparent;
  stroke: var(--wb-color-border-separator);
}
.wb-chart__radar-axis {
  stroke: var(--wb-color-border-separator);
}
.wb-chart__radar-shape {
  fill-opacity: 0.2;
}
.wb-chart__radar-outline {
  fill: transparent;
  stroke-width: 2;
}
.wb-chart__center {
  position: absolute;
  left: 0;
  right: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  pointer-events: none;
  text-align: center;
}
.wb-chart__center--custom-gauge {
  inset: 0;
}
.wb-chart__center-content {
  pointer-events: auto;
}
.wb-chart__center--donut,
.wb-chart__center--pie,
.wb-chart__center--gauge {
  top: 0;
  height: calc(100% - var(--wb-asset-wb-chart-legend-height));
}
.wb-chart__center-value {
  color: var(--wb-color-text-primary);
  font-size: var(--wb-font-display-xs-font-size);
  font-weight: var(--wb-font-display-xs-font-weight);
  line-height: var(--wb-font-display-xs-line-height);
  letter-spacing: var(--wb-font-display-xs-letter-spacing);
}
.wb-chart__center-value small {
  margin-inline: var(--wb-spacing-component-xs) 0;
  font-size: var(--wb-font-body-s-font-size);
  font-weight: var(--wb-font-body-s-font-weight);
  line-height: var(--wb-font-body-s-line-height);
  letter-spacing: var(--wb-font-body-s-letter-spacing);
}
.wb-chart__center-label {
  color: var(--wb-color-text-secondary);
}
.wb-chart.is-analysis .wb-chart__center--gauge {
  top: 14%;
  height: 86%;
}
.wb-chart.is-analysis .wb-chart__center--gauge .wb-chart__center-value {
  font-size: var(--wb-font-display-s-font-size);
  font-weight: var(--wb-font-display-s-font-weight);
  line-height: var(--wb-font-display-s-line-height);
  letter-spacing: var(--wb-font-display-s-letter-spacing);
}
.wb-chart.is-analysis .wb-chart__center--gauge .wb-chart__center-label {
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
}
.wb-chart__status {
  margin-block: var(--wb-spacing-component-sm) 0;
  padding-block: 0;
  padding-inline: var(--wb-spacing-component-md);
  border-radius: var(--wb-radius-full);
  background: var(--wb-color-none-subtle);
  color: var(--wb-color-text-primary);
}
.wb-chart__tooltip {
  position: absolute;
  z-index: 1;
  min-width: var(--wb-asset-wb-chart-tooltip-min-width);
  padding: var(--wb-spacing-component-sm) var(--wb-spacing-component-md);
  border-radius: var(--wb-radius-md);
  background: var(--wb-color-surface-overlay);
  box-shadow: var(--wb-shadow-base);
  color: var(--wb-color-text-primary);
  pointer-events: none;
}
.wb-chart__tooltip-title {
  padding-bottom: var(--wb-spacing-component-xs);
  color: var(--wb-color-text-secondary);
}
.wb-chart__tooltip-row {
  display: flex;
  align-items: center;
  gap: var(--wb-spacing-component-sm);
}
.wb-chart__tooltip-row strong {
  margin-inline: auto 0;
  font-size: var(--wb-font-body-s-font-size);
  font-weight: var(--wb-font-body-s-font-weight);
  line-height: var(--wb-font-body-s-line-height);
  letter-spacing: var(--wb-font-body-s-letter-spacing);
}
.wb-chart__legend {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: var(--wb-spacing-component-xs) var(--wb-spacing-component-lg);
  padding-block: var(--wb-spacing-component-sm) 0;
}
.wb-chart__legend-item {
  display: inline-flex;
  align-items: center;
  gap: var(--wb-spacing-component-xs);
}
.wb-chart__dot {
  width: var(--wb-asset-wb-chart-dot-size);
  height: var(--wb-asset-wb-chart-dot-size);
  flex: none;
}
</style>
