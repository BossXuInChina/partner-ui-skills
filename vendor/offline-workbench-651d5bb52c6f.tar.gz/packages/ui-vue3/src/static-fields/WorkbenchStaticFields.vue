<script setup>
import '../shared/static-field.css';
import { computed } from 'vue';
import WorkbenchButton from '../button/WorkbenchButton.vue';
import WorkbenchLink from '../link/WorkbenchLink.vue';
import WorkbenchTooltip from '../tooltip/WorkbenchTooltip.vue';

const props = defineProps({
  label: { type: String, required: true },
  model: { type: Object, required: true },
  fields: { type: Array, required: true },
});
const emit = defineEmits(['copy']);

function displayValue(value) {
  if (Array.isArray(value)) return value.join('、') || '—';
  if (typeof value === 'boolean') return value ? '是' : '否';
  return value == null || value === '' ? '—' : String(value);
}

const entries = computed(() =>
  props.fields.map((field) => {
    const value = Object.hasOwn(field, 'value') ? field.value : props.model[field.key];
    const label = /[：:]$/.test(field.label) ? field.label : `${field.label}：`;
    const text = field.format
      ? String(field.format(value, props.model) ?? '—')
      : displayValue(value);
    return { ...field, labelText: label, value, text };
  }),
);
</script>

<template>
  <ul
    class="record-fields"
    :aria-label="label"
    role="list"
  >
    <li
      v-for="field in entries"
      :key="field.key"
      class="record-fields__item"
      :data-field-key="field.key"
    >
      <WorkbenchTooltip
        :content="`${field.labelText}${field.text}`"
        overflow-only
      >
        <template #trigger="{ aria }">
          <span
            class="record-fields__text wb-static-field"
            :tabindex="field.href ? undefined : 0"
            data-record-field-text
            v-bind="field.href ? {} : aria"
          >
            <span class="record-fields__label wb-static-field__label">{{ field.labelText }}</span>
            <span
              v-if="field.href"
              class="record-fields__link"
            >
              <WorkbenchLink
                :href="field.href"
                :target="field.target"
                v-bind="aria"
              >
                <span class="record-fields__link-label">{{ field.text }}</span>
              </WorkbenchLink>
            </span>
            <span
              v-else
              class="record-fields__value"
              :data-value-color="field.color"
            >
              <slot
                :name="`value-${field.key}`"
                :field="field"
                >{{ field.text }}</slot
              >
            </span>
          </span>
        </template>
      </WorkbenchTooltip>
      <span
        v-if="$slots[`action-${field.key}`]"
        class="record-fields__action"
      >
        <slot
          :name="`action-${field.key}`"
          :field="field"
        />
      </span>
      <span
        v-if="field.copy"
        class="record-fields__copy"
      >
        <WorkbenchButton
          appearance="icon"
          size="24"
          :aria-label="`复制${field.label}`"
          @click="emit('copy', { value: field.value, label: field.label, key: field.key })"
        >
          <template #icon
            ><span
              class="record-fields__copy-icon"
              aria-hidden="true"
          /></template>
        </WorkbenchButton>
      </span>
    </li>
  </ul>
</template>

<style scoped>
.record-fields {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: var(--wb-spacing-component-sm) var(--wb-spacing-component-lg);
  margin: 0;
  padding: 0;
  list-style: none;
}
.record-fields__item {
  display: flex;
  align-items: center;
  gap: var(--wb-spacing-component-xs);
  min-width: 0;
}
.record-fields__label,
.record-fields__value {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.record-fields__value[data-value-color='secondary'] {
  color: var(--wb-color-text-secondary);
}
.record-fields__value[data-value-color='success'] {
  color: var(--wb-color-success);
}
.record-fields__value[data-value-color='error'] {
  color: var(--wb-color-error);
}
.record-fields__value[data-value-color='action'] {
  color: var(--wb-color-text-action);
}
.record-fields__link {
  display: flex;
  min-width: 0;
}
.record-fields__link-label {
  display: -webkit-box;
  overflow: hidden;
  overflow-wrap: anywhere;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 1;
}
.record-fields__action,
.record-fields__copy {
  display: flex;
  flex: none;
}
.record-fields__copy-icon {
  display: block;
  inline-size: var(--wb-icon-size-16);
  block-size: var(--wb-icon-size-16);
  mask: url('./record-copy.svg') center / contain no-repeat;
  background-color: var(--wb-color-text-primary);
}
</style>
