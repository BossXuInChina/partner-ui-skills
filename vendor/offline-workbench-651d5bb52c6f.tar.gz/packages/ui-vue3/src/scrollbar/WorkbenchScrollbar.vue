<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, reactive, ref, watch, watchPostEffect } from 'vue';
import type { PropType } from 'vue';
import './scrollbar.css';

interface TrackInsets {
  blockEnd?: number;
  inlineEnd?: number;
  blockEndReserve?: number;
}

const props = defineProps({
  label: { type: String, required: true },
  describedby: String,
  axis: { type: String, default: 'vertical' },
  size: { type: String, default: 'default' },
  state: String,
  trackInsets: { type: Object as PropType<TrackInsets> },
});

const viewport = ref<HTMLDivElement>();
const content = ref<HTMLDivElement>();
const track = ref<HTMLDivElement>();
const thumb = ref<HTMLDivElement>();
const metrics = reactive({ ratio: 1, position: 0, width: 0, height: 0 });
const dragging = ref(false);
const horizontal = computed(() => props.axis === 'horizontal');

function inset(value: number | undefined, size: number) {
  return typeof value === 'number' && Number.isFinite(value)
    ? Math.max(0, Math.min(size, value))
    : 0;
}

const blockEnd = computed(() => inset(props.trackInsets?.blockEnd, metrics.height));
const inlineEnd = computed(() => inset(props.trackInsets?.inlineEnd, metrics.width));
// A footer moving into view changes the rail's hit area. Reserving its full
// height keeps the thumb's usable travel constant throughout the scroll.
const reservedTail = computed(() =>
  horizontal.value
    ? 0
    : Math.max(0, inset(props.trackInsets?.blockEndReserve, metrics.height) - blockEnd.value),
);
const hasTrack = computed(
  () =>
    metrics.ratio < 1 &&
    (horizontal.value
      ? inlineEnd.value < metrics.width && blockEnd.value < metrics.height
      : blockEnd.value + reservedTail.value < metrics.height && inlineEnd.value < metrics.width),
);
watchPostEffect(() => {
  if (track.value) {
    const style = track.value.style;
    style.setProperty(
      '--scrollbar-track-block-end',
      props.trackInsets?.blockEnd === undefined ? '' : blockEnd.value + 'px',
    );
    style.setProperty(
      '--scrollbar-track-inline-end',
      props.trackInsets?.inlineEnd === undefined ? '' : inlineEnd.value + 'px',
    );
  }
  if (thumb.value) {
    thumb.value.style.setProperty(
      '--scrollbar-thumb-length',
      thumbLength(metrics.ratio, reservedTail.value),
    );
    thumb.value.style.setProperty(
      '--scrollbar-thumb-position',
      thumbLength(metrics.position, reservedTail.value),
    );
  }
});

function thumbLength(fraction: number, reserve: number) {
  return reserve ? `calc(${fraction * 100}% - ${fraction * reserve}px)` : `${fraction * 100}%`;
}

function dimensions(element: HTMLDivElement) {
  return horizontal.value
    ? { total: element.scrollWidth, client: element.clientWidth }
    : { total: element.scrollHeight, client: element.clientHeight };
}

function horizontalScrollOrigin(element: HTMLDivElement, range: number) {
  return horizontal.value && getComputedStyle(element).direction === 'rtl' ? -range : 0;
}

function readScroll(element: HTMLDivElement, origin: number) {
  return horizontal.value ? element.scrollLeft - origin : element.scrollTop;
}

function writeScroll(element: HTMLDivElement, position: number, origin: number) {
  if (horizontal.value) element.scrollLeft = position + origin;
  else element.scrollTop = position;
}

function measure() {
  const element = viewport.value;
  if (!element) return;
  const { total, client } = dimensions(element);
  const range = Math.max(0, total - client);
  metrics.ratio = total ? Math.min(1, client / total) : 1;
  metrics.position = total
    ? readScroll(element, horizontalScrollOrigin(element, range)) / total
    : 0;
  metrics.width = element.clientWidth;
  metrics.height = element.clientHeight;
}

let observer: ResizeObserver | undefined;
let drag:
  { pointerId: number; point: number; preciseScroll: number; appliedScroll: number } | undefined;

function geometry() {
  const element = viewport.value;
  const rect = track.value?.getBoundingClientRect();
  if (!element || !rect) return;
  const { total, client } = dimensions(element);
  const range = total - client;
  const length = (horizontal.value ? rect.width : rect.height) - reservedTail.value;
  if (range <= 0 || length <= 0) return;
  const origin = horizontalScrollOrigin(element, range);
  return {
    element,
    total,
    range,
    length,
    client,
    origin,
    edge: horizontal.value ? rect.left : rect.top,
    scroll: readScroll(element, origin),
  };
}

function pointerDown(event: PointerEvent) {
  if (event.button !== 0 || drag) return;
  const g = geometry();
  if (!g) return;
  const point = horizontal.value ? event.clientX : event.clientY;
  g.element.focus({ preventScroll: true });
  if (!(event.target instanceof Node && thumb.value?.contains(event.target))) {
    const offset = point - g.edge;
    writeScroll(g.element, (offset / g.length) * g.total - g.client / 2, g.origin);
    measure();
  }
  const scroll = readScroll(g.element, g.origin);
  drag = { pointerId: event.pointerId, point, preciseScroll: scroll, appliedScroll: scroll };
  dragging.value = true;
  track.value?.setPointerCapture(event.pointerId);
  event.preventDefault();
}

function pointerMove(event: PointerEvent) {
  if (!drag || drag.pointerId !== event.pointerId) return;
  const g = geometry();
  if (!g) {
    endDrag();
    return;
  }
  const point = horizontal.value ? event.clientX : event.clientY;
  const previous = g.scroll === drag.appliedScroll ? drag.preciseScroll : g.scroll;
  const next = Math.max(
    0,
    Math.min(g.range, previous + ((point - drag.point) * g.total) / g.length),
  );
  writeScroll(g.element, next, g.origin);
  drag.point = point;
  drag.preciseScroll = next;
  drag.appliedScroll = readScroll(g.element, g.origin);
  measure();
}

function endDrag(event?: PointerEvent) {
  if (!drag || (event && event.pointerId !== drag.pointerId)) return;
  const { pointerId } = drag;
  drag = undefined;
  dragging.value = false;
  if (track.value?.hasPointerCapture(pointerId)) track.value.releasePointerCapture(pointerId);
}

function keydown(event: KeyboardEvent) {
  if (event.target !== viewport.value || !viewport.value) return;
  const element = viewport.value;
  const { total, client } = dimensions(element);
  const keys = horizontal.value ? ['ArrowLeft', 'ArrowRight'] : ['ArrowUp', 'ArrowDown'];
  let delta;
  if (event.key === keys[0]) delta = -40;
  else if (event.key === keys[1]) delta = 40;
  else if (event.key === 'PageUp') delta = -client;
  else if (event.key === 'PageDown') delta = client;
  else if (event.key === 'Home') delta = -Infinity;
  else if (event.key === 'End') delta = Infinity;
  else return;
  event.preventDefault();
  const origin = horizontalScrollOrigin(element, Math.max(0, total - client));
  writeScroll(
    element,
    delta === -Infinity ? 0 : delta === Infinity ? total : readScroll(element, origin) + delta,
    origin,
  );
}

watch(
  horizontal,
  () => {
    endDrag();
    measure();
  },
  { flush: 'post' },
);
watch(hasTrack, (visible) => {
  if (!visible) endDrag();
});

onMounted(() => {
  observer = new ResizeObserver(measure);
  if (viewport.value) observer.observe(viewport.value);
  if (content.value) observer.observe(content.value);
  measure();
});
onBeforeUnmount(() => {
  observer?.disconnect();
  endDrag();
});
defineExpose({ viewport, measure });
</script>
<template>
  <div
    class="wb-scrollbar wb-scrollarea"
    :class="[
      size === 'small' ? '' : 'wb-scrollbar--large',
      {
        'is-horizontal': axis === 'horizontal',
        'is-hover': state === 'hover',
        'is-dragging': dragging,
      },
    ]"
  >
    <div
      ref="viewport"
      class="wb-scrollarea__viewport"
      role="region"
      :aria-label="label"
      :aria-describedby="describedby"
      tabindex="0"
      @scroll="measure"
      @keydown="keydown"
    >
      <div
        ref="content"
        class="wb-scrollarea__content"
      >
        <slot />
      </div>
    </div>
    <div
      v-if="hasTrack"
      ref="track"
      class="wb-scrollarea__track"
      aria-hidden="true"
      @pointerdown="pointerDown"
      @pointermove="pointerMove"
      @pointerup="endDrag"
      @pointercancel="endDrag"
      @lostpointercapture="endDrag"
    >
      <div
        ref="thumb"
        class="wb-scrollarea__thumb"
      />
    </div>
  </div>
</template>
<style>
.wb-scrollarea {
  position: relative;
  min-width: 0;
  min-height: 0;
}
.wb-scrollarea__viewport {
  width: 100%;
  height: 100%;
  overflow-y: auto;
  overflow-x: hidden;
  scrollbar-width: none;
  box-sizing: border-box;
}
.wb-scrollarea__viewport::-webkit-scrollbar {
  display: none;
}
.wb-scrollarea__viewport:focus-visible {
  outline: 2px solid var(--wb-color-border-focus);
  outline-offset: -2px;
}
.wb-scrollarea__content {
  display: flow-root;
  min-width: 100%;
}
.wb-scrollarea.is-horizontal .wb-scrollarea__content {
  width: max-content;
}
.wb-scrollarea__track {
  position: absolute;
  inset-block: 0 var(--scrollbar-track-block-end, 0px);
  inset-inline-end: var(--scrollbar-track-inline-end, 0px);
  width: var(--scrollbar-width);
  touch-action: none;
  user-select: none;
}
.wb-scrollarea__thumb {
  position: absolute;
  width: 100%;
  height: var(--scrollbar-thumb-length);
  top: var(--scrollbar-thumb-position);
  border: var(--scrollbar-safe) solid transparent;
  box-sizing: border-box;
  border-radius: var(--wb-radius-full);
  background: var(--scrollbar-fill);
  background-clip: padding-box;
}
.wb-scrollarea__track:hover .wb-scrollarea__thumb,
.wb-scrollarea.is-hover .wb-scrollarea__thumb,
.wb-scrollarea.is-dragging .wb-scrollarea__thumb {
  border-width: var(--scrollbar-safe-hover);
  background-color: var(--wb-color-scrollbar-thumb-fill-hover);
}
.wb-scrollarea.is-horizontal .wb-scrollarea__track {
  inset-block-start: auto;
  inset-inline-start: 0;
  width: auto;
  height: var(--scrollbar-width);
}
.wb-scrollarea.is-horizontal .wb-scrollarea__thumb {
  height: 100%;
  width: var(--scrollbar-thumb-length);
  left: var(--scrollbar-thumb-position);
  top: 0;
}
.wb-scrollarea.is-horizontal .wb-scrollarea__viewport {
  overflow-x: auto;
  overflow-y: hidden;
}
</style>
