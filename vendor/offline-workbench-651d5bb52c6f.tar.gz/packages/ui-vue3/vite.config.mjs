import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';
import { defineConfig } from 'vite';
import vue from '@vitejs/plugin-vue';
const root = fileURLToPath(new URL('.', import.meta.url));
export default defineConfig({
  root,
  plugins: [vue()],
  // Generated custom properties are also read by runtime code; preserve their declared units.
  build: {
    cssMinify: false,
    emptyOutDir: true,
    outDir: 'dist',
    lib: {
      entry: resolve(root, 'src/index.ts'),
      formats: ['es'],
      fileName: () => 'index.js',
      cssFileName: 'styles',
    },
    rollupOptions: {
      external: ['vue'],
      output: { inlineDynamicImports: false, chunkFileNames: 'chunks/[name]-[hash].js' },
    },
    sourcemap: false,
  },
});
