<script setup>
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import breadcrumbSeparator from './assets/面包屑_斜杠.svg';
import { computed, nextTick, onBeforeUnmount, onMounted, ref, useId, watch } from 'vue';

const props = defineProps({
  items: { type: Array, default: () => [] },
  collapseThreshold: { type: Number, default: 6 },
  ariaLabel: { type: String, default: '面包屑' },
});
const emit = defineEmits(['navigate']);
const menuId = `wb-breadcrumb-${useId()}-menu`;
const root = ref(null);
const trigger = ref(null);
const panel = ref(null);
const expanded = ref(false);

const normalizedItems = computed(() =>
  props.items.filter((item) => item && item.id != null && item.label != null),
);
const isCollapsed = computed(
  () => normalizedItems.value.length > Math.max(6, Math.floor(props.collapseThreshold) || 6),
);
const hiddenItems = computed(() => (isCollapsed.value ? normalizedItems.value.slice(1, -4) : []));
const visibleItems = computed(() => {
  if (!isCollapsed.value)
    return normalizedItems.value.map((item, index) => ({
      kind: 'item',
      item,
      originalIndex: index,
    }));
  const tailStart = normalizedItems.value.length - 4;
  return [
    { kind: 'item', item: normalizedItems.value[0], originalIndex: 0 },
    { kind: 'collapsed', id: '__collapsed__' },
    ...normalizedItems.value
      .slice(tailStart)
      .map((item, index) => ({ kind: 'item', item, originalIndex: tailStart + index })),
  ];
});

function setTrigger(element) {
  trigger.value = element;
}
function isCurrent(entry) {
  return entry.kind === 'item' && entry.originalIndex === normalizedItems.value.length - 1;
}
function activate(item, event) {
  if (item.disabled) {
    event?.preventDefault();
    return;
  }
  emit('navigate', item, event);
}
function menuButtons() {
  return [...(panel.value?.querySelectorAll('[role="menuitem"]:not(:disabled)') ?? [])];
}
function focusMenu(index = 0) {
  nextTick(() => menuButtons()[index]?.focus());
}
function placePanel() {
  const rect = trigger.value?.getBoundingClientRect();
  const menuRect = panel.value?.getBoundingClientRect();
  if (!rect || !menuRect) return;
  const gap = Number.parseFloat(
    getComputedStyle(root.value).getPropertyValue('--wb-spacing-component-xs'),
  );
  const viewportGap = gap;
  const width = menuRect.width;
  const below = window.innerHeight - rect.bottom - gap - viewportGap;
  const above = rect.top - gap - viewportGap;
  const placeBelow = below >= menuRect.height || below >= above;
  const availableHeight = Math.max(0, placeBelow ? below : above);
  const top = placeBelow
    ? rect.bottom + gap
    : Math.max(viewportGap, rect.top - gap - Math.min(menuRect.height, availableHeight));
  panel.value.style.setProperty(
    '--breadcrumb-menu-left',
    `${Math.max(viewportGap, Math.min(rect.left, window.innerWidth - width - viewportGap))}px`,
  );
  panel.value.style.setProperty('--breadcrumb-menu-top', `${top}px`);
  panel.value.style.setProperty('--breadcrumb-menu-max-height', `${availableHeight}px`);
}
function openMenu(focus = false) {
  if (!hiddenItems.value.some((item) => !item.disabled)) return;
  expanded.value = true;
  nextTick(placePanel);
  if (focus) focusMenu();
}
function closeMenu({ restoreFocus = false } = {}) {
  if (!expanded.value) return;
  expanded.value = false;
  if (restoreFocus) nextTick(() => trigger.value?.focus());
}
function toggleMenu() {
  expanded.value ? closeMenu() : openMenu(false);
}
function selectHidden(item, event) {
  activate(item, event);
  if (!item.disabled) closeMenu({ restoreFocus: true });
}
function handleTriggerKeydown(event) {
  if (event.key === 'ArrowDown' || event.key === 'Enter' || event.key === ' ') {
    event.preventDefault();
    openMenu(true);
  } else if (event.key === 'Escape') closeMenu({ restoreFocus: true });
}
function handleMenuKeydown(event) {
  const buttons = menuButtons();
  const index = buttons.indexOf(document.activeElement);
  let nextIndex = null;
  if (event.key === 'ArrowDown') nextIndex = (index + 1) % buttons.length;
  if (event.key === 'ArrowUp') nextIndex = (index - 1 + buttons.length) % buttons.length;
  if (event.key === 'Home') nextIndex = 0;
  if (event.key === 'End') nextIndex = buttons.length - 1;
  if (nextIndex != null) {
    event.preventDefault();
    buttons[nextIndex]?.focus();
  }
  if (event.key === 'Escape') {
    event.preventDefault();
    event.stopPropagation();
    closeMenu({ restoreFocus: true });
  }
}
function handleDocumentPointer(event) {
  if (expanded.value && !root.value?.contains(event.target) && !panel.value?.contains(event.target))
    closeMenu();
}
function handleFocusOut(event) {
  if (!root.value?.contains(event.relatedTarget) && !panel.value?.contains(event.relatedTarget))
    closeMenu();
}
watch(hiddenItems, (items) => {
  if (!items.length) closeMenu();
  else nextTick(placePanel);
});
function handleViewportChange() {
  if (expanded.value) placePanel();
}
onMounted(() => {
  document.addEventListener('pointerdown', handleDocumentPointer);
  window.addEventListener('resize', handleViewportChange);
  window.addEventListener('scroll', handleViewportChange, true);
});
onBeforeUnmount(() => {
  document.removeEventListener('pointerdown', handleDocumentPointer);
  window.removeEventListener('resize', handleViewportChange);
  window.removeEventListener('scroll', handleViewportChange, true);
});
</script>

<template>
  <nav
    ref="root"
    class="wb-breadcrumb"
    :aria-label="ariaLabel"
    @focusout="handleFocusOut"
  >
    <ol class="wb-breadcrumb__list">
      <li
        v-for="(entry, visibleIndex) in visibleItems"
        :key="entry.kind === 'item' ? entry.item.id : entry.id"
        class="wb-breadcrumb__entry"
      >
        <span
          v-if="visibleIndex"
          class="wb-breadcrumb__separator"
          aria-hidden="true"
          ><img
            :src="breadcrumbSeparator"
            alt=""
            width="12"
            height="12"
        /></span>
        <button
          v-if="entry.kind === 'collapsed'"
          :ref="setTrigger"
          type="button"
          class="wb-breadcrumb__collapsed"
          aria-label="显示折叠的路径"
          aria-haspopup="menu"
          :aria-expanded="expanded"
          :aria-controls="expanded ? menuId : undefined"
          @click="toggleMenu"
          @keydown="handleTriggerKeydown"
        >
          ...
        </button>
        <span
          v-else-if="isCurrent(entry)"
          class="wb-breadcrumb__current"
          aria-current="page"
          :title="entry.item.label"
          >{{ entry.item.label }}</span
        >
        <span
          v-else-if="entry.item.disabled"
          class="wb-breadcrumb__node is-disabled"
          aria-disabled="true"
          :title="entry.item.label"
          >{{ entry.item.label }}</span
        >
        <a
          v-else-if="entry.item.href"
          class="wb-breadcrumb__node"
          :href="entry.item.href"
          :title="entry.item.label"
          @click="activate(entry.item, $event)"
          >{{ entry.item.label }}</a
        >
        <button
          v-else
          type="button"
          class="wb-breadcrumb__node"
          :title="entry.item.label"
          @click="activate(entry.item, $event)"
        >
          {{ entry.item.label }}
        </button>
      </li>
    </ol>
    <Teleport to="body">
      <div
        v-if="expanded"
        :id="menuId"
        ref="panel"
        role="menu"
        aria-label="折叠的面包屑路径"
        class="wb-breadcrumb__menu"
        @keydown="handleMenuKeydown"
        @focusout="handleFocusOut"
      >
        <template
          v-for="item in hiddenItems"
          :key="item.id"
        >
          <a
            v-if="item.href && !item.disabled"
            :href="item.href"
            role="menuitem"
            class="wb-breadcrumb__menu-item"
            :title="item.label"
            @click="selectHidden(item, $event)"
            >{{ item.label }}</a
          >
          <button
            v-else
            type="button"
            role="menuitem"
            class="wb-breadcrumb__menu-item"
            :disabled="item.disabled"
            :title="item.label"
            @click="selectHidden(item, $event)"
          >
            {{ item.label }}
          </button>
        </template>
      </div>
    </Teleport>
  </nav>
</template>

<style>
.wb-breadcrumb {
  box-sizing: border-box;
  min-width: 0;
  width: 100%;
  color: var(--wb-color-text-secondary);
  background: transparent;
  border: 0;
  border-radius: 0;
  box-shadow: none;
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
}
.wb-breadcrumb__list {
  display: flex;
  min-width: 0;
  margin: 0;
  padding: 0;
  list-style: none;
}
.wb-breadcrumb__entry {
  display: flex;
  min-width: 0;
  align-items: center;
  flex: 0 1 auto;
}
.wb-breadcrumb__separator {
  display: inline-flex;
  align-items: center;
  flex: none;
  margin-inline: var(--wb-spacing-component-xs);
}
.wb-breadcrumb__separator img {
  display: block;
}
.wb-breadcrumb__node,
.wb-breadcrumb__current,
.wb-breadcrumb__collapsed {
  display: block;
  min-width: 0;
  max-width: var(--wb-asset-wb-breadcrumb-label-max-width);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: inherit;
  font: inherit;
  line-height: inherit;
}
.wb-breadcrumb__node,
.wb-breadcrumb__collapsed {
  padding: 0;
  border: 0;
  background: transparent;
  text-decoration: none;
  cursor: pointer;
}
.wb-breadcrumb__node:hover,
.wb-breadcrumb__collapsed:hover {
  color: var(--wb-color-text-primary);
}
.wb-breadcrumb__node:focus-visible,
.wb-breadcrumb__collapsed:focus-visible {
  border-radius: var(--wb-radius-sm);
  outline: 1px solid var(--wb-color-border-focus);
  outline-offset: 2px;
}
.wb-breadcrumb__node.is-disabled {
  color: var(--wb-color-text-disabled);
  cursor: not-allowed;
}
.wb-breadcrumb__current {
  color: var(--wb-color-text-primary);
}
.wb-breadcrumb__menu {
  box-sizing: border-box;
  position: fixed;
  z-index: 40;
  top: var(--breadcrumb-menu-top);
  left: var(--breadcrumb-menu-left);
  display: grid;
  width: max-content;
  min-width: var(--wb-asset-wb-breadcrumb-menu-min-width);
  max-width: min(
    var(--wb-asset-wb-breadcrumb-menu-max-width),
    calc(100vw - 2 * var(--wb-spacing-component-xs))
  );
  max-height: var(--breadcrumb-menu-max-height);
  padding: var(--wb-spacing-component-xs);
  overflow-y: auto;
  border: 0;
  border-radius: var(--wb-radius-sm);
  background: var(--wb-color-surface-overlay);
  box-shadow: var(--wb-shadow-sm);
  color: var(--wb-color-text-primary);
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
}
.wb-breadcrumb__menu-item {
  display: block;
  align-content: center;
  text-decoration: none;
  box-sizing: border-box;
  width: 100%;
  height: var(--wb-asset-wb-breadcrumb-menu-option-height);
  padding-inline: var(--wb-spacing-component-md);
  overflow: hidden;
  border: 0;
  border-radius: var(--wb-radius-sm);
  background: transparent;
  color: inherit;
  font: inherit;
  text-align: left;
  text-overflow: ellipsis;
  white-space: nowrap;
  cursor: pointer;
}
.wb-breadcrumb__menu-item:hover,
.wb-breadcrumb__menu-item:focus-visible {
  outline: 0;
  background: var(--wb-color-fill-hover);
}
.wb-breadcrumb__menu-item:disabled {
  color: var(--wb-color-text-disabled);
  cursor: not-allowed;
}
</style>
