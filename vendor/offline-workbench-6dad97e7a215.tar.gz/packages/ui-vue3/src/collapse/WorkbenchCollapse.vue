<script setup>
import '../../../../catalog/generated/asset.tokens.css';
</script>

<template>
  <div class="wb-collapse">
    <slot />
  </div>
</template>

<style>
.wb-collapse {
  min-width: 0;
}

.wb-collapse > .wb-collapse-item + .wb-collapse-item {
  margin-top: var(--wb-asset-wb-collapse-item-separator-gap);
  padding-top: var(--wb-asset-wb-collapse-item-separator-gap);
  border-top: 1px solid var(--wb-color-border-separator-subtle);
}

.wb-collapse > .wb-collapse-item.is-expanded + .wb-collapse-item {
  margin-top: var(--wb-asset-wb-collapse-expanded-item-separator-gap);
}
</style>
