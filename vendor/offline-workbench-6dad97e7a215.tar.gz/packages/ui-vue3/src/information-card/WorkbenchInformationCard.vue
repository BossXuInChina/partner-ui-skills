<script setup lang="ts">
import { useSlots, type PropType } from 'vue';
import { hasSlotContent } from '../card-block/slots';
const slots = useSlots();
const has = (name: string) => hasSlotContent(slots, name);
import BlockFrame from '../card-block/BlockFrame.vue';
import BlockActions from '../card-block/BlockActions.vue';
import type {
  CardVariant,
  CardSize,
  CardAction,
  CardFooter,
  CardActionEvent,
} from '../../types/card-blocks';
defineProps({
  title: { type: String, default: '' },
  variant: {
    type: String as PropType<CardVariant>,
    default: 'display-white',
    validator: (value: string) =>
      ['display-white', 'display-tinted', 'operation', 'navigation'].includes(value),
  },
  size: {
    type: String as PropType<CardSize>,
    default: 'xxxl',
    validator: (value: string) => ['s', 'm', 'l', 'xl', 'xxl', 'xxxl'].includes(value),
  },
  href: { type: String, default: undefined },
  target: { type: String, default: undefined },
  rel: { type: String, default: undefined },
  headerActions: { type: Array as PropType<CardAction[]>, default: () => [] },
  footer: { type: Object as PropType<CardFooter | null>, default: null },
  actions: { type: Array as PropType<CardAction[]>, default: () => [] },
  bodySize: {
    type: Number as PropType<14>,
    default: 14,
    validator: (value: number) => [14].includes(value),
  },
  description: { type: String, default: '' },
  tags: { type: Array as PropType<string[]>, default: () => [] },
  structure: {
    type: String as PropType<'icon' | 'text-action'>,
    default: 'icon',
    validator: (value: string) => ['icon', 'text-action'].includes(value),
  },
});
const emit = defineEmits({ action: (_payload: CardActionEvent) => true });
</script>
<template>
  <BlockFrame
    v-bind="$props"
    :title="structure === 'icon' ? '' : title"
    class="wbc-info-card"
    :class="`wbc-info-card--${structure}`"
    data-card-block="information"
    @action="emit('action', $event)"
  >
    <template
      v-if="(has('header') && variant !== 'navigation') || structure === 'icon'"
      #header
    >
      <slot
        v-if="has('header') && variant !== 'navigation'"
        name="header"
      />
      <div
        v-else
        class="wbc-info-title-row"
      >
        <slot
          v-if="has('icon') && variant !== 'navigation'"
          name="icon"
        /><span
          v-else
          class="wbc-info-icon"
          aria-hidden="true"
          >✦</span
        >
        <slot
          v-if="has('header-actions') && variant !== 'navigation'"
          name="header-actions"
        /><BlockActions
          v-else-if="variant !== 'navigation' && headerActions.length"
          header
          :items="headerActions"
          @activate="(a, event) => emit('action', { id: a.id, source: 'header', event })"
        />
      </div>
    </template>
    <template #header-actions
      ><slot
        v-if="has('header-actions') && variant !== 'navigation'"
        name="header-actions"
    /></template>
    <template #footer
      ><slot
        v-if="has('footer') && variant !== 'navigation'"
        name="footer"
    /></template>
    <template #actions
      ><slot
        v-if="has('actions') && variant !== 'navigation'"
        name="actions"
    /></template>
    <slot
      v-if="has('content') && variant !== 'navigation'"
      name="content"
    />
    <div
      v-else-if="(structure === 'icon' && title) || tags.length || description"
      class="wbc-info-content"
    >
      <div
        v-if="(structure === 'icon' && title) || tags.length"
        :class="structure === 'icon' ? 'wbc-info-title-tags' : undefined"
      >
        <h3
          v-if="structure === 'icon' && title"
          class="wbc-title"
        >
          {{ title }}
        </h3>
        <div
          v-if="tags.length"
          class="wbc-tags"
        >
          <span
            v-for="(tag, i) in tags"
            :key="i"
            >{{ tag }}</span
          >
        </div>
      </div>
      <p
        v-if="description"
        class="wbc-description"
      >
        {{ description }}
      </p>
    </div>
  </BlockFrame>
</template>
