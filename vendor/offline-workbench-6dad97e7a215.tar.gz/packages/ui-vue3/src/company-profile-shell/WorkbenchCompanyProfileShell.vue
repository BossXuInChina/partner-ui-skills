<script setup>
import { computed, ref, watch } from 'vue';
import WorkbenchBreadcrumb from '../breadcrumb/WorkbenchBreadcrumb.vue';
import WorkbenchCard from '../card/WorkbenchCard.vue';
import WorkbenchTag from '../tag/WorkbenchTag.vue';
import WorkbenchTabs from '../tabs/WorkbenchTabs.vue';
import WorkbenchTopNav from '../top-nav/WorkbenchTopNav.vue';

const props = defineProps({
  primaryItems: { type: Array, required: true },
  secondaryItems: { type: Array, default: () => [] },
  secondaryParent: { type: String, default: '' },
  initialPrimary: { type: String, default: '' },
  initialSecondary: { type: String, default: '' },
  navigation: { type: Object, required: true },
  breadcrumbs: { type: Array, default: () => [] },
  identity: { type: Object, required: true },
  primaryLabel: { type: String, default: '一级栏目' },
  secondaryLabel: { type: String, default: '二级栏目' },
  contentLabel: { type: String, default: '资料内容' },
  contentClass: { type: [String, Array, Object, Function], default: '' },
});
const emit = defineEmits([
  'update:primary',
  'update:secondary',
  'navigation-action',
  'breadcrumb-navigate',
]);
const secondaryParentValue = computed(
  () => props.secondaryParent || props.primaryItems[0]?.value || '',
);
const primary = ref(props.initialPrimary || secondaryParentValue.value);
const secondary = ref(props.initialSecondary || props.secondaryItems[0]?.value || '');
const topTab = ref(props.navigation.initialTab || props.navigation.tabs?.[0]?.value || '');
const currentSite = ref(props.navigation.initialSite || props.navigation.sites?.[0]?.value || '');
const currentLanguage = ref(
  props.navigation.initialLanguage || props.navigation.languages?.[0]?.value || '',
);
watch(
  () => props.initialPrimary,
  (value) => {
    if (value) primary.value = value;
  },
);
watch(
  () => props.initialSecondary,
  (value) => {
    if (value) {
      secondary.value = value;
      if (!props.initialPrimary) primary.value = secondaryParentValue.value;
    }
  },
);
const primaryItem = computed(() => props.primaryItems.find((item) => item.value === primary.value));
const secondaryItem = computed(() =>
  props.secondaryItems.find((item) => item.value === secondary.value),
);
const resolvedContentClass = computed(() =>
  typeof props.contentClass === 'function'
    ? props.contentClass({ primary: primary.value, secondary: secondary.value })
    : props.contentClass,
);
function chooseTab(which, value) {
  if (which === 'primary') {
    primary.value = value;
    emit('update:primary', value);
  } else {
    secondary.value = value;
    emit('update:secondary', value);
  }
}
function chooseNavigation(kind, value) {
  if (kind === 'tab') topTab.value = value;
  if (kind === 'site') currentSite.value = value;
  if (kind === 'language') currentLanguage.value = value;
  emit('navigation-action', { kind, value });
}
function navigateBreadcrumb(payload) {
  payload?.preventDefault?.();
  emit('breadcrumb-navigate', payload);
}
</script>

<template>
  <div class="wb-profile-shell">
    <WorkbenchTopNav
      :mode="navigation.mode || 'workbench'"
      :user-state="navigation.userState || 'authenticated'"
      :tabs="navigation.tabs"
      :active-tab="topTab"
      :sites="navigation.sites"
      :current-site="currentSite"
      :languages="navigation.languages"
      :current-language="currentLanguage"
      :user-menu-items="navigation.userMenuItems"
      @update:active-tab="chooseNavigation('tab', $event)"
      @select-site="chooseNavigation('site', $event)"
      @select-language="chooseNavigation('language', $event)"
      @select-user-action="chooseNavigation('user-action', $event)"
      @search="chooseNavigation('search', $event)"
      @notification="chooseNavigation('notification', $event)"
    />
    <main class="wb-profile-shell__main">
      <WorkbenchBreadcrumb
        :items="breadcrumbs"
        @navigate="navigateBreadcrumb"
      />
      <header class="wb-profile-shell__heading">
        <div class="wb-profile-shell__identity">
          <h1>{{ identity.name }}</h1>
          <WorkbenchTag
            v-if="identity.tag"
            :label="identity.tag.label"
            :variant="identity.tag.variant || 'basic'"
          />
        </div>
        <dl
          v-if="identity.details?.length"
          class="wb-profile-shell__identity-details"
        >
          <div
            v-for="detail in identity.details"
            :key="detail.label"
          >
            <dt>{{ detail.label }}</dt>
            <dd>{{ detail.value }}</dd>
          </div>
        </dl>
      </header>
      <WorkbenchCard
        variant="display-white"
        class="wb-profile-shell__content-card"
        :class="resolvedContentClass"
        :aria-label="contentLabel"
      >
        <WorkbenchTabs
          :model-value="primary"
          :items="primaryItems"
          variant="rail"
          :aria-label="primaryLabel"
          @update:model-value="(value) => chooseTab('primary', value)"
        >
          <template #panel>
            <WorkbenchTabs
              v-if="secondaryItems.length"
              v-show="primary === secondaryParentValue"
              :model-value="secondary"
              :items="secondaryItems"
              variant="divider"
              :aria-label="secondaryLabel"
              @update:model-value="(value) => chooseTab('secondary', value)"
            >
              <template #panel>
                <slot
                  name="secondary-content"
                  :primary="primary"
                  :secondary="secondary"
                  :primary-item="primaryItem"
                  :secondary-item="secondaryItem"
                />
              </template>
            </WorkbenchTabs>
            <slot
              v-if="primary !== secondaryParentValue || !secondaryItems.length"
              name="primary-content"
              :primary="primary"
              :primary-item="primaryItem"
            />
          </template>
        </WorkbenchTabs>
      </WorkbenchCard>
      <slot
        name="hint"
        :primary="primary"
        :secondary="secondary"
      />
    </main>
    <footer
      v-if="$slots.footer"
      class="wb-profile-shell__footer"
    >
      <slot name="footer" />
    </footer>
  </div>
</template>

<style>
.wb-profile-shell {
  min-height: 100vh;
  color: var(--wb-color-text-primary);
  background: var(--wb-color-surface-page);
}
.wb-profile-shell .wb-profile-shell__main {
  box-sizing: border-box;
  display: grid;
  width: 100%;
  max-width: calc(
    var(--wb-asset-wb-top-nav-grid-max-width) + var(--wb-spacing-screen-edge-expanded) +
      var(--wb-spacing-screen-edge-expanded)
  );
  gap: var(--wb-spacing-layout-content-gap);
  margin-inline: auto;
  padding: 0 var(--wb-spacing-screen-edge-expanded) var(--wb-spacing-layout-container-block);
  /* The page supplies its own navigation-to-content interval; this Block defaults to zero. */
  padding-block-start: var(--company-profile-shell-content-start, 0);
}
.wb-profile-shell .wb-profile-shell__heading {
  display: grid;
  gap: var(--wb-spacing-component-sm);
  margin-bottom: var(--wb-spacing-component-sm);
}
.wb-profile-shell .wb-profile-shell__identity,
.wb-profile-shell .wb-profile-shell__identity-details,
.wb-profile-shell .wb-profile-shell__identity-details > div {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--wb-spacing-component-sm);
  margin: 0;
}
.wb-profile-shell .wb-profile-shell__identity {
  min-height: var(--wb-asset-wb-form-control-height);
  gap: var(--wb-spacing-component-lg);
}
.wb-profile-shell .wb-profile-shell__heading h1 {
  margin: 0;
  font-size: var(--wb-font-headline-s-font-size);
  font-weight: var(--wb-font-headline-s-font-weight);
  line-height: var(--wb-font-headline-s-line-height);
  letter-spacing: var(--wb-font-headline-s-letter-spacing);
}
.wb-profile-shell .wb-profile-shell__identity-details {
  min-height: var(--wb-asset-wb-form-control-height);
  gap: var(--wb-spacing-component-xl);
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
}
.wb-profile-shell .wb-profile-shell__identity-details dt {
  color: var(--wb-color-text-secondary);
}
.wb-profile-shell .wb-profile-shell__identity-details dd {
  margin: 0;
}
.wb-profile-shell .wb-profile-shell__content-card {
  container-type: inline-size;
  min-width: 0;
  overflow: visible;
}
.wb-profile-shell .wb-profile-shell__footer {
  padding: var(--wb-spacing-layout-container-block) var(--wb-spacing-screen-edge-expanded);
  border-top: 1px solid var(--wb-color-border-separator);
  color: var(--wb-color-text-secondary);
  text-align: center;
}
</style>
