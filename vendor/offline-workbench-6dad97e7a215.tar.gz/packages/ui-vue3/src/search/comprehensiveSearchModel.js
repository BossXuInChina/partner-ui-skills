export const fieldKey = value => JSON.stringify(['field', value]);
export const conditionKey = (field, value) => JSON.stringify(['value', field, value]);

// Search owns field/value data; CascaderPanel owns columns, rows and navigation.
export function comprehensiveOptions(fields) {
  const groups = new Map();
  for (const field of fields) {
    const name = field.group || '筛选条件';
    if (!groups.has(name)) groups.set(name, []);
    groups.get(name).push(field);
  }
  return [...groups].flatMap(([name, items], groupIndex) => [
    ...(groupIndex ? [{ key: JSON.stringify(['divider', name]), type: 'divider' }] : []),
    { key: JSON.stringify(['group', name]), type: 'group', label: name },
    ...items.map(field => ({
      key: fieldKey(field.value), label: field.label, disabled: field.disabled,
      kind: 'field', field,
      ...(field.options?.length ? {
        children: [
          { key: JSON.stringify(['heading', field.value]), type: 'group', label: field.label },
          ...field.options.map(option => ({
            key: conditionKey(field.value, option.value), label: option.label,
            disabled: option.disabled, kind: 'value', value: option.value,
          })),
        ],
      } : {}),
    })),
  ]);
}
