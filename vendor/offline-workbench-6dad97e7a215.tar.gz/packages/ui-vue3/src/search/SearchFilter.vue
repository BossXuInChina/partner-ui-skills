<script setup>
import { useFormDisabled } from '../form/useFormDisabled.js';
import '../shared/disclosure-motion.css';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import '../../../../catalog/generated/asset.tokens.css';
import { computed, nextTick, onBeforeUnmount, onMounted, ref, useId, watch } from 'vue';

const props = defineProps({
  side: { type: String, default: 'prefix' },
  type: {
    type: String,
    default: 'basic',
    validator: (value) => ['basic', 'filter-prefix', 'filter-suffix'].includes(value),
  },
  placeholder: { type: String, default: '请输入搜索内容' },
  disabled: Boolean,
  showIcon: { type: Boolean, default: true },
  previewState: { type: String, default: 'default' },
  filterLabel: { type: String, default: '筛选' },
  filterPlaceholder: String,
  filterValue: { type: String, default: '' },
  filterOptions: { type: Array, default: () => [] },
  showPanel: Boolean,
});
const disabled = useFormDisabled(() => props.disabled);

const emit = defineEmits([
  'update:modelValue',
  'update:filterValue',
  'search',
  'clear',
  'filter-change',
]);
const root = ref(null);
const panel = ref(null);
const portalled = ref(false);
let resizeObserver;
function hasClippingAncestor() {
  for (
    let node = root.value?.parentElement;
    node && node !== document.body;
    node = node.parentElement
  ) {
    const style = getComputedStyle(node);
    if (
      [style.overflowX, style.overflowY].some((value) => value && value !== 'visible') ||
      (style.clipPath && style.clipPath !== 'none') ||
      /paint|strict|content/.test(style.contain)
    )
      return true;
  }
  return false;
}
function within(node) {
  return Boolean(node && (root.value?.contains(node) || panel.value?.contains(node)));
}
function updatePanelPosition() {
  if (!expanded.value || !filterTrigger.value || !panel.value) return;
  const anchor = filterTrigger.value.getBoundingClientRect();
  const style = getComputedStyle(filterTrigger.value);
  const gap = parseFloat(style.getPropertyValue('--wb-spacing-component-xs')) || 0;
  const edge = parseFloat(style.getPropertyValue('--wb-spacing-component-sm')) || 0;
  const below = Math.max(0, window.innerHeight - edge - anchor.bottom - gap);
  const above = Math.max(0, anchor.top - edge - gap);
  const menu = panel.value;
  if (!portalled.value) {
    const rect = menu.getBoundingClientRect();
    if (
      hasClippingAncestor() ||
      rect.height > below ||
      rect.right > window.innerWidth - edge ||
      rect.left < edge
    ) {
      portalled.value = true;
      nextTick(updatePanelPosition);
    }
    return;
  }
  // A body-mounted menu keeps the host font, semantic tokens and modal ownership.
  for (const property of style) {
    if (property.startsWith('--wb-'))
      menu.style.setProperty(property, style.getPropertyValue(property));
  }
  for (const property of [
    'font-family',
    'font-size',
    'font-weight',
    'line-height',
    'letter-spacing',
  ]) {
    menu.style.setProperty(property, style.getPropertyValue(property));
  }
  const viewportWidth = Math.max(0, window.innerWidth - 2 * edge);
  const naturalWidth =
    parseFloat(style.getPropertyValue('--wb-asset-wb-search-panel-width')) || anchor.width;
  const width = Math.min(viewportWidth, Math.max(anchor.width, naturalWidth));
  menu.style.setProperty('--filter-panel-width', `${width}px`);
  const naturalHeight = menu.scrollHeight;
  const upwards = naturalHeight > below && above > below;
  menu.style.setProperty('--filter-panel-max-height', `${upwards ? above : below}px`);
  const height = menu.getBoundingClientRect().height;
  const left = props.side === 'suffix' ? anchor.right - width : anchor.left;
  menu.style.setProperty(
    '--filter-panel-left',
    `${Math.max(edge, Math.min(left, window.innerWidth - edge - width))}px`,
  );
  menu.style.setProperty(
    '--filter-panel-top',
    `${upwards ? anchor.top - height - gap : anchor.bottom + gap}px`,
  );
  menu.style.removeProperty('z-index');
  const owner = root.value.closest('.wb-modal-host, .wb-drawer-host');
  if (owner) menu.style.zIndex = String(Number(getComputedStyle(owner).zIndex) + 1);
}
function preparePanel() {
  portalled.value = hasClippingAncestor();
  nextTick(updatePanelPosition);
}

const filterTrigger = ref(null);
const localOpen = ref(false);
const id = useId();

const isDisabled = computed(() => disabled.value || props.previewState === 'disabled');
const expanded = computed(
  () => !isDisabled.value && (props.showPanel || props.previewState === 'open' || localOpen.value),
);
const selectedFilter = computed(() =>
  props.filterOptions.find((option) => option.value === props.filterValue),
);
const filterText = computed(
  () => selectedFilter.value?.label || props.filterPlaceholder || props.filterLabel,
);

function enabledOptions() {
  return [...(panel.value?.querySelectorAll('[role="option"]') || [])].filter(
    (option) => !option.disabled,
  );
}
function focusOption(index = 0) {
  nextTick(async () => {
    updatePanelPosition();
    await nextTick();
    const options = enabledOptions();
    options[Math.max(0, Math.min(index, options.length - 1))]?.focus();
  });
}
function toggleFilter() {
  if (isDisabled.value) return;
  localOpen.value = !localOpen.value;
  if (localOpen.value) focusOption();
}
function selectFilter(option) {
  if (isDisabled.value || option.disabled) return;
  const cleared = props.filterValue === option.value;
  emit('update:filterValue', cleared ? '' : option.value);
  emit('filter-change', cleared ? null : option);
  localOpen.value = false;
  filterTrigger.value?.focus();
}
function filterKeydown(event) {
  if (isDisabled.value) return;
  if (event.key === 'Escape' && expanded.value) {
    event.preventDefault();
    event.stopPropagation();
    localOpen.value = false;
    filterTrigger.value?.focus();
    return;
  }
  if (!['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) return;
  event.preventDefault();
  event.stopPropagation();
  const options = enabledOptions();
  const index = options.indexOf(document.activeElement);
  localOpen.value = true;
  if (event.key === 'Home') focusOption(0);
  else if (event.key === 'End') focusOption(options.length - 1);
  else
    focusOption(
      index < 0
        ? 0
        : (index + (event.key === 'ArrowDown' ? 1 : -1) + options.length) % options.length,
    );
}
function blur(event) {
  if (!within(event.relatedTarget)) localOpen.value = false;
}
function outside(event) {
  if (!within(event.target)) localOpen.value = false;
}

watch(
  () => props.showPanel,
  (value) => {
    localOpen.value = value && !isDisabled.value;
  },
  { immediate: true },
);
watch(isDisabled, (value) => {
  if (value) localOpen.value = false;
});
watch(expanded, preparePanel, { flush: 'sync' });
watch(
  panel,
  (node, previous) => {
    if (previous) resizeObserver?.unobserve(previous);
    if (node) resizeObserver?.observe(node);
    nextTick(updatePanelPosition);
  },
  { flush: 'post' },
);
onMounted(() => {
  document.addEventListener('pointerdown', outside);
  document.addEventListener('scroll', updatePanelPosition, true);
  window.addEventListener('resize', updatePanelPosition);
  resizeObserver = new ResizeObserver(updatePanelPosition);
  if (root.value) resizeObserver.observe(root.value);
  if (panel.value) resizeObserver.observe(panel.value);
  preparePanel();
});
onBeforeUnmount(() => {
  document.removeEventListener('pointerdown', outside);
  document.removeEventListener('scroll', updatePanelPosition, true);
  window.removeEventListener('resize', updatePanelPosition);
  resizeObserver?.disconnect();
});
</script>
<template>
  <div
    ref="root"
    class="wb-search__filter"
    :class="[
      `wb-search__filter--${side}`,
      {
        'is-disabled': isDisabled,
        'is-expanded': expanded,
        'has-selection': !!selectedFilter,
        'is-placeholder': !selectedFilter && !!filterPlaceholder,
      },
    ]"
    @keydown="filterKeydown"
    @focusout="blur"
  >
    <button
      ref="filterTrigger"
      class="wb-search__filter-trigger"
      type="button"
      :disabled="isDisabled"
      aria-haspopup="listbox"
      :aria-expanded="expanded"
      :aria-controls="expanded ? `${id}-filter-list` : undefined"
      @click="toggleFilter"
    >
      <span class="wb-search__filter-main"
        ><span
          v-if="showIcon"
          class="wb-search__filter-icon"
          aria-hidden="true"
          ><slot name="filter-icon"><WorkbenchIcon name="文件夹_14px" /></slot></span
        ><span class="wb-search__filter-label">{{ filterText }}</span></span
      >
      <WorkbenchIcon
        class="wb-search__filter-arrow wb-disclosure-icon"
        :class="{ 'is-expanded': expanded }"
        name="箭头/尺寸=10, 方向=下箭头"
        :size="10"
      />
    </button>
    <Teleport
      to="body"
      :disabled="!portalled"
    >
      <div
        v-if="expanded"
        ref="panel"
        :id="`${id}-filter-list`"
        class="wb-search__panel"
        :class="{ 'wb-search__panel--suffix': side === 'suffix', 'is-teleported': portalled }"
        @keydown="filterKeydown"
        @focusout="blur"
        role="listbox"
        :aria-label="`${filterLabel}选项`"
      >
        <button
          v-for="option in filterOptions"
          :key="option.value"
          class="wb-search__option"
          type="button"
          role="option"
          :disabled="option.disabled"
          :aria-disabled="option.disabled || undefined"
          :aria-selected="filterValue === option.value"
          :title="option.label"
          @click="selectFilter(option)"
        >
          <span>{{ option.label }}</span
          ><span
            v-if="filterValue === option.value"
            aria-hidden="true"
            class="wb-search__selected-mark"
            ><svg viewBox="0 0 10 10"><path d="m1 5 3 3 5-6" /></svg
          ></span>
        </button>
      </div>
    </Teleport>
  </div>
</template>
