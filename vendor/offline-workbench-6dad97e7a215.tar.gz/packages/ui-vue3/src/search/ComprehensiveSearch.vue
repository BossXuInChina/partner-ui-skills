<script setup>
import { useFormDisabled } from '../form/useFormDisabled.js';
import { computed, nextTick, onBeforeUnmount, onMounted, ref, useId, watch } from 'vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import CascaderPanel from '../cascader/CascaderPanel.vue';
import { indexOptions } from '../cascader/cascaderModel.js';
import { comprehensiveOptions, conditionKey, fieldKey } from './comprehensiveSearchModel.js';
import WorkbenchPopover from '../popover/WorkbenchPopover.vue';
import WorkbenchTooltip from '../tooltip/WorkbenchTooltip.vue';
import WorkbenchTag from '../tag/WorkbenchTag.vue';
import '../tag/tag-surface.css';

const props = defineProps({
  modelValue: { type: String, default: '' },
  conditions: { type: Array, default: () => [] },
  fields: { type: Array, default: () => [] },
  disabled: Boolean,
  wrapConditions: Boolean,
  previewState: { type: String, default: 'default' },
  helpText: { type: String, default: '直接输入关键字搜索，或选择筛选字段后输入、选择条件；Enter 搜索，Escape 关闭面板。' },
});
const disabled = useFormDisabled(() => props.disabled);
const emit = defineEmits(['update:modelValue', 'update:conditions', 'search', 'clear', 'condition-change']);
const root = ref(null);
const input = ref(null);
const trigger = ref(null);
const panel = ref(null);
const cascader = ref(null);
const actions = ref(null);
const measure = ref(null);
const reserve = ref(null);
const overflowMeasure = ref(null);
const overflowList = ref(null);
const visibleCount = ref(Infinity);
const panelOpen = ref(false);
const activeField = ref(null);
const composing = ref(false);
const panelId = `comprehensive-${useId()}`;
const isDisabled = computed(() => disabled.value || props.previewState === 'disabled');
const shown = computed(() => !isDisabled.value && panelOpen.value);
const visibleConditions = computed(() => props.wrapConditions ? props.conditions : props.conditions.slice(0, visibleCount.value));
const hiddenConditions = computed(() => props.wrapConditions ? [] : props.conditions.slice(visibleCount.value));
const menuOptions = computed(() => comprehensiveOptions(props.fields));
const menuIndex = computed(() => indexOptions(menuOptions.value));
const menuPath = computed(() => activeField.value?.options?.length ? [fieldKey(activeField.value.value)] : []);
const menuSelected = computed(() => [
  ...props.conditions.flatMap(item => [fieldKey(item.field), conditionKey(item.field, item.value)]),
]);
const placeholder = computed(() => activeField.value ? '请输入条件值' : props.conditions.length ? '添加筛选条件' : '默认按照关键字搜索');
let observer;
let overflowObserver;

function fitOverflowTags() {
  const list = overflowList.value;
  const surface = list?.closest('.wb-popover__panel');
  if (!surface || !list.children.length) return;
  surface.style.removeProperty('--comprehensive-tags-width');
  const left = list.getBoundingClientRect().left;
  const occupied = Math.max(...[...list.children].map(item => item.getBoundingClientRect().right)) - left;
  const style = getComputedStyle(surface);
  const width = occupied + parseFloat(style.paddingLeft) + parseFloat(style.paddingRight);
  surface.style.setProperty('--comprehensive-tags-width', `${width}px`);
}
watch(overflowList, node => {
  overflowObserver?.disconnect();
  if (!node) return;
  overflowObserver = new ResizeObserver(fitOverflowTags);
  overflowObserver.observe(node);
  fitOverflowTags();
}, { flush: 'post' });
watch([hiddenConditions, () => props.fields], () => nextTick(fitOverflowTags), { deep: true, flush: 'post' });

function label(condition) {
  const field = props.fields.find(item => item.value === condition.field);
  const option = field?.options?.find(item => item.value === condition.value);
  return `${field?.label || condition.field}：${condition.label || option?.label || condition.value}`;
}
function updateConditions(conditions) {
  emit('update:conditions', conditions);
  emit('condition-change', conditions);
}
function remove(index) {
  if (isDisabled.value) return;
  updateConditions(props.conditions.filter((_, itemIndex) => itemIndex !== index));
}
function chooseField(field) {
  if (isDisabled.value || field.disabled) return;
  activeField.value = field;
  panelOpen.value = Boolean(field.options?.length);
  nextTick(() => input.value?.focus());
}
function expandField(key) {
  const item = menuIndex.value.get(key);
  if (item?.kind === 'field') chooseField(item.field);
}
function chooseMenu(key) {
  const item = menuIndex.value.get(key);
  if (item?.disabled || isDisabled.value) return;
  if (item?.kind === 'field') chooseField(item.field);
  else if (item?.kind === 'value') addCondition(item.value, item.label);
}
function toggleMenu(key) {
  const item = menuIndex.value.get(key);
  if (!item || item.disabled || isDisabled.value || item.kind !== 'field') return;
  if (menuSelected.value.includes(key)) {
    updateConditions(props.conditions.filter(condition => condition.field !== item.field.value));
    if (activeField.value?.value === item.field.value) activeField.value = null;
  } else chooseField(item.field);
}
function closePanel() {
  panelOpen.value = false;
  activeField.value = null;
  nextTick(() => trigger.value?.focus());
}
function addCondition(value, text) {
  if (isDisabled.value || !activeField.value || !String(value).trim()) return;
  const condition = { field: activeField.value.value, value, ...(text ? { label: text } : {}) };
  const existing = props.conditions.filter(item => item.field !== condition.field);
  updateConditions([...existing, condition]);
  emit('update:modelValue', '');
  activeField.value = null;
  panelOpen.value = false;
  nextTick(() => input.value?.focus());
}
function submit(event) {
  if (isDisabled.value || composing.value || event.isComposing || event.keyCode === 229) return;
  event.preventDefault();
  if (activeField.value) addCondition(props.modelValue);
  else { panelOpen.value = false; emit('search', { keyword: props.modelValue, conditions: props.conditions }); }
}
function clear() {
  if (isDisabled.value) return;
  emit('update:modelValue', '');
  updateConditions([]);
  activeField.value = null;
  panelOpen.value = false;
  emit('clear');
  nextTick(() => input.value?.focus());
}
function openPanel() { if (!isDisabled.value) panelOpen.value = true; }
function onKeydown(event) {
  if (event.key === 'Escape') {
    event.stopPropagation();
    closePanel();
  } else if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
    event.preventDefault();
    openPanel();
    nextTick(() => cascader.value?.focusFirst());
  } else if (event.key === 'ArrowLeft' && activeField.value) activeField.value = null;
}
function outside(event) {
  if (!root.value?.contains(event.target)) panelOpen.value = false;
}
function blur(event) {
  if (!root.value?.contains(event.relatedTarget)) panelOpen.value = false;
}
function updatePanelPosition() {
  const node = root.value;
  const anchor = trigger.value;
  const overlay = panel.value;
  if (!shown.value || !node || !anchor || !overlay) return;
  const bounds = node.getBoundingClientRect();
  const target = anchor.getBoundingClientRect();
  const style = getComputedStyle(node);
  const numeric = key => parseFloat(style.getPropertyValue(key)) || 0;
  const scaleX = bounds.width / node.offsetWidth || 1;
  const scaleY = bounds.height / node.offsetHeight || 1;
  const edge = numeric('--wb-spacing-component-xs');
  const gap = edge * scaleY;
  const rowInset = Math.max(0, (numeric('--wb-asset-wb-search-core-height') * scaleY - target.height) / 2);
  const below = target.bottom + rowInset + gap;
  const above = target.top - rowInset - gap;
  const roomBelow = window.innerHeight - edge - below;
  const roomAbove = above - edge;
  const opensAbove = overlay.getBoundingClientRect().height > roomBelow && roomAbove > roomBelow;
  const available = Math.max(0, opensAbove ? roomAbove : roomBelow);
  overlay.style.setProperty('--comprehensive-menu-max-height', `${available / scaleY}px`);
  const menu = overlay.getBoundingClientRect();
  const panelStyle = getComputedStyle(overlay.querySelector('.wb-cascader-panel'));
  const optionStyle = getComputedStyle(overlay.querySelector('.wb-cascader-panel__option'));
  const contentInset = (parseFloat(panelStyle.paddingLeft) + parseFloat(optionStyle.paddingLeft)) * scaleX;
  const textLeft = input.value.getBoundingClientRect().left - contentInset;
  const left = Math.min(Math.max(edge, textLeft), Math.max(edge, window.innerWidth - edge - menu.width));
  const top = opensAbove ? above - menu.height : below;
  overlay.dataset.side = opensAbove ? 'top' : 'bottom';
  overlay.style.setProperty('--comprehensive-menu-left', `${(left - bounds.left) / scaleX - numeric('border-left-width')}px`);
  overlay.style.setProperty('--comprehensive-menu-top', `${(top - bounds.top) / scaleY - numeric('border-top-width')}px`);
}
function fit() {
  if (!root.value) return;
  root.value.style.setProperty('--comprehensive-actions-width', `${actions.value?.offsetWidth || 0}px`);
  if (!measure.value || props.wrapConditions) return;
  const style = getComputedStyle(root.value);
  const padding = parseFloat(style.paddingLeft) + parseFloat(style.paddingRight);
  const gap = parseFloat(style.columnGap) || 4;
  let available = root.value.clientWidth - padding - (actions.value?.offsetWidth || 0) - (reserve.value?.offsetWidth || 0) - (trigger.value?.offsetWidth || 0) - (root.value.querySelector('.wb-comprehensive-search__field')?.offsetWidth || 0) - gap * 4;
  const widths = [...measure.value.children].map(item => item.getBoundingClientRect().width);
  const total = widths.reduce((sum, width) => sum + width + gap, 0);
  if (total <= available) { visibleCount.value = widths.length; return; }
  available -= (overflowMeasure.value?.getBoundingClientRect().width || 0) + gap;
  let count = 0;
  for (const width of widths) { if (available < width + gap) break; available -= width + gap; count++; }
  visibleCount.value = count;
}
watch(() => [props.conditions, props.wrapConditions, props.modelValue, activeField.value], () => nextTick(fit), { deep: true });
watch(() => props.previewState, state => { panelOpen.value = state === 'open'; }, { immediate: true });
watch([shown, activeField, visibleCount, () => props.conditions, () => props.wrapConditions], () => nextTick(updatePanelPosition), { deep: true, flush: 'post' });
watch(panel, (node, previous) => {
  if (previous) observer?.unobserve(previous);
  if (node) observer?.observe(node);
  nextTick(updatePanelPosition);
}, { flush: 'post' });
watch(isDisabled, disabled => { if (disabled) { panelOpen.value = false; activeField.value = null; } });
onMounted(() => {
  observer = new ResizeObserver(() => { fit(); nextTick(updatePanelPosition); });
  observer.observe(root.value);
  if (actions.value) observer.observe(actions.value);
  if (trigger.value) observer.observe(trigger.value);
  window.addEventListener('resize', updatePanelPosition);
  window.addEventListener('resize', fitOverflowTags);
  document.addEventListener('scroll', updatePanelPosition, true);
  document.addEventListener('pointerdown', outside);
  nextTick(fit);
});
onBeforeUnmount(() => { overflowObserver?.disconnect(); window.removeEventListener('resize', fitOverflowTags); observer?.disconnect(); window.removeEventListener('resize', updatePanelPosition); document.removeEventListener('scroll', updatePanelPosition, true); document.removeEventListener('pointerdown', outside); });
</script>

<template>
  <div ref="root" class="wb-comprehensive-search" :class="[`is-${previewState}`, { 'is-disabled': isDisabled, 'has-conditions': conditions.length, 'is-wrapping': wrapConditions }]" @keydown="onKeydown" @focusout="blur">
    <div v-for="(condition, index) in visibleConditions" :key="`${condition.field}-${index}`" class="wb-comprehensive-search__chip wb-tag-surface">
      <span>{{ label(condition) }}</span>
      <button class="wb-tag-surface__remove" type="button" :aria-label="`删除条件${label(condition)}`" :disabled="isDisabled" @click="remove(index)"><WorkbenchIcon name="/ic_public_close_line_8px" /></button>
    </div>
    <WorkbenchPopover v-if="hiddenConditions.length" placement="top" aria-label="更多筛选条件" :disabled="isDisabled">
      <template #trigger="{ aria }"><button v-bind="aria" class="wb-comprehensive-search__overflow" type="button" :disabled="isDisabled" :aria-label="`查看其余${hiddenConditions.length}个条件`"><WorkbenchTag :label="`+${hiddenConditions.length}`" /></button></template>
      <div ref="overflowList" class="wb-comprehensive-search__overflow-list">
        <div v-for="(condition, index) in hiddenConditions" :key="`${condition.field}-${index}`" class="wb-comprehensive-search__chip wb-tag-surface">
          <span>{{ label(condition) }}</span><button class="wb-tag-surface__remove" type="button" :aria-label="`删除条件${label(condition)}`" :disabled="isDisabled" @click.stop="remove(visibleCount + index)"><WorkbenchIcon name="/ic_public_close_line_8px" /></button>
        </div>
      </div>
    </WorkbenchPopover>
    <div class="wb-comprehensive-search__entry">
      <span v-if="activeField" class="wb-comprehensive-search__field">{{ activeField.label }}：</span>
      <button ref="trigger" type="button" class="wb-comprehensive-search__filter" aria-label="选择筛选条件" aria-haspopup="dialog" :aria-controls="shown ? panelId : undefined" :aria-expanded="shown" :disabled="isDisabled" @click="panelOpen = !panelOpen">
        <WorkbenchIcon :name="`筛选/尺寸=14,类型=${conditions.length ? '已筛选' : '未筛选'},面性=off`" />
      </button>
      <input ref="input" type="search" class="wb-comprehensive-search__input" aria-label="综合搜索内容" :placeholder="placeholder" :value="modelValue" :disabled="isDisabled" @input="emit('update:modelValue', $event.target.value)" @keydown.enter="submit" @compositionstart="composing = true" @compositionend="composing = false" />
    </div>
    <div ref="actions" class="wb-comprehensive-search__actions">
      <button v-if="modelValue || conditions.length" type="button" aria-label="清除综合搜索" :disabled="isDisabled" @click="clear"><WorkbenchIcon name="/ic_public_close_line_14px" /></button>
      <span v-if="modelValue || conditions.length" class="wb-comprehensive-search__separator" aria-hidden="true"></span>
      <WorkbenchTooltip :content="helpText" placement="top" :disabled="isDisabled"><template #trigger="{ aria }"><button v-bind="aria" type="button" aria-label="综合搜索帮助" :disabled="isDisabled"><WorkbenchIcon name="问号/大小=14,面性=off" /></button></template></WorkbenchTooltip>
    </div>
    <div v-if="shown" :id="panelId" ref="panel" class="wb-comprehensive-search__panel" role="dialog" aria-label="综合搜索筛选面板">
      <CascaderPanel ref="cascader" :options="menuOptions" :index="menuIndex" :path="menuPath" :selected="menuSelected" :column-selection="['multiple', 'single']" label="综合搜索条件" @expand="expandField" @choose="chooseMenu" @toggle="toggleMenu" @close="closePanel" />
    </div>
    <div ref="measure" class="wb-comprehensive-search__measure wb-comprehensive-search__conditions-measure" aria-hidden="true"><span v-for="(condition, index) in conditions" :key="index" class="wb-comprehensive-search__chip wb-tag-surface">{{ label(condition) }}<WorkbenchIcon name="/ic_public_close_line_8px" /></span></div>
    <span ref="overflowMeasure" class="wb-comprehensive-search__measure" aria-hidden="true"><WorkbenchTag :label="`+${conditions.length}`" /></span>
    <span ref="reserve" class="wb-comprehensive-search__reserve" aria-hidden="true"></span>
  </div>
</template>

<style src="./comprehensive-search.css"></style>
