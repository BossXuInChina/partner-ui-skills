<script setup>
import { useFormDisabled } from '../form/useFormDisabled.js';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import '../../../../catalog/generated/asset.tokens.css';
import { computed, nextTick, ref } from 'vue';
import SearchFilter from './SearchFilter.vue';
import ComprehensiveSearch from './ComprehensiveSearch.vue';
const props = defineProps({
  conditions: { type: Array, default: () => [] },
  fields: { type: Array, default: () => [] },
  wrapConditions: Boolean,
  helpText: String,
  modelValue: { type: String, default: '' },
  searchIconPosition: { type: String, default: 'left', validator: value => ['left', 'right'].includes(value) },
  variant: { type: String, default: 'outlined', validator: value => ['outlined', 'filled'].includes(value) },
  appearance: { type: String, default: 'standard', validator: value => ['standard', 'global'].includes(value) },
  type: { type: String, default: 'basic' },
  placeholder: { type: String, default: '请输入搜索内容' },
  disabled: Boolean,
  prefixDisabled: Boolean,
  suffixDisabled: Boolean,
  showPrefixIcon: { type: Boolean, default: true },
  showSuffixIcon: { type: Boolean, default: true },
  previewState: { type: String, default: 'default' },
  filterValue: { type: String, default: '' },
  filterOptions: { type: Array, default: () => [] },
  prefixValue: { type: String, default: '' },
  suffixValue: { type: String, default: '' },
  prefixOptions: { type: Array, default: () => [] },
  suffixOptions: { type: Array, default: () => [] },
  showPanel: Boolean,
});
const disabled = useFormDisabled(() => props.disabled);
const emit = defineEmits(['update:modelValue', 'update:filterValue', 'update:prefixValue', 'update:suffixValue', 'search', 'clear', 'filter-change', 'update:conditions', 'condition-change']);
const input = ref(null);
const composing = ref(false);
const both = computed(() => props.type === 'filter-both');
const isDisabled = computed(() => disabled.value || props.previewState === 'disabled');
let lastLiveValue;
function searchLive(value) {
  if (props.searchIconPosition !== 'left' || isDisabled.value || composing.value || value === lastLiveValue) return;
  lastLiveValue = value;
  emit('search', value);
}
function updateValue(event) { if (isDisabled.value) return; emit('update:modelValue', event.target.value); if (!event.isComposing) searchLive(event.target.value); }
function endComposition(event) { composing.value = false; searchLive(event.target.value); }
function submitSearch(event) { if (!isDisabled.value && !composing.value && !event.isComposing && event.keyCode !== 229) { event.preventDefault(); emit('search', props.modelValue); } }
function clear() { if (isDisabled.value) return; emit('update:modelValue', ''); emit('clear'); searchLive(''); nextTick(() => input.value?.focus()); }
</script>
<template>
  <ComprehensiveSearch v-if="type === 'comprehensive'" :model-value="modelValue" :conditions="conditions" :fields="fields" :wrap-conditions="wrapConditions" :help-text="helpText" :disabled="disabled" :preview-state="previewState" @update:model-value="emit('update:modelValue', $event)" @update:conditions="emit('update:conditions', $event)" @search="emit('search', $event)" @clear="emit('clear')" @condition-change="emit('condition-change', $event)" />
  <div v-else class="wb-search" :class="[`wb-search--${type}`, `is-${previewState}`, { 'is-disabled': isDisabled, 'wb-search--global': appearance === 'global', 'wb-search--filled': variant === 'filled', 'is-populated': Boolean(modelValue) }]" :data-grid-span="both ? 6 : 4">
    <SearchFilter v-if="type === 'filter-prefix' || both" side="prefix" :show-icon="showPrefixIcon" :filter-value="both ? prefixValue : filterValue" :filter-options="both ? prefixOptions : filterOptions" :disabled="isDisabled || prefixDisabled" :preview-state="previewState" :show-panel="showPanel" @update:filter-value="emit(both ? 'update:prefixValue' : 'update:filterValue', $event)" @filter-change="emit('filter-change', $event)">
      <template #filter-icon><slot name="prefix-icon"><slot name="filter-icon"><WorkbenchIcon name="文件夹_14px" /></slot></slot></template>
    </SearchFilter>
    <div class="wb-search__core" :class="`wb-search__core--icon-${searchIconPosition}`">
      <WorkbenchIcon v-if="searchIconPosition === 'left'" class="wb-search__search-icon wb-search__search-icon--left" :name="appearance === 'global' ? 'WB-TOP-NAV/action/search_20px' : '搜索_14px'" />
      <input ref="input" class="wb-search__input" type="search" :value="modelValue" :placeholder="placeholder" :disabled="isDisabled" @input="updateValue" @compositionstart="composing = true" @compositionend="endComposition" @keydown.enter="submitSearch" />
      <span v-if="modelValue || searchIconPosition === 'right'" class="wb-search__actions">
        <button v-if="modelValue" class="wb-search__clear" :class="{ 'wb-search__clear--left': searchIconPosition === 'left' }" type="button" :disabled="isDisabled" aria-label="清除搜索内容" @click="clear"><WorkbenchIcon :name="appearance === 'global' ? '/ic_public_close_line_16px' : '/ic_public_close_line_14px'" /></button>
        <template v-if="searchIconPosition === 'right'">
          <span v-if="modelValue" class="wb-search__actions-separator" aria-hidden="true"></span>
          <button class="wb-search__submit" type="button" aria-label="执行搜索" :disabled="isDisabled" @click="submitSearch"><WorkbenchIcon class="wb-search__search-icon" :name="appearance === 'global' ? 'WB-TOP-NAV/action/search_20px' : '搜索_14px'" /></button>
        </template>
      </span>
    </div>
    <SearchFilter v-if="type === 'filter-suffix' || both" side="suffix" :show-icon="showSuffixIcon" :filter-value="both ? suffixValue : filterValue" :filter-options="both ? suffixOptions : filterOptions" :disabled="isDisabled || suffixDisabled" :preview-state="previewState" :show-panel="showPanel" @update:filter-value="emit(both ? 'update:suffixValue' : 'update:filterValue', $event)" @filter-change="emit('filter-change', $event)">
      <template #filter-icon><slot name="suffix-icon"><slot name="filter-icon"><WorkbenchIcon name="文件夹_14px" /></slot></slot></template>
    </SearchFilter>
  </div>
</template>




<style src="./search.css"></style>
