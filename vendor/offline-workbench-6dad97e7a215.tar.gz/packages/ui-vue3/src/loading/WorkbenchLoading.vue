<script setup>
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import { computed } from 'vue';

const props = defineProps({
  size: {
    type: Number,
    default: 20,
    validator: (value) => [64, 48, 24, 20, 14, 12].includes(value),
  },
  inverse: { type: Boolean, default: false },
  label: { type: String, default: '' },
  ariaLabel: { type: String, default: '' },
});

const resolvedSize = computed(() =>
  [64, 48, 24, 20, 14, 12].includes(props.size) ? props.size : 20,
);
const dotSize = computed(() => resolvedSize.value / 8);
const center = computed(() => resolvedSize.value / 2);
const radius = computed(() => center.value - dotSize.value / 2);
const dots = computed(() =>
  Array.from({ length: 8 }, (_, index) => {
    const angle = (index * Math.PI) / 4;
    return {
      x: center.value + radius.value * Math.sin(angle),
      y: center.value - radius.value * Math.cos(angle),
    };
  }),
);
const statusLabel = computed(() => props.label || props.ariaLabel);
</script>

<template>
  <span
    class="wb-loading"
    :class="[
      `wb-loading--size-${resolvedSize}`,
      { 'wb-loading--inverse': inverse, 'wb-loading--announced': Boolean(statusLabel) },
    ]"
    :role="statusLabel ? 'status' : undefined"
    :aria-live="statusLabel ? 'polite' : undefined"
    :aria-label="statusLabel || undefined"
    :aria-hidden="statusLabel ? undefined : 'true'"
  >
    <svg
      class="wb-loading__svg"
      :viewBox="`0 0 ${resolvedSize} ${resolvedSize}`"
      aria-hidden="true"
    >
      <circle
        v-for="(dot, index) in dots"
        :key="index"
        class="wb-loading__dot"
        :cx="dot.x"
        :cy="dot.y"
        :r="dotSize / 2"
      />
      <g class="wb-loading__phase">
        <g class="wb-loading__spin">
          <circle
            class="wb-loading__arc"
            :cx="center"
            :cy="center"
            :r="radius"
            pathLength="100"
            fill="none"
            :stroke-width="dotSize"
          />
        </g>
      </g>
    </svg>
    <span
      v-if="statusLabel"
      class="wb-loading__sr-only"
      >{{ statusLabel }}</span
    >
  </span>
</template>

<style>
.wb-loading {
  --loading-track-color: var(--wb-asset-wb-loading-track-color-light);
  display: inline-flex;
  color: var(--wb-color-icon-primary);
}
.wb-loading--size-64 {
  width: var(--wb-asset-wb-loading-size-64);
  height: var(--wb-asset-wb-loading-size-64);
}
.wb-loading--size-48 {
  width: var(--wb-asset-wb-loading-size-48);
  height: var(--wb-asset-wb-loading-size-48);
}
.wb-loading--size-24 {
  width: var(--wb-asset-wb-loading-size-24);
  height: var(--wb-asset-wb-loading-size-24);
}
.wb-loading--size-20 {
  width: var(--wb-asset-wb-loading-size-20);
  height: var(--wb-asset-wb-loading-size-20);
}
.wb-loading--size-14 {
  width: var(--wb-asset-wb-loading-size-14);
  height: var(--wb-asset-wb-loading-size-14);
}
.wb-loading--size-12 {
  width: var(--wb-asset-wb-loading-size-12);
  height: var(--wb-asset-wb-loading-size-12);
}
.wb-loading__svg {
  display: block;
  width: 100%;
  height: 100%;
  overflow: visible;
}
.wb-loading__dot {
  fill: var(--loading-track-color);
  stroke: none;
}
.wb-loading__phase {
  transform-box: view-box;
  transform-origin: center;
  animation: wb-loading-phase var(--wb-asset-wb-loading-phase-duration) linear infinite;
}
.wb-loading__spin {
  transform-box: view-box;
  transform-origin: center;
  animation: wb-loading-spin var(--wb-asset-wb-loading-motion-duration) linear infinite;
}
.wb-loading__arc {
  stroke: currentColor;
  stroke-linecap: round;
  animation: wb-loading-arc var(--wb-asset-wb-loading-motion-duration)
    var(--wb-asset-wb-loading-motion-easing) infinite;
}
.wb-loading--inverse {
  color: var(--wb-asset-wb-loading-inverse-foreground-color);
}
.wb-loading--inverse .wb-loading__dot {
  fill: var(--wb-asset-wb-loading-inverse-track-color);
}
[data-wb-theme='dark'] .wb-loading {
  --loading-track-color: var(--wb-asset-wb-loading-track-color-dark);
}
.wb-loading__sr-only {
  position: absolute;
  width: var(--wb-asset-wb-loading-sr-only-size);
  height: var(--wb-asset-wb-loading-sr-only-size);
  padding: 0;
  margin: var(--wb-asset-wb-loading-sr-only-offset);
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border: 0;
}
@keyframes wb-loading-spin {
  from {
    transform: rotate(-90deg);
  }
  to {
    transform: rotate(90deg);
  }
}
@keyframes wb-loading-phase {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}
@keyframes wb-loading-arc {
  0% {
    stroke-dasharray: 4.55 100;
    stroke-dashoffset: 0;
  }
  50% {
    stroke-dasharray: var(--wb-asset-wb-loading-arc-max-length) 100;
    stroke-dashoffset: 0;
  }
  100% {
    stroke-dasharray: 4.55 100;
    stroke-dashoffset: -45.45;
  }
}
@media (prefers-reduced-motion: reduce) {
  .wb-loading__phase,
  .wb-loading__spin,
  .wb-loading__arc {
    animation: none;
  }
  .wb-loading__arc {
    stroke-dasharray: 50 100;
  }
}
</style>
