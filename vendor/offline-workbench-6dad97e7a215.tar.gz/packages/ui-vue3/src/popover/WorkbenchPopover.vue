<script setup>
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import { computed, nextTick, onBeforeUnmount, onMounted, ref, useId, watch } from 'vue';
import PopoverArrow from './PopoverArrow.vue';

const placements = ['top-start', 'top', 'top-end', 'right-start', 'right', 'right-end', 'bottom-start', 'bottom', 'bottom-end', 'left-start', 'left', 'left-end'];
const opposite = { top: 'bottom', bottom: 'top', left: 'right', right: 'left' };
const props = defineProps({
  placement: { type: String, default: 'top', validator: value => ['top-start', 'top', 'top-end', 'right-start', 'right', 'right-end', 'bottom-start', 'bottom', 'bottom-end', 'left-start', 'left', 'left-end'].includes(value) },
  title: { type: String, default: '' },
  open: { type: Boolean, default: undefined },
  disabled: Boolean,
  ariaLabel: { type: String, default: '说明气泡' },
});
const emit = defineEmits(['update:open']);
const id = useId();
const root = ref(null); const panel = ref(null); const internalOpen = ref(false);
let closeTimer; let observer; let ignoreNextFocusOpen = false;
const controlled = computed(() => props.open !== undefined);
const shown = computed(() => !props.disabled && (controlled.value ? props.open : internalOpen.value));
const triggerSlotProps = computed(() => ({ open: shown.value, aria: { 'aria-describedby': shown.value ? `${id}-popover` : undefined } }));
function setOpen(value) { const next = Boolean(value) && !props.disabled; if (!controlled.value) internalOpen.value = next; emit('update:open', next); if (next) nextTick(updatePosition); }
function cancelClose() { window.clearTimeout(closeTimer); }
function scheduleClose() { cancelClose(); closeTimer = window.setTimeout(() => { if (!root.value?.matches(':hover') && !panel.value?.matches(':hover') && !within(document.activeElement)) setOpen(false); }, 0); }
function within(node) { return Boolean(node && (root.value?.contains(node) || panel.value?.contains(node))); }
function onFocusOut(event) { if (!within(event.relatedTarget)) scheduleClose(); }
function splitPlacement(value) { const [side, align = 'center'] = value.split('-'); return { side, align: align === 'start' || align === 'end' ? align : 'center' }; }
function sideSpace(side, rect) { const edge = 4; return side === 'top' ? rect.top - edge : side === 'bottom' ? window.innerHeight - rect.bottom - edge : side === 'left' ? rect.left - edge : window.innerWidth - rect.right - edge; }
function positionCenterArrow(element, side, align, trigger, rect, left) {
  if (align !== 'center' || !['top', 'bottom'].includes(side)) {
    element.style.removeProperty('--popover-arrow-left');
    return;
  }
  const arrowWidth = parseFloat(getComputedStyle(element).getPropertyValue('--popover-arrow-width')) || 12;
  const arrowLeft = Math.max(0, Math.min(rect.width - arrowWidth, trigger.left + trigger.width / 2 - left - arrowWidth / 2));
  element.style.setProperty('--popover-arrow-left', `${arrowLeft}px`);
}
function updatePosition() {
  if (!shown.value || !root.value || !panel.value) return;
  const trigger = root.value.getBoundingClientRect(); const element = panel.value; const rect = element.getBoundingClientRect();
  const requested = splitPlacement(props.placement); let side = requested.side;
  const arrowHeight = parseFloat(getComputedStyle(element).getPropertyValue('--popover-arrow-height')) || 8;
  const arrowOverlap = parseFloat(getComputedStyle(element).getPropertyValue('--popover-arrow-overlap')) || 1;
  const triggerGap = parseFloat(getComputedStyle(element).getPropertyValue('--popover-trigger-gap')) || 4;
  const offset = arrowHeight - arrowOverlap + triggerGap;
  const required = (side === 'top' || side === 'bottom' ? rect.height : rect.width) + offset;
  const preferredSpace = sideSpace(side, trigger); const flippedSpace = sideSpace(opposite[side], trigger);
  if (preferredSpace < required && flippedSpace > preferredSpace) side = opposite[side];
  const align = requested.align; const edge = 4;
  let left; let top;
  if (side === 'top' || side === 'bottom') {
    left = align === 'start' ? trigger.left : align === 'end' ? trigger.right - rect.width : trigger.left + (trigger.width - rect.width) / 2;
    top = side === 'top' ? trigger.top - rect.height - offset : trigger.bottom + offset;
  } else {
    top = align === 'start' ? trigger.top : align === 'end' ? trigger.bottom - rect.height : trigger.top + (trigger.height - rect.height) / 2;
    left = side === 'left' ? trigger.left - rect.width - offset : trigger.right + offset;
  }
  left = Math.min(Math.max(edge, left), Math.max(edge, window.innerWidth - edge - rect.width));
  top = Math.min(Math.max(edge, top), Math.max(edge, window.innerHeight - edge - rect.height));
  element.dataset.placement = `${side}${align === 'center' ? '' : `-${align}`}`;
  element.style.setProperty('--popover-left', `${left}px`); element.style.setProperty('--popover-top', `${top}px`);
  positionCenterArrow(element, side, align, trigger, rect, left);
}
function onTriggerFocusIn() { cancelClose(); if (ignoreNextFocusOpen) { ignoreNextFocusOpen = false; return; } setOpen(true); }
function onKeydown(event) { if (event.key === 'Escape' && shown.value) { event.preventDefault(); ignoreNextFocusOpen = true; setOpen(false); nextTick(() => root.value?.querySelector('[tabindex],button,a,input,select,textarea')?.focus()); } }
onMounted(() => { document.addEventListener('keydown', onKeydown); window.addEventListener('resize', updatePosition); document.addEventListener('scroll', updatePosition, true); observer = new ResizeObserver(updatePosition); if (root.value) observer.observe(root.value); });
watch(panel, (node, previous) => {
  if (previous) observer?.unobserve(previous);
  if (node) observer?.observe(node);
  nextTick(updatePosition);
}, { flush: 'post' });
watch(() => [props.placement, props.disabled], () => { if (props.disabled) setOpen(false); else nextTick(updatePosition); });
onBeforeUnmount(() => { cancelClose(); document.removeEventListener('keydown', onKeydown); window.removeEventListener('resize', updatePosition); document.removeEventListener('scroll', updatePosition, true); observer?.disconnect(); });
</script>

<template>
  <span ref="root" class="wb-popover" :class="{ 'is-open': shown, 'is-disabled': disabled }" @pointerenter="cancelClose(); setOpen(true)" @pointerleave="scheduleClose" @focusin="onTriggerFocusIn" @focusout="onFocusOut">
    <slot name="trigger" v-bind="triggerSlotProps" />
  </span>
  <Teleport to="body">
    <section v-if="shown" :id="`${id}-popover`" ref="panel" class="wb-popover__panel" :class="{ 'has-title': title }" :aria-label="ariaLabel" @pointerenter="cancelClose" @pointerleave="scheduleClose" @focusin="cancelClose" @focusout="onFocusOut">
      <PopoverArrow class="wb-popover__arrow" />
      <h2 v-if="title" class="wb-popover__title">{{ title }}</h2>
      <div class="wb-popover__content"><slot /></div>
    </section>
  </Teleport>
</template>

<style>
.wb-popover { display: inline-flex; }
.wb-popover__panel { --popover-arrow-width: var(--wb-asset-wb-popover-arrow-width); --popover-arrow-height: var(--wb-asset-wb-popover-arrow-height); --popover-arrow-overlap: var(--wb-asset-wb-popover-arrow-overlap); --popover-trigger-gap: var(--wb-asset-wb-popover-trigger-gap); box-sizing: border-box; position: fixed; z-index: 40; top: var(--popover-top, -9999px); left: var(--popover-left, -9999px); width: max-content; max-width: min(var(--wb-asset-wb-popover-max-width), calc(100vw - 2 * var(--wb-spacing-component-xs))); padding: var(--wb-spacing-component-lg); border-radius: var(--wb-radius-md); background: var(--wb-color-surface-overlay); box-shadow: var(--wb-shadow-lg); color: var(--wb-color-text-primary); }
.wb-popover__title { margin: 0 0 var(--wb-spacing-component-sm); font-size: var(--wb-font-headline-s-font-size); font-weight: var(--wb-font-headline-s-font-weight); line-height: var(--wb-font-headline-s-line-height); letter-spacing: var(--wb-font-headline-s-letter-spacing); }
.wb-popover__content { font-size: var(--wb-font-body-m-font-size); font-weight: var(--wb-font-body-m-font-weight); line-height: var(--wb-font-body-m-line-height); letter-spacing: var(--wb-font-body-m-letter-spacing); }
.wb-popover__panel.has-title .wb-popover__content { color: var(--wb-color-text-secondary); }
.wb-popover__content :first-child { margin-top: 0; }.wb-popover__content :last-child { margin-bottom: 0; }
.wb-popover__arrow { position: absolute; display: block; width: var(--popover-arrow-width); height: var(--popover-arrow-height); overflow: visible; }
.wb-popover__panel[data-placement^='top'] .wb-popover__arrow { bottom: calc(-1 * var(--popover-arrow-height) + var(--popover-arrow-overlap)); }
.wb-popover__panel[data-placement^='bottom'] .wb-popover__arrow { top: calc(-1 * var(--popover-arrow-height) + var(--popover-arrow-overlap)); transform: rotate(180deg); }
.wb-popover__panel[data-placement^='left'] .wb-popover__arrow { right: calc(-1 * var(--popover-arrow-height) + var(--popover-arrow-overlap)); transform: rotate(-90deg); transform-origin: center; }
.wb-popover__panel[data-placement^='right'] .wb-popover__arrow { left: calc(-1 * var(--popover-arrow-height) + var(--popover-arrow-overlap)); transform: rotate(90deg); transform-origin: center; }
.wb-popover__panel[data-placement^='top'][data-placement$='-start'] .wb-popover__arrow, .wb-popover__panel[data-placement^='bottom'][data-placement$='-start'] .wb-popover__arrow { left: calc(var(--wb-spacing-component-lg) - var(--popover-arrow-width) / 2); }
.wb-popover__panel[data-placement^='top'][data-placement$='-end'] .wb-popover__arrow, .wb-popover__panel[data-placement^='bottom'][data-placement$='-end'] .wb-popover__arrow { right: calc(var(--wb-spacing-component-lg) - var(--popover-arrow-width) / 2); }
.wb-popover__panel[data-placement^='left'][data-placement$='-start'] .wb-popover__arrow { right: calc(-1 * var(--popover-arrow-height) + var(--popover-arrow-overlap)); top: calc(var(--wb-spacing-component-lg) - var(--popover-arrow-height) / 2); }
.wb-popover__panel[data-placement^='left'][data-placement$='-end'] .wb-popover__arrow { right: calc(-1 * var(--popover-arrow-height) + var(--popover-arrow-overlap)); top: auto; bottom: calc(var(--wb-spacing-component-lg) - var(--popover-arrow-height) / 2); }
.wb-popover__panel[data-placement^='right'][data-placement$='-start'] .wb-popover__arrow { left: calc(-1 * var(--popover-arrow-height) + var(--popover-arrow-overlap)); top: calc(var(--wb-spacing-component-lg) - var(--popover-arrow-height) / 2); }
.wb-popover__panel[data-placement^='right'][data-placement$='-end'] .wb-popover__arrow { left: calc(-1 * var(--popover-arrow-height) + var(--popover-arrow-overlap)); top: auto; bottom: calc(var(--wb-spacing-component-lg) - var(--popover-arrow-height) / 2); }
.wb-popover__panel[data-placement='top'] .wb-popover__arrow, .wb-popover__panel[data-placement='bottom'] .wb-popover__arrow { left: var(--popover-arrow-left, calc(50% - var(--popover-arrow-width) / 2)); }
.wb-popover__panel[data-placement='left'] .wb-popover__arrow, .wb-popover__panel[data-placement='right'] .wb-popover__arrow { top: calc(50% - var(--popover-arrow-height) / 2); }
</style>
