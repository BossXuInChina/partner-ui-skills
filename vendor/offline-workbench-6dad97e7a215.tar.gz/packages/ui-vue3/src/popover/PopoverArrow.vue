<template>
  <svg viewBox="0 0 12 8" aria-hidden="true">
    <path d="M0 0h12L7.6 5.9C6.8 7 5.2 7 4.4 5.9L0 0Z" />
  </svg>
</template>

<style scoped>
path { fill: var(--wb-color-surface-overlay); }
</style>
