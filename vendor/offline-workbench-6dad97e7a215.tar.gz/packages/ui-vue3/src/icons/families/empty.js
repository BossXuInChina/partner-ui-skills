import runtime from '../generated/runtime/empty.json' with { type: 'json' };
import compatibility from '../generated/compat/empty.json' with { type: 'json' };
import { createIconFamily } from '../iconRuntime.js';

export const emptyIcons = /* @__PURE__ */ createIconFamily(runtime, compatibility);
