import runtime from '../generated/runtime/system.json' with { type: 'json' };
import compatibility from '../generated/compat/system.json' with { type: 'json' };
import { createIconFamily } from '../iconRuntime.js';

export const systemIcons = /* @__PURE__ */ createIconFamily(runtime, compatibility);
