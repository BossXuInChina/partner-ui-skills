import runtime from '../generated/runtime/pedestal.json' with { type: 'json' };
import compatibility from '../generated/compat/pedestal.json' with { type: 'json' };
import { createIconFamily } from '../iconRuntime.js';

export const pedestalIcons = /* @__PURE__ */ createIconFamily(runtime, compatibility);
