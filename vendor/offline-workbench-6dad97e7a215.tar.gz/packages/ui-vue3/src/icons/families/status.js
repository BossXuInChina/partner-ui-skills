import runtime from '../generated/runtime/status.json' with { type: 'json' };
import compatibility from '../generated/compat/status.json' with { type: 'json' };
import { createIconFamily } from '../iconRuntime.js';

export const statusIcons = /* @__PURE__ */ createIconFamily(runtime, compatibility);
