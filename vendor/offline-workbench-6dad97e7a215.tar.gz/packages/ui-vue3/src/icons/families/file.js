import runtime from '../generated/runtime/file.json' with { type: 'json' };
import compatibility from '../generated/compat/file.json' with { type: 'json' };
import { createIconFamily } from '../iconRuntime.js';

export const fileIcons = /* @__PURE__ */ createIconFamily(runtime, compatibility);
