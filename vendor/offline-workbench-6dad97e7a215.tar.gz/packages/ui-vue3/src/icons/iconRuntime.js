import { createIconResolver } from './iconCore.js';

/** The compatibility overlay is transitional synchronous Studio display data, not runtime evidence. */
export function createIconFamily(runtime, compatibility) {
  const overlay = new Map(compatibility.icons.map((icon) => [icon.key, icon]));
  return {
    index: runtime,
    resolve: createIconResolver(runtime),
    manifest: {
      ...compatibility,
      icons: runtime.icons.map((icon) => ({ ...icon, ...overlay.get(icon.key) })),
    },
  };
}
