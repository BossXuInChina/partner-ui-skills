<script>
import { emptyIcons } from '../families/empty.js';

export default {
  inheritAttrs: false,
  emptyIconManifest: emptyIcons.manifest,
};
</script>

<script setup>
import { computed, useAttrs, watchEffect } from 'vue';
import { iconAttributes, reportIconError } from '../iconCore.js';
import { useIconAsset } from '../useIconAsset.js';
import { emptyAssets } from '../loaders/empty.js';

const props = defineProps({
  name: { type: String, default: '' },
  type: { type: String, default: 'no-data' },
  size: { type: [Number, String], default: undefined },
  label: { type: String, default: '' },
});

const attrs = useAttrs();
const iconByName = new Map(
  emptyIcons.index.icons.flatMap((icon) => [
    [icon.key, icon],
    [icon.alias, icon],
  ]),
);
const nativeSize = (value) => {
  const match = String(value).match(/^(\d+(?:\.\d+)?)(?:px)?$/);
  return match && Number(match[1]) > 0 ? Number(match[1]) : null;
};
const resolution = computed(() => {
  if (props.name) {
    const named = iconByName.get(props.name);
    if (!named) return { icon: null, error: `EMPTY_ICON_NOT_FOUND: ${props.name}` };
    if (props.size !== undefined && nativeSize(props.size) !== named.size) {
      return { icon: null, error: `EMPTY_ICON_SIZE_MISMATCH: ${props.name} (${props.size})` };
    }
    return { icon: named, error: null };
  }
  const requestedSize = props.size === undefined ? 120 : nativeSize(props.size);
  const icon = emptyIcons.index.icons.find(
    (item) => item.type === props.type && item.size === requestedSize,
  );
  return icon
    ? { icon, error: null }
    : { icon: null, error: `EMPTY_ICON_VARIANT_MISSING: ${props.type}/${props.size}` };
});
const icon = computed(() => resolution.value.icon);
const sourceIcon = computed(() => {
  if (!icon.value || props.name || icon.value.type === 'network-error') return icon.value;
  return emptyIcons.index.icons.find((item) => item.type === icon.value.type && item.size === 64);
});
const sourceNode = computed(
  () => emptyIcons.manifest.icons.find((item) => item.key === icon.value?.key)?.nodeId,
);
const {
  source,
  error: assetError,
  status: assetStatus,
} = useIconAsset(
  computed(() => sourceIcon.value?.assetFile),
  emptyAssets,
);
const error = computed(() => resolution.value.error || assetError.value);
watchEffect(() => reportIconError(error.value));
</script>

<template>
  <img
    v-if="icon"
    class="workbench-empty-icon"
    v-bind="iconAttributes(attrs)"
    :data-icon-key="icon?.key"
    :data-icon-alias="icon?.alias"
    :data-icon-error="error || undefined"
    :data-icon-loading="assetStatus === 'loading' ? 'true' : undefined"
    :data-icon-source-node="sourceNode"
    :src="source || undefined"
    :width="icon?.size"
    :height="icon?.size"
    :alt="label"
    :aria-hidden="label ? undefined : 'true'"
    :data-empty-type="icon?.type"
    :data-icon-size="icon?.size"
    draggable="false"
  />
</template>

<style scoped>
.workbench-empty-icon {
  display: inline-block;
  flex: none;
  vertical-align: middle;
  object-fit: contain;
  max-width: none;
}
</style>
