<script>
export default { inheritAttrs: false };
</script>

<script setup>
import { computed, watchEffect } from 'vue';
import { pedestalIcons } from '../families/pedestal.js';
import { nativeIconStyle, nativeSvgStyle, reportIconError } from '../iconCore.js';
import { useIconAsset } from '../useIconAsset.js';
import { pedestalAssets } from '../loaders/pedestal.js';

const props = defineProps({
  name: { type: String, required: true },
  label: { type: String, default: '' },
  size: { type: Number, default: undefined, validator: (value) => [28, 48].includes(value) },
});
const byName = new Map(
  pedestalIcons.index.icons.flatMap((icon) => [
    [icon.key, icon],
    [icon.alias, icon],
  ]),
);
const icon = computed(() => byName.get(props.name));
const sourceNode = computed(
  () => pedestalIcons.manifest.icons.find((item) => item.key === icon.value?.key)?.nodeId,
);
const {
  source,
  error: assetError,
  status: assetStatus,
} = useIconAsset(
  computed(() => icon.value?.assetFile),
  pedestalAssets,
);
const dimensions = computed(() => {
  if (!icon.value || ![28, 48].includes(props.size)) {
    return { ...nativeIconStyle(icon.value), ...nativeSvgStyle(icon.value) };
  }
  const size = `${props.size}px`;
  return {
    width: size, height: size, minWidth: size, maxWidth: size,
    minHeight: size, maxHeight: size, flexShrink: '0',
    '--workbench-icon-canvas-left': '0px', '--workbench-icon-canvas-top': '0px',
    '--workbench-icon-canvas-width': size, '--workbench-icon-canvas-height': size,
  };
});
const error = computed(() =>
  icon.value ? assetError.value : `PEDESTAL_ICON_NOT_FOUND: ${props.name}`,
);
watchEffect(() => reportIconError(error.value));
</script>

<template>
  <span
    v-if="icon"
    class="workbench-pedestal-icon"
    :data-icon-key="icon.key"
    :data-icon-alias="icon.alias"
    :data-icon-source-node="sourceNode"
    :data-icon-error="error || undefined"
    :data-icon-loading="assetStatus === 'loading' ? 'true' : undefined"
    :data-icon-size="size || icon.size"
    :data-icon-shape="icon.shape"
    :data-icon-tone="icon.tone"
    :style="dimensions"
    :role="label ? 'img' : undefined"
    :aria-label="label || undefined"
    :aria-hidden="label ? undefined : 'true'"
  >
    <img
      :src="source || undefined"
      :width="icon.exported.width"
      :height="icon.exported.height"
      alt=""
      aria-hidden="true"
      draggable="false"
    />
  </span>
</template>

<style scoped>
.workbench-pedestal-icon {
  position: relative;
  display: inline-flex;
  flex: none;
  vertical-align: middle;
}
.workbench-pedestal-icon img {
  position: absolute;
  display: block;
  left: var(--workbench-icon-canvas-left);
  top: var(--workbench-icon-canvas-top);
  width: var(--workbench-icon-canvas-width);
  height: var(--workbench-icon-canvas-height);
  max-width: none;
}
</style>
