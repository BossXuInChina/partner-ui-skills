const extensions = {
  pdf: 'pdf', zip: 'archive', rar: 'archive', '7z': 'archive',
  doc: 'word', docx: 'word', word: 'word', ppt: 'powerpoint', pptx: 'powerpoint',
  xls: 'excel', xlsx: 'excel', mp3: 'audio', mp4: 'video', txt: 'text', hdx: 'hdx',
  png: 'image', jpg: 'image', jpeg: 'image', tif: 'image', tiff: 'image',
};
const types = new Set(['pdf', 'archive', 'file', 'word', 'powerpoint', 'excel', 'audio', 'video', 'text', 'hdx', 'image', 'unknown']);
export function resolveFileIconType(value = '') {
  const name = String(value).toLowerCase().split(/[?#]/)[0];
  if (types.has(name)) return name;
  const extension = name.slice(name.lastIndexOf('.') + 1);
  return extensions[extension] ?? 'unknown';
}
