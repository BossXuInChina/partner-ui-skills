<script>
import { fileIcons } from '../families/file.js';
export default { inheritAttrs: false, fileIconManifest: fileIcons.manifest };
</script>

<script setup>
import { computed, useAttrs, watchEffect } from 'vue';
import { nativeIconStyle, iconAttributes, reportIconError } from '../iconCore.js';
import { useIconAsset } from '../useIconAsset.js';
import { fileAssets } from '../loaders/file.js';
import { resolveFileIconType } from './fileIconType.js';

const props = defineProps({
  name: { type: String, default: '' },
  type: { type: String, default: '' },
  filename: { type: String, default: '' },
  size: { type: [Number, String], default: undefined },
  label: { type: String, default: '' },
});
const attrs = useAttrs();
const type = computed(() => resolveFileIconType(props.type || props.filename));
const resolution = computed(() =>
  props.name
    ? fileIcons.resolve(props.name, props.size, 'file')
    : fileIcons.resolve(`${type.value}/${props.size ?? 32}`, undefined, 'file'),
);
const icon = computed(() => resolution.value.icon);
const iconType = computed(() => icon.value?.key.split('/')[0] ?? type.value);
const {
  source,
  error: assetError,
  status: assetStatus,
} = useIconAsset(
  computed(() => (icon.value ? `${iconType.value}-48.svg` : undefined)),
  fileAssets,
);
const error = computed(() => resolution.value.error || assetError.value);
watchEffect(() => reportIconError(error.value));
</script>

<template>
  <img
    class="workbench-file-icon"
    v-bind="iconAttributes(attrs)"
    :style="nativeIconStyle(icon)"
    :data-icon-key="icon?.key"
    :data-icon-alias="icon?.alias"
    :data-icon-error="error || undefined"
    :data-icon-loading="assetStatus === 'loading' ? 'true' : undefined"
    :src="source || undefined"
    :width="icon?.native.width"
    :height="icon?.native.height"
    :alt="label"
    :aria-hidden="label ? undefined : 'true'"
    :data-file-type="type"
    :data-icon-size="icon?.size"
    draggable="false"
  />
</template>

<style scoped>
.workbench-file-icon {
  display: inline-block;
  flex: none;
  vertical-align: middle;
  object-fit: contain;
}
</style>
