/** Coalesce concurrent imports, keep fulfilled payloads, and permit a fresh attempt after failure. */
export function createIconAssetLoader(modules, prefix = '') {
  const fulfilled = new Map();
  const pending = new Map();
  return {
    peek: (name) => fulfilled.get(name),
    load(name) {
      if (fulfilled.has(name)) return Promise.resolve(fulfilled.get(name));
      if (pending.has(name)) return pending.get(name);
      const request = Promise.resolve()
        .then(() => {
          const load = modules[prefix + name];
          if (!load) throw new Error('ICON_ASSET_NOT_FOUND: ' + name);
          return load();
        })
        .then((source) => {
          if (typeof source !== 'string' || !source) throw new Error('ICON_ASSET_INVALID: ' + name);
          fulfilled.set(name, source);
          return source;
        })
        .finally(() => pending.delete(name));
      pending.set(name, request);
      return request;
    },
  };
}
