import { createIconAssetLoader } from '../iconAssetLoader.js';

export const pedestalAssets = /* @__PURE__ */ createIconAssetLoader(
  import.meta.glob('../pedestal/assets/*.svg', { query: '?url', import: 'default' }),
  '../pedestal/assets/',
);
