import { createIconAssetLoader } from '../iconAssetLoader.js';

export const systemAssets = /* @__PURE__ */ createIconAssetLoader(
  import.meta.glob('../assets/*.svg', { query: '?raw', import: 'default' }),
  '../assets/',
);
