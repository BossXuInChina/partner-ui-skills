import { createIconAssetLoader } from '../iconAssetLoader.js';

export const fileAssets = /* @__PURE__ */ createIconAssetLoader(
  import.meta.glob('../file/assets/*-48.svg', { query: '?url', import: 'default' }),
  '../file/assets/',
);
