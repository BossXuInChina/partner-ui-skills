import { createIconAssetLoader } from '../iconAssetLoader.js';

export const statusAssets = /* @__PURE__ */ createIconAssetLoader(
  import.meta.glob('../status/assets/*.svg', { query: '?raw', import: 'default' }),
  '../status/assets/',
);
