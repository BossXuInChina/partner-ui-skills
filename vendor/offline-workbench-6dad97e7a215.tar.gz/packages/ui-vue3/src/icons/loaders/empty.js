import { createIconAssetLoader } from '../iconAssetLoader.js';

export const emptyAssets = /* @__PURE__ */ createIconAssetLoader(
  import.meta.glob('../empty/assets/*.svg', { query: '?url', import: 'default' }),
  '../empty/assets/',
);
