import { shallowRef, watch } from 'vue';

export function useIconAsset(assetFile, loader) {
  const source = shallowRef('');
  const error = shallowRef(null);
  const status = shallowRef('idle');
  watch(
    assetFile,
    (name, _previous, onCleanup) => {
      let current = true;
      onCleanup(() => {
        current = false;
      });
      error.value = null;
      source.value = name ? (loader.peek(name) ?? '') : '';
      status.value = source.value ? 'loaded' : name ? 'loading' : 'idle';
      if (!name || source.value) return;
      loader.load(name).then(
        (result) => {
          if (!current) return;
          source.value = result;
          status.value = 'loaded';
        },
        () => {
          if (!current) return;
          error.value = 'ICON_ASSET_LOAD_FAILED: ' + name;
          status.value = 'error';
        },
      );
    },
    { immediate: true, flush: 'sync' },
  );
  return { source, error, status };
}
