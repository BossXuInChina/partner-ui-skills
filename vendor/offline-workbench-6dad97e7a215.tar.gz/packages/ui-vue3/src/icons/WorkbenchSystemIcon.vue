<script>
import WorkbenchIcon from './WorkbenchIcon.vue';
import { systemIcons } from './families/system.js';

export default {
  inheritAttrs: false,
  components: { WorkbenchIcon },
  iconManifest: systemIcons.manifest,
};
</script>

<script setup>
const props = defineProps({
  name: { type: String, required: true },
  size: { type: [Number, String], default: undefined },
  color: { type: String, default: 'currentColor' },
  label: { type: String, default: '' },
});
</script>

<template>
  <WorkbenchIcon
    :name="props.name"
    :size="props.size"
    :color="props.color"
    :label="props.label"
  />
</template>
