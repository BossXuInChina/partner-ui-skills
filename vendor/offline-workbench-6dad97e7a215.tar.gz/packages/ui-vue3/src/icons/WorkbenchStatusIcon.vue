<script>
import { statusIcons } from './families/status.js';
export default { inheritAttrs: false, iconManifest: statusIcons.manifest };
</script>

<script setup>
import { computed, useId, watchEffect } from 'vue';
import { nativeIconStyle, nativeSvgStyle, reportIconError } from './iconCore.js';
import { useIconAsset } from './useIconAsset.js';
import { statusAssets } from './loaders/status.js';

// Status assets carry their original size and semantic paint. Unknown attributes,
// including width, height, class and style, are deliberately not forwarded.
// Legacy size only requests a separate registered native-size variant.
const props = defineProps({
  name: { type: String, required: true },
  size: { type: [Number, String], default: undefined },
  label: { type: String, default: '' },
});
const resolution = computed(() => statusIcons.resolve(props.name, props.size, 'status'));
const icon = computed(() => resolution.value.icon);
const {
  source: assetSource,
  error: assetError,
  status: assetStatus,
} = useIconAsset(
  computed(() => icon.value?.assetFile),
  statusAssets,
);
const error = computed(() => resolution.value.error || assetError.value);
watchEffect(() => reportIconError(error.value));
const prefix = `wb-status-${useId().replace(/[^a-zA-Z0-9_-]/g, '_')}-`;
const markup = computed(() => {
  const source = assetSource.value;
  if (!source) return '';
  const ids = new Map();
  for (const match of source.matchAll(/\bid="([^"]+)"/g)) {
    if (!ids.has(match[1])) ids.set(match[1], `${prefix}${ids.size}`);
  }
  return source
    .replace(/\bid="([^"]+)"/g, (match, id) => `id="${ids.get(id)}"`)
    .replace(/url\(#([^)]+)\)/g, (match, id) => `url(#${ids.get(id) ?? id})`)
    .replace(
      /((?:xlink:)?href=")#([^"]+)"/g,
      (match, attribute, id) => `${attribute}#${ids.get(id) ?? id}"`,
    );
});
const dimensions = computed(() => ({
  ...nativeIconStyle(icon.value),
  ...nativeSvgStyle(icon.value),
}));
</script>

<template>
  <span
    class="workbench-status-icon"
    :data-icon-key="icon?.key"
    :data-icon-alias="icon?.alias"
    :data-icon-native="icon ? `${icon.native.width}x${icon.native.height}` : undefined"
    :data-icon-error="error || undefined"
    :data-icon-loading="assetStatus === 'loading' ? 'true' : undefined"
    :style="dimensions"
    :role="label ? 'img' : undefined"
    :aria-label="label || undefined"
    :aria-hidden="label ? undefined : 'true'"
    v-html="markup"
  />
</template>

<style scoped>
.workbench-status-icon {
  position: relative;
  display: inline-flex;
  flex: none;
  vertical-align: middle;
}
.workbench-status-icon :deep(svg) {
  display: block;
  position: absolute !important;
  left: var(--workbench-icon-canvas-left) !important;
  top: var(--workbench-icon-canvas-top) !important;
  width: var(--workbench-icon-canvas-width) !important;
  height: var(--workbench-icon-canvas-height) !important;
  overflow: visible;
}
</style>
