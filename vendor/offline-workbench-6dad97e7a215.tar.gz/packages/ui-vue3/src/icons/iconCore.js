const positiveSize = (value) =>
  /^(?:\d+(?:\.\d+)?)(?:px)?$/.test(String(value)) && Number.parseFloat(value) > 0
    ? Number.parseFloat(value)
    : null;

export function createIconResolver(index) {
  const byName = new Map(
    index.icons.flatMap((icon) => [
      [`${icon.kind}:${icon.key}`, icon],
      ...(icon.alias ? [[`${icon.kind}:${icon.alias}`, icon]] : []),
    ]),
  );
  return (name, size, kind = 'system') => {
    const requestedIcon = byName.get(`${kind}:${name}`);
    if (!requestedIcon) return { icon: null, error: `ICON_NOT_FOUND: ${kind}:${name}` };
    const original = requestedIcon.replacementKey
      ? byName.get(`${kind}:${requestedIcon.replacementKey}`)
      : requestedIcon;
    if (!original) return { icon: null, error: `ICON_REPLACEMENT_NOT_FOUND: ${requestedIcon.key}` };
    const result = resolveNativeIcon(
      index,
      original,
      name,
      size,
      kind,
      Boolean(requestedIcon.replacementKey),
    );
    return requestedIcon.replacementKey ? { ...result, replacedKey: requestedIcon.key } : result;
  };
}

function resolveNativeIcon(index, original, name, size, kind, replacement) {
  if (original.native.status !== 'confirmed')
    return {
      icon: null,
      error: `ICON_NATIVE_SIZE_${original.native.status.toUpperCase()}: ${original.key}`,
    };
  if (size === undefined) return { icon: original, error: null };
  const requested = positiveSize(size);
  if (!requested) return { icon: null, error: `ICON_SIZE_NOT_NATIVE: ${name} (${size})` };
  if (original.native.width === requested && original.native.height === requested)
    return { icon: original, error: null };
  if (replacement || name === original.alias)
    return {
      icon: null,
      error: `ICON_${replacement ? 'REPLACEMENT' : 'ALIAS'}_SIZE_MISMATCH: ${name} (${size})`,
    };
  const candidates = index.icons.filter(
    (icon) =>
      icon.kind === kind &&
      icon.variantGroup === original.variantGroup &&
      icon.style === original.style &&
      icon.colorMode === original.colorMode &&
      icon.native.status === 'confirmed' &&
      icon.native.width === requested &&
      icon.native.height === requested,
  );
  if (candidates.length !== 1)
    return {
      icon: null,
      error: `ICON_NATIVE_VARIANT_${candidates.length ? 'AMBIGUOUS' : 'MISSING'}: ${name} (${size})`,
    };
  return { icon: candidates[0], error: null };
}

const reported = new Set();
export function reportIconError(error) {
  if (error && !reported.has(error)) {
    reported.add(error);
    console.warn(`[WorkbenchIcon] ${error}`);
  }
}
export function nativeIconStyle(icon) {
  if (!icon) return { width: '0px', height: '0px' };
  const width = `${icon.native.width}px !important`,
    height = `${icon.native.height}px !important`;
  return {
    width,
    height,
    minWidth: width,
    maxWidth: width,
    minHeight: height,
    maxHeight: height,
    flexShrink: '0',
  };
}

// Compiled records contain only the verified canvas result. Legacy fixtures retain their evidence path.
export function iconCanvas(icon) {
  if (icon.canvas) return icon.canvas;
  const width = icon.exported?.width ?? icon.native.width;
  const height = icon.exported?.height ?? icon.native.height;
  const viewBox = icon.sourceViewBox
    ?.trim()
    .split(/[\s,]+/)
    .map(Number);
  const frame = icon.native.evidence === 'registered-and-source-frame' ? icon.sourceFrame : null;
  if (
    !frame ||
    viewBox?.length !== 4 ||
    !viewBox.every(Number.isFinite) ||
    viewBox[2] <= 0 ||
    viewBox[3] <= 0
  )
    return { width, height, left: 0, top: 0 };
  const scale = Math.min(width / viewBox[2], height / viewBox[3]);
  return {
    width,
    height,
    left: -((width - viewBox[2] * scale) / 2 + (frame.x - viewBox[0]) * scale),
    top: -((height - viewBox[3] * scale) / 2 + (frame.y - viewBox[1]) * scale),
  };
}
export function nativeSvgStyle(icon) {
  if (!icon) return {};
  const canvas = iconCanvas(icon);
  return Object.fromEntries(
    Object.entries(canvas).map(([key, value]) => [`--workbench-icon-canvas-${key}`, `${value}px`]),
  );
}
export function iconAttributes(attrs) {
  return Object.fromEntries(
    Object.entries(attrs).filter(
      ([key]) => key === 'class' || key === 'id' || /^(?:aria-|data-)/.test(key),
    ),
  );
}
