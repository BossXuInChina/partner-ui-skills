<script setup lang="ts">
import type { PropType } from 'vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import { stepIcons } from './stepIcons.js';
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue';

export interface StepItem {
  key?: string | number;
  title: string;
  description?: string;
  status?: 'finish' | 'process' | 'wait' | 'error' | 'disabled' | 'unavailable' | 'available';
  disabled?: boolean;
  /** A pending step can explicitly allow navigation. */
  clickable?: boolean;
}
const props = defineProps({
  items: { type: Array as PropType<StepItem[]>, required: true },
  modelValue: { type: Number, default: 0 },
  current: Number,
  variant: { type: String as PropType<'horizontal' | 'vertical' | 'arrow'>, default: 'horizontal' },
  size: { type: String as PropType<'large' | 'medium' | 'small' | 'mini'>, default: 'medium' },
  nodeType: { type: String as PropType<'number' | 'icon'>, default: 'number' },
  readonly: { type: Boolean, default: true },
  disabled: { type: Boolean, default: false },
  ariaLabel: { type: String, default: '流程步骤' },
});
const emit = defineEmits(['update:modelValue', 'change']);
const viewport = ref<HTMLElement>();
const list = ref<HTMLOListElement>();
const canScrollBack = ref(false);
const canScrollForward = ref(false);
const overflow = computed(() => canScrollBack.value || canScrollForward.value);
const active = computed(() => props.modelValue >= 0 && props.modelValue < props.items.length ? props.modelValue : -1);
const progress = computed(() => props.current ?? props.modelValue);
const labels = { finish: '已完成', process: '进行中', wait: '未开始', error: '步骤异常', disabled: '无权限', unavailable: '不可操作', available: '可开始' };
function iconName(index: number) {
  const size = props.variant === 'arrow' || ['small', 'mini'].includes(props.size) ? '小尺寸' : props.size === 'large' ? '大尺寸' : '中尺寸';
  const states = { finish: '已完成', error: '异常图标', disabled: '无权限图标', unavailable: '未开始图标', available: '可开始图标', process: '进行中图标', wait: '未开始图标' };
  const status = states[statusAt(index)];
  const focus = props.variant === 'arrow' && statusAt(index) === 'finish'
    ? 'focus'
    : active.value === index ? 'focus' : 'default';
  return stepIcons[`${size}/${status}/${focus}`] ?? stepIcons[`${size}/${status}/default`];
}

function statusAt(index: number): NonNullable<StepItem['status']> {
  const item = props.items[index];
  if (!item || item.disabled || props.disabled) return 'disabled';
  return item.status ?? (index < progress.value ? 'finish' : index === progress.value ? 'process' : 'wait');
}
function navigable(index: number) {
  if (props.readonly || ['disabled', 'unavailable'].includes(statusAt(index))) return false;
  if (props.items[index].clickable === false) return false;
  return props.items[index].clickable === true || ['finish', 'process', 'error', 'available'].includes(statusAt(index));
}
const firstNavigable = computed(() => props.items.findIndex((_, index) => navigable(index)));
const focusIndex = ref(-1);
const tabStop = computed(() => navigable(focusIndex.value) ? focusIndex.value : navigable(active.value) ? active.value : firstNavigable.value);
function select(index: number) {
  if (!navigable(index) || active.value === index) return;
  emit('update:modelValue', index);
  emit('change', index, props.items[index]);
}
function onKeydown(event: KeyboardEvent, index: number) {
  const previous = props.variant === 'vertical' ? 'ArrowUp' : 'ArrowLeft';
  const next = props.variant === 'vertical' ? 'ArrowDown' : 'ArrowRight';
  if (![previous, next, 'Home', 'End'].includes(event.key)) return;
  event.preventDefault();
  const candidates = props.items.flatMap((_, i) => navigable(i) ? [i] : []);
  const position = candidates.indexOf(index);
  const target = event.key === 'Home' ? candidates[0] : event.key === 'End' ? candidates.at(-1) : candidates[position + (event.key === next ? 1 : -1)];
  if (target === undefined) return;
  const button = list.value?.querySelector<HTMLButtonElement>(`[data-step-index="${target}"] button`);
  button?.focus();
  button?.scrollIntoView({ block: 'nearest', inline: 'nearest' });
}
function measure() {
  const el = viewport.value;
  if (!el || props.variant === 'vertical') { canScrollBack.value = false; canScrollForward.value = false; return; }
  canScrollBack.value = el.scrollLeft > 1;
  canScrollForward.value = el.scrollLeft + el.clientWidth < el.scrollWidth - 1;
}
function scroll(direction: number) {
  const el = viewport.value;
  if (!el) return;
  const target = el.scrollLeft + direction * Math.ceil(el.clientWidth * 0.75);
  el.scrollTo({ left: Math.max(0, Math.min(target, el.scrollWidth - el.clientWidth)), behavior: 'auto' });
}
let observer: ResizeObserver | undefined;
onMounted(() => {
  observer = new ResizeObserver(measure);
  if (viewport.value) observer.observe(viewport.value);
  if (list.value) observer.observe(list.value);
  measure();
});
onBeforeUnmount(() => observer?.disconnect());
watch(() => [props.items, props.variant, props.size], async () => { await nextTick(); measure(); }, { deep: true });
</script>

<template>
  <div class="wb-steps" :class="[`wb-steps--${variant}`, `wb-steps--${size}`, { 'wb-steps--overflow': overflow }]">
    <button v-if="overflow" class="wb-steps__scroll" type="button" :disabled="!canScrollBack" aria-label="查看前面的步骤" @click="scroll(-1)"><WorkbenchIcon name="/ic_arrow_left_line#2:144" /></button>
    <div ref="viewport" class="wb-steps__viewport" @scroll.passive="measure">
      <ol ref="list" class="wb-steps__list" :aria-label="ariaLabel">
        <li v-for="(item, index) in items" :key="item.key ?? index" class="wb-steps__item" :class="[`wb-steps__item--${statusAt(index)}`, { 'wb-steps__item--selected': active === index }]" :data-step-index="index" :aria-current="active === index ? 'step' : undefined">
          <component :is="readonly ? 'div' : 'button'" class="wb-steps__content" :type="readonly ? undefined : 'button'" :disabled="readonly ? undefined : !navigable(index)" :tabindex="readonly ? undefined : (tabStop === index ? 0 : -1)" :aria-label="`${item.title}，${labels[statusAt(index)]}${item.description ? `，${item.description}` : ''}`" @focus="focusIndex = index" @click="select(index)" @keydown="onKeydown($event, index)">
            <span class="wb-steps__node" :class="{ 'wb-steps__node--full-icon': !(nodeType === 'number' && ['process', 'wait'].includes(statusAt(index))) && (size !== 'mini' || variant === 'arrow') }" aria-hidden="true">
              <slot name="icon" :item="item" :index="index" :status="statusAt(index)">
                <span v-if="(size !== 'mini' || variant === 'arrow') && nodeType === 'number' && ['process', 'wait'].includes(statusAt(index))" class="wb-steps__number">{{ index + 1 }}</span>
                <WorkbenchIcon v-else-if="size !== 'mini' || variant === 'arrow'" :name="iconName(index)" />
              </slot>
            </span>
            <span class="wb-steps__copy">
              <span class="wb-steps__title" :title="item.title"><slot name="title" :item="item" :index="index">{{ item.title }}</slot></span>
              <span v-if="item.description && variant !== 'arrow' && (size === 'large' || size === 'medium')" class="wb-steps__description" :title="item.description"><slot name="description" :item="item" :index="index">{{ item.description }}</slot></span>
            </span>
          </component>
          <span v-if="index < items.length - 1 && variant !== 'arrow'" class="wb-steps__line" aria-hidden="true" />
        </li>
      </ol>
    </div>
    <button v-if="overflow" class="wb-steps__scroll" type="button" :disabled="!canScrollForward" aria-label="查看后面的步骤" @click="scroll(1)"><WorkbenchIcon name="/ic_arrow_right_line#2:141" /></button>
  </div>
</template>

<style scoped>
.wb-steps {
  --node-size: var(--wb-asset-wb-steps-node-medium);
  --step-pitch: var(--wb-asset-wb-steps-pitch-medium);
  --copy-width: var(--wb-asset-wb-steps-copy-width);
  --node-gap: var(--wb-asset-wb-steps-gap);
  --step-ink: var(--wb-asset-wb-steps-ink);
  --step-muted: var(--wb-asset-wb-steps-muted);
  --step-fill: var(--wb-asset-wb-steps-fill);
  --step-error: var(--wb-asset-wb-steps-error);
  display: flex; align-items: flex-start; min-width: 0; color: var(--step-ink);
  font-family: inherit;
}
.wb-steps--large { --node-size: var(--wb-asset-wb-steps-node-large); --step-pitch: var(--wb-asset-wb-steps-pitch-large); }
.wb-steps--small { --node-size: var(--wb-asset-wb-steps-node-small); --step-pitch: var(--wb-asset-wb-steps-pitch-small); }
.wb-steps--mini { --node-size: var(--wb-asset-wb-steps-node-mini); --step-pitch: var(--wb-asset-wb-steps-pitch-small); --node-gap: var(--wb-asset-wb-steps-gap-mini); }
.wb-steps--overflow { column-gap: var(--wb-asset-wb-steps-overflow-safe-gap); }
.wb-steps__viewport { min-width: 0; flex: 1; overflow-x: auto; scrollbar-width: thin; padding-block: var(--wb-spacing-component-xs); margin-block: calc(0px - var(--wb-spacing-component-xs)); }
.wb-steps__list { display: flex; padding: 0; margin: 0; list-style: none; min-width: 100%; width: max-content; }
.wb-steps__item { display: flex; position: relative; flex: 1 0 min(var(--step-pitch), var(--copy-width)); min-width: 0; }
.wb-steps .wb-steps__list > .wb-steps__item { margin: 0; }
.wb-steps__item:last-child { flex: 0 0 auto; width: var(--copy-width); }
.wb-steps--horizontal .wb-steps__item:last-child .wb-steps__content { width: max-content; max-width: var(--copy-width); min-width: var(--node-size); margin-inline: auto; }
.wb-steps--horizontal .wb-steps__item:last-child .wb-steps__title, .wb-steps--horizontal .wb-steps__item:last-child .wb-steps__description { max-width: var(--copy-width); }
.wb-steps__content { position: relative; z-index: 1; display: flex; flex-direction: column; align-items: center; gap: var(--node-gap); width: var(--copy-width); padding: 0; border: 0; margin: 0; background: transparent; color: inherit; font: inherit; text-align: center; box-sizing: border-box; }
button.wb-steps__content { cursor: pointer; }
button.wb-steps__content:disabled { cursor: default; }
.wb-steps__node { position: relative; display: grid; place-items: center; flex: 0 0 var(--node-size); width: var(--node-size); height: var(--node-size); box-sizing: border-box; border: var(--wb-asset-wb-steps-line-width) solid currentColor; border-radius: var(--wb-radius-full); background: var(--step-fill); color: var(--step-ink); }
.wb-steps__node--full-icon { border: 0; }
.wb-steps__number { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; text-align: center; font-variant-numeric: lining-nums tabular-nums; font-size: var(--wb-font-body-s-font-size); font-weight: var(--wb-font-body-s-font-weight); line-height: var(--wb-font-body-s-line-height); letter-spacing: var(--wb-font-body-s-letter-spacing); }
.wb-steps--large:not(.wb-steps--arrow) .wb-steps__number { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; text-align: center; font-variant-numeric: lining-nums tabular-nums; font-size: var(--wb-font-body-l-font-size); font-weight: var(--wb-font-body-l-font-weight); line-height: var(--wb-font-body-l-line-height); letter-spacing: var(--wb-font-body-l-letter-spacing); }
.wb-steps__copy { display: flex; flex-direction: column; min-width: 0; width: 100%; }
.wb-steps__title { display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: var(--wb-font-headline-xs-font-size); line-height: var(--wb-font-headline-xs-line-height); font-weight: var(--wb-font-headline-xs-font-weight); letter-spacing: var(--wb-font-headline-xs-letter-spacing); }
.wb-steps__description { display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; overflow-wrap: anywhere; color: var(--wb-asset-wb-steps-secondary); font-size: var(--wb-font-body-s-font-size); line-height: var(--wb-font-body-s-line-height); font-weight: var(--wb-font-body-s-font-weight); letter-spacing: var(--wb-font-body-s-letter-spacing); }
.wb-steps--small .wb-steps__title, .wb-steps--mini .wb-steps__title { font-size: var(--wb-font-headline-xxs-font-size); line-height: var(--wb-font-headline-xxs-line-height); font-weight: var(--wb-font-headline-xxs-font-weight); letter-spacing: var(--wb-font-headline-xxs-letter-spacing); }
.wb-steps__line { position: absolute; top: calc(var(--node-size) / 2); left: calc((var(--copy-width) + var(--node-size)) / 2 + var(--node-gap)); right: calc((var(--node-size) - var(--copy-width)) / 2 + var(--node-gap)); height: var(--wb-asset-wb-steps-line-width); background: var(--wb-asset-wb-steps-line-muted); }
.wb-steps__item--finish .wb-steps__line { background: var(--wb-asset-wb-steps-line-finish); }
.wb-steps__item--wait, .wb-steps__item--disabled, .wb-steps__item--unavailable { color: var(--wb-asset-wb-steps-secondary); }
.wb-steps__item--wait .wb-steps__node, .wb-steps__item--disabled .wb-steps__node, .wb-steps__item--unavailable .wb-steps__node { color: var(--wb-asset-wb-steps-placeholder); border-color: var(--wb-asset-wb-steps-border-muted); }
.wb-steps__item--wait .wb-steps__description, .wb-steps__item--disabled .wb-steps__description, .wb-steps__item--unavailable .wb-steps__description { color: inherit; }
.wb-steps__item--error .wb-steps__node:not(.wb-steps__node--full-icon) { color: var(--step-error); background: var(--wb-asset-wb-steps-error-fill); }
.wb-steps:not(.wb-steps--arrow) .wb-steps__item--selected:not(.wb-steps__item--wait):not(.wb-steps__item--disabled):not(.wb-steps__item--unavailable):not(.wb-steps__item--error) .wb-steps__node:not(.wb-steps__node--full-icon) { color: var(--wb-asset-wb-steps-inverse); border-color: var(--step-ink); background: var(--step-ink); }
.wb-steps:not(.wb-steps--mini) .wb-steps__item--selected.wb-steps__item--error .wb-steps__node { border-color: var(--step-error); background: transparent; }
.wb-steps__content:focus-visible { outline: none; }
.wb-steps__content:focus-visible .wb-steps__node { box-shadow: 0 0 0 var(--wb-asset-wb-steps-focus-width) var(--wb-asset-wb-steps-focus-color); }
.wb-steps--mini .wb-steps__node { background: currentColor; }
.wb-steps--mini .wb-steps__item--selected .wb-steps__node { color: var(--step-ink); }
.wb-steps--mini .wb-steps__item--error .wb-steps__node:not(.wb-steps__node--full-icon) { color: var(--step-error); background: currentColor; }
.wb-steps--vertical .wb-steps__list { flex-direction: column; width: 100%; }
.wb-steps--vertical .wb-steps__item { flex: none; min-height: var(--wb-asset-wb-steps-vertical-medium); padding-bottom: var(--node-gap); }
.wb-steps--vertical.wb-steps--large .wb-steps__item { min-height: var(--wb-asset-wb-steps-vertical-large); }
.wb-steps--vertical.wb-steps--small .wb-steps__item, .wb-steps--vertical.wb-steps--mini .wb-steps__item { min-height: var(--wb-asset-wb-steps-vertical-small); }
.wb-steps--vertical .wb-steps__item:last-child { min-height: 0; padding-bottom: 0; width: 100%; }
.wb-steps--vertical .wb-steps__content { flex-direction: row; align-items: flex-start; gap: var(--node-gap); width: 100%; text-align: left; }
.wb-steps--vertical.wb-steps--large .wb-steps__content { gap: var(--wb-asset-wb-steps-gap-large); }
.wb-steps--vertical .wb-steps__copy { max-width: var(--wb-asset-wb-steps-vertical-copy-width); }
.wb-steps--vertical .wb-steps__line { top: calc(var(--node-size) + var(--node-gap)); bottom: var(--node-gap); left: calc(var(--node-size) / 2); right: auto; width: var(--wb-asset-wb-steps-line-width); height: auto; }
.wb-steps--arrow { --node-size: var(--wb-asset-wb-steps-node-small); }
.wb-steps--arrow .wb-steps__list { gap: var(--wb-asset-wb-steps-arrow-gap); }
.wb-steps--arrow .wb-steps__item, .wb-steps--arrow .wb-steps__item:last-child { flex: 1 0 var(--wb-asset-wb-steps-arrow-width); }
.wb-steps--arrow .wb-steps__content { width: 100%; flex-direction: row; justify-content: center; height: var(--wb-asset-wb-steps-arrow-height); gap: var(--wb-asset-wb-steps-gap); padding-inline: var(--wb-asset-wb-steps-arrow-padding); background: var(--step-fill); clip-path: polygon(0 0, calc(100% - var(--wb-asset-wb-steps-arrow-tip)) 0, 100% 50%, calc(100% - var(--wb-asset-wb-steps-arrow-tip)) 100%, 0 100%, var(--wb-asset-wb-steps-arrow-tip) 50%); }
.wb-steps--arrow .wb-steps__item:first-child .wb-steps__content { clip-path: polygon(0 0, calc(100% - var(--wb-asset-wb-steps-arrow-tip)) 0, 100% 50%, calc(100% - var(--wb-asset-wb-steps-arrow-tip)) 100%, 0 100%); }
.wb-steps--arrow .wb-steps__item:last-child .wb-steps__content { clip-path: polygon(0 0, 100% 0, 100% 100%, 0 100%, var(--wb-asset-wb-steps-arrow-tip) 50%); }
.wb-steps--arrow .wb-steps__copy { width: auto; }
.wb-steps--arrow .wb-steps__node:not(.wb-steps__node--full-icon) { color: var(--wb-asset-wb-steps-inverse); border: 0; background: var(--step-ink); }
.wb-steps--arrow .wb-steps__item--selected .wb-steps__content { color: var(--wb-asset-wb-steps-inverse); background: var(--step-ink); }
.wb-steps.wb-steps--arrow .wb-steps__item--selected:not(.wb-steps__item--error) .wb-steps__node:not(.wb-steps__node--full-icon) { color: var(--step-ink); background: var(--wb-asset-wb-steps-inverse); }
.wb-steps--arrow .wb-steps__item--error .wb-steps__content { color: var(--step-error); background: var(--wb-asset-wb-steps-error-fill); }
.wb-steps--arrow .wb-steps__item--error .wb-steps__node:not(.wb-steps__node--full-icon) { color: var(--wb-asset-wb-steps-inverse); background: transparent; }
.wb-steps--arrow .wb-steps__item--wait .wb-steps__node:not(.wb-steps__node--full-icon), .wb-steps--arrow .wb-steps__item--disabled .wb-steps__node:not(.wb-steps__node--full-icon), .wb-steps--arrow .wb-steps__item--unavailable .wb-steps__node:not(.wb-steps__node--full-icon) { color: var(--wb-asset-wb-steps-inverse); background: var(--step-muted); }
.wb-steps--arrow .wb-steps__content:focus-visible { box-shadow: inset 0 0 0 var(--wb-asset-wb-steps-focus-width) var(--wb-asset-wb-steps-focus-color); }
.wb-steps__scroll { flex: none; display: grid; place-items: center; padding: 0; width: var(--wb-asset-wb-steps-scroll-size); height: var(--wb-asset-wb-steps-scroll-size); border: 0; border-radius: var(--wb-radius-full); background: var(--step-fill); color: var(--step-ink); font: inherit; cursor: pointer; }
.wb-steps__scroll:disabled { color: var(--step-muted); cursor: default; }
.wb-steps__scroll:focus-visible { outline: var(--wb-asset-wb-steps-focus-width) solid var(--wb-asset-wb-steps-focus-color); }
.wb-steps .wb-steps__node--full-icon { border: 0; background: transparent; }
</style>
