<script setup>
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import { computed, onBeforeUnmount, ref, useId, watch } from 'vue';
import WorkbenchButton from '../button/WorkbenchButton.vue';
import WorkbenchModal from '../modal/WorkbenchModal.vue';
import WorkbenchCheckbox from '../choice/WorkbenchCheckbox.vue';
import WorkbenchStatusIcon from '../icons/WorkbenchStatusIcon.vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';

const statusIconSemantics = {
  info: 'info',
  success: 'success',
  warning: 'warning',
  danger: 'alert-orange',
  critical: 'alert-red',
  error: 'close_circle',
};

const props = defineProps({
  modelValue: { type: Boolean, default: false },
  type: { type: String, default: 'info', validator: value => ['info', 'success', 'warning', 'danger', 'critical', 'error'].includes(value) },
  title: { type: String, required: true },
  message: { type: String, required: true },
  showIcon: { type: Boolean, default: true },
  checkboxLabel: { type: String, default: '' },
  checkboxChecked: { type: Boolean, default: false },
  primaryAction: { type: Object, required: true },
  secondaryAction: { type: Object, default: null },
  pending: { type: Boolean, default: false },
  actionHandler: { type: Function, default: undefined },
  beforeClose: { type: Function, default: undefined },
  showGrid: { type: Boolean, default: false },
});

const messageId = `wb-feedback-message-${useId()}`;
const statusIconName = computed(() => `${statusIconSemantics[props.type]}/solid/16`);
const emit = defineEmits(['update:modelValue', 'update:checkboxChecked', 'action', 'close', 'action-error', 'close-error']);

const working = ref(false);
let operation = 0;
watch(() => props.modelValue, () => { operation += 1; working.value = false; }, { flush: 'sync' });
onBeforeUnmount(() => { operation += 1; });
async function invokeAction(action, requestClose) {
  if (!action || action.disabled || working.value || props.pending) return;
  working.value = true;
  const currentOperation = ++operation;
  try {
    emit('action', action.id);
    if (await props.actionHandler?.(action) === false || currentOperation !== operation || !props.modelValue) return;
    await requestClose('action');
  } catch (error) { if (currentOperation === operation && props.modelValue) emit('action-error', { action, error }); }
  finally { if (currentOperation === operation) working.value = false; }
}
async function guardClose(reason) {
  if (props.pending || (working.value && reason !== 'action')) return false;
  const currentOperation = operation;
  try {
    const allowed = props.beforeClose ? await props.beforeClose(reason) : true;
    return allowed !== false && currentOperation === operation && props.modelValue && !props.pending;
  } catch (error) {
    if (currentOperation === operation && props.modelValue) emit('close-error', error);
    return false;
  }
}
</script>

<template>
  <WorkbenchModal
    :model-value="modelValue"
    :title="title"
    :aria-describedby="messageId"
    size="s"
    :close-on-mask="false"
    :close-on-esc="false"
    :before-close="guardClose"
    :show-grid="showGrid"
    @update:model-value="emit('update:modelValue', $event)"
    @close="emit('close', $event)"
  >
    <template #close-icon>
      <WorkbenchIcon name="/ic_public_close_line_14px" />
    </template>
    <div
      :id="messageId" class="feedback-dialog__message" :aria-busy="working || pending"
      :class="[`feedback-dialog__message--${type}`, { 'feedback-dialog__message--with-icon': showIcon }]"
      :data-feedback-type="type"
    >
      <span v-if="showIcon" class="feedback-dialog__status-icon" :data-status-icon="statusIconName" aria-hidden="true"><WorkbenchStatusIcon :name="statusIconName" /></span>
      {{ message }}
    </div>
    <template #footer="{ requestClose }">
      <div class="feedback-dialog__actions" :class="{ 'feedback-dialog__actions--with-icon': showIcon }">
        <WorkbenchCheckbox
          v-if="checkboxLabel"
          class="feedback-dialog__checkbox"
          :disabled="working || pending"
          :model-value="checkboxChecked"
          :label="checkboxLabel"
          @update:model-value="emit('update:checkboxChecked', $event)"
        />
        <div class="feedback-dialog__buttons">
          <WorkbenchButton
            v-if="secondaryAction"
            appearance="secondary"
            :disabled="secondaryAction.disabled || working || pending"
            @click="invokeAction(secondaryAction, requestClose)"
          >{{ secondaryAction.label }}</WorkbenchButton>
          <WorkbenchButton
            :disabled="primaryAction.disabled || working || pending"
            @click="invokeAction(primaryAction, requestClose)"
          >{{ primaryAction.label }}</WorkbenchButton>
        </div>
      </div>
    </template>
  </WorkbenchModal>
</template>

<style>
.wb-modal:has(.feedback-dialog__message--with-icon) .wb-modal__header {
  display: grid;
  grid-template-columns: var(--wb-asset-wb-feedback-dialog-status-icon-size) minmax(0, 1fr) auto;
  align-items: center;
  gap: var(--wb-spacing-component-sm);
}

.wb-modal:has(.feedback-dialog__message--with-icon) .wb-modal__header::before,
.wb-modal:has(.feedback-dialog__message--with-icon) .wb-modal__header::after {
  width: var(--wb-asset-wb-feedback-dialog-status-icon-size);
  height: var(--wb-asset-wb-feedback-dialog-status-icon-size);
  grid-area: 1 / 1;
  align-self: center;
}

.wb-modal:has(.feedback-dialog__message--with-icon) .wb-modal__title,
.wb-modal:has(.feedback-dialog__message--with-icon) .wb-modal__close {
  align-self: center;
}

.wb-modal:has(.feedback-dialog__message--with-icon) .wb-modal__header::before {
  content: '';
}

.wb-modal:has(.feedback-dialog__message--with-icon) .feedback-dialog__status-icon {
  position: absolute;
  z-index: 1;
  inset-block-start: calc(var(--wb-spacing-layout-container-block) + (var(--wb-font-headline-s-line-height) - var(--wb-asset-wb-feedback-dialog-status-icon-size)) / 2);
  inset-inline-start: var(--wb-spacing-layout-container-inline);
  display: flex;
  width: var(--wb-asset-wb-feedback-dialog-status-icon-size);
  height: var(--wb-asset-wb-feedback-dialog-status-icon-size);
  align-items: center;
}

.feedback-dialog__message {
  color: var(--wb-color-text-secondary);
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
  white-space: pre-line;
}

.feedback-dialog__actions {
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: var(--wb-spacing-component-lg);
}

.feedback-dialog__message--with-icon,
.feedback-dialog__actions--with-icon {
  padding-inline-start: calc(var(--wb-asset-wb-feedback-dialog-status-icon-size) + var(--wb-spacing-component-sm));
}

.wb-modal:has(.feedback-dialog__message) .wb-modal__close {
  display: flex;
  align-items: center;
  justify-content: center;

}

.wb-modal:has(.feedback-dialog__message--with-icon) .wb-modal__close {
  width: auto;
  height: auto;
  flex-basis: auto;
}



.feedback-dialog__checkbox { min-width: 0; align-self: center; }
.feedback-dialog__buttons { display: flex; flex: none; align-items: center; justify-content: flex-end; gap: var(--wb-spacing-component-sm); margin-inline-start: auto; }
</style>
