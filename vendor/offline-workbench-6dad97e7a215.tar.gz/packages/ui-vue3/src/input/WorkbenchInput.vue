<script setup>
import { useFormDisabled } from '../form/useFormDisabled.js';
import { useFieldControl } from '../form/fieldContext.js';
import SearchFilter from '../search/SearchFilter.vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import '../../../../catalog/generated/asset.tokens.css';
import '../scrollbar/scrollbar.css';
import { computed, ref, useId, watch, watchEffect, onBeforeUnmount } from 'vue';
const props = defineProps({
  modelValue: { type: String, default: '' },
  type: { type: String, default: 'text' },
  size: { type: String, default: '32', validator: (value) => ['28', '32'].includes(value) },
  placeholder: { type: String, default: '请输入' },
  resizable: { type: Boolean, default: true },
  required: Boolean,
  disabled: Boolean,
  name: String,
  ariaLabel: String,
  state: { type: String, default: 'default' },
  maxLength: Number,
  validate: Function,
  prefixValue: String,
  prefixPlaceholder: String,
  prefixOptions: { type: Array, default: () => [] },
  prefixDisabled: Boolean,
  showPrefixIcon: { type: Boolean, default: true },
  suffixDisabled: Boolean,
  showSuffixIcon: { type: Boolean, default: true },
  unit: String,
  unitFilterLabel: { type: String, default: '筛选' },
  unitOptions: { type: Array, default: () => [] },
  showTrailingIcon: Boolean,
});
const emit = defineEmits(['update:modelValue', 'update:unit', 'update:prefixValue', 'validation']);
const hasPrefix = computed(
  () => props.prefixOptions.length > 0 || Boolean(props.prefixPlaceholder),
);
const id = useId();
const native = ref(null);
const visible = ref(false);
const touched = ref(false);
const error = ref('');
const composing = ref(false);
const disabled = useFormDisabled(() => props.disabled || props.state === 'disabled');
const {
  field,
  attrs: fieldAttrs,
  required: controlRequired,
  invalid: fieldInvalid,
} = useFieldControl(() => props.modelValue, {
  id,
  nativeRequired: true,
  named: () => props.ariaLabel,
  required: () => props.required,
  invalid: () => !!message.value,
  focus: () => native.value?.focus(),
  validate: () => reason(native.value?.value ?? props.modelValue),
  reset: () => {
    touched.value = false;
    error.value = '';
  },
});
const count = computed(() => Array.from(props.modelValue).length);
const over = computed(() => props.maxLength != null && count.value > props.maxLength);
function reason(value) {
  if (disabled.value) return '';
  return (
    (props.state === 'error' ? '输入内容不符合要求' : '') ||
    (!field && controlRequired.value && !value.trim()
      ? '请输入必填内容'
      : props.maxLength != null && Array.from(value).length > props.maxLength
        ? `最多建议输入${props.maxLength}个字符`
        : props.validate?.(value) || '')
  );
}
const message = computed(() =>
  disabled.value ? '' : props.state === 'error' ? '输入内容不符合要求' : error.value,
);
function check(value = props.modelValue) {
  error.value = reason(value);
  const message = validityMessage(error.value);
  native.value?.setCustomValidity(message);
  emit('validation', { valid: !message, message });
  return !message;
}
function validityMessage(inputError) {
  if (disabled.value) return '';
  return field?.invalid.value ? field.feedback.value || inputError || '内容不符合要求' : inputError;
}
function input(event) {
  if (composing.value || event.isComposing) {
    event.stopPropagation();
    return;
  }
  emit('update:modelValue', event.target.value);
  native.value?.setCustomValidity(reason(event.target.value));
  if (touched.value) check(event.target.value);
}
function compositionEnd(event) {
  composing.value = false;
  input(event);
}
function blur() {
  if (!disabled.value && !composing.value) {
    touched.value = true;
    check(native.value?.value ?? props.modelValue);
  }
}
function validate() {
  touched.value = true;
  field?.validate('submit');
  return check(native.value?.value ?? props.modelValue);
}
watch(
  [
    () => props.modelValue,
    () => props.state,
    disabled,
    () => props.required,
    () => props.maxLength,
    () => props.validate,
  ],
  () => {
    if (touched.value && !composing.value) check();
  },
);
watchEffect(() => {
  if (native.value && !composing.value)
    native.value.setCustomValidity(validityMessage(reason(props.modelValue)));
});
// Measure the reserved native gutter; it is part of the 12px end inset.
let gutterObserver;
watch(
  native,
  (element) => {
    gutterObserver?.disconnect();
    if (!element || element.tagName !== 'TEXTAREA') return;
    const measure = () =>
      element.style.setProperty(
        '--input-scrollbar-gutter',
        `${element.offsetWidth - element.clientWidth}px`,
      );
    gutterObserver = new ResizeObserver(measure);
    gutterObserver.observe(element);
    measure();
  },
  { flush: 'post' },
);
onBeforeUnmount(() => gutterObserver?.disconnect());
defineExpose({ validate, focus: () => native.value?.focus() });
</script>
<template>
  <div
    class="wb-input"
    :class="[
      `is-${state}`,
      `wb-input--size-${size}`,
      { 'is-disabled': disabled, 'has-error': field ? fieldInvalid : !!message },
    ]"
  >
    <div class="wb-input__body">
      <div class="wb-input__row">
        <div
          class="wb-input__shell wb-search"
          :class="[
            `is-${state}`,
            {
              'is-disabled': disabled,
              'wb-search--filter-both': hasPrefix && unitOptions.length,
              'wb-search--filter-prefix': hasPrefix,
              'wb-search--filter-suffix': unitOptions.length,
            },
          ]"
        >
          <SearchFilter
            v-if="hasPrefix && type !== 'textarea'"
            side="prefix"
            :filter-value="prefixValue"
            :filter-placeholder="prefixPlaceholder"
            :filter-options="prefixOptions"
            :disabled="disabled || prefixDisabled || !prefixOptions.length"
            :show-icon="showPrefixIcon"
            :preview-state="state"
            @update:filter-value="emit('update:prefixValue', $event)"
            ><template #filter-icon
              ><slot name="prefix-icon"><WorkbenchIcon name="文件夹_14px" /></slot></template
          ></SearchFilter>
          <div
            class="wb-input__control"
            :class="{
              'wb-input__control--multiline': type === 'textarea',
              'is-resizable': type === 'textarea' && resizable && !disabled,
            }"
          >
            <textarea
              v-if="type === 'textarea'"
              :id="id"
              ref="native"
              :name="name"
              :aria-label="ariaLabel || undefined"
              class="wb-input__native wb-scrollbar"
              :value="modelValue"
              :placeholder="placeholder"
              :disabled="disabled"
              :required="controlRequired"
              :aria-invalid="!!message"
              v-bind="fieldAttrs"
              rows="3"
              @input="input"
              @blur="blur"
              @invalid="validate"
              @compositionstart="composing = true"
              @compositionend="compositionEnd"
            />
            <input
              v-else
              :id="id"
              ref="native"
              :name="name"
              :aria-label="ariaLabel || undefined"
              class="wb-input__native"
              :type="type === 'password' && !visible ? 'password' : 'text'"
              :value="modelValue"
              :placeholder="placeholder"
              :disabled="disabled"
              :required="controlRequired"
              :aria-invalid="!!message"
              v-bind="fieldAttrs"
              @input="input"
              @blur="blur"
              @invalid="validate"
              @compositionstart="composing = true"
              @compositionend="compositionEnd"
            />
            <span
              v-if="type === 'textarea' && maxLength != null"
              class="wb-input__counter"
              ><span :class="{ 'is-over': over && !disabled }">{{ count }}</span> /
              {{ maxLength }}</span
            >
            <button
              v-if="type === 'password'"
              type="button"
              class="wb-input__icon-button"
              :disabled="disabled"
              :aria-label="visible ? '隐藏密码' : '显示密码'"
              :aria-pressed="visible"
              @click="visible = !visible"
            >
              <WorkbenchIcon
                :name="visible ? '可见不可见/可见=off_14px' : '可见不可见/可见=on_14px'"
              />
            </button>
            <span
              v-else-if="type !== 'textarea' && showTrailingIcon"
              class="wb-input__trailing"
              aria-hidden="true"
              ><slot name="trailing-icon"><WorkbenchIcon name="默认/类型=单图标_14px" /></slot
            ></span>
          </div>
          <SearchFilter
            v-if="unitOptions.length && type !== 'textarea'"
            side="suffix"
            :filter-label="unitFilterLabel"
            :filter-value="unit"
            :filter-options="unitOptions"
            :disabled="disabled || suffixDisabled"
            :show-icon="showSuffixIcon"
            :preview-state="state"
            @update:filter-value="emit('update:unit', $event)"
            ><template #filter-icon
              ><slot name="suffix-icon"><WorkbenchIcon name="文件夹_14px" /></slot></template
          ></SearchFilter>
        </div>
        <span
          v-if="unit && !unitOptions.length"
          class="wb-input__unit"
          >{{ unit }}</span
        >
      </div>
    </div>
  </div>
</template>
<style src="../search/search.css"></style>
<style>
.wb-input {
  display: flex;
  flex-direction: column;
  gap: var(--wb-spacing-component-sm);
  color: var(--wb-color-text-primary);
  font-size: var(--wb-font-body-m-font-size);
  line-height: var(--wb-font-body-m-line-height);
  font-weight: var(--wb-font-body-m-font-weight);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
}
.wb-input__counter .is-over {
  color: var(--wb-color-error);
}
.wb-input__body {
  flex: 1;
  min-width: 0;
}
.wb-input__row {
  display: flex;
  align-items: center;
  gap: var(--wb-spacing-component-sm);
}
.wb-input__shell {
  min-width: 0;
  flex: 1;
}
.wb-input--size-28 {
  --input-control-height: var(--wb-asset-wb-input-height-compact);
}
.wb-input__shell.wb-search--filter-prefix .wb-input__control {
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
}
.wb-input__shell.wb-search--filter-suffix .wb-input__control {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}
.wb-input__control {
  position: relative;
  display: flex;
  align-items: center;
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  height: var(--input-control-height, var(--wb-asset-wb-input-height));
  padding-inline: var(--wb-spacing-component-md);
  border: 1px solid var(--wb-color-border);
  border-radius: var(--wb-radius-sm);
  background: var(--wb-color-fill-subtle-default);
}
.wb-input__native {
  width: 100%;
  min-width: 0;
  flex: 1;
  padding: 0;
  border: 0;
  outline: 0;
  color: inherit;
  background: transparent;
  font: inherit;
}
.wb-input__native::placeholder {
  color: var(--wb-color-text-placeholder);
  opacity: 1;
}
.wb-input__control:hover,
.wb-input.is-hover .wb-input__control {
  border-color: var(--wb-color-border-hover);
}
.wb-input__control:focus-within,
.wb-input.is-focus .wb-input__control {
  border-color: var(--wb-color-border-focus);
}
.wb-input.has-error .wb-input__control {
  border-color: var(--wb-color-error);
}
.wb-input__control--multiline {
  height: var(--wb-asset-wb-input-multiline-height);
  position: relative;
  flex-direction: column;
  align-items: stretch;
  padding: var(--wb-spacing-component-xs) 0 var(--wb-asset-wb-input-counter-bottom)
    var(--wb-spacing-component-md);
}
.wb-input__control--multiline .wb-input__native {
  flex: 1;
  min-height: 0;
  resize: none;
  overflow-y: auto;
  scrollbar-gutter: stable;
  box-sizing: border-box;
  padding-right: calc(var(--wb-spacing-component-md) - var(--input-scrollbar-gutter, 0));
}
.wb-input__counter {
  flex: none;
  margin-right: var(--wb-spacing-component-md);
  pointer-events: none;
  text-align: right;
  color: var(--wb-color-text-secondary);
  font-size: var(--wb-font-body-s-font-size);
  font-weight: var(--wb-font-body-s-font-weight);
  line-height: var(--wb-asset-wb-input-counter-line-height);
  letter-spacing: var(--wb-font-body-s-letter-spacing);
}
.wb-input__trailing,
.wb-input__icon-button {
  flex: none;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-left: var(--wb-spacing-component-sm);
}
.wb-input__icon-button {
  align-self: stretch;
  padding: 0;
  border: 0;
  background: transparent;
  cursor: pointer;
}
.wb-input__trailing,
.wb-input__icon-button {
  color: var(--wb-color-icon-secondary);
}
.wb-input__unit-select {
  max-width: 50%;
  border: 0;
  background: transparent;
  color: inherit;
  font: inherit;
  margin-left: var(--wb-spacing-component-sm);
}
.wb-input.is-disabled .wb-input__control {
  border-color: var(--wb-color-border-disabled);
  background: transparent;
  color: var(--wb-color-text-disabled);
}
.wb-input.is-disabled .wb-input__native::placeholder,
.wb-input.is-disabled .wb-input__counter,
.wb-input.is-disabled .wb-input__unit {
  color: var(--wb-color-text-disabled);
}
.wb-input.is-disabled .wb-input__trailing,
.wb-input.is-disabled .wb-input__icon-button {
  color: var(--wb-color-icon-disabled);
}
</style>

<style>
.wb-input__control--multiline {
  min-height: var(--wb-asset-wb-input-multiline-height);
}
.wb-input__control--multiline.is-resizable {
  resize: vertical;
  overflow: hidden;
}
</style>

<style>
.wb-input__shell:not(.is-disabled) .wb-search__filter.is-disabled {
  background: var(--wb-color-fill-subtle-disabled);
}
.wb-input__shell .wb-search__filter--prefix {
  border-top-left-radius: var(--wb-radius-sm);
  border-bottom-left-radius: var(--wb-radius-sm);
}
.wb-input__shell .wb-search__filter--suffix {
  border-top-right-radius: var(--wb-radius-sm);
  border-bottom-right-radius: var(--wb-radius-sm);
}
</style>
