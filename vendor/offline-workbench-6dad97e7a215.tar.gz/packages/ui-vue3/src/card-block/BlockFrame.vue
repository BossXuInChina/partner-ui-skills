<script setup lang="ts">
import { computed, useSlots, type PropType } from 'vue';
import WorkbenchCard from '../card/WorkbenchCard.vue';
import { hasSlotContent } from './slots';
import BlockActions from './BlockActions.vue';
import type {
  CardVariant,
  CardSize,
  CardAction,
  CardFooter,
  CardActionEvent,
} from '../../types/card-blocks';
import '../../../../catalog/generated/asset.tokens.css';
import './blocks.css';
const props = defineProps({
  title: { type: String, default: '' },
  variant: {
    type: String as PropType<CardVariant>,
    default: 'display-white',
    validator: (value: string) =>
      ['display-white', 'display-tinted', 'operation', 'navigation'].includes(value),
  },
  size: {
    type: String as PropType<CardSize>,
    default: 'xxxl',
    validator: (value: string) => ['s', 'm', 'l', 'xl', 'xxl', 'xxxl'].includes(value),
  },
  href: { type: String, default: undefined },
  target: { type: String, default: undefined },
  rel: { type: String, default: undefined },
  headerActions: { type: Array as PropType<CardAction[]>, default: () => [] },
  footer: { type: Object as PropType<CardFooter | null>, default: null },
  actions: { type: Array as PropType<CardAction[]>, default: () => [] },
});
const emit = defineEmits({ action: (_payload: CardActionEvent) => true });
const slots = useSlots();
const navigation = computed(() => props.variant === 'navigation');
const has = (name: string) => !navigation.value && hasSlotContent(slots, name);
const progress = computed(() =>
  props.footer?.kind === 'progress'
    ? Math.max(0, Math.min(100, Number(props.footer.value) || 0))
    : 0,
);
const expectedProgress = computed(() =>
  props.footer?.kind === 'progress'
    ? Math.max(0, Math.min(100 - progress.value, Number(props.footer.expectedValue) || 0))
    : 0,
);
const totalProgress = computed(
  () => Math.round((progress.value + expectedProgress.value) * 100) / 100,
);
const footerVisible = () =>
  has('footer') ||
  props.footer?.kind === 'progress' ||
  (props.footer?.kind === 'metadata' && !!props.footer.text);
</script>
<template>
  <WorkbenchCard
    class="wbc-root"
    :variant="variant"
    :size="size"
    :href="href"
    :target="target"
    :rel="rel"
  >
    <template
      v-if="
        title || has('header') || (!navigation && (has('header-actions') || headerActions.length))
      "
      #header
    >
      <slot
        v-if="has('header')"
        name="header"
      />
      <div
        v-else
        class="wbc-info-title-row"
      >
        <h3
          v-if="title"
          class="wbc-title"
        >
          {{ title }}
        </h3>
        <slot
          v-if="has('header-actions')"
          name="header-actions"
        />
        <BlockActions
          v-else-if="!navigation && headerActions.length"
          :items="headerActions"
          header
          @activate="(a, event) => emit('action', { id: a.id, source: 'header', event })"
        />
      </div>
    </template>
    <slot />
    <template
      v-if="footerVisible()"
      #footer
    >
      <slot
        v-if="has('footer')"
        name="footer"
      />
      <p
        v-else-if="footer?.kind === 'metadata'"
        class="wbc-meta"
      >
        {{ footer.text }}
      </p>
      <div
        v-else-if="footer?.kind === 'progress' && footer.expectedValue !== undefined"
        class="wbc-progress-target"
      >
        <div class="wbc-progress">
          <div
            class="wbc-progress-track wbc-progress-segments"
            role="progressbar"
            :aria-label="footer.label || '预计完成进度'"
            :aria-valuenow="totalProgress"
            aria-valuemin="0"
            aria-valuemax="100"
            :aria-valuetext="`当前 ${Math.round(progress * 100) / 100}%，预计增加 ${Math.round(expectedProgress * 100) / 100}%${footer.targetLabel ? '，' + footer.targetLabel : ''}`"
          >
            <progress
              class="wbc-progress-native wbc-progress-expected"
              :value="totalProgress"
              max="100"
              aria-hidden="true"
            />
            <progress
              class="wbc-progress-native wbc-progress-current"
              :value="progress"
              max="100"
              aria-hidden="true"
            />
          </div>
          <strong>{{ totalProgress }}%</strong>
        </div>
        <p
          v-if="footer.targetLabel"
          class="wbc-meta"
        >
          {{ footer.targetLabel }}
        </p>
      </div>
      <div
        v-else-if="footer?.kind === 'progress'"
        class="wbc-progress"
      >
        <progress
          class="wbc-progress-native"
          :value="progress"
          max="100"
          :aria-label="footer.label || '完成进度'"
        />
        <strong>{{ progress }}%</strong>
      </div>
    </template>
    <template
      v-if="!navigation && (has('actions') || actions.length)"
      #actions
    >
      <slot
        v-if="has('actions')"
        name="actions"
      />
      <BlockActions
        v-else
        :items="actions"
        @activate="(a, event) => emit('action', { id: a.id, source: 'actions', event })"
      />
    </template>
  </WorkbenchCard>
</template>
