import { Comment, Fragment, Text } from 'vue';
import type { Slots, VNode } from 'vue';
function containsContent(nodes: VNode[]): boolean {
  return nodes.some((node) => {
    if (node.type === Comment) return false;
    if (node.type === Text) return String(node.children ?? '').trim().length > 0;
    if (node.type === Fragment)
      return Array.isArray(node.children) && containsContent(node.children as VNode[]);
    return true;
  });
}
export function hasSlotContent(
  slots: Slots,
  name: string,
  scope: Record<string, unknown> = {},
): boolean {
  const nodes = slots[name]?.(scope);
  return !!nodes && containsContent(nodes);
}
