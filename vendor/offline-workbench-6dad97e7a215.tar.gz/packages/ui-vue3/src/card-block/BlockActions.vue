<script setup lang="ts">
import type { PropType } from 'vue';
import WorkbenchButton from '../button/WorkbenchButton.vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import type { CardAction } from '../../types/card-blocks';
defineProps({
  items: { type: Array as PropType<CardAction[]>, default: () => [] },
  header: { type: Boolean, default: false },
});
const emit = defineEmits({ activate: (_action: CardAction, _event: MouseEvent) => true });
</script>
<template>
  <div
    :class="
      header
        ? 'wbc-header-actions'
        : ['wbc-actions', { 'wbc-actions--text': items.every((a) => a.appearance === 'text') }]
    "
  >
    <template
      v-for="(action, index) in items"
      :key="action.id"
    >
      <span
        v-if="
          header && index && items[index - 1].appearance === 'icon' && action.appearance !== 'icon'
        "
        class="wbc-header-separator"
        aria-hidden="true"
      />
      <WorkbenchButton
        :appearance="action.appearance || 'secondary'"
        :size="action.appearance === 'icon' ? '24' : '28'"
        :disabled="action.disabled"
        :aria-label="action.appearance === 'icon' ? action.label : undefined"
        @click="emit('activate', action, $event)"
      >
        <template
          v-if="action.icon"
          #icon
          ><WorkbenchIcon :name="action.icon"
        /></template>
        <template v-if="action.appearance !== 'icon'">{{ action.label }}</template>
      </WorkbenchButton>
    </template>
  </div>
</template>
