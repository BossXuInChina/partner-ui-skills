import { reactive, ref, toValue, watch } from 'vue';

export function useQueryTransaction({
  fields,
  scope,
  page = ref(1),
  pageSize = ref(10),
  total,
} = {}) {
  const keys = fields.map((field) => (typeof field === 'string' ? field : field.key));
  const clone = (value) =>
    value != null && typeof value === 'object' ? JSON.parse(JSON.stringify(value)) : value;
  const defaults = Object.fromEntries(
    fields.map((field) =>
      typeof field === 'string' ? [field, ''] : [field.key, field.default ?? ''],
    ),
  );
  const blank = () => clone(defaults);
  const draft = reactive(blank());
  const applied = reactive(blank());
  const expanded = ref(false);
  const normalize = (value) => (typeof value === 'string' ? value.trim() : (value ?? ''));
  function confirm() {
    keys.forEach((key) => {
      applied[key] = clone(normalize(draft[key]));
      draft[key] = clone(applied[key]);
    });
    page.value = 1;
  }
  function cancel() {
    Object.assign(draft, clone(applied));
  }
  function reset() {
    Object.assign(draft, blank());
    Object.assign(applied, blank());
    page.value = 1;
  }
  function remove(key) {
    if (keys.includes(key)) {
      draft[key] = clone(defaults[key]);
      applied[key] = clone(defaults[key]);
      page.value = 1;
    }
  }
  watch(
    expanded,
    (open) => {
      if (open) Object.assign(draft, clone(applied));
    },
    { flush: 'sync' },
  );
  if (scope !== undefined)
    watch(
      () => toValue(scope),
      () => {
        reset();
        expanded.value = false;
      },
      { flush: 'sync' },
    );
  if (total !== undefined)
    watch(
      [() => toValue(total), pageSize],
      ([count, size]) => {
        page.value = Math.max(
          1,
          Math.min(page.value, Math.max(1, Math.ceil((Number(count) || 0) / (Number(size) || 1)))),
        );
      },
      { flush: 'sync', immediate: true },
    );
  return { draft, applied, expanded, confirm, cancel, reset, remove };
}

export default useQueryTransaction;
