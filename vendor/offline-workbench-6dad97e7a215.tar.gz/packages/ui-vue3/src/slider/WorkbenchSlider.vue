<script setup>
import { useFormDisabled } from '../form/useFormDisabled.js';
import { useFieldControl, fieldContextKey } from '../form/fieldContext.js';
import { provide } from 'vue';
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import { computed, nextTick, ref, watch, watchEffect } from 'vue';
import WorkbenchInput from '../input/WorkbenchInput.vue';

const props = defineProps({
  modelValue: { type: [Number, Array], default: 0 },
  min: { type: Number, default: 0 },
  max: { type: Number, default: 100 },
  step: { type: Number, default: 1 },
  type: {
    type: String,
    default: 'continuous',
    validator: (value) => ['continuous', 'discrete'].includes(value),
  },
  range: Boolean,
  disabled: Boolean,
  name: String,
  ariaLabel: { type: String, default: '滑动条' },
  ariaDescribedby: String,
  invalid: Boolean,
  showValue: Boolean,
  showTicks: Boolean,
  showTickLabels: Boolean,
  tickLabelMode: {
    type: String,
    default: 'all',
    validator: (value) => ['all', 'endpoints'].includes(value),
  },
  showInput: Boolean,
  wideInput: Boolean,
  unit: String,
  tickLabels: { type: [Array, Object], default: () => ({}) },
  showTooltip: Boolean,
});
const disabled = useFormDisabled(() => props.disabled);
const lower = ref(null),
  upper = ref(null);
const { field, attrs: lowerFieldAttrs } = useFieldControl(() => props.modelValue, {
  describedBy: () => props.ariaDescribedby,
  invalid: () => props.invalid,
  option: true,
  focus: () => lower.value?.focus(),
});
const { attrs: upperFieldAttrs } = useFieldControl(() => props.modelValue, {
  active: () => props.type === 'discrete' && props.range,
  describedBy: () => props.ariaDescribedby,
  invalid: () => props.invalid,
  option: true,
  focus: () => upper.value?.focus(),
});
provide(fieldContextKey, null);
const controlLabel = computed(() => field?.label.value || props.ariaLabel);
const emit = defineEmits(['update:modelValue']);
const activeThumb = ref('');
const focusedThumb = ref('');
const inputDrafts = ref(['', '']);
const editingInput = ref([false, false]);
const lastInteractedThumb = ref('lower');
watch(() => disabled.value, disabled => {
  if (disabled) {
    activeThumb.value = '';
    focusedThumb.value = '';
  }
});
const isRange = computed(() => props.type === 'discrete' && props.range);
const span = computed(() => Math.max(0, props.max - props.min));
const safeStep = computed(() => (Number.isFinite(props.step) && props.step > 0 ? props.step : 1));
const precision = computed(() => String(safeStep.value).split('.')[1]?.length || 0);
const displayUnit = computed(() => String(props.unit || '').toUpperCase());
function normalize(value) {
  const numeric = Number(value);
  const safe = Number.isFinite(numeric) ? numeric : props.min;
  const stepped = props.min + Math.round((safe - props.min) / safeStep.value) * safeStep.value;
  return Number(Math.min(props.max, Math.max(props.min, stepped)).toFixed(precision.value));
}
const values = computed(() => {
  if (!isRange.value)
    return [normalize(Array.isArray(props.modelValue) ? props.modelValue[0] : props.modelValue)];
  const source = Array.isArray(props.modelValue) ? props.modelValue : [props.min, props.modelValue];
  const lower = normalize(source[0]);
  const upper = normalize(source[1] ?? props.max);
  return lower <= upper ? [lower, upper] : [upper, lower];
});
const percentages = computed(() =>
  values.value.map((value) => (span.value ? ((value - props.min) / span.value) * 100 : 0)),
);
watch(
  values,
  (value) =>
    value.forEach((item, index) => {
      if (!editingInput.value[index]) inputDrafts.value[index] = String(item);
    }),
  { immediate: true },
);
const startPercent = computed(() => (isRange.value ? percentages.value[0] : 0));
const endPercent = computed(() => (isRange.value ? percentages.value[1] : percentages.value[0]));
const ticks = computed(() => {
  if (props.type !== 'discrete' || (!props.showTicks && !props.showTickLabels) || span.value <= 0)
    return [];
  const count = Math.floor(span.value / safeStep.value);
  const result = Array.from({ length: count + 1 }, (_, index) =>
    normalize(props.min + index * safeStep.value),
  );
  if (result.at(-1) !== props.max) result.push(props.max);
  return result.map((value) => {
    const configured = Array.isArray(props.tickLabels)
      ? props.tickLabels.find((item) => Number(item?.value) === value)
      : props.tickLabels?.[value];
    const detail = typeof configured === 'string' ? { text: configured } : configured || {};
    const percent = ((value - props.min) / span.value) * 100;
    return {
      value,
      percent,
      endpoint: value === props.min || value === props.max,
      selected: percent >= startPercent.value && percent <= endPercent.value,
      unit: String(detail.unit ?? displayUnit.value).toUpperCase(),
      text: detail.text || '',
    };
  });
});
const railArea = ref(null);
watchEffect(() => {
  railArea.value?.style.setProperty('--slider-start', `${startPercent.value}%`);
  railArea.value?.style.setProperty('--slider-end', `${endPercent.value}%`);
});
function setTickPosition(element, percent) {
  element?.style.setProperty('--tick-position', `${percent}%`);
}
function updateThumb(index, rawValue) {
  if (disabled.value) return;
  lastInteractedThumb.value = index === 0 ? 'lower' : 'upper';
  let value = normalize(rawValue);
  if (!isRange.value) {
    emit('update:modelValue', value);
    return;
  }
  const next = [...values.value];
  value = index === 0 ? Math.min(value, next[1]) : Math.max(value, next[0]);
  next[index] = value;
  emit('update:modelValue', next);
}
function nativeInput(index, event) {
  updateThumb(index, event.target.value);
  nextTick(() => {
    event.target.value = String(values.value[index]);
  });
}
function beginInput(index) {
  editingInput.value[index] = true;
  inputDrafts.value[index] = String(values.value[index]);
}
function editInput(index, value) {
  inputDrafts.value[index] = value;
}
function commitInput(index, keepEditing = false, event) {
  if (event?.isComposing || event?.keyCode === 229) return;
  if (!editingInput.value[index]) return;
  if (keepEditing) event?.preventDefault();
  const draft = inputDrafts.value[index];
  editingInput.value[index] = keepEditing;
  if (draft.trim() && Number.isFinite(Number(draft))) updateThumb(index, draft);
  nextTick(() => {
    inputDrafts.value[index] = String(values.value[index]);
  });
}
function setActive(name) {
  if (!disabled.value) {
    activeThumb.value = name;
    lastInteractedThumb.value = name;
  }
}
function clearActive() {
  activeThumb.value = '';
}
function setFocused(name, event) {
  focusedThumb.value = event?.target?.matches(':focus-visible') ? name : '';
}
function clearFocused(name) {
  if (focusedThumb.value === name) focusedThumb.value = '';
}
function clearPointerTooltip(event) {
  if (!event.buttons) activeThumb.value = '';
}
function tooltipVisible(name) {
  return !disabled.value && props.showTooltip && (activeThumb.value === name || focusedThumb.value === name);
}
function tickLabelVisible(tick) {
  return props.showTickLabels && (props.tickLabelMode === 'all' || tick.endpoint);
}
function chooseFromRail(event) {
  if (disabled.value || event.target.closest?.('.wb-slider__native')) return;
  const rail = event.currentTarget.querySelector('.wb-slider__rail');
  const rect = rail?.getBoundingClientRect();
  if (!rect?.width) return;
  const ratio = Math.min(1, Math.max(0, (event.clientX - rect.left) / rect.width));
  const value = normalize(props.min + ratio * span.value);
  let index = 0;
  if (isRange.value) {
    const lowerDistance = Math.abs(value - values.value[0]);
    const upperDistance = Math.abs(value - values.value[1]);
    index =
      lowerDistance === upperDistance
        ? lastInteractedThumb.value === 'upper'
          ? 1
          : 0
        : lowerDistance < upperDistance
          ? 0
          : 1;
  }
  updateThumb(index, value);
  setActive(index === 0 ? 'lower' : 'upper');
}
</script>

<template>
  <div
    class="wb-slider"
    :class="{
      'is-disabled': disabled,
      'is-discrete': type === 'discrete',
      'is-range': isRange,
      'has-tick-labels': type === 'discrete' && showTickLabels,
    }"
    @pointerleave="clearPointerTooltip"
  >
    <div
      ref="railArea"
      class="wb-slider__rail-area"
      @click="chooseFromRail"
    >
      <div
        class="wb-slider__rail"
        aria-hidden="true"
      >
        <span
          class="wb-slider__unselected"
          data-part="unselected-track"
        /><span
          class="wb-slider__selected"
          data-part="selected-track"
        />
      </div>
      <div
        v-if="type === 'discrete' && (showTicks || showTickLabels)"
        class="wb-slider__ticks"
        aria-hidden="true"
      >
        <span
          v-for="tick in ticks"
          :key="tick.value"
          :ref="(element) => setTickPosition(element, tick.percent)"
          class="wb-slider__tick-position"
          ><span
            v-if="showTicks && !tick.endpoint"
            class="wb-slider__tick"
            :class="{ 'is-selected': tick.selected }"
            data-part="tick"
          /><span
            v-if="tickLabelVisible(tick)"
            class="wb-slider__tick-label"
            data-part="tick-label"
            ><span
              >{{ tick.value
              }}<span
                v-if="tick.unit"
                class="wb-slider__tick-unit"
              >
                {{ tick.unit }}</span
              ></span
            ><small v-if="tick.text">{{ tick.text }}</small></span
          ></span
        >
      </div>
      <input
        ref="lower"
        v-bind="lowerFieldAttrs"
        class="wb-slider__native wb-slider__native--lower"
        :class="{
          'is-current': activeThumb === 'lower' || focusedThumb === 'lower',
          'is-active': activeThumb === 'lower',
        }"
        data-part="thumb"
        type="range"
        :name="isRange && name ? `${name}-min` : name"
        :value="values[0]"
        :min="min"
        :max="max"
        :step="safeStep"
        :disabled="disabled"
        :aria-label="isRange ? `${controlLabel}最小值` : controlLabel"
        :aria-valuemax="isRange ? values[1] : max"
        @input="nativeInput(0, $event)"
        @pointerenter="setActive('lower')"
        @pointerleave="clearActive"
        @pointerdown="setActive('lower')"
        @pointerup="clearActive"
        @pointercancel="clearActive"
        @focus="setFocused('lower', $event)"
        @blur="clearFocused('lower')"
      />
      <span
        v-if="tooltipVisible('lower')"
        class="wb-slider__tooltip wb-slider__tooltip--lower"
        data-part="tooltip"
        aria-hidden="true"
        ><span>{{ values[0] }}{{ displayUnit }}</span
        ><svg viewBox="0 0 12 8"><path d="M0 0h12L7.6 5.9C6.8 7 5.2 7 4.4 5.9L0 0Z" /></svg
      ></span>
      <template v-if="isRange">
        <input
          ref="upper"
          v-bind="upperFieldAttrs"
          class="wb-slider__native wb-slider__native--upper"
          :class="{
            'is-current': activeThumb === 'upper' || focusedThumb === 'upper',
            'is-active': activeThumb === 'upper',
          }"
          data-part="thumb"
          type="range"
          :name="name ? `${name}-max` : undefined"
          :value="values[1]"
          :min="min"
          :max="max"
          :step="safeStep"
          :disabled="disabled"
          :aria-label="`${controlLabel}最大值`"
          :aria-valuemin="values[0]"
          @input="nativeInput(1, $event)"
          @pointerenter="setActive('upper')"
          @pointerleave="clearActive"
          @pointerdown="setActive('upper')"
          @pointerup="clearActive"
          @pointercancel="clearActive"
          @focus="setFocused('upper', $event)"
          @blur="clearFocused('upper')"
        />
        <span
          v-if="tooltipVisible('upper')"
          class="wb-slider__tooltip wb-slider__tooltip--upper"
          data-part="tooltip"
          aria-hidden="true"
          ><span>{{ values[1] }}{{ displayUnit }}</span
          ><svg viewBox="0 0 12 8"><path d="M0 0h12L7.6 5.9C6.8 7 5.2 7 4.4 5.9L0 0Z" /></svg
        ></span>
      </template>
    </div>
    <div
      v-if="showInput || showValue || unit"
      class="wb-slider__editor"
    >
      <div
        v-if="showInput"
        class="wb-slider__input-group"
      >
        <WorkbenchInput
          class="wb-slider__input"
          :class="{ 'is-wide': wideInput }"
          data-part="input"
          :model-value="inputDrafts[0]"
          :disabled="disabled"
          :aria-label="isRange ? `${controlLabel}最小值输入` : `${controlLabel}输入`"
          @focusin="beginInput(0)"
          @update:model-value="editInput(0, $event)"
          @keydown.enter="commitInput(0, true, $event)"
          @focusout="commitInput(0)"
        /><span
          v-if="isRange"
          class="wb-slider__separator"
          aria-hidden="true"
          >至</span
        ><WorkbenchInput
          v-if="isRange"
          class="wb-slider__input"
          :class="{ 'is-wide': wideInput }"
          data-part="input"
          :model-value="inputDrafts[1]"
          :disabled="disabled"
          :aria-label="`${controlLabel}最大值输入`"
          @focusin="beginInput(1)"
          @update:model-value="editInput(1, $event)"
          @keydown.enter="commitInput(1, true, $event)"
          @focusout="commitInput(1)"
        />
      </div>
      <output
        v-else-if="showValue"
        class="wb-slider__value"
        >{{ isRange ? values.join(' – ') : values[0] }}</output
      ><span
        v-if="unit"
        class="wb-slider__unit"
        data-part="unit"
        >{{ displayUnit }}</span
      >
    </div>
  </div>
</template>

<style scoped>
.wb-slider {
  display: flex;
  align-items: flex-start;
  gap: 0;
  width: 100%;
  min-width: 0;
  min-height: var(--wb-asset-wb-slider-input-height);
  color: var(--wb-color-text-primary);
}
.wb-slider__rail-area {
  position: relative;
  flex: 1;
  min-width: 0;
  height: var(--wb-asset-wb-slider-control-height);
  margin-block-start: var(--wb-asset-wb-slider-control-align-offset);
}
.wb-slider.has-tick-labels .wb-slider__rail-area {
  height: var(--wb-asset-wb-slider-control-label-height);
}
.wb-slider__rail {
  position: absolute;
  top: calc(
    (var(--wb-asset-wb-slider-control-height) - var(--wb-asset-wb-slider-track-height)) / 2
  );
  left: 0;
  width: 100%;
  height: var(--wb-asset-wb-slider-track-height);
  overflow: hidden;
  border-radius: var(--wb-radius-full);
}
.wb-slider__rail-area:not(:has(.wb-slider__native:disabled)) {
  cursor: pointer;
}
.wb-slider__unselected,
.wb-slider__selected {
  position: absolute;
  inset-block: 0;
  border-radius: var(--wb-radius-full);
}
.wb-slider__unselected {
  inset-inline: 0;
  background: var(--wb-color-fill-default);
}
.wb-slider__selected {
  left: var(--slider-start);
  width: calc(var(--slider-end) - var(--slider-start));
  background: var(--wb-color-icon-primary);
}
.wb-slider__native {
  position: absolute;
  z-index: 2;
  top: 0;
  left: calc(var(--wb-asset-wb-slider-thumb-size) / -2);
  width: calc(100% + var(--wb-asset-wb-slider-thumb-size));
  height: var(--wb-asset-wb-slider-control-height);
  margin: 0;
  appearance: none;
  pointer-events: none;
  background: transparent;
}
.wb-slider__native::-webkit-slider-runnable-track {
  height: var(--wb-asset-wb-slider-track-height);
  background: transparent;
}
.wb-slider__native::-webkit-slider-thumb {
  box-sizing: border-box;
  width: var(--wb-asset-wb-slider-thumb-size);
  height: var(--wb-asset-wb-slider-thumb-size);
  margin-top: calc(
    (var(--wb-asset-wb-slider-track-height) - var(--wb-asset-wb-slider-thumb-size)) / 2
  );
  appearance: none;
  pointer-events: auto;
  border: 0;
  border-radius: var(--wb-radius-full);
  background: var(--wb-asset-wb-slider-thumb-color);
  box-shadow: var(--wb-asset-wb-slider-thumb-shadow);
  cursor: grab;
}
.wb-slider__native::-moz-range-track {
  height: var(--wb-asset-wb-slider-track-height);
  background: transparent;
}
.wb-slider__native::-moz-range-thumb {
  box-sizing: border-box;
  width: var(--wb-asset-wb-slider-thumb-size);
  height: var(--wb-asset-wb-slider-thumb-size);
  pointer-events: auto;
  border: 0;
  border-radius: var(--wb-radius-full);
  background: var(--wb-asset-wb-slider-thumb-color);
  box-shadow: var(--wb-asset-wb-slider-thumb-shadow);
  cursor: grab;
}
.wb-slider__native.is-current {
  z-index: 3;
}
.wb-slider__native.is-active::-webkit-slider-thumb,
.wb-slider__native:active::-webkit-slider-thumb,
.wb-slider__native:focus-visible::-webkit-slider-thumb {
  box-shadow:
    0 0 0 var(--wb-asset-wb-slider-thumb-ring-width) var(--wb-color-icon-primary),
    var(--wb-asset-wb-slider-thumb-shadow);
}
.wb-slider__native:active::-webkit-slider-thumb {
  cursor: grabbing;
}
.wb-slider__native.is-active::-moz-range-thumb,
.wb-slider__native:active::-moz-range-thumb,
.wb-slider__native:focus-visible::-moz-range-thumb {
  box-shadow:
    0 0 0 var(--wb-asset-wb-slider-thumb-ring-width) var(--wb-color-icon-primary),
    var(--wb-asset-wb-slider-thumb-shadow);
}
.wb-slider__native:active::-moz-range-thumb {
  cursor: grabbing;
}
.wb-slider__native:focus-visible {
  outline: none;
}
.wb-slider__ticks {
  position: absolute;
  z-index: 1;
  inset: 0;
  pointer-events: none;
}
.wb-slider__tick-position {
  position: absolute;
  top: 0;
  left: var(--tick-position);
  transform: translateX(-50%);
}
.wb-slider__tick {
  position: absolute;
  top: var(--wb-asset-wb-slider-tick-top);
  left: 50%;
  width: var(--wb-asset-wb-slider-tick-width);
  height: var(--wb-asset-wb-slider-tick-height);
  transform: translateX(-50%);
  border-radius: var(--wb-radius-full);
  background: var(--wb-color-fill-default);
}
.wb-slider__tick.is-selected {
  background: var(--wb-color-icon-primary);
}
.wb-slider__tick-label {
  position: absolute;
  top: var(--wb-asset-wb-slider-label-top);
  left: 50%;
  display: grid;
  justify-items: center;
  transform: translateX(-50%);
  white-space: nowrap;
  color: var(--wb-color-text-primary);
  font-size: var(--wb-font-body-s-font-size);
  font-weight: var(--wb-font-body-s-font-weight);
  line-height: var(--wb-font-body-s-line-height);
  letter-spacing: var(--wb-font-body-s-letter-spacing);
}
.wb-slider__tick-label small {
  font: inherit;
  color: var(--wb-color-text-placeholder);
}
.wb-slider__tick-unit {
  display: inline-block;
  margin-inline-start: var(--wb-asset-wb-slider-tick-unit-gap);
  text-transform: uppercase;
}
.wb-slider__tooltip {
  position: absolute;
  z-index: 5;
  bottom: calc(100% + var(--wb-asset-wb-slider-tooltip-offset));
  transform: translateX(-50%);
  box-sizing: border-box;
  width: max-content;
  padding: var(--wb-spacing-component-xs) var(--wb-spacing-component-sm);
  border-radius: var(--wb-radius-sm);
  color: var(--wb-color-text-primary);
  background: var(--wb-color-surface-overlay);
  box-shadow: var(--wb-shadow-lg);
  white-space: nowrap;
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
  pointer-events: none;
}
.wb-slider__tooltip svg {
  position: absolute;
  top: 100%;
  left: calc(50% - var(--wb-asset-wb-popover-arrow-width) / 2);
  display: block;
  width: var(--wb-asset-wb-popover-arrow-width);
  height: var(--wb-asset-wb-popover-arrow-height);
  overflow: visible;
}
.wb-slider__tooltip svg path {
  fill: var(--wb-color-surface-overlay);
}
.wb-slider__tooltip--lower {
  left: var(--slider-start);
}
.wb-slider:not(.is-range) .wb-slider__tooltip--lower {
  left: var(--slider-end);
}
.wb-slider__tooltip--upper {
  left: var(--slider-end);
}
.wb-slider__editor {
  display: flex;
  flex: none;
  align-items: center;
  gap: var(--wb-asset-wb-slider-input-unit-gap);
  height: var(--wb-asset-wb-slider-input-height);
  margin-block-start: calc(
    var(--wb-asset-wb-slider-control-align-offset) + var(--wb-asset-wb-slider-control-height) -
      var(--wb-asset-wb-slider-input-height)
  );
  margin-inline-start: var(--wb-spacing-component-md);
}
.wb-slider__input-group {
  display: flex;
  align-items: center;
  gap: var(--wb-spacing-component-sm);
  height: 100%;
}
.wb-slider__input {
  width: var(--wb-asset-wb-slider-input-width);
}
.wb-slider__input.is-wide {
  width: var(--wb-asset-wb-slider-input-wide-width);
}
.wb-slider__input:deep(.wb-input__control) {
  height: var(--wb-asset-wb-slider-input-height);
  min-height: var(--wb-asset-wb-slider-input-height);
  padding-inline: var(--wb-spacing-component-xs);
  align-items: center;
}
.wb-slider__input:deep(.wb-input__native) {
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
  text-align: center;
}
.wb-slider__value {
  min-width: 3ch;
  text-align: right;
}
.wb-slider__unit {
  display: flex;
  align-items: center;
  height: 100%;
  color: var(--wb-color-text-primary);
  white-space: nowrap;
  text-transform: uppercase;
}
.wb-slider.is-disabled {
  color: var(--wb-color-text-disabled);
}
.wb-slider.is-disabled .wb-slider__selected,
.wb-slider.is-disabled .wb-slider__tick {
  background: var(--wb-color-icon-disabled);
}
.wb-slider.is-disabled .wb-slider__native::-webkit-slider-thumb {
  background: var(--wb-color-fill-disabled);
  box-shadow: none;
  cursor: not-allowed;
  opacity: 1;
}
.wb-slider.is-disabled .wb-slider__native::-moz-range-thumb {
  background: var(--wb-color-fill-disabled);
  box-shadow: none;
  cursor: not-allowed;
  opacity: 1;
}
.wb-slider.is-disabled .wb-slider__input {
  border-color: var(--wb-color-border-disabled);
  color: var(--wb-color-text-disabled);
  background: transparent;
}
</style>
