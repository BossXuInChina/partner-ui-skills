<script setup>
import { useFormDisabled } from '../form/useFormDisabled.js';
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import { computed, nextTick, onBeforeUnmount, onMounted, ref, useId, watch } from 'vue';
import WorkbenchButton from '../button/WorkbenchButton.vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';

const props = defineProps({
  modelValue: { type: [String, Array], default: '' },
  range: Boolean,
  use12Hours: Boolean,
  showSeconds: { type: Boolean, default: true },
  showNow: Boolean,
  disabled: Boolean,
  name: String,
  ariaLabel: { type: String, default: '选择时间' },
  ariaDescribedby: String,
  invalid: Boolean,
  placeholder: { type: String, default: '请选择时间' },
  previewState: { type: String, default: 'default' },
  defaultOpen: Boolean,
  teleportPanel: Boolean,
  inline: Boolean,
});
const disabled = useFormDisabled(() => props.disabled);
const emit = defineEmits(['update:modelValue', 'change', 'cancel']);
const root = ref(null);
const panel = ref(null);
let resizeObserver;
const open = ref(false);
const endpoint = ref(0);
const draft = ref([]);
const touched = ref([false, false]);
const panelId = `wb-time-${useId().replace(/[^\w-]/g, '')}`;
const pad = (value) => String(value).padStart(2, '0');
const hours = computed(() =>
  Array.from({ length: props.use12Hours ? 12 : 24 }, (_, i) => pad(props.use12Hours ? i + 1 : i)),
);
const units = Array.from({ length: 60 }, (_, i) => pad(i));
const columns = computed(() => [
  { key: 'hour', label: '小时', values: hours.value },
  { key: 'minute', label: '分钟', values: units },
  ...(props.showSeconds ? [{ key: 'second', label: '秒', values: units }] : []),
  ...(props.use12Hours ? [{ key: 'period', label: '上午或下午', values: ['AM', 'PM'] }] : []),
]);
function parse(value) {
  if (typeof value !== 'string' || !/^\d{2}:\d{2}(?::\d{2})?$/.test(value)) return null;
  const [hour, minute, second = 0] = value.split(':').map(Number);
  return hour < 24 && minute < 60 && second < 60 ? { hour, minute, second } : null;
}
function now() {
  const time = new Date();
  return {
    hour: time.getHours(),
    minute: time.getMinutes(),
    second: props.showSeconds ? time.getSeconds() : 0,
  };
}
const committed = computed(() =>
  props.range
    ? [
        parse(Array.isArray(props.modelValue) ? props.modelValue[0] : ''),
        parse(Array.isArray(props.modelValue) ? props.modelValue[1] : ''),
      ]
    : [parse(props.modelValue), null],
);
const active = computed(() => draft.value[endpoint.value] ?? { hour: 0, minute: 0, second: 0 });
function serialize(value) {
  return [value.hour, value.minute, ...(props.showSeconds ? [value.second] : [])]
    .map(pad)
    .join(':');
}
function display(index) {
  const value = open.value && touched.value[index] ? draft.value[index] : committed.value[index];
  if (!value) return props.range ? ['请选择开始时间', '请选择结束时间'][index] : props.placeholder;
  if (!props.use12Hours) return serialize(value);
  return `${[value.hour % 12 || 12, value.minute, ...(props.showSeconds ? [value.second] : [])].map(pad).join(':')} ${value.hour < 12 ? 'AM' : 'PM'}`;
}
function isPlaceholder(index) {
  return !(open.value && touched.value[index]) && !committed.value[index];
}
function selected(key) {
  if (key === 'period') return active.value.hour < 12 ? 'AM' : 'PM';
  if (key === 'hour' && props.use12Hours) return pad(active.value.hour % 12 || 12);
  return pad(active.value[key]);
}
const seconds = (value) =>
  value.hour * 3600 + value.minute * 60 + (props.showSeconds ? value.second : 0);
const invalidRange = computed(
  () =>
    props.range &&
    endpoint.value === 1 &&
    draft.value.length === 2 &&
    seconds(draft.value[1]) < seconds(draft.value[0]),
);

function positionColumns(focus = false) {
  nextTick(() => {
    for (const column of panel.value?.querySelectorAll('[role="listbox"]') ?? []) {
      const option = column.querySelector('[aria-selected="true"]');
      if (!option) continue;
      column.scrollTop = option.offsetTop - (column.clientHeight - option.offsetHeight) / 2;
    }
    if (focus)
      panel.value
        ?.querySelector('[role="option"][aria-selected="true"]')
        ?.focus({ preventScroll: true });
  });
}
function begin(index = 0, focus = false) {
  if (disabled.value) return;
  if (!open.value) {
    const current = now();
    draft.value = committed.value.map((value) => ({ ...(value ?? current) }));
    touched.value = [false, false];
  }
  endpoint.value = index;
  open.value = true;
  positionColumns(focus);
}
function focusTrigger() {
  nextTick(() =>
    root.value
      ?.querySelector(
        props.range ? `[data-endpoint="${endpoint.value}"]` : '.wb-time-picker__trigger',
      )
      ?.focus(),
  );
}
function cancel(restoreFocus = false) {
  if (!open.value) return;
  open.value = false;
  emit('cancel');
  if (props.inline && !disabled.value) begin(endpoint.value);
  if (restoreFocus) focusTrigger();
}
function choose(key, value) {
  const index = endpoint.value;
  const next =
    touched.value[index] || committed.value[index]
      ? { ...active.value }
      : { hour: 0, minute: 0, second: 0 };
  if (key === 'period') next.hour = (next.hour % 12) + (value === 'PM' ? 12 : 0);
  else if (key === 'hour' && props.use12Hours)
    next.hour = (Number(value) % 12) + (next.hour >= 12 ? 12 : 0);
  else next[key] = Number(value);
  draft.value[index] = next;
  touched.value[index] = true;
  positionColumns();
}
function publish(values) {
  const value = props.range ? values.map(serialize) : serialize(values[0]);
  open.value = false;
  emit('update:modelValue', value);
  emit('change', value);
  if (props.inline) nextTick(() => begin(endpoint.value));
  focusTrigger();
}
function confirm() {
  if (invalidRange.value) return;
  if (props.range && endpoint.value === 0) {
    touched.value[0] = true;
    begin(1, true);
    return;
  }
  publish(draft.value);
}
function chooseNow() {
  const value = now();
  if (!props.range) return publish([value]);
  draft.value[endpoint.value] = value;
  touched.value[endpoint.value] = true;
  if (endpoint.value === 0) begin(1, true);
  else if (!invalidRange.value) publish(draft.value);
  else positionColumns(true);
}
function optionKeydown(event, column, value) {
  const index = column.values.indexOf(value);
  const step = { ArrowUp: -1, ArrowDown: 1, PageUp: -5, PageDown: 5 }[event.key];
  if (step !== undefined || event.key === 'Home' || event.key === 'End') {
    event.preventDefault();
    const next =
      event.key === 'Home'
        ? 0
        : event.key === 'End'
          ? column.values.length - 1
          : Math.max(0, Math.min(column.values.length - 1, index + step));
    const targetColumn = event.currentTarget.closest('[role="listbox"]');
    choose(column.key, column.values[next]);
    nextTick(() =>
      targetColumn.querySelector('[aria-selected="true"]')?.focus({ preventScroll: true }),
    );
  } else if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
    event.preventDefault();
    const lists = [...panel.value.querySelectorAll('[role="listbox"]')];
    const next =
      lists.indexOf(event.currentTarget.closest('[role="listbox"]')) +
      (event.key === 'ArrowRight' ? 1 : -1);
    lists[next]?.querySelector('[aria-selected="true"]')?.focus({ preventScroll: true });
  }
}
function contains(target) {
  return root.value?.contains(target) || panel.value?.contains(target);
}
function positionPanel() {
  if (!panel.value) return;
  if (!props.teleportPanel || props.inline) {
    panel.value.style.removeProperty('left');
    panel.value.style.removeProperty('top');
    return;
  }
  if (!open.value || !root.value) return;
  const anchor = root.value.getBoundingClientRect();
  const box = panel.value.getBoundingClientRect();
  const style = getComputedStyle(root.value);
  const gap = parseFloat(style.getPropertyValue('--wb-asset-wb-time-picker-panel-offset'));
  const edge = parseFloat(style.getPropertyValue('--wb-spacing-component-sm'));
  const left = props.range && endpoint.value === 1 ? anchor.right - box.width : anchor.left;
  const top =
    anchor.bottom + gap + box.height <= window.innerHeight - edge
      ? anchor.bottom + gap
      : Math.max(edge, anchor.top - box.height - gap);
  Object.assign(panel.value.style, {
    left: `${Math.max(edge, Math.min(left, window.innerWidth - box.width - edge))}px`,
    top: `${top}px`,
  });
}
function outside(event) {
  if (props.inline) return;
  if (!contains(event.target)) cancel();
}
function focusout(event) {
  if (props.inline) return;
  if (event.relatedTarget && !contains(event.relatedTarget)) cancel();
}
function escape(event) {
  if (event.key !== 'Escape' || !open.value) return;
  event.preventDefault();
  event.stopPropagation();
  cancel(true);
}
watch(
  () => props.defaultOpen,
  (value) => {
    if (!props.inline) value ? begin() : cancel();
  },
);
watch(
  () => disabled.value,
  (value) => {
    if (value) cancel();
    else if (props.inline) begin();
  },
);
watch(
  () => [props.range, props.use12Hours, props.showSeconds],
  () => {
    cancel();
    if (props.inline && !open.value) begin();
  },
);
watch(
  () => props.inline,
  (value) => {
    if (value && !disabled.value) begin();
  },
);
watch(
  () => props.modelValue,
  () => {
    if (open.value) {
      open.value = false;
      begin(endpoint.value);
    }
  },
  { deep: true },
);
watch([open, endpoint, () => props.teleportPanel], () => nextTick(positionPanel));
watch(
  panel,
  (node, previous) => {
    if (previous) resizeObserver?.unobserve(previous);
    if (node) resizeObserver?.observe(node);
    nextTick(positionPanel);
  },
  { flush: 'post' },
);
onMounted(() => {
  document.addEventListener('pointerdown', outside);
  window.addEventListener('resize', positionPanel);
  document.addEventListener('scroll', positionPanel, true);
  resizeObserver = new ResizeObserver(positionPanel);
  if (root.value) resizeObserver.observe(root.value);
  if (props.defaultOpen || props.inline) begin();
});
onBeforeUnmount(() => {
  document.removeEventListener('pointerdown', outside);
  window.removeEventListener('resize', positionPanel);
  document.removeEventListener('scroll', positionPanel, true);
  resizeObserver?.disconnect();
});
</script>

<template>
  <div
    ref="root"
    class="wb-time-picker"
    :class="{ 'is-range': range, 'is-open': open, 'is-disabled': disabled, 'is-invalid': invalid }"
    :data-preview-state="previewState"
    @keydown="escape"
    @focusout="focusout"
  >
    <div
      v-if="range"
      class="wb-time-picker__trigger wb-time-picker__range"
      :class="{ 'is-filled': committed[0] || committed[1] }"
      role="group"
      :aria-label="ariaLabel"
      @click="begin(endpoint)"
    >
      <button
        v-for="index in [0, 1]"
        :key="index"
        type="button"
        class="wb-time-picker__endpoint"
        :class="{
          'is-placeholder': isPlaceholder(index),
          'is-active': open && (endpoint === index || (index === 0 && !isPlaceholder(0))),
        }"
        :data-endpoint="index"
        :disabled="disabled"
        :aria-label="`${ariaLabel}：${index ? '结束时间' : '开始时间'}`"
        aria-haspopup="dialog"
        :aria-expanded="open && endpoint === index"
        :aria-controls="panelId"
        :aria-describedby="ariaDescribedby"
        :aria-invalid="invalid || undefined"
        @click="begin(index)"
        @keydown.down.prevent="begin(index, true)"
      >
        {{ display(index) }}
      </button>
      <span
        class="wb-time-picker__separator"
        aria-hidden="true"
        >-</span
      >
      <WorkbenchIcon
        class="wb-time-picker__icon"
        name="时间_14px"
      />
    </div>
    <button
      v-else
      type="button"
      class="wb-time-picker__trigger"
      :disabled="disabled"
      :aria-label="ariaLabel"
      aria-haspopup="dialog"
      :aria-expanded="open"
      :aria-controls="panelId"
      :aria-describedby="ariaDescribedby"
      :aria-invalid="invalid || undefined"
      @click="inline ? begin() : open ? cancel() : begin()"
      @keydown.down.prevent="begin(0, true)"
    >
      <span :class="{ 'is-placeholder': isPlaceholder(0) }">{{ display(0) }}</span>
      <WorkbenchIcon
        class="wb-time-picker__icon"
        name="时间_14px"
      />
    </button>
    <template v-if="name">
      <template v-if="range"
        ><input
          type="hidden"
          :name="`${name}[0]`"
          :value="Array.isArray(modelValue) ? modelValue[0] : ''"
          :disabled="disabled" /><input
          type="hidden"
          :name="`${name}[1]`"
          :value="Array.isArray(modelValue) ? modelValue[1] : ''"
          :disabled="disabled"
      /></template>
      <input
        v-else
        type="hidden"
        :name="name"
        :value="modelValue"
        :disabled="disabled"
      />
    </template>
    <Teleport
      to="body"
      :disabled="!teleportPanel || inline"
    >
      <div
        v-if="open && !disabled"
        :id="panelId"
        ref="panel"
        class="wb-time-picker__panel"
        :class="{
          'is-end': range && endpoint === 1,
          'is-teleported': teleportPanel && !inline,
          'is-inline': inline,
        }"
        role="dialog"
        :aria-label="range ? `${ariaLabel}：${endpoint ? '结束时间' : '开始时间'}` : ariaLabel"
        @keydown="teleportPanel && escape($event)"
        @focusout="teleportPanel && focusout($event)"
      >
        <div class="wb-time-picker__columns">
          <div
            v-for="column in columns"
            :key="column.key"
            class="wb-time-picker__column"
            :class="{ 'wb-time-picker__column--period': column.key === 'period' }"
            role="listbox"
            :aria-label="column.label"
            :data-unit="column.key"
          >
            <button
              v-for="value in column.values"
              :key="value"
              type="button"
              class="wb-time-picker__option"
              role="option"
              :aria-selected="selected(column.key) === value"
              :tabindex="selected(column.key) === value ? 0 : -1"
              @click="choose(column.key, value)"
              @keydown="optionKeydown($event, column, value)"
            >
              {{ value }}
            </button>
          </div>
        </div>
        <p
          v-if="invalidRange"
          class="wb-time-picker__error"
          role="alert"
        >
          结束时间不能早于开始时间
        </p>
        <div class="wb-time-picker__footer">
          <WorkbenchButton
            v-if="showNow"
            class="wb-time-picker__now"
            appearance="text"
            size="32"
            @click="chooseNow"
            >此刻</WorkbenchButton
          >
          <div class="wb-time-picker__actions">
            <WorkbenchButton
              appearance="secondary"
              size="32"
              @click="cancel(true)"
              >取消</WorkbenchButton
            >
            <WorkbenchButton
              class="wb-time-picker__done"
              size="32"
              :disabled="invalidRange"
              @click="confirm"
              >确定</WorkbenchButton
            >
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>

<style scoped>
.wb-time-picker {
  --time-width: var(--wb-asset-wb-time-picker-panel-width);
  --time-height: var(--wb-asset-wb-time-picker-control-height);
  --time-padding: var(--wb-asset-wb-time-picker-panel-inline-padding);
  --time-selection-offset: var(--wb-asset-wb-time-picker-selection-offset);
  position: relative;
  width: var(--time-width);
  max-width: 100%;
  color: var(--wb-color-text-primary);
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
}
.wb-time-picker.is-range {
  width: var(--wb-asset-wb-time-picker-range-width);
}
.wb-time-picker__trigger {
  box-sizing: border-box;
  display: flex;
  width: 100%;
  height: var(--time-height);
  align-items: center;
  justify-content: space-between;
  gap: var(--wb-spacing-component-sm);
  padding: 0 var(--wb-asset-wb-time-picker-trigger-inline-padding);
  border: 1px solid var(--wb-color-border);
  border-radius: var(--wb-radius-sm);
  background: var(--wb-color-surface-card-default);
  color: inherit;
  font: inherit;
  text-align: left;
  cursor: pointer;
}
.wb-time-picker__trigger:hover,
.wb-time-picker[data-preview-state='hover'] .wb-time-picker__trigger {
  border-color: var(--wb-color-border-hover);
}
.wb-time-picker__trigger:focus-visible,
.wb-time-picker__range:focus-within,
.is-open .wb-time-picker__trigger,
.wb-time-picker[data-preview-state='focused'] .wb-time-picker__trigger {
  border-color: var(--wb-color-border-focus);
  outline: none;
}
.is-placeholder {
  color: var(--wb-color-text-placeholder);
}
.is-open .wb-time-picker__trigger .is-placeholder,
.wb-time-picker[data-preview-state='focused'] .wb-time-picker__trigger .is-placeholder {
  color: var(--wb-color-text-primary);
}
.wb-time-picker__icon {
  color: var(--wb-color-icon-tertiary);
}
.wb-time-picker__range {
  display: grid;
  padding-inline-start: var(--wb-spacing-component-xs);
  grid-template-columns: minmax(0, 1fr) auto minmax(0, 1fr) auto;
}
.wb-time-picker__endpoint {
  grid-row: 1;
  width: 100%;
  min-width: 0;
  padding: 0;
  border: 0;
  border-radius: var(--wb-asset-wb-time-picker-endpoint-radius);
  background: transparent;
  color: inherit;
  font: inherit;
  text-align: left;
  cursor: pointer;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.wb-time-picker__endpoint.is-placeholder {
  color: var(--wb-color-text-placeholder);
}
.wb-time-picker__endpoint:first-child {
  grid-column: 1;
  box-sizing: border-box;
  padding-inline-start: var(--wb-spacing-component-sm);
}
.wb-time-picker__endpoint:nth-child(2) {
  grid-column: 3;
}
.wb-time-picker__separator {
  grid-row: 1;
  grid-column: 2;
}
.wb-time-picker__range .wb-time-picker__icon {
  grid-row: 1;
  grid-column: 4;
}
.wb-time-picker__endpoint:first-child.is-active {
  background: var(--wb-color-fill-hover);
}
.wb-time-picker__endpoint:focus-visible {
  outline: 1px solid var(--wb-color-border-focus);
  outline-offset: 1px;
}
.is-disabled .wb-time-picker__trigger {
  border-color: var(--wb-color-border);
  background: var(--wb-color-fill-subtle-disabled);
  color: var(--wb-color-text-disabled);
  cursor: not-allowed;
}
.is-disabled .wb-time-picker__trigger .is-placeholder {
  color: var(--wb-color-text-disabled);
}
.is-disabled .wb-time-picker__icon {
  color: var(--wb-color-icon-disabled);
}
.is-disabled .wb-time-picker__endpoint {
  background: transparent;
  cursor: not-allowed;
}
.is-invalid .wb-time-picker__trigger {
  border-color: var(--wb-color-error);
}
.wb-time-picker__panel {
  position: absolute;
  z-index: 20;
  top: calc(100% + var(--wb-asset-wb-time-picker-panel-offset));
  left: 0;
  width: var(--time-width);
  border: 0;
  border-radius: var(--wb-radius-md);
  background: var(--wb-color-surface-overlay);
  box-shadow: var(--wb-asset-wb-time-picker-panel-shadow);
}
.wb-time-picker__panel.is-end {
  right: 0;
  left: auto;
}
.wb-time-picker__panel.is-inline {
  position: static;
  max-width: 100%;
  margin-top: var(--wb-asset-wb-time-picker-panel-offset);
}
.wb-time-picker__panel.is-teleported {
  --time-width: var(--wb-asset-wb-time-picker-panel-width);
  --time-height: var(--wb-asset-wb-time-picker-control-height);
  --time-padding: var(--wb-asset-wb-time-picker-panel-inline-padding);
  --time-selection-offset: var(--wb-asset-wb-time-picker-selection-offset);
  position: fixed;
  right: auto;
  color: var(--wb-color-text-primary);
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
}
.wb-time-picker__columns {
  display: flex;
  gap: var(--wb-spacing-component-sm);
  padding: var(--wb-spacing-component-lg) var(--time-padding);
}
.wb-time-picker__column {
  position: relative;
  box-sizing: border-box;
  flex: 1 1 0;
  min-width: 0;
  height: var(--wb-asset-wb-time-picker-list-height);
  padding-block: var(--time-selection-offset);
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-width: none;
  scroll-snap-type: y proximity;
}
.wb-time-picker__column::-webkit-scrollbar {
  display: none;
}
.wb-time-picker__column--period {
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: var(--wb-spacing-component-xs);
  padding-block: calc(var(--time-height) + var(--wb-spacing-component-xs)) 0;
  overflow: hidden;
}
.wb-time-picker__option {
  box-sizing: border-box;
  display: block;
  width: 100%;
  height: var(--time-height);
  padding: var(--wb-spacing-component-xs);
  border: 1px solid transparent;
  border-radius: var(--wb-radius-sm);
  background: transparent;
  color: inherit;
  font: inherit;
  text-align: center;
  cursor: pointer;
  scroll-snap-align: center;
}
.wb-time-picker__option + .wb-time-picker__option {
  margin-top: var(--wb-spacing-component-xs);
}
.wb-time-picker__column--period .wb-time-picker__option {
  flex: none;
  margin: 0;
}
.wb-time-picker__option:hover {
  background: var(--wb-color-fill-hover);
}
.wb-time-picker__option[aria-selected='true'] {
  border-color: var(--wb-color-border-focus);
}
.wb-time-picker__option:focus-visible {
  outline: 1px solid var(--wb-color-border-focus);
  outline-offset: -1px;
}
.wb-time-picker__footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: var(--time-padding);
  border-top: 1px solid var(--wb-color-border-separator);
}
.wb-time-picker__actions {
  display: flex;
  gap: var(--wb-spacing-component-sm);
  margin-left: auto;
}
.wb-time-picker__error {
  margin: 0;
  padding: 0 var(--time-padding) var(--wb-spacing-component-xs);
  color: var(--wb-color-error);
}
</style>
