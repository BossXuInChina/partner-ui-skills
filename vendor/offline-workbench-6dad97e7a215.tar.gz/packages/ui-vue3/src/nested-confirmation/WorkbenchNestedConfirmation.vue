<script setup>
import WorkbenchModal from '../modal/WorkbenchModal.vue';

const props = defineProps({
  parentOpen: { type: Boolean, required: true },
  childOpen: { type: Boolean, required: true },
  parentTitle: { type: String, required: true },
  childTitle: { type: String, required: true },
  parentSize: { type: String, default: 'l' },
  childSize: { type: String, default: 'm' },
  parentBusy: { type: Boolean, default: false },
  childBusy: { type: Boolean, default: false },
});
const emit = defineEmits(['request-close-parent', 'request-close-child']);

function requestParentClose(value) {
  if (value === false && !props.childOpen && !props.parentBusy) emit('request-close-parent');
}
function requestChildClose(value) {
  if (value === false && !props.childBusy) emit('request-close-child');
}
</script>

<template>
  <WorkbenchModal
    :model-value="parentOpen"
    :title="parentTitle"
    :size="parentSize"
    :close-on-esc="!childOpen"
    :close-on-mask="!childOpen && !parentBusy"
    :before-close="() => !childOpen && !parentBusy"
    @update:model-value="requestParentClose"
  >
    <slot name="parent" />
    <template
      v-if="$slots['parent-footer']"
      #footer
      ><slot name="parent-footer"
    /></template>
  </WorkbenchModal>
  <WorkbenchModal
    :model-value="childOpen"
    :title="childTitle"
    :size="childSize"
    :before-close="() => !childBusy"
    @update:model-value="requestChildClose"
  >
    <slot name="child" />
    <template
      v-if="$slots['child-footer']"
      #footer
      ><slot name="child-footer"
    /></template>
  </WorkbenchModal>
</template>
