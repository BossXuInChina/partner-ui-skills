<script setup>
import { nextTick } from 'vue';
import WorkbenchInput from '../input/WorkbenchInput.vue';
import WorkbenchButton from '../button/WorkbenchButton.vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import WorkbenchTooltip from '../tooltip/WorkbenchTooltip.vue';
const props = defineProps({
  rows: { type: Array, required: true },
  members: { type: Array, default: () => [] },
});
const emit = defineEmits(['add', 'delete', 'update-field']);
const taskInputs = new Map();
function setTaskInput(id, element) {
  if (element) taskInputs.set(id, element);
  else taskInputs.delete(id);
}
function focusTask(id) {
  taskInputs.get(id)?.focus();
}
async function add(id) {
  const previous = new Set(props.rows.map((row) => row.id));
  emit('add', id);
  await nextTick();
  const inserted = props.rows.find((row) => !previous.has(row.id));
  if (inserted) focusTask(inserted.id);
}
async function remove(id) {
  if (props.rows.length <= 1) return;
  const index = props.rows.findIndex((row) => row.id === id);
  const adjacent = props.rows[index + 1] ?? props.rows[index - 1];
  emit('delete', id);
  await nextTick();
  if (adjacent && !props.rows.some((row) => row.id === id)) focusTask(adjacent.id);
}
</script>
<template>
  <section
    class="followup"
    aria-label="新增遗留任务"
  >
    <h2>新增遗留任务</h2>
    <div class="followup__body">
      <div
        v-for="(row, index) in rows"
        :key="row.id"
        class="followup__row"
      >
        <div class="followup__fields">
          <WorkbenchInput
            :ref="(input) => setTaskInput(row.id, input)"
            :model-value="row.name"
            :prefix-value="row.member?.[0] || ''"
            :prefix-options="members"
            prefix-placeholder="请选择成员"
            :show-prefix-icon="false"
            size="32"
            @update:model-value="emit('update-field', row.id, 'name', $event)"
            @update:prefix-value="emit('update-field', row.id, 'member', $event ? [$event] : [])"
            :aria-label="`第${index + 1}行任务`"
            placeholder="请输入该成员对应的任务"
          />
        </div>
        <div class="followup__actions">
          <span class="followup__action"
            ><WorkbenchTooltip :content="rows.length === 1 ? '至少保留一条任务' : '删除此任务'">
              <template #trigger="{ aria }">
                <WorkbenchButton
                  v-bind="aria"
                  appearance="icon"
                  icon-layout="container"
                  size="24"
                  :aria-label="`删除第${index + 1}行`"
                  :disabled="rows.length === 1"
                  @click="remove(row.id)"
                >
                  <template #icon
                    ><WorkbenchIcon
                      name="/ic_public_minus_line_14px"
                      :size="14"
                  /></template>
                </WorkbenchButton>
              </template> </WorkbenchTooltip
          ></span>
          <span class="followup__action"
            ><WorkbenchTooltip content="在下方新增任务">
              <template #trigger="{ aria }">
                <WorkbenchButton
                  v-bind="aria"
                  appearance="icon"
                  icon-layout="container"
                  size="24"
                  :aria-label="`在第${index + 1}行后新增`"
                  @click="add(row.id)"
                >
                  <template #icon
                    ><WorkbenchIcon
                      name="/ic_public_plus_line_14px"
                      :size="14"
                  /></template>
                </WorkbenchButton>
              </template> </WorkbenchTooltip
          ></span>
        </div>
      </div>
    </div>
  </section>
</template>
<style scoped>
.followup {
  container-type: inline-size;
}
.followup h2 {
  font: inherit;
  margin: 0 0 var(--wb-spacing-component-sm);
}
.followup__body {
  display: grid;
  gap: var(--wb-spacing-component-sm);
  padding: var(--wb-spacing-component-lg);
  background: var(--wb-color-surface-card-tinted);
  border-radius: var(--wb-radius-md);
}
.followup__row {
  display: flex;
  align-items: center;
  gap: var(--wb-spacing-component-lg);
}
.followup__fields {
  flex: 1;
  min-width: 0;
  display: grid;
}
.followup__actions {
  display: flex;
  flex: none;
  align-items: center;
  gap: 0;
  box-sizing: border-box;
  height: var(--wb-asset-wb-followup-rows-height);
  padding: 0;
  border: 1px solid var(--wb-color-border);
  border-radius: var(--wb-radius-sm);
  background: var(--wb-color-surface-container);
}
.followup__action {
  width: var(--wb-asset-wb-followup-rows-action-cell);
  display: grid;
  place-items: center;
}
.followup__actions::before {
  content: '';
  order: 1;
  height: var(--wb-asset-wb-followup-rows-divider-height);
  width: var(--wb-asset-wb-followup-rows-divider-width);
  background: var(--wb-color-border);
}
.followup__actions > :last-child {
  order: 2;
}
</style>
