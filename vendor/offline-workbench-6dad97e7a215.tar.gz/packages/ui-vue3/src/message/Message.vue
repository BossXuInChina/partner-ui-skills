<script setup>
import { messageNativeGeometry } from './messageNativeGeometry.js';
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import './message-motion.css';
import { computed, onBeforeUnmount, ref, watch } from 'vue';
import { createAutoDismiss, normalizeDuration } from '../feedback/autoDismiss.js';
import { registerFeedbackHost } from '../overlay/isolation.js';
import WorkbenchCheckbox from '../choice/WorkbenchCheckbox.vue';
import WorkbenchLink from '../link/WorkbenchLink.vue';
import WorkbenchStatusIcon from '../icons/WorkbenchStatusIcon.vue';
import WorkbenchLoading from '../loading/WorkbenchLoading.vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';

const statusIconSemantics = {
  info: 'info',
  success: 'success',
  warning: 'warning',
  danger: 'alert-orange',
  critical: 'alert-red',
  error: 'close_circle',
};

const props = defineProps({
  modelValue: { type: Boolean, default: false },
  type: { type: String, default: 'info', validator: value => ['info', 'success', 'warning', 'danger', 'critical', 'error', 'loading'].includes(value) },
  message: { type: String, required: true },
  messageKey: { type: [String, Number], default: '' },
  linkLabel: { type: String, default: '' },
  linkHref: { type: String, default: '' },
  checkboxLabel: { type: String, default: '' },
  checkboxChecked: { type: Boolean, default: false },
  showIcon: { type: Boolean, default: true },
  showClose: { type: Boolean, default: true },
  placement: { type: String, default: 'global', validator: value => ['global', 'dialog'].includes(value) },
  autoClose: { type: Number, default: undefined },
});

const emit = defineEmits(['update:modelValue', 'update:checkboxChecked', 'close', 'link']);
const globalHost = ref(null);
let releaseFeedback = null;
watch(
  globalHost,
  (root) => {
    releaseFeedback?.();
    releaseFeedback = root ? registerFeedbackHost(root) : null;
  },
  { flush: 'post' },
);
const timer = createAutoDismiss(() => dismiss('timeout'));
const effectiveDuration = computed(() => {
  if (props.type === 'loading') return 0;
  const fallback = props.placement === 'global' || props.showClose ? 2000 : 7000;
  return normalizeDuration(props.autoClose, fallback);
});
const role = computed(() => ['critical', 'error'].includes(props.type) ? 'alert' : 'status');
const isLoading = computed(() => props.type === 'loading');
const statusIconName = computed(() => `${statusIconSemantics[props.type]}/solid/16`);

function clearTimer() { timer.dispose(); }
function dismiss(reason) {
  clearTimer();
  if (!props.modelValue) return;
  emit('update:modelValue', false);
  emit('close', reason);
}
function schedule() {
  if (!props.modelValue) { timer.dispose(); return; }
  timer.reset(effectiveDuration.value);
}
function activateLink() { emit('link', { href: props.linkHref }); }

watch(() => [props.modelValue, props.messageKey, props.message, props.type, props.showClose, props.placement, props.autoClose], schedule, { immediate: true });
onBeforeUnmount(() => { clearTimer(); releaseFeedback?.(); });
</script>

<template>
  <Teleport v-if="placement === 'global'" to="body">
    <Transition name="message" appear>
      <section :style="messageNativeGeometry" v-if="modelValue" ref="globalHost" :key="messageKey || message" class="wb-message wb-message--global" :class="[`wb-message--${type}`, { 'has-icon': showIcon, 'has-close': showClose }]" @mouseenter="timer.pause('pointer')" @mouseleave="timer.resume('pointer')" @focusin="timer.pause('focus')" @focusout="!$event.currentTarget.contains($event.relatedTarget) && timer.resume('focus')" :role="role" :aria-live="role === 'status' ? 'polite' : 'assertive'">
        <div class="wb-message__main">
          <span v-if="showIcon && isLoading" class="wb-message__icon wb-message__icon--loading" aria-hidden="true"><WorkbenchLoading :size="14" /></span>
          <span v-else-if="showIcon" class="wb-message__icon" :data-status-icon="statusIconName"><WorkbenchStatusIcon :name="statusIconName" /></span>
          <div class="wb-message__body">
            <p class="wb-message__copy">{{ message }}<WorkbenchLink v-if="linkLabel && linkHref" :href="linkHref" class="wb-message__link" @click="activateLink">{{ linkLabel }}</WorkbenchLink></p>
            <WorkbenchCheckbox v-if="checkboxLabel" class="wb-message__checkbox" :model-value="checkboxChecked" :label="checkboxLabel" :no-wrap="true" @update:model-value="emit('update:checkboxChecked', $event)" />
          </div>
        </div>
        <button v-if="showClose" class="wb-message__close" type="button" aria-label="关闭提示" @click="dismiss('button')"><WorkbenchIcon name="/ic_public_close_line_10px" /></button>
      </section>
    </Transition>
  </Teleport>
  <Transition v-else name="message" appear>
    <section :style="messageNativeGeometry" v-if="modelValue" :key="messageKey || message" class="wb-message wb-message--dialog" :class="[`wb-message--${type}`, { 'has-icon': showIcon, 'has-close': showClose }]" @mouseenter="timer.pause('pointer')" @mouseleave="timer.resume('pointer')" @focusin="timer.pause('focus')" @focusout="!$event.currentTarget.contains($event.relatedTarget) && timer.resume('focus')" :role="role" :aria-live="role === 'status' ? 'polite' : 'assertive'">
      <div class="wb-message__main">
        <span v-if="showIcon && isLoading" class="wb-message__icon wb-message__icon--loading" aria-hidden="true"><WorkbenchLoading :size="14" /></span>
        <span v-else-if="showIcon" class="wb-message__icon" :data-status-icon="statusIconName"><WorkbenchStatusIcon :name="statusIconName" /></span>
        <div class="wb-message__body">
          <p class="wb-message__copy">{{ message }}<WorkbenchLink v-if="linkLabel && linkHref" :href="linkHref" class="wb-message__link" @click="activateLink">{{ linkLabel }}</WorkbenchLink></p>
          <WorkbenchCheckbox v-if="checkboxLabel" class="wb-message__checkbox" :model-value="checkboxChecked" :label="checkboxLabel" :no-wrap="true" @update:model-value="emit('update:checkboxChecked', $event)" />
        </div>
      </div>
      <button v-if="showClose" class="wb-message__close" type="button" aria-label="关闭提示" @click="dismiss('button')"><WorkbenchIcon name="/ic_public_close_line_10px" /></button>
    </section>
  </Transition>
</template>

<style>
.wb-message { --message-icon-space: 0; --message-close-space: 0; display: inline-flex; width: max-content; max-width: min(var(--wb-asset-wb-message-max-width), calc(100vw - var(--wb-spacing-component-lg) * 2)); align-items: flex-start; box-sizing: border-box; padding: var(--wb-spacing-component-md); border-radius: var(--wb-radius-lg); color: var(--wb-color-text-primary); background: var(--wb-color-surface-overlay); box-shadow: var(--wb-shadow-lg); }
.wb-message.has-icon { --message-icon-space: calc(var(--wb-asset-wb-message-status-icon-size) + var(--wb-spacing-component-sm)); }
.wb-message.has-close { --message-close-space: calc(var(--message-close-width) + var(--wb-spacing-component-lg)); }
.wb-message--global { position: fixed; z-index: var(--wb-asset-wb-message-layer); top: var(--wb-asset-wb-message-global-top-offset); left: 50%; transform: translateX(-50%); }
.wb-message--dialog { max-width: min(var(--wb-asset-wb-message-max-width), calc(100% - var(--wb-asset-wb-scrollbar-scrollbar-width))); position: absolute; z-index: var(--wb-asset-wb-message-dialog-layer); inset-block-start: 0; inset-inline-start: calc(50% - var(--wb-asset-wb-scrollbar-scrollbar-width) / 2); transform: translateX(-50%); }
.wb-modal__content:has(.wb-message--dialog) { position: relative; overflow: visible; }
.wb-message__main { display: inline-flex; min-width: 0; max-width: 100%; flex: 1 1 auto; align-items: flex-start; }
.wb-message.has-icon .wb-message__main { gap: var(--wb-spacing-component-sm); }
.wb-message__body { display: flex; min-width: 0; max-width: calc(min(var(--wb-asset-wb-message-max-width), calc(100vw - var(--wb-spacing-component-lg) - var(--wb-spacing-component-lg))) - var(--wb-spacing-component-md) - var(--wb-spacing-component-md) - var(--message-icon-space) - var(--message-close-space)); flex: 0 1 auto; align-items: center; flex-wrap: wrap; column-gap: var(--wb-spacing-component-lg); row-gap: var(--wb-spacing-component-sm); }
.wb-message__icon { display: flex; flex: 0 0 auto; align-items: center; margin-block-start: calc((var(--wb-font-body-m-line-height) - var(--wb-asset-wb-message-status-icon-size)) / 2); }
.wb-message__copy { min-width: 0; max-width: 100%; flex: 0 1 auto; margin: 0; overflow-wrap: anywhere; font-size: var(--wb-font-body-m-font-size); font-weight: var(--wb-font-body-m-font-weight); line-height: var(--wb-font-body-m-line-height); letter-spacing: var(--wb-font-body-m-letter-spacing); }
.wb-message__link { display: inline-flex; margin-inline-start: var(--wb-spacing-component-sm); white-space: nowrap; }
.wb-message__checkbox { flex: 0 0 auto; }
.wb-message__close { display: inline-flex; flex: 0 0 auto; align-items: center; justify-content: center; width: auto; height: var(--wb-font-body-m-line-height); margin-inline-start: var(--wb-spacing-component-lg); padding: 0; border: 0; color: var(--wb-color-icon-primary); background: transparent; cursor: pointer;  }
.wb-message__close:hover { color: var(--wb-color-icon-hover); }
.wb-message__close:active { color: var(--wb-color-icon-active); }
.wb-message__close:focus-visible { outline: 1px solid var(--wb-color-border-focus); outline-offset: 2px; }
</style>
