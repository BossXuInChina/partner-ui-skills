<script setup>
import { messageNativeGeometry } from './messageNativeGeometry.js';
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import './message-motion.css';
import { computed, onBeforeUnmount, watch } from 'vue';
import { createAutoDismiss, normalizeDuration } from '../feedback/autoDismiss.js';
import { registerFeedbackHost } from '../overlay/isolation.js';
import WorkbenchCheckbox from '../choice/WorkbenchCheckbox.vue';
import WorkbenchLink from '../link/WorkbenchLink.vue';
import WorkbenchStatusIcon from '../icons/WorkbenchStatusIcon.vue';
import WorkbenchLoading from '../loading/WorkbenchLoading.vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';

const props = defineProps({ items: { type: Array, default: () => [] }, autoClose: { type: Number, default: undefined } });
const emit = defineEmits(['dismiss', 'link', 'checkbox']);
const statusIconSemantics = { info: 'info', success: 'success', warning: 'warning', danger: 'alert-orange', critical: 'alert-red', error: 'close_circle' };
const visibleItems = computed(() => props.items.slice(0, 2));
const statusIconName = type => `${statusIconSemantics[type]}/solid/16`;
const timers = new Map();
const replacementTimers = new Map();
const dismissed = new Set();
const feedbackRefs = new Map();
const feedbackReleases = new Map();
function feedbackRef(id) {
  if (!feedbackRefs.has(id))
    feedbackRefs.set(id, (root) => {
      const previous = feedbackReleases.get(id);
      if (previous?.root === root) return;
      previous?.release();
      if (root) feedbackReleases.set(id, { root, release: registerFeedbackHost(root) });
      else feedbackReleases.delete(id);
    });
  return feedbackRefs.get(id);
}

function dismiss(item, reason) {
  if (!item || dismissed.has(item.id)) return;
  dismissed.add(item.id); timers.get(item.id)?.timer.dispose();
  clearTimeout(replacementTimers.get(item.id)); replacementTimers.delete(item.id);
  emit('dismiss', { id: item.id, reason });
}
watch(() => props.items.map(item => [item.id, item.messageKey, item.message, item.type, props.autoClose]), () => {
  const ids = new Set(props.items.map(item => item.id));
  for (const id of feedbackRefs.keys()) if (!ids.has(id)) feedbackRefs.delete(id);
  for (const [id, entry] of timers) if (!ids.has(id)) { entry.timer.dispose(); timers.delete(id); }
  for (const [id, replacementTimer] of replacementTimers) if (!ids.has(id)) { clearTimeout(replacementTimer); replacementTimers.delete(id); }
  for (const id of dismissed) if (!ids.has(id)) dismissed.delete(id);
  for (const item of props.items.slice(1)) {
    if (replacementTimers.has(item.id) || dismissed.has(item.id)) continue;
    replacementTimers.set(item.id, setTimeout(() => dismiss(item, 'replaced'), 200));
  }
  for (const item of props.items.slice(0, 1)) {
    const signature = JSON.stringify([item.messageKey, item.message, item.type, props.autoClose]);
    const entry = timers.get(item.id);
    if (entry?.signature === signature) continue;
    dismissed.delete(item.id);
    const timer = entry?.timer || createAutoDismiss(() => dismiss(item, 'timeout'));
    timers.set(item.id, { timer, signature });
    timer.reset(item.type === 'loading' ? 0 : normalizeDuration(props.autoClose, 2000));
  }
}, { immediate: true });
onBeforeUnmount(() => { for (const entry of feedbackReleases.values()) entry.release(); feedbackReleases.clear(); feedbackRefs.clear(); for (const entry of timers.values()) entry.timer.dispose(); for (const replacementTimer of replacementTimers.values()) clearTimeout(replacementTimer); });
</script>

<template>
  <Teleport to="body">
    <TransitionGroup appear name="message" tag="section" class="wb-message-stack" aria-label="全局操作反馈">
      <section :style="messageNativeGeometry" v-for="(item, index) in visibleItems" :key="item.id" :ref="feedbackRef(item.id)" @mouseenter="timers.get(item.id)?.timer.pause('pointer')" @mouseleave="timers.get(item.id)?.timer.resume('pointer')" @focusin="timers.get(item.id)?.timer.pause('focus')" @focusout="!$event.currentTarget.contains($event.relatedTarget) && timers.get(item.id)?.timer.resume('focus')" class="wb-message wb-message--stack" :class="[`wb-message--${item.type}`, { 'has-icon': item.showIcon !== false, 'has-close': item.showClose !== false, 'is-replacing': index > 0 }]" :role="['critical', 'error'].includes(item.type) ? 'alert' : 'status'" :aria-live="['critical', 'error'].includes(item.type) ? 'assertive' : 'polite'">
        <div class="wb-message__main"><span v-if="item.showIcon !== false && item.type === 'loading'" class="wb-message__icon wb-message__icon--loading" aria-hidden="true"><WorkbenchLoading :size="14" /></span><span v-else-if="item.showIcon !== false" class="wb-message__icon" :data-status-icon="statusIconName(item.type)"><WorkbenchStatusIcon :name="statusIconName(item.type)" /></span><div class="wb-message__body"><p class="wb-message__copy">{{ item.message }}<WorkbenchLink v-if="item.linkLabel && item.linkHref" :href="item.linkHref" class="wb-message__link" @click="emit('link', { id: item.id, href: item.linkHref })">{{ item.linkLabel }}</WorkbenchLink></p><WorkbenchCheckbox v-if="item.checkboxLabel" class="wb-message__checkbox" :model-value="item.checkboxChecked === true" :label="item.checkboxLabel" :no-wrap="true" @update:model-value="emit('checkbox', { id: item.id, checked: $event })" /></div></div>
        <button v-if="item.showClose !== false" class="wb-message__close" type="button" aria-label="关闭提示" @click="dismiss(item, 'button')"><WorkbenchIcon name="/ic_public_close_line_10px" /></button>
      </section>
    </TransitionGroup>
  </Teleport>
</template>

<style>
.wb-message-stack { position: fixed; z-index: var(--wb-asset-wb-message-layer); top: var(--wb-asset-wb-message-global-top-offset); left: 50%; display: grid; width: fit-content; max-width: min(var(--wb-asset-wb-message-max-width), calc(100vw - var(--wb-spacing-component-lg) * 2)); gap: var(--wb-spacing-component-sm); margin: 0; padding: 0; transform: translateX(-50%); }
.wb-message-stack .wb-message { --message-icon-space:0; --message-close-space:0; display: inline-flex; width: max-content; max-width: 100%; align-items: flex-start; box-sizing: border-box; padding: var(--wb-spacing-component-md); border-radius: var(--wb-radius-lg); color: var(--wb-color-text-primary); background: var(--wb-color-surface-overlay); box-shadow: var(--wb-shadow-lg); }.wb-message-stack .wb-message.has-icon { --message-icon-space:calc(var(--wb-icon-size-16) + var(--wb-spacing-component-sm)); }.wb-message-stack .wb-message.has-close { --message-close-space:calc(var(--wb-icon-size-16) + var(--wb-spacing-component-lg)); }
.wb-message-stack .wb-message.is-replacing { opacity: 0; transition: transform var(--wb-asset-wb-message-motion-duration) var(--wb-asset-wb-message-motion-easing), opacity var(--wb-asset-wb-message-motion-duration) var(--wb-asset-wb-message-motion-easing); }
.wb-message-stack .wb-message__main { display: inline-flex; min-width: 0; max-width:100%; flex:1 1 auto; align-items: flex-start; }.wb-message-stack .wb-message.has-icon .wb-message__main { gap: var(--wb-spacing-component-sm); }.wb-message-stack .wb-message__body { display:flex; min-width:0; max-width:calc(min(var(--wb-asset-wb-message-max-width), calc(100vw - var(--wb-spacing-component-lg) - var(--wb-spacing-component-lg))) - var(--wb-spacing-component-md) - var(--wb-spacing-component-md) - var(--message-icon-space) - var(--message-close-space)); flex:0 1 auto; align-items:flex-start; flex-wrap:wrap; column-gap:var(--wb-spacing-component-lg); row-gap:var(--wb-spacing-component-sm); }.wb-message-stack .wb-message__icon { display:grid; flex:0 0 auto; margin-block-start:calc((var(--wb-font-body-m-line-height) - var(--wb-icon-size-16)) / 2); place-items:center; border-radius:var(--wb-radius-full); color:var(--wb-color-text-inverse); background:var(--message-status-color); font-size:var(--wb-font-body-s-font-size); font-weight:var(--wb-font-body-s-font-weight); line-height:var(--wb-font-body-s-line-height); letter-spacing:var(--wb-font-body-s-letter-spacing); }.wb-message-stack .wb-message--danger .wb-message__icon,.wb-message-stack .wb-message--critical .wb-message__icon { border-radius:0; clip-path:polygon(50% 2%,100% 94%,0 94%); }.wb-message-stack .wb-message--info,.wb-message-stack .wb-message--loading { --message-status-color:var(--wb-color-info-primary); }.wb-message-stack .wb-message--success { --message-status-color:var(--wb-color-success); }.wb-message-stack .wb-message--warning { --message-status-color:var(--wb-color-warning); }.wb-message-stack .wb-message--danger { --message-status-color:var(--wb-color-alert); }.wb-message-stack .wb-message--critical,.wb-message-stack .wb-message--error { --message-status-color:var(--wb-color-error); }.wb-message-stack .wb-message--warning .wb-message__icon { color:var(--wb-color-text-primary); }.wb-message-stack .wb-message--loading .wb-message__icon { color:var(--message-status-color); background:transparent; }.wb-message-stack .wb-message__copy { min-width:0; max-width:100%; flex:0 1 auto; margin:0; overflow-wrap:anywhere; font:var(--wb-font-body-m-font-weight) var(--wb-font-body-m-font-size)/var(--wb-font-body-m-line-height) var(--wb-font-body-m-font-family); }.wb-message-stack .wb-message__link { display:inline-flex; margin-inline-start:var(--wb-spacing-component-sm); white-space:nowrap; }.wb-message-stack .wb-message__checkbox { flex:0 0 auto; }.wb-message-stack .wb-message__close { display:inline-flex; flex:0 0 auto; align-items:center; justify-content:center; cursor:pointer; width: auto; height: auto; margin-inline-start:var(--wb-spacing-component-lg); padding:0; border:0; color:var(--wb-color-icon-primary); background:transparent;  }
.wb-message-stack .wb-message__close:hover { color: var(--wb-color-icon-hover); }
.wb-message-stack .wb-message__close:active { color: var(--wb-color-icon-active); }
.wb-message-stack .wb-message__close:focus-visible { outline: 1px solid var(--wb-color-border-focus); outline-offset: 2px; }
.wb-message-stack .wb-message.has-close { --message-close-space: calc(var(--message-close-width) + var(--wb-spacing-component-lg)); }
.wb-message-stack .wb-message__body { align-items: center; }
.wb-message-stack .wb-message__icon { margin-block-start: calc((var(--wb-font-body-m-line-height) - var(--wb-asset-wb-message-status-icon-size)) / 2); }
.wb-message-stack .wb-message__close { height: var(--wb-font-body-m-line-height); }

.wb-message-stack .wb-message__icon { background: transparent; border-radius: 0; clip-path: none; }
.wb-message-stack .wb-message--danger .wb-message__icon, .wb-message-stack .wb-message--critical .wb-message__icon { clip-path: none; }
</style>
