import { systemIcons } from '../icons/families/system.js';

// Reserve the exact same registered native frame as the rendered close icon.
// This is layout geometry; it cannot resize or repaint the asset.
const { icon, error } = systemIcons.resolve('/ic_public_close_line_10px');
if (!icon) throw new Error(error);
export const messageNativeGeometry = Object.freeze({
  '--message-close-width': `${icon.native.width}px`,
});
