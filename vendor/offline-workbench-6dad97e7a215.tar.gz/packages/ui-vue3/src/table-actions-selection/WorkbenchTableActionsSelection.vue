<script setup>
import { computed, useAttrs, useSlots } from 'vue';
import WorkbenchTable from '../table/WorkbenchTable.vue';
import { mergePageSelection } from './useCrossPageSelection.js';

defineOptions({ inheritAttrs: false });
const props = defineProps({
  caption: { type: String, default: '' },
  columns: { type: Array, required: true },
  rows: { type: Array, required: true },
  selectedIds: { type: Array, required: true },
  rowKey: { type: [String, Function], default: 'id' },
  sort: { type: Object, default: null },
  page: { type: Number, default: 1 },
  pageSize: { type: Number, default: 10 },
  total: { type: Number, default: null },
  selectionFixed: { type: Boolean, default: false },
  actionsFixed: { type: Boolean, default: false },
  rowActions: { type: [Array, Function], default: () => [] },
});
const emit = defineEmits([
  'update:selectedIds',
  'selection-change',
  'update:sort',
  'sort-change',
  'column-filter',
  'update:page',
  'page-change',
  'update:pageSize',
  'page-size-change',
  'row-action',
]);
const attrs = useAttrs();
const slots = useSlots();
const slottedColumns = () => props.columns.filter((column) => slots[`cell-${column.key}`]);
const visibleSelectedIds = computed(() => {
  const selected = new Set(props.selectedIds);
  return props.rows
    .map((row) => (typeof props.rowKey === 'function' ? props.rowKey(row) : row[props.rowKey]))
    .filter((id) => selected.has(id));
});
function onSelectionChange(payload) {
  const next = mergePageSelection({
    pageRows: props.rows,
    selectedIds: props.selectedIds,
    rowKey: props.rowKey,
    ...payload,
  });
  if (next !== props.selectedIds) emit('update:selectedIds', next);
  emit('selection-change', { ...payload, selectedIds: next });
}
</script>

<template>
  <WorkbenchTable
    v-bind="attrs"
    class="wb-table-actions-selection"
    :caption="caption"
    :columns="columns"
    :rows="rows"
    :row-key="rowKey"
    :sort="sort"
    :page="page"
    :page-size="pageSize"
    :total="total"
    :selection-fixed="selectionFixed"
    :actions-fixed="actionsFixed"
    :row-actions="rowActions"
    selectable
    :selected-row-keys="visibleSelectedIds"
    @selection-change="onSelectionChange"
    @update:sort="emit('update:sort', $event)"
    @sort-change="emit('sort-change', $event)"
    @column-filter="emit('column-filter', $event)"
    @update:page="emit('update:page', $event)"
    @page-change="emit('page-change', $event)"
    @update:page-size="emit('update:pageSize', $event)"
    @page-size-change="emit('page-size-change', $event)"
    @row-action="emit('row-action', $event)"
  >
    <template
      v-if="$slots['toolbar-leading']"
      #toolbar-leading="slotProps"
      ><slot
        name="toolbar-leading"
        v-bind="slotProps || {}"
    /></template>
    <template
      v-if="$slots['toolbar-actions']"
      #toolbar-actions="slotProps"
      ><slot
        name="toolbar-actions"
        v-bind="slotProps || {}"
    /></template>
    <template
      v-if="$slots['row-actions']"
      #row-actions="slotProps"
      ><slot
        name="row-actions"
        v-bind="slotProps || {}"
    /></template>
    <template
      v-for="column in slottedColumns()"
      #[`cell-${column.key}`]="slotProps"
      ><slot
        :name="`cell-${column.key}`"
        v-bind="slotProps || {}"
    /></template>
  </WorkbenchTable>
</template>
