import { computed, ref } from 'vue';

// Table reports current-page keys. Retain keys from other pages by a stable row ID.
const keyOf = (row, rowKey) => (typeof rowKey === 'function' ? rowKey(row) : row[rowKey]);
// Preserve selections from other pages while replacing selection on the current page.
export function mergePageSelection({
  pageRows,
  selectedIds,
  selectedRowKeys = [],
  source,
  rowKey = 'id',
}) {
  if (source === 'external-page-change' || source === 'external-page-size-change')
    return selectedIds;
  if (source === 'clear') return [];
  const currentPageIds = new Set(pageRows.map((row) => keyOf(row, rowKey)));
  const next = new Set(selectedIds.filter((id) => !currentPageIds.has(id)));
  for (const id of selectedRowKeys) if (currentPageIds.has(id)) next.add(id);
  return [...next];
}

export function useCrossPageSelection({ pageRows, selectedIds = ref([]), rowKey = 'id' }) {
  const visibleSelectedIds = computed(() => {
    const selected = new Set(selectedIds.value);
    return pageRows.value.map((row) => keyOf(row, rowKey)).filter((id) => selected.has(id));
  });
  const selectedCount = computed(() => selectedIds.value.length);
  function updateSelection(payload = {}) {
    selectedIds.value = mergePageSelection({
      pageRows: pageRows.value,
      selectedIds: selectedIds.value,
      rowKey,
      ...payload,
    });
  }
  function clearSelection() {
    selectedIds.value = [];
  }
  function removeIds(ids) {
    const removed = new Set(ids);
    selectedIds.value = selectedIds.value.filter((id) => !removed.has(id));
  }
  return {
    selectedIds,
    visibleSelectedIds,
    selectedCount,
    updateSelection,
    clearSelection,
    removeIds,
  };
}
