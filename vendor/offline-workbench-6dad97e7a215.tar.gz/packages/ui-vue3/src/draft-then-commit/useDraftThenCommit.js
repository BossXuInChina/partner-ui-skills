import { computed, readonly, ref } from 'vue';

const copy = (value) => JSON.parse(JSON.stringify(value));
/** JSON-data flow. Confirmation, persistence and notifications belong to the host. */
export function useDraftThenCommit(initial = {}) {
  const record = ref(copy(initial));
  const pending = ref(false);
  const error = ref(null);
  let revision = 0;
  const stage = computed(() =>
    record.value.arranged != null
      ? record.value.result
        ? 'resulted'
        : 'arranged'
      : record.value.draft != null
        ? 'draft'
        : 'pending',
  );
  function reset(value = initial) {
    const next = copy(value);
    revision += 1;
    record.value = next;
    pending.value = false;
    error.value = null;
  }
  function saveDraft(value) {
    if (pending.value || record.value.arranged != null) return false;
    record.value = { ...record.value, draft: copy(value) };
    error.value = null;
    return true;
  }
  async function commit(action, confirm) {
    if (pending.value || record.value.arranged != null) return { ok: false, reason: 'unavailable' };
    if (typeof action !== 'function') throw new TypeError('A host commit action is required');
    const ticket = ++revision;
    pending.value = true;
    error.value = null;
    try {
      const input = copy(record.value.draft ?? record.value.defaults ?? {});
      if (confirm && !(await confirm(copy(input)))) return { ok: false, reason: 'cancelled' };
      if (ticket !== revision) return { ok: false, reason: 'stale' };
      const arranged = await action(copy(input));
      if (ticket !== revision) return { ok: false, reason: 'stale' };
      if (arranged == null) throw new TypeError('Commit must return the saved arrangement');
      record.value = { ...record.value, arranged: copy(arranged), draft: null, result: '' };
      return { ok: true };
    } catch (cause) {
      if (ticket !== revision) return { ok: false, reason: 'stale' };
      error.value = cause;
      return { ok: false, reason: 'failed', error: cause };
    } finally {
      if (ticket === revision) pending.value = false;
    }
  }
  function updateResult({ status, result }) {
    if (pending.value || record.value.arranged == null) return false;
    record.value = { ...record.value, arranged: { ...record.value.arranged, status }, result };
    return true;
  }
  return {
    record: readonly(record),
    stage,
    pending: readonly(pending),
    error: readonly(error),
    saveDraft,
    commit,
    updateResult,
    reset,
  };
}
export default useDraftThenCommit;
