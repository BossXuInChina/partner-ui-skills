import type { WorkbenchUiRegistry } from '@workbench/ui-contracts';

export { default as WorkbenchCard } from './card/WorkbenchCard.vue';
export { default as WorkbenchCardGrid } from './card/WorkbenchCardGrid.vue';
export { default as WorkbenchLink } from './link/WorkbenchLink.vue';
export { default as WorkbenchTag } from './tag/WorkbenchTag.vue';

export const workbenchVue3Registry: WorkbenchUiRegistry = Object.freeze({
  framework: 'vue3',
  productionEligible: false,
  assets: Object.freeze({}),
});

export { default as WorkbenchDropdown } from './dropdown/WorkbenchDropdown.vue';
export { default as WorkbenchBreadcrumb } from './breadcrumb/WorkbenchBreadcrumb.vue';
export { default as WorkbenchPagination } from './pagination/WorkbenchPagination.vue';
export { default as WorkbenchTabs } from './tabs/WorkbenchTabs.vue';
export { default as WorkbenchButtonRadioGroup } from './button-radio-group/WorkbenchButtonRadioGroup.vue';
export { default as WorkbenchCarousel } from './carousel/WorkbenchCarousel.vue';
export { default as WorkbenchPopover } from './popover/WorkbenchPopover.vue';
export { default as WorkbenchNumberCount } from './number-count/WorkbenchNumberCount.vue';
export { default as WorkbenchRating } from './rating/WorkbenchRating.vue';
export { default as WorkbenchSlider } from './slider/WorkbenchSlider.vue';
export { default as WorkbenchSwitch } from './switch/WorkbenchSwitch.vue';

export { default as WorkbenchAlert } from './alert/Alert.vue';
export { default as WorkbenchLoading } from './loading/WorkbenchLoading.vue';
export { default as WorkbenchSkeleton } from './skeleton/WorkbenchSkeleton.vue';
export { default as WorkbenchMessage } from './message/Message.vue';
export { default as WorkbenchNotification } from './notification/NotificationStack.vue';
export { default as WorkbenchFeedbackDialog } from './feedback-dialog/FeedbackDialog.vue';
export { default as WorkbenchPopconfirm } from './popconfirm/WorkbenchPopconfirm.vue';
export { default as WorkbenchFloatingButton } from './floating-button/FloatingButton.vue';
export { default as WorkbenchTooltip } from './tooltip/WorkbenchTooltip.vue';
export { default as GlobalMessageStack } from './message/GlobalMessageStack.vue';
export { default as WorkbenchSkeletonBlock } from './skeleton/WorkbenchSkeletonBlock.vue';
export { default as WorkbenchBadge } from './badge/WorkbenchBadge.vue';
export { default as WorkbenchForm } from './form/WorkbenchForm.vue';
export { default as WorkbenchFormItem } from './form/WorkbenchFormItem.vue';
export { default as WorkbenchFormGroup } from './form/WorkbenchFormGroup.vue';
export { default as WorkbenchTable } from './table/WorkbenchTable.vue';
export { default as WorkbenchDataToolbar } from './table/WorkbenchDataToolbar.vue';
export { default as WorkbenchTopNav } from './top-nav/WorkbenchTopNav.vue';

// Export names follow the approved asset, not the file name — the same rule already used for
// `FeedbackDialog.vue` -> `WorkbenchFeedbackDialog` and `NotificationStack.vue` ->
// `WorkbenchNotification`. These exports complete the surface so every approved component's
// implementation is reachable from the package entry; they do not declare any asset consumable
// (`workbenchVue3Registry.assets` stays empty and `productionEligible` stays false).
export { default as WorkbenchButton } from './button/WorkbenchButton.vue';
export { default as WorkbenchCheckbox } from './choice/WorkbenchCheckbox.vue';
export { default as WorkbenchCollapse } from './collapse/WorkbenchCollapse.vue';
export { default as WorkbenchDrawer } from './drawer/WorkbenchDrawer.vue';
export { default as WorkbenchInput } from './input/WorkbenchInput.vue';
export { default as WorkbenchModal } from './modal/WorkbenchModal.vue';
export { default as WorkbenchRadio } from './radio/WorkbenchRadio.vue';
export { default as WorkbenchScrollbar } from './scrollbar/WorkbenchScrollbar.vue';
export { default as WorkbenchSearch } from './search/WorkbenchSearch.vue';
export { default as WorkbenchSelect } from './select/WorkbenchSelect.vue';

// Existing Collapse composition support; inherits its parent asset qualification.
export { default as WorkbenchCollapseItem } from './collapse/WorkbenchCollapseItem.vue';

export { default as WorkbenchCompanyProfileShell } from './company-profile-shell/WorkbenchCompanyProfileShell.vue';
export { default as WorkbenchDraftListFilter } from './draft-list-filter/WorkbenchDraftListFilter.vue';
export { default as WorkbenchManagementFormModal } from './management-form-modal/WorkbenchManagementFormModal.vue';
export { default as WorkbenchTableActionsSelection } from './table-actions-selection/WorkbenchTableActionsSelection.vue';
export { default as WorkbenchNestedConfirmation } from './nested-confirmation/WorkbenchNestedConfirmation.vue';

export { default as WorkbenchIcon } from './icons/WorkbenchIcon.vue';
export { default as WorkbenchSystemIcon } from './icons/WorkbenchSystemIcon.vue';
export { default as WorkbenchStatusIcon } from './icons/WorkbenchStatusIcon.vue';
export { default as WorkbenchFileIcon } from './icons/file/WorkbenchFileIcon.vue';
export { default as WorkbenchEmptyIcon } from './icons/empty/WorkbenchEmptyIcon.vue';
export { default as WorkbenchPedestalIcon } from './pedestal-icon/WorkbenchPedestalIcon.vue';
export { default as WorkbenchEmptyState } from './empty-state/WorkbenchEmptyState.vue';
export { default as WorkbenchSideNavigation } from './side-navigation/WorkbenchSideNavigation.vue';

// Batch-registered prototype components; production eligibility remains false.
export { default as WorkbenchSteps } from './steps/WorkbenchSteps.vue';
export { default as WorkbenchFooter } from './footer/WorkbenchFooter.vue';
export { default as WorkbenchTree } from './tree/WorkbenchTree.vue';
export { default as WorkbenchTimeline } from './timeline/WorkbenchTimeline.vue';
export { default as WorkbenchTransfer } from './transfer/WorkbenchTransfer.vue';
export { default as WorkbenchTransferPanel } from './transfer/TransferPanel.vue';
export { default as WorkbenchCascader } from './cascader/WorkbenchCascader.vue';
export { default as WorkbenchCascaderOverflow } from './cascader/CascaderOverflow.vue';
export { default as WorkbenchCascaderPanel } from './cascader/CascaderPanel.vue';
export { default as WorkbenchChart } from './chart/WorkbenchChart.vue';
export { default as WorkbenchDatePanel } from './date-picker/WorkbenchDatePanel.vue';
export { default as WorkbenchDatePicker } from './date-picker/WorkbenchDatePicker.vue';
export { default as WorkbenchTimePicker } from './time-picker/WorkbenchTimePicker.vue';
export { default as WorkbenchImageUpload } from './image-upload/WorkbenchImageUpload.vue';
export { default as WorkbenchImageUploadTile } from './image-upload/ImageUploadTile.vue';
export { default as WorkbenchUpload } from './upload/WorkbenchUpload.vue';
export { default as WorkbenchUploadFileItem } from './upload/UploadFileItem.vue';
export { default as WorkbenchUploadFileList } from './upload/UploadFileList.vue';

export { default as WorkbenchAvatar } from './avatar/WorkbenchAvatar.vue';
export { default as WorkbenchAvatarGroup } from './avatar/WorkbenchAvatarGroup.vue';

export type { TabItem } from '../types/public-contracts';

// Registered Card Blocks; local prototype qualification remains unchanged.
export { default as WorkbenchMetricCard } from './metric-card/WorkbenchMetricCard.vue';
export { default as WorkbenchInformationCard } from './information-card/WorkbenchInformationCard.vue';
export { default as WorkbenchMediaCard } from './media-card/WorkbenchMediaCard.vue';
export { default as WorkbenchQuickAppCard } from './quick-app-card/WorkbenchQuickAppCard.vue';
export type * from '../types/card-blocks';

// Registered homepage Blocks (2026-11-04); prototype-only qualification.
export { default as WorkbenchEventCalendar } from './event-calendar/WorkbenchEventCalendar.vue';
export { default as WorkbenchTabsHeader } from './tabs-header/WorkbenchTabsHeader.vue';
export { default as WorkbenchFilterChips } from './filter-chips/WorkbenchFilterChips.vue';
export { default as WorkbenchExpandCard } from './expand-card/WorkbenchExpandCard.vue';
export { default as WorkbenchPolicyLinks } from './policy-links/WorkbenchPolicyLinks.vue';
export { default as WorkbenchInfoList } from './info-list/WorkbenchInfoList.vue';
export { default as WorkbenchMoreAction } from './more-action/WorkbenchMoreAction.vue';
export { default as WorkbenchCertificationDetails } from './certification-details/WorkbenchCertificationDetails.vue';
export type * from '../types/home-blocks';

export { default as WorkbenchFollowupRows } from './followup-rows/WorkbenchFollowupRows.vue';

export { default as WorkbenchTransactionStageProgress } from './transaction-stage-progress/WorkbenchTransactionStageProgress.vue';

export { default as WorkbenchContentSection } from './content-section/WorkbenchContentSection.vue';

export { default as WorkbenchReadonlyFields } from './readonly-fields/WorkbenchReadonlyFields.vue';

export { default as useQueryTransaction } from './query-transaction/useQueryTransaction.js';

export { default as useScopedSelection } from './scoped-selection/useScopedSelection.js';

export { default as useStageBrowsing } from './stage-browsing/useStageBrowsing.js';

export { default as useEditTransaction } from './edit-transaction/useEditTransaction.js';

export { default as resolveContentState } from './content-state/contentState.js';

export { default as useDraftThenCommit } from './draft-then-commit/useDraftThenCommit.js';
