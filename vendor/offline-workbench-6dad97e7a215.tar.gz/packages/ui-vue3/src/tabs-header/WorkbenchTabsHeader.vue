<script setup lang="ts">
// Block: card-level tab header = rail tabs + optional corner count badges + right-side action slot.
import type { PropType } from 'vue';
import WorkbenchTabs from '../tabs/WorkbenchTabs.vue';
import WorkbenchBadge from '../badge/WorkbenchBadge.vue';
import type { TabsHeaderItem } from '../../types/home-blocks';
defineProps({
  modelValue: { type: [String, Number], required: true },
  items: { type: Array as PropType<TabsHeaderItem[]>, required: true },
  size: {
    type: String as PropType<'small' | 'large'>,
    default: 'large',
    validator: (value: string) => ['small', 'large'].includes(value),
  },
  ariaLabel: { type: String, default: '页签' },
});
const emit = defineEmits(['update:modelValue']);
</script>

<template>
  <div class="wb-tabs-header">
    <WorkbenchTabs
      class="wb-tabs-header__tabs"
      variant="rail"
      :size="size"
      :model-value="modelValue"
      :items="items"
      :aria-label="ariaLabel"
      @update:model-value="emit('update:modelValue', $event)"
    >
      <template #tab="{ item }">
        <WorkbenchBadge
          v-if="item.badge"
          variant="number"
          placement="corner"
          :value="item.badge"
          :aria-label="`${item.label} ${item.badge} 项`"
          >{{ item.label }}</WorkbenchBadge
        >
        <template v-else>{{ item.label }}</template>
      </template>
    </WorkbenchTabs>
    <div v-if="$slots.extra" class="wb-tabs-header__extra"><slot name="extra" /></div>
  </div>
</template>

<style>
.wb-tabs-header { position: relative; }
.wb-tabs-header__tabs { width: 100%; }
.wb-tabs-header__extra { position: absolute; top: 50%; right: 0; display: flex; align-items: center; gap: var(--wb-spacing-component-md); transform: translateY(-50%); }
</style>
