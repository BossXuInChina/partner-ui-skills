<script setup>
import { computed, useSlots, Comment, Fragment, Text } from 'vue';
const props = defineProps({
  title: { type: String, default: '' },
  headingLevel: { type: Number, default: 2 },
});
const headingTag = computed(
  () => `h${[1, 2, 3, 4, 5, 6].includes(props.headingLevel) ? props.headingLevel : 2}`,
);
const slots = useSlots();
const nonempty = (nodes) =>
  nodes?.some((node) =>
    node.type === Comment
      ? false
      : node.type === Fragment
        ? nonempty(node.children)
        : node.type === Text
          ? Boolean(String(node.children).trim())
          : true,
  );
const has = (name) => Boolean(slots[name] && nonempty(slots[name]()));
</script>

<template>
  <section class="content-section">
    <header
      v-if="title || has('heading') || has('meta') || has('actions')"
      class="content-section__header"
    >
      <div class="content-section__identity">
        <slot name="heading"
          ><component
            :is="headingTag"
            v-if="title"
            class="content-section__title"
            >{{ title }}</component
          ></slot
        >
      </div>
      <div
        v-if="has('actions')"
        class="content-section__actions"
      >
        <slot name="actions" />
      </div>
      <div
        v-if="has('meta')"
        class="content-section__meta"
      >
        <slot name="meta" />
      </div>
    </header>
    <div class="content-section__body"><slot /></div>
    <footer
      v-if="has('footer')"
      class="content-section__footer"
    >
      <slot name="footer" />
    </footer>
  </section>
</template>

<style scoped>
.content-section {
  min-width: 0;
}
.content-section__header {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  align-items: center;
  column-gap: var(--wb-spacing-layout-content-gap);
  row-gap: var(--wb-spacing-component-sm);
  margin-block-end: var(--wb-spacing-layout-content-gap);
}
.content-section__identity {
  min-width: 0;
}
.content-section__title {
  margin: 0;
  font: inherit;
  font-size: var(--wb-font-headline-s-font-size);
  font-weight: var(--wb-font-headline-s-font-weight);
  line-height: var(--wb-font-headline-s-line-height);
  letter-spacing: var(--wb-font-headline-s-letter-spacing);
}
.content-section__meta {
  flex-basis: 100%;
  color: var(--wb-color-text-secondary);
  font-size: var(--wb-font-body-m-font-size);
  line-height: var(--wb-font-body-m-line-height);
  font-weight: var(--wb-font-body-m-font-weight);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
}
.content-section__actions {
  display: flex;
  flex: none;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--wb-spacing-component-sm);
}
.content-section__body {
  min-width: 0;
}
.content-section__footer {
  display: flex;
  flex-wrap: wrap;
  justify-content: flex-end;
  gap: var(--wb-spacing-component-sm);
  margin-block-start: var(--wb-spacing-layout-action-gap);
}
@media (width < 768px) {
  .content-section__header {
    flex-wrap: wrap;
  }
  .content-section__actions {
    margin-inline-start: auto;
  }
}
</style>
