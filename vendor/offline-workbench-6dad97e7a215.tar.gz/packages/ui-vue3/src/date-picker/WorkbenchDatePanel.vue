<script setup>
import { computed, nextTick, ref } from 'vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import { addDays, dateKey, localDate, monthStart } from './dateUtils.js';

const props = defineProps({
  visibleDate: { type: Date, required: true },
  view: { type: String, default: 'date' },
  yearStart: Number,
  selected: { type: Array, default: () => [] },
  range: Boolean,
  hoverValue: { type: String, default: '' },
  today: { type: Date, required: true },
  isDisabled: { type: Function, default: () => false },
  showPrev: { type: Boolean, default: true },
  showNext: { type: Boolean, default: true },
  dateMarkers: { type: Object, default: null },
  showEmptyMarkers: Boolean,
  fluid: Boolean,
});
const emit = defineEmits(['choose', 'navigate', 'changeView', 'hover']);
const root = ref(null);
const weekdays = ['日', '一', '二', '三', '四', '五', '六'];
const markerCount = (key) => {
  const value = props.dateMarkers ? props.dateMarkers[key] : undefined;
  return value === true ? 1 : Number(value) > 0 ? Number(value) : 0;
};
const showMarker = (key) => props.view === 'date' && Boolean(props.dateMarkers)
  && (props.showEmptyMarkers || markerCount(key) > 0);
const title = computed(() => props.view === 'year'
  ? props.yearStart + ' 年 - ' + (props.yearStart + 15) + ' 年'
  : props.visibleDate.getFullYear() + ' 年');
const items = computed(() => {
  if (props.view === 'month') return Array.from({ length: 12 }, (_, index) => {
    const date = localDate(props.visibleDate.getFullYear(), index);
    return { date, key: dateKey(date, 'month'), label: (index + 1) + '月' };
  });
  if (props.view === 'year') return Array.from({ length: 16 }, (_, index) => {
    const date = localDate(props.yearStart + index);
    return { date, key: dateKey(date, 'year'), label: String(props.yearStart + index) };
  });
  const first = monthStart(props.visibleDate);
  const start = addDays(first, -first.getDay());
  return Array.from({ length: 42 }, (_, index) => {
    const date = addDays(start, index);
    return { date, key: dateKey(date), label: String(date.getDate()), outside: date.getMonth() !== props.visibleDate.getMonth() };
  });
});
const limits = computed(() => {
  const selected = props.selected.map(value => value.slice(0, props.view === 'year' ? 4 : props.view === 'month' ? 7 : 10));
  if (props.range && selected.length === 1 && props.hoverValue) selected.push(props.hoverValue);
  return selected.sort();
});
const selectedKey = computed(() => {
  const selected = items.value.find(item => limits.value.includes(item.key) && !props.isDisabled(item.date, props.view));
  return selected?.key || items.value.find(item => !item.outside && !props.isDisabled(item.date, props.view))?.key;
});
function classes(item) {
  const [start, end] = limits.value;
  const inRange = props.range && !item.outside && end && item.key >= start && item.key <= end;
  const lastDay = props.view === 'date' && new Date(item.date.getFullYear(), item.date.getMonth() + 1, 0).getDate();
  return {
    'is-outside': item.outside,
    'is-month-start': props.view === 'date' && !item.outside && item.date.getDate() === 1,
    'is-month-end': props.view === 'date' && !item.outside && item.date.getDate() === lastDay,
    'is-today': !props.range && item.key === dateKey(props.today, props.view),
    'is-selected': limits.value.includes(item.key),
    'is-in-range': inRange,
    'is-range-start': inRange && item.key === start,
    'is-range-end': inRange && item.key === end,
  };
}
function move(amount, year = false) {
  emit('navigate', props.view === 'date' ? { months: year ? amount * 12 : amount } : { years: amount * (props.view === 'year' ? 16 : 1) });
}
function focusInitial() {
  root.value?.querySelector('[tabindex="0"]')?.focus();
}
async function keydown(event, item, index) {
  const columns = props.view === 'date' ? 7 : props.view === 'month' ? 3 : 4;
  const offsets = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -columns, ArrowDown: columns };
  if (event.key === 'PageUp' || event.key === 'PageDown') {
    event.preventDefault();
    move(event.key === 'PageUp' ? -1 : 1, event.shiftKey);
    await nextTick();
    focusInitial();
    return;
  }
  if (!(event.key in offsets) && !['Home', 'End'].includes(event.key)) return;
  event.preventDefault();
  const targetIndex = event.key === 'Home' ? index - index % columns
    : event.key === 'End' ? index + columns - index % columns - 1 : index + offsets[event.key];
  await focusTarget(item, index, targetIndex);
}
async function focusTarget(item, index, targetIndex) {
  let target = items.value[targetIndex];
  if (props.view === 'date') {
    let date = addDays(item.date, targetIndex - index);
    const direction = targetIndex < index ? -1 : 1;
    let attempts = 0;
    while (props.isDisabled(date, 'date') && attempts++ < 366) date = addDays(date, direction);
    if (props.isDisabled(date, 'date')) return;
    if (date.getMonth() !== props.visibleDate.getMonth() || date.getFullYear() !== props.visibleDate.getFullYear()) {
      emit('navigate', { date: monthStart(date) });
      await nextTick();
    }
    target = { key: dateKey(date) };
  } else {
    let nextIndex = Math.max(0, Math.min(items.value.length - 1, targetIndex));
    const direction = targetIndex < index ? -1 : 1;
    while (items.value[nextIndex] && props.isDisabled(items.value[nextIndex].date, props.view)) nextIndex += direction;
    target = items.value[nextIndex];
  }
  if (target) {
    const button = root.value?.querySelector('[data-date="' + target.key + '"]');
    root.value?.querySelectorAll('[data-date]').forEach(node => { node.tabIndex = node === button ? 0 : -1; });
    button?.focus();
  }
}
defineExpose({ focusInitial });
</script>

<template>
  <section ref="root" class="wb-date-calendar" :class="['wb-date-calendar--' + view, { 'is-fluid': fluid }]" :aria-label="title + (view === 'date' ? ' ' + (visibleDate.getMonth() + 1) + ' 月' : '')">
    <header class="wb-date-calendar__header">
      <div class="wb-date-calendar__nav">
        <template v-if="showPrev">
          <button type="button" :aria-label="view === 'year' ? '前16年' : '上一年'" @click="move(-1, true)"><WorkbenchIcon name="双箭头/大小=16,方向=左" /></button>
          <button v-if="view === 'date'" type="button" aria-label="上个月" @click="move(-1)"><WorkbenchIcon name="箭头/尺寸=16,方向=左箭头" /></button>
        </template>
      </div>
      <div class="wb-date-calendar__title">
        <button v-if="view !== 'year'" type="button" aria-label="选择年份" @click="emit('changeView', 'year')">{{ title }}</button>
        <span v-else>{{ title }}</span>
        <button v-if="view === 'date'" type="button" aria-label="选择月份" @click="emit('changeView', 'month')">{{ visibleDate.getMonth() + 1 }} 月</button>
      </div>
      <div class="wb-date-calendar__nav">
        <template v-if="showNext">
          <button v-if="view === 'date'" type="button" aria-label="下个月" @click="move(1)"><WorkbenchIcon name="箭头/尺寸=16,方向=右箭头" /></button>
          <button type="button" :aria-label="view === 'year' ? '后16年' : '下一年'" @click="move(1, true)"><WorkbenchIcon name="双箭头/大小=16,方向=右" /></button>
        </template>
      </div>
    </header>
    <div v-if="view === 'date'" class="wb-date-calendar__week"><span v-for="day in weekdays" :key="day">{{ day }}</span></div>
    <div class="wb-date-calendar__grid" :class="{ 'wb-date-picker__days': view === 'date', 'has-markers': view === 'date' && Boolean(dateMarkers) }" @mouseleave="emit('hover', '')">
      <div v-for="(item, index) in items" :key="item.key" class="wb-date-calendar__cell" :class="classes(item)">
        <button
          type="button" :data-date="item.key" :aria-label="view === 'date' && markerCount(item.key) > 0 ? item.key + '，有日程标记' : item.key" :aria-pressed="limits.includes(item.key)"
          :aria-current="item.key === dateKey(today, view) ? 'date' : undefined"
          :disabled="isDisabled(item.date, view)" :tabindex="item.key === selectedKey ? 0 : -1"
          @click="emit('choose', item.date)" @mouseenter="emit('hover', item.key)" @focus="emit('hover', item.key)"
          @keydown="keydown($event, item, index)"
        >{{ item.label }}</button>
        <span v-if="showMarker(item.key)" class="wb-date-calendar__event-marker" :class="{ 'has-events': markerCount(item.key) > 0 }" aria-hidden="true" />
      </div>
    </div>
  </section>
</template>

<style scoped>
.wb-date-calendar { box-sizing: border-box; flex: none; width: var(--wb-asset-wb-date-picker-panel-width); padding: var(--wb-spacing-component-lg) var(--wb-spacing-component-md); color: var(--wb-color-text-primary); }
.wb-date-calendar__header { display: flex; align-items: center; justify-content: space-between; height: var(--wb-font-body-m-line-height); margin-bottom: var(--wb-spacing-component-xl); }
.wb-date-calendar__nav { display: flex; gap: var(--wb-spacing-component-sm); min-width: calc(var(--wb-icon-size-16) * 2 + var(--wb-spacing-component-sm)); }
.wb-date-calendar__nav:last-child { justify-content: flex-end; }
.wb-date-calendar__nav button { display: flex; width: var(--wb-icon-size-16); height: var(--wb-icon-size-16); padding: 0; color: var(--wb-color-icon-secondary); }
.wb-date-calendar button { border: 0; background: transparent; font: inherit; cursor: pointer; color: inherit; }
.wb-date-calendar__title { display: flex; justify-content: center; gap: var(--wb-spacing-component-sm); white-space: nowrap; font-size: var(--wb-font-headline-xs-font-size); font-weight: var(--wb-font-headline-xs-font-weight); line-height: var(--wb-font-headline-xs-line-height); letter-spacing: var(--wb-font-headline-xs-letter-spacing); }
.wb-date-calendar__title button { padding: 0; }
.wb-date-calendar__week { display: grid; grid-template-columns: repeat(7, var(--wb-asset-wb-date-picker-day-size)); column-gap: var(--wb-spacing-component-md); width: var(--wb-asset-wb-date-picker-grid-width); margin: 0 auto var(--wb-spacing-component-lg); text-align: center; font-size: var(--wb-font-body-s-font-size); font-weight: var(--wb-font-body-s-font-weight); line-height: var(--wb-font-body-s-line-height); letter-spacing: var(--wb-font-body-s-letter-spacing); }
.wb-date-calendar__grid { display: grid; width: var(--wb-asset-wb-date-picker-grid-width); margin: 0 auto; grid-template-columns: repeat(7, var(--wb-asset-wb-date-picker-day-size)); gap: var(--wb-spacing-component-md); }
.wb-date-calendar.is-fluid { width: 100%; min-width: var(--wb-asset-wb-date-picker-panel-width); }
.wb-date-calendar--date.is-fluid .wb-date-calendar__week, .wb-date-calendar--date.is-fluid .wb-date-calendar__grid { width: 100%; justify-content: space-between; }
/* With event markers, keep 12px from a marker's bottom edge to the next row's date control. */
.wb-date-calendar__grid.has-markers { row-gap: calc(var(--wb-spacing-component-xs) + var(--wb-asset-wb-date-picker-event-marker-size) + var(--wb-spacing-component-md)); }
.wb-date-calendar__cell { position: relative; isolation: isolate; }
.wb-date-calendar__event-marker { position: absolute; left: 50%; bottom: calc(-1 * (var(--wb-spacing-component-xs) + var(--wb-asset-wb-date-picker-event-marker-size))); transform: translateX(-50%); width: var(--wb-asset-wb-date-picker-event-marker-size); height: var(--wb-asset-wb-date-picker-event-marker-size); border-radius: var(--wb-radius-full); background: var(--wb-color-text-disabled); pointer-events: none; }
.wb-date-calendar__event-marker.has-events { background: var(--wb-color-brand); }
.wb-date-calendar__cell button { display: block; position: relative; box-sizing: border-box; width: 100%; height: var(--wb-asset-wb-date-picker-day-size); padding: 0; border: 1px solid transparent; border-radius: var(--wb-radius-sm); font-size: var(--wb-font-body-s-font-size); font-weight: var(--wb-font-body-s-font-weight); line-height: var(--wb-font-body-s-line-height); letter-spacing: var(--wb-font-body-s-letter-spacing); }
.wb-date-calendar__cell.is-outside { color: var(--wb-color-text-disabled); }
.wb-date-calendar__cell.is-today button, .wb-date-calendar__cell button:hover, .wb-date-calendar__cell button:disabled { background: var(--wb-color-fill-hover); }
.wb-date-calendar__cell.is-outside button { background: transparent; }
.wb-date-calendar__cell.is-selected button { border-color: var(--wb-color-border-focus); color: var(--wb-color-text-primary); }
.wb-date-calendar__cell.is-in-range::before { content: ''; position: absolute; z-index: -1; inset: 0 calc(var(--wb-spacing-component-md) / -2); background: var(--wb-color-fill-selected); }
.wb-date-calendar__cell.is-range-start::before { left: 0; border-start-start-radius: var(--wb-radius-sm); border-end-start-radius: var(--wb-radius-sm); }
.wb-date-calendar__cell.is-range-end::before { right: 0; border-start-end-radius: var(--wb-radius-sm); border-end-end-radius: var(--wb-radius-sm); }
.wb-date-calendar--date .wb-date-calendar__cell.is-month-start.is-in-range::before { left: 0; border-start-start-radius: var(--wb-radius-sm); border-end-start-radius: var(--wb-radius-sm); }
.wb-date-calendar--date .wb-date-calendar__cell.is-month-end.is-in-range::before { right: 0; border-start-end-radius: var(--wb-radius-sm); border-end-end-radius: var(--wb-radius-sm); }
.wb-date-calendar__cell button:disabled { cursor: not-allowed; color: var(--wb-color-text-disabled); }
.wb-date-calendar button:focus-visible { outline: 2px solid var(--wb-color-border-focus); outline-offset: var(--wb-spacing-component-xs); }
.wb-date-calendar--month .wb-date-calendar__grid { grid-template-columns: repeat(3, var(--wb-asset-wb-date-picker-period-width)); width: var(--wb-asset-wb-date-picker-period-grid-width); column-gap: var(--wb-asset-wb-date-picker-month-column-gap); row-gap: var(--wb-asset-wb-date-picker-month-row-gap); }
.wb-date-calendar--year .wb-date-calendar__grid { grid-template-columns: repeat(4, var(--wb-asset-wb-date-picker-period-width)); width: var(--wb-asset-wb-date-picker-period-grid-width); gap: var(--wb-asset-wb-date-picker-year-gap); }
.wb-date-calendar--month .wb-date-calendar__cell button { height: var(--wb-asset-wb-date-picker-period-width); }
.wb-date-calendar--month .wb-date-calendar__cell button, .wb-date-calendar--year .wb-date-calendar__cell button { font-size: var(--wb-font-body-m-font-size); font-weight: var(--wb-font-body-m-font-weight); line-height: var(--wb-font-body-m-line-height); letter-spacing: var(--wb-font-body-m-letter-spacing); }
.wb-date-calendar--month .is-in-range::before { inset-inline: calc(var(--wb-asset-wb-date-picker-month-column-gap) / -2); }
.wb-date-calendar--year .is-in-range::before { inset-inline: calc(var(--wb-asset-wb-date-picker-year-gap) / -2); }
.wb-date-calendar__grid .is-range-start::before { left: 0; }
.wb-date-calendar__grid .is-range-end::before { right: 0; }
.wb-date-calendar--date .wb-date-calendar__cell:nth-child(7n + 1)::before,
.wb-date-calendar--month .wb-date-calendar__cell:nth-child(3n + 1)::before,
.wb-date-calendar--year .wb-date-calendar__cell:nth-child(4n + 1)::before { left: 0; border-start-start-radius: var(--wb-radius-sm); border-end-start-radius: var(--wb-radius-sm); }
.wb-date-calendar--date .wb-date-calendar__cell:nth-child(7n)::before,
.wb-date-calendar--month .wb-date-calendar__cell:nth-child(3n)::before,
.wb-date-calendar--year .wb-date-calendar__cell:nth-child(4n)::before { right: 0; border-start-end-radius: var(--wb-radius-sm); border-end-end-radius: var(--wb-radius-sm); }
</style>
