<script setup>
import { useFormDisabled } from '../form/useFormDisabled.js';
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import { computed, nextTick, onBeforeUnmount, ref, useId, watch } from 'vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import WorkbenchButton from '../button/WorkbenchButton.vue';
import '../scrollbar/scrollbar.css';
import WorkbenchDatePanel from './WorkbenchDatePanel.vue';
import { addDays, dateKey, formatValue, localDate, monthStart, pad, parseDate } from './dateUtils.js';

const props = defineProps({
  modelValue: { type: [String, Array], default: '' },
  type: { type: String, default: 'date', validator: value => ['date', 'month', 'year', 'datetime'].includes(value) },
  range: Boolean, showTime: Boolean, disabled: Boolean,
  size: { type: String, default: 'default' },
  name: String, ariaLabel: { type: String, default: '选择日期' }, ariaDescribedby: String, invalid: Boolean,
  placeholder: String, min: String, max: String, disabledDate: Function,
  shortcuts: { type: [Boolean, Array], default: false }, inline: Boolean, defaultOpen: Boolean,
  dateMarkers: { type: Object, default: null },
  showEmptyMarkers: Boolean,
  fluid: Boolean,
  flatInline: Boolean,
  showInput: { type: Boolean, default: true },
  previewState: { type: String, default: 'default' }, today: { type: Date, default: () => new Date() },
});
const disabled = useFormDisabled(() => props.disabled);
const emit = defineEmits(['update:modelValue', 'change', 'clear', 'openChange']);
const root = ref(null), panel = ref(null), calendars = ref([]), inputs = ref([]), trigger = ref(null);
const panelId = 'wb-date-panel-' + useId(), open = ref(false);
const unit = computed(() => props.type === 'datetime' ? 'date' : props.type);
const withTime = computed(() => unit.value === 'date' && (props.showTime || props.type === 'datetime'));
const inactive = computed(() => disabled.value || props.previewState === 'disabled');
const committed = computed(() => {
  const values = props.range ? (Array.isArray(props.modelValue) ? props.modelValue : []) : [props.modelValue];
  return values.filter(value => parseDate(value, unit.value)).slice(0, props.range ? 2 : 1);
});
const text = ref([]), draft = ref([]), hoverValue = ref(''), view = ref(unit.value);
const visible = ref(monthStart(parseDate(committed.value[0], unit.value) || props.today));
const yearStart = ref(visible.value.getFullYear() - 5);
const activeTimeEnd = ref(0), timeParts = ref(['00', '00', '00']);
const hasValue = computed(() => committed.value.length > 0);
const showPanel = computed(() => !inactive.value && (open.value || props.inline));
const fluidPanel = computed(() => props.fluid && props.inline && !props.range && !withTime.value && !shortcutItems.value.length);
const ready = computed(() => draft.value.length === (props.range ? 2 : 1) && draft.value.every(value => {
  const date = parseDate(value, unit.value);
  return date && !isDisabled(date, unit.value);
}));
const dates = computed(() => Array.from({ length: props.range ? 2 : 1 }, (_, index) => view.value === 'year'
  ? localDate(yearStart.value + index * 16)
  : view.value === 'month' ? localDate(visible.value.getFullYear() + index) : monthStart(visible.value, index)));
const defaultShortcuts = computed(() => [
  { label: '昨天', date: addDays(props.today, -1) }, { label: '过去7天', date: addDays(props.today, -6) },
  { label: '过去14天', date: addDays(props.today, -13) }, { label: '过去30天', date: addDays(props.today, -29) },
  { label: '过去90天', date: addDays(props.today, -89) },
  { label: '本周五', date: addDays(props.today, 5 - (props.today.getDay() || 7)) },
  { label: '本周末', date: addDays(props.today, 7 - (props.today.getDay() || 7)) }, { label: '14天后', date: addDays(props.today, 14) },
]);
const shortcutItems = computed(() => Array.isArray(props.shortcuts) ? props.shortcuts : props.shortcuts ? defaultShortcuts.value : []);
const timeChoices = [Array.from({ length: 24 }, (_, index) => pad(index)), ...Array.from({ length: 2 }, () => Array.from({ length: 60 }, (_, index) => pad(index)))];
const timeLabels = ['小时', '分钟', '秒'];
const fieldPlaceholder = computed(() => props.placeholder || (withTime.value ? '请选择日期与时间' : unit.value === 'month' ? '请选择月份' : unit.value === 'year' ? '请选择年份' : '请选择日期'));

function isDisabled(date, displayUnit = unit.value) {
  if (date.getFullYear() < 1 || date.getFullYear() > 9999) return true;
  const key = dateKey(date, displayUnit), min = parseDate(props.min, unit.value), max = parseDate(props.max, unit.value);
  return !!((min && key < dateKey(min, displayUnit)) || (max && key > dateKey(max, displayUnit)) || props.disabledDate?.(new Date(date), displayUnit));
}
function loadTime() {
  const date = parseDate(draft.value[activeTimeEnd.value], unit.value);
  timeParts.value = date ? [pad(date.getHours()), pad(date.getMinutes()), pad(date.getSeconds())] : ['00', '00', '00'];
}
function resetDraft() {
  draft.value = [...committed.value];
  text.value = props.range ? [committed.value[0] || '', committed.value[1] || ''] : [committed.value[0] || ''];
  const date = parseDate(draft.value[0], unit.value) || props.today;
  visible.value = monthStart(date); yearStart.value = Math.max(1, Math.min(props.range ? 9968 : 9984, date.getFullYear() - 5));
  view.value = unit.value; activeTimeEnd.value = 0; hoverValue.value = ''; loadTime();
}
function publish(values) {
  if (inactive.value) return;
  const next = props.range ? values : values[0] || '';
  emit('update:modelValue', next); emit('change', next);
}
async function setOpen(value, focusGrid = false) {
  if (inactive.value) return;
  if (value && !open.value) resetDraft();
  open.value = value; emit('openChange', value);
  await nextTick();
  if (value) { positionPanel(); if (focusGrid) calendars.value[0]?.focusInitial(); }
}
function close(restore = false) {
  open.value = false; hoverValue.value = ''; emit('openChange', false);
  if (restore) nextTick(() => inputs.value[0]?.focus());
}
function cancel() { resetDraft(); close(true); }
function choose(date) {
  if (inactive.value || isDisabled(date, view.value)) return;
  if (view.value !== unit.value) {
    visible.value = monthStart(date);
    view.value = view.value === 'year' && unit.value === 'date' ? 'month' : unit.value;
    return;
  }
  const value = withTime.value ? dateKey(date) + ' ' + timeParts.value.join(':') : formatValue(date, unit.value);
  if (props.range) {
    draft.value = draft.value.length === 1 ? [draft.value[0], value].sort() : [value];
    activeTimeEnd.value = 1;
  } else draft.value = [value];
  hoverValue.value = '';
  text.value = props.range ? [draft.value[0] || '', draft.value[1] || ''] : [...draft.value];
  loadTime();
  if (ready.value && !withTime.value) { publish([...draft.value]); close(true); }
}
function changeView(next) {
  view.value = next; yearStart.value = Math.max(1, Math.min(props.range ? 9968 : 9984, visible.value.getFullYear() - 5));
}
function navigate(change, index) {
  if (change.date) visible.value = monthStart(change.date, -index);
  else if (view.value === 'year') yearStart.value = Math.max(1, Math.min(props.range ? 9968 : 9984, yearStart.value + change.years));
  else {
    const next = localDate(visible.value.getFullYear() + (change.years || 0), visible.value.getMonth() + (change.months || 0));
    if (next.getFullYear() >= 1 && next.getFullYear() <= (props.range ? 9998 : 9999)) visible.value = next;
  }
  nextTick(positionPanel);
}
function correctInput(index) {
  const value = text.value[index];
  if (!value?.trim()) { if (!props.range) { draft.value = []; publish([]); } return; }
  const parsed = parseDate(value, unit.value, true);
  if (!parsed || isDisabled(parsed, unit.value)) { text.value[index] = committed.value[index] || ''; return; }
  text.value[index] = formatValue(parsed, unit.value, withTime.value);
  const all = text.value.map(value => parseDate(value, unit.value));
  if (all.length === (props.range ? 2 : 1) && all.every(date => date && !isDisabled(date, unit.value))) {
    draft.value = all.map(date => formatValue(date, unit.value, withTime.value)).sort();
    text.value = [...draft.value]; publish([...draft.value]); visible.value = monthStart(all[0]);
  }
}
function clear() {
  draft.value = []; text.value = props.range ? ['', ''] : [''];
  publish([]); emit('clear'); close(); nextTick(() => inputs.value[0]?.focus());
}
function selectShortcut(item) {
  const values = typeof item.value === 'function' ? item.value() : item.value;
  let selected = values == null ? [item.date, ...(props.range ? [props.today] : [])] : Array.isArray(values) ? values : [values];
  selected = selected.map(value => value instanceof Date ? new Date(value) : parseDate(value, unit.value)).filter(Boolean);
  if (selected.length !== (props.range ? 2 : 1) || selected.some(date => isDisabled(date, unit.value))) return;
  draft.value = selected.map(date => formatValue(date, unit.value, withTime.value)).sort();
  text.value = [...draft.value]; visible.value = monthStart(selected[0]); loadTime();
  if (!withTime.value) { publish([...draft.value]); close(true); }
}
function now() { if (!isDisabled(props.today, unit.value)) selectShortcut({ value: props.range ? [props.today, props.today] : props.today }); }
function selectTime(index, value) {
  const position = props.range ? activeTimeEnd.value : 0;
  if (!draft.value[position]) return;
  timeParts.value[index] = value;
  const next = [...draft.value]; next[position] = next[position].slice(0, 10) + ' ' + timeParts.value.join(':');
  draft.value = next; text.value = props.range ? [next[0] || '', next[1] || ''] : next;
}
function timeKey(event, column, index) {
  if (!['Home', 'End', 'ArrowDown', 'ArrowUp'].includes(event.key)) return;
  event.preventDefault();
  const options = [...event.currentTarget.parentElement.querySelectorAll('[role="option"]')];
  const target = event.key === 'Home' ? 0 : event.key === 'End' ? options.length - 1 : index + (event.key === 'ArrowDown' ? 1 : -1);
  const next = Math.max(0, Math.min(options.length - 1, target));
  selectTime(column, timeChoices[column][next]); options[next]?.focus();
}
function confirm() { if (ready.value) { publish([...draft.value].sort()); close(true); } }
function onKey(event) { if (!event.isComposing && event.key === 'Escape' && showPanel.value) { event.preventDefault(); cancel(); } }
function inputKey(event, index) {
  if (event.isComposing) return;
  if (event.key === 'ArrowDown') { event.preventDefault(); setOpen(true, true); }
  if (event.key === 'Enter') { event.preventDefault(); correctInput(index); close(); }
}
function outside(event) {
  if (!root.value?.contains(event.target) && !panel.value?.contains(event.target)) {
    const activeInput = inputs.value.indexOf(document.activeElement);
    if (event.type === 'pointerdown' && activeInput >= 0) correctInput(activeInput);
    resetDraft(); close();
  }
}
function positionPanel() {
  if (!panel.value || props.inline || !root.value) return;
  const anchor = root.value.getBoundingClientRect(), box = panel.value.getBoundingClientRect();
  const style = getComputedStyle(root.value);
  const gap = parseFloat(style.getPropertyValue('--wb-spacing-component-xs'));
  const edge = parseFloat(style.getPropertyValue('--wb-spacing-component-sm'));
  const top = anchor.bottom + gap + box.height <= window.innerHeight - edge ? anchor.bottom + gap : Math.max(edge, anchor.top - box.height - gap);
  Object.assign(panel.value.style, { left: Math.max(edge, Math.min(anchor.left, window.innerWidth - box.width - edge)) + 'px', top: top + 'px' });
}
watch([() => props.modelValue, unit, () => props.range, withTime], resetDraft, { immediate: true, deep: true });
watch(inactive, value => { if (value) close(); });
watch(showPanel, value => {
  const method = value && !props.inline ? 'addEventListener' : 'removeEventListener';
  document[method]('pointerdown', outside); document[method]('focusin', outside);
  window[method]('resize', positionPanel); window[method]('scroll', positionPanel, true);
  if (value) nextTick(positionPanel);
}, { immediate: true });
watch(() => props.defaultOpen, value => { if (value) setOpen(true); }, { immediate: true });
onBeforeUnmount(() => {
  document.removeEventListener('pointerdown', outside); document.removeEventListener('focusin', outside);
  window.removeEventListener('resize', positionPanel); window.removeEventListener('scroll', positionPanel, true);
});
defineExpose({ focus: () => inputs.value[0] ? inputs.value[0].focus() : calendars.value[0]?.focusInitial(), open: () => setOpen(true), close });
watch(disabled, (value) => { if (value) { close(); } });
</script>

<template>
  <div ref="root" class="wb-date-picker" :class="['wb-date-picker--' + size, 'is-' + previewState, { 'is-disabled': inactive, 'is-open': showPanel, 'is-invalid': invalid, 'has-value': hasValue, 'is-range': range, 'is-fluid': fluidPanel }]" @keydown="onKey">
    <div v-if="!inline || showInput" class="wb-date-picker__field">
      <template v-for="index in (range ? [0, 1] : [0])" :key="index">
        <span v-if="index" class="wb-date-picker__separator" aria-hidden="true">-</span>
        <input :ref="element => { inputs[index] = element; }" v-model="text[index]" type="text" class="wb-date-picker__input" :class="{ 'is-start': range && index === 0 }"
          :aria-label="ariaLabel + (range ? (index ? '结束日期输入' : '开始日期输入') : '输入')" role="combobox" aria-haspopup="dialog"
          :aria-expanded="showPanel" :aria-controls="panelId" :aria-describedby="ariaDescribedby" :aria-invalid="invalid || undefined" :disabled="inactive"
          :placeholder="range ? (index ? '请选择结束日期' : '请选择开始日期') : fieldPlaceholder" autocomplete="off"
          @click="setOpen(true)" @blur="correctInput(index)" @keydown="inputKey($event, index)" />
      </template>
      <button type="button" class="wb-date-picker__clear" :aria-label="'清除' + ariaLabel" :aria-hidden="!hasValue || inactive" :disabled="!hasValue || inactive" :tabindex="hasValue && !inactive ? 0 : -1" @click.stop="clear"><WorkbenchIcon name="/ic_public_close_line_14px" /></button>
      <button ref="trigger" type="button" class="wb-date-picker__trigger" :aria-label="ariaLabel" :disabled="inactive" aria-haspopup="dialog" :aria-expanded="showPanel" :aria-controls="panelId" @click="setOpen(!open, true)"><WorkbenchIcon name="日期/尺寸=14" /></button>
    </div>
    <template v-if="name"><input v-for="(value, index) in (range ? committed : [committed[0] || ''])" :key="index" type="hidden" :name="range ? name + '[' + index + ']' : name" :value="value" :disabled="inactive" /></template>
    <Teleport to="body" :disabled="inline">
      <div v-if="showPanel" :id="panelId" ref="panel" class="wb-date-picker__panel wb-scrollbar" :class="{ 'is-inline': inline, 'is-panel-only': inline && !showInput, 'is-fluid': fluidPanel, 'is-flat': inline && flatInline }" :role="inline && !showInput ? 'group' : 'dialog'" :aria-label="inline && !showInput ? ariaLabel : ariaLabel + '选择面板'" @keydown="onKey">
        <aside v-if="shortcutItems.length && view === 'date'" class="wb-date-picker__shortcuts" aria-label="快捷日期"><button v-for="item in shortcutItems" :key="item.label" type="button" @click="selectShortcut(item)">{{ item.label }}</button></aside>
        <div class="wb-date-picker__main">
          <div class="wb-date-picker__calendars">
            <WorkbenchDatePanel v-for="(date, index) in dates" :key="index" ref="calendars" :visible-date="date" :view="view"
              :year-start="yearStart + index * 16" :selected="draft" :range="range" :hover-value="hoverValue" :today="today" :is-disabled="isDisabled" :date-markers="dateMarkers" :show-empty-markers="showEmptyMarkers"
              :show-prev="index === 0" :show-next="index === dates.length - 1" :fluid="fluidPanel"
              @choose="choose" @navigate="navigate($event, index)" @change-view="changeView" @hover="hoverValue = $event" />
            <div v-if="withTime && view === 'date'" class="wb-date-picker__time">
              <div class="wb-date-picker__time-heading">{{ timeParts.join(' : ') }}</div>
              <div v-if="range" class="wb-date-picker__time-ends"><button v-for="index in [0, 1]" :key="index" type="button" :aria-pressed="activeTimeEnd === index" @click="activeTimeEnd = index; loadTime()">{{ index ? '结束' : '开始' }}</button></div>
              <div class="wb-date-picker__time-columns">
                <div v-for="(choices, column) in timeChoices" :key="column" class="wb-date-picker__time-column">
                  <div class="wb-date-picker__time-label">{{ ['时', '分', '秒'][column] }}</div>
                  <div role="listbox" :aria-label="timeLabels[column]" class="wb-date-picker__time-list wb-scrollbar">
                    <button v-for="(value, index) in choices" :key="value" type="button" role="option" :aria-selected="timeParts[column] === value" :tabindex="timeParts[column] === value ? 0 : -1" @click="selectTime(column, value)" @keydown="timeKey($event, column, index)">{{ value }}</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <footer v-if="withTime && view === 'date'" class="wb-date-picker__footer">
            <WorkbenchButton appearance="text" @click="now">此刻</WorkbenchButton>
            <div class="wb-date-picker__footer-actions"><WorkbenchButton appearance="secondary" @click="cancel">取消</WorkbenchButton><WorkbenchButton :disabled="!ready" @click="confirm">确定</WorkbenchButton></div>
          </footer>
        </div>
      </div>
    </Teleport>
  </div>
</template>

<style scoped>
.wb-date-picker { position: relative; width: var(--date-picker-field-width, var(--wb-asset-wb-date-picker-panel-width)); max-width: 100%; color: var(--wb-color-text-primary); font-size: var(--wb-font-body-m-font-size); font-weight: var(--wb-font-body-m-font-weight); line-height: var(--wb-font-body-m-line-height); letter-spacing: var(--wb-font-body-m-letter-spacing); }
.wb-date-picker__field { display: flex; box-sizing: border-box; align-items: center; gap: var(--wb-spacing-component-sm); height: var(--wb-asset-wb-date-picker-trigger-height); padding: 0 var(--wb-spacing-component-md); border: 1px solid var(--wb-color-border); border-radius: var(--wb-radius-sm); background: var(--wb-color-surface-card-default); }
.wb-date-picker__input { box-sizing: border-box; flex: 1; min-width: 0; width: 100%; padding: 0; border: 0; outline: 0; background: transparent; color: inherit; font: inherit; }
.wb-date-picker.is-range .wb-date-picker__field { padding-left: var(--wb-spacing-component-xs); }
.wb-date-picker.is-range .wb-date-picker__input.is-start { padding-left: var(--wb-spacing-component-sm); }
.wb-date-picker.is-range.is-open .wb-date-picker__input.is-start { border-radius: var(--wb-radius-sm); background: var(--wb-color-fill-hover); }
.wb-date-picker__input::placeholder { color: var(--wb-color-text-placeholder); opacity: 1; }
.wb-date-picker__field:hover, .is-hover .wb-date-picker__field { border-color: var(--wb-color-border-hover); }
.wb-date-picker__field:focus-within, .is-open .wb-date-picker__field, .is-focused .wb-date-picker__field { border-color: var(--wb-color-border-focus); }
.wb-date-picker__trigger, .wb-date-picker__clear { display: flex; flex: none; align-items: center; justify-content: center; box-sizing: content-box; width: var(--wb-asset-wb-date-picker-icon-size); height: var(--wb-asset-wb-date-picker-icon-size); padding: 0; border: 0; background: transparent; color: var(--wb-color-icon-secondary); cursor: pointer; }
.wb-date-picker__clear { opacity: 0; visibility: hidden; padding-inline-end: var(--wb-spacing-component-sm); border-inline-end: 1px solid var(--wb-color-border-separator); }
.has-value:not(.is-disabled) .wb-date-picker__field:hover .wb-date-picker__clear,
.has-value:not(.is-disabled) .wb-date-picker__field:focus-within .wb-date-picker__clear { opacity: 1; visibility: visible; }
.wb-date-picker__trigger:focus-visible, .wb-date-picker__clear:focus-visible { outline: 2px solid var(--wb-color-border-focus); outline-offset: var(--wb-spacing-component-xs); }
.wb-date-picker__separator { color: var(--wb-color-text-secondary); }
.is-disabled .wb-date-picker__field { border-color: var(--wb-color-border-disabled); background: var(--wb-color-fill-subtle-disabled); color: var(--wb-color-text-disabled); cursor: not-allowed; }
.is-disabled .wb-date-picker__input::placeholder { color: var(--wb-color-text-disabled); }
.is-disabled .wb-date-picker__trigger { color: var(--wb-color-icon-disabled); cursor: not-allowed; }
.is-invalid .wb-date-picker__field { border-color: var(--wb-color-error); }
.wb-date-picker--small { font-size: var(--wb-font-body-s-font-size); font-weight: var(--wb-font-body-s-font-weight); line-height: var(--wb-font-body-s-line-height); letter-spacing: var(--wb-font-body-s-letter-spacing); }
.wb-date-picker--small .wb-date-picker__field { height: var(--wb-asset-wb-date-picker-small-height); }
.wb-date-picker__panel { z-index: var(--wb-asset-wb-date-picker-panel-z); display: flex; width: max-content; overflow: auto; box-sizing: border-box; border: 0; border-radius: var(--wb-radius-md); background: var(--wb-color-surface-overlay); box-shadow: var(--wb-shadow-base); color: var(--wb-color-text-primary); font-family: inherit; font-size: var(--wb-font-body-m-font-size); font-weight: var(--wb-font-body-m-font-weight); line-height: var(--wb-font-body-m-line-height); letter-spacing: var(--wb-font-body-m-letter-spacing); }
.wb-date-picker__panel.is-inline { margin-top: var(--wb-spacing-component-xs); max-width: var(--wb-date-picker-inline-panel-max-width, 100%); }
.wb-date-picker__panel.is-panel-only { margin-top: 0; }
.wb-date-picker.is-fluid, .wb-date-picker__panel.is-fluid, .wb-date-picker__panel.is-fluid .wb-date-picker__main, .wb-date-picker__panel.is-fluid .wb-date-picker__calendars { width: 100%; }
.wb-date-picker__panel.is-fluid .wb-date-picker__main { flex: 1; }
.wb-date-picker__panel.is-flat { box-shadow: none; }
.wb-date-picker__panel:not(.is-inline) { position: fixed; max-width: calc(100vw - var(--wb-spacing-component-sm) * 2); max-height: calc(100vh - var(--wb-spacing-component-sm) * 2); }
.wb-date-picker__main { min-width: 0; flex: none; }
.wb-date-picker__calendars { display: flex; }
.wb-date-picker__calendars > .wb-date-calendar + .wb-date-calendar { box-sizing: content-box; width: calc(var(--wb-asset-wb-date-picker-panel-width) - var(--wb-spacing-component-md) * 2); border-left: 1px solid var(--wb-color-border-separator); }
.wb-date-picker__shortcuts { display: flex; flex: none; flex-direction: column; box-sizing: border-box; width: var(--wb-asset-wb-date-picker-shortcuts-width); padding: var(--wb-spacing-component-lg) var(--wb-spacing-component-xl); gap: var(--wb-asset-wb-date-picker-shortcuts-gap); border-right: 1px solid var(--wb-color-border-separator); }
.wb-date-picker__shortcuts button { padding: 0; border: 0; background: transparent; color: inherit; text-align: left; font: inherit; white-space: nowrap; cursor: pointer; }
.wb-date-picker__shortcuts button:hover { color: var(--wb-color-text-action); }
.wb-date-picker__time { box-sizing: border-box; width: var(--wb-asset-wb-date-picker-time-width); padding: var(--wb-asset-wb-date-picker-time-padding-top) var(--wb-spacing-component-md) var(--wb-spacing-component-lg); border-left: 1px solid var(--wb-color-border-separator); }
.wb-date-picker__time-heading { text-align: center; height: var(--wb-font-body-s-line-height); font-size: var(--wb-font-body-s-font-size); font-weight: var(--wb-font-body-s-font-weight); line-height: var(--wb-font-body-s-line-height); letter-spacing: var(--wb-font-body-s-letter-spacing); margin-bottom: var(--wb-spacing-component-lg); }
.wb-date-picker__time-columns { display: flex; gap: var(--wb-spacing-component-sm); }
.wb-date-picker__time-column { flex: 1; min-width: 0; text-align: center; }
.wb-date-picker__time-label { display: flex; align-items: center; justify-content: center; height: var(--wb-asset-wb-date-picker-day-size); margin-bottom: var(--wb-spacing-component-md); }
.wb-date-picker__time-list { height: var(--wb-asset-wb-date-picker-time-list-height); overflow-y: auto; scrollbar-width: none; }
.wb-date-picker__time-list button { display: block; width: 100%; height: var(--wb-asset-wb-date-picker-day-size); margin-bottom: var(--wb-spacing-component-md); padding: 0; border: 1px solid transparent; border-radius: var(--wb-radius-sm); background: transparent; color: inherit; font: inherit; cursor: pointer; }
.wb-date-picker__time-list button[aria-selected="true"] { border-color: var(--wb-color-border-focus); }
.wb-date-picker__time-list button:hover { background: var(--wb-color-fill-hover); }
.wb-date-picker__time-ends { display: flex; justify-content: center; gap: var(--wb-spacing-component-sm); margin-bottom: var(--wb-spacing-component-sm); }
.wb-date-picker__time-ends button { border: 0; background: transparent; color: var(--wb-color-text-secondary); cursor: pointer; font: inherit; }
.wb-date-picker__time-ends button[aria-pressed="true"] { color: var(--wb-color-text-primary); }
.wb-date-picker__footer { display: flex; box-sizing: border-box; align-items: center; justify-content: space-between; gap: var(--wb-spacing-component-sm); height: calc(var(--wb-asset-wb-date-picker-day-size) + var(--wb-spacing-component-md) * 2); padding: 0 var(--wb-spacing-component-md); border-top: 1px solid var(--wb-color-border-separator); }
.wb-date-picker__footer-actions { display: flex; gap: var(--wb-spacing-component-sm); }
</style>
