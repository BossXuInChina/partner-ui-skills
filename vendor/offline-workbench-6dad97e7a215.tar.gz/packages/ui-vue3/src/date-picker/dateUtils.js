export const pad = value => String(value).padStart(2, '0');
export function localDate(year, month = 0, day = 1) {
  const date = new Date(0);
  date.setFullYear(year, month, day);
  date.setHours(0, 0, 0, 0);
  return date;
}
export function dateKey(date, unit = 'date') {
  const year = String(date.getFullYear()).padStart(4, '0');
  if (unit === 'year') return year;
  const month = `${year}-${pad(date.getMonth() + 1)}`;
  return unit === 'month' ? month : `${month}-${pad(date.getDate())}`;
}
export function parseDate(value, unit = 'date', correct = false) {
  if (typeof value !== 'string' || !value.trim()) return null;
  const parts = value.trim().match(/^(\d{4})(?:[-/.年](\d{1,2}))?(?:[-/.月](\d{1,2})日?)?(?:[ T](\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?$/);
  if (!parts || (unit !== 'year' && !parts[2]) || (!['year', 'month'].includes(unit) && !parts[3])) return null;
  return dateFromParts(parts, correct);
}
function dateFromParts(parts, correct) {
  const year = Number(parts[1]);
  if (year < 1 || year > 9999) return null;
  const bound = (value, max) => Math.max(1, Math.min(max, value));
  const month = correct ? bound(Number(parts[2] || 1), 12) : Number(parts[2] || 1);
  const maxDay = localDate(year, month, 0).getDate();
  const day = correct ? bound(Number(parts[3] || 1), maxDay) : Number(parts[3] || 1);
  if (month < 1 || month > 12 || day < 1 || day > maxDay) return null;
  const date = localDate(year, month - 1, day);
  const time = [parts[4], parts[5], parts[6]].map(value => Number(value || 0));
  const limits = [23, 59, 59];
  if (!correct && time.some((value, index) => value > limits[index])) return null;
  date.setHours(...time.map((value, index) => Math.min(limits[index], value)), 0);
  return date;
}
export function formatValue(date, unit = 'date', time = false) {
  return dateKey(date, unit) + (time && unit === 'date' ? ` ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}` : '');
}
export function addDays(date, amount) {
  const next = new Date(date);
  next.setDate(next.getDate() + amount);
  return next;
}
export function monthStart(date, amount = 0) {
  return localDate(date.getFullYear(), date.getMonth() + amount);
}
