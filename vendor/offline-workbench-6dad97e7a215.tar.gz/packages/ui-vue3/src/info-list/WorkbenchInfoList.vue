<script setup lang="ts">
// Block: information list item = title / tags / time on three rows, separated by subtle dividers.
import type { PropType } from 'vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import WorkbenchTag from '../tag/WorkbenchTag.vue';
import type { InfoListItem } from '../../types/home-blocks';
defineProps({
  items: { type: Array as PropType<InfoListItem[]>, required: true },
  href: { type: String, default: '#' },
});
</script>

<template>
  <ul class="wb-info-list">
    <li v-for="(item, index) in items" :key="index" class="wb-info-list__item">
      <a class="wb-info-list__title" :href="item.href ?? href">{{ item.title }}</a>
      <span v-if="item.tags?.length" class="wb-info-list__tags">
        <WorkbenchTag v-for="tag in item.tags" :key="tag[0]" variant="status-subtle" size="small" :status="tag[1]" :label="tag[0]" />
      </span>
      <span class="wb-info-list__time"><WorkbenchIcon name="首页 时间/time" :size="16" />{{ item.time }}</span>
    </li>
  </ul>
</template>

<style>
.wb-info-list { margin: 0; padding: 0; list-style: none; }
.wb-info-list__item { display: flex; flex-direction: column; gap: var(--wb-spacing-component-sm); padding: var(--wb-spacing-component-sm) 0; border-bottom: var(--wb-asset-wb-info-list-divider-width) solid var(--wb-color-border-separator-subtle); }
/* Title 14px body-m, confirmed by the user on 2026-11-04. */
.wb-info-list__title { overflow: hidden; color: var(--wb-color-text-primary); font-size: var(--wb-font-body-m-font-size); font-weight: var(--wb-font-body-m-font-weight); line-height: var(--wb-font-body-m-line-height); letter-spacing: var(--wb-font-body-m-letter-spacing); text-decoration: none; text-overflow: ellipsis; white-space: nowrap; }
.wb-info-list__title:hover { color: var(--wb-color-link-hover); }
.wb-info-list__tags { display: flex; gap: var(--wb-spacing-component-xs); }
.wb-info-list__time { display: inline-flex; align-items: center; gap: var(--wb-spacing-component-xs); color: var(--wb-color-text-secondary); font-size: var(--wb-font-body-m-font-size); font-weight: var(--wb-font-body-m-font-weight); line-height: var(--wb-font-body-m-line-height); letter-spacing: var(--wb-font-body-m-letter-spacing); }
.wb-info-list__time .workbench-icon { flex: 0 0 auto; }
</style>
