<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, ref, useId, useSlots, watch } from 'vue';
import WorkbenchButton from '../button/WorkbenchButton.vue';
import {
  acquireModalIsolation,
  controlledOverlays,
  focusableElementsIn,
  focusableFeedbackElements,
  focusIsInFeedback,
  nextFocusIndex,
  isTopOverlay,
} from '../overlay/isolation.js';
import '../scrollbar/scrollbar.css';

const props = defineProps({
  modelValue: { type: Boolean, default: false },
  title: { type: String, required: true },
  placement: {
    type: String,
    default: 'right',
    validator: (value) => ['right', 'bottom'].includes(value),
  },
  modal: { type: Boolean, default: true },
  panelSize: { type: [String, Number], default: undefined },
  closeOnMask: { type: Boolean, default: true },
  closeOnEsc: { type: Boolean, default: true },
  actions: { type: Array, default: () => [] },
  beforeClose: { type: Function, default: undefined },
});

const emit = defineEmits(['update:modelValue', 'close', 'action']);
const slots = useSlots();
const panel = ref(null);
const titleId = `wb-drawer-title-${useId().replaceAll(':', '')}`;
const closing = ref(false);
let previousFocus = null;
let releaseIsolation = null;
let activation = 0;
let closeRequest = 0;

const transitionName = computed(() => `wb-drawer-${props.placement}`);
const hasFooter = computed(() => Boolean(slots.footer) || props.actions.length > 0);

function normalizedPanelSize() {
  if (props.panelSize === undefined || props.panelSize === null || props.panelSize === '')
    return '';
  const value =
    typeof props.panelSize === 'number' ? `${props.panelSize}px` : props.panelSize.trim();
  const property = props.placement === 'right' ? 'width' : 'height';
  return CSS.supports(property, value) ? value : '';
}

function applyPanelSize() {
  if (!panel.value) return;
  const value = normalizedPanelSize();
  panel.value.style.removeProperty('--drawer-requested-size');
  if (value) {
    panel.value.style.setProperty('--drawer-requested-size', value);
    return;
  }
  if (props.placement === 'right') {
    const resolvedWidth = panel.value.getBoundingClientRect().width;
    panel.value.style.setProperty('--drawer-requested-size', `${resolvedWidth}px`);
  }
}

function focusableElements() {
  if (!panel.value) return [];
  const elements = focusableElementsIn(panel.value);
  controlledOverlays(panel.value).forEach((overlay) => {
    const overlayElements = focusableElementsIn(overlay);
    const trigger = overlay.id
      ? panel.value.querySelector(`[aria-controls="${CSS.escape(overlay.id)}"]`)
      : null;
    const triggerIndex = elements.indexOf(trigger);
    if (triggerIndex >= 0) elements.splice(triggerIndex + 1, 0, ...overlayElements);
  });
  return [...elements, ...focusableFeedbackElements()];
}

function focusIsInside() {
  return (
    panel.value?.contains(document.activeElement) ||
    focusIsInFeedback() ||
    controlledOverlays(panel.value).some((overlay) => overlay.contains(document.activeElement))
  );
}

function focusIsInOwnedOverlay() {
  return controlledOverlays(panel.value).some((overlay) =>
    overlay.contains(document.activeElement),
  );
}

function enableModalIsolation() {
  if (!releaseIsolation)
    releaseIsolation = acquireModalIsolation(() => [
      panel.value?.parentElement,
      ...controlledOverlays(panel.value),
    ]);
}
function disableModalIsolation() {
  releaseIsolation?.();
  releaseIsolation = null;
}

async function activate() {
  const generation = ++activation;
  previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
  await nextTick();
  if (generation !== activation || !props.modelValue || !panel.value) return;
  applyPanelSize();
  if (props.modal) enableModalIsolation();
  panel.value?.focus({ preventScroll: true });
}

function deactivate() {
  activation += 1;
  disableModalIsolation();
  if (previousFocus?.isConnected) previousFocus.focus();
  previousFocus = null;
}

async function requestClose(reason = 'button') {
  if (closing.value || !props.modelValue) return false;
  closing.value = true;
  const request = ++closeRequest;
  try {
    const allowed = props.beforeClose ? await props.beforeClose(reason) : true;
    if (allowed === false || request !== closeRequest || !props.modelValue) return false;
    emit('update:modelValue', false);
    emit('close', reason);
    return true;
  } catch {
    return false;
  } finally {
    if (request === closeRequest) closing.value = false;
  }
}

async function invokeAction(action) {
  emit('action', action);
  if (action.closeOnClick === true) await requestClose('action');
}

function handleDocumentKeydown(event) {
  if (!props.modelValue || !isTopOverlay(releaseIsolation)) return;
  if (!event.defaultPrevented && event.key === 'Escape' && props.closeOnEsc) {
    event.preventDefault();
    requestClose('escape');
    return;
  }
  if (!props.modal || event.key !== 'Tab') return;
  trapTabFocus(event);
}

// Keep focus within the top dialog, including owned teleported controls.
function trapTabFocus(event) {
  const elements = focusableElements();
  if (!elements.length) {
    event.preventDefault();
    panel.value?.focus();
    return;
  }
  const first = elements[0];
  const last = elements[elements.length - 1];
  const controlledId = document.activeElement?.getAttribute?.('aria-controls');
  const controlledOverlay = controlledId ? document.getElementById(controlledId) : null;
  const controlledTarget = controlledOverlay ? focusableElementsIn(controlledOverlay)[0] : null;
  if (document.activeElement === panel.value) {
    event.preventDefault();
    (event.shiftKey ? last : first).focus();
  } else if (
    !event.shiftKey &&
    controlledTarget &&
    controlledOverlays(panel.value).includes(controlledOverlay)
  ) {
    event.preventDefault();
    controlledTarget.focus();
  } else if (focusIsInOwnedOverlay() || focusableFeedbackElements().length) {
    event.preventDefault();
    elements[nextFocusIndex(elements, event.shiftKey)].focus();
  } else if (!focusIsInside()) {
    event.preventDefault();
    first.focus();
  } else if (event.shiftKey && document.activeElement === first) {
    event.preventDefault();
    last.focus();
  } else if (!event.shiftKey && document.activeElement === last) {
    event.preventDefault();
    first.focus();
  }
}

watch(
  () => props.modelValue,
  (open) => {
    closeRequest += 1;
    closing.value = false;
    return open ? activate() : deactivate();
  },
  { immediate: true, flush: 'sync' },
);
watch(
  () => [props.panelSize, props.placement],
  () => nextTick(applyPanelSize),
);
watch(
  () => props.modal,
  (modal) => {
    if (!props.modelValue) return;
    disableModalIsolation();
    if (modal) enableModalIsolation();
  },
);

onMounted(() => document.addEventListener('keydown', handleDocumentKeydown));
onBeforeUnmount(() => {
  closeRequest += 1;
  closing.value = false;
  document.removeEventListener('keydown', handleDocumentKeydown);
  deactivate();
});

defineExpose({ requestClose });
</script>

<template>
  <Teleport to="body">
    <Transition :name="transitionName">
      <div
        v-if="modelValue"
        class="wb-drawer-host"
        :class="[`wb-drawer-host--${placement}`, { 'is-modal': modal }]"
        data-testid="drawer-host"
      >
        <div
          v-if="modal"
          class="wb-drawer__mask"
          aria-hidden="true"
          data-testid="drawer-mask"
          @click="closeOnMask && requestClose('mask')"
        ></div>
        <section
          ref="panel"
          class="wb-drawer"
          :class="[`wb-drawer--${placement}`, { 'has-footer': hasFooter }]"
          role="dialog"
          :aria-modal="modal ? 'true' : undefined"
          :aria-labelledby="titleId"
          tabindex="-1"
        >
          <header class="wb-drawer__header">
            <h2
              :id="titleId"
              class="wb-drawer__title"
              :title="title"
            >
              {{ title }}
            </h2>
            <button
              class="wb-drawer__close"
              type="button"
              aria-label="关闭抽屉"
              @click="requestClose('button')"
            >
              <svg
                viewBox="0 0 16 16"
                aria-hidden="true"
              >
                <path d="m3 3 10 10M13 3 3 13" />
              </svg>
            </button>
          </header>
          <div class="wb-drawer__content wb-scrollbar">
            <slot />
          </div>
          <footer
            v-if="hasFooter"
            class="wb-drawer__footer"
          >
            <slot
              name="footer"
              :request-close="requestClose"
            >
              <WorkbenchButton
                v-for="action in actions"
                :key="action.id"
                :appearance="action.appearance === 'secondary' ? 'secondary' : 'primary'"
                :disabled="action.disabled"
                @click="invokeAction(action)"
                >{{ action.label }}</WorkbenchButton
              >
            </slot>
          </footer>
        </section>
      </div>
    </Transition>
  </Teleport>
</template>

<style>
.wb-drawer-host {
  position: fixed;
  z-index: var(--overlay-layer, auto);
  inset: 0;
  pointer-events: none;
}

.wb-drawer-host.is-modal {
  pointer-events: auto;
}

.wb-drawer__mask {
  position: absolute;
  inset: 0;
  border: 0;
  background: var(--wb-color-scrim-modal);
  cursor: default;
}

.wb-drawer {
  box-sizing: border-box;
  position: absolute;
  display: flex;
  overflow: hidden;
  flex-direction: column;
  border: 0;
  border-radius: var(--wb-radius-none);
  padding: var(--wb-spacing-layout-container-block) var(--wb-spacing-layout-container-inline);
  color: var(--wb-color-text-primary);
  background: var(--wb-color-surface-overlay);
  pointer-events: auto;
}

.wb-drawer:focus {
  outline: 0;
}

.wb-drawer--right {
  top: 0;
  right: 0;
  bottom: 0;
  width: var(--drawer-requested-size, fit-content);
  min-width: min(var(--wb-asset-wb-drawer-right-min-width), 100vw);
  max-width: 100vw;
  height: 100%;
  box-shadow: var(--wb-shadow-l-base);
}

.wb-drawer--bottom {
  right: 0;
  bottom: 0;
  left: 0;
  width: 100%;
  height: var(--drawer-requested-size, fit-content);
  min-height: min(var(--wb-asset-wb-drawer-bottom-min-height), 100vh);
  max-height: 100vh;
  box-shadow: var(--wb-shadow-t-m);
}

.wb-drawer__header {
  display: flex;
  flex: 0 0 auto;
  align-items: center;
  justify-content: space-between;
  gap: var(--wb-spacing-component-lg);
  padding: 0;
}

.wb-drawer.has-footer {
  padding-block-end: var(--wb-spacing-dialog-padding-block-end-with-actions);
}

.wb-drawer__title {
  min-width: 0;
  max-width: 100%;
  overflow: hidden;
  flex: 1 1 auto;
  margin: 0;
  font-size: var(--wb-font-headline-s-font-size);
  font-weight: var(--wb-font-headline-s-font-weight);
  line-height: var(--wb-font-headline-s-line-height);
  letter-spacing: var(--wb-font-headline-s-letter-spacing);
  text-overflow: ellipsis;
  white-space: nowrap;
}

.wb-drawer__close {
  display: block;
  width: var(--wb-icon-size-16);
  height: var(--wb-icon-size-16);
  flex: 0 0 var(--wb-icon-size-16);
  padding: 0;
  border: 0;
  color: var(--wb-color-icon-primary);
  background: transparent;
  cursor: pointer;
}

.wb-drawer__close:hover {
  color: var(--wb-color-icon-hover);
}

.wb-drawer__close:active {
  color: var(--wb-color-icon-active);
}

.wb-drawer__close:focus-visible {
  outline: 1px solid var(--wb-color-border-focus);
  outline-offset: 2px;
}

.wb-drawer__close svg {
  display: block;
  width: 100%;
  height: 100%;
  fill: none;
  stroke: currentColor;
}

.wb-drawer__content {
  --select-field-width: 100%;
  min-width: 0;
  min-height: 0;
  overflow: auto;
  flex: 1 1 auto;
  margin-block-start: var(--wb-spacing-component-lg);
  margin-inline-end: calc(0px - var(--wb-spacing-layout-container-inline));
  padding: 0
    calc(var(--wb-spacing-layout-container-inline) - var(--wb-asset-wb-scrollbar-scrollbar-width)) 0
    0;
  scrollbar-gutter: stable;
}

.wb-drawer__footer {
  display: flex;
  flex: 0 0 auto;
  justify-content: flex-end;
  gap: var(--wb-spacing-component-sm);
  margin-block-start: var(--wb-spacing-layout-action-gap);
  padding: 0;
}
</style>
