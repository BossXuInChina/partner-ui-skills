<script setup>
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import { createAutoDismiss, normalizeDuration } from '../feedback/autoDismiss.js';
import { computed, onBeforeUnmount, watch } from 'vue';
import WorkbenchLink from '../link/WorkbenchLink.vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import WorkbenchStatusIcon from '../icons/WorkbenchStatusIcon.vue';

const statusIconSemantics = {
  info: 'info',
  success: 'success',
  warning: 'warning',
  danger: 'alert-orange',
  critical: 'alert-red',
  error: 'close_circle',
};

const props = defineProps({
  items: { type: Array, default: () => [] },
  surface: {
    type: String,
    default: 'default',
    validator: (value) => ['default', 'subtle'].includes(value),
  },
  duration: { type: Number, default: 5000 },
});
const emit = defineEmits(['dismiss', 'link']);
const timers = new Map();
const dismissed = new Set();
const visibleItems = computed(() => props.items.slice(0, 3));
const statusIconName = (type) => `${statusIconSemantics[type]}/solid/16`;
function dismiss(item, reason) {
  if (dismissed.has(item.id)) return;
  dismissed.add(item.id);
  timers.get(item.id)?.dispose();
  emit('dismiss', { id: item.id, reason });
}
function pause(item, reason) {
  timers.get(item.id)?.pause(reason);
}
function resume(item, reason) {
  timers.get(item.id)?.resume(reason);
}
function onFocusOut(event, item) {
  if (!event.currentTarget.contains(event.relatedTarget)) resume(item, 'focus');
}
watch(
  () => [props.items.map((item) => item.id), props.duration],
  (_, previous) => {
    const ids = new Set(props.items.map((item) => item.id));
    for (const [id, timer] of timers)
      if (!ids.has(id)) {
        timer.dispose();
        timers.delete(id);
      }
    for (const id of dismissed) if (!ids.has(id)) dismissed.delete(id);
    for (const item of visibleItems.value) {
      if (dismissed.has(item.id)) continue;
      const existing = timers.get(item.id);
      const timer = existing || createAutoDismiss(() => dismiss(item, 'timeout'));
      timers.set(item.id, timer);
      if (!existing || previous?.[1] !== props.duration)
        timer.reset(normalizeDuration(props.duration, 5000));
    }
    for (const item of props.items.slice(3)) dismiss(item, 'overflow');
  },
  { immediate: true },
);
onBeforeUnmount(() => {
  for (const timer of timers.values()) timer.dispose();
});
</script>

<template>
  <TransitionGroup
    name="notification"
    tag="section"
    class="notification-stack"
    aria-label="通知提醒"
  >
    <article
      v-for="(item, index) in visibleItems"
      :key="item.id"
      class="notification-stack__item"
      :class="[
        `notification-stack__item--${item.type}`,
        `is-${surface}`,
        `stack-index-${index}`,
        { 'has-icon': item.showIcon !== false, 'has-close': item.showClose !== false },
      ]"
      :aria-label="item.title || item.description || item.linkLabel"
      :role="item.type === 'error' || item.type === 'critical' ? 'alert' : 'status'"
      @mouseenter="pause(item, 'pointer')"
      @mouseleave="resume(item, 'pointer')"
      @focusin="pause(item, 'focus')"
      @focusout="onFocusOut($event, item)"
    >
      <div
        class="notification-stack__header"
        :class="{ 'has-icon': item.showIcon !== false, 'has-close': item.showClose !== false }"
      >
        <span
          v-if="item.showIcon !== false"
          class="notification-stack__icon"
          :data-status-icon="statusIconName(item.type)"
          aria-hidden="true"
          ><WorkbenchStatusIcon :name="statusIconName(item.type)"
        /></span>
        <strong
          v-if="item.title"
          class="notification-stack__title"
          >{{ item.title }}</strong
        >
        <div
          v-else
          class="notification-stack__header-copy"
        >
          <p
            v-if="item.description"
            class="notification-stack__description"
          >
            {{ item.description }}
          </p>
          <WorkbenchLink
            v-if="item.linkLabel && item.linkHref"
            :href="item.linkHref"
            class="notification-stack__link"
            @click="emit('link', { id: item.id, href: item.linkHref })"
            >{{ item.linkLabel }}</WorkbenchLink
          >
        </div>
        <button
          v-if="item.showClose !== false"
          type="button"
          class="notification-stack__close"
          aria-label="关闭通知"
          @click="dismiss(item, 'button')"
        >
          <WorkbenchIcon name="/ic_public_close_line_10px" />
        </button>
        <div
          v-if="item.title && (item.description || (item.linkLabel && item.linkHref))"
          class="notification-stack__description-row"
        >
          <p
            v-if="item.description"
            class="notification-stack__description"
          >
            {{ item.description }}
          </p>
          <WorkbenchLink
            v-if="item.linkLabel && item.linkHref"
            :href="item.linkHref"
            class="notification-stack__link"
            @click="emit('link', { id: item.id, href: item.linkHref })"
            >{{ item.linkLabel }}</WorkbenchLink
          >
        </div>
      </div>
    </article>
  </TransitionGroup>
</template>

<style>
.notification-stack {
  position: fixed;
  z-index: var(--wb-asset-wb-notification-stack-layer);
  top: var(--wb-asset-wb-notification-top-offset);
  right: var(--wb-asset-wb-notification-right-offset);
  display: grid;
  width: fit-content;
  max-width: min(
    var(--wb-asset-wb-notification-max-width),
    calc(100% - var(--wb-asset-wb-notification-right-offset) * 2)
  );
  gap: var(--wb-asset-wb-notification-stack-gap);
  margin: 0;
  padding: 0;
}
.notification-stack__item {
  position: relative;
  display: grid;
  gap: var(--wb-spacing-component-sm);
  padding: var(--wb-spacing-component-lg);
  border-radius: var(--wb-radius-lg);
  color: var(--wb-color-text-primary);
  background: var(--wb-color-surface-overlay);
  box-shadow: var(--wb-shadow-lg);
}
.notification-stack__item.stack-index-0 {
  z-index: 1;
}
.notification-stack__item.stack-index-1 {
  z-index: 2;
}
.notification-stack__item.stack-index-2 {
  z-index: 3;
}
.notification-stack__item.is-subtle.notification-stack__item--info {
  background: var(--wb-color-info-secondary-subtle);
}
.notification-stack__item.is-subtle.notification-stack__item--success {
  background: var(--wb-color-success-primary-subtle);
}
.notification-stack__item.is-subtle.notification-stack__item--warning {
  background: var(--wb-color-warning-subtle);
}
.notification-stack__item.is-subtle.notification-stack__item--danger {
  background: var(--wb-color-alert-subtle);
}
.notification-stack__item.is-subtle.notification-stack__item--critical,
.notification-stack__item.is-subtle.notification-stack__item--error {
  background: var(--wb-color-error-subtle);
}
.notification-stack__icon {
  display: flex;
  width: var(--wb-asset-wb-notification-status-icon-size);
  height: var(--wb-asset-wb-notification-status-icon-size);
  align-items: center;
}
.notification-stack__header {
  --notification-content-column: 1;
  --notification-close-column: 2;
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  grid-template-rows: auto;
  align-items: center;
  column-gap: var(--wb-spacing-component-sm);
  row-gap: var(--wb-spacing-component-sm);
  min-width: 0;
}
.notification-stack__header.has-icon {
  --notification-content-column: 2;
  --notification-close-column: 3;
  grid-template-columns: var(--wb-asset-wb-notification-status-icon-size) minmax(0, 1fr);
}
.notification-stack__header.has-close {
  grid-template-columns: minmax(0, 1fr) 18px;
}
.notification-stack__header.has-icon.has-close {
  grid-template-columns: var(--wb-asset-wb-notification-status-icon-size) minmax(0, 1fr) 18px;
}
.notification-stack__icon {
  grid-column: 1;
  grid-row: 1;
}
.notification-stack__title,
.notification-stack__header-copy {
  grid-column: var(--notification-content-column);
  grid-row: 1;
  min-width: 0;
}
.notification-stack__description-row {
  grid-column: var(--notification-content-column);
  grid-row: 2;
}
.notification-stack__header-copy {
  display: flex;
  min-width: 0;
  align-items: baseline;
  flex-wrap: wrap;
  gap: var(--wb-spacing-component-sm);
}
.notification-stack__header-copy .notification-stack__description {
  flex: 1;
  min-width: 0;
}
.notification-stack__header-copy .notification-stack__link {
  margin-inline-start: auto;
}
.notification-stack__title {
  font-size: var(--wb-font-headline-s-font-size);
  font-weight: var(--wb-font-headline-s-font-weight);
  line-height: var(--wb-font-headline-s-line-height);
  letter-spacing: var(--wb-font-headline-s-letter-spacing);
}
.notification-stack__description-row {
  display: flex;
  min-width: 0;
  align-items: baseline;
  flex-wrap: wrap;
  gap: var(--wb-spacing-component-sm);
}
.notification-stack__description-row .notification-stack__description {
  flex: 1;
  min-width: 0;
}
.notification-stack__description-row .notification-stack__link {
  margin-inline-start: auto;
}
.notification-stack__close {
  grid-column: var(--notification-close-column);
  grid-row: 1;
  align-self: center;
}
.notification-stack__description {
  margin: 0;
  color: var(--wb-color-text-secondary);
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
}
.notification-stack__link {
  width: fit-content;
  font: inherit;
}
.notification-stack__close:focus-visible {
  outline: 1px solid var(--wb-color-border-focus);
  outline-offset: 2px;
}
.notification-stack__close {
  display: flex;
  width: auto;
  height: auto;
  align-items: center;
  justify-content: center;
  justify-self: end;
  padding: 0;
  border: 0;
  color: var(--wb-color-icon-primary);
  background: transparent;
  cursor: pointer;
}
.notification-stack__close:hover {
  color: var(--wb-color-icon-hover);
}
.notification-stack__close:active {
  color: var(--wb-color-icon-active);
}
.notification-enter-active,
.notification-leave-active,
.notification-move {
  transition:
    transform var(--wb-asset-wb-notification-motion-duration)
      var(--wb-asset-wb-notification-motion-easing),
    opacity var(--wb-asset-wb-notification-motion-duration)
      var(--wb-asset-wb-notification-motion-easing);
}
.notification-enter-from,
.notification-leave-to {
  opacity: 0;
  transform: scale(var(--wb-asset-wb-notification-entry-scale));
}
@media (prefers-reduced-motion: reduce) {
  .notification-enter-active,
  .notification-leave-active,
  .notification-move {
    transition-duration: 0s;
  }
}
</style>
