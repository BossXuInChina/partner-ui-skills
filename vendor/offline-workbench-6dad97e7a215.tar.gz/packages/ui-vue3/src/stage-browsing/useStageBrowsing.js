import { ref, toValue, watch } from 'vue';

export function useStageBrowsing({ current, count, viewed } = {}) {
  const clamp = (index) =>
    Math.max(0, Math.min(Math.max(0, (Number(toValue(count)) || 0) - 1), Number(index) || 0));
  const viewedStage = ref(clamp(viewed === undefined ? toValue(current) : toValue(viewed)));
  function browse(index) {
    viewedStage.value = clamp(index);
  }
  function goCurrent() {
    browse(toValue(current));
  }
  watch(
    () => toValue(count),
    () => browse(viewedStage.value),
    { flush: 'sync' },
  );
  return { viewedStage, goCurrent, browse };
}

export default useStageBrowsing;
