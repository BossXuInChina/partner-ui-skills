<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, ref, useId, useSlots, watch } from 'vue';
import WorkbenchButton from '../button/WorkbenchButton.vue';
import {
  acquireModalIsolation,
  controlledOverlays,
  focusableElementsIn,
  focusableFeedbackElements,
  focusIsInFeedback,
  nextFocusIndex,
  isTopOverlay,
} from '../overlay/isolation.js';
import '../scrollbar/scrollbar.css';

const props = defineProps({
  modelValue: { type: Boolean, default: false },
  title: { type: String, required: true },
  ariaDescribedby: { type: String, default: undefined },
  size: { type: String, default: 'm', validator: (value) => ['s', 'm', 'l', 'xl'].includes(value) },
  readonly: { type: Boolean, default: false },
  topNavigationHeight: { type: [String, Number], default: 0 },
  closeOnMask: { type: Boolean, default: true },
  closeOnEsc: { type: Boolean, default: true },
  actions: { type: Array, default: () => [] },
  beforeClose: { type: Function, default: undefined },
  showGrid: { type: Boolean, default: false },
});

const emit = defineEmits(['update:modelValue', 'close', 'action']);
const slots = useSlots();
const host = ref(null);
const panel = ref(null);
const gridColumnCount = ref(0);
const titleId = `wb-modal-title-${useId().replaceAll(':', '')}`;
const closing = ref(false);
let previousFocus = null;
let releaseIsolation = null;
let activation = 0;
let closeRequest = 0;

const hasFooter = computed(
  () => !props.readonly && (Boolean(slots.footer) || props.actions.length > 0),
);
const sizeSpanProperties = {
  s: '--wb-asset-wb-modal-size-s-columns',
  m: '--wb-asset-wb-modal-size-m-columns',
  l: '--wb-asset-wb-modal-size-l-columns',
  xl: '--wb-asset-wb-modal-size-xl-columns',
};

function assetProperty(key) {
  return `--wb-asset-wb-modal-${key}`;
}

function resolvedNumber(style, key) {
  return parseFloat(style.getPropertyValue(assetProperty(key)));
}

function normalizedTopNavigationHeight(style) {
  if (
    props.topNavigationHeight === undefined ||
    props.topNavigationHeight === null ||
    props.topNavigationHeight === ''
  ) {
    return '0px';
  }
  const value =
    typeof props.topNavigationHeight === 'number'
      ? `${props.topNavigationHeight}px`
      : props.topNavigationHeight.trim();
  return CSS.supports('height', value) ? value : '0px';
}

function applyLayout() {
  if (!host.value || !panel.value) return;
  const rootStyle = getComputedStyle(document.documentElement);
  const gridColumns = resolvedNumber(rootStyle, 'grid-columns');
  gridColumnCount.value = gridColumns;
  const gridWidth = resolvedNumber(rootStyle, 'grid-max-width');
  const gutter = resolvedNumber(rootStyle, 'grid-gutter');
  const span = parseFloat(rootStyle.getPropertyValue(sizeSpanProperties[props.size]));
  const safeEdge = parseFloat(rootStyle.getPropertyValue('--wb-spacing-screen-edge-expanded'));
  const columnWidth = (gridWidth - (gridColumns - 1) * gutter) / gridColumns;
  const targetWidth = span * columnWidth + (span - 1) * gutter;
  const safeWidth = Math.max(0, document.documentElement.clientWidth - safeEdge * 2);
  panel.value.style.setProperty('--modal-resolved-width', `${Math.min(targetWidth, safeWidth)}px`);
  host.value.style.setProperty(
    '--modal-top-navigation-height',
    normalizedTopNavigationHeight(rootStyle),
  );
}

function ownedOverlays() {
  return controlledOverlays(panel.value);
}

function focusableElements() {
  if (!panel.value) return [];
  const elements = focusableElementsIn(panel.value);
  ownedOverlays().forEach((overlay) => {
    const overlayElements = focusableElementsIn(overlay);
    const trigger = overlay.id
      ? panel.value.querySelector(`[aria-controls="${CSS.escape(overlay.id)}"]`)
      : null;
    const triggerIndex = elements.indexOf(trigger);
    if (triggerIndex >= 0) elements.splice(triggerIndex + 1, 0, ...overlayElements);
  });
  return [...elements, ...focusableFeedbackElements()];
}

function focusIsInside() {
  return (
    panel.value?.contains(document.activeElement) ||
    focusIsInFeedback() ||
    ownedOverlays().some((overlay) => overlay.contains(document.activeElement))
  );
}

function focusIsInOwnedOverlay() {
  return ownedOverlays().some((overlay) => overlay.contains(document.activeElement));
}

function enableModalIsolation() {
  if (!releaseIsolation)
    releaseIsolation = acquireModalIsolation(() => [
      panel.value?.parentElement,
      ...controlledOverlays(panel.value),
    ]);
}
function disableModalIsolation() {
  releaseIsolation?.();
  releaseIsolation = null;
}

async function activate() {
  const generation = ++activation;
  previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
  await nextTick();
  if (generation !== activation || !props.modelValue || !panel.value) return;
  applyLayout();
  enableModalIsolation();
  panel.value?.focus({ preventScroll: true });
}

function deactivate() {
  activation += 1;
  disableModalIsolation();
  if (previousFocus?.isConnected) previousFocus.focus();
  previousFocus = null;
}

async function requestClose(reason = 'button') {
  if (closing.value || !props.modelValue) return false;
  closing.value = true;
  const request = ++closeRequest;
  try {
    const allowed = props.beforeClose ? await props.beforeClose(reason) : true;
    if (allowed === false || request !== closeRequest || !props.modelValue) return false;
    emit('update:modelValue', false);
    emit('close', reason);
    return true;
  } catch {
    return false;
  } finally {
    if (request === closeRequest) closing.value = false;
  }
}

async function invokeAction(action) {
  emit('action', action);
  if (action.closeOnClick === true) await requestClose('action');
}

function handleDocumentKeydown(event) {
  if (!props.modelValue || !isTopOverlay(releaseIsolation)) return;
  if (!event.defaultPrevented && event.key === 'Escape' && props.closeOnEsc) {
    event.preventDefault();
    requestClose('escape');
    return;
  }
  if (event.key !== 'Tab') return;
  trapTabFocus(event);
}

// Keep focus within the top dialog, including owned teleported controls.
function trapTabFocus(event) {
  const elements = focusableElements();
  if (!elements.length) {
    event.preventDefault();
    panel.value?.focus();
    return;
  }
  const first = elements[0];
  const last = elements[elements.length - 1];
  const controlledId = document.activeElement?.getAttribute?.('aria-controls');
  const controlledOverlay = controlledId ? document.getElementById(controlledId) : null;
  const controlledTarget = controlledOverlay ? focusableElementsIn(controlledOverlay)[0] : null;
  if (document.activeElement === panel.value) {
    event.preventDefault();
    (event.shiftKey ? last : first).focus();
  } else if (
    !event.shiftKey &&
    controlledTarget &&
    controlledOverlays(panel.value).includes(controlledOverlay)
  ) {
    event.preventDefault();
    controlledTarget.focus();
  } else if (focusIsInOwnedOverlay() || focusableFeedbackElements().length) {
    event.preventDefault();
    elements[nextFocusIndex(elements, event.shiftKey)].focus();
  } else if (!focusIsInside()) {
    event.preventDefault();
    first.focus();
  } else if (event.shiftKey && document.activeElement === first) {
    event.preventDefault();
    last.focus();
  } else if (!event.shiftKey && document.activeElement === last) {
    event.preventDefault();
    first.focus();
  }
}

watch(
  () => props.modelValue,
  (open) => {
    closeRequest += 1;
    closing.value = false;
    return open ? activate() : deactivate();
  },
  { immediate: true, flush: 'sync' },
);
watch(
  () => [props.size, props.topNavigationHeight],
  () => nextTick(applyLayout),
);

onMounted(() => {
  document.addEventListener('keydown', handleDocumentKeydown);
  window.addEventListener('resize', applyLayout);
});
onBeforeUnmount(() => {
  closeRequest += 1;
  closing.value = false;
  document.removeEventListener('keydown', handleDocumentKeydown);
  window.removeEventListener('resize', applyLayout);
  deactivate();
});

defineExpose({ requestClose });
</script>

<template>
  <Teleport to="body">
    <Transition name="wb-modal">
      <div
        v-if="modelValue"
        ref="host"
        class="wb-modal-host"
        data-testid="modal-host"
      >
        <div
          class="wb-modal__mask"
          aria-hidden="true"
          data-testid="modal-mask"
          @click="closeOnMask && requestClose('mask')"
        ></div>
        <div
          v-if="showGrid"
          class="wb-modal__grid-overlay"
          data-wb-grid-overlay
          aria-hidden="true"
        >
          <i
            v-for="column in gridColumnCount"
            :key="column"
            data-wb-grid-track
            ><span data-wb-grid-label>{{ column }}</span></i
          >
        </div>
        <section
          ref="panel"
          class="wb-modal"
          :class="[`wb-modal--${size}`, { 'has-footer': hasFooter, 'is-readonly': readonly }]"
          :data-readonly="readonly || undefined"
          role="dialog"
          aria-modal="true"
          :aria-labelledby="titleId"
          :aria-describedby="ariaDescribedby"
          tabindex="-1"
        >
          <header class="wb-modal__header">
            <h2
              :id="titleId"
              class="wb-modal__title"
              :title="title"
            >
              {{ title }}
            </h2>
            <button
              class="wb-modal__close"
              type="button"
              aria-label="关闭对话框"
              @click="requestClose('button')"
            >
              <slot name="close-icon">
                <svg
                  viewBox="0 0 16 16"
                  aria-hidden="true"
                >
                  <path d="m3 3 10 10M13 3 3 13" />
                </svg>
              </slot>
            </button>
          </header>
          <div class="wb-modal__content wb-scrollbar">
            <slot :readonly="readonly" />
          </div>
          <footer
            v-if="hasFooter"
            class="wb-modal__footer"
          >
            <slot
              name="footer"
              :request-close="requestClose"
            >
              <WorkbenchButton
                v-for="action in actions"
                :key="action.id"
                :appearance="action.appearance === 'secondary' ? 'secondary' : 'primary'"
                :disabled="action.disabled"
                @click="invokeAction(action)"
                >{{ action.label }}</WorkbenchButton
              >
            </slot>
          </footer>
        </section>
      </div>
    </Transition>
  </Teleport>
</template>

<style>
.wb-modal-host {
  position: fixed;
  z-index: var(--overlay-layer, auto);
  inset: 0;
  display: flex;
  box-sizing: border-box;
  align-items: center;
  justify-content: center;
  padding-block: var(--modal-top-navigation-height) var(--wb-asset-wb-modal-bottom-clearance);
  padding-inline: var(--wb-spacing-screen-edge-expanded);
}

.wb-modal__mask {
  position: absolute;
  z-index: 0;
  inset: 0;
  background: var(--wb-color-scrim-modal);
}

.wb-modal__grid-overlay {
  z-index: 1;
  inset-inline-start: 50%;
  inset-inline-end: auto;
  inline-size: min(
    var(--wb-asset-wb-modal-grid-max-width),
    calc(100% - var(--wb-spacing-screen-edge-expanded) * 2)
  );
  grid-template-columns: repeat(var(--wb-asset-wb-modal-grid-columns), minmax(0, 1fr));
  column-gap: var(--wb-asset-wb-modal-grid-gutter);
  transform: translateX(-50%);
}

.wb-modal {
  position: relative;
  z-index: 2;
  display: flex;
  overflow: hidden;
  box-sizing: border-box;
  width: var(--modal-resolved-width);
  max-width: 100%;
  max-height: 100%;
  flex-direction: column;
  padding: var(--wb-spacing-layout-container-block) var(--wb-spacing-layout-container-inline);
  border: 0;
  border-radius: var(--wb-radius-lg);
  color: var(--wb-color-text-primary);
  background: var(--wb-color-surface-overlay);
  box-shadow: var(--wb-shadow-xl);
}

.wb-modal:focus {
  outline: 0;
}

.wb-modal.has-footer {
  padding-block-end: var(--wb-spacing-dialog-padding-block-end-with-actions);
}

.wb-modal__header {
  display: flex;
  flex: 0 0 auto;
  align-items: center;
  justify-content: space-between;
  gap: var(--wb-spacing-component-lg);
  padding: 0;
}

.wb-modal__title {
  min-width: 0;
  max-width: 100%;
  overflow: hidden;
  flex: 1 1 auto;
  margin: 0;
  font-size: var(--wb-font-headline-s-font-size);
  font-weight: var(--wb-font-headline-s-font-weight);
  line-height: var(--wb-font-headline-s-line-height);
  letter-spacing: var(--wb-font-headline-s-letter-spacing);
  text-overflow: ellipsis;
  white-space: nowrap;
}

.wb-modal__close {
  display: block;
  width: var(--wb-icon-size-16);
  height: var(--wb-icon-size-16);
  flex: 0 0 var(--wb-icon-size-16);
  padding: 0;
  border: 0;
  color: var(--wb-color-icon-primary);
  background: transparent;
  cursor: pointer;
}

.wb-modal__close:hover {
  color: var(--wb-color-icon-hover);
}

.wb-modal__close:active {
  color: var(--wb-color-icon-active);
}

.wb-modal__close:focus-visible {
  outline: 1px solid var(--wb-color-border-focus);
  outline-offset: 2px;
}

.wb-modal__close > svg {
  display: block;
  width: 100%;
  height: 100%;
  fill: none;
  stroke: currentColor;
}

.wb-modal__content {
  --select-field-width: 100%;
  min-width: 0;
  min-height: 0;
  overflow: auto;
  flex: 1 1 auto;
  margin-block-start: var(--wb-spacing-component-lg);
  margin-inline-end: calc(0px - var(--wb-spacing-layout-container-inline));
  padding: 0
    calc(var(--wb-spacing-layout-container-inline) - var(--wb-asset-wb-scrollbar-scrollbar-width)) 0
    0;
  scrollbar-gutter: stable;
}

.wb-modal__footer {
  display: flex;
  flex: 0 0 auto;
  justify-content: flex-end;
  gap: var(--wb-spacing-component-sm);
  margin-block-start: var(--wb-spacing-layout-action-gap);
  padding: 0;
}
</style>
