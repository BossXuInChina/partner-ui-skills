/** A zero duration disables dismissal. Invalid values use the documented default. */
export function normalizeDuration(value, fallback = 0) {
  return Number.isFinite(value) && value >= 0 ? value : fallback;
}

/** Pointer and focus pause independently; resuming one must not clear the other. */
export function createAutoDismiss(callback) {
  let timer;
  let remaining = 0;
  let startedAt = 0;
  let active = false;
  const reasons = new Set();
  function clear() { clearTimeout(timer); timer = undefined; }
  function run() {
    if (!active || timer !== undefined || reasons.size) return;
    startedAt = Date.now();
    timer = setTimeout(() => { timer = undefined; active = false; callback(); }, remaining);
  }
  return {
    reset(duration) { clear(); remaining = normalizeDuration(duration); active = remaining > 0; run(); },
    pause(reason) {
      reasons.add(reason);
      if (timer !== undefined) { remaining = Math.max(0, remaining - (Date.now() - startedAt)); clear(); }
    },
    resume(reason) { reasons.delete(reason); run(); },
    stop() { clear(); active = false; },
    dispose() { clear(); active = false; reasons.clear(); },
  };
}
