<script setup>
import { useFieldControl } from '../form/fieldContext.js';
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import { computed, nextTick, ref, watch } from 'vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
const props = defineProps({ modelValue:{type:Number,default:0}, step:{type:Number,default:1}, min:{type:Number,default:undefined}, max:{type:Number,default:undefined}, disabled:Boolean, name:String, ariaLabel:{type:String,default:'数量'} });
const native = ref(null);
const emit = defineEmits(['update:modelValue','change']);
const hasMin=computed(()=>Number.isFinite(props.min)), hasMax=computed(()=>Number.isFinite(props.max));
const safeStep=computed(()=>Number.isFinite(props.step)&&props.step>0?props.step:1);
const places=value=>String(value).split('.')[1]?.length??0;
const precision=computed(()=>Math.max(places(safeStep.value),places(props.modelValue),hasMin.value?places(props.min):0,hasMax.value?places(props.max):0));
const clamp=value=>Math.min(hasMax.value?props.max:Infinity,Math.max(hasMin.value?props.min:-Infinity,value));
const current=computed(()=>clamp(Number.isFinite(props.modelValue)?props.modelValue:0));
const format=value=>Number(value.toFixed(precision.value)).toString();
const draft=ref(format(current.value)); watch(current,value=>{draft.value=format(value);});
const disabled=computed(()=>props.disabled);
const canDecrement=computed(()=>!disabled.value&&(!hasMin.value||current.value>props.min));
const canIncrement=computed(()=>!disabled.value&&(!hasMax.value||current.value<props.max));
function update(value,source){const next=Number(clamp(Number(value)).toFixed(precision.value));if(next===current.value){draft.value=format(current.value);return;}emit('update:modelValue',next);emit('change',{value:next,source});nextTick(()=>{draft.value=format(current.value);});}
function commit(){if(disabled.value)return;const value=Number(draft.value);if(!draft.value.trim()||!Number.isFinite(value)){draft.value=format(current.value);return;}update(value,'input');}
function handleKeydown(event){if(event.key==='Enter'){event.preventDefault();commit();return;}if(event.key==='ArrowDown'&&canDecrement.value){event.preventDefault();update(current.value-safeStep.value,'decrement');}if(event.key==='ArrowUp'&&canIncrement.value){event.preventDefault();update(current.value+safeStep.value,'increment');}}
const { attrs: fieldAttrs } = useFieldControl(() => props.modelValue, { nativeRequired: true, focus: () => native.value?.focus() });
</script>
<template>
  <div class="wb-counter-input" :class="{'is-disabled':disabled}" role="group" :aria-label="ariaLabel">
    <button class="wb-counter-input__action" type="button" :disabled="!canDecrement" aria-label="减少" @click="canDecrement&&update(current-safeStep,'decrement')"><WorkbenchIcon name="/ic_public_minus_line_14px" /></button>
    <span class="wb-counter-input__divider wb-counter-input__divider--start" aria-hidden="true" />
    <input ref="native" v-bind="fieldAttrs" class="wb-counter-input__value" type="text" role="spinbutton" :name="name" :value="draft" :disabled="disabled" inputmode="decimal" autocomplete="off" :aria-label="`${ariaLabel}数值`" :aria-valuenow="current" :aria-valuemin="hasMin ? min : undefined" :aria-valuemax="hasMax ? max : undefined" @input="draft=$event.target.value" @keydown="handleKeydown" @blur="commit">
    <span class="wb-counter-input__divider wb-counter-input__divider--end" aria-hidden="true" />
    <button class="wb-counter-input__action" type="button" :disabled="!canIncrement" aria-label="增加" @click="canIncrement&&update(current+safeStep,'increment')"><WorkbenchIcon name="/ic_public_plus_line_14px" /></button>
  </div>
</template>
<style scoped>
.wb-counter-input{box-sizing:border-box;position:relative;display:grid;grid-template-columns:var(--wb-asset-wb-number-count-action-width) 1fr var(--wb-asset-wb-number-count-action-width);width:var(--wb-asset-wb-number-count-width);height:var(--wb-asset-wb-number-count-height);border:1px solid var(--wb-color-border);border-radius:var(--wb-radius-sm);color:var(--wb-color-text-primary);background:var(--wb-color-fill-subtle-default);font:var(--wb-font-body-m-font-weight) var(--wb-font-body-m-font-size)/var(--wb-font-body-m-line-height) inherit}
.wb-counter-input:not(.is-disabled):hover,.wb-counter-input:not(.is-disabled).is-hover{border-color:var(--wb-color-border-hover)}
.wb-counter-input:not(.is-disabled):has(.wb-counter-input__action:active),.wb-counter-input:not(.is-disabled).is-pressed,.wb-counter-input:not(.is-disabled):focus-within,.wb-counter-input:not(.is-disabled).is-focus{border-color:var(--wb-color-border-focus)}
.wb-counter-input:not(.is-disabled):has(:focus-visible),.wb-counter-input:not(.is-disabled).is-focus{outline:2px solid var(--wb-color-border-focus);outline-offset:2px}
.wb-counter-input__action:focus{outline:0}
.wb-counter-input.is-disabled{border-color:var(--wb-color-border-disabled);color:var(--wb-color-text-disabled);background:var(--wb-color-fill-subtle-disabled)}
.wb-counter-input__action{z-index:1;display:grid;width:100%;height:100%;place-items:center;padding:0;border:0;border-radius:inherit;color:var(--wb-color-icon-secondary);background:transparent;cursor:pointer}.wb-counter-input__action:hover:not(:disabled),.wb-counter-input__action:active:not(:disabled){color:var(--wb-color-icon-primary)}.wb-counter-input__action:disabled{color:var(--wb-color-icon-disabled);cursor:not-allowed}
.wb-counter-input__value{z-index:1;min-width:0;padding:0;border:0;outline:0;color:inherit;background:transparent;font:inherit;text-align:center}.wb-counter-input__value:disabled{cursor:not-allowed}
.wb-counter-input__divider{position:absolute;z-index:0;top:50%;transform:translateY(-50%);width:var(--wb-asset-wb-number-count-divider-width);height:var(--wb-asset-wb-number-count-divider-height);background:var(--wb-color-border)}.wb-counter-input__divider--start{inset-inline-start:calc(var(--wb-asset-wb-number-count-action-width) - var(--wb-asset-wb-number-count-divider-width))}.wb-counter-input__divider--end{inset-inline-end:calc(var(--wb-asset-wb-number-count-action-width) - var(--wb-asset-wb-number-count-divider-width))}.wb-counter-input.is-disabled .wb-counter-input__divider{background:var(--wb-color-border-separator)}
</style>
