<script setup>
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import { computed, nextTick, onBeforeUnmount, onMounted, ref, useId, watch } from 'vue';

const props = defineProps({
  modelValue: { type: Number, default: 0 },
  items: { type: Array, default: () => [] },
  ariaLabel: { type: String, default: '走马灯' },
  disabled: { type: Boolean, default: false },
  autoplay: { type: Boolean, default: true },
  contentMotion: { type: Boolean, default: false },
  showNavigation: { type: Boolean, default: true },
  indicatorPlacement: { type: String, default: 'overlay', validator: (value) => ['overlay', 'below'].includes(value) },
  transitionStyle: { type: String, default: 'fade', validator: (value) => ['fade', 'slide'].includes(value) },
});
const emit = defineEmits(['update:modelValue', 'change']);
const instanceId = `wb-carousel-${useId()}`;
const hovered = ref(false);
const slideDirection = ref(1);
const focused = ref(false);
const documentHidden = ref(false);
const reducedMotion = ref(false);
let timer = null;
let motionQuery = null;
const contentAnimations = new Set();
function cancelContentMotion() {
  for (const animation of contentAnimations) animation.cancel();
  contentAnimations.clear();
}
function animateContent(element, entering, done) {
  if (!props.contentMotion || reducedMotion.value) { done?.(); return; }
  const nodes = [...element.querySelectorAll('[data-wb-carousel-motion]')];
  const style = getComputedStyle(element);
  const token = key => parseFloat(style.getPropertyValue(`--wb-asset-wb-carousel-content-${key}`));
  const duration = token('duration'), stagger = token('stagger'), offset = token('offset');
  const animations = nodes.map((node, index) => {
    const animation = node.animate(entering
      ? [{ opacity: 0, transform: `translateY(${offset}px)` }, { opacity: 1, transform: 'translateY(0)' }]
      : [{ opacity: 1, transform: 'translateY(0)' }, { opacity: 0, transform: `translateY(${offset}px)` }],
    { duration, delay: (entering ? index : nodes.length - index - 1) * stagger, easing: 'ease-out', fill: 'both' });
    contentAnimations.add(animation);
    return animation;
  });
  Promise.allSettled(animations.map(animation => animation.finished)).then(() => {
    for (const animation of animations) { animation.cancel(); contentAnimations.delete(animation); }
    done?.();
  });
}
const motionSlide = ref(null);
const displayedIndex = ref(Math.min(Math.max(Number.isInteger(props.modelValue) ? props.modelValue : 0, 0), Math.max(0, props.items.length - 1)));
let motionRevision = 0;
async function changeContent() {
  const revision = ++motionRevision;
  cancelContentMotion();
  if (props.contentMotion && motionSlide.value) await new Promise(done => animateContent(motionSlide.value, false, done));
  if (revision !== motionRevision) return;
  displayedIndex.value = safeIndex.value;
  await nextTick();
  if (revision !== motionRevision || !props.contentMotion || !motionSlide.value) return;
  animateContent(motionSlide.value, true);
}



const itemCount = computed(() => props.items.length);
const hasMultiple = computed(() => itemCount.value > 1);
const safeIndex = computed(() => itemCount.value ? Math.min(Math.max(Number.isInteger(props.modelValue) ? props.modelValue : 0, 0), itemCount.value - 1) : 0);
const activeItem = computed(() => props.items[safeIndex.value]);
const shouldAutoplay = computed(() => hasMultiple.value && props.autoplay && !props.disabled && !hovered.value && !focused.value && !documentHidden.value && !reducedMotion.value);
const slideId = index => `${instanceId}-slide-${index}`;

function stopAutoplay() {
  if (timer) window.clearInterval(timer);
  timer = null;
}
function syncAutoplay() {
  stopAutoplay();
  if (shouldAutoplay.value) timer = window.setInterval(() => goTo(safeIndex.value + 1), Number.parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--wb-asset-wb-carousel-autoplay-interval')) || 5000);
}
function normalized(index) {
  if (!itemCount.value) return 0;
  return ((index % itemCount.value) + itemCount.value) % itemCount.value;
}
function goTo(index, userInitiated = false) {
  if (!hasMultiple.value || props.disabled) return;
  const next = normalized(index);
  if (next !== safeIndex.value) slideDirection.value = index < safeIndex.value ? -1 : 1;
  if (next !== safeIndex.value) {
    emit('update:modelValue', next);
    emit('change', next, props.items[next]);
  }
  if (userInitiated) syncAutoplay();
}
function onKeydown(event) {
  if (props.disabled || !hasMultiple.value) return;
  if (event.key === 'ArrowLeft') { event.preventDefault(); goTo(safeIndex.value - 1, true); }
  else if (event.key === 'ArrowRight') { event.preventDefault(); goTo(safeIndex.value + 1, true); }
  else if (event.key === 'Home') { event.preventDefault(); goTo(0, true); }
  else if (event.key === 'End') { event.preventDefault(); goTo(itemCount.value - 1, true); }
}
function onVisibilityChange() { documentHidden.value = document.hidden; }
function onMotionChange(event) { reducedMotion.value = event.matches; }

watch(() => [props.modelValue, itemCount.value], () => {
  if (itemCount.value && props.modelValue !== safeIndex.value) emit('update:modelValue', safeIndex.value);
}, { immediate: true });
watch([safeIndex, () => props.contentMotion, reducedMotion], changeContent);
watch(shouldAutoplay, syncAutoplay, { immediate: true });
watch(() => props.items, syncAutoplay, { deep: true });
onMounted(() => {
  documentHidden.value = document.hidden;
  motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
  reducedMotion.value = motionQuery.matches;
  document.addEventListener('visibilitychange', onVisibilityChange);
  motionQuery.addEventListener('change', onMotionChange);
  syncAutoplay();
});
onBeforeUnmount(() => {
  motionRevision += 1;
  cancelContentMotion();
  stopAutoplay();
  document.removeEventListener('visibilitychange', onVisibilityChange);
  motionQuery?.removeEventListener('change', onMotionChange);
});
</script>

<template>
  <section
    class="wb-carousel"
    :class="{ 'is-disabled': disabled, 'is-empty': !itemCount, 'is-slide-reverse': slideDirection < 0, 'wb-carousel--indicators-below': indicatorPlacement === 'below' }"
    :aria-label="ariaLabel"
    aria-roledescription="carousel"
    @mouseenter="hovered = true"
    @mouseleave="hovered = false"
    @focusin="focused = true"
    @focusout="event => { if (!event.currentTarget.contains(event.relatedTarget)) focused = false; }"
    @keydown="onKeydown"
  >
    <div class="wb-carousel__viewport">
      <template v-if="itemCount">
        <div v-if="contentMotion" ref="motionSlide" :id="slideId(displayedIndex)" class="wb-carousel__slide" role="group" aria-roledescription="slide" :aria-label="`${displayedIndex + 1} / ${itemCount}`">
          <slot name="slide" :item="items[displayedIndex]" :index="displayedIndex" :selected="true">{{ items[displayedIndex]?.label }}</slot>
        </div>
        <Transition v-else :name="transitionStyle === 'slide' ? 'wb-carousel-scroll' : 'wb-carousel-slide'">
          <div :id="slideId(safeIndex)" :key="activeItem?.key ?? safeIndex" class="wb-carousel__slide" role="group" aria-roledescription="slide" :aria-label="`${safeIndex + 1} / ${itemCount}`">
            <slot name="slide" :item="activeItem" :index="safeIndex" :selected="true">{{ activeItem?.label ?? activeItem?.key ?? `第 ${safeIndex + 1} 项` }}</slot>
          </div>
        </Transition>
      </template>
      <slot v-else name="empty" />
      <template v-if="hasMultiple">
        <button v-if="showNavigation" class="wb-carousel__navigation wb-carousel__navigation--previous" type="button" aria-label="上一张" :aria-controls="slideId(safeIndex)" :disabled="disabled" @click="goTo(safeIndex - 1, true)">
          <WorkbenchIcon name="箭头/尺寸=16,方向=左箭头" :size="16" />
        </button>
        <button v-if="showNavigation" class="wb-carousel__navigation wb-carousel__navigation--next" type="button" aria-label="下一张" :aria-controls="slideId(safeIndex)" :disabled="disabled" @click="goTo(safeIndex + 1, true)">
          <WorkbenchIcon name="箭头/尺寸=16,方向=右箭头" :size="16" />
        </button>
      </template>
    </div>
    <div v-if="hasMultiple" class="wb-carousel__indicators" role="group" aria-label="选择图片">
      <button v-for="(item, index) in items" :key="item.key" class="wb-carousel__indicator" :class="{ 'is-current': index === safeIndex }" type="button" :aria-label="`切换到第 ${index + 1} 张`" :aria-current="index === safeIndex ? 'true' : undefined" :disabled="disabled" @click="goTo(index, true)"><span class="wb-carousel__indicator-mark" /></button>
    </div>
  </section>
</template>

<style>
.wb-carousel { position: relative; display: grid; width: 100%; min-width: 0; }
.wb-carousel__viewport { position: relative; min-width: 0; overflow: hidden; }
.wb-carousel__slide { width: 100%; min-width: 0; }
.wb-carousel { --carousel-navigation-default-fill: var(--wb-asset-wb-carousel-navigation-default-fill); --carousel-navigation-hover-fill: var(--wb-asset-wb-carousel-navigation-hover-fill); --carousel-navigation-disabled-fill: var(--wb-asset-wb-carousel-navigation-disabled-fill); }
.wb-carousel__navigation { position: absolute; z-index: 1; top: 50%; display: inline-flex; width: var(--wb-asset-wb-carousel-navigation-size); height: var(--wb-asset-wb-carousel-navigation-size); align-items: center; justify-content: center; padding: 0; border: 0; border-radius: var(--wb-radius-full); background: var(--carousel-navigation-default-fill); color: var(--wb-color-icon-secondary); cursor: pointer; opacity: 0; transform: translateY(-50%); transition: opacity 160ms ease-out, background 160ms ease-out, color 160ms ease-out; }
.wb-carousel:hover .wb-carousel__navigation, .wb-carousel:focus-within .wb-carousel__navigation { opacity: 1; }
.wb-carousel__navigation:hover:not(:disabled), .wb-carousel__navigation:active:not(:disabled) { background: var(--carousel-navigation-hover-fill); color: var(--wb-color-icon-primary); }
.wb-carousel__navigation:disabled { background: var(--carousel-navigation-disabled-fill); color: var(--wb-color-icon-disabled); }
.wb-carousel__navigation:focus-visible, .wb-carousel__indicator:focus-visible { outline: 2px solid var(--wb-color-border-focus); outline-offset: 2px; }
.wb-carousel__navigation:disabled, .wb-carousel__indicator:disabled { cursor: not-allowed; }
.wb-carousel__navigation--previous { left: var(--wb-asset-wb-carousel-navigation-inset); }
.wb-carousel__navigation--next { right: var(--wb-asset-wb-carousel-navigation-inset); }
.wb-carousel__indicators { position: absolute; z-index: 2; bottom: var(--wb-asset-wb-carousel-indicator-bottom-inset); left: 50%; display: flex; width: max-content; max-width: calc(100% - (var(--wb-asset-wb-carousel-navigation-inset) * 2)); align-items: center; gap: var(--wb-spacing-component-md); transform: translateX(-50%); }
.wb-carousel--indicators-below .wb-carousel__indicators { position: static; justify-self: center; max-width: 100%; margin-top: var(--wb-spacing-component-lg); transform: none; }
.wb-carousel__indicator { position: relative; display: inline-flex; width: var(--wb-asset-wb-carousel-indicator-size); height: var(--wb-asset-wb-carousel-indicator-size); align-items: center; justify-content: center; box-sizing: content-box; margin-inline: calc(var(--wb-asset-wb-carousel-indicator-hit-size) / -4); padding: calc(var(--wb-asset-wb-carousel-indicator-hit-size) / 4); border: 0; background: transparent; cursor: pointer; transition: width var(--wb-asset-wb-carousel-indicator-motion-duration) var(--wb-asset-wb-carousel-indicator-motion-easing); }
.wb-carousel__indicator-mark { display: block; flex: 0 0 auto; width: var(--wb-asset-wb-carousel-indicator-size); height: var(--wb-asset-wb-carousel-indicator-size); border-radius: var(--wb-radius-full); background: var(--wb-color-none); transition: width var(--wb-asset-wb-carousel-indicator-motion-duration) var(--wb-asset-wb-carousel-indicator-motion-easing), background var(--wb-asset-wb-carousel-indicator-motion-duration) var(--wb-asset-wb-carousel-indicator-motion-easing); }
.wb-carousel__indicator:hover:not(:disabled) .wb-carousel__indicator-mark { background: var(--wb-color-icon-hover); }
.wb-carousel__indicator.is-current { width: var(--wb-asset-wb-carousel-active-indicator-width); }
.wb-carousel__indicator.is-current .wb-carousel__indicator-mark { width: var(--wb-asset-wb-carousel-active-indicator-width); background: var(--wb-color-icon-primary); }
[data-wb-theme="dark"] .wb-carousel__indicator-mark, [data-wb-theme="dark"] .wb-carousel__indicator:hover:not(:disabled) .wb-carousel__indicator-mark, [data-wb-theme="dark"] .wb-carousel__indicator.is-current .wb-carousel__indicator-mark { background: var(--wb-color-text-inverse); }
.wb-carousel-slide-enter-active { position: relative; z-index: 1; transition: opacity var(--wb-asset-wb-carousel-slide-motion-duration) var(--wb-asset-wb-carousel-slide-motion-easing); }
.wb-carousel-slide-enter-from { opacity: 0; }
.wb-carousel-slide-leave-active { position: absolute; inset: 0; animation: wb-carousel-slide-hold var(--wb-asset-wb-carousel-slide-motion-duration) var(--wb-asset-wb-carousel-slide-motion-easing); }
@keyframes wb-carousel-slide-hold { from, to { opacity: 1; } }
.wb-carousel-scroll-enter-active, .wb-carousel-scroll-leave-active { transition: transform var(--wb-asset-wb-carousel-slide-motion-duration) var(--wb-asset-wb-carousel-slide-motion-easing); }
.wb-carousel-scroll-enter-active { position: relative; z-index: 1; }
.wb-carousel-scroll-leave-active { position: absolute; inset: 0; }
.wb-carousel-scroll-enter-from { transform: translateX(100%); }
.is-slide-reverse .wb-carousel-scroll-enter-from { transform: translateX(-100%); }
.wb-carousel-scroll-leave-to { transform: translateX(-100%); }
.is-slide-reverse .wb-carousel-scroll-leave-to { transform: translateX(100%); }
@media (prefers-reduced-motion: reduce) { .wb-carousel-scroll-enter-active, .wb-carousel-scroll-leave-active { transition: none; } }
@media (prefers-reduced-motion: reduce) { .wb-carousel__slide, .wb-carousel__navigation, .wb-carousel__indicator-mark, .wb-carousel-slide-enter-active, .wb-carousel-slide-leave-active { animation: none; transition: none; } }
</style>
