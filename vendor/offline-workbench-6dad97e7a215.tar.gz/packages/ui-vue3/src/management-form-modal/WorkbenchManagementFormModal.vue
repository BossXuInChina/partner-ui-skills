<script setup>
import WorkbenchModal from '../modal/WorkbenchModal.vue';

defineProps({
  modelValue: Boolean,
  title: { type: String, required: true },
  size: { type: String, default: 'l', validator: (value) => ['m', 'l'].includes(value) },
  contentClass: { type: String, default: '' },
});
defineEmits(['update:modelValue']);
</script>

<template>
  <WorkbenchModal
    :model-value="modelValue"
    :title="title"
    :size="size"
    @update:model-value="$emit('update:modelValue', $event)"
  >
    <div :class="['wb-management-form-modal__content', contentClass]">
      <slot name="notice" />
      <slot />
      <slot name="supplement" />
    </div>
    <template
      v-if="$slots.footer"
      #footer
      ><slot name="footer"
    /></template>
  </WorkbenchModal>
</template>

<style>
.wb-management-form-modal__content {
  display: grid;
  gap: var(--wb-spacing-layout-content-gap);
  min-width: 0;
}
.wb-modal__content:has(.wb-management-form-modal__content) {
  margin-inline-start: calc(0px - var(--wb-spacing-layout-container-inline));
  padding-inline-start: var(--wb-spacing-layout-container-inline);
}
</style>
