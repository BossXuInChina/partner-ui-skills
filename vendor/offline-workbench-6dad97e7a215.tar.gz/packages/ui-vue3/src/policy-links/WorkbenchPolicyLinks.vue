<script setup lang="ts">
// Block: rule / policy document links (document icon + name + chevron) placed under a tab bar.
import type { PropType } from 'vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import type { PolicyLinkItem } from '../../types/home-blocks';
defineProps({
  items: { type: Array as PropType<Array<string | PolicyLinkItem>>, required: true },
  href: { type: String, default: '#' },
  ariaLabel: { type: String, default: '规则与政策' },
});
const label = (item: string | PolicyLinkItem) => (typeof item === 'string' ? item : item.label);
const target = (item: string | PolicyLinkItem, fallback: string) =>
  typeof item === 'string' ? fallback : (item.href ?? fallback);
</script>

<template>
  <nav class="wb-policy-links" :aria-label="ariaLabel">
    <a v-for="item in items" :key="label(item)" class="wb-policy-links__item" :href="target(item, href)">
      <WorkbenchIcon name="文件/尺寸=14" /><span>{{ label(item) }}</span><WorkbenchIcon name="/ic_arrow_right_line_12px" />
    </a>
  </nav>
</template>

<style>
.wb-policy-links { display: flex; flex-wrap: wrap; gap: var(--wb-spacing-component-sm) var(--wb-spacing-component-xl); }
.wb-policy-links__item { display: inline-flex; align-items: center; gap: var(--wb-spacing-component-xs); color: var(--wb-color-text-primary); font-size: var(--wb-font-body-m-font-size); font-weight: var(--wb-font-body-m-font-weight); line-height: var(--wb-font-body-m-line-height); letter-spacing: var(--wb-font-body-m-letter-spacing); text-decoration: none; }
.wb-policy-links__item:hover { color: var(--wb-color-link-hover); }
</style>
