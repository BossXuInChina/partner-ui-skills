<script setup>
import {
  Comment,
  Fragment,
  Text,
  computed,
  inject,
  nextTick,
  onMounted,
  onBeforeUnmount,
  provide,
  ref,
  shallowReactive,
  useId,
  useSlots,
  watch,
} from 'vue';
import WorkbenchTooltip from '../tooltip/WorkbenchTooltip.vue';
import WorkbenchRequiredMark from './WorkbenchRequiredMark.vue';
import { formContextKey, getPath } from './formContext.js';
import { fieldContextKey } from './fieldContext.js';

const props = defineProps({
  prop: { type: String, default: '' },
  modelValue: { default: undefined },
  required: Boolean,
  hint: { type: String, default: '' },
  labelPosition: {
    type: String,
    default: 'top',
    validator: (value) => ['top', 'left'].includes(value),
  },
  labelWidth: { type: String, default: 'var(--wb-asset-wb-form-label-width)' },
  label: { type: String, required: true },
  mode: {
    type: String,
    default: '',
    validator: (value) => ['', 'readonly', 'editable'].includes(value),
  },
  size: {
    type: String,
    default: '',
    validator: (value) => ['', 's', 'base', 'm', 'l', 'xl'].includes(value),
  },
  rules: { type: Array, default: () => [] },
  validateStatus: {
    type: String,
    default: '',
    validator: (value) => ['', 'error'].includes(value),
  },
  message: { type: String, default: '' },
  formatter: Function,
});
const context = inject(formContextKey, null);
const slots = useSlots();
if (context && !props.prop) throw new Error('WorkbenchFormItem inside WorkbenchForm requires prop');
const controls = shallowReactive(new Map());
const labelPosition = computed(() => context?.labelPosition.value || props.labelPosition);
const labelWidth = computed(() => context?.labelWidth.value || props.labelWidth);
const showGrid = computed(() => context?.showGrid.value || false);
const customGrid = computed(() => context?.hasCustomSize.value || false);
const labelElement = ref(null);
const naturalLabelWidth = ref(0);
const displayLabel = ref(props.label);
const labelTruncated = computed(() => displayLabel.value !== props.label);
let labelObserver;

const id = `wb-field-${useId()}`;
const root = ref(null);
const localStatus = ref('');
const localFeedback = ref('');
const touched = ref(false);
const status = computed(() => props.validateStatus || localStatus.value);
const feedback = computed(() => (props.validateStatus ? props.message : localFeedback.value));
const disabled = computed(
  () => Boolean(context?.disabled?.value) && effectiveMode.value !== 'readonly',
);
const effectiveMode = computed(() =>
  context
    ? context.mode.value === 'mixed'
      ? props.mode || 'editable'
      : context.mode.value
    : props.mode || 'editable',
);
const required = computed(
  () =>
    effectiveMode.value !== 'readonly' &&
    (context
      ? props.rules.some((rule) => rule?.required)
      : props.required || props.rules.some((rule) => rule?.required)),
);
const value = computed(() =>
  context
    ? getPath(context.model.value, props.prop)
    : props.modelValue !== undefined
      ? props.modelValue
      : [...controls.values()][0]?.value(),
);
const model = computed(() => context?.model.value || { [props.prop || 'field']: value.value });
const displayValue = computed(() =>
  props.formatter
    ? props.formatter(value.value, model.value)
    : Array.isArray(value.value)
      ? value.value.join('、') || '—'
      : typeof value.value === 'boolean'
        ? value.value
          ? '是'
          : '否'
        : value.value === '' || value.value == null
          ? '—'
          : value.value,
);
const span = computed(() => ({ s: 2, base: 4, m: 6, l: 8, xl: 10 })[props.size] ?? null);
const describedBy = computed(() =>
  feedback.value ? `${id}-feedback` : props.hint ? `${id}-hint` : undefined,
);
const firstControl = computed(() => [...controls.values()][0]);
const labelFor = computed(() =>
  firstControl.value?.labelable ? firstControl.value.id : undefined,
);
const invalid = computed(() => effectiveMode.value !== 'readonly' && status.value === 'error');
const registeredStatus = computed(() => (effectiveMode.value === 'readonly' ? '' : status.value));

function hasReadonlySlot(name) {
  function containsContent(nodes) {
    return nodes.some((node) => {
      if (node.type === Comment) return false;
      if (node.type === Text) return String(node.children ?? '').trim().length > 0;
      if (node.type === Fragment)
        return Array.isArray(node.children) && containsContent(node.children);
      return true;
    });
  }
  const nodes = slots[name]?.({
    value: value.value,
    displayValue: displayValue.value,
    prop: props.prop,
    model: model.value,
  });
  return Boolean(nodes && containsContent(nodes));
}

function empty(input) {
  return (
    input === false ||
    input == null ||
    (typeof input === 'string' && !input.trim()) ||
    (Array.isArray(input) && input.length === 0)
  );
}

function resultFrom(rule) {
  if (rule.required && empty(value.value)) return rule.message || '请完成此项';
  if (typeof rule.validator !== 'function') return '';
  try {
    const result = rule.validator(value.value, model.value);
    if (result && typeof result.then === 'function') {
      Promise.resolve(result).catch(() => {});
      return rule.message || '当前版本不支持异步校验';
    }
    if (result === false) return rule.message || '内容不符合要求';
    if (typeof result === 'string') return result;
  } catch {
    return rule.message || '校验执行失败';
  }
  return '';
}

function validationResult() {
  return { prop: props.prop, status: status.value, message: feedback.value };
}

function validate(trigger = 'submit') {
  touched.value = true;
  if (effectiveMode.value === 'readonly') {
    localStatus.value = '';
    localFeedback.value = '';
    return { prop: props.prop, status: '', message: '' };
  }
  if (props.validateStatus) return validationResult();
  const rules =
    !context && props.required && !props.rules.some((rule) => rule.required)
      ? [{ required: true, message: '请输入必填内容' }, ...props.rules]
      : props.rules;
  const active = rules.filter(
    (rule) => trigger === 'submit' || !rule.trigger || [].concat(rule.trigger).includes(trigger),
  );
  const issues = active
    .map((rule) => ({ rule, message: resultFrom(rule) }))
    .filter((item) => item.message);
  const controlMessage = [...controls.values()]
    .map((control) => control.validate?.())
    .find(Boolean);
  if (controlMessage) issues.push({ rule: { severity: 'error' }, message: controlMessage });
  const issue = issues[0];
  if (issue) {
    localStatus.value = 'error';
    localFeedback.value = issue.message;
  } else {
    localStatus.value = '';
    localFeedback.value = '';
  }
  return validationResult();
}

function reset() {
  touched.value = false;
  localStatus.value = '';
  localFeedback.value = '';
  controls.forEach((control) => control.reset?.());
}

function focus() {
  if (firstControl.value?.focus) {
    firstControl.value.focus();
    return;
  }
  const control = root.value?.querySelector(
    '.wb-form-item__control input:not([type=hidden]),.wb-form-item__control textarea,.wb-form-item__control select,.wb-form-item__control button,.wb-form-item__control [tabindex]:not([tabindex="-1"])',
  );
  (control || root.value?.querySelector('[tabindex]:not([tabindex="-1"])'))?.focus();
}

function touch(trigger, event) {
  if (
    trigger === 'blur' &&
    event?.relatedTarget &&
    (root.value?.contains(event.relatedTarget) ||
      [...controls.values()].some((control) => control.containsFocus?.(event.relatedTarget)))
  )
    return;
  if (event?.isComposing || event?.target?.composing) return;
  if (effectiveMode.value !== 'readonly') validate(trigger);
}

function measureLabelWidth() {
  if (!labelElement.value || typeof document === 'undefined') return;
  const style = getComputedStyle(labelElement.value);
  const canvas = document.createElement('canvas');
  const context2d = canvas.getContext('2d');
  if (!context2d) return;
  context2d.font = style.font;
  const letterSpacing = Number.parseFloat(style.letterSpacing) || 0;
  const widthOf = (text) =>
    context2d.measureText(text).width + Math.max(0, [...text].length - 1) * letterSpacing;
  const naturalWidth = Math.ceil(widthOf(props.label));
  if (naturalLabelWidth.value !== naturalWidth) {
    naturalLabelWidth.value = naturalWidth;
    context?.refreshLabelWidths?.();
  }
  const columnWidth = Number.parseFloat(getComputedStyle(root.value).gridTemplateColumns);
  const available =
    (columnWidth || labelElement.value.getBoundingClientRect().width) -
    (Number.parseFloat(style.paddingLeft) || 0) -
    (Number.parseFloat(style.paddingRight) || 0);
  if (labelPosition.value !== 'left' || available <= 0 || widthOf(props.label) <= available) {
    displayLabel.value = props.label;
    return;
  }
  const characters =
    typeof Intl.Segmenter === 'function'
      ? [...new Intl.Segmenter(undefined, { granularity: 'grapheme' }).segment(props.label)].map(
          (item) => item.segment,
        )
      : Array.from(props.label);
  let start = 0;
  let end = characters.length;
  while (start < end) {
    const middle = Math.ceil((start + end) / 2);
    if (widthOf(`${characters.slice(0, middle).join('')}…`) <= available) start = middle;
    else end = middle - 1;
  }
  displayLabel.value = `${characters.slice(0, start).join('')}…`;
}

watch(
  () => [props.label, labelPosition.value, labelWidth.value],
  () => nextTick(measureLabelWidth),
  { flush: 'post' },
);
onMounted(() => {
  measureLabelWidth();
  labelObserver = new ResizeObserver(measureLabelWidth);
  labelObserver.observe(labelElement.value);
  document.fonts?.ready.then(measureLabelWidth);
});

watch(
  value,
  () => {
    if (touched.value && effectiveMode.value !== 'readonly') validate('change');
  },
  { deep: true, flush: 'post' },
);
watch(
  () => props.validateStatus,
  (current, previous) => {
    if (previous && !current && touched.value) validate('change');
  },
  { flush: 'post' },
);
provide(fieldContextKey, {
  label: computed(() => props.label),
  labelId: `${id}-label`,
  controlCount: computed(() => controls.size),
  required,
  invalid,
  describedBy,
  status,
  feedback,
  registerControl(control) {
    controls.set(control.id, control);
    return () => controls.delete(control.id);
  },
  validate: (trigger) => validate(trigger),
  blur: (event) => touch('blur', event),
});
const unregister = context?.registerField({
  get prop() {
    return props.prop;
  },
  get size() {
    return props.size;
  },
  get labelWidth() {
    return naturalLabelWidth.value;
  },
  status: registeredStatus,
  validate,
  reset,
  focus,
});
onBeforeUnmount(() => {
  labelObserver?.disconnect();
  unregister?.();
});
defineExpose({ validate, reset, focus, status });
</script>

<template>
  <div
    ref="root"
    class="wb-form-item"
    :class="[
      `is-${status || 'default'}`,
      `is-${effectiveMode}`,
      `is-label-${labelPosition}`,
      size ? `is-size-${size}` : '',
      { 'has-size': span, 'is-custom-grid': customGrid, 'is-disabled': disabled },
    ]"
    @focusout="touch('blur', $event)"
    @input="touch('change', $event)"
    @change="touch('change', $event)"
    @click.capture="touched = true"
  >
    <div class="wb-form-item__label-wrap">
      <span
        v-if="required"
        class="wb-form-item__required"
        aria-hidden="true"
        ><WorkbenchRequiredMark
      /></span>
      <WorkbenchTooltip
        :content="label"
        :overflow-only="labelPosition !== 'left'"
        :disabled="labelPosition === 'left' && !labelTruncated"
        placement="top-start"
        ><template #trigger="{ aria }"
          ><label
            ref="labelElement"
            :for="labelFor"
            :aria-label="label"
            @click="focus"
            class="wb-form-item__label"
            :id="`${id}-label`"
            tabindex="0"
            v-bind="aria"
            >{{ displayLabel }}</label
          ></template
        ></WorkbenchTooltip
      >
    </div>
    <div
      v-if="effectiveMode === 'readonly'"
      class="wb-form-item__readonly"
      :class="{
        'has-richcontent': hasReadonlySlot('readonly') || hasReadonlySlot('readonly-actions'),
      }"
      role="group"
      :aria-labelledby="`${id}-label`"
    >
      <template v-if="hasReadonlySlot('readonly') || hasReadonlySlot('readonly-actions')">
        <div class="wb-form-item__readonly-value">
          <slot
            name="readonly"
            :value="value"
            :display-value="displayValue"
            :prop="prop"
            :model="model"
            >{{ displayValue }}</slot
          >
        </div>
        <div
          v-if="hasReadonlySlot('readonly-actions')"
          class="wb-form-item__readonly-actions"
        >
          <slot
            name="readonly-actions"
            :value="value"
            :display-value="displayValue"
            :prop="prop"
            :model="model"
          />
        </div>
      </template>
      <template v-else>{{ displayValue }}</template>
      <div
        v-if="showGrid"
        class="wb-form-item__grid-overlay"
        data-wb-grid-overlay
        aria-hidden="true"
      >
        <i
          v-for="column in 12"
          :key="column"
          data-wb-grid-track
          ><span data-wb-grid-label>{{ column }}</span></i
        >
      </div>
    </div>
    <div
      v-else
      class="wb-form-item__body"
      :role="controls.size > 1 ? 'group' : undefined"
      :aria-labelledby="controls.size > 1 ? `${id}-label` : undefined"
      :aria-describedby="describedBy"
    >
      <div class="wb-form-item__control">
        <slot
          :status="status"
          :message="feedback"
          :described-by="describedBy"
          :invalid="invalid"
          :required="required"
          :labelled-by="`${id}-label`"
        />
        <div
          v-if="showGrid"
          class="wb-form-item__grid-overlay"
          data-wb-grid-overlay
          aria-hidden="true"
        >
          <i
            v-for="column in 12"
            :key="column"
            data-wb-grid-track
            ><span data-wb-grid-label>{{ column }}</span></i
          >
        </div>
      </div>
      <p
        v-if="!feedback && hint"
        :id="`${id}-hint`"
        class="wb-form-item__hint"
      >
        <span>{{ hint }}</span>
      </p>
      <p
        v-if="feedback"
        :id="`${id}-feedback`"
        class="wb-form-item__feedback"
        role="alert"
      >
        <span>{{ feedback }}</span>
      </p>
    </div>
  </div>
</template>

<style scoped>
.wb-form-item {
  --form-label-width: v-bind(labelWidth);
  min-width: 0;
}
.wb-form-item.is-custom-grid {
  grid-column: span var(--form-auto-span);
}
.wb-form-item.is-custom-grid.is-size-s {
  grid-column: span 2;
}
.wb-form-item.is-custom-grid.is-size-base {
  grid-column: span 4;
}
.wb-form-item.is-custom-grid.is-size-m {
  grid-column: span 6;
}
.wb-form-item.is-custom-grid.is-size-l {
  grid-column: span 8;
}
.wb-form-item.is-custom-grid.is-size-xl {
  grid-column: span 10;
}
.wb-form-item__label-wrap {
  position: relative;
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  overflow: visible;
}
.wb-form-item__label-wrap :deep(.wb-tooltip) {
  display: flex;
  width: 100%;
  min-width: 0;
}
.wb-form-item__label {
  display: block;
  width: 100%;
  min-width: 0;
  max-width: 100%;
  overflow: hidden;
  color: var(--wb-color-text-primary);
  text-overflow: ellipsis;
  white-space: nowrap;
  outline-offset: 2px;
}
.wb-form-item__label:focus-visible {
  outline: 2px solid var(--wb-color-border-focus);
}
.wb-form-item__required {
  display: flex;
  align-items: center;
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  inset-inline-end: 100%;
}
.wb-form-item__body {
  min-width: 0;
}
.wb-form-item__control {
  --select-field-width: 100%;
  --date-picker-field-width: 100%;
  position: relative;
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  align-items: center;
  min-width: 0;
  min-height: var(--wb-asset-wb-form-control-height);
}
.wb-form-item__readonly {
  position: relative;
  box-sizing: border-box;
  display: flex;
  align-items: flex-start;
  min-width: 0;
  min-height: var(--wb-asset-wb-form-control-height);
  padding-block: calc(
    (var(--wb-asset-wb-form-control-height) - var(--wb-font-body-m-line-height)) / 2
  );
  overflow-wrap: anywhere;
  color: var(--wb-color-text-primary);
}
.wb-form-item__readonly.has-richcontent {
  align-items: flex-start;
  padding-block: 0;
}
.wb-form-item__readonly-value {
  min-width: 0;
  padding-block: calc(
    (var(--wb-asset-wb-form-control-height) - var(--wb-font-body-m-line-height)) / 2
  );
  overflow-wrap: anywhere;
}
.wb-form-item__readonly-actions {
  display: flex;
  align-items: center;
  flex: none;
  min-height: var(--wb-asset-wb-form-control-height);
  margin-inline-start: var(--wb-spacing-component-sm);
}
.wb-form-item__readonly-actions:empty {
  display: none;
}
.wb-form-item.is-disabled .wb-form-item__label {
  color: var(--wb-color-text-disabled);
}
.wb-form-item.is-readonly .wb-form-item__label {
  color: var(--wb-color-text-secondary);
}
.wb-form-item__control :deep(.wb-rating__item) {
  height: var(--wb-asset-wb-form-control-height);
}
.wb-form-item.is-label-top {
  display: grid;
  gap: var(--wb-spacing-component-sm);
}
.wb-form-item.is-label-left {
  display: grid;
  grid-template-columns: var(--form-label-width) minmax(0, 1fr);
  gap: var(--wb-spacing-component-lg);
  align-items: start;
}
.wb-form-item.is-label-left .wb-form-item__label-wrap {
  width: fit-content;
  max-width: 100%;
  justify-self: end;
}
.wb-form-item.is-label-left .wb-form-item__label {
  width: 100%;
  min-height: var(--wb-asset-wb-form-control-height);
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
  padding-block: calc(
    (var(--wb-asset-wb-form-control-height) - var(--wb-font-body-m-line-height)) / 2
  );
  text-align: right;
  /* Preserve the field prefix and place the ellipsis at the text end. */
  direction: ltr;
}
.wb-form-item__hint,
.wb-form-item__feedback {
  display: flex;
  align-items: flex-start;
  gap: var(--wb-spacing-component-xs);
  margin: 0;
  font-size: var(--wb-font-body-s-font-size);
  font-weight: var(--wb-font-body-s-font-weight);
  line-height: var(--wb-font-body-s-line-height);
  letter-spacing: var(--wb-font-body-s-letter-spacing);
}
.wb-form-item__hint {
  color: var(--wb-color-text-placeholder);
}
.wb-form-item__hint > span,
.wb-form-item__feedback {
  overflow-wrap: anywhere;
}
.wb-form-item.is-error .wb-form-item__feedback {
  color: var(--wb-color-error);
}
.wb-form-item__grid-overlay {
  grid-template-columns: repeat(12, minmax(0, 1fr));
}
.wb-form-item.is-error .wb-form-item__control :deep(input:not([type='range'])),
.wb-form-item.is-error .wb-form-item__control :deep(textarea),
.wb-form-item.is-error .wb-form-item__control :deep(.wb-input__control),
.wb-form-item.is-error .wb-form-item__control :deep(.wb-select__control),
.wb-form-item.is-error .wb-form-item__control :deep(.wb-counter-input),
.wb-form-item.is-error .wb-form-item__control :deep(button[aria-haspopup]) {
  border-color: var(--wb-color-error);
}
@container wb-form (width < 656px) {
  .wb-form-item.is-custom-grid,
  .wb-form-item.is-custom-grid.has-size {
    grid-column: 1 / -1;
  }
}
</style>
