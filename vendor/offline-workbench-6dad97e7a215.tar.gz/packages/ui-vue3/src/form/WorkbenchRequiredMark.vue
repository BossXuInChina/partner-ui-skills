<template>
  <svg
    class="wb-required-mark"
    viewBox="0 0 8 22"
    width="8"
    height="22"
    aria-hidden="true"
    focusable="false"
  >
    <path
      d="M3.38823 7.68428L5.01223 6.59228L5.53023 7.48828L3.78023 8.35628L5.53023 9.21028L5.01223 10.1063L3.38823 9.01428L3.52823 10.9603L2.49223 10.9603L2.63223 9.01428L1.00823 10.1063L0.490234 9.21028L2.24023 8.35628L0.490234 7.48828L1.00823 6.59228L2.63223 7.68428L2.49223 5.73828L3.52823 5.73828L3.38823 7.68428Z"
      fill="#E02128"
      fill-rule="evenodd"
    />
  </svg>
</template>

<style scoped>
.wb-required-mark {
  display: block;
  flex: none;
}
</style>
