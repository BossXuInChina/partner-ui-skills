<script setup>
defineProps({ label: { type: String, default: '' }, nested: Boolean });
</script>

<template>
  <fieldset
    class="wb-form-group"
    :class="{ 'is-nested': nested }"
  >
    <legend v-if="label">{{ label }}</legend>
    <div class="wb-form-group__content"><slot /></div>
  </fieldset>
</template>

<style scoped>
.wb-form-group {
  grid-column: 1/-1;
  min-width: 0;
  margin: 0;
  padding: 0;
  border: 0;
}
.wb-form-group legend {
  margin-bottom: var(--wb-spacing-component-lg);
  padding: 0;
  color: var(--wb-color-text-primary);
  font-size: var(--wb-font-headline-xs-font-size);
  font-weight: var(--wb-font-headline-xs-font-weight);
  line-height: var(--wb-font-headline-xs-line-height);
  letter-spacing: var(--wb-font-headline-xs-letter-spacing);
}
.wb-form-group.is-nested {
  padding-inline-start: var(--wb-asset-wb-form-nested-indent);
}
.wb-form-group__content {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: var(--form-row-gap, var(--wb-spacing-component-lg)) var(--wb-spacing-component-lg);
}
@container wb-form (width < 656px) {
  .wb-form-group__content {
    grid-template-columns: minmax(0, 1fr);
  }
}
</style>
