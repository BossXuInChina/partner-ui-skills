import { computed, inject, onBeforeUnmount, useId, watch } from 'vue';

export const fieldContextKey = Symbol('workbench-field');
export function descriptionIds(...values) {
  return (
    [...new Set(values.filter(Boolean).flatMap((value) => value.split(' ')))].join(' ') || undefined
  );
}

// Bind semantics to the actual input/group, never the component's decorative root.
export function useFieldControl(value, options = {}) {
  const field = inject(fieldContextKey, null);
  const id = `wb-control-${options.id || useId()}`;
  const control = {
    id,
    value,
    labelable: options.labelable !== false,
    focus: options.focus,
    containsFocus: options.containsFocus,
    validate: options.validate,
    reset: options.reset,
  };
  let unregister;
  watch(
    options.active || (() => true),
    (active) => {
      unregister?.();
      unregister = active ? field?.registerControl(control) : undefined;
    },
    { immediate: true },
  );
  onBeforeUnmount(() => unregister?.());
  const required = computed(() => (field ? field.required.value : !!options.required?.()));
  const invalid = computed(() => (field ? field.invalid.value : !!options.invalid?.()));
  const attrs = computed(() => ({
    id,
    ...(field && !options.option && !options.named?.() ? { 'aria-labelledby': field.labelId } : {}),
    'aria-describedby': descriptionIds(
      options.describedBy?.(),
      options.option ? field?.labelId : undefined,
      field?.describedBy.value,
    ),
    'aria-invalid': invalid.value ? true : false,
    'aria-required': required.value || undefined,
    ...(options.nativeRequired
      ? {
          required:
            required.value &&
            (options.nativeRequired !== 'single' || !field || field.controlCount.value === 1),
        }
      : {}),
  }));
  return { field, attrs, required, invalid };
}
