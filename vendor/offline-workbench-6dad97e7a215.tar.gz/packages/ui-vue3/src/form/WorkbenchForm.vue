<script setup>
import '../../../../catalog/generated/asset.tokens.css';
import { computed, provide, ref } from 'vue';
import { formContextKey } from './formContext.js';
import { useFormDisabled } from './useFormDisabled.js';

const props = defineProps({
  title: { type: String, required: true },
  titleVisible: { type: Boolean, default: true },
  model: { type: Object, required: true },
  density: {
    type: String,
    default: 'comfortable',
    validator: (value) => ['comfortable', 'compact'].includes(value),
  },
  mode: {
    type: String,
    default: 'editable',
    validator: (value) => ['readonly', 'editable', 'mixed'].includes(value),
  },
  labelPosition: {
    type: String,
    default: 'top',
    validator: (value) => ['top', 'left'].includes(value),
  },
  labelWidth: { type: String, default: 'var(--wb-asset-wb-form-label-width)' },
  disabled: Boolean,
  singleLine: Boolean,
  showGrid: Boolean,
});
const disabled = useFormDisabled(() => props.disabled);
const emit = defineEmits(['submit', 'invalid']);
const fields = [];
const fieldVersion = ref(0);
const submitting = ref(false);
const labelWidth = computed(() => {
  fieldVersion.value;
  const widestLabel = Math.max(0, ...fields.map((field) => field.labelWidth || 0));
  return `min(${widestLabel}px, ${props.labelWidth})`;
});
const hasCustomSize = computed(() => {
  fieldVersion.value;
  return fields.some((field) => Boolean(field.size));
});

function registerField(field) {
  fields.push(field);
  fieldVersion.value += 1;
  return () => {
    const index = fields.indexOf(field);
    if (index >= 0) fields.splice(index, 1);
    fieldVersion.value += 1;
  };
}

async function validate() {
  const results = fields.map((field) => field.validate('submit'));
  const errors = results.filter((result) => result.status === 'error');
  return { valid: errors.length === 0, errors };
}

function resetValidation() {
  fields.forEach((field) => field.reset());
}

function focusFirstInvalid() {
  fields.find((field) => field.status.value === 'error')?.focus();
}

async function submit(event) {
  event?.preventDefault();
  if (disabled.value || submitting.value) return;
  submitting.value = true;
  try {
    const result = await validate();
    if (disabled.value) return result;
    if (!result.valid) {
      focusFirstInvalid();
      emit('invalid', result);
      return result;
    }
    emit('submit', { model: props.model });
    return result;
  } finally {
    submitting.value = false;
  }
}

provide(formContextKey, {
  disabled,
  model: computed(() => props.model),
  mode: computed(() => props.mode),
  labelPosition: computed(() => props.labelPosition),
  labelWidth,
  refreshLabelWidths() {
    fieldVersion.value += 1;
  },
  showGrid: computed(() => props.showGrid),
  hasCustomSize,
  registerField,
});
defineExpose({ validate, resetValidation, focusFirstInvalid, submit });
</script>

<template>
  <div class="wb-form-container">
    <form
      class="wb-form"
      :aria-label="title"
      :aria-disabled="disabled || undefined"
      :class="[
        { 'has-custom-size': hasCustomSize, 'is-single-line': singleLine },
        `is-${mode}`,
        `is-density-${density}`,
        `is-label-${labelPosition}`,
      ]"
      novalidate
      @submit="submit"
    >
      <h2
        class="wb-form__title"
        :class="{ 'is-visually-hidden': !titleVisible }"
      >
        {{ title }}
      </h2>
      <fieldset
        class="wb-form__fieldset"
        :disabled="disabled"
      >
        <div class="wb-form__grid">
          <slot />
          <div
            v-if="$slots.actions && mode !== 'readonly'"
            class="wb-form__actions"
          >
            <slot name="actions" />
          </div>
        </div>
      </fieldset>
    </form>
  </div>
</template>

<style scoped>
.wb-form-container {
  --form-label-width: v-bind(labelWidth);
  container: wb-form / inline-size;
  min-width: 0;
}
.wb-form {
  min-width: 0;
  color: var(--wb-color-text-primary);
  --form-row-gap: var(--wb-spacing-component-lg);
  --form-columns: 1;
  --form-auto-span: 12;
}
.wb-form__title {
  margin: 0 0 var(--wb-spacing-layout-content-gap);
  font-size: var(--wb-font-headline-s-font-size);
  font-weight: var(--wb-font-headline-s-font-weight);
  line-height: var(--wb-font-headline-s-line-height);
  letter-spacing: var(--wb-font-headline-s-letter-spacing);
}
.wb-form__title.is-visually-hidden {
  position: absolute;
  width: var(--wb-asset-wb-form-screen-reader-box-size);
  height: var(--wb-asset-wb-form-screen-reader-box-size);
  padding: 0;
  margin: var(--wb-asset-wb-form-screen-reader-offset);
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border: 0;
}
.wb-form__grid {
  display: grid;
  grid-template-columns: repeat(var(--form-columns), minmax(0, 1fr));
  gap: var(--form-row-gap) var(--wb-spacing-component-lg);
  align-items: start;
}
.wb-form.is-readonly.is-density-compact {
  --form-row-gap: var(--wb-spacing-component-xs);
}
.wb-form.has-custom-size .wb-form__grid {
  grid-template-columns: repeat(12, minmax(0, 1fr));
}
.wb-form__actions {
  display: flex;
  justify-self: end;
  align-items: center;
  gap: var(--wb-spacing-component-sm);
  min-width: 0;
}
.wb-form.is-label-top .wb-form__actions {
  align-self: end;
}
.wb-form.has-custom-size .wb-form__actions {
  grid-column: 1 / -1;
}
@container wb-form (width >= 656px) {
  .wb-form {
    --form-columns: 2;
    --form-auto-span: 6;
  }
  .wb-form__actions {
    grid-column: -2 / -1;
    justify-self: end;
  }
  .wb-form.has-custom-size .wb-form__actions {
    grid-column: -7 / -1;
  }
}
@container wb-form (width >= 968px) {
  .wb-form {
    --form-columns: 3;
    --form-auto-span: 4;
  }
  .wb-form.has-custom-size .wb-form__actions {
    grid-column: -5 / -1;
  }
}
@container wb-form (width >= 1280px) {
  .wb-form {
    --form-columns: 4;
    --form-auto-span: 3;
  }
  .wb-form.has-custom-size .wb-form__actions {
    grid-column: -4 / -1;
  }
}
.wb-form.is-single-line .wb-form__actions {
  align-self: end;
  width: 100%;
  justify-self: stretch;
}
.wb-form.is-single-line .wb-form__actions :deep(*) {
  flex: 1;
}
@container wb-form (width < 656px) {
  .wb-form.is-single-line .wb-form__actions {
    width: auto;
    justify-self: end;
  }
  .wb-form.is-single-line .wb-form__actions :deep(*) {
    flex: none;
  }
}
</style>

<style scoped>
.wb-form__fieldset {
  margin: 0;
  padding: 0;
  border: 0;
  min-width: 0;
}
</style>
