export const formContextKey = Symbol('workbench-form');

export function getPath(source, path) {
  if (!path) return undefined;
  return path.split('.').reduce((value, key) => value?.[key], source);
}
