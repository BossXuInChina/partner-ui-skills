import { computed, inject } from 'vue';
import { formContextKey } from './formContext.js';

// A child's explicit false cannot override a disabled owning form.
export function useFormDisabled(own = () => false) {
  const form = inject(formContextKey, null);
  return computed(() => Boolean(form?.disabled?.value || own()));
}
