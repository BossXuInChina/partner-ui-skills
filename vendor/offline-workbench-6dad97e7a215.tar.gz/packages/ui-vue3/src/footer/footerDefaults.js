export const footerCopyright = '版权所有©华为技术有限公司 1998-2026。保留一切权利。';
export const footerRegistration = '粤A2-20044005号';
export const footerLinks = [
  { id: 'contact', label: '联系我们' },
  { id: 'privacy', label: '隐私保护' },
  { id: 'legal', label: '法律声明' },
  { id: 'agreement', label: '用户协议' },
];
