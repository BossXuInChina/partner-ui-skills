<script setup>
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import { footerCopyright, footerRegistration, footerLinks } from './footerDefaults.js';

const props = defineProps({
  copyright: { type: String, default: footerCopyright },
  registration: {
    type: Object,
    default: () => ({ id: 'registration', label: footerRegistration }),
  },
  links: { type: Array, default: () => footerLinks.map((item) => ({ ...item })) },
  disabled: { type: Boolean, default: false },
});
const emit = defineEmits(['select']);
const isDisabled = (item) => props.disabled || item.disabled;
const elementFor = (item) => (item.href ? 'a' : 'button');
const relFor = (item) =>
  item.target === '_blank'
    ? [...new Set(`${item.rel ?? ''} noopener noreferrer`.trim().split(/\s+/))].join(' ')
    : item.rel;
function attributesFor(item) {
  const disabled = isDisabled(item);
  return item.href
    ? {
        href: disabled ? undefined : item.href,
        target: item.target,
        rel: relFor(item),
        role: disabled ? 'link' : undefined,
        'aria-disabled': disabled || undefined,
        tabindex: disabled ? -1 : undefined,
      }
    : { type: 'button', disabled };
}
function select(item, event) {
  if (isDisabled(item)) {
    event.preventDefault();
    return;
  }
  emit('select', item);
}
</script>

<template>
  <footer
    class="wb-footer"
    role="contentinfo"
    aria-label="网站页脚"
  >
    <div class="wb-footer__inner">
      <p
        v-if="copyright || $slots.copyright || registration?.label"
        class="wb-footer__metadata"
      >
        <span
          v-if="copyright || $slots.copyright"
          class="wb-footer__copyright"
          ><slot name="copyright">{{ copyright }}</slot></span
        >
        <component
          v-if="registration?.label"
          :is="registration.href || registration.action ? elementFor(registration) : 'span'"
          class="wb-footer__registration"
          :class="{ 'wb-footer__entry': registration.href || registration.action }"
          v-bind="registration.href || registration.action ? attributesFor(registration) : {}"
          @click="
            registration.href || registration.action ? select(registration, $event) : undefined
          "
          >{{ registration.label }}</component
        >
      </p>
      <nav
        v-if="links.length"
        class="wb-footer__links"
        aria-label="页脚法律与支持"
      >
        <component
          v-for="item in links"
          :key="item.id ?? item.label"
          :is="elementFor(item)"
          class="wb-footer__entry"
          v-bind="attributesFor(item)"
          @click="select(item, $event)"
          >{{ item.label }}</component
        >
      </nav>
    </div>
  </footer>
</template>

<style scoped>
.wb-footer {
  container: wb-footer / inline-size;
  width: 100%;
  color: var(--wb-color-text-secondary);
  background: var(--wb-color-surface-page);
  font-family: inherit;
  font-size: var(--wb-font-body-s-font-size);
  font-weight: var(--wb-font-body-s-font-weight);
  line-height: var(--wb-font-body-s-line-height);
  letter-spacing: var(--wb-font-body-s-letter-spacing);
}
.wb-footer__inner {
  box-sizing: border-box;
  width: 100%;
  margin-inline: auto;
  padding: var(--wb-spacing-component-lg) var(--wb-spacing-screen-edge-compact);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--wb-spacing-component-sm);
}
.wb-footer__metadata {
  min-width: 0;
  width: 100%;
  margin: 0;
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
  gap: 0 var(--wb-spacing-component-xl);
  text-align: center;
}
.wb-footer__copyright {
  min-width: 0;
  max-width: 100%;
  overflow-wrap: anywhere;
}
.wb-footer__registration {
  flex: none;
  max-width: 100%;
  overflow-wrap: anywhere;
}
.wb-footer__links {
  min-width: 0;
  max-width: 100%;
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
  gap: var(--wb-spacing-component-sm) var(--wb-spacing-component-xl);
}
.wb-footer__entry {
  min-width: 0;
  max-width: 100%;
  margin: 0;
  padding: 0;
  border: 0;
  border-radius: var(--wb-radius-sm);
  background: transparent;
  color: inherit;
  font: inherit;
  text-align: inherit;
  overflow-wrap: anywhere;
  text-decoration: none;
  cursor: pointer;
}
.wb-footer__entry:not(:disabled, [aria-disabled='true']):is(:hover, :focus-visible, :active) {
  color: var(--wb-color-text-primary);
  text-decoration: underline;
  text-underline-offset: var(--wb-asset-wb-footer-focus-offset);
}
.wb-footer__entry:focus-visible {
  outline: var(--wb-asset-wb-footer-focus-width) solid
    var(--wb-color-border-focus);
  outline-offset: var(--wb-asset-wb-footer-focus-offset);
}
.wb-footer__entry:is(:disabled, [aria-disabled='true']) {
  color: var(--wb-color-text-disabled);
  cursor: not-allowed;
}
@container wb-footer (width >= 768px) {
  .wb-footer__inner {
    padding-inline: var(--wb-spacing-screen-edge-expanded);
  }
}
@container wb-footer (width >= 800px) {
  .wb-footer__inner {
    flex-direction: row;
    gap: var(--wb-spacing-component-lg);
  }
  .wb-footer__metadata {
    flex: 1;
    width: auto;
    justify-content: flex-start;
    text-align: left;
  }
  .wb-footer__links {
    flex: none;
    max-width: 50%;
    justify-content: flex-end;
  }
}
@container wb-footer (width > 1920px) {
  .wb-footer__inner {
    width: var(--wb-layout-grid-max-width);
    padding-inline: 0;
  }
}
</style>
