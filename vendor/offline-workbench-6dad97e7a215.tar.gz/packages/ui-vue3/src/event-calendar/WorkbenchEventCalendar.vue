<script setup lang="ts">
// Block: fluid date panel with event markers + collapsible agenda list for the selected day.
import { computed, ref, watch, type PropType } from 'vue';
import WorkbenchButton from '../button/WorkbenchButton.vue';
import WorkbenchDatePicker from '../date-picker/WorkbenchDatePicker.vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import WorkbenchScrollbar from '../scrollbar/WorkbenchScrollbar.vue';
import WorkbenchTag from '../tag/WorkbenchTag.vue';
import type { EventCalendarEvent } from '../../types/home-blocks';

const props = defineProps({
  events: { type: Array as PropType<EventCalendarEvent[]>, required: true },
  initialDate: { type: String, required: true },
  today: { type: Date, default: () => new Date() },
  ariaLabel: { type: String, default: '活动日历' },
  agendaLabel: { type: String, default: '当日活动' },
  emptyText: { type: String, default: '当日暂无活动' },
});
const emit = defineEmits(['open', 'select']);
const selected = ref(props.initialDate);
const collapsed = ref(false);
watch(selected, (date) => emit('select', date));
const markers = computed(() =>
  props.events.reduce<Record<string, number>>(
    (all, event) => ({ ...all, [event.date]: (all[event.date] ?? 0) + 1 }),
    {},
  ),
);
const agenda = computed(() => props.events.filter((event) => event.date === selected.value));
</script>

<template>
  <div class="wb-event-calendar">
    <WorkbenchDatePicker v-model="selected" inline fluid flat-inline :show-input="false" show-empty-markers :date-markers="markers" :today="today" :aria-label="ariaLabel" />
    <div class="wb-event-calendar__toggle">
      <WorkbenchButton class="wb-event-calendar__toggle-button" appearance="text" text-layout="inline" :aria-expanded="!collapsed" @click="collapsed = !collapsed"
        >{{ collapsed ? '展开' : '收起'
        }}<template #icon><span class="wb-event-calendar__arrow" :class="{ 'is-expanded': !collapsed }"><WorkbenchIcon name="/ic_arrow_right_line#2:141" :size="10" /></span></template
      ></WorkbenchButton>
    </div>
    <WorkbenchScrollbar v-if="!collapsed" class="wb-event-calendar__scroll" :label="agendaLabel" size="small">
      <ul class="wb-event-calendar__agenda" :aria-label="agendaLabel">
        <li v-if="!agenda.length" class="wb-event-calendar__empty">{{ emptyText }}</li>
        <li v-for="event in agenda" :key="event.id">
          <button type="button" class="wb-event-calendar__item" @click="emit('open', event)">
            <span class="wb-event-calendar__title"><b>{{ event.title }}</b><WorkbenchTag size="small" :label="event.type" /></span>
            <span class="wb-event-calendar__meta"><WorkbenchIcon name="首页 时间/time" :size="16" />{{ event.time }}</span>
            <span class="wb-event-calendar__meta"><WorkbenchIcon name="定位/location" :size="16" />{{ event.place }}</span>
          </button>
        </li>
      </ul>
    </WorkbenchScrollbar>
  </div>
</template>

<style>
.wb-event-calendar { display: flex; flex-direction: column; }
.wb-event-calendar > .wb-date-picker { align-self: stretch; }
.wb-event-calendar__toggle { position: relative; z-index: 1; display: flex; height: var(--wb-asset-wb-button-height-32); align-items: center; justify-content: center; margin-top: var(--wb-spacing-component-sm); }
.wb-event-calendar__toggle .wb-event-calendar__toggle-button, .wb-event-calendar__toggle .wb-event-calendar__toggle-button[aria-expanded="true"] { color: var(--wb-color-text-primary); }
.wb-event-calendar__arrow { display: inline-flex; transition: transform var(--wb-asset-wb-event-calendar-motion-duration) ease; }
.wb-event-calendar__arrow.is-expanded { transform: rotate(360deg); }
@media (prefers-reduced-motion: reduce) { .wb-event-calendar__arrow { transition: none; } }
.wb-event-calendar__toggle::after { position: absolute; inset: 0; box-shadow: var(--wb-asset-wb-event-calendar-toggle-shadow); clip-path: inset(100% 0 calc(-1 * var(--wb-asset-wb-button-height-32))); content: ''; pointer-events: none; }
.wb-event-calendar__scroll { height: var(--wb-asset-wb-event-calendar-agenda-height); margin-top: var(--wb-spacing-component-lg); }
.wb-event-calendar__agenda { display: flex; flex-direction: column; margin: 0; padding: 0; list-style: none; }
.wb-event-calendar__item { display: flex; width: 100%; flex-direction: column; gap: var(--wb-spacing-component-sm); padding: var(--wb-spacing-component-md) 0; border: 0; border-bottom: var(--wb-asset-wb-event-calendar-divider-width) solid var(--wb-color-border-separator-subtle); background: none; text-align: left; font-family: inherit; font-size: var(--wb-font-body-m-font-size); font-weight: var(--wb-font-body-m-font-weight); line-height: var(--wb-font-body-m-line-height); letter-spacing: var(--wb-font-body-m-letter-spacing); cursor: pointer; }
.wb-event-calendar__item:hover b { color: var(--wb-color-link); }
.wb-event-calendar__title { display: flex; align-items: center; justify-content: flex-start; gap: var(--wb-spacing-component-sm); }
.wb-event-calendar__title b { overflow: hidden; font-size: var(--wb-font-body-m-font-size); font-weight: var(--wb-font-body-m-font-weight); line-height: var(--wb-font-body-m-line-height); letter-spacing: var(--wb-font-body-m-letter-spacing); text-overflow: ellipsis; white-space: nowrap; }
.wb-event-calendar__meta { display: inline-flex; align-items: center; gap: var(--wb-spacing-component-xs); color: var(--wb-color-text-secondary); font-size: var(--wb-font-body-m-font-size); font-weight: var(--wb-font-body-m-font-weight); line-height: var(--wb-font-body-m-line-height); letter-spacing: var(--wb-font-body-m-letter-spacing); }
.wb-event-calendar__empty { padding: var(--wb-spacing-component-lg) 0; color: var(--wb-color-text-secondary); text-align: center; }
</style>
