<script setup lang="ts">
// Block: read-only certification facts (type, region, start / end / review dates) inside a status card.
import type { PropType } from 'vue';
import WorkbenchTag from '../tag/WorkbenchTag.vue';
import type { CertificationDetailsData } from '../../types/home-blocks';
defineProps({
  details: { type: Object as PropType<CertificationDetailsData>, required: true },
  ariaLabel: { type: String, default: '认证详情' },
});
</script>

<template>
  <dl class="wb-certification-details" :aria-label="ariaLabel">
    <div class="wb-certification-details__type"><dt>认证类型：</dt><dd><WorkbenchTag variant="status-subtle" status="alert" size="small" :label="details.type" /></dd></div>
    <div class="wb-certification-details__region"><dt>归属认证代表处/系统部：</dt><dd>{{ details.region }}</dd></div>
    <div><dt>认证开始时间：</dt><dd>{{ details.start }}</dd></div>
    <div><dt>认证结束时间：</dt><dd>{{ details.end }}</dd></div>
    <div><dt>能力复核时间：</dt><dd>{{ details.review }}</dd></div>
  </dl>
</template>

<style>
.wb-certification-details { display: flex; flex-wrap: wrap; gap: var(--wb-spacing-component-md); margin: auto 0 0; padding: var(--wb-spacing-component-lg); border-radius: var(--wb-radius-md); background: var(--wb-color-surface-card-default); font-family: inherit; font-size: var(--wb-font-body-s-font-size); font-weight: var(--wb-font-body-s-font-weight); line-height: var(--wb-font-body-s-line-height); letter-spacing: var(--wb-font-body-s-letter-spacing); }
.wb-certification-details > div { flex: 1 1 calc(var(--wb-spacing-component-xl) * 4); min-width: min(100%, calc(var(--wb-spacing-component-xl) * 4)); }
.wb-certification-details > .wb-certification-details__type, .wb-certification-details > .wb-certification-details__region { flex-basis: calc(50% - var(--wb-spacing-component-md)); display: flex; flex-wrap: wrap; align-items: center; gap: var(--wb-spacing-component-xs); }
.wb-certification-details dt { color: var(--wb-color-text-secondary); }
.wb-certification-details dd { margin: 0; color: var(--wb-color-text-primary); overflow-wrap: anywhere; }
</style>
