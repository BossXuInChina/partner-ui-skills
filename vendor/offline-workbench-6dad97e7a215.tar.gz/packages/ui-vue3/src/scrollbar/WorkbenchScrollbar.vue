<script setup>
import { ref, reactive, onMounted, onBeforeUnmount, watchPostEffect } from 'vue';
import './scrollbar.css';
const props = defineProps({
  label: { type: String, required: true },
  describedby: String,
  axis: { type: String, default: 'vertical' },
  size: { type: String, default: 'default' },
  state: String,
});
const viewport = ref(),
  content = ref(),
  track = ref(),
  thumb = ref();
const metrics = reactive({ ratio: 1, position: 0 });
const dragging = ref(false);
// Runtime geometry derives from measured content, not design dimensions.
watchPostEffect(() => {
  if (!thumb.value) return;
  thumb.value.style.setProperty('--scrollbar-thumb-length', `${metrics.ratio * 100}%`);
  thumb.value.style.setProperty('--scrollbar-thumb-position', `${metrics.position * 100}%`);
});
let observer, drag;
const horizontal = () => props.axis === 'horizontal';
function measure() {
  const e = viewport.value;
  if (!e) return;
  const client = horizontal() ? e.clientWidth : e.clientHeight,
    total = horizontal() ? e.scrollWidth : e.scrollHeight;
  metrics.ratio = total ? Math.min(1, client / total) : 1;
  metrics.position = total ? (horizontal() ? e.scrollLeft : e.scrollTop) / total : 0;
}
function pointerDown(event) {
  if (event.button !== 0) return;
  const e = viewport.value;
  e.focus({ preventScroll: true });
  const rect = track.value.getBoundingClientRect();
  const length = horizontal() ? rect.width : rect.height;
  const total = horizontal() ? e.scrollWidth : e.scrollHeight;
  const point = horizontal() ? event.clientX : event.clientY;
  if (!event.target.closest('.wb-scrollarea__thumb')) {
    const offset = point - (horizontal() ? rect.left : rect.top);
    e[horizontal() ? 'scrollLeft' : 'scrollTop'] = (offset / length - metrics.ratio / 2) * total;
  }
  drag = { point, scroll: horizontal() ? e.scrollLeft : e.scrollTop, total, length };
  dragging.value = true;
  track.value.setPointerCapture(event.pointerId);
  event.preventDefault();
}
function pointerMove(event) {
  if (!drag) return;
  viewport.value[horizontal() ? 'scrollLeft' : 'scrollTop'] =
    drag.scroll +
    (((horizontal() ? event.clientX : event.clientY) - drag.point) * drag.total) / drag.length;
}
function endDrag() {
  drag = null;
  dragging.value = false;
}
function keydown(event) {
  if (event.target !== viewport.value) return;
  const e = viewport.value;
  const amount = horizontal() ? e.clientWidth : e.clientHeight;
  const keys = horizontal() ? ['ArrowLeft', 'ArrowRight'] : ['ArrowUp', 'ArrowDown'];
  let delta;
  if (event.key === keys[0]) delta = -40;
  else if (event.key === keys[1]) delta = 40;
  else if (event.key === 'PageUp') delta = -amount;
  else if (event.key === 'PageDown') delta = amount;
  else if (event.key === 'Home') delta = -Infinity;
  else if (event.key === 'End') delta = Infinity;
  else return;
  event.preventDefault();
  const key = horizontal() ? 'scrollLeft' : 'scrollTop';
  e[key] =
    delta === -Infinity
      ? 0
      : delta === Infinity
        ? horizontal()
          ? e.scrollWidth
          : e.scrollHeight
        : e[key] + delta;
}
onMounted(() => {
  observer = new ResizeObserver(measure);
  observer.observe(viewport.value);
  observer.observe(content.value);
  measure();
});
onBeforeUnmount(() => {
  observer?.disconnect();
  endDrag();
});
defineExpose({ viewport, measure });
</script>
<template>
  <div
    class="wb-scrollbar wb-scrollarea"
    :class="[
      size === 'small' ? '' : 'wb-scrollbar--large',
      {
        'is-horizontal': axis === 'horizontal',
        'is-hover': state === 'hover',
        'is-dragging': dragging,
      },
    ]"
  >
    <div
      ref="viewport"
      class="wb-scrollarea__viewport"
      role="region"
      :aria-label="label"
      :aria-describedby="describedby"
      tabindex="0"
      @scroll="measure"
      @keydown="keydown"
    >
      <div
        ref="content"
        class="wb-scrollarea__content"
      >
        <slot />
      </div>
    </div>
    <div
      v-if="metrics.ratio < 1"
      ref="track"
      class="wb-scrollarea__track"
      aria-hidden="true"
      @pointerdown="pointerDown"
      @pointermove="pointerMove"
      @pointerup="endDrag"
      @pointercancel="endDrag"
      @lostpointercapture="endDrag"
    >
      <div
        ref="thumb"
        class="wb-scrollarea__thumb"
      />
    </div>
  </div>
</template>
<style>
.wb-scrollarea {
  position: relative;
  min-width: 0;
  min-height: 0;
}
.wb-scrollarea__viewport {
  width: 100%;
  height: 100%;
  overflow-y: auto;
  overflow-x: hidden;
  scrollbar-width: none;
  box-sizing: border-box;
}
.wb-scrollarea__viewport::-webkit-scrollbar {
  display: none;
}
.wb-scrollarea__viewport:focus-visible {
  outline: 2px solid var(--wb-color-border-focus);
  outline-offset: -2px;
}
.wb-scrollarea__content {
  display: flow-root;
  min-width: 100%;
}
.wb-scrollarea.is-horizontal .wb-scrollarea__content {
  width: max-content;
}
.wb-scrollarea__track {
  position: absolute;
  inset-block: 0;
  inset-inline-end: 0;
  width: var(--scrollbar-width);
  touch-action: none;
  user-select: none;
}
.wb-scrollarea__thumb {
  position: absolute;
  width: 100%;
  height: var(--scrollbar-thumb-length);
  top: var(--scrollbar-thumb-position);
  border: var(--scrollbar-safe) solid transparent;
  box-sizing: border-box;
  border-radius: var(--wb-radius-full);
  background: var(--scrollbar-fill);
  background-clip: padding-box;
}
.wb-scrollarea__track:hover .wb-scrollarea__thumb,
.wb-scrollarea.is-hover .wb-scrollarea__thumb,
.wb-scrollarea.is-dragging .wb-scrollarea__thumb {
  border-width: var(--scrollbar-safe-hover);
  background-color: var(--wb-color-scrollbar-thumb-fill-hover);
}
.wb-scrollarea.is-horizontal .wb-scrollarea__track {
  inset-block-start: auto;
  inset-inline-start: 0;
  width: auto;
  height: var(--scrollbar-width);
}
.wb-scrollarea.is-horizontal .wb-scrollarea__thumb {
  height: 100%;
  width: var(--scrollbar-thumb-length);
  left: var(--scrollbar-thumb-position);
  top: 0;
}
.wb-scrollarea.is-horizontal .wb-scrollarea__viewport {
  overflow-x: auto;
  overflow-y: hidden;
}
</style>
