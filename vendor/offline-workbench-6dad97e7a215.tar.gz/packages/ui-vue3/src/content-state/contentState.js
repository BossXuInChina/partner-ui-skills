export function resolveContentState({
  loading = false,
  error = null,
  count = 0,
  filtered = false,
  future = false,
} = {}) {
  if (loading) return { kind: 'loading', type: 'loading', recovery: null };
  if (error) return { kind: 'error', type: 'load-failed', recovery: 'retry' };
  if (count > 0) return { kind: 'content', type: 'content', recovery: null };
  if (filtered) return { kind: 'filtered', type: 'no-results', recovery: 'reset' };
  if (future) return { kind: 'future', type: 'no-data', recovery: 'go-current' };
  return { kind: 'empty', type: 'no-data', recovery: 'create' };
}

export default resolveContentState;
