<script setup lang="ts">
// Block: right-side text drill-down entry ("更多 >", "查看历史 >") for card and tab headers.
import WorkbenchButton from '../button/WorkbenchButton.vue';
defineProps({
  label: { type: String, default: '更多' },
  disabled: { type: Boolean, default: false },
});
const emit = defineEmits(['click']);
</script>

<template>
  <WorkbenchButton
    class="wb-more-action"
    appearance="text"
    text-layout="inline"
    intent="drilldown"
    drilldown="more"
    :disabled="disabled"
    @click="emit('click', $event)"
    >{{ label }}</WorkbenchButton
  >
</template>
