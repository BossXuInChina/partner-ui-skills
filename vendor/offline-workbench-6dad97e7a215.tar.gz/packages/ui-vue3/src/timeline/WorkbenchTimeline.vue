<script setup>
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import WorkbenchStatusIcon from '../icons/WorkbenchStatusIcon.vue';
import placeholder from './assets/thumbnail-placeholder.svg';

defineProps({
  items: { type: Array, default: () => [] },
  nodeType: { type: String, default: 'dot', validator: (value) => ['dot', 'icon'].includes(value) },
  label: { type: String, default: '事件时间轴' },
});

const statusLabels = {
  default: '默认',
  loading: '加载中',
  disabled: '禁用',
  error: '失败',
  process: '进行中',
  success: '成功',
};
function status(item) {
  return Object.hasOwn(statusLabels, item.status) ? item.status : 'default';
}
function focused(item) {
  return Boolean(item.focused) && !['loading', 'disabled'].includes(status(item));
}
function imageSource(image) {
  return image === true ? placeholder : typeof image === 'string' ? image : image?.src;
}
function datetime(item) {
  return (
    item.datetime ||
    (/^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}$/.test(item.time ?? '')
      ? item.time.replace(' ', 'T')
      : undefined)
  );
}
</script>

<template>
  <ol
    class="wb-timeline"
    :aria-label="label"
  >
    <li
      v-for="(item, index) in items"
      :key="item.key ?? index"
      class="wb-timeline__item"
      :data-status="status(item)"
    >
      <span
        v-if="index < items.length - 1"
        class="wb-timeline__connector"
        aria-hidden="true"
      />
      <span
        class="wb-timeline__node"
        role="img"
        :aria-label="statusLabels[status(item)]"
        :data-focused="focused(item)"
      >
        <slot
          name="node"
          :item="item"
          :index="index"
        >
          <template
            v-if="
              (item.nodeType ?? nodeType) === 'icon' &&
              ['process', 'success', 'error'].includes(status(item))
            "
          >
            <WorkbenchIcon
              v-if="status(item) === 'process'"
              name="时间_14px"
              :color="'var(--wb-color-info-primary)'"
            />
            <WorkbenchStatusIcon
              v-else
              :name="`${status(item) === 'error' ? 'close_circle' : 'success'}/outline/14`"
            />
          </template>
          <span
            v-else
            class="wb-timeline__dot"
            :class="{ 'wb-timeline__dot--loading': status(item) === 'loading' }"
            aria-hidden="true"
          />
        </slot>
      </span>
      <div class="wb-timeline__content">
        <time
          v-if="item.time || $slots.time"
          class="wb-timeline__time"
          :datetime="datetime(item)"
        >
          <slot
            name="time"
            :item="item"
            :index="index"
            >{{ item.time }}</slot
          >
        </time>
        <div class="wb-timeline__event">
          <div
            v-if="item.image || $slots.image"
            class="wb-timeline__image"
          >
            <slot
              name="image"
              :item="item"
              :index="index"
            >
              <img
                :src="imageSource(item.image)"
                :alt="item.image?.alt ?? ''"
              />
            </slot>
          </div>
          <div class="wb-timeline__copy">
            <p
              v-if="item.title || $slots.title"
              class="wb-timeline__title"
            >
              <slot
                name="title"
                :item="item"
                :index="index"
                >{{ item.title }}</slot
              >
            </p>
            <p
              v-if="item.description || $slots.description"
              class="wb-timeline__description"
            >
              <slot
                name="description"
                :item="item"
                :index="index"
                >{{ item.description }}</slot
              >
            </p>
          </div>
        </div>
      </div>
    </li>
  </ol>
</template>

<style scoped>
.wb-timeline {
  width: 100%;
  min-width: 0;
  max-width: 100%;
  margin: 0;
  padding: 0;
  list-style: none;
  color: var(--wb-color-text-primary);
}
.wb-timeline > .wb-timeline__item {
  position: relative;
  display: grid;
  grid-template-columns: var(--wb-asset-wb-timeline-node-size) minmax(0, 1fr);
  column-gap: var(--wb-asset-wb-timeline-gap);
  min-height: var(--wb-asset-wb-timeline-pitch);
  margin: 0;
  padding: 0;
  --timeline-tone: var(--wb-color-icon-tertiary);
  --timeline-focus-tone: var(--wb-color-info-primary);
}
.wb-timeline__item[data-status='success'] {
  --timeline-tone: var(--wb-color-success);
  --timeline-focus-tone: var(--wb-color-success);
}
.wb-timeline__item[data-status='error'] {
  --timeline-tone: var(--wb-color-error);
  --timeline-focus-tone: var(--wb-color-error);
}
.wb-timeline__item[data-status='process'] {
  --timeline-tone: var(--wb-color-info-primary);
}
.wb-timeline__item[data-status='loading'],
.wb-timeline__item[data-status='disabled'] {
  --timeline-tone: var(--wb-asset-wb-timeline-inactive);
}
.wb-timeline__node {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: var(--wb-asset-wb-timeline-node-size);
  height: var(--wb-asset-wb-timeline-node-size);
  margin-top: var(--wb-asset-wb-timeline-node-top);
  color: var(--timeline-tone);
}
.wb-timeline__dot {
  position: relative;
  box-sizing: border-box;
  width: var(--wb-asset-wb-timeline-dot-size);
  height: var(--wb-asset-wb-timeline-dot-size);
  border: var(--wb-asset-wb-timeline-line-width) solid currentColor;
  border-radius: var(--wb-radius-full);
}
.wb-timeline__node[data-focused='true'] .wb-timeline__dot {
  /* Paint in the even 14px slot so the 9px ring needs no fractional-positioned layer. */
  --timeline-paint-aa: calc(var(--wb-asset-wb-timeline-line-width) / 4);
  width: 100%;
  height: 100%;
  border: 0;
  border-radius: 0;
  background: radial-gradient(
    circle at center,
    var(--timeline-focus-tone) 0
      calc(var(--wb-asset-wb-timeline-dot-focus-size) / 2 - var(--timeline-paint-aa)),
    transparent calc(var(--wb-asset-wb-timeline-dot-focus-size) / 2 + var(--timeline-paint-aa))
      calc(
        var(--wb-asset-wb-timeline-dot-size) / 2 - var(--wb-asset-wb-timeline-line-width) -
          var(--timeline-paint-aa)
      ),
    currentColor
      calc(
        var(--wb-asset-wb-timeline-dot-size) / 2 - var(--wb-asset-wb-timeline-line-width) +
          var(--timeline-paint-aa)
      )
      calc(var(--wb-asset-wb-timeline-dot-size) / 2 - var(--timeline-paint-aa)),
    transparent calc(var(--wb-asset-wb-timeline-dot-size) / 2 + var(--timeline-paint-aa))
  );
}
.wb-timeline__dot--loading {
  border-top-color: var(--wb-color-icon-tertiary);
  animation: timeline-spin var(--wb-asset-wb-timeline-loading-duration) linear infinite;
}
.wb-timeline__connector {
  position: absolute;
  top: var(--wb-asset-wb-timeline-connector-top);
  bottom: calc(-1 * var(--wb-asset-wb-timeline-connector-overhang));
  left: calc((var(--wb-asset-wb-timeline-node-size) - var(--wb-asset-wb-timeline-line-width)) / 2);
  width: var(--wb-asset-wb-timeline-line-width);
  background: var(--wb-color-border-separator);
}
.wb-timeline__content {
  min-width: 0;
  padding-block: var(--wb-asset-wb-timeline-content-top) var(--wb-asset-wb-timeline-content-bottom);
}
.wb-timeline__time,
.wb-timeline__description {
  color: var(--wb-color-text-secondary);
  font-size: var(--wb-font-body-s-font-size);
  font-weight: var(--wb-font-body-s-font-weight);
  line-height: var(--wb-font-body-s-line-height);
  letter-spacing: var(--wb-font-body-s-letter-spacing);
}
.wb-timeline__time {
  display: block;
  overflow-wrap: anywhere;
}
.wb-timeline__event {
  display: flex;
  align-items: flex-start;
  gap: var(--wb-asset-wb-timeline-gap);
  margin-top: var(--wb-asset-wb-timeline-copy-gap);
}
.wb-timeline__image {
  flex: none;
  width: var(--wb-asset-wb-timeline-image-size);
  height: var(--wb-asset-wb-timeline-image-size);
}
.wb-timeline__image > img {
  display: block;
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: var(--wb-asset-wb-timeline-image-radius);
}
.wb-timeline__copy {
  min-width: 0;
  flex: 1;
}
.wb-timeline__title,
.wb-timeline__description {
  margin: 0;
  overflow-wrap: anywhere;
}
.wb-timeline__title {
  color: var(--wb-color-text-primary);
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
}
@keyframes timeline-spin {
  to {
    transform: rotate(1turn);
  }
}
@media (prefers-reduced-motion: reduce) {
  .wb-timeline__dot--loading {
    animation: none;
  }
}
</style>
