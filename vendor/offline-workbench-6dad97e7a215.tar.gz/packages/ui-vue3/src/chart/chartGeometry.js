// Pure geometry helpers for WorkbenchChart. Coordinates are SVG user units (1 unit = 1 CSS px).

export const palette = [
  'var(--wb-color-info-primary)',
  'var(--wb-asset-wb-chart-series-green)',
  'var(--wb-asset-wb-chart-series-orange)',
  'var(--wb-asset-wb-chart-series-purple)',
  'var(--wb-asset-wb-chart-series-cyan)',
  'var(--wb-color-warning)',
  'var(--wb-color-info-secondary)',
  'var(--wb-color-none)',
];

export function seriesColor(series, index) {
  return series?.color || palette[index % palette.length];
}

export function niceMax(value, ticks = 5) {
  if (!(value > 0)) return ticks;
  const rough = value / ticks;
  const power = 10 ** Math.floor(Math.log10(rough));
  const step = [1, 2, 2.5, 5, 10].map((factor) => factor * power).find((candidate) => candidate >= rough);
  return step * ticks;
}

export function axisTicks(max, count = 5) {
  return Array.from({ length: count + 1 }, (_, index) => (max / count) * index);
}

export function formatNumber(value) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) return '-';
  const number = Number(value);
  return Number.isInteger(number) ? number.toLocaleString('en-US') : number.toLocaleString('en-US', { maximumFractionDigits: 2 });
}

export function stackedMax(series, categories) {
  const groups = new Map();
  for (const item of series) {
    const key = item.stack ?? item.name;
    const totals = groups.get(key) ?? categories.map(() => 0);
    (item.data ?? []).forEach((value, index) => {
      totals[index] += Number(value) || 0;
    });
    groups.set(key, totals);
  }
  return Math.max(0, ...[...groups.values()].flat());
}

// Lays out vertical bars. Series sharing a `stack` key are stacked; others sit side by side.
export function barLayout({ categories, series, plot, max, barWidth = 12, gap = 4 }) {
  const slot = plot.width / Math.max(1, categories.length);
  const stacks = [];
  for (const item of series) {
    const key = item.stack ?? `__${item.name}`;
    if (!stacks.includes(key)) stacks.push(key);
  }
  const groupWidth = stacks.length * barWidth + (stacks.length - 1) * gap;
  const rects = [];
  categories.forEach((category, categoryIndex) => {
    const center = plot.x + slot * categoryIndex + slot / 2;
    const offsets = new Map();
    series.forEach((item, seriesIndex) => {
      const key = item.stack ?? `__${item.name}`;
      const stackIndex = stacks.indexOf(key);
      const value = Number(item.data?.[categoryIndex]) || 0;
      const base = offsets.get(key) ?? 0;
      const height = max > 0 ? (value / max) * plot.height : 0;
      const x = center - groupWidth / 2 + stackIndex * (barWidth + gap);
      rects.push({
        key: `${seriesIndex}-${categoryIndex}`,
        seriesIndex,
        categoryIndex,
        value,
        x,
        y: plot.y + plot.height - base - height,
        width: barWidth,
        height,
      });
      offsets.set(key, base + height);
    });
  });
  return { slot, rects };
}

export function linePoints({ data, categories, plot, max }) {
  const slot = plot.width / Math.max(1, categories.length);
  return categories.map((_, index) => ({
    x: plot.x + slot * index + slot / 2,
    y: plot.y + plot.height - (max > 0 ? ((Number(data?.[index]) || 0) / max) * plot.height : 0),
    value: data?.[index],
  }));
}

// Monotone-ish smooth path through points using Catmull-Rom converted to cubic Bezier.
export function smoothPath(points) {
  if (!points.length) return '';
  if (points.length === 1) return `M${points[0].x},${points[0].y}`;
  let path = `M${points[0].x},${points[0].y}`;
  for (let index = 0; index < points.length - 1; index += 1) {
    const p0 = points[index - 1] ?? points[index];
    const p1 = points[index];
    const p2 = points[index + 1];
    const p3 = points[index + 2] ?? p2;
    const c1 = { x: p1.x + (p2.x - p0.x) / 6, y: p1.y + (p2.y - p0.y) / 6 };
    const c2 = { x: p2.x - (p3.x - p1.x) / 6, y: p2.y - (p3.y - p1.y) / 6 };
    path += ` C${c1.x},${c1.y} ${c2.x},${c2.y} ${p2.x},${p2.y}`;
  }
  return path;
}

export function polar(cx, cy, radius, angle) {
  const radians = ((angle - 90) * Math.PI) / 180;
  return { x: cx + radius * Math.cos(radians), y: cy + radius * Math.sin(radians) };
}

// Arc path between angles (degrees, 0 = top, clockwise).
export function arcPath(cx, cy, radius, start, end) {
  const sweep = Math.min(359.999, Math.max(0, end - start));
  const from = polar(cx, cy, radius, start);
  const to = polar(cx, cy, radius, start + sweep);
  const large = sweep > 180 ? 1 : 0;
  return `M${from.x},${from.y} A${radius},${radius} 0 ${large} 1 ${to.x},${to.y}`;
}

export function sectorPath(cx, cy, radius, start, end) {
  const sweep = Math.min(359.999, Math.max(0, end - start));
  const from = polar(cx, cy, radius, start);
  const to = polar(cx, cy, radius, start + sweep);
  const large = sweep > 180 ? 1 : 0;
  return `M${cx},${cy} L${from.x},${from.y} A${radius},${radius} 0 ${large} 1 ${to.x},${to.y} Z`;
}

// Splits a full circle into segments for donut/pie. A small angular gap separates segments.
export function ringSegments(items, gapDegrees = 0) {
  const total = items.reduce((sum, item) => sum + (Number(item.value) || 0), 0);
  let cursor = 0;
  return items.map((item, index) => {
    const value = Number(item.value) || 0;
    const sweep = total > 0 ? (value / total) * 360 : 0;
    const segment = {
      index,
      value,
      percent: total > 0 ? value / total : 0,
      start: cursor + (sweep > gapDegrees ? gapDegrees / 2 : 0),
      end: cursor + sweep - (sweep > gapDegrees ? gapDegrees / 2 : 0),
      mid: cursor + sweep / 2,
    };
    cursor += sweep;
    return segment;
  });
}

// Gauge arcs run from -135deg to +135deg (270deg sweep) like the reference dashboards.
export const gaugeStart = -135;
export const gaugeSweep = 270;

export function gaugeAngle(value, min, max) {
  const ratio = max > min ? Math.max(0, Math.min(1, (value - min) / (max - min))) : 0;
  return gaugeStart + gaugeSweep * ratio;
}

export function radarPoints({ indicators, data, cx, cy, radius }) {
  const step = 360 / Math.max(1, indicators.length);
  return indicators.map((indicator, index) => {
    const ratio = indicator.max > 0 ? Math.max(0, Math.min(1, (Number(data?.[index]) || 0) / indicator.max)) : 0;
    return polar(cx, cy, radius * ratio, step * index);
  });
}
