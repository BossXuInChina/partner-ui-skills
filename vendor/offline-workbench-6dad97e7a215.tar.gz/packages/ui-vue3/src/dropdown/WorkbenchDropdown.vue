<script setup>
import { useFormDisabled } from '../form/useFormDisabled.js';
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import ChoiceMark from '../choice/ChoiceMark.vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import { computed, nextTick, onBeforeUnmount, onMounted, ref, useId, watch } from 'vue';

const props = defineProps({
  size: {
    type: String,
    default: 'default',
    validator: (value) => ['small', 'default', 'large'].includes(value),
  },
  triggerType: {
    type: String,
    default: 'button',
    validator: (value) => ['button', 'text', 'icon'].includes(value),
  },
  textIntent: {
    type: String,
    default: 'drilldown',
    validator: (value) => ['action', 'drilldown'].includes(value),
  },
  textLayout: {
    type: String,
    default: 'container',
    validator: (value) => ['container', 'inline'].includes(value),
  },
  panelWidth: {
    type: String,
    default: 'auto',
    validator: (value) => ['auto', 'min', 'max'].includes(value),
  },
  items: { type: Array, required: true },
  radioValues: { type: Object, default: () => ({}) },
  checkboxValues: { type: Array, default: () => [] },
  disabled: Boolean,
  open: { type: Boolean, default: undefined },
  ariaLabel: { type: String, default: '下拉菜单' },
});
const disabled = useFormDisabled(() => props.disabled);
const emit = defineEmits(['action', 'update:radio', 'update:checked', 'update:open']);
const id = useId();
const root = ref(null);
const trigger = ref(null);
const triggerContent = ref(null);
const panel = ref(null);
const internalOpen = ref(false);
const isControlled = computed(() => props.open !== undefined);
const expanded = computed(
  () => !disabled.value && (isControlled.value ? props.open : internalOpen.value),
);
const selectedItems = computed(() =>
  props.items.filter(
    (item) =>
      (item.type === 'radio' && props.radioValues[item.group] === item.value) ||
      (item.type === 'checkbox' && props.checkboxValues.includes(item.id)),
  ),
);
const summary = computed(() => selectedItems.value.map((item) => item.label).join('、'));
const triggerSlotProps = computed(() => ({
  open: expanded.value,
  selectedItems: selectedItems.value,
  summary: summary.value,
  toggle,
  aria: {
    'aria-haspopup': 'menu',
    'aria-expanded': String(expanded.value),
    'aria-controls': expanded.value ? `${id}-menu` : undefined,
  },
}));

function setOpen(value) {
  const next = Boolean(value) && !disabled.value;
  if (!isControlled.value) internalOpen.value = next;
  emit('update:open', next);
  if (next)
    nextTick(() => {
      updatePanelPosition();
      focusItem();
    });
}
function toggle() {
  setOpen(!expanded.value);
}
function itemNodes() {
  return [...(panel.value?.querySelectorAll('[role^="menuitem"]:not(:disabled)') || [])];
}
function focusItem(index = 0) {
  nextTick(() => {
    const nodes = itemNodes();
    nodes[Math.max(0, Math.min(index, nodes.length - 1))]?.focus();
  });
}
function restoreFocus() {
  nextTick(() => trigger.value?.focus());
}
function close({ restore = false } = {}) {
  setOpen(false);
  if (restore) restoreFocus();
}
function isChecked(item) {
  if (item.type === 'radio') return props.radioValues[item.group] === item.value;
  if (item.type === 'checkbox') return props.checkboxValues.includes(item.id);
  return false;
}
function activate(item, source = 'click') {
  if (disabled.value || item.disabled) return;
  if (item.type === 'action') {
    emit('action', { id: item.id });
    close({ restore: true });
  } else if (item.type === 'radio') {
    if (!isChecked(item)) emit('update:radio', { groupId: item.group, value: item.value });
    if (source !== 'space') close({ restore: true });
  } else if (item.type === 'checkbox') {
    emit('update:checked', { id: item.id, checked: !isChecked(item) });
    if (source === 'enter') close({ restore: true });
    else nextTick(updatePanelPosition);
  }
}
function handleItemKeydown(event, item) {
  if (event.key === ' ' || event.key === 'Enter') {
    event.preventDefault();
    activate(item, event.key === ' ' ? 'space' : 'enter');
  }
}
function keydown(event) {
  if (event.key === 'Escape') {
    if (!expanded.value) return;
    event.preventDefault();
    event.stopPropagation();
    close({ restore: true });
    return;
  }
  if (!['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key) || disabled.value) return;
  event.preventDefault();
  if (!expanded.value) {
    setOpen(true);
    nextTick(() =>
      focusItem(event.key === 'ArrowUp' || event.key === 'End' ? itemNodes().length - 1 : 0),
    );
    return;
  }
  const nodes = itemNodes();
  if (!nodes.length) return;
  const index = nodes.indexOf(document.activeElement);
  const target =
    event.key === 'Home'
      ? 0
      : event.key === 'End'
        ? nodes.length - 1
        : index < 0
          ? event.key === 'ArrowUp'
            ? nodes.length - 1
            : 0
          : (index + (event.key === 'ArrowDown' ? 1 : -1) + nodes.length) % nodes.length;
  nodes[target]?.focus();
}
function withinDropdown(node) {
  return Boolean(node && (root.value?.contains(node) || panel.value?.contains(node)));
}
function handleOutside(event) {
  if (expanded.value && !withinDropdown(event.target)) close();
}
function handleFocusOut(event) {
  if (expanded.value && !withinDropdown(event.relatedTarget)) close();
}
function getPanelLeft(element, panelRect, triggerRect, gap) {
  const panelWidth = panelRect.width;
  const firstItem = element.querySelector('.wb-dropdown__item');
  const itemStart = element.querySelector(
    '.wb-dropdown__item .wb-choice-mark, .wb-dropdown__item-leading, .wb-dropdown__item-label',
  );
  const itemStartInset = itemStart ? itemStart.getBoundingClientRect().left - panelRect.left : 0;
  const firstItemStyle = firstItem ? getComputedStyle(firstItem) : null;
  const itemContentRight = firstItem
    ? firstItem.getBoundingClientRect().right - (parseFloat(firstItemStyle.paddingRight) || 0)
    : panelRect.right;
  const itemContentRightInset = panelRect.right - itemContentRight;
  const triggerContentRect = triggerContent.value?.getBoundingClientRect();
  const alignToContent = ['text', 'icon'].includes(props.triggerType);
  const contentLeft = triggerContentRect?.left ?? triggerRect.left;
  const contentRight = triggerContentRect?.right ?? triggerRect.right;
  const leftAligned = alignToContent ? contentLeft - itemStartInset : triggerRect.left;
  const rightEdge = props.triggerType === 'icon' ? contentRight : triggerRect.right;
  const rightAligned =
    rightEdge + (props.triggerType === 'icon' ? itemContentRightInset : 0) - panelWidth;
  const left = leftAligned + panelWidth <= window.innerWidth - gap ? leftAligned : rightAligned;
  return Math.min(Math.max(gap, left), Math.max(gap, window.innerWidth - gap - panelWidth));
}
function updatePanelPosition() {
  if (!expanded.value || !trigger.value || !panel.value) return;
  const gap =
    parseFloat(
      getComputedStyle(document.documentElement).getPropertyValue('--wb-spacing-component-xs'),
    ) || 4;
  const triggerRect = trigger.value.getBoundingClientRect();
  const element = panel.value;
  element.style.removeProperty('--dropdown-max-height');
  const naturalHeight = element.scrollHeight;
  const panelRect = element.getBoundingClientRect();
  const clampedLeft = getPanelLeft(element, panelRect, triggerRect, gap);
  const below = Math.max(0, window.innerHeight - triggerRect.bottom - gap * 2);
  const above = Math.max(0, triggerRect.top - gap * 2);
  const placement =
    naturalHeight <= below
      ? 'bottom'
      : naturalHeight <= above
        ? 'top'
        : below >= above
          ? 'bottom'
          : 'top';
  const available = placement === 'bottom' ? below : above;
  const renderedHeight = Math.min(naturalHeight, available);
  const top =
    placement === 'bottom' ? triggerRect.bottom + gap : triggerRect.top - gap - renderedHeight;
  element.dataset.placement = placement;
  element.style.setProperty('--dropdown-left', `${clampedLeft}px`);
  element.style.setProperty('--dropdown-top', `${Math.max(gap, top)}px`);
  element.style.setProperty('--dropdown-max-height', `${available}px`);
}
function handleDocumentScroll(event) {
  if (panel.value?.contains(event.target)) return;
  updatePanelPosition();
}

let resizeObserver;
onMounted(() => {
  document.addEventListener('pointerdown', handleOutside);
  window.addEventListener('resize', updatePanelPosition);
  document.addEventListener('scroll', handleDocumentScroll, true);
  resizeObserver = new ResizeObserver(updatePanelPosition);
  if (trigger.value) resizeObserver.observe(trigger.value);
});
watch(
  panel,
  (node, previous) => {
    if (previous) resizeObserver?.unobserve(previous);
    if (node) resizeObserver?.observe(node);
    nextTick(updatePanelPosition);
  },
  { flush: 'post' },
);
watch(
  () => disabled.value,
  (value) => {
    if (value) setOpen(false);
  },
);
onBeforeUnmount(() => {
  document.removeEventListener('pointerdown', handleOutside);
  window.removeEventListener('resize', updatePanelPosition);
  document.removeEventListener('scroll', handleDocumentScroll, true);
  resizeObserver?.disconnect();
});
</script>

<template>
  <span
    ref="root"
    class="wb-dropdown"
    :class="[
      `wb-dropdown--${size}`,
      `wb-dropdown--trigger-${triggerType}`,
      {
        [`wb-dropdown--text-${textIntent}`]: triggerType === 'text',
        'is-text-inline': triggerType === 'text' && textLayout === 'inline',
        'is-open': expanded,
        'is-disabled': disabled,
      },
    ]"
    @focusout="handleFocusOut"
  >
    <button
      :id="`${id}-trigger`"
      ref="trigger"
      type="button"
      class="wb-dropdown__trigger"
      :disabled="disabled"
      :aria-label="ariaLabel"
      aria-haspopup="menu"
      :aria-expanded="expanded"
      :aria-controls="expanded ? `${id}-menu` : undefined"
      @click="toggle"
      @keydown="keydown"
    >
      <span
        ref="triggerContent"
        class="wb-dropdown__trigger-content"
        ><slot
          name="trigger"
          v-bind="triggerSlotProps"
          >{{ summary || ariaLabel }}</slot
        ></span
      >
      <span
        class="wb-dropdown__arrow-frame"
        aria-hidden="true"
      >
        <WorkbenchIcon
          class="wb-dropdown__arrow"
          name="/ic_arrow_right_line#2:141"
          :size="10"
        />
      </span>
    </button>
    <Teleport to="body">
      <div
        v-if="expanded"
        :id="`${id}-menu`"
        ref="panel"
        role="menu"
        :aria-labelledby="`${id}-trigger`"
        class="wb-dropdown__panel"
        :class="[`wb-dropdown__panel--${size}`, `is-width-${panelWidth}`]"
        @keydown="keydown"
        @focusout="handleFocusOut"
      >
        <template
          v-for="item in items"
          :key="item.id"
        >
          <div
            v-if="item.type === 'separator'"
            role="separator"
            class="wb-dropdown__separator"
          />
          <div
            v-else-if="item.type === 'label'"
            role="presentation"
            class="wb-dropdown__label"
          >
            {{ item.label }}
          </div>
          <button
            v-else
            type="button"
            :role="
              item.type === 'radio'
                ? 'menuitemradio'
                : item.type === 'checkbox'
                  ? 'menuitemcheckbox'
                  : 'menuitem'
            "
            class="wb-dropdown__item"
            :disabled="item.disabled"
            :aria-disabled="item.disabled || undefined"
            :aria-checked="
              item.type === 'radio' || item.type === 'checkbox' ? isChecked(item) : undefined
            "
            :title="item.label"
            @click="activate(item, 'click')"
            @keydown="handleItemKeydown($event, item)"
          >
            <ChoiceMark
              v-if="item.type === 'checkbox'"
              :checked="isChecked(item)"
              :disabled="item.disabled"
            />
            <span
              v-else-if="item.icon"
              class="wb-dropdown__item-leading"
              aria-hidden="true"
              >{{ item.icon }}</span
            >
            <span class="wb-dropdown__item-label">{{ item.label }}</span>
            <WorkbenchIcon
              v-if="item.type === 'radio' && isChecked(item)"
              class="wb-dropdown__selected-mark"
              name="完成_14px"
            />
          </button>
        </template>
      </div>
    </Teleport>
  </span>
</template>

<style>
.wb-dropdown {
  display: inline-flex;
  vertical-align: middle;
  color: var(--wb-color-text-primary);
}
.wb-dropdown__trigger {
  box-sizing: border-box;
  display: inline-flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--wb-asset-wb-dropdown-trigger-arrow-gap);
  min-width: 0;
  height: var(--dropdown-height);
  padding-inline: var(--wb-spacing-component-md);
  border: 1px solid var(--wb-color-border);
  border-radius: var(--wb-radius-sm);
  background: transparent;
  color: inherit;
  font: inherit;
  cursor: pointer;
}
.wb-dropdown__trigger-content {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.wb-dropdown__arrow-frame {
  display: inline-grid;
  width: var(--wb-asset-wb-dropdown-arrow-size);
  height: var(--wb-asset-wb-dropdown-arrow-size);
  flex: none;
  place-items: center;
  transform: rotate(90deg);
  transition: transform var(--wb-asset-wb-dropdown-arrow-motion-duration)
    var(--wb-asset-wb-dropdown-arrow-motion-easing);
}
.wb-dropdown.is-open .wb-dropdown__arrow-frame {
  transform: rotate(270deg);
}
@media (prefers-reduced-motion: reduce) {
  .wb-dropdown__arrow-frame {
    transition: none;
  }
}
.wb-dropdown__trigger:hover {
  border-color: var(--wb-color-border-hover);
}
.wb-dropdown__trigger:focus-visible {
  border-color: var(--wb-color-border-focus);
  outline: 1px solid var(--wb-color-border-focus);
  outline-offset: 0;
}
.wb-dropdown--trigger-button .wb-dropdown__trigger {
  padding-inline: var(--wb-spacing-component-md);
  justify-content: center;
  border-color: var(--wb-color-border);
  color: var(--wb-color-text-primary);
  background: var(--wb-color-fill-subtle-default);
}
.wb-dropdown--trigger-button .wb-dropdown__arrow-frame {
  color: var(--wb-color-icon-primary);
}
.wb-dropdown--trigger-button .wb-dropdown__trigger:hover,
.wb-dropdown--trigger-button .wb-dropdown__trigger:active,
.wb-dropdown--trigger-button.is-open .wb-dropdown__trigger {
  border-color: var(--wb-color-border-hover);
}
.wb-dropdown--trigger-button .wb-dropdown__trigger:focus-visible {
  outline: 2px solid var(--wb-color-border-focus);
  outline-offset: 2px;
}
.wb-dropdown--trigger-text .wb-dropdown__trigger {
  padding-inline: var(--wb-spacing-component-sm);
  border: 0;
  background: transparent;
}
.wb-dropdown--trigger-text.is-text-inline .wb-dropdown__trigger {
  height: auto;
  padding: 0;
}
.wb-dropdown--trigger-text.wb-dropdown--text-action .wb-dropdown__trigger {
  color: var(--wb-color-text-action);
}
.wb-dropdown--trigger-text.wb-dropdown--text-drilldown .wb-dropdown__trigger {
  color: var(--wb-color-text-primary);
}
.wb-dropdown--trigger-text .wb-dropdown__trigger:hover {
  color: var(--wb-color-text-action-hover);
}
.wb-dropdown--trigger-text .wb-dropdown__trigger:active,
.wb-dropdown--trigger-text.is-open .wb-dropdown__trigger {
  color: var(--wb-color-text-action-active);
}
.wb-dropdown--trigger-text .wb-dropdown__trigger:focus-visible {
  outline: 2px solid var(--wb-color-border-focus);
  outline-offset: 2px;
}
.wb-dropdown--trigger-icon .wb-dropdown__trigger {
  min-width: var(--dropdown-height);
  width: var(--dropdown-height);
  padding: 0;
  justify-content: center;
  border: 0;
  background: transparent;
  color: var(--wb-color-icon-primary);
}
.wb-dropdown--trigger-icon .wb-dropdown__trigger:hover {
  color: var(--wb-color-icon-hover);
}
.wb-dropdown--trigger-icon .wb-dropdown__trigger:active,
.wb-dropdown--trigger-icon.is-open .wb-dropdown__trigger {
  color: var(--wb-color-icon-active);
}
.wb-dropdown--trigger-icon .wb-dropdown__trigger:focus-visible {
  outline: 2px solid var(--wb-color-border-focus);
  outline-offset: 2px;
}
.wb-dropdown--trigger-icon .wb-dropdown__arrow-frame {
  display: none;
}
.wb-dropdown.is-disabled .wb-dropdown__trigger {
  color: var(--wb-color-text-disabled);
  cursor: not-allowed;
}
.wb-dropdown--trigger-text.wb-dropdown--text-action.is-disabled .wb-dropdown__trigger {
  color: var(--wb-color-text-action-disabled);
}
.wb-dropdown--trigger-text.wb-dropdown--text-drilldown.is-disabled .wb-dropdown__trigger {
  color: var(--wb-color-text-disabled);
}
.wb-dropdown--trigger-button.is-disabled .wb-dropdown__trigger {
  border-color: var(--wb-color-border-disabled);
  color: var(--wb-color-text-disabled);
  background: var(--wb-color-fill-subtle-disabled);
}
.wb-dropdown--trigger-button.is-disabled .wb-dropdown__arrow-frame {
  color: var(--wb-color-icon-disabled);
}
.wb-dropdown--trigger-icon.is-disabled .wb-dropdown__trigger {
  color: var(--wb-color-icon-disabled);
  background: transparent;
}
.wb-dropdown--small {
  --dropdown-height: var(--wb-asset-wb-dropdown-height-small);
  font-size: var(--wb-font-body-s-font-size);
  font-weight: var(--wb-font-body-s-font-weight);
  line-height: var(--wb-font-body-s-line-height);
  letter-spacing: var(--wb-font-body-s-letter-spacing);
}
.wb-dropdown--default,
.wb-dropdown--large {
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
}
.wb-dropdown--default {
  --dropdown-height: var(--wb-asset-wb-dropdown-height-default);
}
.wb-dropdown--large {
  --dropdown-height: var(--wb-asset-wb-dropdown-height-large);
}
.wb-dropdown--trigger-text.wb-dropdown--small,
.wb-dropdown--trigger-icon.wb-dropdown--small {
  --dropdown-height: var(--wb-asset-wb-button-height-28);
}
.wb-dropdown--trigger-text.wb-dropdown--default,
.wb-dropdown--trigger-icon.wb-dropdown--default,
.wb-dropdown--trigger-text.wb-dropdown--large,
.wb-dropdown--trigger-icon.wb-dropdown--large {
  --dropdown-height: var(--wb-asset-wb-button-height-32);
}
.wb-dropdown--trigger-button.wb-dropdown--small {
  --dropdown-height: var(--wb-asset-wb-button-height-28);
}
.wb-dropdown--trigger-button.wb-dropdown--default {
  --dropdown-height: var(--wb-asset-wb-button-height-32);
}
.wb-dropdown--trigger-button.wb-dropdown--large {
  --dropdown-height: var(--wb-asset-wb-button-height-36);
}
.wb-dropdown__panel {
  box-sizing: border-box;
  position: fixed;
  z-index: 40;
  top: var(--dropdown-top);
  left: var(--dropdown-left);
  display: grid;
  gap: var(--wb-spacing-component-xs);
  width: max-content;
  min-width: var(--dropdown-panel-default-width);
  max-width: min(
    var(--wb-asset-wb-dropdown-panel-max-width),
    calc(100vw - 2 * var(--wb-spacing-component-xs))
  );
  max-height: var(--dropdown-max-height);
  padding: var(--wb-spacing-component-xs);
  overflow-y: auto;
  border: 0;
  border-radius: var(--wb-radius-md);
  background: var(--wb-color-surface-overlay);
  box-shadow: var(--wb-shadow-sm);
  color: var(--wb-color-text-primary);
}
.wb-dropdown__panel--small {
  --dropdown-height: var(--wb-asset-wb-dropdown-height-small);
  --dropdown-panel-default-width: var(--wb-asset-wb-dropdown-panel-width-small);
  --dropdown-panel-min-width: var(--wb-asset-wb-dropdown-panel-min-width-compact);
  font-size: var(--wb-font-body-s-font-size);
  font-weight: var(--wb-font-body-s-font-weight);
  line-height: var(--wb-font-body-s-line-height);
  letter-spacing: var(--wb-font-body-s-letter-spacing);
}
.wb-dropdown__panel--default,
.wb-dropdown__panel--large {
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
}
.wb-dropdown__panel--default {
  --dropdown-height: var(--wb-asset-wb-dropdown-height-default);
  --dropdown-panel-default-width: var(--wb-asset-wb-dropdown-panel-width-default);
  --dropdown-panel-min-width: var(--wb-asset-wb-dropdown-panel-min-width-compact);
}
.wb-dropdown__panel--large {
  --dropdown-height: var(--wb-asset-wb-dropdown-height-large);
  --dropdown-panel-default-width: var(--wb-asset-wb-dropdown-panel-width-large);
  --dropdown-panel-min-width: var(--wb-asset-wb-dropdown-panel-min-width-large);
}
.wb-dropdown__panel.is-width-min {
  width: var(--dropdown-panel-min-width);
  min-width: var(--dropdown-panel-min-width);
  max-width: var(--dropdown-panel-min-width);
}
.wb-dropdown__panel.is-width-max {
  width: min(
    var(--wb-asset-wb-dropdown-panel-max-width),
    calc(100vw - 2 * var(--wb-spacing-component-xs))
  );
  min-width: min(
    var(--wb-asset-wb-dropdown-panel-max-width),
    calc(100vw - 2 * var(--wb-spacing-component-xs))
  );
}
.wb-dropdown__item {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--wb-spacing-component-sm);
  width: 100%;
  min-width: 0;
  height: var(--dropdown-height);
  padding-inline: var(--wb-spacing-component-sm);
  border: 0;
  border-radius: var(--wb-radius-sm);
  background: transparent;
  color: inherit;
  font: inherit;
  text-align: left;
  cursor: pointer;
}
.wb-dropdown__item:not(:disabled):hover,
.wb-dropdown__item:not(:disabled):focus-visible {
  background: var(--wb-color-fill-hover);
  outline: none;
}
.wb-dropdown__item:disabled {
  color: var(--wb-color-text-disabled);
  cursor: not-allowed;
}
.wb-dropdown__item-label {
  min-width: 0;
  flex: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.wb-dropdown__item-leading {
  width: var(--wb-asset-wb-dropdown-leading-icon-size);
  height: var(--wb-asset-wb-dropdown-leading-icon-size);
  flex: none;
}
.wb-dropdown__selected-mark {
  flex: none;
  color: currentColor;
}
.wb-dropdown__item .wb-choice-mark {
  align-self: center;
  margin-block-start: 0;
}
.wb-dropdown__item:not(:disabled):hover .wb-choice-mark {
  border-color: var(--wb-color-icon-primary);
}
.wb-dropdown__label {
  padding: var(--wb-spacing-component-xs) var(--wb-spacing-component-sm) 0;
  color: var(--wb-color-text-secondary);
}
.wb-dropdown__separator {
  height: var(--wb-asset-wb-dropdown-separator-width);
  margin-inline: var(--wb-spacing-component-sm);
  background: var(--wb-color-border);
}
</style>
