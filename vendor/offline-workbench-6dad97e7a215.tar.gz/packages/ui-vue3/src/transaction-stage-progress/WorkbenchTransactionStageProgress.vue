<script setup>
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import WorkbenchSteps from '../steps/WorkbenchSteps.vue';

defineProps({
  items: { type: Array, required: true },
  modelValue: { type: Number, default: 0 },
  current: Number,
  readonly: { type: Boolean, default: true },
  ariaLabel: { type: String, default: '交易进度' },
});
const emit = defineEmits(['update:modelValue', 'change']);
</script>

<template>
  <div class="transaction-stage-progress">
    <WorkbenchSteps
      :items="items"
      :model-value="modelValue"
      :current="current"
      :readonly="readonly"
      size="medium"
      node-type="icon"
      :aria-label="ariaLabel"
      @update:model-value="emit('update:modelValue', $event)"
      @change="(index, item) => emit('change', index, item)"
    >
      <template #title="{ item, index }">
        <span class="transaction-stage-progress__title">
          <span class="transaction-stage-progress__label">{{ item.title }}</span>
          <WorkbenchIcon
            v-if="index === modelValue"
            class="transaction-stage-progress__pointer"
            name="定位/指针"
            :size="16"
            aria-hidden="true"
          />
        </span>
      </template>
    </WorkbenchSteps>
  </div>
</template>

<style scoped>
.transaction-stage-progress {
  min-width: 0;
  padding: var(--wb-spacing-component-lg);
  border-radius: var(--wb-radius-sm);
  background: var(--wb-color-surface-card-tinted);
}
.transaction-stage-progress__title {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--wb-spacing-component-sm);
  min-width: 0;
}
.transaction-stage-progress__label {
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>
