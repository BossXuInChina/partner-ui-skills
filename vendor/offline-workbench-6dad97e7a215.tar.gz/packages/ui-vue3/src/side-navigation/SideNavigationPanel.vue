<script setup>
import { computed, ref, watch } from 'vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import WorkbenchSearch from '../search/WorkbenchSearch.vue';
import SideNavigationPanelList from './SideNavigationPanelList.vue';

const props = defineProps({
  item: { type: Object, required: true },
  mode: { type: String, default: 'flyout' },
  density: { type: String, default: 'default' },
  showFlyoutIcons: { type: Boolean, default: true },
  activeItem: { type: String, default: '' },
  expandAll: { type: Boolean, default: false },
});
const emit = defineEmits(['select', 'close']);
const query = ref('');
const favoriteIds = ref(new Set());
const fallbackFlyoutIcon = '布局视图/视图=宫格,尺寸=16,面性=off';
watch(() => props.item.id, () => { query.value = ''; });
const groups = computed(() => {
  const needle = query.value.trim().toLocaleLowerCase();
  return (props.item.children ?? []).map(group => {
    const entries = group.children?.length ? group.children : [group];
    const groupMatches = group.label.toLocaleLowerCase().includes(needle);
    return { ...group, entries: entries.filter(entry => groupMatches || [entry.label, entry.description].filter(Boolean).join(' ').toLocaleLowerCase().includes(needle)) };
  }).filter(group => group.entries.length);
});
function toggleFavorite(entry) {
  const next = new Set(favoriteIds.value);
  if (next.has(entry.id)) next.delete(entry.id);
  else next.add(entry.id);
  favoriteIds.value = next;
}
function moveFocus(event) {
  if (!['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) return;
  const buttons = [...event.currentTarget.querySelectorAll('.wb-side-nav__panel-option:not([disabled])')];
  const current = buttons.indexOf(event.target.closest('button'));
  if (current < 0) return;
  event.preventDefault();
  const target = event.key === 'Home' ? 0 : event.key === 'End' ? buttons.length - 1 : (current + (event.key === 'ArrowDown' ? 1 : -1) + buttons.length) % buttons.length;
  buttons[target]?.focus();
}
</script>

<template>
  <section class="wb-side-nav__panel" :class="[`wb-side-nav__panel--${mode}`, `wb-side-nav__panel--${density}`]" :aria-label="`${item.label}子菜单`" @keydown.esc.stop="emit('close')" @keydown.left.self.prevent="emit('close')">
    <SideNavigationPanelList v-if="mode === 'popup'" :items="item.children" :active-item="activeItem" :expand-all="expandAll" @select="emit('select', $event)" @back="emit('close')" />
    <template v-else>
      <WorkbenchSearch v-if="mode === 'columns'" v-model="query" class="wb-side-nav__panel-search" placeholder="搜索导航菜单" />
      <div class="wb-side-nav__panel-groups" @keydown="moveFocus">
        <section v-for="group in groups" :key="group.id" class="wb-side-nav__panel-group" :aria-label="group.label">
          <h3 v-if="group.children?.length" class="wb-side-nav__panel-group-title">{{ group.label }}</h3>
          <ul class="wb-side-nav__panel-options">
            <li v-for="entry in group.entries" :key="entry.id">
              <div class="wb-side-nav__panel-option-row">
                <button type="button" class="wb-side-nav__panel-option" :class="{ 'is-selected': activeItem === entry.id }" :aria-current="activeItem === entry.id ? 'page' : undefined" :title="[entry.label, entry.description].filter(Boolean).join('：')" @click="emit('select', entry)" @keydown.left.prevent="emit('close')">
                  <WorkbenchIcon v-if="showFlyoutIcons && mode === 'flyout'" :name="entry.icon || fallbackFlyoutIcon" :size="16" />
                  <span class="wb-side-nav__panel-copy"><span class="wb-side-nav__panel-label">{{ entry.label }}</span><span v-if="entry.description && mode === 'flyout'" class="wb-side-nav__panel-description">{{ entry.description }}</span></span>
                  <WorkbenchIcon v-if="mode === 'flyout' && activeItem === entry.id" class="wb-side-nav__panel-check" name="完成/尺寸=14" />
                </button>
                <button v-if="mode === 'columns'" type="button" class="wb-side-nav__panel-favorite" :aria-label="`${favoriteIds.has(entry.id) ? '取消收藏' : '收藏'}：${entry.label}`" :aria-pressed="favoriteIds.has(entry.id)" @click.stop="toggleFavorite(entry)">
                  <WorkbenchIcon :name="favoriteIds.has(entry.id) ? '收藏/尺寸=12,面性=on' : '收藏/尺寸=12,面性=off'" size="12" />
                </button>
              </div>
            </li>
          </ul>
        </section>
        <p v-if="!groups.length" role="status">未找到匹配菜单</p>
      </div>
    </template>
  </section>
</template>

<style>
.wb-side-nav__panel {
  position: absolute;
  z-index: var(--wb-asset-wb-side-navigation-panel-z-index);
  inset-block: 0;
  inset-inline-start: 100%;
  box-sizing: border-box;
  inline-size: min(var(--wb-asset-wb-side-navigation-panel-width), var(--side-navigation-panel-available));
  min-inline-size: 0;
  overflow: auto;
  color: var(--wb-color-text-primary);
  background: var(--wb-color-surface-container);
  box-shadow: var(--wb-shadow-r-sm);
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
}
.wb-side-nav__panel-groups { padding: 0 var(--wb-asset-wb-side-navigation-panel-group-padding) var(--wb-asset-wb-side-navigation-panel-inline-padding); }
.wb-side-nav__panel--flyout .wb-side-nav__panel-groups { padding: var(--wb-asset-wb-side-navigation-flyout-panel-block-padding) var(--wb-asset-wb-side-navigation-flyout-panel-inline-end-padding) var(--wb-asset-wb-side-navigation-flyout-panel-block-padding) var(--wb-asset-wb-side-navigation-flyout-panel-inline-start-padding); }
.wb-side-nav__panel-group + .wb-side-nav__panel-group { margin-block-start: var(--wb-asset-wb-side-navigation-panel-group-gap); }
.wb-side-nav__panel-group-title { padding: var(--wb-spacing-component-md) var(--wb-spacing-component-lg) var(--wb-spacing-component-sm); margin: 0; color: var(--wb-color-text-secondary); font-size: var(--wb-font-body-s-font-size); font-weight: var(--wb-font-body-s-font-weight); line-height: var(--wb-font-body-s-line-height); letter-spacing: var(--wb-font-body-s-letter-spacing); }
.wb-side-nav__panel--flyout .wb-side-nav__panel-group-title { padding-block-start: 0; }
.wb-side-nav__panel-options { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: var(--wb-spacing-component-sm); padding: 0; margin: 0; list-style: none; }
.wb-side-nav__panel-option { display: flex; align-items: center; gap: var(--wb-asset-wb-side-navigation-icon-text-gap); box-sizing: border-box; inline-size: 100%; min-inline-size: 0; padding: var(--wb-spacing-component-sm) var(--wb-spacing-component-lg); border: 0; border-radius: var(--wb-radius-xs); color: inherit; background: transparent; font: inherit; text-align: start; cursor: pointer; }
.wb-side-nav__panel-option-row { display: flex; min-inline-size: 0; }
.wb-side-nav__panel-option:hover, .wb-side-nav__panel-option:focus-visible { background: var(--wb-color-fill-hover); }
.wb-side-nav__panel-option.is-selected { color: var(--wb-color-brand); background: var(--wb-color-fill-selected); }
.wb-side-nav__panel--flyout .wb-side-nav__panel-option { block-size: var(--wb-asset-wb-side-navigation-flyout-row-height); padding: var(--wb-asset-wb-side-navigation-flyout-item-block-padding) var(--wb-asset-wb-side-navigation-flyout-item-inline-padding); border-radius: var(--wb-radius-sm); }
.wb-side-nav__panel--flyout .wb-side-nav__panel-option > .workbench-icon:not(.wb-side-nav__panel-check) { align-self: flex-start; margin-block-start: var(--wb-asset-wb-side-navigation-flyout-icon-title-offset); }
.wb-side-nav__panel--flyout .wb-side-nav__panel-option.is-selected { color: var(--wb-color-text-primary); background: var(--wb-color-fill-selected); }
.wb-side-nav__panel--flyout .wb-side-nav__panel-option.is-selected > .workbench-icon:not(.wb-side-nav__panel-check) { color: var(--wb-color-brand); }
.wb-side-nav__panel-check { margin-inline-start: auto; color: var(--wb-color-icon-primary); }
.wb-side-nav__panel--popup .wb-side-nav__panel-option.is-selected { color: var(--wb-color-text-primary); }
.wb-side-nav__panel-option:focus-visible { outline: var(--wb-asset-wb-side-navigation-selected-track-width) solid var(--wb-color-border-focus); outline-offset: calc(0px - var(--wb-asset-wb-side-navigation-selected-track-width)); }
.wb-side-nav__panel-copy { display: flex; flex: 1; flex-direction: column; min-inline-size: 0; }
.wb-side-nav__panel-label, .wb-side-nav__panel-description { display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.wb-side-nav__panel-description { color: var(--wb-color-text-secondary); font-size: var(--wb-font-body-s-font-size); font-weight: var(--wb-font-body-s-font-weight); line-height: var(--wb-font-body-s-line-height); letter-spacing: var(--wb-font-body-s-letter-spacing); }
.wb-side-nav__panel--columns { inline-size: var(--side-navigation-panel-available); padding: var(--wb-asset-wb-side-navigation-columns-block-padding) var(--wb-asset-wb-side-navigation-panel-inline-padding); }
.wb-side-nav__panel-search { inline-size: min(100%, var(--wb-asset-wb-side-navigation-panel-search-width)); margin-block-end: var(--wb-asset-wb-side-navigation-columns-group-gap); }
.wb-side-nav__panel--columns .wb-side-nav__panel-groups { padding: 0; }
.wb-side-nav__panel--columns .wb-side-nav__panel-group + .wb-side-nav__panel-group { margin-block-start: var(--wb-asset-wb-side-navigation-columns-group-gap); }
.wb-side-nav__panel--columns .wb-side-nav__panel-options { grid-template-columns: repeat(4, minmax(0, 1fr)); }
.wb-side-nav__panel--columns .wb-side-nav__panel-group-title { padding: 0 var(--wb-spacing-component-sm); margin-block-end: var(--wb-asset-wb-side-navigation-columns-heading-gap); font: var(--wb-font-body-m); color: var(--wb-color-text-primary); }
.wb-side-nav__panel--columns .wb-side-nav__panel-option-row { align-items: center; border-radius: var(--wb-radius-xs); }
.wb-side-nav__panel--columns .wb-side-nav__panel-option-row:hover, .wb-side-nav__panel--columns .wb-side-nav__panel-option-row:focus-within { background: var(--wb-color-fill-hover); }
.wb-side-nav__panel--columns .wb-side-nav__panel-option-row:has(.wb-side-nav__panel-option.is-selected) { background: var(--wb-color-fill-selected); }
.wb-side-nav__panel--columns .wb-side-nav__panel-option { flex: 1; padding: var(--wb-asset-wb-side-navigation-columns-item-block-padding) var(--wb-spacing-component-sm); border-radius: var(--wb-radius-xs) 0 0 var(--wb-radius-xs); color: var(--wb-color-text-secondary); }
.wb-side-nav__panel--columns .wb-side-nav__panel-option:hover, .wb-side-nav__panel--columns .wb-side-nav__panel-option:focus-visible { background: transparent; }
.wb-side-nav__panel--columns .wb-side-nav__panel-option.is-selected { color: var(--wb-color-brand); background: transparent; }
.wb-side-nav__panel-favorite { display: inline-flex; flex: none; align-items: center; justify-content: center; inline-size: 28px; padding: 0; border: 0; border-radius: 0 var(--wb-radius-xs) var(--wb-radius-xs) 0; color: var(--wb-color-text-secondary); background: transparent; cursor: pointer; }
.wb-side-nav__panel-favorite:hover, .wb-side-nav__panel-favorite:focus-visible { color: var(--wb-color-text-primary); }
.wb-side-nav__panel-favorite[aria-pressed="true"] { color: var(--wb-color-warning); }
.wb-side-nav__panel-favorite:focus-visible { outline: var(--wb-asset-wb-side-navigation-selected-track-width) solid var(--wb-color-border-focus); outline-offset: calc(0px - var(--wb-asset-wb-side-navigation-selected-track-width)); }
.wb-side-nav__panel--popup { inset-block-start: min(var(--side-navigation-panel-anchor), calc(100% - var(--wb-asset-wb-side-navigation-popup-min-visible-height))); inset-block-end: auto; max-block-size: calc(100% - min(var(--side-navigation-panel-anchor), calc(100% - var(--wb-asset-wb-side-navigation-popup-min-visible-height)))); inline-size: min(var(--wb-asset-wb-side-navigation-popup-width), var(--side-navigation-panel-available)); padding: var(--wb-asset-wb-side-navigation-popup-padding); border-radius: var(--wb-radius-md); box-shadow: var(--wb-shadow-base); }
</style>
