<script setup>
import { nextTick, ref } from 'vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';

const props = defineProps({ items: { type: Array, default: () => [] }, activeItem: { type: String, default: '' }, expandAll: { type: Boolean, default: false } });
const emit = defineEmits(['select', 'back']);
const openId = ref(props.items.find(item => item.children?.some(child => child.id === props.activeItem))?.id ?? '');
const list = ref(null);
const hasChildren = item => item.children?.length > 0;
const isOpen = item => props.expandAll || openId.value === item.id;
const containsActive = item => item.id === props.activeItem || (item.children ?? []).some(containsActive);
function activate(item) {
  if (hasChildren(item)) { if (!props.expandAll) openId.value = openId.value === item.id ? '' : item.id; }
  else emit('select', item);
}
function returnTo(item) {
  openId.value = '';
  nextTick(() => list.value?.querySelector(`[data-panel-item="${CSS.escape(item.id)}"]`)?.focus());
}
function handleKey(event, item) {
  const ownList = event.currentTarget.closest('ul');
  const buttons = [...ownList.children].map(li => li.querySelector(':scope > button')).filter(Boolean);
  const index = buttons.indexOf(event.currentTarget);
  if (['ArrowUp', 'ArrowDown', 'Home', 'End'].includes(event.key)) {
    event.preventDefault();
    const target = event.key === 'Home' ? 0 : event.key === 'End' ? buttons.length - 1 : (index + (event.key === 'ArrowDown' ? 1 : -1) + buttons.length) % buttons.length;
    buttons[target]?.focus();
  } else if (event.key === 'ArrowRight' && hasChildren(item)) {
    event.preventDefault();
    openId.value = item.id;
    const button = event.currentTarget;
    nextTick(() => button.parentElement?.querySelector(':scope > ul > li > button')?.focus());
  } else if (event.key === 'ArrowLeft') {
    event.preventDefault();
    if (openId.value === item.id) openId.value = '';
    else emit('back');
  }
}
</script>
<template>
  <ul ref="list" class="wb-side-nav__popup-list">
    <li v-for="item in items" :key="item.id">
      <button type="button" class="wb-side-nav__panel-option" :data-panel-item="item.id" :class="{ 'is-selected': containsActive(item) }" :title="item.label" :aria-current="activeItem === item.id ? 'page' : undefined" :aria-expanded="hasChildren(item) ? isOpen(item) : undefined" @click="activate(item)" @keydown="handleKey($event, item)">
        <span class="wb-side-nav__panel-copy"><span class="wb-side-nav__panel-label">{{ item.label }}</span></span>
        <span class="wb-side-nav__popup-trailing">
          <WorkbenchIcon v-if="hasChildren(item)" class="wb-side-nav__popup-arrow" :class="{ 'is-expanded': isOpen(item) }" name="/ic_arrow_right_line#2:142" />
          <WorkbenchIcon v-if="activeItem === item.id" class="wb-side-nav__popup-check" name="完成/尺寸=12" />
        </span>
      </button>
      <SideNavigationPanelList v-if="hasChildren(item) && isOpen(item)" :items="item.children" :active-item="activeItem" :expand-all="expandAll" @select="emit('select', $event)" @back="returnTo(item)" />
    </li>
  </ul>
</template>
<style scoped>
.wb-side-nav__popup-list { display: flex; flex-direction: column; gap: var(--wb-asset-wb-side-navigation-popup-gap); padding: 0; margin: 0; list-style: none; }
.wb-side-nav__popup-list .wb-side-nav__popup-list { padding-inline-start: var(--wb-asset-wb-side-navigation-child-no-icon-indent); margin-block-start: var(--wb-asset-wb-side-navigation-popup-gap); }
.wb-side-nav__panel-option { block-size: var(--wb-asset-wb-side-navigation-popup-row-height); padding: var(--wb-asset-wb-side-navigation-popup-item-block-padding) var(--wb-asset-wb-side-navigation-popup-item-inline-padding); border-radius: var(--wb-radius-sm); gap: var(--wb-asset-wb-side-navigation-panel-group-padding); }
.wb-side-nav__popup-trailing { display: flex; flex: none; align-items: center; justify-content: flex-end; gap: var(--wb-asset-wb-side-navigation-popup-gap); margin-inline-start: auto; }
.wb-side-nav__popup-arrow { transition: transform var(--wb-asset-wb-side-navigation-motion-duration) var(--wb-asset-wb-side-navigation-motion-easing); }
.wb-side-nav__popup-arrow.is-expanded { transform: rotate(90deg); }
@media (prefers-reduced-motion: reduce) { .wb-side-nav__popup-arrow { transition: none; } }
</style>
