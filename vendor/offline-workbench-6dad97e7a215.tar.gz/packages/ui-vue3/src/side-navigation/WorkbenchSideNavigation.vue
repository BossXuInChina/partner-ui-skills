<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch, useId } from 'vue';
import WorkbenchButton from '../button/WorkbenchButton.vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import SideNavigationPanel from './SideNavigationPanel.vue';
import '../../../../catalog/generated/asset.tokens.css';

const props = defineProps({
  title: { type: String, default: '' },
  topToggle: { type: Boolean, default: false },
  width: { type: String, default: '' },
  panelMode: { type: String, default: 'flyout', validator: value => ['flyout', 'popup', 'columns'].includes(value) },
  panelDensity: { type: String, default: 'default', validator: value => ['small', 'default', 'large'].includes(value) },
  showFlyoutIcons: { type: Boolean, default: true },
  showDivider: { type: Boolean, default: true },
  ariaLabel: { type: String, default: '侧边导航' },
  items: { type: Array, default: () => [] },
  collapsed: { type: Boolean, default: false },
  activeItem: { type: String, default: '' },
  expandedItems: { type: Array, default: () => [] },
  panelItemId: { type: String, default: undefined },
  panelExpandAll: { type: Boolean, default: false },
  collapsible: { type: Boolean, default: true },
});

const emit = defineEmits(['update:collapsed', 'update:activeItem', 'update:expandedItems', 'update:panelItemId', 'select']);
const root = ref(null);
const viewportWidth = ref(typeof window === 'undefined' ? 1440 : window.innerWidth);
const internalPanelItem = ref(null);
const panelItem = computed(() => {
  if (props.panelItemId === undefined) return internalPanelItem.value;
  return props.items.flatMap(item => item.children ?? []).find(child => child.id === props.panelItemId && hasChildren(child)) ?? null;
});
const panelTrigger = ref(null);
const panelId = `wb-side-panel-${useId()}`;
const iconAliases = { home: '房子/尺寸=16,面性=off', chart: '图表/类型=柱状图,尺寸=16,面性=off', users: '文件/尺寸=16', grid: '布局视图/视图=宫格,尺寸=16,面性=off' };
const iconName = value => iconAliases[value] ?? (value || '布局视图/视图=宫格,尺寸=16,面性=off');
const containsActive = item => item.id === props.activeItem || (item.children ?? []).some(containsActive);
const expandedSet = computed(() => new Set(props.expandedItems));
const sizeClass = computed(() => {
  if (viewportWidth.value < 768) return 'is-size-undefined';
  if (viewportWidth.value >= 1921) return 'is-size-ultrawide';
  if (viewportWidth.value >= 1280) return 'is-size-wide';
  return 'is-size-medium';
});
const hasChildren = item => Array.isArray(item.children) && item.children.length > 0;
const hasActivePage = item => hasChildren(item) ? item.children.some(hasActivePage) : item.id === props.activeItem;
const isExpanded = item => expandedSet.value.has(item.id);

function updateExpanded(id, expanded) {
  const next = new Set(props.expandedItems);
  if (expanded) next.add(id); else next.delete(id);
  emit('update:expandedItems', [...next]);
}

function setPanel(item) {
  if (props.panelItemId === undefined) internalPanelItem.value = item;
  else emit('update:panelItemId', item?.id ?? '');
}

function activate(item, event, child = false) {
  if (child && hasChildren(item)) {
    if (panelItem.value?.id === item.id) closePanel();
    else {
      setPanel(item);
      panelTrigger.value = event?.currentTarget ?? null;
      measureViewport();
    }
    return;
  }
  closePanel(false);
  if (hasChildren(item)) {
    if (props.collapsed) {
      emit('update:collapsed', false);
      updateExpanded(item.id, true);
    } else {
      updateExpanded(item.id, !isExpanded(item));
    }
    return;
  }
  emit('update:activeItem', item.id);
  emit('select', item);
}

function sameLevelButtons(button) {
  const list = button.closest('ul');
  if (!list) return [];
  return [...list.children]
    .map(entry => entry.querySelector(':scope > button'))
    .filter(Boolean);
}

function moveFocus(event, edge) {
  const buttons = sameLevelButtons(event.currentTarget);
  const current = buttons.indexOf(event.currentTarget);
  if (current < 0 || !buttons.length) return;
  event.preventDefault();
  const target = edge === 'first' ? 0 : edge === 'last' ? buttons.length - 1 : (current + edge + buttons.length) % buttons.length;
  buttons[target]?.focus();
}

function handleKeydown(event, item, child = false) {
  if (event.key === 'ArrowDown') return moveFocus(event, 1);
  if (event.key === 'ArrowUp') return moveFocus(event, -1);
  if (event.key === 'Home') return moveFocus(event, 'first');
  if (event.key === 'End') return moveFocus(event, 'last');
  if (event.key === 'Escape') { closePanel(); return; }
  if (child) return handleChildKeydown(event, item);
  if (!hasChildren(item)) return;
  if (event.key === 'ArrowRight') {
    event.preventDefault();
    if (props.collapsed) emit('update:collapsed', false);
    if (!isExpanded(item)) updateExpanded(item.id, true);
    nextTick(() => root.value?.querySelector(`[data-parent-id="${CSS.escape(item.id)}"]`)?.focus());
  }
  if (event.key === 'ArrowLeft' && isExpanded(item)) {
    event.preventDefault();
    updateExpanded(item.id, false);
  }
}

function handleChildKeydown(event, item) {
  if (event.key === 'ArrowLeft') {
    event.preventDefault();
    const parent = event.currentTarget.closest('.wb-side-nav__children')?.parentElement?.querySelector(':scope > button');
    closePanel(false);
    parent?.focus();
    return;
  }
  if (!hasChildren(item)) return;
  if (event.key === 'ArrowRight') {
    event.preventDefault();
    if (panelItem.value?.id !== item.id) activate(item, event, true);
    nextTick(() => root.value?.querySelector('.wb-side-nav__panel-option')?.focus());
    return;
  }
}

function toggleNavigation() {
  closePanel(false);
  emit('update:collapsed', !props.collapsed);
}

function beforeSubmenuEnter(element) {
  element.style.height = '0';
  element.style.overflow = 'hidden';
}

function enterSubmenu(element) {
  requestAnimationFrame(() => { element.style.height = `${element.scrollHeight}px`; });
}

function afterSubmenuEnter(element) {
  element.style.height = 'auto';
  element.style.overflow = '';
}

function beforeSubmenuLeave(element) {
  element.style.height = `${element.scrollHeight}px`;
  element.style.overflow = 'hidden';
}

function leaveSubmenu(element) {
  requestAnimationFrame(() => { element.style.height = '0'; });
}

function afterSubmenuLeave(element) {
  element.style.height = '';
  element.style.overflow = '';
}

function closePanel(restoreFocus = true) {
  setPanel(null);
  if (restoreFocus) nextTick(() => { if (!panelItem.value) panelTrigger.value?.focus(); });
}
function selectPanelItem(item) {
  emit('update:activeItem', item.id);
  emit('select', item);
  closePanel();
}
function onOutsidePointer(event) {
  if (panelItem.value && !root.value?.contains(event.target)) closePanel(false);
}
function measureViewport() {
  viewportWidth.value = window.innerWidth;
  if (!root.value) return;
  const box = root.value.getBoundingClientRect();
  root.value.style.setProperty('--side-navigation-panel-available', `${Math.max(0, window.innerWidth - box.right)}px`);
  const y = Math.max(0, (panelTrigger.value?.getBoundingClientRect().top ?? box.top) - box.top);
  root.value.style.setProperty('--side-navigation-panel-anchor', `${y}px`);
}
watch(() => props.width, value => {
  if (value) root.value?.style.setProperty('--side-navigation-width', value);
  else root.value?.style.removeProperty('--side-navigation-width');
  nextTick(measureViewport);
}, { flush: 'post' });
watch(() => props.collapsed, () => { closePanel(false); nextTick(measureViewport); });
watch(() => props.panelMode, () => nextTick(measureViewport));
watch(() => props.panelItemId, () => nextTick(() => {
  panelTrigger.value = panelItem.value
    ? root.value?.querySelector(`[data-child-id="${CSS.escape(panelItem.value.id)}"]`) ?? null
    : null;
  measureViewport();
}));
watch(() => props.items, () => closePanel(false));
watch(() => props.expandedItems, () => {
  if (panelItem.value && !props.items.some(item => isExpanded(item) && item.children?.some(child => child.id === panelItem.value.id))) closePanel(false);
});
onMounted(() => {
  if (props.width) root.value.style.setProperty('--side-navigation-width', props.width);
  measureViewport();
  if (panelItem.value) nextTick(() => {
    panelTrigger.value = root.value?.querySelector(`[data-child-id="${CSS.escape(panelItem.value.id)}"]`) ?? null;
    measureViewport();
  });
  window.addEventListener('resize', measureViewport);
  document.addEventListener('pointerdown', onOutsidePointer);
});
onBeforeUnmount(() => {
  window.removeEventListener('resize', measureViewport);
  document.removeEventListener('pointerdown', onOutsidePointer);
});
defineExpose({ toggle: toggleNavigation, closePanel });
</script>

<template>
  <nav ref="root" class="wb-side-nav" :class="[sizeClass, { 'is-collapsed': collapsed, 'has-divider': showDivider }]" :aria-label="ariaLabel" @keydown.esc.stop="closePanel()" @transitionend.self="measureViewport">
    <header v-if="title || topToggle" class="wb-side-nav__header" :class="{ 'has-title': title && !collapsed }">
      <span v-if="title && !collapsed" class="wb-side-nav__label" :title="title">{{ title }}</span>
      <WorkbenchButton v-if="topToggle" appearance="icon" icon-layout="container" size="32" :aria-label="collapsed ? '展开侧边导航（顶部）' : '收起侧边导航（顶部）'" :aria-expanded="!collapsed" @click="toggleNavigation"><template #icon><WorkbenchIcon :name="collapsed ? '导航/尺寸=20,类型=展开' : '导航/尺寸=20,类型=折叠'" /></template></WorkbenchButton>
    </header>
    <ul class="wb-side-nav__list">
      <li v-for="item in items" :key="item.id" class="wb-side-nav__entry">
        <button
          type="button"
          class="wb-side-nav__item wb-side-nav__item--parent"
          :class="{ 'is-selected': activeItem === item.id, 'is-active-path': containsActive(item) }"
          :aria-current="activeItem === item.id ? 'page' : undefined"
          :aria-expanded="hasChildren(item) ? isExpanded(item) && !collapsed : undefined"
          :aria-label="item.label"
          :title="item.label"
          @click="activate(item, $event)"
          @keydown="handleKeydown($event, item)"
        >
          <span v-if="!hasChildren(item) && activeItem === item.id && !collapsed" class="wb-side-nav__track" aria-hidden="true" />
          <WorkbenchIcon class="wb-side-nav__icon" :name="iconName(item.icon)" :size="16" />
          <span v-if="!collapsed" class="wb-side-nav__label">{{ item.label }}</span>
          <WorkbenchIcon v-if="!collapsed" class="wb-side-nav__arrow" :class="{ 'is-expanded': hasChildren(item) && isExpanded(item) }" name="/ic_arrow_right_line#2:141" />
        </button>

        <Transition
          @before-enter="beforeSubmenuEnter"
          @enter="enterSubmenu"
          @after-enter="afterSubmenuEnter"
          @before-leave="beforeSubmenuLeave"
          @leave="leaveSubmenu"
          @after-leave="afterSubmenuLeave"
        >
          <ul v-if="hasChildren(item) && isExpanded(item) && !collapsed" class="wb-side-nav__children">
            <li v-for="child in item.children" :key="child.id" class="wb-side-nav__entry">
              <button
                type="button"
                class="wb-side-nav__item wb-side-nav__item--child"
                :class="{ 'is-selected': containsActive(child) || panelItem?.id === child.id }"
                :aria-current="activeItem === child.id ? 'page' : undefined"
                :aria-expanded="hasChildren(child) ? panelItem?.id === child.id : undefined"
                :aria-controls="hasChildren(child) && panelItem?.id === child.id ? panelId : undefined"
                :data-parent-id="item.id"
                :data-child-id="child.id"
                :title="child.label"
                @click="activate(child, $event, true)"
                @keydown="handleKeydown($event, child, true)"
              >
                <span v-if="hasActivePage(child)" class="wb-side-nav__track" aria-hidden="true" />
                <span class="wb-side-nav__label">{{ child.label }}</span>
                <WorkbenchIcon class="wb-side-nav__arrow" name="/ic_arrow_right_line#2:141" />
              </button>
            </li>
          </ul>
        </Transition>
      </li>
    </ul>

    <WorkbenchButton
      v-if="collapsible"
      appearance="icon"
      icon-layout="container"
      size="32"
      class="wb-side-nav__collapse"
      :aria-label="collapsed ? '展开侧边导航' : '收起侧边导航'"
      :aria-expanded="!collapsed"
      @click="toggleNavigation"
    >
      <template #icon><WorkbenchIcon class="wb-side-nav__collapse-icon" :name="collapsed ? '导航/尺寸=20,类型=展开' : '导航/尺寸=20,类型=折叠'" /></template>
    </WorkbenchButton>
    <SideNavigationPanel v-if="panelItem && !collapsed" :id="panelId" :item="panelItem" :mode="panelMode" :density="panelDensity" :show-flyout-icons="showFlyoutIcons" :active-item="activeItem" :expand-all="panelExpandAll" @select="selectPanelItem" @close="closePanel" />
  </nav>
</template>

<style scoped>
.wb-side-nav {
  position: relative;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  inline-size: var(--side-navigation-width, var(--wb-asset-wb-side-navigation-expanded-width-medium));
  block-size: 100%;
  min-block-size: 0;
  flex-shrink: 0;
  color: var(--wb-color-text-primary);
  background: var(--wb-color-surface-container);
  font: var(--wb-font-body-m);
  transition: inline-size var(--wb-asset-wb-side-navigation-motion-duration) var(--wb-asset-wb-side-navigation-motion-easing);
}
.wb-side-nav.has-divider::after {
  position: absolute;
  z-index: 1;
  inset-block: 0;
  inset-inline-end: 0;
  inline-size: var(--wb-asset-wb-side-navigation-end-border-width);
  background: var(--wb-color-border-separator);
  content: '';
  pointer-events: none;
}
.wb-side-nav.is-size-wide { inline-size: var(--side-navigation-width, var(--wb-asset-wb-side-navigation-expanded-width-wide)); }
.wb-side-nav.is-size-ultrawide { inline-size: var(--side-navigation-width, var(--wb-asset-wb-side-navigation-expanded-width-ultrawide)); }
.wb-side-nav.is-size-undefined { inline-size: var(--side-navigation-width, var(--wb-asset-wb-side-navigation-expanded-width-fallback)); }
.wb-side-nav.is-collapsed { inline-size: var(--wb-asset-wb-side-navigation-collapsed-width); }
.wb-side-nav__list, .wb-side-nav__children { padding: 0; margin: 0; list-style: none; }
.wb-side-nav__children { transition: height var(--wb-asset-wb-side-navigation-motion-duration) var(--wb-asset-wb-side-navigation-motion-easing); }
.wb-side-nav__list { flex: 1; min-block-size: 0; overflow: auto; padding-block-start: var(--wb-asset-wb-side-navigation-first-item-offset); }
.wb-side-nav__header.has-title { block-size: auto; padding: 0 var(--wb-asset-wb-side-navigation-item-inline-padding) var(--wb-asset-wb-side-navigation-title-divider-gap); margin-block-end: var(--wb-asset-wb-side-navigation-divider-item-gap); border-block-end: var(--wb-asset-wb-side-navigation-end-border-width) solid var(--wb-color-border-separator); overflow: visible; }
.wb-side-nav__header.has-title + .wb-side-nav__list { padding-block-start: 0; }
.wb-side-nav__item {
  position: relative;
  box-sizing: border-box;
  display: flex;
  align-items: center;
  inline-size: 100%;
  block-size: var(--wb-asset-wb-side-navigation-item-height);
  padding-inline: var(--wb-asset-wb-side-navigation-item-inline-padding);
  border: 0;
  border-radius: 0;
  color: inherit;
  background: transparent;
  font: inherit;
  text-align: start;
  cursor: pointer;
}
.wb-side-nav__item.is-selected { background: var(--wb-color-fill-selected); }
.wb-side-nav__item:hover, .wb-side-nav__item:focus-visible { background: var(--wb-color-fill-hover); }
.wb-side-nav__item:focus-visible { outline: var(--wb-asset-wb-side-navigation-selected-track-width) solid var(--wb-color-border-focus); outline-offset: calc(0px - var(--wb-asset-wb-side-navigation-selected-track-width)); }
.wb-side-nav__icon {
  flex: 0 0 var(--wb-asset-wb-side-navigation-icon-size);
  color: var(--wb-color-icon-primary);
}
.wb-side-nav__label { min-inline-size: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.wb-side-nav.is-collapsed .wb-side-nav__item--parent.is-active-path .wb-side-nav__icon { color: var(--wb-color-brand); }
.wb-side-nav__item .wb-side-nav__label { flex: 1; }
.wb-side-nav__item--parent .wb-side-nav__icon + .wb-side-nav__label { margin-inline-start: var(--wb-asset-wb-side-navigation-icon-text-gap); }
.wb-side-nav__arrow {
  flex: 0 0 var(--wb-asset-wb-side-navigation-arrow-size);
  margin-inline-start: var(--wb-asset-wb-side-navigation-icon-text-gap);
  transition: transform var(--wb-asset-wb-side-navigation-motion-duration) var(--wb-asset-wb-side-navigation-motion-easing);
}
.wb-side-nav__arrow.is-expanded { transform: rotate(90deg); }
.wb-side-nav__item--child { position: relative; }
.wb-side-nav__item--child { padding-inline-start: calc(var(--wb-asset-wb-side-navigation-item-inline-padding) + var(--wb-asset-wb-side-navigation-icon-size) + var(--wb-asset-wb-side-navigation-icon-text-gap)); }
.wb-side-nav__track {
  position: absolute;
  inset-inline-start: 0;
  inset-block-start: 50%;
  inline-size: var(--wb-asset-wb-side-navigation-selected-track-width);
  block-size: var(--wb-asset-wb-side-navigation-selected-track-height);
  border-radius: var(--wb-radius-full);
  background: var(--wb-color-brand);
  transform: translateY(-50%);
}
.wb-side-nav__collapse {
  --button-icon-size: var(--wb-asset-wb-side-navigation-collapse-icon-size);

  flex: 0 0 auto;
  margin-block: auto calc(var(--wb-asset-wb-side-navigation-collapse-bottom-offset) - (var(--wb-asset-wb-button-height-32) - var(--wb-asset-wb-side-navigation-collapse-icon-size)) / 2);
  margin-inline-start: calc(var(--wb-asset-wb-side-navigation-collapse-inline-offset) - (var(--wb-asset-wb-button-height-32) - var(--wb-asset-wb-side-navigation-collapse-icon-size)) / 2);
}
.wb-side-nav__collapse-icon { transition: transform var(--wb-asset-wb-side-navigation-motion-duration) var(--wb-asset-wb-side-navigation-motion-easing); }
.wb-side-nav__collapse-icon.is-collapsed { transform: rotate(180deg); }
@media (prefers-reduced-motion: reduce) { .wb-side-nav, .wb-side-nav__children, .wb-side-nav__arrow, .wb-side-nav__collapse-icon { transition: none; } }
</style>

<style scoped>
.wb-side-nav__header { display: flex; align-items: center; flex: none; gap: var(--wb-asset-wb-side-navigation-icon-text-gap); block-size: var(--wb-asset-wb-side-navigation-item-height); padding-inline: var(--wb-asset-wb-side-navigation-header-padding); overflow: hidden; }
.wb-side-nav.is-collapsed .wb-side-nav__header { padding-inline: var(--wb-asset-wb-side-navigation-header-padding); }
</style>
