export const uploadStatuses = ['ready', 'uploading', 'paused', 'success', 'error'];

export function formatFileSize(bytes = 0) {
  if (bytes >= 1024 * 1024) return `${Number((bytes / 1024 / 1024).toFixed(1))}M`;
  if (bytes >= 1024) return `${Number((bytes / 1024).toFixed(1))}K`;
  return `${Math.max(0, bytes)}B`;
}

export function acceptsFile(file, accept = '') {
  if (!accept.trim()) return true;
  return accept.split(',').map(rule => rule.trim().toLowerCase()).filter(Boolean).some(rule => {
    if (rule.startsWith('.')) return file.name.toLowerCase().endsWith(rule);
    const mime = (file.type || '').toLowerCase();
    return rule.endsWith('/*') ? mime.startsWith(rule.slice(0, -1)) : mime === rule;
  });
}

export function progressOf(file) {
  return Number(Math.max(0, Math.min(100, Number(file.percentage) || 0)).toFixed(1));
}

export function normalizeUploadFile(file, id) {
  return {
    ...file, id: file.id ?? id, name: file.name || '未命名文件', size: Number(file.size) || 0,
    status: uploadStatuses.includes(file.status) ? file.status : 'ready',
    percentage: file.status === 'success' ? 100 : progressOf(file),
  };
}
