<script setup>
import UploadFileItem from './UploadFileItem.vue';
defineProps({ files: { type: Array, default: () => [] }, listType: { type: String, default: 'text' }, background: Boolean, disabled: Boolean, previewState: { type: String, default: 'default' }, label: { type: String, default: '附件列表' } });
defineEmits(['remove', 'retry', 'pause', 'resume', 'preview', 'download']);
</script>

<template>
  <ul class="upload-file-list" :data-list-type="listType" :aria-label="label">
    <UploadFileItem v-for="file in files" :key="file.id" :file="file" :list-type="listType" :background="background" :disabled="disabled" :preview-state="previewState" @remove="$emit('remove', $event)" @retry="$emit('retry', $event)" @pause="$emit('pause', $event)" @resume="$emit('resume', $event)" @preview="$emit('preview', $event)" @download="$emit('download', $event)" />
  </ul>
</template>

<style scoped>
.upload-file-list { display: flex; flex-direction: column; gap: var(--wb-asset-wb-upload-row-gap); padding: 0; margin: 0; list-style: none; min-width: 0; }
.upload-file-list[data-list-type="compact"] { gap: var(--wb-asset-wb-upload-compact-gap); }
</style>
