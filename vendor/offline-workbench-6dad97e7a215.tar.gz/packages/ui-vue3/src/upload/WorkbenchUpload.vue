<script setup>
import { useFormDisabled } from '../form/useFormDisabled.js';
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import { computed, markRaw, onBeforeUnmount, ref, useId, watch } from 'vue';
import WorkbenchButton from '../button/WorkbenchButton.vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import UploadFileList from './UploadFileList.vue';
import { acceptsFile, formatFileSize, normalizeUploadFile, progressOf } from './uploadModel.js';

const props = defineProps({
  modelValue: { type: Array, default: () => [] },
  mode: { type: String, default: 'click', validator: value => ['click', 'drag'].includes(value) },
  listType: { type: String, default: 'text', validator: value => ['text', 'compact', 'card'].includes(value) },
  accept: { type: String, default: '.doc,.xlsx,.pdf' },
  maxSize: { type: Number, default: 5 * 1024 * 1024 },
  limit: { type: Number, default: 0 },
  multiple: { type: Boolean, default: true },
  disabled: Boolean, background: Boolean,
  showTrigger: { type: Boolean, default: true },
  autoUpload: { type: Boolean, default: true },
  customRequest: { type: Function, default: undefined },
  beforeUpload: { type: Function, default: undefined },
  hint: { type: String, default: undefined },
  label: { type: String, default: '文件上传' },
  previewState: { type: String, default: 'default' },
});
const disabled = useFormDisabled(() => props.disabled);
const emit = defineEmits(['update:modelValue', 'change', 'select', 'progress', 'success', 'error', 'reject', 'remove', 'pause', 'resume', 'preview', 'download']);
const instanceId = useId();
let sequence = 0;
let alive = true;
const input = ref(null);
const files = ref([]);
const validationMessage = ref('');
const dragging = ref(false);
let dragDepth = 0;
const jobs = new Map();
const effectiveDisabled = computed(() => disabled.value || props.previewState === 'disabled');
const actualListType = computed(() => props.mode === 'drag' && props.listType === 'text' ? 'card' : props.listType);
const hintText = computed(() => props.hint ?? `${props.maxSize > 0 ? `不超过${formatFileSize(props.maxSize)}，` : ''}${props.accept ? `支持${props.accept.replaceAll('.', '').replaceAll(',', '、')}` : '支持所有文件格式'}`);

watch(() => props.modelValue, value => {
  const next = value.map(file => normalizeUploadFile(file, `${instanceId}-${++sequence}`));
  for (const id of jobs.keys()) if (!next.some(file => file.id === id)) abort(id);
  files.value = next;
}, { immediate: true });
watch(effectiveDisabled, value => { if (value) { dragging.value = false; dragDepth = 0; } });

function publish(next) {
  if (!alive) return;
  files.value = next;
  emit('update:modelValue', next);
  emit('change', next);
}
function update(id, patch) {
  const next = files.value.map(file => file.id === id ? { ...file, ...patch } : file);
  publish(next);
  return next.find(file => file.id === id);
}
function abort(id) {
  const job = jobs.get(id);
  jobs.delete(id);
  job?.controller.abort();
}
function reject(file, reason, message) {
  validationMessage.value = message;
  emit('reject', { file, reason, message });
}
function validFile(raw) {
  if (!acceptsFile(raw, props.accept)) { reject(raw, 'type', `${raw.name}：文件格式不支持`); return false; }
  if (props.maxSize > 0 && raw.size > props.maxSize) { reject(raw, 'size', `${raw.name}：文件大小不能超过${formatFileSize(props.maxSize)}`); return false; }
  return true;
}
async function passesBeforeUpload(raw, selected) {
  if (!props.beforeUpload) return true;
  try { return await props.beforeUpload(raw, selected) !== false; }
  catch { if (alive) reject(raw, 'before-upload', `${raw.name}：文件校验失败`); return false; }
}
async function selectFiles(source) {
  if (effectiveDisabled.value || !alive) return;
  validationMessage.value = '';
  const selected = Array.from(source ?? []);
  for (const raw of (props.multiple ? selected : selected.slice(0, 1))) {
    if (!alive || effectiveDisabled.value) break;
    if (!validFile(raw) || !await passesBeforeUpload(raw, selected)) continue;
    if (!alive || effectiveDisabled.value) break;
    if (props.limit > 0 && files.value.length >= props.limit) { reject(raw, 'limit', `最多上传${props.limit}个文件`); continue; }
    const record = normalizeUploadFile({ name: raw.name, size: raw.size, type: raw.type, raw: markRaw(raw), status: 'ready', percentage: 0 }, `${instanceId}-${++sequence}`);
    publish([...files.value, record]);
    emit('select', record);
    if (props.autoUpload && props.customRequest) void upload(record);
  }
}
async function upload(file) {
  const current = files.value.find(item => item.id === file.id);
  if (!alive || effectiveDisabled.value || !current || !props.customRequest || jobs.has(file.id)) return;
  const controller = new AbortController();
  const job = { controller };
  jobs.set(file.id, job);
  const isCurrent = () => alive && !controller.signal.aborted && jobs.get(file.id) === job && files.value.some(item => item.id === file.id);
  const resumed = current.status === 'paused';
  update(file.id, { status: 'uploading', error: '', percentage: resumed ? progressOf(current) : 0 });
  try {
    const result = await props.customRequest({
      file: current.raw, record: current, signal: controller.signal,
      loaded: resumed ? current.size * progressOf(current) / 100 : 0,
      onProgress(progress) {
        if (!isCurrent()) return;
        const percentage = typeof progress === 'number' ? progress : progress?.total > 0 ? progress.loaded / progress.total * 100 : 0;
        const record = update(file.id, { percentage: Math.max(0, Math.min(100, Number(percentage) || 0)) });
        emit('progress', record);
      },
    });
    if (!isCurrent()) return;
    // The transport owns its response. Never let it overwrite record identity or local File.
    const record = update(file.id, { status: 'success', percentage: 100, response: result, ...(result?.url ? { url: result.url } : {}) });
    emit('success', record, result);
  } catch (error) {
    if (!isCurrent()) return;
    const record = update(file.id, { status: 'error', error: '上传失败' });
    emit('error', error, record);
  } finally { if (jobs.get(file.id) === job) jobs.delete(file.id); }
}
function remove(file) {
  if (effectiveDisabled.value) return;
  abort(file.id);
  publish(files.value.filter(item => item.id !== file.id));
  emit('remove', file);
}
function pause(file) {
  if (effectiveDisabled.value || file.status !== 'uploading') return;
  abort(file.id);
  const record = update(file.id, { status: 'paused' });
  emit('pause', record);
}
function resume(file) {
  if (effectiveDisabled.value) return;
  emit('resume', file);
  void upload(file);
}
function retry(file) {
  if (effectiveDisabled.value) return;
  abort(file.id);
  void upload(file);
}
function onInput(event) { void selectFiles(event.target.files); event.target.value = ''; }
function choose() { if (!effectiveDisabled.value) input.value?.click(); }
function enter(event) {
  if (effectiveDisabled.value || !Array.from(event.dataTransfer?.types ?? []).includes('Files')) return;
  dragDepth += 1; dragging.value = true;
}
function leave() { dragDepth = Math.max(0, dragDepth - 1); if (!dragDepth) dragging.value = false; }
function drop(event) { dragging.value = false; dragDepth = 0; void selectFiles(event.dataTransfer?.files); }
function submit() { if (!effectiveDisabled.value) return Promise.all(files.value.filter(file => ['ready', 'error'].includes(file.status)).map(upload)); }
onBeforeUnmount(() => { alive = false; for (const id of [...jobs.keys()]) abort(id); });
defineExpose({ selectFiles, submit, pause, resume, retry, remove });
</script>

<template>
  <section class="workbench-upload" :data-mode="mode" :data-disabled="effectiveDisabled" :aria-label="label">
    <input ref="input" class="workbench-upload__input" type="file" :accept="accept" :multiple="multiple" :disabled="effectiveDisabled" :aria-label="`选择${label}文件`" tabindex="-1" @change="onInput" />
    <template v-if="showTrigger">
      <button v-if="mode === 'drag'" class="workbench-upload__drop" :data-state="dragging ? 'active' : previewState" type="button" :disabled="effectiveDisabled" :aria-label="`拖拽或单击${label}`" @click="choose" @dragenter.prevent="enter" @dragleave.prevent="leave" @dragover.prevent @drop.prevent="drop">
        <WorkbenchIcon class="workbench-upload__plus" name="/ic_public_plus_line_20px" />
        <span class="workbench-upload__drop-text">将文件拖到此处或<span class="workbench-upload__link">单击上传</span></span>
        <span class="workbench-upload__hint">{{ hintText }}</span>
      </button>
      <div v-else class="workbench-upload__trigger">
        <WorkbenchButton appearance="secondary" :disabled="effectiveDisabled" @click="choose"><template #icon><WorkbenchIcon name="/ic_public_plus_line_14px" /></template>文件上传</WorkbenchButton>
        <span class="workbench-upload__hint">{{ hintText }}</span>
      </div>
    </template>
    <p v-if="validationMessage" class="workbench-upload__validation" role="alert">{{ validationMessage }}</p>
    <div v-if="mode === 'click'" class="workbench-upload__attachments">
      <span class="workbench-upload__divider" aria-hidden="true"></span>
    </div>
    <UploadFileList v-if="files.length" :files="files" :list-type="actualListType" :background="background" :disabled="effectiveDisabled" :preview-state="previewState" :label="`${label}附件列表`" @remove="remove" @retry="retry" @pause="pause" @resume="resume" @preview="$emit('preview', $event)" @download="$emit('download', $event)" />
    <p v-else-if="mode === 'click' || !showTrigger" class="workbench-upload__empty">暂无附件</p>
    <span class="workbench-upload__announcement" aria-live="polite" aria-atomic="true">{{ files.filter(file => file.status === 'uploading').length }}个文件上传中，{{ files.filter(file => file.status === 'success').length }}个上传成功，{{ files.filter(file => file.status === 'error').length }}个上传失败</span>
  </section>
</template>

<style scoped>
.workbench-upload { width: var(--wb-asset-wb-upload-width); max-width: 100%; min-width: 0; display: flex; flex-direction: column; gap: var(--wb-asset-wb-upload-list-gap); color: var(--wb-color-text-primary);     font-size: var(--wb-font-body-m-font-size); font-weight: var(--wb-font-body-m-font-weight); line-height: var(--wb-font-body-m-line-height); letter-spacing: var(--wb-font-body-m-letter-spacing); }
.workbench-upload__input { display: none; }
.workbench-upload[data-mode="click"] { gap: 0; }
.workbench-upload[data-mode="click"] .workbench-upload__attachments { margin-top: var(--wb-spacing-component-md); margin-bottom: var(--wb-spacing-component-xs); }
.workbench-upload__divider { display: block; height: var(--wb-asset-wb-upload-divider-thickness); background: repeating-linear-gradient(to right, var(--wb-color-border-separator) 0 var(--wb-asset-wb-upload-divider-dash), transparent var(--wb-asset-wb-upload-divider-dash) calc(var(--wb-asset-wb-upload-divider-dash) * 2)); }
.workbench-upload__trigger { display: flex; flex-wrap: wrap; gap: var(--wb-asset-wb-upload-list-gap); align-items: center; min-height: var(--wb-asset-wb-upload-trigger-height); }
.workbench-upload__trigger :deep(.wb-button) { flex: none; }
.workbench-upload__hint { color: var(--wb-color-text-secondary);    font-size: var(--wb-font-body-s-font-size); font-weight: var(--wb-font-body-s-font-weight); line-height: var(--wb-font-body-s-line-height); letter-spacing: var(--wb-font-body-s-letter-spacing); }
.workbench-upload__drop { box-sizing: border-box; position: relative; display: flex; flex-direction: column; align-items: center; justify-content: flex-start; width: 100%; height: var(--wb-asset-wb-upload-drop-height); border: 1px dashed var(--wb-color-border); border-radius: var(--wb-radius-sm); background: var(--wb-color-fill-hover); padding: var(--wb-asset-wb-upload-drop-top) var(--wb-asset-wb-upload-card-padding) 0; font: inherit; color: inherit; cursor: pointer; flex: none; }
.workbench-upload__plus { margin-bottom: var(--wb-asset-wb-upload-list-gap); }
.workbench-upload__drop-text { white-space: nowrap;   font-size: var(--wb-font-body-m-font-size); font-weight: var(--wb-font-body-m-font-weight); line-height: var(--wb-font-body-m-line-height); letter-spacing: var(--wb-font-body-m-letter-spacing); }
.workbench-upload__drop .workbench-upload__hint { margin-top: var(--wb-asset-wb-upload-compact-gap); }
.workbench-upload__link { color: var(--wb-color-text-action); }
.workbench-upload__drop:hover, .workbench-upload__drop[data-state="hover"] { border-color: var(--wb-color-text-primary); }
.workbench-upload__drop:focus-visible, .workbench-upload__drop[data-state="active"] { border: 1px solid var(--wb-color-text-primary); background: var(--wb-color-surface-container); outline: none; }
.workbench-upload__drop:disabled { cursor: not-allowed; color: var(--wb-color-text-disabled); border-color: var(--wb-color-border); }
.workbench-upload[data-disabled="true"] .workbench-upload__link { color: var(--wb-color-text-disabled); }
.workbench-upload__empty { margin: 0;   color: var(--wb-color-text-secondary);  font-size: var(--wb-font-body-s-font-size); font-weight: var(--wb-font-body-s-font-weight); line-height: var(--wb-font-body-s-line-height); letter-spacing: var(--wb-font-body-s-letter-spacing); }
.workbench-upload__validation { color: var(--wb-color-error); margin: 0;    font-size: var(--wb-font-body-s-font-size); font-weight: var(--wb-font-body-s-font-weight); line-height: var(--wb-font-body-s-line-height); letter-spacing: var(--wb-font-body-s-letter-spacing); }
.workbench-upload__announcement { position: absolute; width: 0; height: 0; overflow: hidden; clip-path: inset(50%); }
</style>
