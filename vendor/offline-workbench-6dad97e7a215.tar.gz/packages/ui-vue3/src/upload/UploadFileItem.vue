<script setup>
import { computed } from 'vue';
import WorkbenchFileIcon from '../icons/file/WorkbenchFileIcon.vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import { formatFileSize, progressOf } from './uploadModel.js';

const props = defineProps({
  file: { type: Object, required: true },
  listType: { type: String, default: 'text' },
  background: Boolean,
  disabled: Boolean,
  previewState: { type: String, default: 'default' },
});
defineEmits(['remove', 'retry', 'pause', 'resume', 'preview', 'download']);
const percent = computed(() => progressOf(props.file));
const active = computed(() => ['uploading', 'paused'].includes(props.file.status));
const compact = computed(() => props.listType === 'compact');
const card = computed(() => props.listType === 'card');
const error = computed(() => props.file.status === 'error');
const sizeText = computed(() =>
  active.value || (card.value && error.value)
    ? `${formatFileSize((props.file.size * percent.value) / 100)}/${formatFileSize(props.file.size)}`
    : formatFileSize(props.file.size),
);
</script>

<template>
  <li
    class="upload-file"
    :class="{
      'upload-file--card': card,
      'upload-file--compact': compact,
      'upload-file--background': background,
    }"
    :data-status="file.status"
    :data-disabled="disabled"
    :data-preview-state="previewState"
    :data-file-id="file.id"
    :tabindex="compact && active && !disabled ? 0 : undefined"
    :aria-label="`${file.name}，${{ ready: '待上传', uploading: '上传中', paused: '已暂停', success: '上传成功', error: '上传失败' }[file.status]}`"
  >
    <div
      v-if="card"
      class="upload-file__card-surface"
      aria-hidden="true"
    />
    <div class="upload-file__content">
      <WorkbenchIcon
        v-if="compact"
        name="/ic_public_link_line_14px"
      />
      <WorkbenchFileIcon
        v-else
        :filename="file.name"
        :type="error ? 'unknown' : ''"
        :size="card ? 48 : 32"
      />
      <div class="upload-file__copy">
        <div class="upload-file__title-row">
          <button
            class="upload-file__name"
            type="button"
            :title="file.name"
            :disabled="disabled || file.status !== 'success'"
            @click="$emit('preview', file)"
          >
            {{ file.name }}
          </button>
          <div
            class="upload-file__actions"
            :class="{ 'upload-file__actions--on-hover': file.status === 'success' }"
          >
            <template v-if="active">
              <button
                type="button"
                :disabled="disabled"
                :aria-label="`${file.status === 'paused' ? '继续' : '暂停'} ${file.name}`"
                @click="$emit(file.status === 'paused' ? 'resume' : 'pause', file)"
              >
                {{ file.status === 'paused' ? '继续' : '暂停' }}
              </button>
              <button
                type="button"
                :disabled="disabled"
                :aria-label="`${card ? '取消' : '删除'} ${file.name}`"
                @click="$emit('remove', file)"
              >
                {{ card ? '取消' : '删除' }}
              </button>
            </template>
            <template v-else-if="error">
              <button
                type="button"
                :disabled="disabled"
                :aria-label="`重新上传 ${file.name}`"
                @click="$emit('retry', file)"
              >
                <WorkbenchIcon
                  v-if="compact"
                  name="刷新_14px"
                /><template v-else>重新上传</template>
              </button>
              <button
                type="button"
                :disabled="disabled"
                :aria-label="`删除 ${file.name}`"
                @click="$emit('remove', file)"
              >
                <WorkbenchIcon
                  v-if="compact"
                  name="/ic_public_trash_line_14px"
                /><template v-else>删除</template>
              </button>
            </template>
            <template v-else-if="file.status === 'success'">
              <button
                v-if="!compact"
                type="button"
                :disabled="disabled"
                :aria-label="`预览 ${file.name}`"
                @click="$emit('preview', file)"
              >
                预览
              </button>
              <button
                v-if="compact"
                type="button"
                :disabled="disabled"
                :aria-label="`重新上传 ${file.name}`"
                @click="$emit('retry', file)"
              >
                <WorkbenchIcon name="刷新_14px" />
              </button>
              <button
                v-else
                type="button"
                :disabled="disabled"
                :aria-label="`下载 ${file.name}`"
                @click="$emit('download', file)"
              >
                下载
              </button>
              <button
                type="button"
                :disabled="disabled"
                :aria-label="`删除 ${file.name}`"
                @click="$emit('remove', file)"
              >
                <WorkbenchIcon
                  v-if="compact"
                  name="/ic_public_trash_line_14px"
                /><template v-else>删除</template>
              </button>
            </template>
            <button
              v-else
              type="button"
              :disabled="disabled"
              :aria-label="`删除 ${file.name}`"
              @click="$emit('remove', file)"
            >
              删除
            </button>
          </div>
        </div>
        <div
          v-if="(card || compact) && (active || error || (card && file.status === 'success'))"
          class="upload-file__progress-row"
        >
          <progress
            class="upload-file__track"
            :value="percent"
            max="100"
            :aria-label="`${file.name} 上传进度`"
            :aria-valuenow="percent"
            aria-valuemin="0"
            aria-valuemax="100"
          >
            {{ percent }}%
          </progress>
          <span
            v-if="!compact || !error"
            class="upload-file__percent"
            >{{ percent }}%</span
          >
        </div>
        <div
          v-if="!compact"
          class="upload-file__meta"
        >
          <span
            v-if="error"
            class="upload-file__error"
            >{{ file.error || '上传失败' }}</span
          >
          <span v-else
            >{{ sizeText }}<template v-if="!card && active">，{{ percent }}%</template
            ><template v-if="file.status === 'paused'">（已暂停）</template></span
          >
          <span
            v-if="!card && (file.author || file.date)"
            class="upload-file__attribution"
            ><span>{{ file.author }}</span
            ><span>{{ file.date }}</span></span
          >
        </div>
        <span
          v-if="compact && error"
          class="upload-file__sr-only"
          role="status"
          >上传失败</span
        >
      </div>
    </div>
  </li>
</template>

<style scoped>
.upload-file {
  box-sizing: border-box;
  position: relative;
  width: 100%;
  min-width: 0;
  height: var(--wb-asset-wb-upload-row-height);
  border: 0;
  box-shadow: var(--wb-asset-wb-upload-row-stroke);
  border-radius: var(--wb-radius-sm);
  padding: var(--wb-asset-wb-upload-row-padding-block) var(--wb-asset-wb-upload-row-padding-inline);
  list-style: none;
  color: var(--wb-color-text-primary);
}
.upload-file:not(.upload-file--card):not(.upload-file--compact):not([data-disabled='true']):is(
    :hover,
    :focus-within,
    [data-preview-state='hover']
  ) {
  box-shadow: var(--wb-asset-wb-upload-row-hover-stroke);
}
.upload-file__content {
  position: relative;
  display: flex;
  align-items: center;
  gap: var(--wb-asset-wb-upload-icon-gap);
  min-width: 0;
  height: 100%;
}
.upload-file__copy {
  min-width: 0;
  flex: 1;
}
.upload-file__title-row {
  display: flex;
  align-items: center;
  gap: var(--wb-asset-wb-upload-title-gap);
  height: var(--wb-asset-wb-upload-title-height);
}
.upload-file button {
  font: inherit;
  background: transparent;
  border: 0;
  padding: 0;
  margin: 0;
  cursor: pointer;
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
}
.upload-file button:focus-visible {
  outline: 1px solid var(--wb-color-border-focus);
  outline-offset: 2px;
}
.upload-file button:disabled {
  cursor: default;
}
.upload-file__name {
  min-width: 0;
  flex: 1;
  color: inherit;
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
  text-align: left;
}
.upload-file__actions {
  display: flex;
  gap: var(--wb-asset-wb-upload-action-gap);
  flex: none;
  color: var(--wb-color-text-action);
}
.upload-file__actions button {
  display: inline-flex;
  align-items: center;
  color: var(--wb-color-text-action);
}
.upload-file__actions--on-hover {
  visibility: hidden;
}
.upload-file:hover .upload-file__actions,
.upload-file:focus-within .upload-file__actions,
.upload-file[data-preview-state='hover'] .upload-file__actions {
  visibility: visible;
}
.upload-file__actions button:disabled {
  color: var(--wb-color-text-disabled);
}
.upload-file__meta {
  display: flex;
  justify-content: space-between;
  gap: var(--wb-asset-wb-upload-action-gap);
  color: var(--wb-color-text-secondary);
  white-space: nowrap;
  font-size: var(--wb-font-body-s-font-size);
  font-weight: var(--wb-font-body-s-font-weight);
  line-height: var(--wb-font-body-s-line-height);
  letter-spacing: var(--wb-font-body-s-letter-spacing);
}
.upload-file__meta > :first-child {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.upload-file__attribution {
  display: inline-flex;
  flex: none;
  gap: var(--wb-asset-wb-upload-action-gap);
}
.upload-file__error {
  color: var(--wb-color-error);
}
.upload-file--card {
  display: flex;
  align-items: center;
  height: var(--wb-asset-wb-upload-drop-height);
  background: var(--wb-asset-wb-upload-card-bg);
  box-shadow: none;
  padding: var(--wb-asset-wb-upload-card-padding);
}
.upload-file--card::before {
  content: '';
  box-sizing: border-box;
  position: absolute;
  inset: 0;
  border: 1px dashed var(--wb-color-border);
  border-radius: var(--wb-asset-wb-upload-track-height);
  pointer-events: none;
}
.upload-file--card:not([data-disabled='true']):is(
    :hover,
    :focus-within,
    [data-preview-state='hover']
  )::before {
  border-color: var(--wb-color-border-hover);
}
.upload-file__card-surface {
  position: absolute;
  inset: var(--wb-asset-wb-upload-card-inset);
  background: var(--wb-color-surface-container);
  border-radius: var(--wb-radius-sm);
}
.upload-file--card .upload-file__content {
  width: calc(100% - var(--wb-asset-wb-upload-card-inset));
  height: auto;
  align-items: flex-start;
  gap: var(--wb-asset-wb-upload-action-gap);
}
.upload-file--card .upload-file__copy {
  flex: 1;
}
.upload-file--card .upload-file__title-row {
  padding-right: var(--wb-asset-wb-upload-percent-space);
}
.upload-file__progress-row {
  display: flex;
  align-items: center;
  gap: var(--wb-asset-wb-upload-action-gap);
  height: var(--wb-asset-wb-upload-title-height);
}
.upload-file--card .upload-file__progress-row {
  margin-top: var(--wb-asset-wb-upload-progress-gap);
}
.upload-file__track {
  appearance: none;
  display: block;
  min-width: 0;
  width: 0;
  flex: 1;
  height: var(--wb-asset-wb-upload-track-height);
  border: 0;
  background: var(--wb-asset-wb-upload-track-bg);
  border-radius: var(--wb-asset-wb-upload-track-height);
  overflow: hidden;
}
.upload-file__track::-webkit-progress-bar {
  background: var(--wb-asset-wb-upload-track-bg);
  border-radius: var(--wb-asset-wb-upload-track-height);
}
.upload-file__track::-webkit-progress-value {
  background: var(--wb-color-text-primary);
  border-radius: var(--wb-asset-wb-upload-track-height);
}
.upload-file__track::-moz-progress-bar {
  background: var(--wb-color-text-primary);
  border-radius: var(--wb-asset-wb-upload-track-height);
}
.upload-file[data-status='success'] .upload-file__track::-webkit-progress-value,
.upload-file--compact .upload-file__track::-webkit-progress-value {
  background: var(--wb-color-success);
}
.upload-file[data-status='success'] .upload-file__track::-moz-progress-bar,
.upload-file--compact .upload-file__track::-moz-progress-bar {
  background: var(--wb-color-success);
}
.upload-file[data-status='error'] .upload-file__track::-webkit-progress-value {
  background: var(--wb-color-error);
}
.upload-file[data-status='error'] .upload-file__track::-moz-progress-bar {
  background: var(--wb-color-error);
}
.upload-file__percent {
  flex: none;
}
.upload-file--compact {
  height: var(--wb-asset-wb-upload-compact-height);
  border: 0;
  box-shadow: none;
  padding: var(--wb-asset-wb-upload-compact-padding-block)
    var(--wb-asset-wb-upload-compact-padding-inline);
}
.upload-file--compact .upload-file__content {
  gap: var(--wb-asset-wb-upload-compact-gap);
}
.upload-file--compact:hover,
.upload-file--compact:focus-within,
.upload-file--compact[data-preview-state='hover'],
.upload-file--background {
  background: var(--wb-color-fill-hover);
}
.upload-file--compact .upload-file__progress-row {
  position: absolute;
  left: var(--wb-asset-wb-upload-compact-progress-left);
  right: 0;
  bottom: 0;
  height: var(--wb-asset-wb-upload-compact-track-height);
}
.upload-file--compact .upload-file__track {
  height: 100%;
  border-radius: 0;
}
.upload-file--compact .upload-file__percent {
  position: absolute;
  right: 0;
  bottom: var(--wb-asset-wb-upload-compact-percent-bottom);
}
.upload-file--compact[data-status='uploading'] .upload-file__actions {
  visibility: hidden;
}
.upload-file--compact[data-status='uploading']:hover .upload-file__actions,
.upload-file--compact[data-status='uploading']:focus-within .upload-file__actions {
  visibility: visible;
}
.upload-file--compact[data-status='uploading']:hover .upload-file__percent,
.upload-file--compact[data-status='uploading']:focus-within .upload-file__percent {
  visibility: hidden;
}
.upload-file__sr-only {
  position: absolute;
  width: 0;
  height: 0;
  overflow: hidden;
  clip-path: inset(50%);
}
@media (hover: none) {
  .upload-file__actions--on-hover {
    visibility: visible;
  }
}
</style>
