export const emptyStateTypes = [
  { type: 'no-data', label: '暂无数据' },
  { type: 'no-results', label: '搜索无结果' },
  { type: 'network-error', label: '网络异常' },
  { type: 'load-failed', label: '加载失败' },
  { type: 'forbidden', label: '无权限' },
  { type: 'removed', label: '内容已下架' },
  { type: 'expired', label: '内容已失效' },
  { type: 'coming-soon', label: '敬请期待' },
];

export const emptyStateContent = {
  'zh-CN': {
    'no-data': '暂无数据',
    'no-results': '搜索无结果，换个关键词试试吧',
    'network-error': '网络异常，',
    'load-failed': '加载失败，',
    forbidden: '对不起，您当前暂无权限查看',
    removed: '内容已下架，看看其他内容吧',
    expired: '内容已失效，看看其他内容吧',
    'coming-soon': '更多功能即将上线',
    retry: '点击刷新重试',
  },
  'en-US': {
    'no-data': 'No data available',
    'no-results': 'No results found, Try another keyword',
    'network-error': 'Network abnormality, ',
    'load-failed': 'Loading failed, ',
    forbidden: 'Sorry, you do not have the permission',
    removed: 'The content has been removed',
    expired: 'The content has expired',
    'coming-soon': 'The function is about to be launched',
    retry: 'Click Refresh and try again',
  },
};
