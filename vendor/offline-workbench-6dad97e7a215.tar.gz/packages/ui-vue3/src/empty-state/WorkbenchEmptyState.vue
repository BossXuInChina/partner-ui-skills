<script setup>
import { computed } from 'vue';
import WorkbenchButton from '../button/WorkbenchButton.vue';
import WorkbenchEmptyIcon from '../icons/empty/WorkbenchEmptyIcon.vue';
import { emptyStateContent } from './emptyStateContent.js';
import '../../../../catalog/generated/asset.tokens.css';

const props = defineProps({
  type: {
    type: String,
    default: 'no-data',
    validator: (value) =>
      [
        'no-data',
        'no-results',
        'network-error',
        'load-failed',
        'forbidden',
        'removed',
        'expired',
        'coming-soon',
      ].includes(value),
  },
  level: {
    type: String,
    default: 'card',
    validator: (value) => ['local', 'card', 'page'].includes(value),
  },
  size: {
    type: String,
    default: 'auto',
    validator: (value) => ['auto', 'small', 'default', 'large'].includes(value),
  },
  locale: {
    type: String,
    default: 'zh-CN',
    validator: (value) => ['zh-CN', 'en-US'].includes(value),
  },
  title: { type: String, default: '' },
  description: { type: String, default: undefined },
  primaryText: { type: String, default: '' },
  secondaryText: { type: String, default: '' },
  retry: { type: Boolean, default: true },
  busy: { type: Boolean, default: false },
  live: { type: String, default: 'off', validator: (value) => ['off', 'polite'].includes(value) },
});
const emit = defineEmits(['retry', 'primary', 'secondary']);
const content = computed(() => emptyStateContent[props.locale] ?? emptyStateContent['zh-CN']);
const resolvedSize = computed(() =>
  props.size === 'auto' ? (props.level === 'page' ? 'large' : 'default') : props.size,
);
const iconSize = computed(() => ({ small: 64, default: 120, large: 240 })[resolvedSize.value]);
const buttonSize = computed(
  () => ({ small: '28', default: '32', large: '36' })[resolvedSize.value],
);
const retryable = computed(() => ['network-error', 'load-failed'].includes(props.type));
const descriptionText = computed(() => {
  if (props.description !== undefined) return props.description;
  const value = content.value[props.type] ?? content.value['no-data'];
  return retryable.value && !props.retry ? value.replace(/[，,]\s*$/, '') : value;
});
</script>

<template>
  <div
    class="wb-empty-state"
    :data-level="level"
    :data-size="resolvedSize"
    :data-empty-type="type"
    :role="live === 'polite' ? 'status' : undefined"
    :aria-live="live"
    :aria-busy="busy || undefined"
  >
    <template v-if="level !== 'local'">
      <div
        class="wb-empty-state__illustration"
        aria-hidden="true"
      >
        <slot
          name="illustration"
          :type="type"
          :size="iconSize"
        >
          <WorkbenchEmptyIcon
            :type="type"
            :size="iconSize"
          />
        </slot>
      </div>
      <p
        v-if="title || $slots.title"
        class="wb-empty-state__title"
      >
        <slot name="title">{{ title }}</slot>
      </p>
    </template>
    <p
      v-if="descriptionText || $slots.description"
      class="wb-empty-state__description"
    >
      <slot
        name="description"
        :type="type"
      >
        {{ descriptionText
        }}<button
          v-if="retryable && retry && description === undefined"
          class="wb-empty-state__retry"
          type="button"
          :disabled="busy"
          @click="emit('retry', type)"
        >
          {{ content.retry }}
        </button>
      </slot>
    </p>
    <div
      v-if="level !== 'local' && (primaryText || secondaryText || $slots.actions)"
      class="wb-empty-state__actions"
    >
      <slot
        name="actions"
        :size="buttonSize"
        :busy="busy"
      >
        <WorkbenchButton
          v-if="secondaryText"
          appearance="secondary"
          :size="buttonSize"
          :disabled="busy"
          @click="emit('secondary', $event)"
          >{{ secondaryText }}</WorkbenchButton
        >
        <WorkbenchButton
          v-if="primaryText"
          :size="buttonSize"
          :disabled="busy"
          @click="emit('primary', $event)"
          >{{ primaryText }}</WorkbenchButton
        >
      </slot>
    </div>
  </div>
</template>

<style scoped>
.wb-empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  min-width: 0;
  max-width: 100%;
  color: var(--wb-color-text-secondary);
  text-align: center;
  font-size: var(--wb-font-body-s-font-size);
  font-weight: var(--wb-font-body-s-font-weight);
  line-height: var(--wb-font-body-s-line-height);
  letter-spacing: var(--wb-font-body-s-letter-spacing);
}
.wb-empty-state[data-size='large']:not([data-level='local']) {
  font-size: var(--wb-font-body-m-font-size);
  line-height: var(--wb-font-body-m-line-height);
  font-weight: var(--wb-font-body-m-font-weight);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
}
.wb-empty-state__illustration {
  display: flex;
  justify-content: center;
  flex: none;
}
.wb-empty-state__title,
.wb-empty-state__description {
  margin: 0;
  max-width: 100%;
  overflow-wrap: anywhere;
  white-space: pre-line;
}
.wb-empty-state__title {
  color: var(--wb-color-text-primary);
  font-size: var(--wb-font-headline-xs-font-size);
  font-weight: var(--wb-font-headline-xs-font-weight);
  line-height: var(--wb-font-headline-xs-line-height);
  letter-spacing: var(--wb-font-headline-xs-letter-spacing);
}
.wb-empty-state[data-size='large'] .wb-empty-state__title {
  font-size: var(--wb-font-headline-s-font-size);
  line-height: var(--wb-font-headline-s-line-height);
  font-weight: var(--wb-font-headline-s-font-weight);
  letter-spacing: var(--wb-font-headline-s-letter-spacing);
}
.wb-empty-state__retry {
  display: inline;
  margin: 0;
  border: 0;
  padding: 0;
  background: transparent;
  color: var(--wb-color-text-action);
  font: inherit;
  cursor: pointer;
}
.wb-empty-state__retry:disabled {
  color: var(--wb-color-text-disabled);
  cursor: default;
}
.wb-empty-state__retry:focus-visible {
  outline: var(--wb-asset-wb-empty-state-focus-width) solid
    var(--wb-color-border-focus);
  outline-offset: var(--wb-asset-wb-empty-state-focus-offset);
}
.wb-empty-state__actions {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: var(--wb-asset-wb-empty-state-action-gap);
  max-width: 100%;
  margin-top: var(--wb-asset-wb-empty-state-default-action-space);
}
.wb-empty-state[data-size='small'] .wb-empty-state__actions {
  margin-top: var(--wb-asset-wb-empty-state-small-action-space);
}
.wb-empty-state[data-size='large'] .wb-empty-state__actions {
  margin-top: var(--wb-asset-wb-empty-state-large-action-space);
}
</style>
