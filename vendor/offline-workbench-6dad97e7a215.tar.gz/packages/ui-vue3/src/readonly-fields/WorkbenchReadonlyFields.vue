<script setup>
import { computed, onMounted, onBeforeUnmount, ref, useId } from 'vue';
import WorkbenchForm from '../form/WorkbenchForm.vue';
import WorkbenchFormItem from '../form/WorkbenchFormItem.vue';
import WorkbenchButton from '../button/WorkbenchButton.vue';
import WorkbenchTag from '../tag/WorkbenchTag.vue';
const props = defineProps({
  title: { type: String, required: true },
  titleVisible: { type: Boolean, default: false },
  model: { type: Object, required: true },
  fields: { type: Array, required: true },
  columns: { type: Number, default: 3 },
  labelPosition: { type: String, default: 'left' },
  labelWidth: { type: String, default: '224px' },
  density: { type: String, default: 'compact' },
});
const emit = defineEmits(['copy']);
const copyLabelPrefix = `readonly-copy-${useId()}`;
const root = ref(null);
const width = ref(0);
let observer;
onMounted(() => {
  observer = new ResizeObserver(([entry]) => {
    width.value = entry.contentRect.width;
  });
  observer.observe(root.value);
});
onBeforeUnmount(() => observer?.disconnect());
const values = computed(() =>
  Object.fromEntries(
    props.fields.map((field) => [
      field.key,
      Object.hasOwn(field, 'value') ? field.value : props.model[field.key],
    ]),
  ),
);
const activeColumns = computed(() =>
  Math.min(
    Math.max(1, Math.min(4, props.columns || 1)),
    width.value < 656 ? 1 : width.value < 968 ? 2 : width.value < 1280 ? 3 : 4,
  ),
);
// Explicit field spans use Form's public 12-unit grid; the outer wrapper only
// selects the matching span for the currently available container width.
function sizeFor(field) {
  if (activeColumns.value === 1) return '';
  if (field.size) return field.size;
  if (activeColumns.value === 2) return 'm';
  if (activeColumns.value === 3) return 'base';
  return field.size || '';
}
</script>

<template>
  <div
    ref="root"
    class="readonly-fields"
    data-readonly-fields
  >
    <WorkbenchForm
      :title="title"
      :title-visible="titleVisible"
      :model="values"
      mode="readonly"
      :density="density"
      :label-position="labelPosition"
      :label-width="width < 656 ? '96px' : labelWidth"
    >
      <WorkbenchFormItem
        v-for="field in fields"
        :key="field.key"
        :prop="field.key"
        :label="
          labelPosition === 'left' && !/[：:]$/.test(field.label) ? `${field.label}：` : field.label
        "
        :size="sizeFor(field)"
        :formatter="field.format"
        :class="[
          field.class,
          {
            'transaction-copy-field': field.copy,
            'readonly-fields__full-row': activeColumns === 1,
          },
        ]"
        :data-field-key="field.key"
      >
        <template #readonly="{ value, displayValue }">
          <slot
            :name="`value-${field.key}`"
            :value="value"
            :display-value="displayValue"
            :field="field"
          >
            <span
              v-if="field.tone"
              class="transaction-field-status"
              ><WorkbenchTag
                :label="String(displayValue)"
                variant="status-subtle"
                :status="field.tone"
            /></span>
            <span
              v-else
              class="transaction-field-value"
              >{{ displayValue }}</span
            >
          </slot>
        </template>
        <template
          v-if="field.copy"
          #readonly-actions="{ value }"
          ><span
            :id="`${copyLabelPrefix}-${field.key}`"
            hidden
            >复制{{ field.label }}</span
          ><WorkbenchButton
            appearance="text"
            text-layout="inline"
            size="28"
            :aria-labelledby="`${copyLabelPrefix}-${field.key}`"
            @click="emit('copy', { value, label: field.label, key: field.key })"
            >复制</WorkbenchButton
          ></template
        >
      </WorkbenchFormItem>
    </WorkbenchForm>
  </div>
</template>

<style scoped>
.readonly-fields__full-row {
  grid-column: 1 / -1;
}
.readonly-fields {
  min-width: 0;
}
.transaction-field-value {
  user-select: text;
}
.transaction-field-status {
  display: inline-flex;
  align-items: center;
  block-size: var(--wb-font-body-m-line-height);
  vertical-align: top;
}
</style>
