<script setup>
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import { computed, nextTick, onBeforeUnmount, onMounted, ref, useId, watch } from 'vue';
import { focusableElementsIn } from '../overlay/isolation.js';
import WorkbenchButton from '../button/WorkbenchButton.vue';

const placements = [
  'top-start',
  'top',
  'top-end',
  'right-start',
  'right',
  'right-end',
  'bottom-start',
  'bottom',
  'bottom-end',
  'left-start',
  'left',
  'left-end',
];
const opposite = { top: 'bottom', bottom: 'top', left: 'right', right: 'left' };
const props = defineProps({
  placement: {
    type: String,
    default: 'top',
    validator: (value) =>
      [
        'top-start',
        'top',
        'top-end',
        'right-start',
        'right',
        'right-end',
        'bottom-start',
        'bottom',
        'bottom-end',
        'left-start',
        'left',
        'left-end',
      ].includes(value),
  },
  open: { type: Boolean, default: undefined },
  disabled: Boolean,
  type: {
    type: String,
    default: 'info',
    validator: (value) => ['info', 'warning', 'danger', 'critical', 'error'].includes(value),
  },
  showIcon: { type: Boolean, default: true },
  showCancel: { type: Boolean, default: true },
  title: { type: String, required: true },
  message: { type: String, default: '' },
  confirmText: { type: String, default: '确认' },
  cancelText: { type: String, default: '取消' },
  confirmDisabled: Boolean,
  cancelDisabled: Boolean,
  pending: Boolean,
  beforeConfirm: { type: Function, default: undefined },
});
const emit = defineEmits(['update:open', 'confirm', 'cancel', 'confirm-error']);
const id = useId();
const root = ref(null);
const panel = ref(null);
const internalOpen = ref(false);
let observer;
const working = ref(false);
let operation = 0;
const controlled = computed(() => props.open !== undefined);
const shown = computed(
  () => !props.disabled && (controlled.value ? props.open : internalOpen.value),
);
const triggerSlotProps = computed(() => ({
  open: shown.value,
  aria: {
    'aria-expanded': String(shown.value),
    'aria-controls': shown.value ? `${id}-popconfirm` : undefined,
    'aria-haspopup': 'dialog',
  },
}));

function setOpen(value) {
  const next = Boolean(value) && !props.disabled;
  if (!controlled.value) internalOpen.value = next;
  emit('update:open', next);
  if (next) nextTick(updatePosition);
}
function triggerElement() {
  return root.value?.querySelector('button, [tabindex], a, input, select, textarea');
}
function dismiss(reason, restoreFocus = true) {
  if (!shown.value || working.value || props.pending) return;
  setOpen(false);
  emit('cancel', reason);
  if (restoreFocus)
    nextTick(() => {
      if (!shown.value) triggerElement()?.focus();
    });
}
async function confirm() {
  if (!shown.value || props.confirmDisabled || working.value || props.pending) return;
  working.value = true;
  const currentOperation = ++operation;
  try {
    if (
      (await props.beforeConfirm?.()) === false ||
      currentOperation !== operation ||
      !shown.value ||
      props.pending ||
      props.confirmDisabled
    )
      return;
    emit('confirm');
    setOpen(false);
    nextTick(() => {
      if (!shown.value) triggerElement()?.focus();
    });
  } catch (error) {
    if (currentOperation === operation && shown.value) emit('confirm-error', error);
  } finally {
    if (currentOperation === operation) working.value = false;
  }
}
function onTriggerClick(event) {
  if (props.disabled || working.value || props.pending || panel.value?.contains(event.target))
    return;
  setOpen(!shown.value);
}
function within(node) {
  return Boolean(node && (root.value?.contains(node) || panel.value?.contains(node)));
}
function onDocumentClick(event) {
  if (shown.value && !within(event.target)) dismiss('outside', false);
}
function onKeydown(event) {
  if (!shown.value || !within(event.target)) return;
  if (event.key === 'Escape') {
    event.preventDefault();
    event.stopPropagation();
    dismiss('escape');
  }
  if (event.key !== 'Tab' || !panel.value?.contains(event.target)) return;
  const controls = focusableElementsIn(panel.value);
  event.preventDefault();
  event.stopPropagation();
  const nextIndex = controls.indexOf(event.target) + (event.shiftKey ? -1 : 1);
  if (controls[nextIndex]) {
    controls[nextIndex].focus();
    return;
  }
  if (
    (event.shiftKey && event.target === controls[0]) ||
    (!event.shiftKey && event.target === controls.at(-1)) ||
    !controls.length
  ) {
    event.preventDefault();
    event.stopPropagation();
    if (working.value || props.pending) return;
    const trigger = triggerElement();
    const outside = focusableElementsIn(document.body).filter(
      (element) => !panel.value.contains(element),
    );
    const next = event.shiftKey ? trigger : outside[outside.indexOf(trigger) + 1];
    dismiss('tab', false);
    nextTick(() => {
      if (!shown.value) (next || trigger)?.focus();
    });
  }
}
function splitPlacement(value) {
  const [side, align = 'center'] = value.split('-');
  return { side, align: align === 'start' || align === 'end' ? align : 'center' };
}
function sideSpace(side, rect) {
  const edge = 4;
  return side === 'top'
    ? rect.top - edge
    : side === 'bottom'
      ? window.innerHeight - rect.bottom - edge
      : side === 'left'
        ? rect.left - edge
        : window.innerWidth - rect.right - edge;
}
function updatePosition() {
  if (!shown.value || !root.value || !panel.value) return;
  const trigger = root.value.getBoundingClientRect();
  const element = panel.value;
  const rect = element.getBoundingClientRect();
  const requested = splitPlacement(placements.includes(props.placement) ? props.placement : 'top');
  let side = requested.side;
  const arrowHeight =
    parseFloat(getComputedStyle(element).getPropertyValue('--popconfirm-arrow-height')) || 8;
  const arrowOverlap =
    parseFloat(getComputedStyle(element).getPropertyValue('--popconfirm-arrow-overlap')) || 1;
  const triggerGap =
    parseFloat(getComputedStyle(element).getPropertyValue('--popconfirm-trigger-gap')) || 4;
  const offset = arrowHeight - arrowOverlap + triggerGap;
  const required = (side === 'top' || side === 'bottom' ? rect.height : rect.width) + offset;
  const preferredSpace = sideSpace(side, trigger);
  const flippedSpace = sideSpace(opposite[side], trigger);
  if (preferredSpace < required && flippedSpace > preferredSpace) side = opposite[side];
  const { align } = requested;
  const edge = 4;
  const arrowExtent = arrowHeight - arrowOverlap;
  const topInset = edge + (side === 'bottom' ? arrowExtent : 0);
  const bottomInset = edge + (side === 'top' ? arrowExtent : 0);
  let { left, top } = positionOnSide(side, align, trigger, rect, offset);
  left = Math.min(Math.max(edge, left), Math.max(edge, window.innerWidth - edge - rect.width));
  top = Math.min(
    Math.max(topInset, top),
    Math.max(topInset, window.innerHeight - bottomInset - rect.height),
  );
  element.dataset.placement = `${side}${align === 'center' ? '' : `-${align}`}`;
  element.style.setProperty('--popconfirm-left', `${left}px`);
  element.style.setProperty('--popconfirm-top', `${top}px`);
}

function positionOnSide(side, align, trigger, rect, offset) {
  let left;
  let top;
  if (side === 'top' || side === 'bottom') {
    left =
      align === 'start'
        ? trigger.left
        : align === 'end'
          ? trigger.right - rect.width
          : trigger.left + (trigger.width - rect.width) / 2;
    top = side === 'top' ? trigger.top - rect.height - offset : trigger.bottom + offset;
  } else {
    top =
      align === 'start'
        ? trigger.top
        : align === 'end'
          ? trigger.bottom - rect.height
          : trigger.top + (trigger.height - rect.height) / 2;
    left = side === 'left' ? trigger.left - rect.width - offset : trigger.right + offset;
  }
  return { left, top };
}

onMounted(() => {
  document.addEventListener('click', onDocumentClick, true);
  window.addEventListener('resize', updatePosition);
  document.addEventListener('scroll', updatePosition, true);
  observer = new ResizeObserver(updatePosition);
  if (root.value) observer.observe(root.value);
});
watch(
  shown,
  () => {
    operation += 1;
    working.value = false;
  },
  { flush: 'sync' },
);
watch(
  shown,
  (value) =>
    nextTick(() => {
      if (value && panel.value) {
        const content = panel.value.querySelector('.wb-popconfirm__content');
        const initialFocus =
          content && content.scrollHeight > content.clientHeight
            ? panel.value
            : panel.value.querySelector('button:not(:disabled)') || panel.value;
        initialFocus.focus({ preventScroll: true });
      }
      updatePosition();
    }),
  { immediate: true },
);
watch(
  panel,
  (node, previous) => {
    if (previous) observer?.unobserve(previous);
    if (node) observer?.observe(node);
  },
  { flush: 'post' },
);
watch(
  () => [props.placement, props.disabled],
  () => {
    if (props.disabled) setOpen(false);
    else nextTick(updatePosition);
  },
);
onBeforeUnmount(() => {
  operation += 1;
  document.removeEventListener('click', onDocumentClick, true);
  window.removeEventListener('resize', updatePosition);
  document.removeEventListener('scroll', updatePosition, true);
  observer?.disconnect();
});
</script>

<template>
  <span
    ref="root"
    class="wb-popconfirm"
    :class="{ 'is-open': shown, 'is-disabled': disabled }"
    @click="onTriggerClick"
    @keydown="onKeydown"
  >
    <slot
      name="trigger"
      v-bind="triggerSlotProps"
    />
  </span>
  <Teleport to="body">
    <section
      v-if="shown"
      :id="`${id}-popconfirm`"
      ref="panel"
      @keydown="onKeydown"
      class="wb-popconfirm__panel"
      :data-placement="placement"
      role="dialog"
      aria-modal="false"
      tabindex="-1"
      :aria-busy="working || pending"
      :aria-labelledby="`${id}-title`"
      :aria-describedby="message ? `${id}-message` : undefined"
    >
      <svg
        class="wb-popconfirm__arrow"
        viewBox="0 0 12 8"
        aria-hidden="true"
      >
        <path d="M0 0h12L7.6 5.9C6.8 7 5.2 7 4.4 5.9L0 0Z" />
      </svg>
      <div class="wb-popconfirm__content">
        <div class="wb-popconfirm__heading">
          <svg
            v-if="showIcon"
            class="wb-popconfirm__icon"
            :class="`wb-popconfirm__icon--${type}`"
            viewBox="0 0 16 16"
            aria-hidden="true"
          >
            <template v-if="type === 'danger' || type === 'critical'">
              <path
                class="wb-popconfirm__icon-fill"
                d="M8 1.3 15 14H1L8 1.3Z"
              />
              <path
                class="wb-popconfirm__icon-mark"
                d="M8 5v4.2M8 11.5v.1"
              />
            </template>
            <template v-else-if="type === 'error'">
              <circle
                class="wb-popconfirm__icon-fill"
                cx="8"
                cy="8"
                r="7"
              />
              <path
                class="wb-popconfirm__icon-mark"
                d="m5.3 5.3 5.4 5.4m0-5.4-5.4 5.4"
              />
            </template>
            <template v-else>
              <circle
                class="wb-popconfirm__icon-fill"
                cx="8"
                cy="8"
                r="7"
              />
              <path
                class="wb-popconfirm__icon-mark"
                :d="type === 'info' ? 'M8 7v4m0-6.1v.1' : 'M8 4.5v4.4m0 2.4v.1'"
              />
            </template>
          </svg>
          <h2
            :id="`${id}-title`"
            class="wb-popconfirm__title"
          >
            {{ title }}
          </h2>
        </div>
        <p
          v-if="message"
          :id="`${id}-message`"
          class="wb-popconfirm__message"
        >
          {{ message }}
        </p>
        <div class="wb-popconfirm__actions">
          <WorkbenchButton
            v-if="showCancel"
            appearance="secondary"
            size="28"
            :disabled="cancelDisabled || working || pending"
            @click.stop="dismiss('cancel')"
            >{{ cancelText }}</WorkbenchButton
          >
          <WorkbenchButton
            size="28"
            :disabled="confirmDisabled || working || pending"
            @click.stop="confirm"
            >{{ confirmText }}</WorkbenchButton
          >
        </div>
      </div>
    </section>
  </Teleport>
</template>

<style>
.wb-popconfirm {
  display: inline-flex;
}
.wb-popconfirm__panel {
  --popconfirm-arrow-width: var(--wb-asset-wb-popover-arrow-width);
  --popconfirm-arrow-height: var(--wb-asset-wb-popover-arrow-height);
  --popconfirm-arrow-overlap: var(--wb-asset-wb-popover-arrow-overlap);
  --popconfirm-trigger-gap: var(--wb-asset-wb-popover-trigger-gap);
  box-sizing: border-box;
  position: fixed;
  z-index: 40;
  top: var(--popconfirm-top, -9999px);
  left: var(--popconfirm-left, -9999px);
  width: max-content;
  max-width: min(
    var(--wb-asset-wb-popover-max-width),
    calc(100vw - 2 * var(--wb-spacing-component-xs))
  );
  padding: var(--wb-spacing-component-lg);
  border-radius: var(--wb-radius-md);
  background: var(--wb-color-surface-overlay);
  box-shadow: var(--wb-shadow-lg);
  color: var(--wb-color-text-primary);
}
.wb-popconfirm__heading {
  display: flex;
  align-items: center;
  gap: var(--wb-spacing-component-sm);
}
.wb-popconfirm__content {
  max-height: calc(
    100vh - 2 * var(--wb-spacing-component-xs) - 2 * var(--wb-spacing-component-lg) -
      var(--popconfirm-arrow-height) + var(--popconfirm-arrow-overlap)
  );
  overflow-y: auto;
  overscroll-behavior: contain;
}
.wb-popconfirm__icon {
  width: var(--wb-icon-size-16);
  height: var(--wb-icon-size-16);
  flex: 0 0 var(--wb-icon-size-16);
}
.wb-popconfirm__icon--info {
  color: var(--wb-color-info-primary);
}
.wb-popconfirm__icon--warning {
  color: var(--wb-color-warning);
}
.wb-popconfirm__icon--danger {
  color: var(--wb-color-alert);
}
.wb-popconfirm__icon--critical,
.wb-popconfirm__icon--error {
  color: var(--wb-color-error);
}
.wb-popconfirm__icon-fill {
  fill: currentColor;
}
.wb-popconfirm__icon-mark {
  fill: none;
  stroke: var(--wb-color-text-inverse);
  stroke-width: 1.5;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.wb-popconfirm__icon--warning .wb-popconfirm__icon-mark {
  stroke: var(--wb-color-text-primary);
}
.wb-popconfirm__title {
  margin: 0;
  overflow-wrap: anywhere;
  font-size: var(--wb-font-headline-s-font-size);
  font-weight: var(--wb-font-headline-s-font-weight);
  line-height: var(--wb-font-headline-s-line-height);
  letter-spacing: var(--wb-font-headline-s-letter-spacing);
}
.wb-popconfirm__message {
  margin: var(--wb-spacing-component-sm) 0 0;
  overflow-wrap: anywhere;
  color: var(--wb-color-text-secondary);
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
}
.wb-popconfirm__actions {
  display: flex;
  justify-content: flex-end;
  gap: var(--wb-spacing-component-sm);
  margin-top: var(--wb-spacing-component-lg);
}
.wb-popconfirm__arrow {
  position: absolute;
  display: block;
  width: var(--popconfirm-arrow-width);
  height: var(--popconfirm-arrow-height);
  overflow: visible;
}
.wb-popconfirm__arrow path {
  fill: var(--wb-color-surface-overlay);
}
.wb-popconfirm__panel[data-placement^='top'] .wb-popconfirm__arrow {
  bottom: calc(-1 * var(--popconfirm-arrow-height) + var(--popconfirm-arrow-overlap));
}
.wb-popconfirm__panel[data-placement^='bottom'] .wb-popconfirm__arrow {
  top: calc(-1 * var(--popconfirm-arrow-height) + var(--popconfirm-arrow-overlap));
  transform: rotate(180deg);
}
.wb-popconfirm__panel[data-placement^='left'] .wb-popconfirm__arrow {
  right: calc(-1 * var(--popconfirm-arrow-height) + var(--popconfirm-arrow-overlap));
  transform: rotate(-90deg);
}
.wb-popconfirm__panel[data-placement^='right'] .wb-popconfirm__arrow {
  left: calc(-1 * var(--popconfirm-arrow-height) + var(--popconfirm-arrow-overlap));
  transform: rotate(90deg);
}
.wb-popconfirm__panel[data-placement^='top'][data-placement$='-start'] .wb-popconfirm__arrow,
.wb-popconfirm__panel[data-placement^='bottom'][data-placement$='-start'] .wb-popconfirm__arrow {
  left: calc(var(--wb-spacing-component-lg) - var(--popconfirm-arrow-width) / 2);
}
.wb-popconfirm__panel[data-placement^='top'][data-placement$='-end'] .wb-popconfirm__arrow,
.wb-popconfirm__panel[data-placement^='bottom'][data-placement$='-end'] .wb-popconfirm__arrow {
  right: calc(var(--wb-spacing-component-lg) - var(--popconfirm-arrow-width) / 2);
}
.wb-popconfirm__panel[data-placement^='left'][data-placement$='-start'] .wb-popconfirm__arrow,
.wb-popconfirm__panel[data-placement^='right'][data-placement$='-start'] .wb-popconfirm__arrow {
  top: calc(var(--wb-spacing-component-lg) - var(--popconfirm-arrow-height) / 2);
}
.wb-popconfirm__panel[data-placement^='left'][data-placement$='-end'] .wb-popconfirm__arrow,
.wb-popconfirm__panel[data-placement^='right'][data-placement$='-end'] .wb-popconfirm__arrow {
  top: auto;
  bottom: calc(var(--wb-spacing-component-lg) - var(--popconfirm-arrow-height) / 2);
}
.wb-popconfirm__panel[data-placement='top'] .wb-popconfirm__arrow,
.wb-popconfirm__panel[data-placement='bottom'] .wb-popconfirm__arrow {
  left: calc(50% - var(--popconfirm-arrow-width) / 2);
}
.wb-popconfirm__panel[data-placement='left'] .wb-popconfirm__arrow,
.wb-popconfirm__panel[data-placement='right'] .wb-popconfirm__arrow {
  top: calc(50% - var(--popconfirm-arrow-height) / 2);
}
</style>
