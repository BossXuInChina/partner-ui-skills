<script setup lang="ts">
import { useSlots, type PropType } from 'vue';
import { hasSlotContent } from '../card-block/slots';
const slots = useSlots();
const has = (name: string, scope: Record<string, unknown> = {}) =>
  hasSlotContent(slots, name, scope);
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import BlockFrame from '../card-block/BlockFrame.vue';
import type {
  CardSize,
  CardAction,
  CardFooter,
  CardActionEvent,
  CardLayout,
  QuickAppItem,
  QuickAppActivateEvent,
} from '../../types/card-blocks';
const props = defineProps({
  title: { type: String, default: '' },
  variant: {
    type: String as PropType<'display-white'>,
    default: 'display-white',
    validator: (value: string) => ['display-white'].includes(value),
  },
  size: {
    type: String as PropType<CardSize>,
    default: 'xxxl',
    validator: (value: string) => ['s', 'm', 'l', 'xl', 'xxl', 'xxxl'].includes(value),
  },
  href: { type: String, default: undefined },
  target: { type: String, default: undefined },
  rel: { type: String, default: undefined },
  headerActions: { type: Array as PropType<CardAction[]>, default: () => [] },
  footer: { type: Object as PropType<CardFooter | null>, default: null },
  actions: { type: Array as PropType<CardAction[]>, default: () => [] },
  layout: {
    type: String as PropType<CardLayout>,
    default: 'row',
    validator: (value: string) => ['row', 'multi', 'column'].includes(value),
  },
  items: { type: Array as PropType<QuickAppItem[]>, default: () => [] },
});
const emit = defineEmits({
  action: (_payload: CardActionEvent) => true,
  activate: (_payload: QuickAppActivateEvent) => true,
});
function activate(item: QuickAppItem, event: MouseEvent) {
  if (!item.disabled) emit('activate', { item, event });
}
</script>
<template>
  <BlockFrame
    v-bind="$props"
    variant="display-white"
    class="wbc-quick-card"
    :class="{ 'wbc-card--narrow': layout === 'column' }"
    data-card-block="quick-app"
    @action="emit('action', $event)"
  >
    <template #header
      ><slot
        v-if="has('header')"
        name="header"
    /></template>
    <template #header-actions
      ><slot
        v-if="has('header-actions')"
        name="header-actions"
    /></template>
    <template #footer
      ><slot
        v-if="has('footer')"
        name="footer"
    /></template>
    <template #actions
      ><slot
        v-if="has('actions')"
        name="actions"
    /></template>
    <div
      v-if="items.length"
      class="wbc-quick-grid"
      :class="`wbc-quick-grid--${layout}`"
    >
      <component
        :is="item.href && !item.disabled ? 'a' : 'button'"
        v-for="(item, index) in items"
        :key="item.id || index"
        class="wbc-quick-app"
        :type="!item.href || item.disabled ? 'button' : undefined"
        :href="!item.disabled ? item.href : undefined"
        :target="item.target"
        :rel="item.rel || (item.target === '_blank' ? 'noopener noreferrer' : undefined)"
        :disabled="item.disabled ? true : undefined"
        :title="item.label"
        @click="activate(item, $event)"
      >
        <slot
          v-if="has('item', { item, index })"
          name="item"
          :item="item"
          :index="index"
        />
        <template v-else
          ><span aria-hidden="true"
            ><WorkbenchIcon :name="item.icon || '布局视图/视图=宫格,尺寸=20,面性=off'" /></span
          ><strong>{{ item.label }}</strong></template
        >
      </component>
    </div>
    <slot
      v-else-if="has('empty')"
      name="empty"
    />
    <p
      v-else
      class="wbc-empty"
    >
      暂无应用
    </p>
  </BlockFrame>
</template>
