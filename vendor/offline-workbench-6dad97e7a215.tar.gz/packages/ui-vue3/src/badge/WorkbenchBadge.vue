<script setup>
import { computed } from 'vue';
import '../../../../catalog/generated/asset.tokens.css';

const props = defineProps({
  variant: {
    type: String,
    default: 'dot',
    validator: value => ['dot', 'number'].includes(value),
  },
  value: {
    type: Number,
    default: undefined,
    validator: value => Number.isInteger(value),
  },
  ariaLabel: { type: String, default: '' },
  hidden: {
    type: Boolean,
    default: false,
  },
  placement: {
    type: String,
    default: 'corner',
    validator: value => ['corner', 'inline'].includes(value),
  },
});

const showBadge = computed(() => {
  if (props.hidden) return false;
  if (props.variant === 'dot') return true;
  return Number.isInteger(props.value) && props.value > 0;
});
const displayValue = computed(() => props.value > 99 ? '99+' : String(props.value));
const isSingleDigit = computed(() => props.variant === 'number' && props.value > 0 && props.value < 10);
const accessibleLabel = computed(() => props.ariaLabel || `${props.value} 条未读消息`);
</script>

<template>
  <span class="wb-badge" :class="[`wb-badge--${variant}`, `is-${placement}`]">
    <slot />
    <span
      v-if="showBadge"
      class="wb-badge__mark"
      :class="{ 'is-single-digit': isSingleDigit }"
      :role="variant === 'number' ? 'status' : undefined"
      :aria-label="variant === 'number' ? accessibleLabel : undefined"
      :aria-hidden="variant === 'dot' ? 'true' : undefined"
    >
      <span v-if="variant === 'number'" class="wb-badge__value" aria-hidden="true">{{ displayValue }}</span>
    </span>
  </span>
</template>

<style scoped>
.wb-badge {
  position: relative;
  display: inline-flex;
  box-sizing: border-box;
  max-width: 100%;
  vertical-align: middle;
}

.wb-badge__mark {
  position: absolute;
  z-index: 1;
  display: inline-flex;
  box-sizing: content-box;
  flex: none;
  align-items: center;
  justify-content: center;
  border: var(--wb-asset-wb-badge-border-width) solid var(--wb-color-text-inverse);
  border-radius: var(--wb-radius-full);
  background: var(--wb-color-error);
  color: var(--wb-color-text-inverse);
  pointer-events: none;
}

.wb-badge--dot .wb-badge__mark {
  right: 0.5px;
  bottom: 0.5px;
  width: var(--wb-asset-wb-badge-dot-fill-size);
  height: var(--wb-asset-wb-badge-dot-fill-size);
}

.wb-badge--number .wb-badge__mark {
  top: 0;
  right: var(--wb-asset-wb-badge-number-corner-right-offset);
  min-width: var(--wb-asset-wb-badge-number-fill-size);
  height: var(--wb-asset-wb-badge-number-fill-size);
  padding-inline: var(--wb-asset-wb-badge-number-padding-inline);
  transform: translateY(-50%);
}

.wb-badge.is-inline .wb-badge__mark {
  position: relative;
  inset: auto;
  transform: none;
}

.wb-badge--number .wb-badge__mark.is-single-digit {
  width: var(--wb-asset-wb-badge-number-fill-size);
  padding-inline: 0;
}

.wb-badge__value {
  position: relative;
  z-index: 1;
  color: var(--wb-color-text-inverse);
  font-family: inherit;
  font-size: var(--wb-font-body-s-font-size);
  font-weight: var(--wb-font-body-s-font-weight);
  line-height: var(--wb-asset-wb-badge-number-line-height);
  letter-spacing: var(--wb-font-body-s-letter-spacing);
  white-space: nowrap;
}
</style>
