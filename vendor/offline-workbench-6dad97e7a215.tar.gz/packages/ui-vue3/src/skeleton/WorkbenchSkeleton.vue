<script setup>
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import { computed } from 'vue';
import WorkbenchSkeletonBlock from './WorkbenchSkeletonBlock.vue';

const props = defineProps({
  variant: { type: String, default: 'title-text', validator: value => ['title-text', 'text', 'media-text', 'item-text', 'hero-text'].includes(value) },
  showTitle: { type: Boolean, default: true },
  lines: { type: Number, default: 3, validator: value => Number.isInteger(value) && value >= 1 && value <= 5 },
  animated: { type: Boolean, default: true },
  label: { type: String, default: '' },
});

const resolvedVariant = computed(() => ['title-text', 'text', 'media-text', 'item-text', 'hero-text'].includes(props.variant) ? props.variant : 'title-text');
const textLines = computed(() => Array.from({ length: Number.isFinite(props.lines) ? Math.min(5, Math.max(1, Math.floor(props.lines))) : 3 }, (_, index) => index));
const statusLabel = computed(() => props.label.trim());
const showResolvedTitle = computed(() => props.showTitle && resolvedVariant.value !== 'text');
</script>

<template>
  <article
    class="wb-skeleton"
    :class="[`wb-skeleton--${resolvedVariant}`, { 'is-announced': Boolean(statusLabel) }]"
    :role="statusLabel ? 'status' : undefined"
    :aria-live="statusLabel ? 'polite' : undefined"
    :aria-label="statusLabel || undefined"
    :aria-hidden="statusLabel ? undefined : 'true'"
  >
    <WorkbenchSkeletonBlock v-if="resolvedVariant === 'hero-text'" class="wb-skeleton__hero" radius="lg" :animated="animated" />
    <WorkbenchSkeletonBlock v-if="resolvedVariant === 'media-text'" class="wb-skeleton__media" radius="lg" :animated="animated" />
    <WorkbenchSkeletonBlock v-if="resolvedVariant === 'item-text'" class="wb-skeleton__item-icon" :animated="animated" />
    <div class="wb-skeleton__copy">
      <WorkbenchSkeletonBlock v-if="showResolvedTitle" class="wb-skeleton__title" :animated="animated" />
      <div class="wb-skeleton__lines">
        <WorkbenchSkeletonBlock v-for="line in textLines" :key="line" class="wb-skeleton__line" :class="{ 'is-last': line === textLines.length - 1 }" :animated="animated" />
      </div>
    </div>
  </article>
</template>

<style>
.wb-skeleton { display: grid; min-width: 0; gap: var(--wb-spacing-component-md); }
.wb-skeleton--title-text, .wb-skeleton--text, .wb-skeleton--hero-text { grid-template-columns: minmax(0, 1fr); }
.wb-skeleton--media-text, .wb-skeleton--item-text { grid-template-columns: max-content minmax(0, 1fr); align-items: start; }
.wb-skeleton--media-text .wb-skeleton__copy, .wb-skeleton--item-text .wb-skeleton__copy { padding-top: var(--wb-asset-wb-skeleton-copy-offset); }
.wb-skeleton__copy, .wb-skeleton__lines { display: grid; min-width: 0; gap: var(--wb-spacing-component-sm); }
.wb-skeleton__title { width: var(--wb-asset-wb-skeleton-title-width); height: var(--wb-asset-wb-skeleton-title-height); margin-bottom: var(--wb-spacing-component-xs); }
.wb-skeleton__hero { width: 100%; height: var(--wb-asset-wb-skeleton-hero-height); }
.wb-skeleton__media { width: var(--wb-asset-wb-skeleton-media-size); height: var(--wb-asset-wb-skeleton-media-size); flex: none; }
.wb-skeleton__item-icon { width: var(--wb-asset-wb-skeleton-item-icon-size); height: var(--wb-asset-wb-skeleton-title-height); margin-top: var(--wb-asset-wb-skeleton-copy-offset); }
.wb-skeleton__line.is-last { width: var(--wb-asset-wb-skeleton-last-line-width); }
</style>
