<script setup>
import { computed, h, useSlots } from 'vue';
import './tag-surface.css';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import WorkbenchTooltip from '../tooltip/WorkbenchTooltip.vue';

defineOptions({ inheritAttrs: false });

const props = defineProps({
  label: { type: [String, Number], required: true },
  variant: {
    type: String,
    default: 'basic',
    validator: (value) =>
      ['basic', 'status-subtle', 'status-dot', 'category', 'corner', 'status-primary'].includes(
        value,
      ),
  },
  size: {
    type: String,
    default: 'medium',
    validator: (value) => ['small', 'medium', 'large'].includes(value),
  },
  status: {
    type: String,
    default: 'info',
    validator: (value) =>
      ['waiting', 'info', 'success', 'warning', 'alert', 'error', 'none'].includes(value),
  },
  categoryIndex: {
    type: Number,
    default: 1,
    validator: (value) => Number.isInteger(value) && value >= 1 && value <= 12,
  },
  cornerTone: {
    type: String,
    default: 'new',
    validator: (value) => ['new', 'hot', 'discount', 'off'].includes(value),
  },
  placement: {
    type: String,
    default: 'top-left',
    validator: (value) => ['top-left', 'top-right'].includes(value),
  },
  action: {
    type: String,
    default: 'none',
    validator: (value) => ['none', 'add', 'remove'].includes(value),
  },
  interactive: { type: Boolean, default: false },
  selected: { type: Boolean, default: false },
  disabled: { type: Boolean, default: false },
});

const emit = defineEmits(['select', 'add', 'remove']);
const slots = useSlots();
const fullLabel = computed(() => String(props.label));
const graphemes = computed(() => {
  if (typeof Intl !== 'undefined' && Intl.Segmenter) {
    return [
      ...new Intl.Segmenter('zh-CN', { granularity: 'grapheme' }).segment(fullLabel.value),
    ].map((item) => item.segment);
  }
  return Array.from(fullLabel.value);
});
const truncated = computed(() => graphemes.value.length > 7);
// Short tags keep their original DOM; long tags use the shared Tooltip trigger contract.
const TagTooltip = (_, { slots: tooltipSlots }) =>
  truncated.value
    ? h(WorkbenchTooltip, { content: fullLabel.value }, { trigger: tooltipSlots.default })
    : tooltipSlots.default({ aria: {} })[0];
const displayLabel = computed(() =>
  truncated.value ? `${graphemes.value.slice(0, 7).join('')}…` : fullLabel.value,
);
const semanticCategories = [
  { index: 5, terms: ['发生错误', '紧急', '错误'] },
  { index: 1, terms: ['计划中'] },
  { index: 2, terms: ['已完成'] },
  { index: 3, terms: ['待开始'] },
  { index: 4, terms: ['进行中'] },
  { index: 6, terms: ['关机'] },
  { index: 7, terms: ['搁置中'] },
  { index: 8, terms: ['在途中', '类型一'] },
  { index: 9, terms: ['网管管理', '类型二'] },
  { index: 10, terms: ['运力总览', '类型三'] },
  { index: 11, terms: ['副设备', '类型四'] },
  { index: 12, terms: ['主设备', '类型五'] },
];
const resolvedStatus = computed(() => {
  if (props.variant === 'status-primary') return props.status === 'info' ? 'waiting' : props.status;
  if (props.variant === 'status-subtle' || props.variant === 'status-dot')
    return props.status === 'waiting' ? 'info' : props.status;
  return props.status;
});
const statusTone = { info: 1, waiting: 1, success: 2, warning: 3, alert: 4, error: 5, none: 6 };
const toneIndex = computed(() => {
  if (props.variant !== 'category') return statusTone[resolvedStatus.value] ?? 1;
  return (
    semanticCategories.find((item) => item.terms.some((term) => fullLabel.value.includes(term)))
      ?.index ?? props.categoryIndex
  );
});
const effectiveAction = computed(() => (props.variant === 'basic' ? props.action : 'none'));
const selectedAllowed = computed(() => props.variant === 'basic' && props.selected);
const actionable = computed(
  () =>
    effectiveAction.value !== 'remove' && (props.interactive || effectiveAction.value === 'add'),
);
const rootTag = computed(() => (actionable.value ? 'button' : 'span'));
const ariaLabel = computed(() => {
  if (effectiveAction.value === 'add')
    return fullLabel.value.startsWith('添加') ? fullLabel.value : `添加${fullLabel.value}`;
  if (effectiveAction.value === 'remove') return `删除${fullLabel.value}`;
  return fullLabel.value;
});
const rootClasses = computed(() => [
  `wb-tag--${props.variant}`,
  `wb-tag--${props.size}`,
  `is-tone-${toneIndex.value}`,
  `is-status-${resolvedStatus.value}`,
  `is-corner-${props.cornerTone}`,
  `is-${props.placement}`,
  {
    'is-actionable': actionable.value,
    'is-selected': selectedAllowed.value,
    'is-disabled': props.disabled,
    'is-truncated': truncated.value,
    [`is-action-${effectiveAction.value}`]: effectiveAction.value !== 'none',
  },
]);
const showLeadingIcon = computed(() => effectiveAction.value === 'none' && Boolean(slots.icon));

function activate(event) {
  if (props.disabled) return;
  if (effectiveAction.value === 'add') emit('add', { label: fullLabel.value, event });
  else if (props.interactive)
    emit('select', {
      label: fullLabel.value,
      selected: props.variant === 'basic' ? !props.selected : undefined,
      event,
    });
}
</script>

<template>
  <TagTooltip v-slot="{ aria }">
    <component
      :is="rootTag"
      v-bind="$attrs"
      class="wb-tag"
      :class="rootClasses"
      :type="actionable ? 'button' : undefined"
      :disabled="actionable ? disabled : undefined"
      :aria-disabled="!actionable && disabled ? 'true' : undefined"
      :aria-pressed="interactive && variant === 'basic' ? String(selected) : undefined"
      :aria-label="actionable || truncated ? ariaLabel : undefined"
      :aria-describedby="
        [$attrs['aria-describedby'], aria['aria-describedby']].filter(Boolean).join(' ') ||
        undefined
      "
      :data-full-label="truncated ? fullLabel : undefined"
      @click="effectiveAction !== 'remove' && activate($event)"
    >
      <span
        v-if="variant === 'status-dot'"
        class="wb-tag__dot"
        aria-hidden="true"
      />
      <span
        v-else-if="effectiveAction === 'add'"
        class="wb-tag__action-icon wb-tag__action-icon--add"
        aria-hidden="true"
      >
        <WorkbenchIcon name="/ic_public_plus_line_10px" />
      </span>
      <span
        v-else-if="showLeadingIcon"
        class="wb-tag__icon"
        aria-hidden="true"
      >
        <slot name="icon" />
      </span>
      <button
        v-if="effectiveAction === 'remove' && interactive"
        v-bind="aria"
        class="wb-tag__label wb-tag__select"
        type="button"
        :disabled="disabled"
        :aria-pressed="String(selectedAllowed)"
        @click.stop="activate"
      >
        {{ displayLabel }}
      </button>
      <span
        v-else
        class="wb-tag__label"
        >{{ displayLabel }}</span
      >
      <button
        v-if="effectiveAction === 'remove'"
        v-bind="aria"
        class="wb-tag__action-icon wb-tag__remove wb-tag-surface__remove"
        type="button"
        :disabled="disabled"
        :aria-label="`删除${fullLabel}`"
        @click.stop="!disabled && emit('remove', { label: fullLabel, event: $event })"
      >
        <WorkbenchIcon name="/ic_public_close_line_8px" />
      </button>
    </component>
  </TagTooltip>
</template>

<style scoped>
.wb-tag {
  display: inline-flex;
  box-sizing: border-box;
  inline-size: max-content;
  justify-self: start;
  align-items: center;
  justify-content: center;
  flex: none;
  gap: var(--wb-spacing-component-xs);
  height: var(--wb-asset-wb-tag-height-medium);
  padding: 0 var(--wb-asset-wb-tag-padding-inline);
  border: 0;
  border-radius: var(--wb-radius-sm);
  background: var(--tag-basic-background, transparent);
  color: var(--wb-color-text-primary);
  font-family: inherit;
  font-size: var(--wb-font-body-s-font-size);
  font-weight: var(--wb-font-body-s-font-weight);
  line-height: var(--wb-font-body-s-line-height);
  letter-spacing: var(--wb-font-body-s-letter-spacing);
  white-space: nowrap;
  vertical-align: middle;
}
.wb-tag--small {
  height: var(--wb-asset-wb-tag-height-small);
}
.wb-tag--large {
  height: var(--wb-asset-wb-tag-height-large);
  padding-inline: var(--wb-asset-wb-tag-padding-inline-large);
}

.wb-tag.is-action-add {
  background: transparent;
  border: var(--wb-asset-wb-tag-border-width) dashed var(--wb-asset-wb-tag-light-add-border);
}
.wb-tag.is-selected:not(.is-disabled) {
  box-shadow: inset 0 0 0 var(--wb-asset-wb-tag-border-width) var(--wb-color-border-focus);
}
.wb-tag.is-action-add.is-selected:not(.is-disabled) {
  border-color: var(--wb-color-border-focus);
  box-shadow: none;
}
.wb-tag.is-actionable {
  appearance: none;
  cursor: pointer;
}
.wb-tag.is-actionable:focus-visible {
  outline: var(--wb-asset-wb-tag-border-width) solid var(--wb-color-border-focus);
  outline-offset: var(--wb-asset-wb-tag-focus-offset);
}
.wb-tag.is-disabled {
  color: var(--wb-color-text-disabled);
  cursor: not-allowed;
  box-shadow: none;
}
.wb-tag.is-disabled .wb-tag__dot {
  background: var(--wb-color-icon-disabled);
}
.wb-tag__label {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.wb-tag__icon,
.wb-tag__action-icon,
.wb-tag__dot {
  display: inline-flex;
  flex: none;
  align-items: center;
  justify-content: center;
}
.wb-tag__icon {
}
.wb-tag__action-icon {
  width: var(--wb-asset-wb-tag-action-icon-size);
  height: var(--wb-asset-wb-tag-action-icon-size);
}
.wb-tag__action-icon--add {
  width: var(--wb-asset-wb-tag-icon-size);
  height: var(--wb-asset-wb-tag-icon-size);
}
.wb-tag__dot {
  width: var(--wb-asset-wb-tag-dot-size);
  height: var(--wb-asset-wb-tag-dot-size);
  border-radius: var(--wb-radius-full);
}
.wb-tag :deep(svg) {
  display: block;
}
.wb-tag--basic .wb-tag__icon,
.wb-tag--basic .wb-tag__action-icon--add {
  color: var(--wb-color-icon-primary);
}
:global(.wb-tooltip:has(> .wb-tag)) {
  inline-size: max-content;
  justify-self: start;
  flex: none;
  border-radius: inherit;
  vertical-align: middle;
}

.wb-tag--status-subtle.is-tone-1,
.wb-tag--category.is-tone-1 {
  background: var(--wb-asset-wb-tag-light-1-background);
  color: var(--wb-asset-wb-tag-light-1-foreground);
}
.wb-tag--status-subtle.is-tone-2,
.wb-tag--category.is-tone-2 {
  background: var(--wb-asset-wb-tag-light-2-background);
  color: var(--wb-asset-wb-tag-light-2-foreground);
}
.wb-tag--status-subtle.is-tone-3,
.wb-tag--category.is-tone-3 {
  background: var(--wb-asset-wb-tag-light-3-background);
  color: var(--wb-asset-wb-tag-light-3-foreground);
}
.wb-tag--status-subtle.is-tone-4,
.wb-tag--category.is-tone-4 {
  background: var(--wb-asset-wb-tag-light-4-background);
  color: var(--wb-asset-wb-tag-light-4-foreground);
}
.wb-tag--status-subtle.is-tone-5,
.wb-tag--category.is-tone-5 {
  background: var(--wb-asset-wb-tag-light-5-background);
  color: var(--wb-asset-wb-tag-light-5-foreground);
}
.wb-tag--status-subtle.is-tone-6,
.wb-tag--category.is-tone-6 {
  background: var(--wb-asset-wb-tag-light-6-background);
  color: var(--wb-asset-wb-tag-light-6-foreground);
}
.wb-tag--category.is-tone-7 {
  background: var(--wb-asset-wb-tag-light-7-background);
  color: var(--wb-asset-wb-tag-light-7-foreground);
}
.wb-tag--category.is-tone-8 {
  background: var(--wb-asset-wb-tag-light-8-background);
  color: var(--wb-asset-wb-tag-light-8-foreground);
}
.wb-tag--category.is-tone-9 {
  background: var(--wb-asset-wb-tag-light-9-background);
  color: var(--wb-asset-wb-tag-light-9-foreground);
}
.wb-tag--category.is-tone-10 {
  background: var(--wb-asset-wb-tag-light-10-background);
  color: var(--wb-asset-wb-tag-light-10-foreground);
}
.wb-tag--category.is-tone-11 {
  background: var(--wb-asset-wb-tag-light-11-background);
  color: var(--wb-asset-wb-tag-light-11-foreground);
}
.wb-tag--category.is-tone-12 {
  background: var(--wb-asset-wb-tag-light-12-background);
  color: var(--wb-asset-wb-tag-light-12-foreground);
}

.wb-tag--status-dot {
  background: transparent;
  color: var(--wb-color-text-primary);
}
.wb-tag--status-dot.is-status-error .wb-tag__dot {
  background: var(--wb-asset-wb-tag-light-dot-error);
}
.wb-tag--status-dot.is-status-alert .wb-tag__dot {
  background: var(--wb-asset-wb-tag-light-dot-alert);
}
.wb-tag--status-dot.is-status-warning .wb-tag__dot {
  background: var(--wb-asset-wb-tag-light-dot-warning);
}
.wb-tag--status-dot.is-status-success .wb-tag__dot {
  background: var(--wb-asset-wb-tag-light-dot-success);
}
.wb-tag--status-dot.is-status-info .wb-tag__dot,
.wb-tag--status-dot.is-status-waiting .wb-tag__dot {
  background: var(--wb-asset-wb-tag-light-dot-info);
}
.wb-tag--status-dot.is-status-none .wb-tag__dot {
  background: var(--wb-asset-wb-tag-light-dot-none);
}

.wb-tag--corner {
  color: var(--wb-asset-wb-tag-solid-light);
}
.wb-tag--corner.is-corner-new {
  background: var(--wb-asset-wb-tag-light-corner-new);
}
.wb-tag--corner.is-corner-hot {
  background: var(--wb-asset-wb-tag-light-corner-hot);
}
.wb-tag--corner.is-corner-discount {
  background: var(--wb-asset-wb-tag-light-corner-discount);
}
.wb-tag--corner.is-corner-off {
  background: var(--wb-asset-wb-tag-light-corner-off);
}
.wb-tag--corner.is-top-left {
  border-start-start-radius: inherit;
  border-start-end-radius: 0;
  border-end-start-radius: 0;
  border-end-end-radius: inherit;
}
.wb-tag--corner.is-top-right {
  border-start-start-radius: 0;
  border-start-end-radius: inherit;
  border-end-start-radius: inherit;
  border-end-end-radius: 0;
}

.wb-tag--status-primary {
  color: var(--wb-asset-wb-tag-solid-light);
}
.wb-tag--status-primary.is-status-waiting,
.wb-tag--status-primary.is-status-info {
  background: var(--wb-asset-wb-tag-light-primary-waiting);
}
.wb-tag--status-primary.is-status-success {
  background: var(--wb-asset-wb-tag-light-primary-success);
}
.wb-tag--status-primary.is-status-warning {
  background: var(--wb-asset-wb-tag-light-primary-warning);
  color: var(--wb-asset-wb-tag-solid-dark);
}
.wb-tag--status-primary.is-status-alert {
  background: var(--wb-asset-wb-tag-light-primary-alert);
}
.wb-tag--status-primary.is-status-error {
  background: var(--wb-asset-wb-tag-light-primary-error);
}
.wb-tag--status-primary.is-status-none {
  background: var(--wb-asset-wb-tag-light-primary-none);
}

.wb-tag--status-subtle.is-actionable.is-status-error:not(.is-disabled):hover,
.wb-tag--status-subtle.is-actionable.is-status-error:not(.is-disabled):active {
  color: var(--wb-color-error-hover);
}
.wb-tag--status-subtle.is-actionable.is-status-alert:not(.is-disabled):hover,
.wb-tag--status-subtle.is-actionable.is-status-alert:not(.is-disabled):active {
  color: var(--wb-color-alert-hover);
}
.wb-tag--status-subtle.is-actionable.is-status-warning:not(.is-disabled):hover,
.wb-tag--status-subtle.is-actionable.is-status-warning:not(.is-disabled):active {
  color: var(--wb-color-warning-hover);
}
.wb-tag--status-subtle.is-actionable.is-status-success:not(.is-disabled):hover,
.wb-tag--status-subtle.is-actionable.is-status-success:not(.is-disabled):active {
  color: var(--wb-color-success-hover);
}
.wb-tag--status-subtle.is-actionable.is-status-info:not(.is-disabled):hover,
.wb-tag--status-subtle.is-actionable.is-status-info:not(.is-disabled):active {
  color: var(--wb-color-info-primary-hover);
}
.wb-tag--status-subtle.is-actionable.is-status-none:not(.is-disabled):hover,
.wb-tag--status-subtle.is-actionable.is-status-none:not(.is-disabled):active {
  color: var(--wb-color-none-hover);
}
.wb-tag--status-dot.is-actionable.is-status-error:not(.is-disabled):hover .wb-tag__dot,
.wb-tag--status-dot.is-actionable.is-status-error:not(.is-disabled):active .wb-tag__dot {
  background: var(--wb-color-error-hover);
}
.wb-tag--status-dot.is-actionable.is-status-alert:not(.is-disabled):hover .wb-tag__dot,
.wb-tag--status-dot.is-actionable.is-status-alert:not(.is-disabled):active .wb-tag__dot {
  background: var(--wb-color-alert-hover);
}
.wb-tag--status-dot.is-actionable.is-status-warning:not(.is-disabled):hover .wb-tag__dot,
.wb-tag--status-dot.is-actionable.is-status-warning:not(.is-disabled):active .wb-tag__dot {
  background: var(--wb-color-warning-hover);
}
.wb-tag--status-dot.is-actionable.is-status-success:not(.is-disabled):hover .wb-tag__dot,
.wb-tag--status-dot.is-actionable.is-status-success:not(.is-disabled):active .wb-tag__dot {
  background: var(--wb-color-success-hover);
}
.wb-tag--status-dot.is-actionable.is-status-info:not(.is-disabled):hover .wb-tag__dot,
.wb-tag--status-dot.is-actionable.is-status-info:not(.is-disabled):active .wb-tag__dot {
  background: var(--wb-color-info-primary-hover);
}
.wb-tag--status-dot.is-actionable.is-status-none:not(.is-disabled):hover .wb-tag__dot,
.wb-tag--status-dot.is-actionable.is-status-none:not(.is-disabled):active .wb-tag__dot {
  background: var(--wb-color-none-hover);
}
.wb-tag--status-primary.is-actionable.is-status-error:not(.is-disabled):hover,
.wb-tag--status-primary.is-actionable.is-status-error:not(.is-disabled):active {
  background: var(--wb-color-error-hover);
}
.wb-tag--status-primary.is-actionable.is-status-alert:not(.is-disabled):hover,
.wb-tag--status-primary.is-actionable.is-status-alert:not(.is-disabled):active {
  background: var(--wb-color-alert-hover);
}
.wb-tag--status-primary.is-actionable.is-status-warning:not(.is-disabled):hover,
.wb-tag--status-primary.is-actionable.is-status-warning:not(.is-disabled):active {
  background: var(--wb-color-warning-hover);
}
.wb-tag--status-primary.is-actionable.is-status-success:not(.is-disabled):hover,
.wb-tag--status-primary.is-actionable.is-status-success:not(.is-disabled):active {
  background: var(--wb-color-success-hover);
}
.wb-tag--status-primary.is-actionable.is-status-info:not(.is-disabled):hover,
.wb-tag--status-primary.is-actionable.is-status-info:not(.is-disabled):active,
.wb-tag--status-primary.is-actionable.is-status-waiting:not(.is-disabled):hover,
.wb-tag--status-primary.is-actionable.is-status-waiting:not(.is-disabled):active {
  background: var(--wb-color-info-primary-hover);
}
.wb-tag--status-primary.is-actionable.is-status-none:not(.is-disabled):hover,
.wb-tag--status-primary.is-actionable.is-status-none:not(.is-disabled):active {
  background: var(--wb-color-none-hover);
}

[data-wb-theme='dark'] .wb-tag--basic {
  background: var(--wb-asset-wb-tag-dark-basic-background);
  color: var(--wb-color-text-primary);
}
[data-wb-theme='dark'] .wb-tag.is-action-add {
  background: transparent;
  border-color: var(--wb-asset-wb-tag-dark-add-border);
}
[data-wb-theme='dark'] .wb-tag--status-subtle.is-tone-1,
[data-wb-theme='dark'] .wb-tag--category.is-tone-1 {
  background: var(--wb-asset-wb-tag-dark-1-background);
  color: var(--wb-asset-wb-tag-dark-1-foreground);
}
[data-wb-theme='dark'] .wb-tag--status-subtle.is-tone-2,
[data-wb-theme='dark'] .wb-tag--category.is-tone-2 {
  background: var(--wb-asset-wb-tag-dark-2-background);
  color: var(--wb-asset-wb-tag-dark-2-foreground);
}
[data-wb-theme='dark'] .wb-tag--status-subtle.is-tone-3,
[data-wb-theme='dark'] .wb-tag--category.is-tone-3 {
  background: var(--wb-asset-wb-tag-dark-3-background);
  color: var(--wb-asset-wb-tag-dark-3-foreground);
}
[data-wb-theme='dark'] .wb-tag--status-subtle.is-tone-4,
[data-wb-theme='dark'] .wb-tag--category.is-tone-4 {
  background: var(--wb-asset-wb-tag-dark-4-background);
  color: var(--wb-asset-wb-tag-dark-4-foreground);
}
[data-wb-theme='dark'] .wb-tag--status-subtle.is-tone-5,
[data-wb-theme='dark'] .wb-tag--category.is-tone-5 {
  background: var(--wb-asset-wb-tag-dark-5-background);
  color: var(--wb-asset-wb-tag-dark-5-foreground);
}
[data-wb-theme='dark'] .wb-tag--status-subtle.is-tone-6,
[data-wb-theme='dark'] .wb-tag--category.is-tone-6 {
  background: var(--wb-asset-wb-tag-dark-6-background);
  color: var(--wb-asset-wb-tag-dark-6-foreground);
}
[data-wb-theme='dark'] .wb-tag--category.is-tone-7 {
  background: var(--wb-asset-wb-tag-dark-7-background);
  color: var(--wb-asset-wb-tag-dark-7-foreground);
}
[data-wb-theme='dark'] .wb-tag--category.is-tone-8 {
  background: var(--wb-asset-wb-tag-dark-8-background);
  color: var(--wb-asset-wb-tag-dark-8-foreground);
}
[data-wb-theme='dark'] .wb-tag--category.is-tone-9 {
  background: var(--wb-asset-wb-tag-dark-9-background);
  color: var(--wb-asset-wb-tag-dark-9-foreground);
}
[data-wb-theme='dark'] .wb-tag--category.is-tone-10 {
  background: var(--wb-asset-wb-tag-dark-10-background);
  color: var(--wb-asset-wb-tag-dark-10-foreground);
}
[data-wb-theme='dark'] .wb-tag--category.is-tone-11 {
  background: var(--wb-asset-wb-tag-dark-11-background);
  color: var(--wb-asset-wb-tag-dark-11-foreground);
}
[data-wb-theme='dark'] .wb-tag--category.is-tone-12 {
  background: var(--wb-asset-wb-tag-dark-12-background);
  color: var(--wb-asset-wb-tag-dark-12-foreground);
}
[data-wb-theme='dark'] .wb-tag--status-dot.is-status-error .wb-tag__dot {
  background: var(--wb-asset-wb-tag-dark-dot-error);
}
[data-wb-theme='dark'] .wb-tag--status-dot.is-status-alert .wb-tag__dot {
  background: var(--wb-asset-wb-tag-dark-dot-alert);
}
[data-wb-theme='dark'] .wb-tag--status-dot.is-status-warning .wb-tag__dot {
  background: var(--wb-asset-wb-tag-dark-dot-warning);
}
[data-wb-theme='dark'] .wb-tag--status-dot.is-status-success .wb-tag__dot {
  background: var(--wb-asset-wb-tag-dark-dot-success);
}
[data-wb-theme='dark'] .wb-tag--status-dot.is-status-info .wb-tag__dot,
[data-wb-theme='dark'] .wb-tag--status-dot.is-status-waiting .wb-tag__dot {
  background: var(--wb-asset-wb-tag-dark-dot-info);
}
[data-wb-theme='dark'] .wb-tag--status-dot.is-status-none .wb-tag__dot {
  background: var(--wb-asset-wb-tag-dark-dot-none);
}
[data-wb-theme='dark'] .wb-tag--corner.is-corner-new {
  background: var(--wb-asset-wb-tag-dark-corner-new);
}
[data-wb-theme='dark'] .wb-tag--corner.is-corner-hot {
  background: var(--wb-asset-wb-tag-dark-corner-hot);
}
[data-wb-theme='dark'] .wb-tag--corner.is-corner-discount {
  background: var(--wb-asset-wb-tag-dark-corner-discount);
}
[data-wb-theme='dark'] .wb-tag--corner.is-corner-off {
  background: var(--wb-asset-wb-tag-dark-corner-off);
}
[data-wb-theme='dark'] .wb-tag--status-primary.is-status-waiting,
[data-wb-theme='dark'] .wb-tag--status-primary.is-status-info {
  background: var(--wb-asset-wb-tag-dark-primary-waiting);
}
[data-wb-theme='dark'] .wb-tag--status-primary.is-status-success {
  background: var(--wb-asset-wb-tag-dark-primary-success);
}
[data-wb-theme='dark'] .wb-tag--status-primary.is-status-warning {
  background: var(--wb-asset-wb-tag-dark-primary-warning);
}
[data-wb-theme='dark'] .wb-tag--status-primary.is-status-alert {
  background: var(--wb-asset-wb-tag-dark-primary-alert);
}
[data-wb-theme='dark'] .wb-tag--status-primary.is-status-error {
  background: var(--wb-asset-wb-tag-dark-primary-error);
}
[data-wb-theme='dark'] .wb-tag--status-primary.is-status-none {
  background: var(--wb-asset-wb-tag-dark-primary-none);
}
.wb-tag.is-disabled {
  color: var(--wb-color-text-disabled);
}
.wb-tag.is-disabled .wb-tag__dot {
  background: var(--wb-color-icon-disabled);
}
.wb-tag--basic.is-disabled .wb-tag__icon,
.wb-tag--basic.is-disabled .wb-tag__action-icon {
  color: var(--wb-color-icon-disabled);
}
.wb-tag--status-primary.is-disabled .wb-tag__icon {
  color: var(--wb-asset-wb-tag-solid-light);
}
.wb-tag--status-primary.is-disabled.is-status-warning .wb-tag__icon {
  color: var(--wb-asset-wb-tag-solid-dark);
}
.wb-tag--status-primary.is-disabled.is-status-waiting,
.wb-tag--status-primary.is-disabled.is-status-info {
  background: var(--wb-asset-wb-tag-light-primary-waiting);
}
.wb-tag--status-primary.is-disabled.is-status-success {
  background: var(--wb-asset-wb-tag-light-primary-success);
}
.wb-tag--status-primary.is-disabled.is-status-warning {
  background: var(--wb-asset-wb-tag-light-primary-warning);
}
.wb-tag--status-primary.is-disabled.is-status-alert {
  background: var(--wb-asset-wb-tag-light-primary-alert);
}
.wb-tag--status-primary.is-disabled.is-status-error {
  background: var(--wb-asset-wb-tag-light-primary-error);
}
.wb-tag--status-primary.is-disabled.is-status-none {
  background: var(--wb-asset-wb-tag-light-primary-none);
}
[data-wb-theme='dark'] .wb-tag--status-primary.is-disabled.is-status-waiting,
[data-wb-theme='dark'] .wb-tag--status-primary.is-disabled.is-status-info {
  background: var(--wb-asset-wb-tag-dark-primary-waiting);
}
[data-wb-theme='dark'] .wb-tag--status-primary.is-disabled.is-status-success {
  background: var(--wb-asset-wb-tag-dark-primary-success);
}
[data-wb-theme='dark'] .wb-tag--status-primary.is-disabled.is-status-warning {
  background: var(--wb-asset-wb-tag-dark-primary-warning);
}
[data-wb-theme='dark'] .wb-tag--status-primary.is-disabled.is-status-alert {
  background: var(--wb-asset-wb-tag-dark-primary-alert);
}
[data-wb-theme='dark'] .wb-tag--status-primary.is-disabled.is-status-error {
  background: var(--wb-asset-wb-tag-dark-primary-error);
}
[data-wb-theme='dark'] .wb-tag--status-primary.is-disabled.is-status-none {
  background: var(--wb-asset-wb-tag-dark-primary-none);
}
</style>

<style scoped>
.wb-tag__remove,
.wb-tag__select {
  padding: 0;
  border: 0;
  background: transparent;
  font: inherit;
  cursor: pointer;
}
.wb-tag__select {
  color: inherit;
}
.wb-tag__select:focus-visible {
  outline: var(--wb-asset-wb-tag-border-width) solid var(--wb-color-border-focus);
  outline-offset: var(--wb-asset-wb-tag-focus-offset);
}
.wb-tag__select:disabled {
  color: var(--wb-color-icon-disabled);
  cursor: not-allowed;
}
</style>
