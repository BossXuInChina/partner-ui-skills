<script setup>
import { computed, nextTick, ref, watch } from 'vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import ChoiceMark from '../choice/ChoiceMark.vue';
import WorkbenchTooltip from '../tooltip/WorkbenchTooltip.vue';
import { optionColumns, selectionState } from './cascaderModel.js';
const props = defineProps({
  constrained: Boolean,
  options: { type: Array, required: true },
  index: { type: Map, required: true },
  path: { type: Array, required: true },
  selected: { type: Array, required: true },
  mode: { type: String, default: 'single' },
  columnSelection: {
    type: Array,
    default: () => [],
    validator: (values) => values.every((value) => ['single', 'multiple', 'none'].includes(value)),
  },
  label: { type: String, default: '级联选项' },
});
const emit = defineEmits(['expand', 'choose', 'toggle', 'close']);
const root = ref(null);
const focusKey = ref(null);
const focusedLabelKey = ref(null);
const hoveredLabelKey = ref(null);
const dismissedLabelKey = ref(null);
const columns = computed(() => optionColumns(props.options, props.path, props.index));
watch(columns, (visibleColumns) => {
  const visibleKeys = new Set(visibleColumns.flatMap((column) => column.map((item) => item.key)));
  for (const current of [focusedLabelKey, hoveredLabelKey, dismissedLabelKey])
    if (current.value !== null && !visibleKeys.has(current.value)) current.value = null;
});
function setTooltipHover(key, open) {
  if (open && dismissedLabelKey.value !== key) hoveredLabelKey.value = key;
  else if (!open && hoveredLabelKey.value === key) hoveredLabelKey.value = null;
}
function dismissLabel(key) {
  dismissedLabelKey.value = key;
  if (focusedLabelKey.value === key) focusedLabelKey.value = null;
  if (hoveredLabelKey.value === key) hoveredLabelKey.value = null;
}
function focusLabel(key) {
  focusKey.value = key;
  focusedLabelKey.value = dismissedLabelKey.value === key ? null : key;
}
function leaveLabel(key) {
  if (dismissedLabelKey.value === key) dismissedLabelKey.value = null;
}
function blurLabel(key) {
  if (focusedLabelKey.value === key) focusedLabelKey.value = null;
  if (dismissedLabelKey.value === key) dismissedLabelKey.value = null;
}
function entry(item) {
  return props.index.get(item.key);
}
function selectionMode(column) {
  return props.columnSelection[column] ?? props.mode;
}
function check(item) {
  if (props.columnSelection.length)
    return { checked: props.selected.includes(item.key), mixed: false };
  return selectionState(entry(item), props.index, props.selected);
}
function hasChildren(item) {
  return Boolean(item.children?.length);
}
function checkable(item, column) {
  const mode = selectionMode(column);
  return mode === 'multiple' || mode === 'all' || (mode === 'leaf' && !hasChildren(item));
}
function active(item, column) {
  return (
    props.path.includes(item.key) ||
    (selectionMode(column) === 'single' && props.selected.includes(item.key))
  );
}
function activate(item, column) {
  if (entry(item).disabled || item.type) return;
  dismissLabel(item.key);
  if (hasChildren(item)) emit('expand', item.key, column);
  else emit('choose', item.key);
}
function changeCheckbox(event, item) {
  emit('toggle', item.key);
  nextTick(() => {
    event.target.checked = check(item).checked;
    event.target.indeterminate = check(item).mixed;
  });
}
function focusItem(key) {
  focusKey.value = key;
  nextTick(() =>
    [...(root.value?.querySelectorAll('[role="treeitem"]') ?? [])]
      .find((el) => el.dataset.key === String(key))
      ?.focus(),
  );
}
function columnItems(column) {
  return columns.value[column].filter((item) => !entry(item).disabled && !item.type);
}
function step(item, column, delta) {
  const items = columnItems(column);
  const next = Math.max(
    0,
    Math.min(items.length - 1, items.findIndex((node) => node.key === item.key) + delta),
  );
  if (items[next]) focusItem(items[next].key);
}
function keydown(event, item, column) {
  const key = event.key;
  if (
    ![
      'ArrowDown',
      'ArrowUp',
      'ArrowLeft',
      'ArrowRight',
      'Home',
      'End',
      'Enter',
      ' ',
      'Escape',
    ].includes(key)
  )
    return;
  event.preventDefault();
  event.stopPropagation();
  if (key === 'Escape') return emit('close');
  if (key === 'ArrowDown' || key === 'ArrowUp')
    return step(item, column, key === 'ArrowDown' ? 1 : -1);
  if (key === 'Home' || key === 'End') {
    const items = columnItems(column);
    const target = key === 'Home' ? items[0] : items.at(-1);
    if (target) focusItem(target.key);
    return;
  }
  if (key === 'ArrowLeft' && column > 0) return focusItem(props.path[column - 1]);
  if (key === 'ArrowRight' && hasChildren(item)) {
    dismissLabel(item.key);
    emit('expand', item.key, column);
    nextTick(() => {
      const first = item.children.find((node) => !entry(node).disabled && !node.type);
      if (first) focusItem(first.key);
    });
    return;
  }
  if (key === ' ' && checkable(item, column)) return emit('toggle', item.key);
  if (key === 'Enter' || key === ' ') activate(item, column);
}
function focusFirst() {
  const first = columnItems(0)[0];
  if (first) focusItem(first.key);
}
defineExpose({ focusFirst });
</script>

<template>
  <div
    ref="root"
    class="wb-cascader-panel"
    :class="{ 'is-constrained': constrained }"
    role="tree"
    :aria-label="label"
    :aria-multiselectable="columnSelection.includes('multiple') || mode !== 'single' || undefined"
  >
    <div
      v-if="!options.length"
      class="wb-cascader-panel__empty"
      role="status"
    >
      暂无数据
    </div>
    <div
      v-for="(column, columnIndex) in columns"
      v-else
      :key="columnIndex"
      class="wb-cascader-panel__column"
      role="group"
      :aria-label="`第${columnIndex + 1}级`"
    >
      <template
        v-for="item in column"
        :key="item.key"
      >
        <div
          v-if="item.type === 'divider'"
          class="wb-cascader-panel__divider"
          role="separator"
        />
        <div
          v-else-if="item.type === 'group'"
          class="wb-cascader-panel__group"
        >
          {{ item.label }}
        </div>
        <div
          v-else
          class="wb-cascader-panel__option"
          :class="{ 'is-active': active(item, columnIndex), 'is-disabled': entry(item).disabled }"
          role="treeitem"
          :aria-label="columnSelection.length ? item.label : undefined"
          :data-key="item.key"
          :aria-level="columnIndex + 1"
          :aria-expanded="hasChildren(item) ? props.path.includes(item.key) : undefined"
          :aria-selected="
            selectionMode(columnIndex) === 'single' ? selected.includes(item.key) : undefined
          "
          :aria-checked="
            checkable(item, columnIndex)
              ? check(item).mixed
                ? 'mixed'
                : check(item).checked
              : undefined
          "
          :aria-disabled="entry(item).disabled || undefined"
          :tabindex="
            entry(item).disabled
              ? -1
              : focusKey === item.key || (!focusKey && columnItems(0)[0]?.key === item.key)
                ? 0
                : -1
          "
          @click="activate(item, columnIndex)"
          @pointerdown="dismissLabel(item.key)"
          @pointerleave="leaveLabel(item.key)"
          @focus="focusLabel(item.key)"
          @blur="blurLabel(item.key)"
          @keydown="keydown($event, item, columnIndex)"
        >
          <label
            v-if="checkable(item, columnIndex)"
            class="wb-cascader-panel__checkbox"
            @click.stop
          >
            <input
              type="checkbox"
              :aria-label="`选择${item.label}`"
              :checked="check(item).checked"
              :indeterminate="check(item).mixed"
              :disabled="entry(item).disabled"
              tabindex="-1"
              @change="changeCheckbox($event, item)"
            />
            <ChoiceMark
              :checked="check(item).checked"
              :indeterminate="check(item).mixed"
              :disabled="entry(item).disabled"
            />
          </label>
          <span class="wb-cascader-panel__label"
            ><WorkbenchTooltip
              :content="item.label"
              :open="
                dismissedLabelKey !== item.key &&
                (focusedLabelKey === item.key || hoveredLabelKey === item.key)
              "
              overflow-only
              placement="top-start"
              @update:open="setTooltipHover(item.key, $event)"
              ><template #trigger="{ aria }"
                ><span
                  class="wb-cascader-panel__text"
                  v-bind="aria"
                  >{{ item.label }}</span
                ></template
              ></WorkbenchTooltip
            ></span
          >
          <span
            v-if="item.description"
            class="wb-cascader-panel__description"
            :title="item.description"
            >{{ item.description }}</span
          >
          <WorkbenchIcon
            v-if="hasChildren(item)"
            name="箭头/尺寸=10, 方向=右箭头"
            :size="10"
            :color="
              entry(item).disabled
                ? 'var(--wb-color-icon-disabled)'
                : 'var(--wb-color-icon-primary)'
            "
          />
          <WorkbenchIcon
            v-else-if="selectionMode(columnIndex) === 'single' && selected.includes(item.key)"
            name="完成_14px"
            color="var(--wb-color-icon-primary)"
          />
        </div>
      </template>
    </div>
  </div>
</template>

<style scoped>
.wb-cascader-panel {
  box-sizing: border-box;
  display: flex;
  align-items: flex-start;
  gap: var(--wb-asset-wb-cascader-column-gap);
  padding: var(--wb-asset-wb-cascader-panel-padding);
  width: max-content;
  max-width: var(
    --wb-cascader-panel-max-width,
    calc(100vw - var(--wb-asset-wb-cascader-viewport-edge) * 2)
  );
  overflow: auto;
  border: 0;
  border-radius: var(--wb-asset-wb-cascader-panel-radius);
  background: var(--wb-color-surface-overlay);
  color: var(--wb-color-text-primary);
  box-shadow: var(--wb-shadow-base);
  font-family: inherit;
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
  line-height: var(--wb-font-body-m-line-height);
}
.wb-cascader-panel.is-constrained {
  max-width: none;
  overflow-x: visible;
}
.wb-cascader-panel__column {
  display: flex;
  flex-direction: column;
  flex: 0 0 var(--cascader-panel-column-width, var(--wb-asset-wb-cascader-column));
  gap: var(--wb-asset-wb-cascader-row-gap);
  max-height: var(--cascader-panel-max-height, var(--wb-asset-wb-cascader-max-height));
  overflow-y: auto;
}
.wb-cascader-panel__option,
.wb-cascader-panel__group {
  display: flex;
  box-sizing: border-box;
  align-items: center;
  flex: none;
  gap: var(--wb-asset-wb-cascader-option-gap);
  height: var(--wb-asset-wb-cascader-row);
  padding-inline: var(--wb-asset-wb-cascader-option-padding);
  border-radius: var(--wb-radius-sm);
  cursor: pointer;
}
.wb-cascader-panel__option:hover,
.wb-cascader-panel__option.is-active {
  background: var(--wb-color-fill-selected);
}
.wb-cascader-panel__option:focus-visible {
  outline: var(--wb-asset-wb-cascader-border) solid var(--wb-color-border-focus);
  outline-offset: calc(-1 * var(--wb-asset-wb-cascader-border));
}
.wb-cascader-panel__option.is-disabled {
  color: var(--wb-color-text-disabled);
  cursor: not-allowed;
  background: transparent;
}
.wb-cascader-panel__label {
  flex: 1;
  min-width: 0;
}
.wb-cascader-panel__label :deep(.wb-tooltip-debug) {
  display: flex;
  width: 100%;
}
.wb-cascader-panel__text {
  display: block;
  min-width: 0;
  width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.wb-cascader-panel__description {
  flex: 2;
  min-width: 0;
  color: var(--wb-color-text-placeholder);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.wb-cascader-panel__group {
  color: var(--wb-color-text-placeholder);
  cursor: default;
}
.wb-cascader-panel__divider {
  flex: none;
  height: var(--wb-asset-wb-cascader-border);
  background: var(--wb-color-border-separator);
  margin-bottom: var(--wb-asset-wb-cascader-row-gap);
}
.wb-cascader-panel__checkbox {
  display: inline-flex;
  position: relative;
  flex: none;
  cursor: inherit;
}
.wb-cascader-panel__checkbox :deep(.wb-choice-mark) {
  align-self: center;
  margin-block-start: 0;
}
.wb-cascader-panel__checkbox input {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  margin: 0;
  opacity: 0;
  cursor: inherit;
}
.wb-cascader-panel__empty {
  width: var(--cascader-panel-column-width, var(--wb-asset-wb-cascader-column));
  padding: var(--wb-asset-wb-cascader-option-padding);
  color: var(--wb-color-text-placeholder);
}
</style>
