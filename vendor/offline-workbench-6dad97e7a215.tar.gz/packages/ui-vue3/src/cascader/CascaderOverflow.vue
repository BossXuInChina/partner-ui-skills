<script setup>
import { nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue';
import WorkbenchTag from '../tag/WorkbenchTag.vue';
import PopoverArrow from '../popover/PopoverArrow.vue';

const props = defineProps({
  id: { type: String, required: true },
  anchor: { type: Object, required: true },
  items: { type: Array, required: true },
  removable: Boolean,
});
const emit = defineEmits(['remove', 'dismiss', 'focusout']);
const panel = ref(null);
const content = ref(null);
let observer;
function removeItem(item) {
  // Transfer focus before removing its DOM node, so focusout does not dismiss
  // the bubble and keyboard users can continue through the remaining tags.
  const buttons = [...content.value.querySelectorAll('button:not(:disabled)')];
  const index = buttons.indexOf(document.activeElement);
  if (index >= 0) {
    const next = buttons[index + 1] || buttons[index - 1] || props.anchor.querySelector('button');
    next?.focus({ preventScroll: true });
  }
  emit('remove', [item.key]);
}
function dismiss() {
  props.anchor.querySelector('button')?.focus({ preventScroll: true });
  emit('dismiss');
}
function position() {
  if (!panel.value || !props.anchor) return;
  const styles = getComputedStyle(props.anchor);
  for (const property of styles) {
    if (property.startsWith('--wb-'))
      panel.value.style.setProperty(property, styles.getPropertyValue(property));
  }
  panel.value.style.fontFamily = styles.fontFamily;
  const token = (name) =>
    parseFloat(styles.getPropertyValue(`--wb-asset-wb-cascader-${name}`));
  const edge = token('viewport-edge');
  const popoverToken = (name) =>
    parseFloat(styles.getPropertyValue(`--wb-asset-wb-popover-${name}`));
  const arrowWidth = popoverToken('arrow-width');
  const gap = popoverToken('arrow-height') - popoverToken('arrow-overlap') + popoverToken('trigger-gap');
  const widthLimit = Math.min(token('tip-width'), window.innerWidth - edge * 2);
  const padding = parseFloat(styles.getPropertyValue('--wb-spacing-component-xs'));
  const spacing = padding;
  panel.value.style.width = `${widthLimit}px`;
  const available = widthLimit - padding * 2;
  let rowWidth = 0, widest = 0;
  for (const tag of content.value.children) {
    const width = tag.getBoundingClientRect().width;
    const next = rowWidth ? rowWidth + spacing + width : width;
    if (rowWidth && next > available) { widest = Math.max(widest, rowWidth); rowWidth = width; }
    else rowWidth = next;
  }
  panel.value.style.width = `${Math.min(widthLimit, Math.ceil(Math.max(widest, rowWidth) + padding * 2))}px`;
  panel.value.style.maxWidth = `${widthLimit}px`;
  const anchor = props.anchor.getBoundingClientRect();
  const limit = Math.max(0, window.innerHeight - edge * 2);
  const aboveSpace = Math.max(0, Math.min(limit, anchor.top - gap - edge));
  const belowSpace = Math.max(0, Math.min(limit, window.innerHeight - edge - anchor.bottom - gap));
  const height = content.value.scrollHeight;
  const useAbove = height <= aboveSpace || (height > belowSpace && aboveSpace >= belowSpace);
  content.value.style.maxHeight = `${useAbove ? aboveSpace : belowSpace}px`;
  const box = panel.value.getBoundingClientRect();
  const preferred = useAbove ? anchor.top - gap - box.height : anchor.bottom + gap;
  const top = Math.max(edge, Math.min(preferred, window.innerHeight - edge - box.height));
  const left = Math.max(edge, Math.min(anchor.left + anchor.width / 2 - box.width / 2, window.innerWidth - edge - box.width));
  panel.value.dataset.placement = useAbove ? 'top' : 'bottom';
  const arrowLeft = Math.max(0, Math.min(box.width - arrowWidth, anchor.left + anchor.width / 2 - left - arrowWidth / 2));
  panel.value.style.setProperty('--cascader-overflow-arrow-left', `${arrowLeft}px`);
  panel.value.style.top = `${top}px`;
  panel.value.style.left = `${left}px`;
}
watch(() => [props.items, props.removable], () => nextTick(position), { deep: true });
onMounted(() => {
  observer = new ResizeObserver(position);
  observer.observe(panel.value);
  observer.observe(props.anchor);
  window.addEventListener('resize', position);
  window.addEventListener('scroll', position, true);
  nextTick(position);
});
onBeforeUnmount(() => {
  observer?.disconnect();
  window.removeEventListener('resize', position);
  window.removeEventListener('scroll', position, true);
});
defineExpose({ contains: (target) => panel.value?.contains(target) });
</script>

<template>
  <Teleport to="body">
    <div
      ref="panel"
      class="wb-cascader__overflow-bubble"
      :class="{ 'is-removable': removable }"
      :data-overlay-kind="removable ? 'popover' : 'tooltip'"
      @mouseleave="emit('dismiss')"
      @focusout="emit('focusout', $event)"
      @keydown.esc.stop.prevent="dismiss"
    >
      <div
        :id="id"
        ref="content"
        class="wb-cascader__overflow-details"
        :role="removable ? 'group' : 'tooltip'"
        :aria-label="removable ? '超出部分已选项' : undefined"
      >
        <WorkbenchTag
          v-for="item in items"
          :key="item.key"
          :label="item.label"
          :action="removable ? 'remove' : 'none'"
          :disabled="item.disabled"
          @remove="removeItem(item)"
        />
      </div>
      <PopoverArrow class="wb-cascader__overflow-arrow" />
    </div>
  </Teleport>
</template>

<style scoped>
.wb-cascader__overflow-bubble {
  position: fixed;
  z-index: var(--wb-asset-wb-cascader-layer);
  width: max-content;
  max-width: var(--wb-asset-wb-cascader-tip-width);
  border-radius: var(--wb-radius-sm);
  box-shadow: var(--wb-shadow-base);
}
.wb-cascader__overflow-bubble.is-removable {
  border-radius: var(--wb-radius-md);
}
.wb-cascader__overflow-details {
  display: flex;
  flex-wrap: wrap;
  gap: var(--wb-spacing-component-xs);
  align-items: center;
  width: 100%;
  box-sizing: border-box;
  padding: var(--wb-asset-wb-cascader-inset);
  overflow: auto;
  overscroll-behavior: contain;
  border-radius: inherit;
  background: var(--wb-color-surface-overlay);
}
.wb-cascader__overflow-arrow {
  position: absolute;
  display: block;
  left: var(--cascader-overflow-arrow-left);
  width: var(--wb-asset-wb-popover-arrow-width);
  height: var(--wb-asset-wb-popover-arrow-height);
}
.wb-cascader__overflow-bubble[data-placement='top'] .wb-cascader__overflow-arrow {
  bottom: calc(-1 * var(--wb-asset-wb-popover-arrow-height) + var(--wb-asset-wb-popover-arrow-overlap));
}
.wb-cascader__overflow-bubble[data-placement='bottom'] .wb-cascader__overflow-arrow {
  top: calc(-1 * var(--wb-asset-wb-popover-arrow-height) + var(--wb-asset-wb-popover-arrow-overlap));
  transform: rotate(180deg);
}
</style>
