export function indexOptions(options) {
  const entries = new Map();
  function visit(items, path = [], disabled = false) {
    for (const item of items) {
      const entry = { ...item, path: [...path, item.key], disabled: disabled || item.disabled };
      entries.set(item.key, entry);
      if (item.children?.length) visit(item.children, entry.path, entry.disabled);
    }
  }
  visit(options);
  return entries;
}

export function selectableLeaves(entry, index) {
  if (!entry || entry.disabled || entry.type) return [];
  if (!entry.children?.length) return [entry.key];
  return entry.children.flatMap((child) => selectableLeaves(index.get(child.key), index));
}

export function selectionState(entry, index, selected) {
  if (entry.disabled && !entry.children?.length)
    return { checked: selected.includes(entry.key), mixed: false };
  const leaves = selectableLeaves(entry, index);
  const count = leaves.filter((key) => selected.includes(key)).length;
  return {
    checked: leaves.length > 0 && count === leaves.length,
    mixed: count > 0 && count < leaves.length,
  };
}

export function optionColumns(options, path, index) {
  const columns = [options];
  for (const key of path) {
    const entry = index.get(key);
    if (
      !columns.at(-1).some((item) => item.key === key) ||
      !entry?.children?.length ||
      entry.disabled
    )
      break;
    columns.push(entry.children);
  }
  return columns;
}

export function createCascaderOptions({ depth = 3, long = false, disabled = false } = {}) {
  function level(current, prefix = '') {
    return Array.from({ length: 4 }, (_, n) => {
      const key = prefix ? `${prefix}-${n + 1}` : `r${n + 1}`;
      return {
        key,
        label:
          long && n === 1 ? '龙岗区在该场景下为超长选项进行展示未展示部分请使用省略号' : '选项文本',
        disabled: disabled && n === 1,
        ...(current < depth ? { children: level(current + 1, key) } : {}),
      };
    });
  }
  return level(1);
}
