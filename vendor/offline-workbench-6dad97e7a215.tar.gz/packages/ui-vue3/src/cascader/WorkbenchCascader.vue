<script setup>
import { useFormDisabled } from '../form/useFormDisabled.js';
import '../shared/disclosure-motion.css';
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import { computed, nextTick, onBeforeUnmount, onMounted, ref, useId, watch } from 'vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import WorkbenchTag from '../tag/WorkbenchTag.vue';
import CascaderPanel from './CascaderPanel.vue';
import CascaderOverflow from './CascaderOverflow.vue';
import { indexOptions, selectableLeaves } from './cascaderModel.js';

const props = defineProps({
  options: { type: Array, required: true },
  modelValue: { type: [String, Number, Array], default: undefined },
  defaultValue: { type: [String, Number, Array], default: null },
  mode: {
    type: String,
    default: 'single',
    validator: (value) => ['single', 'leaf', 'all'].includes(value),
  },
  size: { type: String, default: 'medium' },
  disabled: Boolean,
  label: { type: String, default: '级联选择器' },
  placeholder: { type: String, default: '请选择' },
  open: { type: Boolean, default: undefined },
  defaultOpen: Boolean,
  defaultExpandedKeys: { type: Array, default: () => [] },
  inlinePanel: Boolean,
  clearable: Boolean,
  tagRemovable: Boolean,
});
const disabled = useFormDisabled(() => props.disabled);
const emit = defineEmits([
  'update:modelValue',
  'update:open',
  'change',
  'expand',
  'remove',
  'clear',
]);
const id = useId();
const overflowPanel = ref(null);
const overflowAnchor = ref(null);
const root = ref(null),
  trigger = ref(null),
  values = ref(null),
  popup = ref(null),
  panel = ref(null),
  measure = ref(null);
const localValue = ref(props.defaultValue);
const localOpen = ref(props.defaultOpen);
const path = ref([...props.defaultExpandedKeys]);
const visibleCount = ref(0),
  overflowHover = ref(false);
const index = computed(() => indexOptions(props.options));
const multiple = computed(() => props.mode !== 'single');
const value = computed(() =>
  props.modelValue === undefined ? localValue.value : props.modelValue,
);
const selected = computed(() => {
  const keys = Array.isArray(value.value) ? value.value : value.value == null ? [] : [value.value];
  return [...new Set(keys)].filter((key) => {
    const item = index.value.get(key);
    return item && !item.type && !item.children?.length;
  });
});
const selectedItems = computed(() => selected.value.map((key) => index.value.get(key)));
const expanded = computed(
  () => !disabled.value && (props.open === undefined ? localOpen.value : props.open),
);
const visibleItems = computed(() => selectedItems.value.slice(0, visibleCount.value));
const hiddenItems = computed(() => selectedItems.value.slice(visibleCount.value));
let resizeObserver;

function setOpen(next) {
  if (disabled.value) return;
  if (props.open === undefined) localOpen.value = next;
  emit('update:open', next);
}
function publish(keys) {
  const next = multiple.value ? keys : (keys[0] ?? null);
  if (props.modelValue === undefined) localValue.value = next;
  emit('update:modelValue', next);
  emit(
    'change',
    next,
    keys.map((key) => index.value.get(key)?.path ?? []),
  );
}
function expand(key, column) {
  path.value = [...path.value.slice(0, column), key];
  emit('expand', key, [...path.value]);
}
function choose(key) {
  const item = index.value.get(key);
  if (!item || item.disabled || item.type || item.children?.length) return;
  if (multiple.value) toggle(key);
  else {
    publish([key]);
    path.value = item.path.slice(0, -1);
    setOpen(false);
    trigger.value?.focus();
  }
}
function toggle(key) {
  if (disabled.value) return;
  const leaves = selectableLeaves(index.value.get(key), index.value);
  if (!leaves.length) return;
  const remove = leaves.every((leaf) => selected.value.includes(leaf));
  const result = new Set(selected.value);
  leaves.forEach((leaf) => (remove ? result.delete(leaf) : result.add(leaf)));
  publish([...index.value.keys()].filter((leaf) => result.has(leaf)));
}
function removeKeys(keys) {
  if (disabled.value) return;
  const removable = keys.filter((key) => !index.value.get(key)?.disabled);
  publish(selected.value.filter((key) => !removable.includes(key)));
  emit('remove', removable);
}
function clear() {
  removeKeys(selected.value);
  emit('clear');
}
function close() {
  setOpen(false);
  trigger.value?.focus();
}
function keydown(event) {
  if (disabled.value) return;
  if (['ArrowDown', 'ArrowUp', 'Enter', ' '].includes(event.key)) {
    event.preventDefault();
    setOpen(true);
    nextTick(() => panel.value?.focusFirst());
  } else if (event.key === 'Escape') {
    event.preventDefault();
    close();
  } else if (
    event.key === 'Backspace' &&
    props.tagRemovable &&
    multiple.value &&
    selected.value.length
  ) {
    event.preventDefault();
    removeKeys(selected.value.slice(-1));
  }
}
function fitTags() {
  if (!values.value || !measure.value) return;
  const tags = [...measure.value.querySelectorAll('[data-measure-tag]')];
  const gap = parseFloat(getComputedStyle(values.value).gap) || 0;
  const available = values.value.clientWidth;
  let count = tags.length;
  while (count > 0) {
    const widths = tags
      .slice(0, count)
      .reduce((sum, el) => sum + el.getBoundingClientRect().width, 0);
    const hidden = tags.length - count;
    const overflow = hidden
      ? measure.value.querySelector('[data-measure-overflow]').getBoundingClientRect().width
      : 0;
    if (widths + Math.max(0, count - 1) * gap + (hidden ? gap + overflow : 0) <= available) break;
    count -= 1;
  }
  visibleCount.value = count;
}
function positionPopup() {
  if (!expanded.value || props.inlinePanel || !popup.value || !trigger.value) return;
  const rect = trigger.value.getBoundingClientRect();
  const style = getComputedStyle(root.value);
  for (const name of style)
    if (name.startsWith('--wb-')) popup.value.style.setProperty(name, style.getPropertyValue(name));
  popup.value.style.fontFamily = style.fontFamily;
  const edge = parseFloat(style.getPropertyValue('--wb-asset-wb-cascader-viewport-edge')) || 8;
  const gap = parseFloat(style.getPropertyValue('--wb-asset-wb-cascader-popup-gap')) || 4;
  const box = popup.value.getBoundingClientRect();
  // Keep the trigger anchor stable as columns grow; additional columns scroll inside.
  const left = Math.max(
    edge,
    Math.min(
      rect.left,
      window.innerWidth - Math.min(rect.width, window.innerWidth - edge * 2) - edge,
    ),
  );
  popup.value.style.left = `${left}px`;
  popup.value.style.maxWidth = `${Math.max(0, window.innerWidth - left - edge)}px`;
  popup.value.style.top = `${rect.bottom + gap + box.height > window.innerHeight - edge && rect.top > box.height ? rect.top - box.height - gap : rect.bottom + gap}px`;
  popup.value.style.maxHeight = `${Math.max(0, window.innerHeight - edge * 2)}px`;
}
function within(target) {
  return (
    root.value?.contains(target) ||
    popup.value?.contains(target) ||
    overflowPanel.value?.contains(target)
  );
}
function outside(event) {
  if (!within(event.target)) {
    setOpen(false);
    overflowHover.value = false;
  }
}
function focusout(event) {
  if (!within(event.relatedTarget)) {
    setOpen(false);
    overflowHover.value = false;
  }
}
watch([selected, () => props.mode, () => props.tagRemovable], () => nextTick(fitTags));
watch(
  expanded,
  (next) => {
    if (next && !path.value.length && selected.value.length)
      path.value = index.value.get(selected.value[0]).path.slice(0, -1);
    nextTick(positionPopup);
  },
  { immediate: true },
);
watch(path, () =>
  nextTick(() => {
    positionPopup();
    if (popup.value) popup.value.scrollLeft = popup.value.scrollWidth;
  }),
);
watch(index, () => {
  path.value = path.value.filter((key) => index.value.has(key));
});
onMounted(() => {
  resizeObserver = new ResizeObserver(() => {
    fitTags();
    positionPopup();
  });
  if (values.value) resizeObserver.observe(values.value);
  if (measure.value) resizeObserver.observe(measure.value);
  document.addEventListener('pointerdown', outside);
  window.addEventListener('resize', positionPopup);
  window.addEventListener('scroll', positionPopup, true);
  nextTick(() => {
    fitTags();
    positionPopup();
  });
});
onBeforeUnmount(() => {
  resizeObserver?.disconnect();
  document.removeEventListener('pointerdown', outside);
  window.removeEventListener('resize', positionPopup);
  window.removeEventListener('scroll', positionPopup, true);
});
defineExpose({ focus: () => trigger.value?.focus(), close });
watch(disabled, (value) => {
  if (value) {
    localOpen.value = false;
    overflowHover.value = false;
  }
});
</script>

<template>
  <div
    ref="root"
    class="wb-cascader"
    :class="[
      `wb-cascader--${size}`,
      {
        'is-disabled': disabled,
        'is-open': expanded,
        'is-multiple': multiple && selected.length,
        'is-inline': inlinePanel,
      },
    ]"
    @focusout="focusout"
  >
    <div
      ref="trigger"
      class="wb-cascader__trigger"
      role="combobox"
      :tabindex="disabled ? -1 : 0"
      :aria-label="label"
      :aria-disabled="disabled || undefined"
      aria-haspopup="tree"
      :aria-expanded="expanded"
      :aria-controls="expanded ? `${id}-panel` : undefined"
      @click="setOpen(!expanded)"
      @keydown.self="keydown"
    >
      <div
        ref="values"
        class="wb-cascader__values"
      >
        <span
          v-if="!selected.length"
          class="wb-cascader__placeholder"
          >{{ placeholder }}</span
        >
        <template v-else-if="multiple">
          <WorkbenchTag
            v-for="item in visibleItems"
            :key="item.key"
            :label="item.label"
            :action="tagRemovable ? 'remove' : 'none'"
            :disabled="disabled || item.disabled"
            @click.stop
            @remove="removeKeys([item.key])"
          />
          <span
            v-if="hiddenItems.length"
            ref="overflowAnchor"
            class="wb-cascader__overflow-group wb-tag-surface"
          >
            <button
              v-if="hiddenItems.length"
              type="button"
              class="wb-cascader__overflow"
              :disabled="disabled"
              :aria-label="`另有${hiddenItems.length}个已选项`"
              :aria-expanded="overflowHover"
              :aria-controls="`${id}-overflow`"
              :aria-describedby="!tagRemovable && overflowHover ? `${id}-overflow` : undefined"
              @click.stop="overflowHover = true"
              @mouseenter="overflowHover = true"
              @focus="overflowHover = true"
              @keydown.esc.stop.prevent="overflowHover = false"
              @keydown.stop
            >
              +{{ hiddenItems.length }}
            </button>
            <button
              v-if="tagRemovable"
              class="wb-tag-surface__remove"
              type="button"
              aria-label="清除超出部分已选项"
              :disabled="disabled || hiddenItems.every((item) => item.disabled)"
              @click.stop="removeKeys(hiddenItems.map((item) => item.key))"
              @keydown.stop
            >
              <WorkbenchIcon name="/ic_public_close_line_8px" />
            </button>
          </span>
        </template>
        <span
          v-else
          class="wb-cascader__text"
          :title="selectedItems[0].label"
          >{{ selectedItems[0].label }}</span
        >
      </div>
      <button
        v-if="clearable && selected.length"
        class="wb-cascader__clear"
        type="button"
        aria-label="清空已选项"
        :disabled="disabled"
        @click.stop="clear"
        @keydown.stop
      >
        <WorkbenchIcon name="/ic_public_close_line_10px" />
      </button>
      <WorkbenchIcon
        class="wb-cascader__arrow wb-disclosure-icon"
        :class="{ 'is-expanded': expanded }"
        name="箭头/尺寸=10, 方向=下箭头"
        :size="10"
        :color="disabled ? 'var(--wb-color-icon-disabled)' : 'var(--wb-color-icon-primary)'"
      />
    </div>
    <div
      v-if="multiple"
      ref="measure"
      class="wb-cascader__measure"
      aria-hidden="true"
    >
      <WorkbenchTag
        v-for="item in selectedItems"
        :key="item.key"
        :label="item.label"
        :action="tagRemovable ? 'remove' : 'none'"
        data-measure-tag
      /><WorkbenchTag
        :label="`+${selectedItems.length}`"
        :action="tagRemovable ? 'remove' : 'none'"
        data-measure-overflow
      />
    </div>
    <CascaderOverflow
      v-if="overflowHover && hiddenItems.length && !disabled"
      :id="`${id}-overflow`"
      ref="overflowPanel"
      :anchor="overflowAnchor"
      :items="hiddenItems"
      :removable="tagRemovable"
      @remove="removeKeys"
      @dismiss="overflowHover = false"
      @focusout="focusout"
    />
    <Teleport
      to="body"
      :disabled="inlinePanel"
    >
      <div
        v-if="expanded"
        :id="`${id}-panel`"
        ref="popup"
        class="wb-cascader__popup"
        :class="{ 'is-portalled': !inlinePanel }"
        @focusout="focusout"
      >
        <CascaderPanel
          ref="panel"
          :constrained="!inlinePanel"
          :options="options"
          :index="index"
          :path="path"
          :selected="selected"
          :mode="mode"
          :label="`${label}选项`"
          @expand="expand"
          @choose="choose"
          @toggle="toggle"
          @close="close"
        />
      </div>
    </Teleport>
  </div>
</template>

<style scoped>
.wb-cascader {
  position: relative;
  width: var(--wb-asset-wb-cascader-width);
  max-width: 100%;
  color: var(--wb-color-text-primary);
  font-family: inherit;
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
  line-height: var(--wb-font-body-m-line-height);
}
.wb-cascader.is-inline {
  width: max-content;
  max-width: var(--wb-cascader-inline-max-width, 100%);
}
.wb-cascader__trigger {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  gap: var(--wb-asset-wb-cascader-option-gap);
  width: var(--wb-asset-wb-cascader-width);
  max-width: 100%;
  height: var(--wb-asset-wb-cascader-height-medium);
  padding-inline: var(--wb-asset-wb-cascader-input-padding);
  border: var(--wb-asset-wb-cascader-border) solid var(--wb-color-border);
  border-radius: var(--wb-radius-sm);
  background: var(--wb-color-fill-subtle-default);
  cursor: pointer;
  outline: none;
}
.wb-cascader--small .wb-cascader__trigger {
  height: var(--wb-asset-wb-cascader-height-small);
}
.wb-cascader--large .wb-cascader__trigger {
  height: var(--wb-asset-wb-cascader-height-large);
}
.wb-cascader__trigger:hover {
  border-color: var(--wb-color-border-hover);
}
.wb-cascader__trigger:focus-visible,
.is-open .wb-cascader__trigger {
  border-color: var(--wb-color-border-focus);
}
.is-disabled .wb-cascader__trigger {
  background: var(--wb-color-fill-subtle-disabled);
  border-color: transparent;
  color: var(--wb-color-text-disabled);
  cursor: not-allowed;
}
.is-multiple .wb-cascader__trigger {
  padding-left: var(--wb-asset-wb-cascader-inset);
}
.wb-cascader__values {
  display: flex;
  flex: 1;
  align-items: center;
  gap: var(--wb-asset-wb-cascader-option-gap);
  min-width: 0;
  overflow: hidden;
}
.wb-cascader__placeholder {
  color: var(--wb-color-text-placeholder);
}
.is-disabled .wb-cascader__placeholder {
  color: var(--wb-color-text-disabled);
}
.wb-cascader__text {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.wb-cascader__measure {
  position: absolute;
  display: flex;
  width: max-content;
  visibility: hidden;
  pointer-events: none;
}
.wb-cascader__overflow {
  font: inherit;
}
.wb-cascader__overflow-group {
  color: inherit;
}
.wb-cascader__overflow,
.wb-cascader__clear {
  appearance: none;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex: none;
  border: 0;
  padding: 0;
  background: transparent;
  font: inherit;
  color: var(--wb-color-icon-primary);
  cursor: pointer;
}
.wb-cascader__overflow:disabled,
.wb-cascader__clear:disabled {
  color: var(--wb-color-icon-disabled);
  cursor: not-allowed;
}
.wb-cascader__overflow:focus-visible,
.wb-cascader__clear:focus-visible {
  outline: var(--wb-asset-wb-cascader-border) solid var(--wb-color-border-focus);
}
.wb-cascader__popup {
  padding-top: var(--wb-asset-wb-cascader-popup-gap);
}
.wb-cascader__popup.is-portalled {
  position: fixed;
  z-index: var(--wb-asset-wb-cascader-layer);
  padding-top: 0;
  overflow: auto;
  border-radius: var(--wb-asset-wb-cascader-panel-radius);
  box-shadow: var(--wb-shadow-base);
}
</style>
