<script setup>
import { computed, useSlots } from 'vue';
import '../../../../catalog/generated/asset.tokens.css';

const props = defineProps({
  href: { type: String, required: true },
  target: { type: String, default: undefined },
  rel: { type: String, default: undefined },
  disabled: { type: Boolean, default: false },
});
const emit = defineEmits(['click']);
const slots = useSlots();
const isDisabled = computed(() => props.disabled);

function handleClick(event) {
  if (isDisabled.value) {
    event.preventDefault();
    event.stopImmediatePropagation();
    return;
  }
  emit('click', event);
}
</script>

<template>
  <a
    class="wb-link"
    :href="isDisabled ? undefined : href"
    :target="target"
    :rel="rel"
    :aria-disabled="isDisabled ? 'true' : undefined"
    :tabindex="isDisabled ? -1 : undefined"
    @click="handleClick"
  >
    <span
      v-if="slots.icon"
      class="wb-link__icon"
      aria-hidden="true"
      ><slot name="icon"
    /></span>
    <span class="wb-link__label"><slot /></span>
  </a>
</template>

<style>
.wb-link {
  display: inline-flex;
  width: fit-content;
  align-items: center;
  gap: var(--wb-spacing-component-xs);
  padding: 0;
  color: var(--wb-color-link);
  background: transparent;
  border: 0;
  border-radius: var(--wb-radius-sm);
  font-family: inherit;
  font-size: inherit;
  font-weight: inherit;
  line-height: inherit;
  letter-spacing: inherit;
  text-decoration-line: none;
  text-decoration-thickness: var(--wb-asset-wb-link-underline-thickness);
  text-underline-offset: var(--wb-asset-wb-link-underline-offset);
  cursor: pointer;
}

.wb-link__icon {
  display: inline-grid;
  width: var(--wb-icon-size-12);
  height: var(--wb-icon-size-12);
  flex: 0 0 var(--wb-icon-size-12);
  place-items: center;
  color: currentColor;
}

.wb-link__icon :is(svg, img) {
  display: block;
  width: 100%;
  height: 100%;
}

.wb-link__icon svg {
  fill: none;
  stroke: currentColor;
}

.wb-link:hover,
.wb-link.is-hover {
  color: var(--wb-color-link-hover);
  text-decoration-line: underline;
}

.wb-link:active,
.wb-link.is-pressed {
  color: var(--wb-color-link-active);
  text-decoration-line: underline;
}

.wb-link:focus-visible,
.wb-link.is-focus {
  text-decoration-line: underline;
  outline: var(--wb-asset-wb-link-focus-outline-width) solid var(--wb-color-border-focus);
  outline-offset: var(--wb-asset-wb-link-focus-outline-offset);
}

.wb-link[aria-disabled='true'],
.wb-link.is-disabled {
  color: var(--wb-color-link-disabled);
  text-decoration-line: underline;
  cursor: not-allowed;
}
</style>
