<script setup>
import '../shared/disclosure-motion.css';
import { resolveColumnWidths } from './column-widths.js';
import { layoutCellWidth } from './layout-width.js';
import { useColumnResize } from './useColumnResize.js';
import ColumnResizeControl from './ColumnResizeControl.vue';
import TableColumnFilter from './TableColumnFilter.vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import { computed, nextTick, onBeforeUnmount, onMounted, ref, useId, useSlots, watch } from 'vue';
import WorkbenchButton from '../button/WorkbenchButton.vue';
import WorkbenchCheckbox from '../choice/WorkbenchCheckbox.vue';
import WorkbenchDropdown from '../dropdown/WorkbenchDropdown.vue';
import WorkbenchLink from '../link/WorkbenchLink.vue';
import WorkbenchPagination from '../pagination/WorkbenchPagination.vue';
import TableScrollArea from './TableScrollArea.vue';
import WorkbenchSkeletonBlock from '../skeleton/WorkbenchSkeletonBlock.vue';
import WorkbenchTooltip from '../tooltip/WorkbenchTooltip.vue';
import TableCellContent from './TableCellContent.vue';
import '../../../../catalog/generated/asset.tokens.css';

const props = defineProps({
  title: { type: String, default: '' },
  caption: { type: String, default: '' },
  ariaLabel: { type: String, default: '' },
  columns: { type: Array, required: true },
  rows: { type: Array, default: () => [] },
  rowKey: { type: [String, Function], required: true },
  selectedRowKeys: { type: Array, default: () => [] },
  sort: { type: Object, default: null },
  page: { type: Number, default: 1 },
  pageSize: { type: Number, default: 10 },
  pageSizeOptions: { type: Array, default: () => [10, 20, 50, 100] },
  total: { type: Number, default: null },
  loading: { type: Boolean, default: false },
  errorMessage: { type: String, default: '' },
  emptyKind: {
    type: String,
    default: 'initial',
    validator: (value) => ['initial', 'filtered'].includes(value),
  },
  selectable: { type: Boolean, default: false },
  selectionFixed: { type: Boolean, default: false },
  actionsFixed: { type: Boolean, default: false },
  expandable: { type: Boolean, default: false },
  expandedRowKeys: { type: Array, default: () => [] },
  isRowExpandable: { type: Function, default: () => true },
  isRowSelectable: { type: Function, default: () => true },
  rowActions: { type: [Array, Function], default: () => [] },
  striped: { type: Boolean, default: false },
  resizable: { type: Boolean, default: false },
  columnWidths: { type: Object, default: undefined },
  columnFilters: { type: Object, default: () => ({}) },
});

const emit = defineEmits([
  'update:selectedRowKeys',
  'selection-change',
  'update:sort',
  'sort-change',
  'column-filter',
  'update:columnFilters',
  'column-filter-change',
  'update:page',
  'page-change',
  'update:pageSize',
  'page-size-change',
  'update:expandedRowKeys',
  'expand-change',
  'row-action',
  'retry',
  'update:columnWidths',
  'column-width-change',
]);

const slots = useSlots();
const instanceId = useId();
const expandedKeys = computed(() => new Set(props.expandedRowKeys));
const expansionKey = computed(
  () => normalizedColumns.value.find((column) => column.fixed === 'left')?.key ?? primaryKey.value,
);
const detailId = (row) => `table-${instanceId}-detail-${encodeURIComponent(String(keyOf(row)))}`;
function toggleExpanded(row) {
  const key = keyOf(row);
  const expanded = !expandedKeys.value.has(key);
  emit(
    'update:expandedRowKeys',
    expanded
      ? [...props.expandedRowKeys, key]
      : props.expandedRowKeys.filter((item) => item !== key),
  );
  emit('expand-change', { row, rowKey: key, expanded });
}
watch(
  () => props.expandedRowKeys,
  (next, previous) => {
    for (const key of previous) {
      if (next.includes(key)) continue;
      const row = props.rows.find((item) => keyOf(item) === key);
      const detail = row && document.getElementById(detailId(row));
      if (detail?.contains(document.activeElement))
        nextTick(() => root.value?.querySelector(`[aria-controls="${detailId(row)}"]`)?.focus());
    }
  },
  { flush: 'pre' },
);
const root = ref(null);
const scrollArea = ref(null);
const isOverflowing = ref(false);
const columnWidths = ref({});
const pixelColumns = ref([]);
let resizeObserver, rootFontProbe;

const normalizedColumns = computed(() =>
  props.columns
    .filter((column) => column && column.key && column.title)
    .slice()
    .sort((a, b) => {
      const rank = (column) => (column.fixed === 'left' ? 0 : column.fixed === 'right' ? 2 : 1);
      return rank(a) - rank(b);
    }),
);
// Adjacent leaf columns in a group share the existing Table layout and behavior.
const hasGroupedHeaders = computed(() =>
  normalizedColumns.value.some((column) => column.group?.key && column.group?.title),
);
// A column group starts after the preceding ungrouped column or a different group.
const groupStarts = computed(
  () =>
    new Set(
      normalizedColumns.value.flatMap((column, index, all) => {
        if (!column.group?.key || !column.group?.title || (index === 0 && !props.selectable))
          return [];
        const previous = all[index - 1];
        return !previous ||
          previous.group?.key !== column.group.key ||
          previous.fixed !== column.fixed
          ? [column.key]
          : [];
      }),
    ),
);
const groupedHeaderRows = computed(() => {
  const top = [],
    bottom = [];
  for (const column of normalizedColumns.value) {
    const group = column.group;
    if (!group?.key || !group?.title) {
      top.push(column);
      continue;
    }
    bottom.push(column);
    const last = top[top.length - 1];
    if (last?.isGroupHeader && last.groupKey === group.key && last.fixed === column.fixed) {
      last.span += 1;
      if (column.fixed === 'right') last.anchorKey = column.key;
    } else {
      top.push({
        isGroupHeader: true,
        groupKey: group.key,
        title: group.title,
        fixed: column.fixed,
        key: `group-${group.key}-${column.key}`,
        anchorKey: column.key,
        startKey: column.key,
        span: 1,
      });
    }
  }
  return [top, bottom];
});
const headerRows = computed(() =>
  hasGroupedHeaders.value ? groupedHeaderRows.value : [normalizedColumns.value],
);
const primaryKey = computed(
  () =>
    normalizedColumns.value.find((column) => column.primary)?.key ??
    normalizedColumns.value[0]?.key,
);
const resize = useColumnResize({
  props,
  columns: normalizedColumns,
  pixelColumns,
  widths: columnWidths,
  root,
  emit,
});
const { editorKey } = resize;
defineExpose({ resetColumnWidths: resize.resetColumnWidths });
const hasRowActions = computed(
  () =>
    Boolean(slots['row-actions']) ||
    (Array.isArray(props.rowActions)
      ? props.rowActions.length > 0
      : typeof props.rowActions === 'function'),
);
const totalColumnCount = computed(
  () => normalizedColumns.value.length + (props.selectable ? 1 : 0) + (hasRowActions.value ? 1 : 0),
);
const hasPagination = computed(() => Number.isFinite(props.total) && props.total >= 0);
const accessibleCaption = computed(
  () => props.caption.trim() || props.ariaLabel.trim() || '数据表格',
);
const hasToolbar = computed(() =>
  Boolean(props.title || slots['toolbar-leading'] || slots['toolbar-actions']),
);
const selectedKeySet = computed(() =>
  props.selectable ? new Set(props.selectedRowKeys) : new Set(),
);
const selectableRows = computed(() =>
  props.selectable ? props.rows.filter((row, index) => props.isRowSelectable(row, index)) : [],
);
const selectedVisibleRows = computed(() =>
  props.rows.filter((row) => selectedKeySet.value.has(keyOf(row))),
);
const selectedVisibleKeys = computed(() => selectedVisibleRows.value.map((row) => keyOf(row)));
const allSelected = computed(
  () =>
    selectableRows.value.length > 0 &&
    selectableRows.value.every((row) => selectedKeySet.value.has(keyOf(row))),
);
const someSelected = computed(
  () =>
    !allSelected.value && selectableRows.value.some((row) => selectedKeySet.value.has(keyOf(row))),
);
const initialLoading = computed(() => props.loading && props.rows.length === 0);
const showError = computed(() => !props.loading && Boolean(props.errorMessage));
const showEmpty = computed(() => !props.loading && !showError.value && props.rows.length === 0);
const skeletonRows = Object.freeze([0, 1, 2, 3, 4]);

function keyOf(row) {
  return typeof props.rowKey === 'function' ? props.rowKey(row) : row?.[props.rowKey];
}

function cellValue(row, column) {
  const value =
    typeof column.field === 'function' ? column.field(row) : row?.[column.field ?? column.key];
  return value === null || value === undefined ? '' : String(value);
}

function columnAlign(column) {
  return column.align === 'right' || column.align === 'end'
    ? 'end'
    : column.align === 'center'
      ? 'center'
      : 'start';
}

function columnFilterValues(column) {
  return Array.isArray(props.columnFilters[column.key]) ? props.columnFilters[column.key] : [];
}

function changeColumnFilter(column, values, source = 'option') {
  if (props.loading || showError.value) return;
  const next = { ...props.columnFilters };
  if (source === 'reset-all') Object.keys(next).forEach((key) => delete next[key]);
  else if (values.length) next[column.key] = [...values];
  else delete next[column.key];
  emit('update:columnFilters', next);
  emit('column-filter-change', {
    key: column.key,
    column,
    values: [...values],
    columnFilters: next,
    source,
  });
}

function normalizeLength(value) {
  if (Number.isFinite(value) && value >= 0) return `${value}px`;
  if (typeof value === 'string' && /^\d+(?:\.\d+)?(?:px|rem|em|%|ch)$/.test(value.trim()))
    return value.trim();
  return '';
}

function applyColumnGeometry(element, column) {
  if (!element) return;
  const width = normalizeLength(column.width);
  const resolved = columnWidths.value[column.key];
  const resolvedWidth = resolved === undefined ? width : `${resolved}px`;
  element.style.width = resolvedWidth;
  element.style.minWidth =
    resolved === undefined ? normalizeLength(column.minWidth) || width : resolvedWidth;
  element.style.maxWidth = resolvedWidth;
  queueMeasure();
}

let measureQueued = false;
function queueMeasure() {
  if (measureQueued) return;
  measureQueued = true;
  nextTick(() => {
    measureQueued = false;
    measureOverflow();
  });
}

function resolveTableColumnWidths(viewport) {
  if (!viewport || !root.value) return {};
  const styles = getComputedStyle(root.value);
  const selectionWidth = props.selectable
    ? Number.parseFloat(styles.getPropertyValue('--wb-asset-wb-table-selection-column-width')) || 0
    : 0;
  const actionWidth = hasRowActions.value
    ? Number.parseFloat(styles.getPropertyValue('--wb-asset-wb-table-action-column-width')) || 0
    : 0;
  const probe = document.createElement('div');
  probe.style.cssText =
    'position:absolute;visibility:hidden;pointer-events:none;height:0;overflow:hidden';
  probe.style.width = `${viewport.clientWidth}px`;
  probe.style.font = getComputedStyle(viewport.querySelector('table')).font;
  const lengthProbe = document.createElement('div');
  probe.append(lengthProbe);
  viewport.append(probe);
  const pixels = (value) => {
    const length = normalizeLength(value);
    if (!length || length.endsWith('px')) return value;
    lengthProbe.style.width = length;
    return Number.parseFloat(getComputedStyle(lengthProbe).width) || 0;
  };
  let columns;
  try {
    columns = normalizedColumns.value.map((column) => ({
      ...column,
      width: pixels(column.width),
      minWidth: pixels(column.minWidth),
      maxWidth: pixels(column.maxWidth),
    }));
  } finally {
    probe.remove();
  }
  const padding =
    Number.parseFloat(styles.getPropertyValue('--wb-asset-wb-table-cell-padding-inline')) || 0;
  const action =
    Number.parseFloat(styles.getPropertyValue('--wb-asset-wb-table-header-action-icon-size')) || 0;
  const gap =
    Number.parseFloat(styles.getPropertyValue('--wb-asset-wb-table-header-action-gap')) || 0;
  columns = columns.map((column) => ({
    ...column,
    minWidth:
      props.resizable && column.resizable !== false
        ? Math.max(
            Number.parseFloat(column.minWidth) || 0,
            2 * padding +
              gap +
              (Number(Boolean(column.sortable)) + Number(Boolean(column.filterable))) *
                (action + gap),
          )
        : column.minWidth,
  }));
  if (JSON.stringify(pixelColumns.value) !== JSON.stringify(columns)) pixelColumns.value = columns;
  return resolveColumnWidths(
    columns,
    viewport.clientWidth - selectionWidth - actionWidth,
    primaryKey.value,
    resize.effectiveWidths.value ?? {},
  );
}

function measureOverflow() {
  const viewport = root.value?.querySelector('.wb-scrollarea__viewport');
  if (!viewport) return;
  const nextWidths = resolveTableColumnWidths(viewport);
  if (JSON.stringify(nextWidths) !== JSON.stringify(columnWidths.value)) {
    columnWidths.value = nextWidths;
    nextTick(measureOverflow);
    return;
  }
  const table = viewport.querySelector('table');
  const extraWidth =
    (props.selectable
      ? Number.parseFloat(
          getComputedStyle(root.value).getPropertyValue(
            '--wb-asset-wb-table-selection-column-width',
          ),
        )
      : 0) +
    (hasRowActions.value
      ? Number.parseFloat(
          getComputedStyle(root.value).getPropertyValue('--wb-asset-wb-table-action-column-width'),
        )
      : 0);
  table.style.width = `${Object.values(nextWidths).reduce((sum, width) => sum + width, extraWidth)}px`;
  table.style.minWidth = '0';
  isOverflowing.value = viewport.scrollWidth > viewport.clientWidth + 1;
  const selectionHeader = viewport.querySelector('thead .wb-table__selection-cell--header');
  const actionHeader = viewport.querySelector('thead .wb-table__action-cell--header');
  const leafHeaders = normalizedColumns.value.map((column) =>
    [...viewport.querySelectorAll('thead th[data-column-key]')].find(
      (header) => header.dataset.columnKey === String(column.key),
    ),
  );
  const headers = [selectionHeader, ...leafHeaders, actionHeader].filter(Boolean);
  for (const side of ['left', 'right']) {
    let offset = 0;
    const fixedHeaders = headers.filter((header) => header.dataset.fixed === side);
    if (side === 'right') fixedHeaders.reverse();
    for (const header of fixedHeaders) {
      const index = headers.indexOf(header);
      header.style.setProperty('--table-fixed-offset', `${offset}px`);
      for (const row of viewport.querySelectorAll('tbody tr:not(.wb-table__detail-row)')) {
        const cell = row.children[index];
        if (cell) cell.style.setProperty('--table-fixed-offset', `${offset}px`);
      }
      offset += layoutCellWidth(header);
    }
  }
  for (const group of viewport.querySelectorAll('thead .wb-table__group-header[data-anchor-key]')) {
    const anchor = leafHeaders.find(
      (header) => header?.dataset.columnKey === group.dataset.anchorKey,
    );
    group.style.setProperty(
      '--table-fixed-offset',
      anchor?.style.getPropertyValue('--table-fixed-offset') || '0px',
    );
  }
  scrollArea.value?.measure();
}

function emitSelection(nextKeys, source) {
  if (!props.selectable) return;
  const visibleKeys = new Set(props.rows.map((row) => keyOf(row)));
  const next = [...new Set(nextKeys)].filter((key) => visibleKeys.has(key));
  const rows = props.rows.filter((row) => next.includes(keyOf(row)));
  emit('update:selectedRowKeys', next);
  emit('selection-change', { selectedRowKeys: next, selectedRows: rows, source });
}

function clearSelection(source = 'clear') {
  if (!props.selectedRowKeys.length) return;
  emitSelection([], source);
}

function toggleAll(checked) {
  if (props.loading || showError.value) return;
  emitSelection(checked ? selectableRows.value.map((row) => keyOf(row)) : [], 'page');
}

function toggleRow(row, checked) {
  if (props.loading || !props.isRowSelectable(row, props.rows.indexOf(row))) return;
  const key = keyOf(row);
  const next = new Set(selectedVisibleKeys.value);
  if (checked) next.add(key);
  else next.delete(key);
  emitSelection([...next], 'row');
}

function sortDirection(column) {
  return props.sort?.key === column.key ? props.sort.direction : null;
}

function ariaSort(column) {
  if (!column.sortable) return undefined;
  const direction = sortDirection(column);
  return direction === 'asc' ? 'ascending' : direction === 'desc' ? 'descending' : 'none';
}

function sortLabel(column) {
  const direction = sortDirection(column);
  return direction === 'asc'
    ? `${column.title}，当前升序，切换为降序`
    : direction === 'desc'
      ? `${column.title}，当前降序，恢复默认顺序`
      : `${column.title}，切换为升序`;
}

function toggleSort(column) {
  if (!column.sortable || props.loading || showError.value) return;
  const direction = sortDirection(column);
  const next =
    direction === 'asc'
      ? { key: column.key, direction: 'desc' }
      : direction === 'desc'
        ? null
        : { key: column.key, direction: 'asc' };
  emit('update:sort', next);
  emit('sort-change', next);
}

function requestColumnFilter(column) {
  if (!column.filterable || props.loading || showError.value) return;
  emit('column-filter', { key: column.key, column, source: 'header' });
}

function actionsFor(row) {
  const actions = typeof props.rowActions === 'function' ? props.rowActions(row) : props.rowActions;
  return Array.isArray(actions) ? actions.filter((action) => action?.id && action?.label) : [];
}

function actionDisabled(action, row) {
  return (
    props.loading ||
    (typeof action.disabled === 'function' ? action.disabled(row) : Boolean(action.disabled))
  );
}

function emitRowAction(row, action, source = 'direct') {
  if (!action || actionDisabled(action, row)) return;
  emit('row-action', { row, rowKey: keyOf(row), action, source });
}

function overflowItems(row) {
  return actionsFor(row)
    .slice(2)
    .map((action) => ({
      id: action.id,
      label: action.label,
      type: 'action',
      disabled: actionDisabled(action, row),
    }));
}

function activateOverflow(row, actionId) {
  const action = actionsFor(row).find((item) => item.id === actionId);
  emitRowAction(row, action, 'overflow');
}

async function markOverflowPanel(open) {
  if (!open) return;
  await nextTick();
  const trigger = root.value?.querySelector(
    '.wb-table__row-more [aria-expanded="true"][aria-controls]',
  );
  const panelId = trigger?.getAttribute('aria-controls');
  if (panelId) document.getElementById(panelId)?.classList.add('wb-table__overflow-panel');
}

function changePage(value) {
  emit('update:page', value);
  emit('page-change', value);
}

function changePageSize(value) {
  emit('update:pageSize', value);
  emit('page-size-change', value);
}

watch([() => props.page, () => props.pageSize], ([page, size], [previousPage, previousSize]) => {
  if ((page !== previousPage || size !== previousSize) && props.selectedRowKeys.length)
    clearSelection(page !== previousPage ? 'external-page-change' : 'external-page-size-change');
});

watch(
  [
    () => props.rows,
    () => props.columns,
    () => props.selectable,
    () => props.selectionFixed,
    () => props.actionsFixed,
  ],
  () => nextTick(measureOverflow),
  { deep: true },
);
watch(resize.effectiveWidths, queueMeasure, { deep: true });
watch(() => props.resizable, queueMeasure);

onMounted(() => {
  if (!props.caption.trim() && !props.ariaLabel.trim())
    console.warn('[WorkbenchTable] caption 或 ariaLabel 至少需要提供一项。');
  resizeObserver = new ResizeObserver(measureOverflow);
  if (root.value) resizeObserver.observe(root.value);
  const viewport = root.value?.querySelector('.wb-scrollarea__viewport');
  const table = root.value?.querySelector('table');
  if (viewport) resizeObserver.observe(viewport);
  if (table) resizeObserver.observe(table);
  // A rem change can leave every container size unchanged after pixel allocation.
  rootFontProbe = document.createElement('span');
  rootFontProbe.setAttribute('aria-hidden', 'true');
  rootFontProbe.style.cssText =
    'position:absolute;left:0;top:0;width:1rem;height:0;visibility:hidden;pointer-events:none';
  root.value?.append(rootFontProbe);
  resizeObserver.observe(rootFontProbe);
  nextTick(measureOverflow);
});

onBeforeUnmount(() => {
  resizeObserver?.disconnect();
  rootFontProbe?.remove();
});
</script>

<template>
  <section
    ref="root"
    class="wb-table-prototype"
    :class="{
      'has-selection': selectable,
      'has-actions': hasRowActions,
      'has-footer': hasPagination || selectedVisibleKeys.length,
      'is-overflowing': isOverflowing,
      'is-striped': striped,
      'is-refreshing': loading && rows.length > 0,
    }"
    :aria-busy="loading || undefined"
  >
    <header
      v-if="hasToolbar"
      class="wb-table__toolbar"
      aria-label="表格操作区"
    >
      <h2
        v-if="title"
        class="wb-table__title"
      >
        {{ title }}
      </h2>
      <div class="wb-table__toolbar-row">
        <div class="wb-table__toolbar-leading">
          <slot name="toolbar-leading" />
        </div>
        <div
          v-if="$slots['toolbar-actions']"
          class="wb-table__toolbar-actions"
        >
          <slot name="toolbar-actions" />
        </div>
      </div>
    </header>

    <span
      v-if="loading && rows.length"
      class="wb-table__sr-only"
      role="status"
      aria-live="polite"
      >正在刷新表格数据</span
    >

    <TableScrollArea
      ref="scrollArea"
      class="wb-table__scroll"
      :label="`${accessibleCaption}横向滚动区域`"
    >
      <table :aria-label="caption ? undefined : ariaLabel || accessibleCaption">
        <caption class="wb-table__sr-only">
          {{
            accessibleCaption
          }}
        </caption>
        <colgroup>
          <col
            v-if="selectable"
            class="wb-table__selection-column"
          />
          <col
            v-for="column in normalizedColumns"
            :key="column.key"
            :ref="(element) => applyColumnGeometry(element, column)"
            :data-fixed="column.fixed"
          />
          <col
            v-if="hasRowActions"
            class="wb-table__action-column"
          />
        </colgroup>
        <thead>
          <tr
            v-for="(headerRow, headerRowIndex) in headerRows"
            :key="headerRowIndex"
          >
            <th
              v-if="selectable && headerRowIndex === 0"
              :rowspan="hasGroupedHeaders ? 2 : 1"
              class="wb-table__selection-cell wb-table__selection-cell--header"
              :data-fixed="selectionFixed ? 'left' : undefined"
              :class="{ 'is-sticky': isOverflowing && selectionFixed }"
              scope="col"
            >
              <WorkbenchCheckbox
                :model-value="allSelected"
                :indeterminate="someSelected"
                :disabled="loading || showError || selectableRows.length === 0"
                aria-label="选择当前页全部行"
                @update:model-value="toggleAll"
              />
            </th>
            <template
              v-for="column in headerRow"
              :key="column.key"
            >
              <th
                v-if="column.isGroupHeader"
                class="wb-table__group-header is-align-center"
                :colspan="column.span"
                :data-anchor-key="column.anchorKey"
                :data-fixed="column.fixed"
                :class="{
                  'is-sticky': isOverflowing && Boolean(column.fixed),
                  'is-group-start': groupStarts.has(column.startKey),
                }"
                scope="colgroup"
              >
                {{ column.title }}
              </th>
              <th
                v-else
                :rowspan="hasGroupedHeaders && !(column.group?.key && column.group?.title) ? 2 : 1"
                :ref="(element) => applyColumnGeometry(element, column)"
                :data-fixed="column.fixed"
                class="wb-table__header-cell"
                :data-column-key="column.key"
                :class="[
                  `is-align-${columnAlign(column)}`,
                  {
                    'is-primary': column.key === primaryKey,
                    'is-sticky': isOverflowing && Boolean(column.fixed),
                    'is-resizable': resize.canResize(column),
                    'is-group-start': groupStarts.has(column.key),
                  },
                ]"
                scope="col"
                :aria-sort="ariaSort(column)"
              >
                <span class="wb-table__header-content">
                  <span class="wb-table__header-title-host">
                    <slot
                      v-if="$slots[`header-${column.key}`]"
                      :name="`header-${column.key}`"
                      :column="column"
                    />
                    <WorkbenchTooltip
                      v-else
                      :content="column.title"
                      overflow-only
                    >
                      <template #trigger="{ aria }"
                        ><span
                          class="wb-table__header-title"
                          tabindex="0"
                          v-bind="aria"
                          >{{ column.title }}</span
                        ></template
                      >
                    </WorkbenchTooltip>
                  </span>
                  <span
                    v-if="column.filterable || column.sortable"
                    class="wb-table__header-actions"
                  >
                    <TableColumnFilter
                      v-if="column.filterable"
                      :column="column"
                      :values="columnFilterValues(column)"
                      :align="columnAlign(column)"
                      :disabled="loading || showError"
                      @request="requestColumnFilter(column)"
                      @change="changeColumnFilter(column, $event)"
                      @reset="changeColumnFilter(column, [], 'reset-column')"
                      @reset-all="changeColumnFilter(column, [], 'reset-all')"
                    />
                    <button
                      v-if="column.sortable"
                      type="button"
                      class="wb-table__header-action wb-table__sort"
                      :class="{ 'is-active': sortDirection(column) }"
                      :disabled="loading || showError"
                      :aria-label="sortLabel(column)"
                      @click="toggleSort(column)"
                    >
                      <WorkbenchIcon
                        name="/ic_public_sort_line_14px"
                        color="var(--wb-color-icon-secondary)"
                        :color-split="
                          sortDirection(column)
                            ? {
                                ratio: 0.5,
                                startColor:
                                  sortDirection(column) === 'asc'
                                    ? 'var(--wb-color-text-action)'
                                    : 'var(--wb-color-icon-secondary)',
                                endColor:
                                  sortDirection(column) === 'desc'
                                    ? 'var(--wb-color-text-action)'
                                    : 'var(--wb-color-icon-secondary)',
                              }
                            : null
                        "
                      />
                    </button>
                  </span>
                </span>
                <ColumnResizeControl
                  v-if="resize.canResize(column)"
                  :column="column"
                  :width="columnWidths[column.key]"
                  :minimum="resize.boundsOf(column.key).min"
                  :maximum="resize.boundsOf(column.key).max"
                  :disabled="loading || showError"
                  :open="editorKey === column.key"
                  @pointerdown="resize.startDrag(column.key, $event)"
                  @pointermove="resize.moveDrag"
                  @pointerup="resize.endDrag"
                  @cancel="resize.cancelDrag"
                  @click="resize.toggleEditor(column.key)"
                  @keydown="resize.keydown(column.key, $event)"
                  @close="editorKey = null"
                  @adjust="
                    resize.changeWidth(column.key, columnWidths[column.key] + $event, 'button')
                  "
                  @reset="resize.resetColumnWidths(column.key)"
                  @reset-all="resize.resetColumnWidths()"
                />
              </th>
            </template>
            <th
              v-if="hasRowActions && headerRowIndex === 0"
              :rowspan="hasGroupedHeaders ? 2 : 1"
              class="wb-table__action-cell wb-table__action-cell--header"
              :data-fixed="actionsFixed ? 'right' : undefined"
              :class="{ 'is-sticky': isOverflowing && actionsFixed }"
              scope="col"
            >
              操作
            </th>
          </tr>
        </thead>

        <tbody
          v-if="initialLoading"
          class="wb-table__skeleton-body"
        >
          <tr
            v-for="rowIndex in skeletonRows"
            :key="rowIndex"
          >
            <td
              v-if="selectable"
              class="wb-table__selection-cell"
              :data-fixed="selectionFixed ? 'left' : undefined"
              :class="{ 'is-sticky': isOverflowing && selectionFixed }"
            />
            <td
              v-for="column in normalizedColumns"
              :key="column.key"
              :ref="(element) => applyColumnGeometry(element, column)"
              :data-fixed="column.fixed"
              :class="{
                'is-primary': column.key === primaryKey,
                'is-sticky': isOverflowing && Boolean(column.fixed),
              }"
            >
              <WorkbenchSkeletonBlock :animated="true" />
            </td>
            <td
              v-if="hasRowActions"
              class="wb-table__action-cell"
              :data-fixed="actionsFixed ? 'right' : undefined"
              :class="{ 'is-sticky': isOverflowing && actionsFixed }"
            >
              <WorkbenchSkeletonBlock :animated="true" />
            </td>
          </tr>
        </tbody>

        <tbody v-else-if="showError">
          <tr>
            <td
              class="wb-table__state-cell"
              :colspan="totalColumnCount"
            >
              <div
                class="wb-table__state"
                role="alert"
              >
                <strong>数据加载失败</strong><span>{{ errorMessage }}</span
                ><slot
                  name="error"
                  :message="errorMessage"
                  ><WorkbenchButton
                    appearance="secondary"
                    size="32"
                    @click="emit('retry')"
                    >重新加载</WorkbenchButton
                  ></slot
                >
              </div>
            </td>
          </tr>
        </tbody>

        <tbody v-else-if="showEmpty">
          <tr>
            <td
              class="wb-table__state-cell"
              :colspan="totalColumnCount"
            >
              <div
                class="wb-table__state"
                role="status"
              >
                <slot
                  name="empty"
                  :kind="emptyKind"
                  ><strong>{{
                    emptyKind === 'filtered' ? '没有符合条件的数据' : '暂无数据'
                  }}</strong
                  ><span>{{
                    emptyKind === 'filtered'
                      ? '请调整搜索或筛选条件后重试。'
                      : '当前还没有可以展示的业务数据。'
                  }}</span></slot
                >
              </div>
            </td>
          </tr>
        </tbody>

        <tbody v-else>
          <template
            v-for="(row, rowIndex) in rows"
            :key="keyOf(row)"
          >
            <tr
              class="wb-table__data-row"
              :class="{
                'is-selected': selectedKeySet.has(keyOf(row)),
                'is-even': rowIndex % 2 === 1,
              }"
            >
              <td
                v-if="selectable"
                class="wb-table__selection-cell"
                :data-fixed="selectionFixed ? 'left' : undefined"
                :class="{ 'is-sticky': isOverflowing && selectionFixed }"
              >
                <WorkbenchCheckbox
                  :model-value="selectedKeySet.has(keyOf(row))"
                  :disabled="loading || !isRowSelectable(row, rowIndex)"
                  :aria-label="`选择第 ${rowIndex + 1} 行`"
                  @update:model-value="toggleRow(row, $event)"
                />
              </td>
              <td
                v-for="column in normalizedColumns"
                :key="column.key"
                :ref="(element) => applyColumnGeometry(element, column)"
                :data-fixed="column.fixed"
                :class="[
                  `is-align-${columnAlign(column)}`,
                  {
                    'is-primary': column.key === primaryKey,
                    'is-sticky': isOverflowing && Boolean(column.fixed),
                    'is-banded': column.banded === true,
                    'is-group-start': groupStarts.has(column.key),
                  },
                ]"
              >
                <div
                  class="wb-table__value"
                  :class="{ 'has-expand': expandable && column.key === expansionKey }"
                >
                  <button
                    v-if="expandable && column.key === expansionKey"
                    class="wb-table__expand"
                    type="button"
                    :disabled="loading || !isRowExpandable(row)"
                    :aria-expanded="expandedKeys.has(keyOf(row))"
                    :aria-controls="detailId(row)"
                    :aria-label="`${expandedKeys.has(keyOf(row)) ? '收起' : '展开'}详情：${keyOf(row)}`"
                    @click="toggleExpanded(row)"
                  >
                    <WorkbenchIcon
                      class="wb-disclosure-icon wb-disclosure-icon--branch"
                      :class="{ 'is-expanded': expandedKeys.has(keyOf(row)) }"
                      name="结构树箭头/方向=向右"
                    />
                  </button>
                  <TableCellContent v-if="$slots[`cell-${column.key}`]">
                    <slot
                      :name="`cell-${column.key}`"
                      :row="row"
                      :value="cellValue(row, column)"
                      :column="column"
                      :row-index="rowIndex"
                    />
                  </TableCellContent>
                  <span
                    v-else
                    class="wb-table__ellipsis-host"
                  >
                    <WorkbenchTooltip
                      :content="cellValue(row, column)"
                      overflow-only
                    >
                      <template #trigger="{ aria }">
                        <span
                          :class="column.ellipsis ? 'wb-table__ellipsis' : 'wb-table__cell-content'"
                          tabindex="0"
                          :aria-describedby="aria['aria-describedby']"
                          >{{ cellValue(row, column) }}</span
                        >
                      </template>
                    </WorkbenchTooltip>
                  </span>
                </div>
              </td>
              <td
                v-if="hasRowActions"
                class="wb-table__action-cell"
                :data-fixed="actionsFixed ? 'right' : undefined"
                :class="{ 'is-sticky': isOverflowing && actionsFixed }"
              >
                <slot
                  v-if="$slots['row-actions']"
                  name="row-actions"
                  :row="row"
                  :actions="actionsFor(row)"
                  :emit-action="(action) => emitRowAction(row, action, 'slot')"
                />
                <div
                  v-else
                  class="wb-table__row-actions"
                >
                  <template
                    v-for="(action, actionIndex) in actionsFor(row).slice(0, 2)"
                    :key="action.id"
                  >
                    <WorkbenchLink
                      v-if="action.type === 'link'"
                      class="wb-table__row-action"
                      :class="
                        actionIndex === 0
                          ? 'wb-table__row-action--primary'
                          : 'wb-table__row-action--secondary'
                      "
                      :href="action.href"
                      :disabled="actionDisabled(action, row)"
                      @click="emitRowAction(row, action, 'direct')"
                      >{{ action.label }}</WorkbenchLink
                    >
                    <WorkbenchButton
                      v-else
                      class="wb-table__row-action"
                      :class="
                        actionIndex === 0
                          ? 'wb-table__row-action--primary'
                          : 'wb-table__row-action--secondary'
                      "
                      appearance="text"
                      size="28"
                      :disabled="actionDisabled(action, row)"
                      @click="emitRowAction(row, action, 'direct')"
                      >{{ action.label }}</WorkbenchButton
                    >
                  </template>
                  <WorkbenchDropdown
                    v-if="overflowItems(row).length"
                    class="wb-table__row-more"
                    size="small"
                    trigger-type="text"
                    text-intent="drilldown"
                    panel-width="min"
                    :items="overflowItems(row)"
                    :disabled="loading"
                    :aria-label="`更多操作：${cellValue(row, normalizedColumns.find((column) => column.key === primaryKey) ?? normalizedColumns[0])}`"
                    @action="activateOverflow(row, $event.id)"
                    @update:open="markOverflowPanel"
                  >
                    <template #trigger>更多</template>
                  </WorkbenchDropdown>
                </div>
              </td>
            </tr>
            <tr
              v-if="expandable && isRowExpandable(row) && expandedKeys.has(keyOf(row))"
              class="wb-table__detail-row"
            >
              <td :colspan="totalColumnCount">
                <div
                  :id="detailId(row)"
                  class="wb-table__detail"
                  role="region"
                  :aria-label="`详情：${keyOf(row)}`"
                >
                  <slot
                    name="expanded-content"
                    :row="row"
                    :row-key="keyOf(row)"
                    :row-index="rowIndex"
                  />
                  <div
                    v-if="$slots['expanded-actions']"
                    class="wb-table__detail-actions"
                  >
                    <slot
                      name="expanded-actions"
                      :row="row"
                      :row-key="keyOf(row)"
                      :row-index="rowIndex"
                    />
                  </div>
                </div>
              </td>
            </tr>
          </template>
        </tbody>
      </table>
    </TableScrollArea>

    <footer
      v-if="hasPagination || selectedVisibleKeys.length"
      class="wb-table__footer"
    >
      <span
        v-if="hasPagination"
        class="wb-table__total"
        >共：{{ total }} 项</span
      >
      <div
        v-if="selectedVisibleKeys.length"
        class="wb-table__batch"
        aria-live="polite"
      >
        <span class="wb-table__selection-summary"
          >已选中：<span class="wb-table__selection-count">{{ selectedVisibleKeys.length }}</span>
          项</span
        >
        <slot
          name="batch-actions"
          :selected-row-keys="selectedVisibleKeys"
          :selected-rows="selectedVisibleRows"
        />
      </div>
      <WorkbenchPagination
        v-if="hasPagination"
        variant="full"
        :model-value="page"
        :page-size="pageSize"
        :page-size-options="pageSizeOptions"
        :total="total"
        :disabled="loading || showError"
        :aria-label="`${accessibleCaption}分页`"
        @change="changePage"
        @page-size-change="changePageSize"
      />
    </footer>
  </section>
</template>

<style scoped>
.wb-table-prototype {
  display: grid;
  min-width: 0;
  container: wb-table / inline-size;
  color: var(--wb-color-text-primary);
  background: var(--wb-color-surface-container);
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
}

.wb-table__toolbar {
  --select-field-width: var(--wb-asset-wb-select-default-width);
  display: grid;
  min-width: 0;
  min-height: var(--wb-asset-wb-table-toolbar-min-height);
  align-content: center;
  gap: var(--wb-spacing-component-md);
  padding: var(--wb-spacing-component-md);
  border-block-end: var(--wb-asset-wb-table-separator-width) solid var(--wb-color-border-separator);
}

.wb-table__toolbar-row,
.wb-table__toolbar-leading,
.wb-table__toolbar-actions,
.wb-table__row-actions {
  display: flex;
  min-width: 0;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--wb-spacing-component-sm);
}

.wb-table__toolbar-row {
  justify-content: space-between;
  gap: var(--wb-spacing-component-lg);
}
.wb-table__toolbar-leading {
  flex: 1 1 auto;
}
.wb-table__toolbar-actions {
  flex: 0 0 auto;
  margin-inline-start: auto;
}
.wb-table__title {
  margin: 0;
  font-size: var(--wb-font-headline-s-font-size);
  font-weight: var(--wb-font-headline-s-font-weight);
  line-height: var(--wb-font-headline-s-line-height);
  letter-spacing: var(--wb-font-headline-s-letter-spacing);
}
.wb-table__selection-summary {
  white-space: nowrap;
}

.wb-table__scroll {
  min-width: 0;
}

table {
  width: max-content;
  min-width: 100%;
  border-spacing: 0;
  border-collapse: separate;
  table-layout: fixed;
  color: inherit;
  background: var(--wb-color-surface-container);
}

th,
td {
  box-sizing: border-box;
  padding-inline: var(--wb-asset-wb-table-cell-padding-inline);
  border-block-end: var(--wb-asset-wb-table-separator-width) solid var(--wb-color-border-separator);
  background-color: var(--wb-color-surface-container);
  text-align: start;
  vertical-align: middle;
}

th {
  position: relative;
  height: var(--wb-asset-wb-table-header-row-height);
  color: var(--wb-color-text-primary);
  background-color: var(--wb-color-surface-container);
  background-image: linear-gradient(
    var(--wb-color-table-header-fill-default),
    var(--wb-color-table-header-fill-default)
  );
  font-family: inherit;
  font-size: var(--wb-font-headline-xs-font-size);
  font-weight: var(--wb-font-headline-xs-font-weight);
  line-height: var(--wb-font-headline-xs-line-height);
  letter-spacing: var(--wb-font-headline-xs-letter-spacing);
}

/* Group boundaries span both header rows; the line inside each group is inset. */
.wb-table__group-header {
  border-block-end-color: transparent;
}
.wb-table__group-header::before {
  position: absolute;
  inset-inline: var(--wb-spacing-component-sm);
  bottom: 0;
  height: var(--wb-asset-wb-table-separator-width);
  background: var(--wb-color-border-separator);
  content: '';
}
.wb-table__group-header.is-group-start,
.wb-table__header-cell.is-group-start,
tbody td.is-group-start {
  border-inline-start: var(--wb-asset-wb-table-separator-width) solid
    var(--wb-color-border-separator);
}

td {
  height: var(--wb-asset-wb-table-body-row-height);
  border-block-end-color: var(--wb-color-border-separator-subtle);
}
.is-align-center {
  text-align: center;
}
.is-align-end {
  text-align: end;
}

.wb-table__header-content,
.wb-table__header-actions {
  display: inline-flex;
  align-items: center;
}
.wb-table__header-content {
  max-width: 100%;
  gap: var(--wb-asset-wb-table-header-action-gap);
}
.is-align-end .wb-table__header-content,
.is-align-end .wb-table__header-actions {
  flex-direction: row-reverse;
}
.wb-table__header-title-host {
  display: block;
  min-width: 0;
}
.wb-table__header-title-host :deep(.wb-tooltip-debug) {
  display: block;
  min-width: 0;
  max-width: 100%;
}
.wb-table__header-title {
  display: block;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.wb-table__header-cell.is-resizable .wb-table__header-content {
  max-width: calc(100% - var(--wb-spacing-component-sm));
}
.wb-table__header-actions {
  flex: none;
  gap: var(--wb-asset-wb-table-header-action-gap);
}
:deep(.wb-table__header-action) {
  position: relative;
  display: inline-grid;
  width: var(--wb-asset-wb-table-header-action-icon-size);
  height: var(--wb-asset-wb-table-header-action-icon-size);
  flex: none;
  place-items: center;
  padding: 0;
  border: 0;
  color: inherit;
  background: transparent;
  cursor: pointer;
}
:deep(.wb-table__header-action)::before {
  position: absolute;
  top: 50%;
  left: 50%;
  width: var(--wb-asset-wb-table-header-action-hit-size);
  height: var(--wb-asset-wb-table-header-action-hit-size);
  transform: translate(-50%, -50%);
  content: '';
}
:deep(.wb-table__header-action:disabled) {
  cursor: progress;
}
:deep(.wb-table__header-action:focus-visible) {
  outline: none;
}
:deep(.wb-table__header-action:focus-visible)::before {
  outline: var(--wb-asset-wb-table-separator-width) solid var(--wb-color-border-focus);
  outline-offset: 1px;
}
thead
  th:not(:last-child):not(.wb-table__group-header):not([rowspan='2']):not(
    :has(+ th.is-group-start)
  )::after {
  position: absolute;
  top: 50%;
  inset-inline-end: 0;
  width: var(--wb-asset-wb-table-separator-width);
  height: var(--wb-asset-wb-table-header-divider-height);
  background: var(--wb-color-border-separator);
  content: '';
  transform: translateY(-50%);
}

.wb-table__selection-cell {
  width: var(--wb-asset-wb-table-selection-column-width);
  min-width: var(--wb-asset-wb-table-selection-column-width);
  max-width: var(--wb-asset-wb-table-selection-column-width);
  padding: 0;
  text-align: center;
}
.wb-table__selection-column {
  width: var(--wb-asset-wb-table-selection-column-width);
}
.wb-table__selection-cell :deep(.wb-choice) {
  justify-content: center;
}
.wb-table__selection-cell :deep(.wb-choice__copy) {
  display: none;
}

.wb-table__action-cell {
  width: var(--wb-asset-wb-table-action-column-width);
  min-width: var(--wb-asset-wb-table-action-column-width);
  max-width: var(--wb-asset-wb-table-action-column-width);
  text-align: start;
}
.wb-table__action-column {
  width: var(--wb-asset-wb-table-action-column-width);
}
.wb-table__row-actions {
  flex-wrap: nowrap;
  gap: var(--wb-spacing-component-xs);
}
.wb-table__row-action,
.wb-table__row-more {
  flex: none;
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
  white-space: nowrap;
}
.wb-table__row-action {
  --inline-label-optical-offset: var(--wb-asset-wb-table-row-action-label-optical-offset);
}
.wb-table__row-action :deep(.wb-link__label),
.wb-table__row-more :deep(.wb-dropdown__trigger-content) {
  position: relative;
  top: var(--wb-asset-wb-table-row-action-label-optical-offset);
}
.wb-table__row-actions
  button.wb-table__row-action--primary:not(:disabled):not([aria-disabled='true']) {
  color: var(--wb-color-text-action);
}
.wb-table__row-actions
  button.wb-table__row-action--primary:not(:disabled):not([aria-disabled='true']):hover {
  color: var(--wb-color-text-action-hover);
}
.wb-table__row-actions
  button.wb-table__row-action--primary:not(:disabled):not([aria-disabled='true']):active {
  color: var(--wb-color-text-action-active);
}
.wb-table__row-actions
  button.wb-table__row-action--secondary:not(:disabled):not([aria-disabled='true']),
.wb-table__row-actions
  button.wb-table__row-action--secondary:not(:disabled):not([aria-disabled='true']):hover,
.wb-table__row-actions
  button.wb-table__row-action--secondary:not(:disabled):not([aria-disabled='true']):active {
  color: var(--wb-color-text-primary);
}
.wb-table__row-more:not(.is-disabled) :deep(.wb-dropdown__trigger),
.wb-table__row-more:not(.is-disabled) :deep(.wb-dropdown__trigger:hover),
.wb-table__row-more:not(.is-disabled) :deep(.wb-dropdown__trigger:active),
.wb-table__row-more.is-open :deep(.wb-dropdown__trigger) {
  color: var(--wb-color-text-primary);
}
:global(.wb-table__overflow-panel) {
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
}

.is-overflowing .is-sticky {
  position: sticky;
  z-index: 2;
}
.is-overflowing [data-fixed='left'].is-sticky {
  left: var(--table-fixed-offset, 0px);
}
.is-overflowing [data-fixed='right'].is-sticky {
  right: var(--table-fixed-offset, 0px);
}
.is-overflowing thead th[data-fixed='left']:not(:has(+ [data-fixed='left']))::after,
.is-overflowing thead th:not([data-fixed='right']):has(+ [data-fixed='right'])::after {
  display: none;
}
.is-overflowing th.is-sticky {
  z-index: 3;
  background-color: var(--wb-color-surface-container);
  background-image: linear-gradient(
    var(--wb-color-table-header-sticky-fill-default),
    var(--wb-color-table-header-sticky-fill-default)
  );
}

tbody tr.wb-table__data-row td.is-banded,
.is-striped tbody:not(.wb-table__skeleton-body) tr.is-even td {
  background-color: var(--wb-color-surface-container);
  background-image: linear-gradient(
    var(--wb-color-table-row-fill-alternating),
    var(--wb-color-table-row-fill-alternating)
  );
}
tbody tr.wb-table__data-row:not(.is-selected):hover td,
.is-striped tbody:not(.wb-table__skeleton-body) tr.is-even:not(.is-selected):hover td {
  background-color: var(--wb-color-surface-container);
  background-image: linear-gradient(var(--wb-color-fill-hover), var(--wb-color-fill-hover));
}
tbody tr.is-selected td,
.is-striped tbody:not(.wb-table__skeleton-body) tr.is-selected td {
  background-color: var(--wb-color-surface-container);
  background-image: linear-gradient(var(--wb-color-fill-selected), var(--wb-color-fill-selected));
}

.wb-table__cell-content,
.wb-table__ellipsis {
  display: block;
  width: 100%;
  max-width: 100%;
  min-width: 0;
}
.wb-table__cell-content,
.wb-table__ellipsis {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.wb-table__ellipsis:focus-visible {
  outline: var(--wb-asset-wb-table-separator-width) solid var(--wb-color-border-focus);
  outline-offset: var(--wb-spacing-component-xs);
}
.wb-table__ellipsis-host {
  display: block;
  width: 100%;
  max-width: 100%;
  min-width: 0;
  overflow: hidden;
}
.wb-table__ellipsis-host :deep(.wb-tooltip-debug) {
  display: block;
  width: 100%;
  max-width: 100%;
  min-width: 0;
  overflow: hidden;
}

.wb-table__state-cell {
  padding: 0;
}
.wb-table__state {
  display: grid;
  min-height: calc(var(--wb-asset-wb-table-body-row-height) * 3);
  place-items: center;
  align-content: center;
  gap: var(--wb-spacing-component-sm);
  padding: var(--wb-spacing-component-xl);
  color: var(--wb-color-text-secondary);
  text-align: center;
}
.wb-table__state strong {
  color: var(--wb-color-text-primary);
}

.wb-table__footer {
  display: flex;
  min-width: 0;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 0;
  min-height: var(--wb-asset-wb-button-height-32);
  margin-block-start: var(--wb-spacing-component-md);
  padding: 0;
  border: 0;
}
.wb-table__total {
  flex: 0 0 auto;
  color: var(--wb-color-text-primary);
}
.wb-table__selection-count {
  color: var(--wb-color-brand);
}
.wb-table__footer :deep(.wb-pagination) {
  margin-inline-start: auto;
}
.wb-table__batch {
  display: flex;
  min-width: 0;
  align-items: center;
  gap: var(--wb-spacing-component-sm);
}
.wb-table__total + .wb-table__batch {
  margin-inline-start: 60px;
}

.wb-table__sr-only {
  position: absolute;
  width: 0;
  height: 0;
  overflow: hidden;
  padding: 0;
  border: 0;
  margin: 0;
  clip-path: inset(50%);
  white-space: nowrap;
}

.wb-table__value {
  min-width: 0;
  white-space: nowrap;
}
.wb-table__value.has-expand {
  display: flex;
  align-items: center;
  gap: var(--wb-spacing-component-sm);
}
.wb-table__expand {
  display: grid;
  flex: none;
  place-items: center;
  padding: 0;
  width: var(--wb-asset-wb-button-height-24);
  height: var(--wb-asset-wb-button-height-24);
  border: 0;
  background: transparent;
  color: var(--wb-color-icon-primary);
  cursor: pointer;
}
.wb-table__expand:focus-visible {
  outline: 1px solid var(--wb-color-border-focus);
}
.wb-table__expand:disabled {
  color: var(--wb-color-icon-disabled);
  cursor: default;
}
.wb-table__detail-row > td {
  padding: 0;
  height: auto;
  background: var(--wb-color-surface-container);
}
.wb-table__detail {
  position: sticky;
  left: 0;
  z-index: 4;
  box-sizing: border-box;
  width: var(--table-viewport-width);
  padding: var(--wb-spacing-layout-container-block) var(--wb-spacing-layout-container-inline);
  background-color: var(--wb-color-surface-container);
  background-image: linear-gradient(
    var(--wb-color-surface-card-tinted),
    var(--wb-color-surface-card-tinted)
  );
}
.wb-table__detail-actions {
  display: flex;
  justify-content: flex-end;
  flex-wrap: wrap;
  gap: var(--wb-spacing-component-sm);
  margin-top: var(--wb-spacing-layout-content-gap);
}
</style>
