// Table cells are border-box; CSS used widths retain fractions without transforms.
export function layoutCellWidth(element) {
  const width = Number.parseFloat(getComputedStyle(element).width);
  return Number.isFinite(width) ? width : element.offsetWidth;
}
