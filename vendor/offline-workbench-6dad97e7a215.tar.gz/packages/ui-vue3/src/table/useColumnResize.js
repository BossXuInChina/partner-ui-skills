import { computed, onBeforeUnmount, ref, shallowRef, watch } from 'vue';
import { clampColumnWidth, columnBounds } from './column-widths.js';

export function useColumnResize({ props, columns, pixelColumns, widths, root, emit }) {
  const localWidths = ref({});
  const drag = shallowRef(null);
  const editorKey = ref(null);
  let suppressClick = false;
  const controlled = computed(() => props.columnWidths !== undefined);
  const overrides = computed(() => (controlled.value ? props.columnWidths : localWidths.value));
  const effectiveWidths = computed(() =>
    drag.value ? { ...overrides.value, [drag.value.key]: drag.value.width } : overrides.value,
  );
  const columnOf = (key) => pixelColumns.value.find((column) => column.key === key);
  const boundsOf = (key) => columnBounds(columnOf(key) ?? {});
  const canResize = (column) => props.resizable && column.resizable !== false;
  function commit(next, key, source) {
    if (!controlled.value) localWidths.value = next;
    emit('update:columnWidths', next);
    emit('column-width-change', {
      key,
      width: key === null ? null : (next[key] ?? null),
      columnWidths: next,
      source,
    });
  }
  function changeWidth(key, value, source) {
    const column = columnOf(key);
    if (!column || props.loading || props.errorMessage) return;
    const current = overrides.value ?? {};
    const next = clampColumnWidth(column, value);
    if (current[key] === next) return;
    commit({ ...current, [key]: next }, key, source);
  }
  function resetColumnWidths(key) {
    cancelDrag();
    const next = { ...(overrides.value ?? {}) };
    if (key === undefined) commit({}, null, 'reset');
    else {
      delete next[key];
      commit(next, key, 'reset');
    }
  }
  function releaseCapture(previous) {
    if (previous?.target.hasPointerCapture(previous.pointerId))
      previous.target.releasePointerCapture(previous.pointerId);
  }
  function cancelDrag() {
    const previous = drag.value;
    drag.value = null;
    if (previous) suppressClick = Boolean(previous.moved);
    releaseCapture(previous);
  }
  function startDrag(key, event) {
    const column = columns.value.find((item) => item.key === key);
    if (event.button !== 0 || !column || !canResize(column) || props.loading || props.errorMessage)
      return;
    cancelDrag();
    suppressClick = false;
    editorKey.value = null;
    const scale = root.value.getBoundingClientRect().width / root.value.offsetWidth || 1;
    const direction = getComputedStyle(root.value).direction === 'rtl' ? -1 : 1;
    event.currentTarget.focus({ preventScroll: true });
    drag.value = {
      key,
      width: widths.value[key],
      startWidth: widths.value[key],
      x: event.clientX,
      scale,
      direction,
      pointerId: event.pointerId,
      target: event.currentTarget,
      moved: false,
    };
    event.currentTarget.setPointerCapture(event.pointerId);
    event.preventDefault();
    event.stopPropagation();
  }
  function moveDrag(event) {
    const current = drag.value;
    if (!current || current.pointerId !== event.pointerId) return;
    const delta = ((event.clientX - current.x) / current.scale) * current.direction;
    drag.value = {
      ...current,
      width: clampColumnWidth(columnOf(current.key), current.startWidth + delta),
      moved: current.moved || Math.abs(delta) >= 1,
    };
    event.preventDefault();
  }
  function endDrag(event) {
    const current = drag.value;
    if (!current || current.pointerId !== event.pointerId) return;
    drag.value = null;
    suppressClick = current.moved;
    releaseCapture(current);
    if (current.moved) changeWidth(current.key, current.width, 'pointer');
  }
  function toggleEditor(key) {
    if (suppressClick) {
      suppressClick = false;
      return;
    }
    editorKey.value = editorKey.value === key ? null : key;
  }
  function keydown(key, event) {
    if (event.key === 'Escape') {
      cancelDrag();
      editorKey.value = null;
      event.preventDefault();
      return;
    }
    if (['Enter', ' '].includes(event.key)) {
      event.preventDefault();
      editorKey.value = key;
      return;
    }
    const { min, max } = boundsOf(key);
    const step = event.shiftKey ? 1 : 10;
    const target = {
      ArrowLeft: widths.value[key] - step,
      ArrowRight: widths.value[key] + step,
      Home: min,
      End: max,
    }[event.key];
    if (target !== undefined) {
      event.preventDefault();
      if (Number.isFinite(target)) changeWidth(key, target, 'keyboard');
    }
  }
  watch(
    () => props.columnWidths,
    () => {
      if (drag.value) cancelDrag();
    },
    { deep: true },
  );
  watch(
    columns,
    (value) => {
      cancelDrag();
      const keys = new Set(value.map((column) => column.key));
      localWidths.value = Object.fromEntries(
        Object.entries(localWidths.value).filter(([key]) => keys.has(key)),
      );
      if (!keys.has(editorKey.value)) editorKey.value = null;
    },
    { deep: true },
  );
  watch(
    () => [props.resizable, props.loading, props.errorMessage],
    () => {
      cancelDrag();
      editorKey.value = null;
    },
  );
  onBeforeUnmount(cancelDrag);
  return {
    effectiveWidths,
    drag,
    editorKey,
    boundsOf,
    canResize,
    changeWidth,
    resetColumnWidths,
    startDrag,
    moveDrag,
    endDrag,
    cancelDrag,
    toggleEditor,
    keydown,
  };
}
