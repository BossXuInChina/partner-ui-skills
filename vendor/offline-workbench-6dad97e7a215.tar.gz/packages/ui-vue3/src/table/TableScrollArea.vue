<script setup>
import { ref, onMounted, onBeforeUnmount } from 'vue';
import WorkbenchScrollbar from '../scrollbar/WorkbenchScrollbar.vue';
import { layoutCellWidth } from './layout-width.js';
import '../../../../catalog/generated/asset.tokens.css';
defineProps({ label: String });
const root = ref();
const scroll = ref();
const track = ref();
const geometry = ref({});
const thumbStyle = ref({});
const overflowing = ref(false);
const dragging = ref(false);
const hiddenLeft = ref(false);
const hiddenRight = ref(false);
let observer, mutationObserver, viewport, drag;
let range = 0,
  travel = 0;
function measure() {
  if (!viewport) return;
  const fixedWidth = (side) =>
    [...viewport.querySelectorAll(`thead [data-fixed="${side}"]`)].reduce(
      (sum, cell) => sum + layoutCellWidth(cell),
      0,
    );
  const left = fixedWidth('left');
  const right = fixedWidth('right');
  range = viewport.scrollWidth - viewport.clientWidth;
  overflowing.value = range > 1;
  const width = Math.max(0, viewport.clientWidth - left - right);
  const length = (width * width) / (width + range || 1);
  travel = width - length;
  hiddenLeft.value = left > 0 && viewport.scrollLeft > 1;
  hiddenRight.value = right > 0 && range - viewport.scrollLeft > 1;
  const nextGeometry = {
    '--table-fixed-left': `${left}px`,
    '--table-fixed-right': `${right}px`,
    '--table-viewport-width': `${viewport.clientWidth}px`,
  };
  const nextThumbStyle = {
    width: `${length}px`,
    transform: `translateX(${range ? (viewport.scrollLeft / range) * travel : 0}px)`,
  };
  if (JSON.stringify(geometry.value) !== JSON.stringify(nextGeometry))
    geometry.value = nextGeometry;
  if (JSON.stringify(thumbStyle.value) !== JSON.stringify(nextThumbStyle))
    thumbStyle.value = nextThumbStyle;
}
defineExpose({ measure });
function down(event) {
  if (event.button !== 0 || !travel) return;
  viewport.focus({ preventScroll: true });
  if (!event.target.closest('.table-scroll__thumb')) {
    const rect = track.value.getBoundingClientRect();
    const scale = rect.width / track.value.clientWidth || 1;
    const length = track.value.clientWidth - travel;
    viewport.scrollLeft = (((event.clientX - rect.left) / scale - length / 2) / travel) * range;
  }
  drag = {
    x: event.clientX,
    scroll: viewport.scrollLeft,
    scale: track.value.getBoundingClientRect().width / track.value.clientWidth || 1,
  };
  dragging.value = true;
  track.value.setPointerCapture(event.pointerId);
  event.preventDefault();
}
function move(event) {
  if (drag)
    viewport.scrollLeft = drag.scroll + ((event.clientX - drag.x) / drag.scale / travel) * range;
}
function end() {
  drag = null;
  dragging.value = false;
}
onMounted(() => {
  viewport = scroll.value.viewport;
  viewport.addEventListener('scroll', measure);
  observer = new ResizeObserver(measure);
  observer.observe(viewport);
  observer.observe(viewport.querySelector('table'));
  mutationObserver = new MutationObserver(measure);
  mutationObserver.observe(viewport.querySelector('table'), {
    subtree: true,
    attributes: true,
    attributeFilter: ['data-fixed'],
    childList: true,
  });
  measure();
});
onBeforeUnmount(() => {
  observer?.disconnect();
  mutationObserver?.disconnect();
  viewport?.removeEventListener('scroll', measure);
});
</script>
<template>
  <div
    ref="root"
    class="table-scroll wb-scrollbar wb-scrollbar--large"
    :class="{
      'has-overflow': overflowing,
      'is-dragging': dragging,
      'has-hidden-left': hiddenLeft,
      'has-hidden-right': hiddenRight,
    }"
    :style="geometry"
  >
    <WorkbenchScrollbar
      ref="scroll"
      axis="horizontal"
      size="default"
      :label="label"
      ><slot
    /></WorkbenchScrollbar>
    <div
      v-if="overflowing"
      ref="track"
      class="table-scroll__track"
      aria-hidden="true"
      @pointerdown="down"
      @pointermove="move"
      @pointerup="end"
      @pointercancel="end"
      @lostpointercapture="end"
    >
      <div
        class="table-scroll__thumb"
        :style="thumbStyle"
      />
    </div>
  </div>
</template>
<style scoped>
.table-scroll {
  position: relative;
  min-width: 0;
  isolation: isolate;
  overflow: hidden;
}
.table-scroll :deep(.wb-scrollarea__track) {
  display: none;
}
.table-scroll__track {
  position: absolute;
  left: var(--table-fixed-left);
  right: var(--table-fixed-right);
  bottom: 0;
  height: var(--scrollbar-width);
  z-index: 4;
  touch-action: none;
  user-select: none;
  overflow: hidden;
}
.table-scroll__thumb {
  position: absolute;
  bottom: 0;
  height: calc(var(--scrollbar-width) - 2 * var(--scrollbar-safe));
  border-radius: var(--wb-radius-full);
  background: var(--scrollbar-fill);
}
.table-scroll__track:hover .table-scroll__thumb,
.is-dragging .table-scroll__thumb {
  height: calc(var(--scrollbar-width) - 2 * var(--scrollbar-safe-hover));
  background: var(--wb-color-scrollbar-thumb-fill-hover);
}
.has-overflow::before,
.has-overflow::after {
  position: absolute;
  top: 0;
  bottom: 0;
  z-index: 3;
  pointer-events: none;
  content: '';
  opacity: 0;
}
.has-hidden-left::before,
.has-hidden-right::after {
  opacity: 1;
}
.has-overflow::before {
  left: 0;
  width: var(--table-fixed-left);
  box-shadow: var(--wb-asset-wb-table-sticky-start-shadow);
}
.has-overflow::after {
  right: 0;
  width: var(--table-fixed-right);
  box-shadow: var(--wb-asset-wb-table-sticky-end-shadow);
}
</style>
