<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, ref, useId, watch } from 'vue';
import WorkbenchPopover from '../popover/WorkbenchPopover.vue';
import WorkbenchCheckbox from '../choice/WorkbenchCheckbox.vue';
import WorkbenchRadio from '../radio/WorkbenchRadio.vue';
import WorkbenchButton from '../button/WorkbenchButton.vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';

const props = defineProps({
  column: { type: Object, required: true },
  values: { type: Array, default: () => [] },
  disabled: Boolean,
  align: String,
});
const emit = defineEmits(['request', 'change', 'reset', 'reset-all']);
const open = ref(false);
const trigger = ref(null);
const panel = ref(null);
const id = `wb-column-filter-${useId()}`;
const builtIn = computed(() => Array.isArray(props.column.filterOptions));
const options = computed(() => props.column.filterOptions ?? []);
const active = computed(() =>
  builtIn.value ? props.values.length > 0 : Boolean(props.column.filtered),
);
const multiple = computed(() => props.column.filterMultiple !== false);
const selectedIndex = computed(() =>
  String(options.value.findIndex((option) => props.values.includes(option.value))),
);

function close(restore = false) {
  open.value = false;
  if (restore) nextTick(() => trigger.value?.focus());
}
function toggle() {
  if (props.disabled) return;
  emit('request');
  if (builtIn.value) {
    open.value = !open.value;
    if (open.value)
      nextTick(() =>
        panel.value?.querySelector('input:not(:disabled),button:not(:disabled)')?.focus(),
      );
  }
}
function select(option, checked) {
  if (props.disabled || option.disabled) return;
  const next = multiple.value
    ? checked
      ? [...new Set([...props.values, option.value])]
      : props.values.filter((value) => value !== option.value)
    : [option.value];
  emit('change', next);
}
function outside(event) {
  if (open.value && !trigger.value?.contains(event.target) && !panel.value?.contains(event.target))
    close();
}
function keydown(event) {
  if (open.value && event.key === 'Escape') {
    event.preventDefault();
    close(true);
  }
}
watch(
  () => props.disabled,
  (disabled) => {
    if (disabled) close();
  },
);
watch(builtIn, (enabled) => {
  if (!enabled) close();
});
onMounted(() => {
  document.addEventListener('pointerdown', outside);
  document.addEventListener('keydown', keydown);
});
onBeforeUnmount(() => {
  document.removeEventListener('pointerdown', outside);
  document.removeEventListener('keydown', keydown);
});
</script>

<template>
  <WorkbenchPopover
    :open="open"
    :disabled="disabled"
    :placement="align === 'end' ? 'bottom-end' : 'bottom-start'"
    :aria-label="`${column.title}筛选`"
    @update:open="
      (value) => {
        if (!value) close();
      }
    "
  >
    <template #trigger>
      <button
        ref="trigger"
        type="button"
        class="wb-table__header-action wb-table__filter"
        :class="{ 'is-active': active }"
        :disabled="disabled"
        :aria-label="`${active ? '修改' : '打开'}${column.title}筛选`"
        :aria-pressed="active"
        :aria-expanded="builtIn ? open : undefined"
        :aria-controls="open ? id : undefined"
        @click="toggle"
      >
        <WorkbenchIcon
          :name="active ? '筛选/类型=已筛选,面性=off_14px' : '筛选/类型=未筛选,面性=off_14px'"
          :color="active ? 'var(--wb-color-text-action)' : 'var(--wb-color-icon-secondary)'"
        />
      </button>
    </template>
    <div
      :id="id"
      ref="panel"
      class="wb-table__column-filter-panel"
      role="group"
      :aria-label="`${column.title}筛选选项`"
    >
      <div
        class="wb-table__column-filter-options"
        :role="multiple ? 'group' : 'radiogroup'"
        :aria-label="`${column.title}可选值`"
      >
        <div
          v-for="(option, index) in options"
          :key="`${typeof option.value}:${option.value}`"
          class="wb-table__column-filter-option"
          :class="{ 'is-disabled': option.disabled, 'is-selected': values.includes(option.value) }"
        >
          <WorkbenchCheckbox
            v-if="multiple"
            :label="option.label"
            :model-value="values.includes(option.value)"
            :disabled="disabled || option.disabled"
            @update:model-value="select(option, $event)"
          />
          <WorkbenchRadio
            v-else
            :label="option.label"
            :name="id"
            :value="String(index)"
            :model-value="selectedIndex"
            :disabled="disabled || option.disabled"
            @update:model-value="select(option, true)"
          />
        </div>
        <span
          v-if="!options.length"
          class="wb-table__column-filter-empty"
          >暂无可选项</span
        >
      </div>
      <div class="wb-table__column-filter-reset">
        <WorkbenchButton
          appearance="text"
          size="28"
          :disabled="disabled"
          @click="emit('reset-all')"
          >重置所有列</WorkbenchButton
        >
        <WorkbenchButton
          appearance="text"
          size="28"
          :disabled="disabled"
          @click="emit('reset')"
          >重置当前列</WorkbenchButton
        >
      </div>
    </div>
  </WorkbenchPopover>
</template>

<style>
.wb-popover__panel:has(> .wb-popover__content > .wb-table__column-filter-panel) {
  width: var(--wb-asset-wb-table-filter-panel-width);
  padding: 0;
}
.wb-popover__panel:has(.wb-table__column-filter-panel) > .wb-popover__arrow {
  display: none;
}
.wb-table__column-filter-panel {
  padding-block-start: var(--wb-spacing-component-xs);
}
.wb-table__column-filter-options {
  display: grid;
  gap: var(--wb-spacing-component-xs);
  max-height: var(--wb-asset-wb-table-filter-options-max-height);
  overflow: auto;
  padding-inline: var(--wb-spacing-component-xs);
}
.wb-table__column-filter-option {
  display: flex;
  align-items: center;
  min-width: 0;
  min-height: var(--wb-asset-wb-table-filter-option-height);
  padding-inline: var(--wb-spacing-component-sm);
  border-radius: var(--wb-radius-sm);
}
.wb-table__column-filter-option:hover:not(.is-disabled),
.wb-table__column-filter-option.is-selected {
  background: var(--wb-color-fill-hover);
}
.wb-table__column-filter-option .wb-choice {
  width: 100%;
  min-width: 0;
}
.wb-table__column-filter-option .wb-choice__label {
  overflow-wrap: anywhere;
}
.wb-table__column-filter-reset {
  display: flex;
  justify-content: space-between;
  align-items: center;
  min-height: var(--wb-asset-wb-table-filter-reset-height);
  border-block-start: var(--wb-asset-wb-table-separator-width) solid
    var(--wb-color-border-separator-subtle);
  gap: var(--wb-spacing-component-xl);
  padding: 0 var(--wb-spacing-component-md);
}
.wb-table__column-filter-reset .wb-button {
  min-width: 0;
  padding-inline: 0;
}
.wb-table__column-filter-empty {
  padding: var(--wb-spacing-component-sm);
  color: var(--wb-color-text-secondary);
}
</style>
