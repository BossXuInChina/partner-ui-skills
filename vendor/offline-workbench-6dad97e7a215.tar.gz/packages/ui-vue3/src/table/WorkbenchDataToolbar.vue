<script setup>
import '../shared/disclosure-motion.css';
import { useId } from 'vue';
import WorkbenchButton from '../button/WorkbenchButton.vue';
import WorkbenchButtonRadioGroup from '../button-radio-group/WorkbenchButtonRadioGroup.vue';
import WorkbenchTag from '../tag/WorkbenchTag.vue';
import WorkbenchTooltip from '../tooltip/WorkbenchTooltip.vue';
import WorkbenchBadge from '../badge/WorkbenchBadge.vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import '../../../../catalog/generated/asset.tokens.css';

const props = defineProps({
  variant: {
    type: String,
    default: 'compact',
    validator: (value) => ['title', 'compact', 'complex'].includes(value),
  },
  title: { type: String, default: '' },
  viewMode: {
    type: String,
    default: 'table',
    validator: (value) => ['table', 'list', 'card'].includes(value),
  },
  filterTags: { type: Array, default: () => [] },
  filterResultText: { type: String, default: '' },
  advancedFilterExpanded: { type: Boolean, default: false },
  refreshing: { type: Boolean, default: false },
  fullscreen: { type: Boolean, default: false },
  showAdvancedFilter: { type: Boolean, default: true },
  showViewSwitch: { type: Boolean, default: true },
});

const emit = defineEmits([
  'update:viewMode',
  'view-change',
  'update:advancedFilterExpanded',
  'filter-confirm',
  'filter-cancel',
  'filter-remove',
  'filter-reset',
  'refresh',
  'settings',
  'fullscreen-change',
]);
const advancedFilterId = `wb-data-toolbar-${useId()}-advanced-filter`;

const viewItems = Object.freeze([
  { value: 'table', label: '表格视图', icon: '布局视图/视图=导航,面性=off_12px' },
  { value: 'card', label: '卡片视图', icon: '布局视图/视图=宫格,面性=off_12px' },
  { value: 'list', label: '列表视图', icon: '布局视图/视图=列表,面性=off_12px' },
]);

function toggleAdvancedFilter() {
  emit('update:advancedFilterExpanded', !props.advancedFilterExpanded);
}

function cancelFilter() {
  emit('filter-cancel');
  emit('update:advancedFilterExpanded', false);
}

function confirmFilter() {
  emit('filter-confirm');
  emit('update:advancedFilterExpanded', false);
}

function changeView(value) {
  emit('update:viewMode', value);
  emit('view-change', value);
}
</script>

<template>
  <section
    class="wb-data-toolbar"
    :class="`wb-data-toolbar--${variant}`"
    aria-label="数据操作区"
  >
    <div class="wb-data-toolbar__main">
      <template v-if="variant === 'title'">
        <h2 class="wb-data-toolbar__title">{{ title }}</h2>
        <div class="wb-data-toolbar__title-actions">
          <slot name="secondary-actions" />
          <slot name="primary-action" />
          <slot name="additional-actions" />
        </div>
      </template>

      <template v-else>
        <div class="wb-data-toolbar__primary-controls">
          <slot name="primary-action" />
          <slot name="secondary-actions" />
          <div
            v-if="$slots.search"
            class="wb-data-toolbar__search"
          >
            <slot name="search" />
          </div>
          <WorkbenchButton
            v-if="showAdvancedFilter"
            class="wb-data-toolbar__advanced-trigger"
            appearance="text"
            size="32"
            :aria-expanded="String(advancedFilterExpanded)"
            :aria-controls="advancedFilterId"
            @click="toggleAdvancedFilter"
          >
            高级筛选
            <WorkbenchBadge
              v-if="filterTags.length"
              class="wb-data-toolbar__filter-count"
              variant="number"
              placement="inline"
              :value="filterTags.length"
              :aria-label="`已生效 ${filterTags.length} 个筛选条件`"
            />
            <WorkbenchIcon
              class="wb-disclosure-icon"
              :class="{ 'is-expanded': advancedFilterExpanded }"
              name="箭头/方向=下箭头_14px"
            />
          </WorkbenchButton>
        </div>

        <div
          v-if="variant === 'complex'"
          class="wb-data-toolbar__auxiliary"
        >
          <WorkbenchButtonRadioGroup
            v-if="showViewSwitch"
            class="wb-data-toolbar__view-switch"
            :model-value="viewMode"
            :items="viewItems"
            aria-label="数据视图"
            @update:model-value="changeView"
          >
            <template #item="{ item }">
              <WorkbenchIcon
                class="wb-data-toolbar__view-icon"
                :name="item.icon"
              />
              <span class="wb-data-toolbar__sr-only">{{ item.label }}</span>
            </template>
          </WorkbenchButtonRadioGroup>
          <div
            class="wb-data-toolbar__icon-actions"
            aria-label="附属操作"
          >
            <WorkbenchTooltip content="刷新">
              <template #trigger="{ aria }"
                ><button
                  class="wb-data-toolbar__utility-button"
                  type="button"
                  aria-label="刷新"
                  :disabled="refreshing"
                  v-bind="aria"
                  @click="emit('refresh')"
                >
                  <WorkbenchIcon
                    class="wb-data-toolbar__utility-icon"
                    name="刷新_14px"
                  /></button
              ></template>
            </WorkbenchTooltip>
            <WorkbenchTooltip content="设置">
              <template #trigger="{ aria }"
                ><button
                  class="wb-data-toolbar__utility-button"
                  type="button"
                  aria-label="设置"
                  v-bind="aria"
                  @click="emit('settings')"
                >
                  <WorkbenchIcon
                    class="wb-data-toolbar__utility-icon"
                    name="/ic_public_setting_line_14px"
                  /></button
              ></template>
            </WorkbenchTooltip>
            <WorkbenchTooltip :content="fullscreen ? '退出全屏' : '全屏'">
              <template #trigger="{ aria }"
                ><button
                  class="wb-data-toolbar__utility-button"
                  type="button"
                  :aria-label="fullscreen ? '退出全屏' : '全屏'"
                  :aria-pressed="fullscreen"
                  v-bind="aria"
                  @click="emit('fullscreen-change', !fullscreen)"
                >
                  <WorkbenchIcon
                    class="wb-data-toolbar__utility-icon"
                    name="全屏_14px"
                  /></button
              ></template>
            </WorkbenchTooltip>
          </div>
          <slot name="additional-actions" />
        </div>
        <div
          v-else-if="$slots['additional-actions']"
          class="wb-data-toolbar__additional"
        >
          <slot name="additional-actions" />
        </div>
      </template>
    </div>

    <div
      v-if="variant !== 'title' && showAdvancedFilter && advancedFilterExpanded"
      :id="advancedFilterId"
      class="wb-data-toolbar__advanced"
      aria-label="高级筛选表单"
    >
      <div class="wb-data-toolbar__advanced-fields"><slot name="advanced-filter-form" /></div>
      <div class="wb-data-toolbar__advanced-actions">
        <WorkbenchButton
          appearance="secondary"
          size="32"
          @click="cancelFilter"
          >取消</WorkbenchButton
        >
        <WorkbenchButton
          size="32"
          @click="confirmFilter"
          >确定</WorkbenchButton
        >
      </div>
    </div>

    <div
      v-if="variant !== 'title' && filterTags.length"
      class="wb-data-toolbar__applied"
      aria-label="已生效筛选条件"
    >
      <span
        v-if="filterResultText"
        class="wb-data-toolbar__result"
        >{{ filterResultText }}</span
      >
      <span class="wb-data-toolbar__applied-label">筛选条件：</span>
      <WorkbenchTag
        v-for="tag in filterTags"
        :key="tag.key"
        :label="tag.label"
        variant="basic"
        size="medium"
        action="remove"
        :disabled="tag.disabled"
        @remove="emit('filter-remove', tag)"
      />
      <WorkbenchButton
        class="wb-data-toolbar__reset"
        appearance="text"
        size="28"
        @click="emit('filter-reset')"
      >
        重置
        <template #icon><WorkbenchIcon name="刷新_14px" /></template>
      </WorkbenchButton>
    </div>
  </section>
</template>

<style scoped>
.wb-data-toolbar {
  display: grid;
  min-width: 0;
  margin-block-end: var(--wb-spacing-layout-content-gap);
  color: var(--wb-color-text-primary);
  background: var(--wb-color-surface-container);
  border-block-end: 0;
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
}
.wb-data-toolbar:has(.wb-data-toolbar__advanced) {
  margin-block-end: 0;
}
.wb-data-toolbar__main {
  --select-field-width: var(--wb-asset-wb-select-default-width);
  display: flex;
  min-width: 0;
  min-height: var(--wb-asset-wb-button-height-32);
  box-sizing: border-box;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: var(--wb-spacing-component-md) var(--wb-spacing-component-xl);
  padding-block: 0;
  padding-inline: 0;
}
.wb-data-toolbar__title {
  margin: 0;
  font-size: var(--wb-font-headline-s-font-size);
  font-weight: var(--wb-font-headline-s-font-weight);
  line-height: var(--wb-font-headline-s-line-height);
  letter-spacing: var(--wb-font-headline-s-letter-spacing);
}
.wb-data-toolbar__title-actions,
.wb-data-toolbar__primary-controls,
.wb-data-toolbar__auxiliary,
.wb-data-toolbar__additional,
.wb-data-toolbar__icon-actions,
.wb-data-toolbar__advanced-actions,
.wb-data-toolbar__applied {
  display: flex;
  min-width: 0;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--wb-spacing-component-sm);
}
.wb-data-toolbar__title-actions,
.wb-data-toolbar__auxiliary,
.wb-data-toolbar__additional {
  margin-inline-start: auto;
}
.wb-data-toolbar__primary-controls {
  flex: 1 1 auto;
  flex-wrap: nowrap;
}
.wb-data-toolbar__auxiliary {
  flex: 0 0 auto;
  gap: var(--wb-spacing-component-xl);
}
.wb-data-toolbar__additional {
  flex: 0 0 auto;
}
.wb-data-toolbar__search {
  width: var(--wb-asset-wb-table-toolbar-search-width);
  flex: 0 0 var(--wb-asset-wb-table-toolbar-search-width);
  min-width: 0;
}
.wb-data-toolbar__search :deep(.wb-search) {
  width: 100%;
}
.wb-data-toolbar__search :deep(.wb-search__core) {
  min-width: 0;
  flex-shrink: 1;
}
.wb-data-toolbar__view-switch {
  gap: var(--wb-asset-wb-table-view-switch-gap);
  width: var(--wb-asset-wb-table-view-switch-width);
  height: var(--wb-asset-wb-button-height-28);
}
.wb-data-toolbar__view-switch :deep(.wb-button-radio-group__item) {
  display: grid;
  width: var(--wb-asset-wb-button-height-24);
  height: var(--wb-asset-wb-button-height-24);
  padding: 0;
  place-items: center;
}
.wb-data-toolbar__view-switch :deep(.wb-button-radio-group__highlight) {
  height: var(--wb-asset-wb-button-height-24);
}
.wb-data-toolbar__icon-actions {
  flex-wrap: nowrap;
  gap: var(--wb-asset-wb-table-toolbar-utility-gap);
}
.wb-data-toolbar__utility-button {
  appearance: none;
  position: relative;
  display: inline-flex;
  box-sizing: border-box;
  width: var(--wb-asset-wb-table-toolbar-utility-icon-size);
  height: var(--wb-asset-wb-button-height-24);
  flex: none;
  align-items: center;
  justify-content: center;
  padding: 0;
  border: 0;
  background: transparent;
  color: var(--wb-color-icon-primary);
  cursor: pointer;
}
.wb-data-toolbar__utility-button::before {
  position: absolute;
  inset-block: 0;
  inset-inline-end: 0;
  width: var(--wb-asset-wb-button-height-24);
  border-radius: var(--wb-radius-sm);
  content: '';
}
.wb-data-toolbar__utility-button:hover:not(:disabled) {
  color: var(--wb-color-icon-hover);
}
.wb-data-toolbar__utility-button:active:not(:disabled) {
  color: var(--wb-color-icon-active);
}
.wb-data-toolbar__utility-button:focus-visible {
  outline: none;
}
.wb-data-toolbar__utility-button:focus-visible::before {
  outline: 1px solid var(--wb-color-border-focus);
  outline-offset: 1px;
}
.wb-data-toolbar__utility-button:disabled {
  color: var(--wb-color-icon-disabled);
  cursor: not-allowed;
}
.wb-data-toolbar__advanced-trigger {
  position: relative;
}
.wb-data-toolbar__advanced-trigger[aria-expanded='true'] {
  background: var(--wb-color-surface-card-tinted);
}
.wb-data-toolbar__advanced-trigger[aria-expanded='true']::after {
  position: absolute;
  top: 100%;
  inset-inline: 0;
  height: var(--wb-spacing-component-md);
  background: var(--wb-color-surface-card-tinted);
  content: '';
  pointer-events: none;
}
.wb-data-toolbar__advanced-trigger :deep(.wb-button__label) {
  display: inline-flex;
  align-items: center;
  gap: var(--wb-spacing-component-sm);
}
.wb-data-toolbar__filter-count {
  flex: none;
}
.wb-data-toolbar__advanced {
  position: relative;
  z-index: 5;
  display: grid;
  gap: 0;
  margin-block: var(--wb-spacing-component-md) var(--wb-spacing-layout-content-gap);
  padding-block-start: var(--wb-spacing-layout-container-block);
  padding-block-end: var(--wb-spacing-component-xl);
  padding-inline: var(--wb-spacing-layout-container-inline);
  border-radius: 0;
  background: var(--wb-color-surface-card-tinted);
}
.wb-data-toolbar__advanced-fields {
  min-width: 0;
}
.wb-data-toolbar__advanced-actions {
  justify-content: flex-end;
  margin-block-start: var(--wb-spacing-component-xl);
}
.wb-data-toolbar__applied {
  height: var(--wb-asset-wb-tag-height-medium);
  flex-wrap: nowrap;
  margin-block-start: var(--wb-spacing-component-sm);
  padding: 0;
  overflow: visible;
  border: 0;
}
.wb-data-toolbar__result,
.wb-data-toolbar__applied-label {
  color: var(--wb-color-text-primary);
  white-space: nowrap;
}
.wb-data-toolbar__reset {
  --button-block-size: var(--wb-asset-wb-table-toolbar-reset-height);
  --button-inline-padding: 0;
  flex: none;
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
}
.wb-data-toolbar__reset :deep(.wb-button__icon) {
  width: var(--wb-asset-wb-table-toolbar-utility-icon-size);
  height: var(--wb-asset-wb-table-toolbar-utility-icon-size);
}
@container wb-table (max-width: 720px) {
  .wb-data-toolbar__primary-controls,
  .wb-data-toolbar__auxiliary,
  .wb-data-toolbar__additional {
    flex-basis: 100%;
  }
  .wb-data-toolbar__auxiliary {
    margin-inline-start: 0;
    justify-content: space-between;
  }
  .wb-data-toolbar__additional {
    margin-inline-start: 0;
  }
}
@container wb-table (max-width: 620px) {
  .wb-data-toolbar__primary-controls {
    flex-wrap: wrap;
  }
  .wb-data-toolbar__search {
    width: 100%;
    flex-basis: 100%;
    order: 4;
  }
}
.wb-data-toolbar__sr-only {
  position: absolute;
  width: var(--wb-asset-wb-table-screen-reader-box-size);
  height: var(--wb-asset-wb-table-screen-reader-box-size);
  overflow: hidden;
  padding: 0;
  border: 0;
  margin: var(--wb-asset-wb-table-screen-reader-offset);
  clip-path: inset(50%);
  white-space: nowrap;
}
</style>
