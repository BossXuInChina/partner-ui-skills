// Allocation uses layout pixels resolved by the caller, independently of cell text.
export function numericPixels(value) {
  if (Number.isFinite(value) && value >= 0) return value;
  if (typeof value === 'string' && /^\d+(?:\.\d+)?px$/.test(value.trim()))
    return Number.parseFloat(value);
  return 0;
}

export function columnBounds(column) {
  const min = numericPixels(column.minWidth);
  const value = column.maxWidth;
  const validMax =
    (Number.isFinite(value) && value >= 0) ||
    (typeof value === 'string' && /^\d+(?:\.\d+)?px$/.test(value.trim()));
  return { min, max: validMax ? Math.max(min, numericPixels(value)) : Infinity };
}

export function clampColumnWidth(column, width) {
  const { min, max } = columnBounds(column);
  return Math.min(max, Math.max(min, width));
}

function minimum(column) {
  return clampColumnWidth(
    column,
    Math.max(numericPixels(column.width), numericPixels(column.minWidth)),
  );
}

// Water filling freezes both minima and maxima before redistributing remaining space.
function equalWidths(columns, available) {
  const widths = {};
  let pending = [...columns];
  let remaining = available;
  while (pending.length) {
    const share = Math.max(0, remaining / pending.length);
    const minima = pending.filter((column) => minimum(column) > share);
    const constrained = minima.length
      ? minima
      : pending.filter((column) => columnBounds(column).max < share);
    if (!constrained.length) {
      const aligned = Math.floor(share * 64) / 64;
      let assigned = 0;
      pending.forEach((column, index) => {
        const value = index === pending.length - 1 ? Math.max(0, remaining) - assigned : aligned;
        widths[column.key] = clampColumnWidth(column, value);
        assigned += widths[column.key];
      });
      break;
    }
    constrained.forEach((column) => {
      widths[column.key] = Math.min(columnBounds(column).max, Math.max(minimum(column), share));
      remaining -= widths[column.key];
    });
    pending = pending.filter((column) => !constrained.includes(column));
  }
  const extra = available - Object.values(widths).reduce((sum, width) => sum + width, 0);
  const growable = columns.filter((column) => widths[column.key] < columnBounds(column).max);
  // A later upper cap may release space after another column was frozen at its minimum.
  // Re-solve only the uncapped subset, retaining equal allocation and all original bounds.
  if (extra > 0 && growable.length > 0 && growable.length < columns.length) {
    const capacity = growable.reduce((sum, column) => sum + widths[column.key], extra);
    Object.assign(widths, equalWidths(growable, capacity));
  }
  return widths;
}

export function resolveColumnWidths(columns, available, primaryKey, manualWidths = {}) {
  const manual = (column) =>
    Object.hasOwn(manualWidths, column.key) &&
    Number.isFinite(manualWidths[column.key]) &&
    manualWidths[column.key] >= 0;
  const automatic = columns.filter((column) => !manual(column));
  const explicit = automatic.find((column) => column.fluid);
  const unspecified = automatic.filter(
    (column) => column.width === undefined || column.width === null || column.width === '',
  );
  const widths = Object.fromEntries(
    columns.map((column) => [
      column.key,
      manual(column) ? clampColumnWidth(column, manualWidths[column.key]) : minimum(column),
    ]),
  );
  if (!explicit && unspecified.length) {
    const fixed = columns.filter((column) => !unspecified.includes(column));
    return {
      ...Object.fromEntries(fixed.map((column) => [column.key, widths[column.key]])),
      ...equalWidths(
        unspecified,
        available - fixed.reduce((sum, column) => sum + widths[column.key], 0),
      ),
    };
  }
  const receiver =
    explicit ??
    automatic.find((column) => column.ellipsis && column.key !== primaryKey) ??
    automatic.find((column) => !column.fixed && column.key !== primaryKey) ??
    automatic.find((column) => column.key === primaryKey);
  if (receiver) {
    const other = columns.reduce(
      (sum, column) => sum + (column === receiver ? 0 : widths[column.key]),
      0,
    );
    widths[receiver.key] = clampColumnWidth(
      receiver,
      Math.max(widths[receiver.key], available - other),
    );
  }
  return widths;
}
