<script setup>
import { computed, useId } from 'vue';
import WorkbenchButton from '../button/WorkbenchButton.vue';
import WorkbenchPopover from '../popover/WorkbenchPopover.vue';
const props = defineProps({
  column: { type: Object, required: true },
  width: Number,
  minimum: Number,
  maximum: Number,
  disabled: Boolean,
  open: Boolean,
});
const descriptionId = useId();
const bounded = computed(() => Number.isFinite(props.maximum));
const emit = defineEmits([
  'pointerdown',
  'pointermove',
  'pointerup',
  'cancel',
  'click',
  'keydown',
  'close',
  'adjust',
  'reset',
  'reset-all',
]);
</script>
<template>
  <span class="wb-table__resize-control">
    <WorkbenchPopover
      placement="bottom-end"
      :open="open"
      :disabled="disabled"
      :aria-label="`${column.title}列宽设置`"
      @update:open="
        (value) => {
          if (!value) emit('close');
        }
      "
    >
      <template #trigger="{ aria }">
        <button
          class="wb-table__resize-handle"
          type="button"
          :role="bounded ? 'slider' : 'button'"
          :aria-orientation="bounded ? 'horizontal' : undefined"
          :aria-label="`调整${column.title}列宽`"
          :aria-valuemin="bounded ? minimum : undefined"
          :aria-valuemax="bounded ? maximum : undefined"
          :aria-valuenow="bounded ? width : undefined"
          :aria-valuetext="bounded ? `${width}像素` : undefined"
          :disabled="disabled"
          v-bind="aria"
          :aria-describedby="[descriptionId, aria['aria-describedby']].filter(Boolean).join(' ')"
          @pointerdown="emit('pointerdown', $event)"
          @pointermove="emit('pointermove', $event)"
          @pointerup="emit('pointerup', $event)"
          @pointercancel="emit('cancel')"
          @lostpointercapture="emit('cancel')"
          @click.stop="emit('click')"
          @keydown.stop="emit('keydown', $event)"
        />
      </template>
      <div
        class="wb-table__width-editor"
        role="group"
        :aria-label="`${column.title}列宽设置`"
      >
        <output aria-live="polite">{{ column.title }}：{{ Math.round(width) }} px</output>
        <div class="wb-table__width-editor-actions">
          <WorkbenchButton
            appearance="secondary"
            size="32"
            :disabled="width <= minimum"
            @click="emit('adjust', -10)"
            >减小列宽</WorkbenchButton
          >
          <WorkbenchButton
            appearance="secondary"
            size="32"
            :disabled="width >= maximum"
            @click="emit('adjust', 10)"
            >增大列宽</WorkbenchButton
          >
          <WorkbenchButton
            appearance="text"
            size="32"
            @click="emit('reset')"
            >重置此列</WorkbenchButton
          >
          <WorkbenchButton
            appearance="text"
            size="32"
            @click="emit('reset-all')"
            >重置全部列宽</WorkbenchButton
          >
        </div>
      </div>
    </WorkbenchPopover>
    <span
      :id="descriptionId"
      hidden
      >当前{{ width }}像素，最小{{ minimum }}像素，{{
        bounded ? `最大${maximum}像素` : '未设置上限'
      }}。可拖动；方向键调整，Shift微调，Home到最小，回车打开列宽设置。</span
    >
  </span>
</template>
<style scoped>
.wb-table__resize-control {
  position: absolute;
  inset-block: 0;
  inset-inline-end: 0;
  width: var(--wb-spacing-component-sm);
  z-index: 2;
}
.wb-table__resize-handle {
  appearance: none;
  display: block;
  width: 100%;
  height: 100%;
  padding: 0;
  border: 0;
  background: transparent;
  cursor: col-resize;
  touch-action: none;
  user-select: none;
}
.wb-table__resize-control :deep(.wb-popover) {
  width: 100%;
  height: 100%;
}
.wb-table__resize-handle:focus-visible {
  outline: var(--wb-asset-wb-table-separator-width) solid var(--wb-color-border-focus);
  outline-offset: calc(var(--wb-asset-wb-table-separator-width) * -1);
}
.wb-table__resize-handle:disabled {
  cursor: not-allowed;
}
.wb-table__width-editor {
  display: grid;
  gap: var(--wb-spacing-component-sm);
}
.wb-table__width-editor-actions {
  display: flex;
  flex-wrap: wrap;
  gap: var(--wb-spacing-component-sm);
}
</style>
