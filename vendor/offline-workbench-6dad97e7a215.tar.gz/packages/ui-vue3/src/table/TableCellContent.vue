<script setup>
import { onMounted, onUpdated, ref } from 'vue';
import WorkbenchTooltip from '../tooltip/WorkbenchTooltip.vue';
const element = ref(null);
const text = ref('');
const editable = ref(false);
function syncContent() {
  text.value = element.value?.textContent?.trim() ?? '';
  editable.value = Boolean(
    element.value?.querySelector('input, textarea, select, button, [role="combobox"]'),
  );
}
onMounted(syncContent);
onUpdated(syncContent);
</script>
<template>
  <span class="wb-table__slot-host">
    <WorkbenchTooltip
      :content="text"
      :disabled="editable || !text"
      overflow-only
    >
      <template #trigger="{ aria }">
        <div
          ref="element"
          class="wb-table__slot-content"
          :class="{ 'is-editable': editable }"
          :tabindex="editable ? undefined : 0"
          :aria-describedby="aria['aria-describedby']"
        >
          <slot />
        </div>
      </template>
    </WorkbenchTooltip>
  </span>
</template>
<style scoped>
.wb-table__slot-host,
.wb-table__slot-host > :deep(.wb-tooltip-debug),
.wb-table__slot-content {
  display: block;
  width: 100%;
  max-width: 100%;
  min-width: 0;
}
.wb-table__slot-content {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.wb-table__slot-content.is-editable {
  overflow: visible;
}
.wb-table__slot-content :deep(> *) {
  max-width: 100%;
  min-width: 0;
}
.wb-table__slot-content:focus-visible {
  outline: var(--wb-asset-wb-table-separator-width) solid var(--wb-color-border-focus);
  outline-offset: var(--wb-spacing-component-xs);
}
</style>
