<script setup>
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue';
import WorkbenchCheckbox from '../choice/WorkbenchCheckbox.vue';
import WorkbenchLink from '../link/WorkbenchLink.vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import WorkbenchStatusIcon from '../icons/WorkbenchStatusIcon.vue';

const statusIconSemantics = {
  info: 'info',
  success: 'success',
  warning: 'warning',
  danger: 'alert-orange',
  critical: 'alert-red',
  error: 'close_circle',
};

const props = defineProps({
  modelValue: { type: Boolean, default: true },
  type: {
    type: String,
    default: 'info',
    validator: (value) =>
      ['info', 'success', 'warning', 'danger', 'critical', 'error'].includes(value),
  },
  message: { type: String, required: true },
  linkLabel: { type: String, default: '' },
  linkHref: { type: String, default: '' },
  showIcon: { type: Boolean, default: true },
  showClose: { type: Boolean, default: true },
  checkboxLabel: { type: String, default: '' },
  checkboxChecked: { type: Boolean, default: false },
  surface: {
    type: String,
    default: undefined,
    validator: (value) => ['semantic', 'neutral'].includes(value),
  },
  placement: {
    type: String,
    default: 'page',
    validator: (value) => ['product', 'global', 'page', 'card', 'dialog'].includes(value),
  },
});

const emit = defineEmits(['update:modelValue', 'update:checkboxChecked', 'link', 'close']);
const resolvedSurface = computed(
  () => props.surface ?? (['product', 'global'].includes(props.placement) ? 'neutral' : 'semantic'),
);
const statusIconName = computed(() => `${statusIconSemantics[props.type]}/solid/14`);
const role = computed(() => (['critical', 'error'].includes(props.type) ? 'alert' : 'status'));
const alertRef = ref(null);
const measureRef = ref(null);
const isWrapped = ref(false);
let resizeObserver;

function tokenNumber(styles, name) {
  return Number.parseFloat(styles.getPropertyValue(name)) || 0;
}

function updateWrapping() {
  const alert = alertRef.value;
  const measure = measureRef.value;
  if (!alert || !measure) return;
  const styles = getComputedStyle(alert);
  const compactGap = tokenNumber(styles, '--wb-spacing-component-sm');
  const looseGap = Number.parseFloat(styles.columnGap) || 0;
  const contentWidth =
    alert.clientWidth -
    Number.parseFloat(styles.paddingLeft) -
    Number.parseFloat(styles.paddingRight);
  const icon = alert.querySelector('.wb-alert__icon');
  const checkbox = alert.querySelector('.wb-alert__checkbox');
  const closeButton = alert.querySelector('.wb-alert__close');
  const iconWidth = icon ? icon.getBoundingClientRect().width + compactGap : 0;
  const checkboxWidth = checkbox ? checkbox.getBoundingClientRect().width + looseGap : 0;
  const closeWidth = closeButton ? closeButton.getBoundingClientRect().width + looseGap : 0;
  isWrapped.value =
    measure.getBoundingClientRect().width + iconWidth + checkboxWidth + closeWidth > contentWidth;
}

function activateLink() {
  emit('link', { href: props.linkHref });
}

function updateCheckbox(checked) {
  emit('update:checkboxChecked', checked);
}

function close() {
  emit('update:modelValue', false);
  emit('close', { reason: 'button', checkboxChecked: props.checkboxChecked });
}

watch(
  () => [
    props.modelValue,
    props.message,
    props.linkLabel,
    props.linkHref,
    props.showIcon,
    props.showClose,
    props.checkboxLabel,
  ],
  () => nextTick(updateWrapping),
);
watch(
  alertRef,
  (current, previous) => {
    if (previous) resizeObserver?.unobserve(previous);
    if (current) resizeObserver?.observe(current);
    nextTick(updateWrapping);
  },
  { flush: 'post' },
);
onMounted(() => {
  resizeObserver = new ResizeObserver(updateWrapping);
  if (alertRef.value) resizeObserver.observe(alertRef.value);
  nextTick(updateWrapping);
});
onBeforeUnmount(() => resizeObserver?.disconnect());
</script>

<template>
  <section
    v-if="modelValue"
    ref="alertRef"
    class="wb-alert"
    :class="[
      `wb-alert--${type}`,
      `is-${resolvedSurface}`,
      `is-${placement}-placement`,
      { 'has-icon': showIcon, 'is-wrapped': isWrapped },
    ]"
    :role="role"
    :aria-live="role === 'alert' ? 'assertive' : 'polite'"
  >
    <div class="wb-alert__main">
      <span
        v-if="showIcon"
        class="wb-alert__icon"
        :data-status-icon="statusIconName"
        aria-hidden="true"
        ><WorkbenchStatusIcon :name="statusIconName"
      /></span>
      <p class="wb-alert__copy">
        <span>{{ message }}</span>
        <WorkbenchLink
          v-if="linkLabel && linkHref"
          :href="linkHref"
          class="wb-alert__link"
          @click="activateLink"
          >{{ linkLabel }}</WorkbenchLink
        >
      </p>
    </div>

    <WorkbenchCheckbox
      v-if="checkboxLabel"
      class="wb-alert__checkbox"
      :model-value="checkboxChecked"
      :label="checkboxLabel"
      @update:model-value="updateCheckbox"
    />

    <button
      v-if="showClose"
      class="wb-alert__close"
      type="button"
      aria-label="关闭公告"
      @click="close"
    >
      <WorkbenchIcon name="/ic_public_close_line_10px" />
    </button>
    <span
      ref="measureRef"
      class="wb-alert__measure"
      aria-hidden="true"
      ><span>{{ message }}</span
      ><span v-if="linkLabel && linkHref">{{ linkLabel }}</span></span
    >
  </section>
</template>

<style>
.wb-alert {
  position: relative;
  display: flex;
  width: 100%;
  min-width: 0;
  box-sizing: border-box;
  align-items: flex-start;
  column-gap: var(--wb-spacing-component-lg);
  padding: var(--wb-spacing-component-md) var(--wb-spacing-component-lg);
  border-radius: var(--wb-radius-lg);
  color: var(--wb-color-text-primary);
}
.wb-alert.is-product-placement {
  border-radius: 0;
}
.wb-alert.is-neutral {
  background: var(--wb-color-none-subtle);
}
.wb-alert.is-semantic.wb-alert--info {
  background: var(--wb-color-info-secondary-subtle);
}
.wb-alert.is-semantic.wb-alert--success {
  background: var(--wb-color-success-primary-subtle);
}
.wb-alert.is-semantic.wb-alert--warning {
  background: var(--wb-color-warning-subtle);
}
.wb-alert.is-semantic.wb-alert--danger {
  background: var(--wb-color-alert-subtle);
}
.wb-alert.is-semantic.wb-alert--critical,
.wb-alert.is-semantic.wb-alert--error {
  background: var(--wb-color-error-subtle);
}
.wb-alert__main {
  display: flex;
  min-width: 0;
  flex: 1 1 auto;
  align-items: flex-start;
}
.wb-alert.has-icon .wb-alert__main {
  gap: var(--wb-spacing-component-sm);
}
.wb-alert__icon {
  display: flex;
  width: var(--wb-asset-wb-alert-status-icon-size);
  height: var(--wb-asset-wb-alert-status-icon-size);
  flex: 0 0 var(--wb-asset-wb-alert-status-icon-size);
  margin-block-start: calc(
    (var(--wb-font-body-m-line-height) - var(--wb-asset-wb-alert-status-icon-size)) / 2
  );
  align-items: center;
}
.wb-alert__copy {
  display: flex;
  min-width: 0;
  flex-wrap: nowrap;
  align-items: baseline;
  gap: var(--wb-spacing-component-sm);
  margin: 0;
  overflow-wrap: anywhere;
  white-space: nowrap;
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
}
.wb-alert__link {
  flex: 0 0 auto;
  min-width: 0;
  max-width: 100%;
}
.wb-alert__checkbox {
  flex: 0 0 auto;
  align-items: flex-start;
  min-width: 0;
  max-width: 100%;
  overflow-wrap: anywhere;
}
.wb-alert__close {
  display: flex;
  width: var(--wb-icon-size-16);
  height: var(--wb-font-body-m-line-height);
  flex: 0 0 var(--wb-icon-size-16);
  align-items: center;
  justify-content: center;
  padding: 0;
  border: 0;
  color: var(--wb-color-icon-primary);
  background: transparent;
  cursor: pointer;
}
.wb-alert__close:hover {
  color: var(--wb-color-icon-hover);
}
.wb-alert__close:active {
  color: var(--wb-color-icon-active);
}
.wb-alert__close:focus-visible {
  outline: 1px solid var(--wb-color-border-focus);
  outline-offset: 2px;
}
.wb-alert__measure {
  position: fixed;
  top: 0;
  left: 0;
  visibility: hidden;
  display: inline-flex;
  width: max-content;
  align-items: baseline;
  gap: var(--wb-spacing-component-sm);
  white-space: nowrap;
  pointer-events: none;
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
}
.wb-alert.is-wrapped {
  display: grid;
  grid-template-columns: minmax(0, 1fr) var(--wb-icon-size-16);
  row-gap: var(--wb-spacing-component-sm);
}
.wb-alert.is-wrapped:not(:has(.wb-alert__close)) {
  grid-template-columns: minmax(0, 1fr);
}
.wb-alert.is-wrapped .wb-alert__main {
  grid-column: 1;
  grid-row: 1;
}
.wb-alert.is-wrapped .wb-alert__copy {
  flex-wrap: wrap;
  white-space: normal;
}
.wb-alert.is-wrapped .wb-alert__checkbox {
  grid-column: 1;
  grid-row: 2;
  justify-self: start;
  margin-inline-start: 0;
}
.wb-alert.is-wrapped.has-icon .wb-alert__checkbox {
  margin-inline-start: calc(
    var(--wb-asset-wb-alert-status-icon-size) + var(--wb-spacing-component-sm)
  );
  max-width: calc(
    100% - var(--wb-asset-wb-alert-status-icon-size) - var(--wb-spacing-component-sm)
  );
}
.wb-alert.is-wrapped .wb-alert__close {
  grid-column: 2;
  grid-row: 1;
  margin-inline-start: 0;
}
</style>
