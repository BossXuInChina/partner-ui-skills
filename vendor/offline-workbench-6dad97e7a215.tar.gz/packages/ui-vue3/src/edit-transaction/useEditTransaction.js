import { computed, ref, toRaw, toValue } from 'vue';

const clone = (value) => JSON.parse(JSON.stringify(toRaw(value)));
function replace(target, value) {
  for (const key of Object.keys(target)) delete target[key];
  Object.assign(target, clone(value));
}
export function useEditTransaction({ model, active }) {
  const baseline = ref(clone(model));
  const leaveOpen = ref(false);
  const pendingNavigation = ref(null);
  const saving = ref(false);
  const error = ref(null);
  const dirty = computed(
    () => Boolean(toValue(active)) && JSON.stringify(model) !== JSON.stringify(baseline.value),
  );
  function markSaved() {
    baseline.value = clone(model);
    error.value = null;
  }
  function reset(value) {
    replace(model, value);
    markSaved();
    leaveOpen.value = false;
    pendingNavigation.value = null;
  }
  function navigate(action) {
    if (dirty.value) {
      pendingNavigation.value = action;
      leaveOpen.value = true;
      return false;
    }
    action();
    return true;
  }
  function cancelLeave() {
    leaveOpen.value = false;
    pendingNavigation.value = null;
  }
  function confirmLeave() {
    const action = pendingNavigation.value;
    cancelLeave();
    if (!action) return;
    replace(model, baseline.value);
    error.value = null;
    action();
  }
  async function runSave(action) {
    if (saving.value) return { ok: false, error: new Error('Save already pending') };
    saving.value = true;
    error.value = null;
    try {
      const value = await action();
      markSaved();
      return { ok: true, value };
    } catch (reason) {
      error.value = reason;
      return { ok: false, error: reason };
    } finally {
      saving.value = false;
    }
  }
  return {
    dirty,
    baseline,
    leaveOpen,
    pendingNavigation,
    saving,
    error,
    reset,
    markSaved,
    navigate,
    confirmLeave,
    cancelLeave,
    runSave,
  };
}

export default useEditTransaction;
