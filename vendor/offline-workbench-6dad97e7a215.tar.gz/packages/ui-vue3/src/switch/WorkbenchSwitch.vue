<script setup>
import { useFormDisabled } from '../form/useFormDisabled.js';
import { useFieldControl } from '../form/fieldContext.js';
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import WorkbenchLoading from '../loading/WorkbenchLoading.vue';
import { nextTick, ref } from 'vue';

const props = defineProps({
  modelValue: Boolean,
  disabled: Boolean,
  loading: Boolean,
  name: String,
  value: { type: String, default: 'on' },
  label: { type: String, default: '' },
  ariaLabel: { type: String, default: '' },
  ariaDescribedby: String,
  invalid: Boolean,
});
const disabled = useFormDisabled(() => props.disabled);
const emit = defineEmits(['update:modelValue']);
const native = ref(null);
function change(event) {
  emit('update:modelValue', event.target.checked);
  nextTick(() => {
    if (native.value) native.value.checked = props.modelValue;
  });
}
const { attrs: fieldAttrs } = useFieldControl(() => props.modelValue, {
  nativeRequired: true,
  describedBy: () => props.ariaDescribedby,
  invalid: () => props.invalid,
  focus: () => native.value?.focus(),
});
</script>
<template>
  <label
    class="wb-switch"
    :class="{ 'is-disabled': disabled, 'is-loading': loading }"
    :aria-busy="loading || undefined"
  >
    <input
      ref="native"
      class="wb-switch__input"
      type="checkbox"
      role="switch"
      :name="name"
      :value="value"
      :checked="modelValue"
      :disabled="disabled || loading"
      :aria-label="ariaLabel || label || '开关'"
      :aria-describedby="ariaDescribedby"
      :aria-invalid="invalid || undefined"
      :aria-busy="loading || undefined"
      v-bind="fieldAttrs"
      @change="change"
    />
    <span
      class="wb-switch__track"
      aria-hidden="true"
      ><span class="wb-switch__thumb"
        ><WorkbenchLoading
          v-if="loading"
          class="wb-switch__loading"
          :size="12" /></span
    ></span>
    <span
      v-if="label"
      class="wb-switch__label"
      >{{ label }}</span
    >
  </label>
</template>
<style scoped>
.wb-switch {
  position: relative;
  display: inline-flex;
  align-items: center;
  gap: var(--wb-spacing-component-sm);
  width: fit-content;
  color: var(--wb-color-text-primary);
  cursor: pointer;
}
.wb-switch__input {
  position: absolute;
  z-index: 1;
  inset: 0;
  margin: 0;
  opacity: 0;
  cursor: inherit;
}
.wb-switch__track {
  position: relative;
  width: var(--wb-asset-wb-switch-width);
  height: var(--wb-asset-wb-switch-height);
  flex: none;
  border-radius: var(--wb-radius-full);
  background: var(--wb-color-none);
  transition: background-color var(--wb-asset-wb-switch-motion-duration) ease-out;
}
.wb-switch__thumb {
  position: absolute;
  top: calc((var(--wb-asset-wb-switch-height) - var(--wb-asset-wb-switch-thumb-size)) / 2);
  left: calc((var(--wb-asset-wb-switch-height) - var(--wb-asset-wb-switch-thumb-size)) / 2);
  display: grid;
  width: var(--wb-asset-wb-switch-thumb-size);
  height: var(--wb-asset-wb-switch-thumb-size);
  place-items: center;
  border-radius: var(--wb-radius-full);
  background: var(--wb-color-icon-inverse);
  transition: transform var(--wb-asset-wb-switch-motion-duration) ease-out;
}
.wb-switch__input:checked + .wb-switch__track {
  background: var(--wb-color-icon-primary);
}
.wb-switch__input:checked + .wb-switch__track .wb-switch__thumb {
  transform: translateX(calc(var(--wb-asset-wb-switch-width) - var(--wb-asset-wb-switch-height)));
}
.wb-switch__input:focus-visible + .wb-switch__track {
  outline: var(--wb-asset-wb-switch-focus-outline-width) solid var(--wb-color-border-focus);
  outline-offset: var(--wb-asset-wb-switch-focus-outline-offset);
}
.is-disabled {
  color: var(--wb-color-text-disabled);
  cursor: not-allowed;
}
.wb-switch.is-disabled .wb-switch__track,
.wb-switch.is-loading .wb-switch__track {
  background: var(--wb-color-fill-disabled);
}
.wb-switch.is-disabled .wb-switch__input:checked + .wb-switch__track,
.wb-switch.is-loading .wb-switch__input:checked + .wb-switch__track {
  background: var(--wb-color-icon-disabled);
}
.is-loading {
  cursor: progress;
}
.wb-switch__loading {
  color: var(--wb-color-icon-disabled);
}
.wb-switch__loading :deep(.wb-loading__dot) {
  display: none;
}
</style>
