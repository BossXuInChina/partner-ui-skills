<script setup>
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import { computed, nextTick, onBeforeUnmount, onMounted, ref, useId, watch } from 'vue';

const placements = [
  'top-start',
  'top',
  'top-end',
  'right-start',
  'right',
  'right-end',
  'bottom-start',
  'bottom',
  'bottom-end',
  'left-start',
  'left',
  'left-end',
];
const opposite = { top: 'bottom', bottom: 'top', left: 'right', right: 'left' };
const props = defineProps({
  content: { type: String, default: '' },
  placement: {
    type: String,
    default: 'top',
    validator: (value) =>
      [
        'top-start',
        'top',
        'top-end',
        'right-start',
        'right',
        'right-end',
        'bottom-start',
        'bottom',
        'bottom-end',
        'left-start',
        'left',
        'left-end',
      ].includes(value),
  },
  open: { type: Boolean, default: undefined },
  disabled: Boolean,
  overflowOnly: Boolean,
  showArrow: { type: Boolean, default: true },
});
const emit = defineEmits(['update:open']);
const id = useId();
const root = ref(null);
const panel = ref(null);
const internalOpen = ref(false);
let observer;
let contentObserver;
let hideTimer;
let triggerObserver;
let observedTrigger;
let pointerInside = false;
let focusInside = false;
let dismissed = false;
const controlled = computed(() => props.open !== undefined);
const isOverflowing = ref(false);
const shown = computed(
  () =>
    !props.disabled &&
    (controlled.value ? props.open : internalOpen.value) &&
    (!props.overflowOnly || isOverflowing.value),
);
const triggerSlotProps = computed(() => ({
  open: shown.value,
  aria: { 'aria-describedby': shown.value ? `${id}-tooltip` : undefined },
}));

function triggerElement() {
  return root.value?.firstElementChild ?? null;
}
function observeTriggerContent() {
  const element = triggerElement();
  if (observedTrigger === element) return;
  if (observedTrigger) observer?.unobserve(observedTrigger);
  observedTrigger = element;
  contentObserver?.disconnect();
  if (element) {
    observer?.observe(element);
    contentObserver?.observe(element, { childList: true, characterData: true, subtree: true });
  }
}
function measureOverflow() {
  const element = triggerElement();
  isOverflowing.value = Boolean(
    element &&
    [element, ...element.querySelectorAll('*')].some(
      (node) =>
        node.clientWidth > 0 &&
        node.textContent?.trim() &&
        (node.scrollWidth > node.clientWidth || node.scrollHeight > node.clientHeight),
    ),
  );
}
function setOpen(value) {
  const next = Boolean(value) && !props.disabled;
  if (!controlled.value) internalOpen.value = next;
  emit('update:open', next);
  if (next)
    nextTick(() => {
      measureOverflow();
      updatePosition();
    });
}
function cancelHide() {
  window.clearTimeout(hideTimer);
}
function syncOpen() {
  measureOverflow();
  setOpen(!dismissed && (pointerInside || focusInside));
}
function enter() {
  cancelHide();
  pointerInside = true;
  syncOpen();
}
function leave() {
  pointerInside = false;
  hide();
}
function hide() {
  cancelHide();
  hideTimer = window.setTimeout(() => {
    if (!pointerInside && !focusInside) dismissed = false;
    syncOpen();
  }, 0);
}
function onFocusOut(event) {
  if (!root.value?.contains(event.relatedTarget)) {
    focusInside = false;
    hide();
  }
}
function splitPlacement(value) {
  const [side, align = 'center'] = value.split('-');
  return { side, align: align === 'start' || align === 'end' ? align : 'center' };
}
function sideSpace(side, rect) {
  const edge = 4;
  return side === 'top'
    ? rect.top - edge
    : side === 'bottom'
      ? window.innerHeight - rect.bottom - edge
      : side === 'left'
        ? rect.left - edge
        : window.innerWidth - rect.right - edge;
}
function positionCenterArrow(element, side, align, trigger, rect, left) {
  if (align !== 'center' || !['top', 'bottom'].includes(side)) {
    element.style.removeProperty('--tooltip-arrow-left');
    return;
  }
  const arrowWidth =
    parseFloat(getComputedStyle(element).getPropertyValue('--wb-asset-wb-popover-arrow-width')) ||
    12;
  const arrowLeft = Math.max(
    0,
    Math.min(rect.width - arrowWidth, trigger.left + trigger.width / 2 - left - arrowWidth / 2),
  );
  element.style.setProperty('--tooltip-arrow-left', `${arrowLeft}px`);
}
function tightenTextWidth(element) {
  element.style.removeProperty('--tooltip-content-width');
  const text = [...element.childNodes].find(
    (node) => node.nodeType === Node.TEXT_NODE && node.textContent.trim(),
  );
  if (text) {
    const range = document.createRange();
    range.selectNodeContents(text);
    const lines = [...range.getClientRects()];
    if (lines.length > 1) {
      const css = getComputedStyle(element);
      const width = Math.ceil(
        Math.max(...lines.map((line) => line.width)) +
          parseFloat(css.paddingLeft) +
          parseFloat(css.paddingRight),
      );
      element.style.setProperty('--tooltip-content-width', `${width}px`);
    }
  }
}
function updatePosition() {
  if (!shown.value || !root.value || !panel.value) return;
  const trigger = root.value.getBoundingClientRect();
  const element = panel.value;
  tightenTextWidth(element);
  const rect = element.getBoundingClientRect();
  const requested = splitPlacement(placements.includes(props.placement) ? props.placement : 'top');
  let side = requested.side;
  const style = getComputedStyle(element);
  const value = (name, fallback) =>
    parseFloat(style.getPropertyValue(`--wb-asset-wb-popover-${name}`)) || fallback;
  const offset =
    (props.showArrow ? value('arrow-height', 8) - value('arrow-overlap', 1) : 0) +
    value('trigger-gap', 4);
  const required = (side === 'top' || side === 'bottom' ? rect.height : rect.width) + offset;
  if (
    sideSpace(side, trigger) < required &&
    sideSpace(opposite[side], trigger) > sideSpace(side, trigger)
  )
    side = opposite[side];
  const { align } = requested;
  const edge = 4;
  let left;
  let top;
  if (side === 'top' || side === 'bottom') {
    left =
      align === 'start'
        ? trigger.left
        : align === 'end'
          ? trigger.right - rect.width
          : trigger.left + (trigger.width - rect.width) / 2;
    top = side === 'top' ? trigger.top - rect.height - offset : trigger.bottom + offset;
  } else {
    top =
      align === 'start'
        ? trigger.top
        : align === 'end'
          ? trigger.bottom - rect.height
          : trigger.top + (trigger.height - rect.height) / 2;
    left = side === 'left' ? trigger.left - rect.width - offset : trigger.right + offset;
  }
  const boundedLeft = Math.min(
    Math.max(edge, left),
    Math.max(edge, window.innerWidth - edge - rect.width),
  );
  const boundedTop = Math.min(
    Math.max(edge, top),
    Math.max(edge, window.innerHeight - edge - rect.height),
  );
  element.dataset.placement = `${side}${align === 'center' ? '' : `-${align}`}`;
  element.style.setProperty('--tooltip-left', `${boundedLeft}px`);
  element.style.setProperty('--tooltip-top', `${boundedTop}px`);
  positionCenterArrow(element, side, align, trigger, rect, boundedLeft);
}
function onFocusIn(event) {
  if (event.target.matches(':focus-visible')) {
    cancelHide();
    if (!root.value?.contains(event.relatedTarget)) dismissed = false;
    focusInside = true;
    syncOpen();
  }
}
function onKeydown(event) {
  if (
    event.key === 'Escape' &&
    shown.value &&
    (root.value?.contains(event.target) ||
      (pointerInside &&
        (event.target === document.body || event.target === document.documentElement)))
  ) {
    event.preventDefault();
    event.stopPropagation();
    dismissed = true;
    setOpen(false);
  }
}

onMounted(() => {
  document.addEventListener('keydown', onKeydown);
  window.addEventListener('resize', measureOverflow);
  window.addEventListener('resize', updatePosition);
  document.addEventListener('scroll', updatePosition, true);
  observer = new ResizeObserver(() => {
    measureOverflow();
    updatePosition();
  });
  contentObserver = new MutationObserver(() => {
    measureOverflow();
    updatePosition();
  });
  if (root.value) observer.observe(root.value);
  triggerObserver = new MutationObserver(() => {
    observeTriggerContent();
    measureOverflow();
  });
  if (root.value) triggerObserver.observe(root.value, { childList: true });
  observeTriggerContent();
  measureOverflow();
});
watch(
  panel,
  (node, previous) => {
    if (previous) observer?.unobserve(previous);
    if (node) observer?.observe(node);
    nextTick(updatePosition);
  },
  { flush: 'post' },
);
watch(
  () => [props.placement, props.disabled, props.overflowOnly, props.content, props.showArrow],
  () => {
    nextTick(() => {
      observeTriggerContent();
      measureOverflow();
      if (props.disabled) setOpen(false);
      else updatePosition();
    });
  },
);
onBeforeUnmount(() => {
  cancelHide();
  document.removeEventListener('keydown', onKeydown);
  window.removeEventListener('resize', measureOverflow);
  window.removeEventListener('resize', updatePosition);
  document.removeEventListener('scroll', updatePosition, true);
  observer?.disconnect();
  contentObserver?.disconnect();
  triggerObserver?.disconnect();
});
</script>

<template>
  <span
    ref="root"
    class="wb-tooltip wb-tooltip-debug"
    :class="{ 'is-open': shown, 'is-disabled': disabled }"
    @pointerenter="enter"
    @pointerleave="leave"
    @focusin="onFocusIn"
    @focusout="onFocusOut"
  >
    <slot
      name="trigger"
      v-bind="triggerSlotProps"
    />
  </span>
  <Teleport to="body">
    <span
      v-if="shown"
      :id="`${id}-tooltip`"
      ref="panel"
      @pointerenter="enter"
      @pointerleave="leave"
      class="wb-tooltip-debug__panel"
      :class="{ 'has-arrow': showArrow, 'has-tags': Boolean($slots.content) }"
      role="tooltip"
    >
      <svg
        v-if="showArrow"
        class="wb-tooltip-debug__arrow"
        viewBox="0 0 12 8"
        aria-hidden="true"
      >
        <path d="M0 0h12L7.6 5.9C6.8 7 5.2 7 4.4 5.9L0 0Z" />
      </svg>
      <span
        v-if="$slots.content"
        class="wb-tooltip__tags"
        ><slot name="content"
      /></span>
      <template v-else>{{ content }}</template>
    </span>
  </Teleport>
</template>

<style>
.wb-tooltip-debug {
  display: inline-flex;
  min-width: 0;
}
.wb-tooltip-debug__panel {
  box-sizing: border-box;
  position: fixed;
  z-index: 40;
  top: var(--tooltip-top, -9999px);
  left: var(--tooltip-left, -9999px);
  width: var(--tooltip-content-width, max-content);
  max-width: min(
    var(--wb-asset-wb-popover-max-width),
    calc(100vw - 2 * var(--wb-spacing-component-xs))
  );
  padding: var(--wb-spacing-component-xs) var(--wb-spacing-component-sm);
  border-radius: var(--wb-radius-sm);
  background: var(--wb-color-surface-overlay);
  box-shadow: var(--wb-shadow-lg);
  color: var(--wb-color-text-primary);
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
  overflow-wrap: anywhere;
}
.wb-tooltip-debug__panel.has-tags {
  padding: var(--wb-spacing-component-xs);
}
.wb-tooltip__tags {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--wb-spacing-component-xs);
}
.wb-tooltip-debug__arrow {
  position: absolute;
  display: block;
  width: var(--wb-asset-wb-popover-arrow-width);
  height: var(--wb-asset-wb-popover-arrow-height);
  overflow: visible;
}
.wb-tooltip-debug__arrow path {
  fill: var(--wb-color-surface-overlay);
}
.wb-tooltip-debug__panel[data-placement^='top'] .wb-tooltip-debug__arrow {
  bottom: calc(var(--wb-asset-wb-popover-arrow-overlap) - var(--wb-asset-wb-popover-arrow-height));
}
.wb-tooltip-debug__panel[data-placement^='bottom'] .wb-tooltip-debug__arrow {
  top: calc(var(--wb-asset-wb-popover-arrow-overlap) - var(--wb-asset-wb-popover-arrow-height));
  transform: rotate(180deg);
}
.wb-tooltip-debug__panel[data-placement^='left'] .wb-tooltip-debug__arrow {
  right: calc(var(--wb-asset-wb-popover-arrow-overlap) - var(--wb-asset-wb-popover-arrow-height));
  transform: rotate(-90deg);
}
.wb-tooltip-debug__panel[data-placement^='right'] .wb-tooltip-debug__arrow {
  left: calc(var(--wb-asset-wb-popover-arrow-overlap) - var(--wb-asset-wb-popover-arrow-height));
  transform: rotate(90deg);
}
.wb-tooltip-debug__panel[data-placement^='top'][data-placement$='-start'] .wb-tooltip-debug__arrow,
.wb-tooltip-debug__panel[data-placement^='bottom'][data-placement$='-start']
  .wb-tooltip-debug__arrow {
  left: calc(var(--wb-spacing-component-lg) - var(--wb-asset-wb-popover-arrow-width) / 2);
}
.wb-tooltip-debug__panel[data-placement^='top'][data-placement$='-end'] .wb-tooltip-debug__arrow,
.wb-tooltip-debug__panel[data-placement^='bottom'][data-placement$='-end']
  .wb-tooltip-debug__arrow {
  right: calc(var(--wb-spacing-component-lg) - var(--wb-asset-wb-popover-arrow-width) / 2);
}
.wb-tooltip-debug__panel[data-placement^='left'][data-placement$='-start'] .wb-tooltip-debug__arrow,
.wb-tooltip-debug__panel[data-placement^='right'][data-placement$='-start']
  .wb-tooltip-debug__arrow {
  top: calc(var(--wb-spacing-component-lg) - var(--wb-asset-wb-popover-arrow-height) / 2);
}
.wb-tooltip-debug__panel[data-placement^='left'][data-placement$='-end'] .wb-tooltip-debug__arrow,
.wb-tooltip-debug__panel[data-placement^='right'][data-placement$='-end'] .wb-tooltip-debug__arrow {
  top: auto;
  bottom: calc(var(--wb-spacing-component-lg) - var(--wb-asset-wb-popover-arrow-height) / 2);
}
.wb-tooltip-debug__panel[data-placement='top'] .wb-tooltip-debug__arrow,
.wb-tooltip-debug__panel[data-placement='bottom'] .wb-tooltip-debug__arrow {
  left: var(--tooltip-arrow-left, calc(50% - var(--wb-asset-wb-popover-arrow-width) / 2));
}
.wb-tooltip-debug__panel[data-placement='left'] .wb-tooltip-debug__arrow,
.wb-tooltip-debug__panel[data-placement='right'] .wb-tooltip-debug__arrow {
  top: calc(50% - var(--wb-asset-wb-popover-arrow-height) / 2);
}
.wb-tooltip-debug__panel::before {
  position: absolute;
  content: '';
  --tooltip-bridge: var(--wb-asset-wb-popover-trigger-gap);
}
.wb-tooltip-debug__panel.has-arrow::before {
  --tooltip-bridge: calc(
    var(--wb-asset-wb-popover-arrow-height) - var(--wb-asset-wb-popover-arrow-overlap) +
      var(--wb-asset-wb-popover-trigger-gap)
  );
}
.wb-tooltip-debug__panel[data-placement^='top']::before {
  top: 100%;
  left: 0;
  right: 0;
  height: var(--tooltip-bridge);
}
.wb-tooltip-debug__panel[data-placement^='bottom']::before {
  bottom: 100%;
  left: 0;
  right: 0;
  height: var(--tooltip-bridge);
}
.wb-tooltip-debug__panel[data-placement^='left']::before {
  left: 100%;
  top: 0;
  bottom: 0;
  width: var(--tooltip-bridge);
}
.wb-tooltip-debug__panel[data-placement^='right']::before {
  right: 100%;
  top: 0;
  bottom: 0;
  width: var(--tooltip-bridge);
}
</style>
