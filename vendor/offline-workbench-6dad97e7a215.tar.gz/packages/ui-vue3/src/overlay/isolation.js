// One active isolation owner follows the topmost modal or drawer.
const inertBefore = new Map();
const stack = [];
// Only component-registered real feedback roots participate; class names confer no access.
const feedbackEntries = new Set();
let blocked = new Set();
let scrollBefore;
let observer;
function block(node) {
  if (!inertBefore.has(node)) inertBefore.set(node, node.inert);
  node.inert = true;
}
function unblock(node) {
  if (!inertBefore.has(node)) return;
  node.inert = inertBefore.get(node);
  inertBefore.delete(node);
}
function refresh() {
  const top = stack.at(-1);
  const allowed = top
    ? [...top.allowedElements(), ...feedbackHosts()].filter((node) => node?.isConnected)
    : [];
  const next = new Set();
  function visit(parent) {
    for (const child of parent.children) {
      if (!(child instanceof HTMLElement) || allowed.includes(child)) continue;
      if (allowed.some((node) => child.contains(node))) visit(child);
      else if (top) next.add(child);
    }
  }
  if (top) visit(document.body);
  for (const node of blocked) if (!next.has(node)) unblock(node);
  for (const node of next) if (!blocked.has(node)) block(node);
  blocked = next;
}
export function acquireModalIsolation(allowedElements) {
  if (!stack.length) {
    scrollBefore = [document.body, document.documentElement].map((node) => ({
      node,
      value: node.style.getPropertyValue('overflow'),
      priority: node.style.getPropertyPriority('overflow'),
    }));
    for (const { node } of scrollBefore) node.style.setProperty('overflow', 'hidden');
    observer = new MutationObserver(refresh);
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['aria-controls'],
    });
  }
  const entry = { allowedElements };
  stack.push(entry);
  refresh();
  let released = false;
  const release = () => {
    if (released) return;
    released = true;
    const index = stack.indexOf(entry);
    if (index !== -1) stack.splice(index, 1);
    if (!stack.length) observer?.disconnect();
    refresh();
    if (!stack.length) {
      for (const { node, value, priority } of scrollBefore) {
        if (value) node.style.setProperty('overflow', value, priority);
        else node.style.removeProperty('overflow');
      }
      scrollBefore = undefined;
      observer = undefined;
    }
  };
  entry.release = release;
  return release;
}
export function isTopOverlay(releaseIsolation) {
  return stack.length ? stack.at(-1).release === releaseIsolation : !releaseIsolation;
}

export function feedbackHosts() {
  for (const entry of feedbackEntries) if (!entry.root.isConnected) feedbackEntries.delete(entry);
  return [...new Set([...feedbackEntries].map((entry) => entry.root))];
}

function topDialog() {
  return stack
    .at(-1)
    ?.allowedElements()
    .flatMap((root) =>
      root?.matches?.('[role="dialog"]') ? [root] : [root?.querySelector?.('[role="dialog"]')],
    )
    .find((node) => node?.isConnected);
}

export function registerFeedbackHost(root) {
  if (!(root instanceof HTMLElement) || !root.isConnected) return () => {};
  const previousFocus = document.activeElement;
  const entry = { root };
  feedbackEntries.add(entry);
  refresh();
  let released = false;
  return () => {
    if (released) return;
    released = true;
    const restore = root.contains(document.activeElement);
    feedbackEntries.delete(entry);
    refresh();
    if (!restore || feedbackHosts().includes(root)) return;
    const target =
      previousFocus?.isConnected &&
      !previousFocus.closest('[inert]') &&
      !previousFocus.matches(':disabled') &&
      previousFocus.getClientRects().length
        ? previousFocus
        : topDialog();
    target?.focus({ preventScroll: true });
  };
}

export function focusableFeedbackElements() {
  return feedbackHosts().flatMap(focusableElementsIn);
}

export function focusIsInFeedback() {
  return feedbackHosts().some((root) => root.contains(document.activeElement));
}

export function nextFocusIndex(elements, shiftKey) {
  const current = elements.indexOf(document.activeElement);
  if (current < 0) return shiftKey ? elements.length - 1 : 0;
  return (current + (shiftKey ? -1 : 1) + elements.length) % elements.length;
}

export function controlledOverlays(panel) {
  return [...(panel?.querySelectorAll('[aria-controls]') || [])].flatMap((trigger) => {
    const node = document.getElementById(trigger.getAttribute('aria-controls'));
    return node && !panel.contains(node) ? [node] : [];
  });
}
export function focusableElementsIn(root) {
  return [
    ...(root?.querySelectorAll(
      'button:not(:disabled),[href],input:not(:disabled),select:not(:disabled),textarea:not(:disabled),[tabindex]',
    ) || []),
  ].filter(
    (node) =>
      node.tabIndex >= 0 &&
      !node.closest('[inert]') &&
      node.getClientRects().length &&
      getComputedStyle(node).visibility !== 'hidden',
  );
}
