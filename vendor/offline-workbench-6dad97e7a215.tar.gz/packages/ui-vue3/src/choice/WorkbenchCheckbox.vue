<script setup>
import { useFormDisabled } from '../form/useFormDisabled.js';
import { useFieldControl } from '../form/fieldContext.js';
import { computed, nextTick, ref, useId } from 'vue';
import ChoiceMark from './ChoiceMark.vue';
const props = defineProps({
  modelValue: Boolean,
  indeterminate: Boolean,
  disabled: Boolean,
  hover: Boolean,
  label: { type: String, default: '' },
  ariaLabel: String,
  description: String,
  noWrap: Boolean,
});
const disabled = useFormDisabled(() => props.disabled);
const emit = defineEmits(['update:modelValue', 'update:indeterminate']);
const descriptionId = useId();
const native = ref(null);
const visibleLabel = computed(() =>
  props.noWrap && Array.from(props.label).length > 20
    ? `${Array.from(props.label).slice(0, 20).join('')}…`
    : props.label,
);
function change(event) {
  if (disabled.value) return;
  const checked = props.indeterminate || event.target.checked;
  event.target.checked = checked;
  event.target.indeterminate = false;
  emit('update:modelValue', checked);
  emit('update:indeterminate', false);
  nextTick(() => {
    if (!native.value) return;
    native.value.checked = props.modelValue;
    native.value.indeterminate = props.indeterminate;
  });
}
const { attrs: fieldAttrs } = useFieldControl(() => props.modelValue, {
  nativeRequired: 'single',
  option: true,
  describedBy: () => (props.description ? descriptionId : undefined),
  focus: () => native.value?.focus(),
});
</script>
<template>
  <label
    class="wb-choice"
    :class="{
      'is-disabled': disabled,
      'is-no-wrap': noWrap,
      'is-icon-only': !label && !description,
    }"
  >
    <input
      ref="native"
      class="wb-choice__input"
      type="checkbox"
      :checked="modelValue"
      :indeterminate.prop="indeterminate"
      :disabled="disabled"
      :aria-label="ariaLabel || label"
      :aria-describedby="description ? descriptionId : undefined"
      v-bind="fieldAttrs"
      @change="change"
    />
    <ChoiceMark
      :checked="modelValue"
      :indeterminate="indeterminate"
      :disabled="disabled"
      :hover="hover"
    />
    <span
      v-if="label || description"
      class="wb-choice__copy"
      ><span
        class="wb-choice__label"
        :title="noWrap ? label : undefined"
        >{{ visibleLabel }}</span
      ><span
        v-if="description"
        :id="descriptionId"
        class="wb-choice__description"
        >{{ description }}</span
      ></span
    >
  </label>
</template>
