<script setup>
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import '../../../../catalog/generated/asset.tokens.css';
defineProps({
  radio: Boolean,
  checked: Boolean,
  indeterminate: Boolean,
  disabled: Boolean,
  hover: Boolean,
});
</script>
<template>
  <span
    class="wb-choice-mark"
    :class="{
      'is-radio': radio,
      'is-checked': checked,
      'is-mixed': indeterminate && !radio,
      'is-disabled': disabled,
      'is-hover': hover,
    }"
    aria-hidden="true"
  >
    <svg
      v-if="radio && checked"
      class="wb-choice-mark__ring wb-choice-mark__legacy"
      viewBox="0 0 16 16"
    >
      <circle
        cx="8"
        cy="8"
      />
    </svg>
    <WorkbenchIcon
      v-if="!radio && checked && !indeterminate"
      name="Checkbox/选中勾/16"
    />
    <svg
      v-if="!radio && indeterminate"
      class="wb-choice-mark__legacy"
      viewBox="0 0 16 16"
    >
      <path
        :class="{ 'is-mixed-line': indeterminate }"
        :d="indeterminate ? 'M4 8h8' : 'M3.5 8l3 3 6-6'"
      />
    </svg>
  </span>
</template>
<style>
.wb-choice-mark {
  pointer-events: none;
  box-sizing: border-box;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex: none;
  width: var(--choice-size, var(--wb-asset-wb-checkbox-size));
  height: var(--choice-size, var(--wb-asset-wb-checkbox-size));
  border: var(--choice-stroke, var(--wb-asset-wb-checkbox-stroke)) solid
    var(--wb-color-icon-tertiary);
  border-radius: var(--wb-asset-wb-checkbox-checkbox-radius);
  background: var(--wb-color-fill-subtle-default);
}
.wb-choice-mark.is-radio {
  --choice-size: var(--wb-asset-wb-radio-size);
  --choice-stroke: var(--wb-asset-wb-radio-stroke);
  --choice-selected-fill: var(--wb-asset-wb-radio-selected-fill);
  --choice-selected-mark: var(--wb-asset-wb-radio-selected-mark);
  border-radius: var(--wb-radius-full);
}
.wb-choice-mark.is-checked,
.wb-choice-mark.is-mixed {
  border-color: var(--choice-selected-fill, var(--wb-asset-wb-checkbox-selected-fill));
  background: var(--choice-selected-fill, var(--wb-asset-wb-checkbox-selected-fill));
}
.wb-choice-mark.is-radio.is-checked {
  border: 0;
  background: transparent;
}
.wb-choice-mark__ring circle {
  r: calc(
    (var(--choice-size, var(--wb-asset-wb-checkbox-size)) + var(--wb-asset-wb-radio-radio-inner)) /
      4
  );
  fill: var(--choice-selected-mark, var(--wb-asset-wb-checkbox-selected-mark));
  stroke: var(--choice-selected-fill, var(--wb-asset-wb-checkbox-selected-fill));
  stroke-width: calc(
    (var(--choice-size, var(--wb-asset-wb-checkbox-size)) - var(--wb-asset-wb-radio-radio-inner)) /
      2
  );
}
.wb-choice:hover .wb-choice-mark__ring circle,
.wb-choice-mark.is-hover .wb-choice-mark__ring circle {
  stroke: var(--wb-color-icon-primary);
}
.wb-choice-mark.is-disabled .wb-choice-mark__ring circle {
  stroke: var(--wb-color-icon-disabled);
}
.wb-choice-mark__legacy {
  width: 100%;
  height: 100%;
  fill: none;
  stroke: var(--choice-selected-mark, var(--wb-asset-wb-checkbox-selected-mark));
  stroke-width: 2;
}
.wb-choice-mark .is-mixed-line {
  stroke-width: var(--wb-asset-wb-checkbox-mixed-line-height);
  stroke-linecap: round;
}
.wb-choice:hover .wb-choice-mark,
.wb-choice-mark.is-hover {
  border-color: var(--wb-color-icon-primary);
}
.wb-choice-mark.is-disabled {
  border-color: var(--wb-color-border-disabled) !important;
  background: var(--wb-color-fill-subtle-disabled);
}
.wb-choice-mark.is-disabled.is-checked,
.wb-choice-mark.is-disabled.is-mixed {
  background: var(--wb-color-icon-disabled);
}
.wb-choice-mark.is-radio.is-disabled.is-checked {
  background: transparent;
}
.wb-choice {
  --choice-mark-offset: calc(
    (var(--wb-font-body-m-line-height) - var(--wb-asset-wb-checkbox-size)) / 2
  );
  position: relative;
  display: inline-flex;
  align-items: flex-start;
  gap: var(--wb-spacing-component-sm);
  color: var(--wb-color-text-primary);
  cursor: pointer;
}
.wb-choice-mark {
  align-self: flex-start;
  margin-block-start: var(
    --choice-mark-offset,
    calc(
      (var(--wb-font-body-m-line-height) - var(--choice-size, var(--wb-asset-wb-checkbox-size))) / 2
    )
  );
}
.wb-choice__copy {
  display: grid;
  gap: var(--wb-spacing-component-xs);
  min-width: 0;
  text-align: left;
}
.wb-choice.is-icon-only {
  gap: 0;
}
.wb-choice.is-icon-only > .wb-choice-mark {
  margin-block-start: 0;
}
.wb-choice.is-icon-only > .wb-choice__input {
  inset-block-start: 0;
}
.wb-choice__label,
.wb-choice__description {
  min-width: 0;
  text-align: left;
}
.wb-choice__label {
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
}
.wb-choice__description {
  color: var(--wb-color-text-secondary);
  font-size: var(--wb-font-caption-m-font-size);
  font-weight: var(--wb-font-caption-m-font-weight);
  line-height: var(--wb-font-caption-m-line-height);
  letter-spacing: var(--wb-font-caption-m-letter-spacing);
}
.wb-choice.is-no-wrap .wb-choice__copy {
  overflow: hidden;
}
.wb-choice.is-no-wrap .wb-choice__label {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.wb-choice.is-disabled {
  color: var(--wb-color-text-disabled);
  cursor: not-allowed;
}
.wb-choice__input {
  position: absolute;
  inset-block-start: var(--choice-mark-offset);
  inset-inline-start: 0;
  opacity: 0;
  width: var(--choice-size, var(--wb-asset-wb-checkbox-size));
  height: var(--choice-size, var(--wb-asset-wb-checkbox-size));
  margin: 0;
}
.wb-choice__input:focus-visible + .wb-choice-mark {
  outline: 1px solid var(--wb-color-border-focus);
  outline-offset: 2px;
}
</style>
