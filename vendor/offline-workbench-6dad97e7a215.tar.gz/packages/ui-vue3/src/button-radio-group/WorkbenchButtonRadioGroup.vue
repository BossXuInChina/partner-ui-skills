<script setup>
import { useFormDisabled } from '../form/useFormDisabled.js';
import { useFieldControl } from '../form/fieldContext.js';
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue';

const props = defineProps({
  modelValue: { type: [String, Number], required: true },
  items: { type: Array, required: true },
  size: { type: String, default: 'small', validator: value => ['small', 'large'].includes(value) },
  ariaLabel: { type: String, default: '单选组' },
  fill: Boolean,
});
const disabled = useFormDisabled();
const emit = defineEmits(['update:modelValue', 'change']);
const rootElement = ref(null);
const itemElements = ref([]);
const highlightElement = ref(null);
const selectedIndex = computed(() => props.items.findIndex(item => item.value === props.modelValue));
const enabledIndexes = computed(() => props.items.map((item, index) => disabled.value || item.disabled ? -1 : index).filter(index => index >= 0));
const focusIndex = computed(() => !disabled.value && selectedIndex.value >= 0 && !props.items[selectedIndex.value]?.disabled
  ? selectedIndex.value
  : (enabledIndexes.value[0] ?? -1));
let resizeObserver;

function updateHighlight() {
  const selected = itemElements.value[selectedIndex.value];
  if (!selected || !highlightElement.value) {
    if (highlightElement.value) highlightElement.value.style.opacity = '0';
    return;
  }
  highlightElement.value.style.width = `${selected.offsetWidth}px`;
  highlightElement.value.style.transform = `translateX(${selected.offsetLeft}px)`;
  highlightElement.value.style.opacity = '1';
}

function select(item, index, focus = false) {
  if (disabled.value || !item || item.disabled) return;
  if (item.value !== props.modelValue) {
    emit('update:modelValue', item.value);
    emit('change', item);
  }
  if (focus) nextTick(() => itemElements.value[index]?.focus());
}

function onKeydown(event, index) {
  if (!['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Home', 'End'].includes(event.key)) return;
  const enabled = enabledIndexes.value;
  if (!enabled.length) return;
  event.preventDefault();
  const position = enabled.indexOf(index);
  let target;
  if (event.key === 'Home') target = enabled[0];
  else if (event.key === 'End') target = enabled.at(-1);
  else if (event.key === 'ArrowRight' || event.key === 'ArrowDown') target = enabled[(Math.max(position, -1) + 1) % enabled.length];
  else target = enabled[(position <= 0 ? enabled.length : position) - 1];
  select(props.items[target], target, true);
}

watch(() => [props.modelValue, props.size, props.items], () => nextTick(updateHighlight), { deep: true });
onMounted(() => {
  nextTick(updateHighlight);
  resizeObserver = new ResizeObserver(updateHighlight);
  if (rootElement.value) resizeObserver.observe(rootElement.value);
});
onBeforeUnmount(() => resizeObserver?.disconnect());
const { attrs: fieldAttrs } = useFieldControl(() => props.modelValue, { labelable: false, focus: () => itemElements.value?.find(el => el?.tabIndex === 0)?.focus() });
</script>

<template>
  <div ref="rootElement" class="wb-button-radio-group" :class="[`wb-button-radio-group--${size}`, { 'is-fill': fill }]" role="radiogroup" :aria-disabled="disabled || undefined" v-bind="fieldAttrs" :aria-label="ariaLabel">
    <button
      v-for="(item, index) in items"
      :key="item.value"
      :ref="element => { itemElements[index] = element; }"
      class="wb-button-radio-group__item"
      :class="{ 'is-selected': item.value === modelValue }"
      type="button"
      role="radio"
      :aria-checked="item.value === modelValue"
      :tabindex="index === focusIndex ? 0 : -1"
      :disabled="disabled || item.disabled"
      @click="select(item, index)"
      @keydown="onKeydown($event, index)"
    >
      <slot name="item" :item="item" :selected="item.value === modelValue">{{ item.label }}</slot>
    </button>
    <span ref="highlightElement" class="wb-button-radio-group__highlight" aria-hidden="true"></span>
  </div>
</template>

<style scoped>
.wb-button-radio-group { box-sizing: border-box; position: relative; display: flex; align-items: center; width: max-content; max-width: 100%; height: var(--wb-asset-wb-button-radio-group-height); gap: var(--wb-asset-wb-button-radio-group-gap); padding: var(--wb-asset-wb-button-radio-group-inset); border-radius: calc(var(--wb-radius-sm) + var(--wb-asset-wb-button-radio-group-inset)); background: var(--wb-color-fill-hover); }
.wb-button-radio-group__item { position: relative; z-index: 1; flex: none; height: var(--wb-asset-wb-button-radio-group-item-height); margin: 0; padding: 0 var(--wb-asset-wb-button-radio-group-item-padding-inline); border: 0; border-radius: var(--wb-radius-sm); color: var(--wb-color-text-secondary); background: transparent; font-family: inherit; font-size: var(--wb-font-body-m-font-size); font-weight: var(--wb-font-body-m-font-weight); line-height: var(--wb-font-body-m-line-height); letter-spacing: var(--wb-font-body-m-letter-spacing); white-space: nowrap; cursor: pointer; }
.wb-button-radio-group__item.is-selected, .wb-button-radio-group__item:hover:not(:disabled), .wb-button-radio-group__item:focus-visible { color: var(--wb-color-text-primary); }
.wb-button-radio-group__item:not(.is-selected):hover:not(:disabled) { background: var(--wb-color-fill-hover); }
.wb-button-radio-group__item:focus-visible { outline: 1px solid var(--wb-color-border-focus); outline-offset: -1px; }
.wb-button-radio-group__item:disabled { color: var(--wb-color-text-disabled); cursor: not-allowed; }
.wb-button-radio-group__highlight { position: absolute; z-index: 0; top: var(--wb-asset-wb-button-radio-group-inset); left: 0; height: var(--wb-asset-wb-button-radio-group-item-height); pointer-events: none; border-radius: var(--wb-radius-sm); background: var(--wb-color-surface-card-default); box-shadow: var(--wb-shadow-sm); opacity: 0; transition: transform var(--wb-asset-wb-button-radio-group-motion-duration) var(--wb-asset-wb-button-radio-group-motion-easing), width var(--wb-asset-wb-button-radio-group-motion-duration) var(--wb-asset-wb-button-radio-group-motion-easing); }
.wb-button-radio-group--large { height: var(--wb-asset-wb-button-radio-group-height-large); }
.wb-button-radio-group--large > .wb-button-radio-group__item { height: var(--wb-asset-wb-button-radio-group-item-height-large); font-size: var(--wb-font-body-l-font-size); font-weight: var(--wb-font-body-l-font-weight); line-height: var(--wb-font-body-l-line-height); letter-spacing: var(--wb-font-body-l-letter-spacing); }
.wb-button-radio-group--large > .wb-button-radio-group__highlight { height: var(--wb-asset-wb-button-radio-group-item-height-large); }
.wb-button-radio-group.is-fill { width: 100%; }
.wb-button-radio-group.is-fill > .wb-button-radio-group__item { flex: 1 1 0; min-width: 0; }
@media (prefers-reduced-motion: reduce) { .wb-button-radio-group__highlight { transition: none; } }
</style>
