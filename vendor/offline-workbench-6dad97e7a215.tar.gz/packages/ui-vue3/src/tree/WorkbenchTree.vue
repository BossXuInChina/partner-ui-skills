<script setup>
import '../shared/disclosure-motion.css';
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import { computed, nextTick, ref, useId, watch } from 'vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import ChoiceMark from '../choice/ChoiceMark.vue';

const props = defineProps({
  items: { type: Array, default: () => [] },
  modelValue: { type: [String, Number], default: undefined },
  expandedKeys: { type: Array, default: undefined },
  defaultExpandedKeys: { type: Array, default: () => [] },
  checkedKeys: { type: Array, default: undefined },
  defaultCheckedKeys: { type: Array, default: () => [] },
  title: { type: String, default: '主标题' },
  titleIcon: { type: String, default: '' },
  showCount: Boolean,
  searchable: { type: Boolean, default: true },
  search: { type: String, default: undefined },
  placeholder: { type: String, default: '请输入搜索内容' },
  checkable: Boolean,
  checkStrictly: Boolean,
  showLine: Boolean,
  showIcons: Boolean,
  editable: { type: Boolean, default: true },
  showActions: { type: Boolean, default: true },
  disabled: Boolean,
  label: { type: String, default: '结构树' },
  emptyText: { type: String, default: '暂无数据' },
});
const emit = defineEmits(['update:modelValue', 'update:expandedKeys', 'update:checkedKeys', 'update:search', 'select', 'expand', 'check', 'rename', 'delete', 'more']);
const treeId = `wb-tree-${useId().replace(/[^a-zA-Z0-9_-]/g, '')}`;
const root = ref(null);
const localExpanded = ref([...props.defaultExpandedKeys]);
const localChecked = ref([...props.defaultCheckedKeys]);
const localSearch = ref('');
const localSelected = ref(null);
const selectedKey = computed(() => props.modelValue === undefined ? localSelected.value : props.modelValue);
const expanded = computed(() => new Set(props.expandedKeys ?? localExpanded.value));
const checked = computed(() => new Set(props.checkedKeys ?? localChecked.value));
const searchValue = computed(() => props.search ?? localSearch.value);
const query = computed(() => searchValue.value.trim().toLocaleLowerCase());
const focusedKey = ref(null);
const editingKey = ref(null);
const editValue = ref('');
const editError = ref('');
const overrides = ref(new Map());
const meta = computed(() => {
  const byKey = new Map();
  function visit(items, parent = null, level = 1, inheritedDisabled = false) {
    items.forEach((node, index) => {
      const entry = { node, key: node.key, parent, level, index, size: items.length,
        disabled: props.disabled || inheritedDisabled || Boolean(node.disabled), children: [] };
      byKey.set(node.key, entry);
      entry.children = visit(node.children ?? [], entry, level + 1, entry.disabled);
    });
    return items.map(node => byKey.get(node.key));
  }
  const roots = visit(props.items);
  return { byKey, roots };
});
function titleOf(entry) { return overrides.value.get(entry.key) ?? entry.node.label ?? entry.node.title ?? String(entry.key); }
const matching = computed(() => {
  if (!query.value) return null;
  const keep = new Set();
  for (const entry of meta.value.byKey.values()) {
    if (!titleOf(entry).toLocaleLowerCase().includes(query.value)) continue;
    for (let ancestor = entry; ancestor; ancestor = ancestor.parent) keep.add(ancestor.key);
  }
  return keep;
});
const rows = computed(() => {
  const result = [];
  function flatten(entries, lines = []) {
    const visible = entries.filter(entry => !matching.value || matching.value.has(entry.key));
    visible.forEach((entry, index) => {
      const isLast = index === visible.length - 1;
      const isExpanded = query.value ? entry.children.some(child => matching.value.has(child.key)) : expanded.value.has(entry.key);
      result.push({ ...entry, isExpanded, isLast, lines });
      if (isExpanded) flatten(entry.children, [...lines, !isLast]);
    });
  }
  flatten(meta.value.roots);
  return result;
});
const enabledRows = computed(() => rows.value.filter(row => !row.disabled));
const tabKey = computed(() => enabledRows.value.some(row => row.key === focusedKey.value)
  ? focusedKey.value : enabledRows.value.find(row => row.key === selectedKey.value)?.key ?? enabledRows.value[0]?.key);
const checkStates = computed(() => {
  const states = new Map();
  function state(entry) {
    const children = entry.children.filter(child => !child.disabled).map(state);
    const result = props.checkStrictly || !children.length
      ? { checked: checked.value.has(entry.key), mixed: false }
      : { checked: children.every(child => child.checked), mixed: children.some(child => child.checked || child.mixed) && !children.every(child => child.checked) };
    states.set(entry.key, result);
    // Disabled descendants retain their externally supplied state but do not affect parent propagation.
    for (const child of entry.children.filter(child => child.disabled)) state(child);
    return result;
  }
  meta.value.roots.forEach(state);
  return states;
});
function rowElement(key) { return [...(root.value?.querySelectorAll('[role="treeitem"]') ?? [])].find(element => element.dataset.key === String(key)); }
async function focusRow(key) { focusedKey.value = key; await nextTick(); rowElement(key)?.focus(); }
function select(entry) {
  if (entry.disabled || editingKey.value !== null) return;
  focusedKey.value = entry.key;
  localSelected.value = entry.key;
  emit('update:modelValue', entry.key);
  emit('select', entry.key, entry.node);
}
function toggle(entry, force) {
  if (entry.disabled || !entry.children.length || query.value) return;
  const keys = new Set(expanded.value);
  const open = force ?? !keys.has(entry.key);
  if (open) keys.add(entry.key); else keys.delete(entry.key);
  localExpanded.value = [...keys];
  emit('update:expandedKeys', [...keys]);
  emit('expand', entry.key, open, entry.node);
  if (!open) {
    let focused = meta.value.byKey.get(focusedKey.value);
    while (focused?.parent) { if (focused.parent.key === entry.key) { focusRow(entry.key); break; } focused = focused.parent; }
  }
}
function check(entry, event) {
  if (entry.disabled) return;
  const next = new Set(checked.value);
  const value = !checkStates.value.get(entry.key)?.checked;
  function set(node) {
    if (node.disabled) return;
    if (value) next.add(node.key); else next.delete(node.key);
    if (!props.checkStrictly) node.children.forEach(set);
  }
  set(entry);
  if (!props.checkStrictly) {
    // Normalize ancestors using the new leaf state, never counting disabled branches.
    function normalize(node) {
      if (node.disabled) return next.has(node.key);
      const children = node.children.filter(child => !child.disabled);
      const states = children.map(normalize);
      if (children.length) { if (states.every(Boolean)) next.add(node.key); else next.delete(node.key); }
      return next.has(node.key);
    }
    meta.value.roots.forEach(normalize);
  }
  localChecked.value = [...next];
  emit('update:checkedKeys', [...next]);
  emit('check', [...next], { key: entry.key, checked: value, node: entry.node });
  select(entry);
  if (event) nextTick(() => {
    event.target.checked = Boolean(checkStates.value.get(entry.key)?.checked);
    event.target.indeterminate = Boolean(checkStates.value.get(entry.key)?.mixed);
  });
}
function searchChanged(value) { localSearch.value = value; emit('update:search', value); }
async function startEdit(entry) {
  if (entry.disabled || !props.editable || entry.node.editable === false) return;
  editingKey.value = entry.key;
  editValue.value = titleOf(entry);
  editError.value = '';
  await nextTick();
  const input = root.value?.querySelector('.wb-tree__editor');
  input?.focus(); input?.select();
}
function cancelEdit() { const key = editingKey.value; editingKey.value = null; editError.value = ''; if (key !== null) focusRow(key); }
function commitEdit() {
  const entry = meta.value.byKey.get(editingKey.value);
  if (!entry) return;
  const value = editValue.value.trim();
  if (!value) { editError.value = '节点名称不能为空'; return; }
  const previous = titleOf(entry);
  overrides.value = new Map(overrides.value).set(entry.key, value);
  editingKey.value = null;
  editError.value = '';
  if (value !== previous) emit('rename', entry.key, value, entry.node);
  focusRow(entry.key);
}
function navigateKey(event, row) {
  const current = enabledRows.value.findIndex(entry => entry.key === row.key);
  let target;
  switch (event.key) {
    case 'ArrowDown': target = enabledRows.value[Math.min(current + 1, enabledRows.value.length - 1)]; break;
    case 'ArrowUp': target = enabledRows.value[Math.max(current - 1, 0)]; break;
    case 'Home': target = enabledRows.value[0]; break;
    case 'End': target = enabledRows.value.at(-1); break;
    case 'ArrowRight': if (!row.isExpanded) toggle(row, true); else target = enabledRows.value.find(entry => entry.parent?.key === row.key); break;
    case 'ArrowLeft': if (row.isExpanded && !query.value) toggle(row, false); else target = row.parent; break;
    default: return false;
  }
  event.preventDefault();
  if (target && !target.disabled) focusRow(target.key);
  return true;
}
function onKeydown(event, row) {
  const checkbox = event.target.matches('input[type="checkbox"]');
  if ((event.target !== event.currentTarget && !checkbox) || event.isComposing || row.disabled) return;
  if (navigateKey(event, row)) return;
  if (event.key === 'Enter') select(row);
  else if (event.key === ' ' && !checkbox) { if (props.checkable) check(row); else select(row); }
  else if (event.key === 'F2') startEdit(row);
  else return;
  event.preventDefault();
}
function highlighted(entry) {
  const text = titleOf(entry);
  const index = query.value ? text.toLocaleLowerCase().indexOf(query.value) : -1;
  return index < 0 ? [text, '', ''] : [text.slice(0, index), text.slice(index, index + query.value.length), text.slice(index + query.value.length)];
}
watch(() => props.items, () => {
  overrides.value = new Map();
  if (!meta.value.byKey.has(editingKey.value)) editingKey.value = null;
});
watch([rows, () => props.disabled], () => {
  if (editingKey.value !== null && !rows.value.some(row => row.key === editingKey.value && !row.disabled)) editingKey.value = null;
});
defineExpose({ focus: () => focusRow(tabKey.value), startEdit: key => { const entry = meta.value.byKey.get(key); if (entry) startEdit(entry); } });
</script>

<template>
  <section ref="root" class="wb-tree" :class="{ 'wb-tree--lines': showLine, 'wb-tree--disabled': disabled }" :aria-label="label">
    <header v-if="title" class="wb-tree__header">
      <div class="wb-tree__heading">
        <WorkbenchIcon v-if="titleIcon" :name="titleIcon" />
        <h3 :id="`${treeId}-title`">{{ title }}</h3>
        <span v-if="showCount" class="wb-tree__count">{{ meta.byKey.size }}</span>
        <slot name="title-actions" />
      </div>
    </header>
    <div v-if="searchable" class="wb-tree__search-wrap">
      <div class="wb-tree__search" :class="{ 'wb-tree__search--disabled': disabled }">
        <WorkbenchIcon name="搜索_14px" :color="disabled ? 'var(--wb-color-icon-disabled)' : 'var(--wb-color-icon-secondary)'" />
        <input type="search" :value="searchValue" :disabled="disabled" :placeholder="placeholder" :aria-label="`搜索${label}`" @input="searchChanged($event.target.value)" />
        <button v-if="searchValue" type="button" :disabled="disabled" aria-label="清除树搜索" @click="searchChanged('')"><WorkbenchIcon name="/ic_public_close_line_14px" /></button>
      </div>
    </div>
    <div class="wb-tree__nodes" role="tree" :aria-label="label" :aria-multiselectable="checkable || undefined" :aria-disabled="disabled || undefined" :tabindex="enabledRows.length ? undefined : 0">
      <div v-for="row in rows" :key="row.key" class="wb-tree__row" :class="{ 'is-selected': selectedKey === row.key, 'is-disabled': row.disabled, 'is-editing': editingKey === row.key }"
        role="treeitem" :data-key="row.key" :aria-level="row.level" :aria-posinset="row.index + 1" :aria-setsize="row.size"
        :aria-label="titleOf(row)" :aria-expanded="row.children.length ? row.isExpanded : undefined" :aria-selected="selectedKey === row.key"
        :aria-checked="checkable ? checkStates.get(row.key)?.mixed ? 'mixed' : Boolean(checkStates.get(row.key)?.checked) : undefined" :aria-disabled="row.disabled || undefined"
        :tabindex="!row.disabled && row.key === tabKey ? 0 : -1"
        @focus.self="focusedKey = row.key" @keydown="onKeydown($event, row)" @click="select(row)" @dblclick="startEdit(row)">
        <span v-for="(_, index) in row.lines" :key="index" class="wb-tree__indent" aria-hidden="true">
          <span v-if="showLine" class="wb-tree__guide" :class="{ 'is-continuing': index < row.lines.length - 1 && row.lines[index + 1], 'is-branch': index === row.lines.length - 1, 'is-last': row.isLast }" />
        </span>
        <button v-if="row.children.length" class="wb-tree__toggle" type="button" tabindex="-1" :disabled="row.disabled || Boolean(query)" :aria-label="`${row.isExpanded ? '收起' : '展开'}${titleOf(row)}`" @dblclick.stop @click.stop="toggle(row)">
          <WorkbenchIcon name="/ic_arrow_right_line#2:142" class="wb-disclosure-icon wb-disclosure-icon--branch" :class="{ 'is-expanded': row.isExpanded }" :size="8" />
        </button>
        <span v-else class="wb-tree__toggle-space" aria-hidden="true" />
        <div class="wb-tree__content">
          <label v-if="checkable && editingKey !== row.key" class="wb-tree__check" @click.stop @dblclick.stop>
            <input type="checkbox" tabindex="-1" :checked="Boolean(checkStates.get(row.key)?.checked)" :indeterminate.prop="Boolean(checkStates.get(row.key)?.mixed)" :disabled="row.disabled" :aria-label="`选择${titleOf(row)}`" @change="check(row, $event)" />
            <ChoiceMark :checked="Boolean(checkStates.get(row.key)?.checked)" :indeterminate="Boolean(checkStates.get(row.key)?.mixed)" :disabled="row.disabled" />
          </label>
          <WorkbenchIcon v-if="showIcons && editingKey !== row.key" :name="row.node.icon || '文件夹/尺寸=14'" :size="14" />
          <input v-if="editingKey === row.key" v-model="editValue" class="wb-tree__editor" :aria-label="`编辑${titleOf(row)}`" :aria-invalid="Boolean(editError)" :aria-describedby="editError ? `${treeId}-edit-error` : undefined" @click.stop @dblclick.stop @keydown.stop @keydown.enter="!$event.isComposing && commitEdit()" @keydown.esc="cancelEdit" @blur="cancelEdit" />
          <span v-else class="wb-tree__label" :title="titleOf(row)"><slot name="label" :node="row.node" :level="row.level"><template v-for="(part, index) in highlighted(row)" :key="index"><mark v-if="index === 1 && part">{{ part }}</mark><template v-else>{{ part }}</template></template></slot></span>
          <span v-if="row.node.count !== undefined && editingKey !== row.key" class="wb-tree__node-count">{{ row.node.count }}</span>
          <span v-if="showActions && !row.disabled && editingKey !== row.key" class="wb-tree__actions">
            <button v-if="editable && row.node.editable !== false" type="button" :aria-label="`编辑${titleOf(row)}`" @dblclick.stop @click.stop="startEdit(row)"><WorkbenchIcon name="/ic_public_brush_line_14px" /></button>
            <button v-if="row.node.deletable !== false" type="button" :aria-label="`删除${titleOf(row)}`" @dblclick.stop @click.stop="emit('delete', row.key, row.node)"><WorkbenchIcon name="/ic_public_trash_line_14px" /></button>
            <button type="button" :aria-label="`${titleOf(row)}的更多操作`" @dblclick.stop @click.stop="emit('more', row.key, row.node)"><WorkbenchIcon name="更多_14px" /></button>
          </span>
        </div>
      </div>
      <p v-if="!rows.length" class="wb-tree__empty" role="status">{{ query ? '未找到匹配节点' : emptyText }}</p>
    </div>
    <p v-if="editError" :id="`${treeId}-edit-error`" class="wb-tree__error" role="alert">{{ editError }}</p>
  </section>
</template>

<style scoped>
.wb-tree { --tree-edge: var(--wb-asset-wb-tree-edge); --tree-indent: var(--wb-asset-wb-tree-indent); --tree-row: var(--wb-asset-wb-tree-row); --tree-gap: var(--wb-asset-wb-tree-row-gap); box-sizing: border-box; width: var(--wb-asset-wb-tree-width); max-width: 100%; color: var(--wb-color-text-primary); background: var(--wb-color-surface-container); font-family: inherit; font-size: var(--wb-font-body-m-font-size); font-weight: var(--wb-font-body-m-font-weight); line-height: var(--wb-font-body-m-line-height); letter-spacing: var(--wb-font-body-m-letter-spacing); }
.wb-tree__header { box-sizing: border-box; min-height: var(--wb-asset-wb-tree-header); padding: var(--tree-edge) var(--tree-edge) 0; }
.wb-tree__heading { display: flex; align-items: center; gap: var(--wb-asset-wb-tree-gap); padding-bottom: var(--tree-edge); border-bottom: 1px solid var(--wb-asset-wb-tree-divider); }
.wb-tree__heading h3 { flex: 1; margin: 0; min-width: 0; font-size: var(--wb-font-headline-l-font-size); font-weight: var(--wb-font-headline-l-font-weight); line-height: var(--wb-font-headline-l-line-height); letter-spacing: var(--wb-font-headline-l-letter-spacing); }
.wb-tree__count, .wb-tree__node-count { flex: none; color: var(--wb-color-text-secondary); font-size: var(--wb-font-body-s-font-size); font-weight: var(--wb-font-body-s-font-weight); line-height: var(--wb-font-body-s-line-height); letter-spacing: var(--wb-font-body-s-letter-spacing); }
.wb-tree__search-wrap { padding: var(--wb-asset-wb-tree-search-top) var(--tree-edge) 0; }
.wb-tree__search { box-sizing: border-box; display: flex; align-items: center; gap: var(--wb-asset-wb-tree-search-gap); height: var(--tree-row); padding: 0 var(--wb-asset-wb-tree-search-inset); border: 1px solid var(--wb-color-border); border-radius: var(--wb-radius-sm); background: var(--wb-color-surface-container); }
.wb-tree__search:hover:not(.wb-tree__search--disabled), .wb-tree__search:focus-within { border-color: var(--wb-color-border-focus); }
.wb-tree__search--disabled { border-color: var(--wb-color-border-disabled); background: var(--wb-color-fill-subtle-disabled); }
.wb-tree__search input { width: 0; flex: 1; min-width: 0; padding: 0; border: 0; outline: 0; background: transparent; color: inherit; font: inherit; }
.wb-tree__search input::placeholder { color: var(--wb-color-text-placeholder); }
.wb-tree__search input::-webkit-search-cancel-button { display: none; }
.wb-tree__search button, .wb-tree__actions button, .wb-tree__toggle { display: inline-flex; align-items: center; justify-content: center; flex: none; margin: 0; padding: 0; border: 0; background: transparent; color: inherit; cursor: pointer; }
.wb-tree__search button:focus-visible, .wb-tree__actions button:focus-visible { outline: 1px solid var(--wb-color-border-focus); outline-offset: 2px; }
.wb-tree__nodes { display: flex; flex-direction: column; gap: var(--tree-gap); padding: var(--wb-asset-wb-tree-list-top) 0 var(--wb-asset-wb-tree-bottom); overflow: auto; }
.wb-tree__row { box-sizing: border-box; position: relative; display: flex; flex: none; align-items: center; height: var(--tree-row); padding-left: var(--tree-edge); padding-right: var(--tree-edge); outline: none; cursor: pointer; }
.wb-tree__toggle, .wb-tree__toggle-space { display: inline-flex; align-items: center; justify-content: center; flex: none; width: var(--wb-asset-wb-tree-toggle); height: var(--wb-asset-wb-tree-toggle); }
.wb-tree__content { z-index: 1; box-sizing: border-box; display: flex; align-items: center; flex: 1; min-width: 0; gap: var(--wb-asset-wb-tree-gap); height: 100%; padding: 0 var(--wb-asset-wb-tree-gap); border-radius: var(--wb-radius-sm); }
.wb-tree__row:hover:not(.is-disabled) .wb-tree__content, .wb-tree__row.is-selected:not(.is-disabled) .wb-tree__content, .wb-tree__row.is-editing .wb-tree__content { background: var(--wb-color-fill-hover); }
.wb-tree__row:focus-visible .wb-tree__content { outline: 1px solid var(--wb-color-border-focus); outline-offset: -1px; }
.wb-tree__label { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.wb-tree__label mark { padding: 0; background: transparent; color: var(--wb-color-text-action); }
.wb-tree__check { position: relative; display: inline-flex; flex: none; width: var(--wb-asset-wb-tree-toggle); height: var(--wb-asset-wb-tree-toggle); }
.wb-tree__check .wb-choice-mark { align-self: center; margin-block-start: 0; }
.wb-tree__check input { position: absolute; inset: 0; margin: 0; opacity: 0; width: 100%; height: 100%; cursor: inherit; }
.wb-tree__check:has(input:focus-visible) { outline: 1px solid var(--wb-color-border-focus); outline-offset: 2px; }
.wb-tree__actions { display: none; flex: none; align-items: center; gap: var(--wb-asset-wb-tree-gap); color: var(--wb-color-icon-secondary); }
.wb-tree__row:hover .wb-tree__actions, .wb-tree__row.is-selected .wb-tree__actions, .wb-tree__row:focus-within .wb-tree__actions { display: inline-flex; }
.wb-tree__actions button { width: var(--wb-asset-wb-tree-action); height: var(--wb-asset-wb-tree-action); }
.wb-tree__actions button:hover { color: var(--wb-color-icon-primary); }
.wb-tree__editor { box-sizing: border-box; flex: 1; min-width: 0; width: 0; height: var(--wb-asset-wb-tree-editor); padding: 0 var(--wb-asset-wb-tree-search-inset); border: 1px solid var(--wb-color-border-focus); border-radius: var(--wb-radius-sm); outline: none; color: inherit; background: var(--wb-color-surface-container); font: inherit; }
.wb-tree__editor[aria-invalid="true"] { border-color: var(--wb-color-error); }
.wb-tree__row.is-disabled, .wb-tree__search--disabled { color: var(--wb-color-text-disabled); cursor: not-allowed; }
.wb-tree__toggle:disabled { cursor: inherit; }
.wb-tree__empty { margin: 0; padding: var(--tree-edge); color: var(--wb-color-text-secondary); text-align: center; }
.wb-tree__error { margin: 0; padding: 0 var(--tree-edge) var(--wb-asset-wb-tree-bottom); color: var(--wb-color-error); }
.wb-tree__indent { position: relative; align-self: stretch; flex: none; width: var(--tree-indent); pointer-events: none; }
.wb-tree__guide { position: absolute; left: var(--wb-asset-wb-tree-gap); top: calc(0px - var(--tree-gap)); height: calc(var(--tree-row) + var(--tree-gap)); }
.wb-tree__guide.is-continuing, .wb-tree__guide.is-branch { border-left: 1px solid var(--wb-color-border-separator); }
.wb-tree__guide.is-branch.is-last { height: calc(var(--tree-row) / 2 + var(--tree-gap)); }
.wb-tree__guide.is-branch::after { position: absolute; content: ''; top: calc(var(--tree-row) / 2 + var(--tree-gap)); left: 0; width: var(--wb-asset-wb-tree-gap); border-top: 1px solid var(--wb-color-border-separator); }
</style>
