<script setup>
import { computed, ref, watch } from 'vue';
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import person from './assets/avatar-person.svg';

const props = defineProps({
  size: { type: [Number, String], default: 60 },
  color: { type: String, default: 'default' },
  text: { type: String, default: 'A' },
  src: { type: String, default: '' },
  icon: Boolean,
  label: { type: String, default: '' },
});
const emit = defineEmits(['error']);
const sizes = [24, 40, 48, 60, 80, 120];
const colors = ['default', 'blue', 'cyan', 'indigo', 'green', 'orange', 'purple'];
const resolvedSize = computed(() => (sizes.includes(Number(props.size)) ? Number(props.size) : 60));
const resolvedColor = computed(() => (colors.includes(props.color) ? props.color : 'default'));
const failed = ref(false);
watch(
  () => props.src,
  () => {
    failed.value = false;
  },
);
const segmenter = new Intl.Segmenter('zh', { granularity: 'grapheme' });
const initials = computed(() =>
  [...segmenter.segment(props.text.trim())]
    .slice(0, 2)
    .map((part) => part.segment)
    .join(''),
);
const accessibleName = computed(
  () => props.label || (props.icon ? '用户头像' : initials.value) || '用户头像',
);
function onError(event) {
  failed.value = true;
  emit('error', event);
}
</script>

<template>
  <span
    class="wb-avatar"
    :data-size="resolvedSize"
    :data-color="resolvedColor"
    role="img"
    :aria-label="accessibleName"
  >
    <img
      v-if="src && !failed"
      class="wb-avatar__image"
      :src="src"
      alt=""
      aria-hidden="true"
      @error="onError"
    />
    <span
      v-else-if="icon || !initials"
      class="wb-avatar__icon"
      aria-hidden="true"
    >
      <slot name="icon">
        <img
          class="wb-avatar__symbol"
          :src="person"
          alt=""
          aria-hidden="true"
        />
      </slot>
    </span>
    <span
      v-else
      class="wb-avatar__text"
      aria-hidden="true"
      >{{ initials }}</span
    >
  </span>
</template>

<style scoped>
.wb-avatar {
  --avatar-size: var(--wb-asset-wb-avatar-size-60);
  display: inline-flex;
  position: relative;
  flex: none;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  width: var(--avatar-size);
  height: var(--avatar-size);
  overflow: hidden;
  border-radius: var(--wb-radius-full);
  vertical-align: middle;
  color: var(--wb-color-text-inverse);
  background: var(--wb-asset-wb-avatar-background-default);
  font-family: var(--wb-font-family-sans-zh, var(--wb-asset-wb-avatar-font-family));
  font-size: var(--wb-font-headline-xl-font-size);
  font-weight: var(--wb-font-headline-xl-font-weight);
  line-height: var(--wb-font-headline-xl-line-height);
  letter-spacing: var(--wb-font-headline-xl-letter-spacing);
  padding: 0;
}
.wb-avatar[data-size='24'] {
  --avatar-size: var(--wb-asset-wb-avatar-size-24);
  font-size: var(--wb-font-headline-xxs-font-size);
  font-weight: var(--wb-font-headline-xxs-font-weight);
  line-height: var(--wb-font-headline-xxs-line-height);
  letter-spacing: var(--wb-font-headline-xxs-letter-spacing);
}
.wb-avatar[data-size='40'] {
  --avatar-size: var(--wb-asset-wb-avatar-size-40);
  font-size: var(--wb-font-headline-s-font-size);
  font-weight: var(--wb-font-headline-s-font-weight);
  line-height: var(--wb-font-headline-s-line-height);
  letter-spacing: var(--wb-font-headline-s-letter-spacing);
}
.wb-avatar[data-size='48'] {
  --avatar-size: var(--wb-asset-wb-avatar-size-48);
}
.wb-avatar[data-size='80'] {
  font-weight: var(--wb-font-headline-xl-font-weight);
  letter-spacing: var(--wb-font-headline-xl-letter-spacing);
  --avatar-size: var(--wb-asset-wb-avatar-size-80);
  font-size: var(--wb-asset-wb-avatar-font-80);
  line-height: var(--wb-asset-wb-avatar-line-80);
}
.wb-avatar[data-size='120'] {
  font-weight: var(--wb-font-headline-xl-font-weight);
  letter-spacing: var(--wb-font-headline-xl-letter-spacing);
  --avatar-size: var(--wb-asset-wb-avatar-size-120);
  font-size: var(--wb-asset-wb-avatar-font-120);
  line-height: var(--wb-asset-wb-avatar-line-120);
}
.wb-avatar[data-color='blue'] {
  background: var(--wb-asset-wb-avatar-background-blue);
}
.wb-avatar[data-color='cyan'] {
  background: var(--wb-asset-wb-avatar-background-cyan);
}
.wb-avatar[data-color='indigo'] {
  background: var(--wb-asset-wb-avatar-background-indigo);
}
.wb-avatar[data-color='green'] {
  background: var(--wb-asset-wb-avatar-background-green);
}
.wb-avatar[data-color='orange'] {
  background: var(--wb-asset-wb-avatar-background-orange);
}
.wb-avatar[data-color='purple'] {
  background: var(--wb-asset-wb-avatar-background-purple);
}
.wb-avatar__text {
  display: block;
  text-align: center;
  white-space: nowrap;
}
.wb-avatar__image {
  display: block;
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.wb-avatar__icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 50%;
  height: 50%;
  line-height: inherit;
}
.wb-avatar__symbol {
  display: block;
  width: 100%;
  height: 100%;
}
</style>
