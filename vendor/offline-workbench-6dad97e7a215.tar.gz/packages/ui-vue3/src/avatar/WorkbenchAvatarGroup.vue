<script setup>
import { computed } from 'vue';
import WorkbenchAvatar from './WorkbenchAvatar.vue';

const props = defineProps({
  items: { type: Array, default: () => [] },
  layout: { type: String, default: 'row' },
  label: { type: String, default: '头像组' },
});
const multiline = computed(
  () => props.layout === 'multiline' && [3, 4].includes(props.items.length),
);
</script>

<template>
  <span
    class="wb-avatar-group"
    :data-layout="multiline ? 'multiline' : 'row'"
    :data-count="items.length"
    role="group"
    :aria-label="label"
  >
    <span
      v-for="(item, index) in items"
      :key="item.id ?? index"
      class="wb-avatar-group__member"
    >
      <WorkbenchAvatar
        :size="24"
        :text="item.text ?? 'A'"
        :src="item.src"
        :color="item.color"
        :icon="item.icon"
        :label="item.label"
      />
    </span>
  </span>
</template>

<style scoped>
.wb-avatar-group {
  display: inline-flex;
  flex: none;
  align-items: center;
  position: relative;
  vertical-align: middle;
}
.wb-avatar-group__member {
  display: inline-flex;
  flex: none;
  position: relative;
}
.wb-avatar-group[data-layout='row'] .wb-avatar-group__member + .wb-avatar-group__member {
  margin-inline-start: var(--wb-asset-wb-avatar-group-overlap);
}
.wb-avatar-group[data-layout='row'] .wb-avatar-group__member::after {
  content: '';
  position: absolute;
  inset: 0;
  pointer-events: none;
  border: var(--wb-asset-wb-avatar-group-border) solid var(--wb-color-text-inverse);
  border-radius: var(--wb-radius-full);
}
.wb-avatar-group[data-layout='multiline'] {
  width: var(--wb-asset-wb-avatar-group-width);
  height: var(--wb-asset-wb-avatar-group-height-four);
}
.wb-avatar-group[data-layout='multiline'] .wb-avatar-group__member {
  position: absolute;
}
.wb-avatar-group[data-layout='multiline'][data-count='3'] {
  height: var(--wb-asset-wb-avatar-group-height-three);
}
.wb-avatar-group[data-layout='multiline'][data-count='3'] .wb-avatar-group__member:nth-child(1) {
  left: var(--wb-asset-wb-avatar-group-center);
  top: 0;
}
.wb-avatar-group[data-layout='multiline'][data-count='3'] .wb-avatar-group__member:nth-child(2) {
  left: 0;
  top: var(--wb-asset-wb-avatar-size-24);
}
.wb-avatar-group[data-layout='multiline'][data-count='3'] .wb-avatar-group__member:nth-child(3) {
  left: var(--wb-asset-wb-avatar-group-step);
  top: var(--wb-asset-wb-avatar-size-24);
}
.wb-avatar-group[data-layout='multiline'][data-count='4'] .wb-avatar-group__member:nth-child(1) {
  left: 0;
  top: 0;
}
.wb-avatar-group[data-layout='multiline'][data-count='4'] .wb-avatar-group__member:nth-child(2) {
  left: var(--wb-asset-wb-avatar-group-step);
  top: 0;
}
.wb-avatar-group[data-layout='multiline'][data-count='4'] .wb-avatar-group__member:nth-child(3) {
  left: 0;
  top: var(--wb-asset-wb-avatar-group-step);
}
.wb-avatar-group[data-layout='multiline'][data-count='4'] .wb-avatar-group__member:nth-child(4) {
  left: var(--wb-asset-wb-avatar-group-step);
  top: var(--wb-asset-wb-avatar-group-step);
}
</style>
