<script setup>
import { useFormDisabled } from '../form/useFormDisabled.js';
import { useFieldControl } from '../form/fieldContext.js';
import { computed, nextTick, ref, useId } from 'vue';
import ChoiceMark from '../choice/ChoiceMark.vue';
const props = defineProps({
  modelValue: String,
  value: { type: String, required: true },
  name: { type: String, required: true },
  disabled: Boolean,
  hover: Boolean,
  label: { type: String, default: '' },
  ariaLabel: String,
  description: String,
  noWrap: Boolean,
});
const disabled = useFormDisabled(() => props.disabled);
const emit = defineEmits(['update:modelValue']);
const descriptionId = useId();
const native = ref(null);
const visibleLabel = computed(() =>
  props.noWrap && Array.from(props.label).length > 20
    ? `${Array.from(props.label).slice(0, 20).join('')}…`
    : props.label,
);
function change() {
  emit('update:modelValue', props.value);
  nextTick(() => {
    if (!native.value) return;
    const owner = native.value;
    const radios = owner
      .getRootNode()
      .querySelectorAll('input[type="radio"][data-wb-controlled-radio]');
    radios.forEach((radio) => {
      if (radio.name === owner.name && radio.form === owner.form)
        radio.checked = radio.dataset.controlledChecked === 'true';
    });
  });
}
const { attrs: fieldAttrs } = useFieldControl(() => props.modelValue, {
  nativeRequired: true,
  option: true,
  describedBy: () => (props.description ? descriptionId : undefined),
  focus: () => native.value?.focus(),
});
</script>
<template>
  <label
    class="wb-choice"
    :class="{ 'is-disabled': disabled, 'is-no-wrap': noWrap }"
  >
    <input
      ref="native"
      class="wb-choice__input"
      type="radio"
      data-wb-controlled-radio
      :data-controlled-checked="modelValue === value"
      :aria-label="ariaLabel || label"
      :aria-describedby="description ? descriptionId : undefined"
      :name="name"
      :value="value"
      :checked="modelValue === value"
      :disabled="disabled"
      v-bind="fieldAttrs"
      @change="change"
    />
    <ChoiceMark
      radio
      :checked="modelValue === value"
      :disabled="disabled"
      :hover="hover"
    />
    <span class="wb-choice__copy"
      ><span
        class="wb-choice__label"
        :title="noWrap ? label : undefined"
        >{{ visibleLabel }}</span
      ><span
        v-if="description"
        :id="descriptionId"
        class="wb-choice__description"
        >{{ description }}</span
      ></span
    >
  </label>
</template>
