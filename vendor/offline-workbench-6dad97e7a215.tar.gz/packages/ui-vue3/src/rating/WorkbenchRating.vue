<script setup>
import { useFormDisabled } from '../form/useFormDisabled.js';
import { useFieldControl } from '../form/fieldContext.js';
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import { computed, nextTick, ref } from 'vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';

const props = defineProps({
  modelValue: { type: Number, default: 0 }, max: { type: Number, default: 5, validator: value => Number.isInteger(value) && value > 0 }, step: { type: Number, default: 1, validator: value => value === 1 || value === 0.5 }, disabled: Boolean, name: String,
  ariaLabel: { type: String, default: '评分' }, ariaDescribedby: String, invalid: Boolean, readOnly: Boolean,
  descriptionMode: { type: String, default: 'per-star', validator: value => ['none', 'text', 'numeric', 'per-star'].includes(value) },
  descriptionPlacement: { type: String, default: 'right', validator: value => ['right', 'bottom'].includes(value) },
  descriptions: { type: Array, default: () => ['很差', '较差', '一般', '较好', '很好'] },
});
const disabled = useFormDisabled(() => props.disabled);
const emit = defineEmits(['update:modelValue']);
const items = ref([]);
const values = computed(() => Array.from({ length: props.max }, (_, index) => index + 1));
const focusValue = computed(() => Math.max(1, Math.min(props.max, Math.ceil(props.modelValue) || 1)));
const isHalfStep = computed(() => props.step === 0.5);
const normalize = value => Math.max(0, Math.min(props.max, Math.round(value / props.step) * props.step));
const scoreText = computed(() => props.descriptionMode === 'numeric' ? props.modelValue.toFixed(1) : props.descriptions[Math.max(0, Math.ceil(props.modelValue) - 1)] || '未评分');
function choose(value) { if (!disabled.value && !props.readOnly) emit('update:modelValue', normalize(value)); }
function chooseByPointer(event, value) { if (!isHalfStep.value) return choose(value); const rect = event.currentTarget.getBoundingClientRect(); choose(value - (event.clientX - rect.left < rect.width / 2 ? 0.5 : 0)); }
function keydown(event) { if (disabled.value || props.readOnly || !['ArrowLeft', 'ArrowDown', 'ArrowRight', 'ArrowUp', 'Home', 'End'].includes(event.key)) return; event.preventDefault(); const next = normalize(event.key === 'Home' ? 0 : event.key === 'End' ? props.max : props.modelValue + (['ArrowRight', 'ArrowUp'].includes(event.key) ? props.step : -props.step)); choose(next); nextTick(() => items.value[Math.max(0, Math.ceil(next) - 1)]?.focus()); }
function fill(value) { return Math.max(0, Math.min(1, props.modelValue - value + 1)); }
const { attrs: fieldAttrs } = useFieldControl(() => props.modelValue, { labelable: false, describedBy: () => props.ariaDescribedby, invalid: () => props.invalid, focus: () => items.value?.find(el => el?.tabIndex === 0)?.focus() });
</script>

<template>
  <div class="wb-rating-wrap" :class="[`is-${descriptionPlacement}`, { 'has-description': descriptionMode !== 'none' && descriptionMode !== 'per-star' }]">
    <div class="wb-rating" :class="{ 'has-per-star-label': descriptionMode === 'per-star', 'is-readonly': readOnly }" role="radiogroup" :aria-readonly="readOnly || undefined" :aria-label="ariaLabel" :aria-describedby="ariaDescribedby" :aria-invalid="invalid || undefined" v-bind="fieldAttrs" @keydown="keydown">
      <div v-for="value in values" :key="value" class="wb-rating__entry">
        <button ref="items" type="button" role="radio" class="wb-rating__item" :class="{ 'is-selected': fill(value) > 0 }" :aria-checked="modelValue === value || (isHalfStep && modelValue === value - 0.5)" :aria-label="isHalfStep ? `${value - 0.5}至${value}.0分` : `${value}.0分`" :disabled="disabled" :tabindex="value === focusValue ? 0 : -1" @click="chooseByPointer($event, value)">
          <span class="wb-rating__star" aria-hidden="true">
            <WorkbenchIcon name="收藏/面性=on_12px" :color-split="{ ratio: fill(value), startColor: disabled ? 'var(--wb-color-icon-disabled)' : 'var(--wb-color-warning)', endColor: disabled ? 'var(--wb-color-icon-disabled)' : 'var(--wb-asset-wb-rating-unselected-color)' }" />
          </span>
        </button>
        <span v-if="descriptionMode === 'per-star'" class="wb-rating__label">{{ descriptions[value - 1] }}</span>
      </div>
    </div>
    <output v-if="descriptionMode !== 'none' && descriptionMode !== 'per-star'" class="wb-rating__description">{{ scoreText }}</output>
    <input v-if="name" type="hidden" :name="name" :value="modelValue" />
  </div>
</template>

<style scoped>
.wb-rating-wrap { display: inline-flex; width: fit-content; align-items: center; }
.wb-rating-wrap.is-right.has-description { gap: var(--wb-asset-wb-rating-description-inline-gap); }
.wb-rating-wrap.is-bottom { flex-direction: column; align-items: center; }.wb-rating-wrap.is-bottom.has-description { gap: var(--wb-asset-wb-rating-description-block-gap); }
.wb-rating { display: inline-flex; gap: var(--wb-spacing-component-sm); width: fit-content; }.wb-rating:not(.has-per-star-label) .wb-rating__entry { display: contents; }.wb-rating.has-per-star-label { gap: var(--wb-asset-wb-rating-per-star-group-gap); align-items: flex-start; }
.wb-rating__entry { display: inline-flex; flex-direction: column; align-items: center; gap: var(--wb-asset-wb-rating-description-block-gap); }.wb-rating__item { position: relative; display: grid; width: var(--wb-asset-wb-rating-button-size); height: var(--wb-asset-wb-rating-button-size); padding: 0; place-items: center; overflow: hidden; border: 0; border-radius: var(--wb-radius-sm); background: transparent; color: var(--wb-asset-wb-rating-unselected-color); cursor: pointer; }
.wb-rating__star { position: relative; display: inline-flex;  pointer-events: none; }
.wb-rating__item:focus-visible { outline: var(--wb-asset-wb-rating-focus-outline-width) solid var(--wb-color-border-focus); outline-offset: var(--wb-asset-wb-rating-focus-outline-offset); }.wb-rating__item:disabled { cursor: not-allowed; color: var(--wb-color-icon-disabled); }
.wb-rating.is-readonly .wb-rating__item { cursor: default; }
.wb-rating__description, .wb-rating__label { color: var(--wb-color-text-primary); font-size: var(--wb-font-body-m-font-size); font-weight: var(--wb-font-body-m-font-weight); line-height: var(--wb-font-body-m-line-height); letter-spacing: var(--wb-font-body-m-letter-spacing); white-space: nowrap; }.wb-rating__label { text-align: center; }
</style>
