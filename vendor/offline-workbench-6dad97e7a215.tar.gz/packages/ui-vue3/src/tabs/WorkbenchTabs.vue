<script setup>
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import {
  computed,
  nextTick,
  onBeforeUnmount,
  onBeforeUpdate,
  onMounted,
  ref,
  useSlots,
  useId,
  watch,
} from 'vue';

const props = defineProps({
  modelValue: { type: [String, Number], required: true },
  items: { type: Array, required: true },
  variant: {
    type: String,
    default: 'basic',
    validator: (value) => ['basic', 'divider', 'rail', 'segment'].includes(value),
  },
  size: {
    type: String,
    default: 'small',
    validator: (value) => ['small', 'large'].includes(value),
  },
  align: {
    type: String,
    default: 'start',
    validator: (value) => ['start', 'center'].includes(value),
  },
  ariaLabel: { type: String, default: '页签' },
  addable: { type: Boolean, default: false },
});
const slots = useSlots();
const emit = defineEmits(['update:modelValue', 'change', 'add', 'remove']);
const instanceId = `wb-tabs-${useId()}`;
const rootElement = ref(null);
const listElement = ref(null);
const indicatorElement = ref(null);
const segmentHighlightElement = ref(null);
const moreElement = ref(null);
const moreMeasureElement = ref(null);
const measureContainerElement = ref(null);
const measureElements = ref([]);
onBeforeUpdate(() => {
  measureElements.value = [];
  tabElements.value = [];
});
const tabElements = ref([]);
const visibleCount = ref(props.items.length);
const menuOpen = ref(false);
const supportsAdd = computed(
  () => props.addable && ['basic', 'divider', 'rail'].includes(props.variant),
);
const menuAlignRight = ref(false);
const activeIndex = computed(() =>
  props.items.findIndex((item) => item.value === props.modelValue),
);
const activeItem = computed(() => props.items[activeIndex.value] ?? null);
const visibleItems = computed(() => props.items.slice(0, visibleCount.value));
const overflowItems = computed(() => props.items.slice(visibleCount.value));
const activeIsOverflow = computed(() => activeIndex.value >= visibleCount.value);
const tabId = (index) => `${instanceId}-tab-${index}`;
const panelId = (index) => `${instanceId}-panel-${index}`;
let resizeObserver;

function updateSelectionVisual() {
  if (activeIndex.value < 0) return;
  const tab = activeIsOverflow.value ? moreElement.value : tabElements.value[activeIndex.value];
  if (!tab) return;
  const visual = ['basic', 'rail'].includes(props.variant)
    ? indicatorElement.value
    : segmentHighlightElement.value;
  if (!visual || !listElement.value) return;
  const tabRect = tab.getBoundingClientRect();
  const listRect = listElement.value.getBoundingClientRect();
  visual.style.width = `${tabRect.width}px`;
  visual.style.transform = `translateX(${tabRect.left - listRect.left}px)`;
}

function interItemSpace(styles) {
  if (['basic', 'rail'].includes(props.variant))
    return Number.parseFloat(styles.getPropertyValue('--wb-asset-wb-tabs-basic-tab-gap')) || 0;
  if (props.variant === 'divider') {
    const divider =
      Number.parseFloat(styles.getPropertyValue('--wb-asset-wb-tabs-divider-width')) || 0;
    const gap = Number.parseFloat(styles.getPropertyValue('--wb-spacing-component-sm')) || 0;
    return divider + gap * 2;
  }
  if (props.variant === 'segment')
    return Number.parseFloat(styles.getPropertyValue('--wb-spacing-component-xs')) || 0;
  return 0;
}

function updateOverflow() {
  if (!rootElement.value || !measureElements.value.length || !moreMeasureElement.value) return;
  const rootStyles = getComputedStyle(rootElement.value);
  const segmentInset =
    props.variant === 'segment'
      ? Number.parseFloat(rootStyles.getPropertyValue('--wb-asset-wb-tabs-segment-inset')) || 0
      : 0;
  const available = Math.max(0, rootElement.value.clientWidth - segmentInset * 2);
  const widths = props.items.map((_, index) => measureElements.value[index]?.offsetWidth ?? 0);
  const styles = getComputedStyle(rootElement.value);
  const space = interItemSpace(styles);
  const addWidth = supportsAdd.value ? (props.size === 'large' ? 16 : 12) : 0;
  const addSpace = supportsAdd.value && widths.length ? space : 0;
  const fullWidth =
    widths.reduce((sum, width) => sum + width, 0) +
    space * Math.max(0, widths.length - 1) +
    addWidth +
    addSpace;
  if (fullWidth <= available) {
    visibleCount.value = props.items.length;
    menuOpen.value = false;
    nextTick(updateSelectionVisual);
    return;
  }
  const moreWidth = moreMeasureElement.value.offsetWidth;
  let used = moreWidth + (supportsAdd.value ? addWidth + space : 0);
  let count = 0;
  for (const width of widths) {
    const next = used + space + width;
    if (next > available) break;
    used = next;
    count += 1;
  }
  visibleCount.value = Math.min(count, Math.max(0, props.items.length - 1));
  nextTick(updateSelectionVisual);
}

function select(item, index, focus = false) {
  if (!item || item.disabled) return;
  if (item.value !== props.modelValue) {
    emit('update:modelValue', item.value);
    emit('change', item);
  }
  if (focus)
    nextTick(() =>
      (index >= visibleCount.value ? moreElement.value : tabElements.value[index])?.focus(),
    );
}

function canRemove(item) {
  return props.variant === 'basic' && Boolean(item.closable) && !item.disabled;
}
function requestRemove(item) {
  if (!canRemove(item)) return;
  const index = props.items.indexOf(item);
  emit('remove', item);
  menuOpen.value = false;
  nextTick(async () => {
    updateOverflow();
    await nextTick();
    const target =
      activeIndex.value >= 0 ? activeIndex.value : Math.min(index, props.items.length - 1);
    const next =
      target >= visibleCount.value ? moreElement.value : document.getElementById(tabId(target));
    (next && !next.hasAttribute('disabled') ? next : rootElement.value)?.focus();
  });
}
function selectOverflow(item) {
  const index = props.items.indexOf(item);
  select(item, index);
  menuOpen.value = false;
  nextTick(() => moreElement.value?.focus());
}

function toggleMore() {
  menuOpen.value = !menuOpen.value;
  if (menuOpen.value)
    nextTick(() => {
      updateMenuAlignment();
      menuItems()[0]?.focus();
    });
}

function updateMenuAlignment() {
  if (!menuOpen.value || !moreElement.value) return;
  const menu = rootElement.value?.querySelector('.wb-tabs__menu');
  if (!menu) return;
  const triggerRect = moreElement.value.getBoundingClientRect();
  const menuWidth = menu.getBoundingClientRect().width;
  const menuTextInset =
    Number.parseFloat(
      getComputedStyle(rootElement.value).getPropertyValue('--wb-spacing-component-xs'),
    ) +
    Number.parseFloat(
      getComputedStyle(rootElement.value).getPropertyValue('--wb-spacing-component-sm'),
    );
  menuAlignRight.value = triggerRect.left + menuWidth - menuTextInset > window.innerWidth - 8;
}

function menuItems() {
  return [...(rootElement.value?.querySelectorAll('.wb-tabs__menu button:not(:disabled)') ?? [])];
}

function onMenuKeydown(event) {
  if (event.key === 'Escape') {
    event.preventDefault();
    event.stopPropagation();
    menuOpen.value = false;
    nextTick(() => moreElement.value?.focus());
    return;
  }
  if (!['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) return;
  event.preventDefault();
  const nodes = menuItems();
  if (!nodes.length) return;
  const index = nodes.indexOf(document.activeElement);
  const target =
    event.key === 'Home'
      ? 0
      : event.key === 'End'
        ? nodes.length - 1
        : (Math.max(0, index) + (event.key === 'ArrowDown' ? 1 : -1) + nodes.length) % nodes.length;
  nodes[target]?.focus();
}

function onFocusOut(event) {
  if (!rootElement.value?.contains(event.relatedTarget)) menuOpen.value = false;
}

function onDocumentPointerdown(event) {
  if (menuOpen.value && !rootElement.value?.contains(event.target)) menuOpen.value = false;
}

function enabledIndexes() {
  return props.items
    .map((item, index) => (item.disabled ? -1 : index))
    .filter((index) => index >= 0);
}

function onKeydown(event, index) {
  if (event.key === 'Delete' && canRemove(props.items[index])) {
    event.preventDefault();
    requestRemove(props.items[index]);
    return;
  }
  if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
  const enabled = enabledIndexes();
  if (!enabled.length) return;
  event.preventDefault();
  const position = enabled.indexOf(index);
  let target;
  if (event.key === 'Home') target = enabled[0];
  else if (event.key === 'End') target = enabled.at(-1);
  else if (event.key === 'ArrowRight')
    target = enabled[(Math.max(position, -1) + 1) % enabled.length];
  else target = enabled[(position <= 0 ? enabled.length : position) - 1];
  select(props.items[target], target, true);
}

watch(visibleCount, () => {
  const focusedIndex = tabElements.value.indexOf(document.activeElement);
  const focusedMore = document.activeElement === moreElement.value;
  nextTick(() => {
    if (focusedIndex >= visibleCount.value && focusedIndex >= 0) moreElement.value?.focus();
    else if (focusedMore && !overflowItems.value.length)
      tabElements.value[activeIndex.value]?.focus();
  });
});

watch(
  () => [props.variant, props.size, props.items, props.addable],
  () => {
    visibleCount.value = props.items.length;
    nextTick(updateOverflow);
  },
  { deep: true },
);
watch(
  () => props.modelValue,
  () => nextTick(updateOverflow),
);
onMounted(() => {
  nextTick(updateOverflow);
  resizeObserver = new ResizeObserver(updateOverflow);
  if (rootElement.value) resizeObserver.observe(rootElement.value);
  if (measureContainerElement.value) resizeObserver.observe(measureContainerElement.value);
  document.addEventListener('pointerdown', onDocumentPointerdown);
  window.addEventListener('resize', updateMenuAlignment);
});
onBeforeUnmount(() => {
  resizeObserver?.disconnect();
  document.removeEventListener('pointerdown', onDocumentPointerdown);
  window.removeEventListener('resize', updateMenuAlignment);
});
</script>

<template>
  <div
    ref="rootElement"
    class="wb-tabs"
    tabindex="-1"
    @focusout="onFocusOut"
    :class="[`wb-tabs--${variant}`, `wb-tabs--${size}`, `wb-tabs--align-${align}`]"
  >
    <div
      ref="listElement"
      class="wb-tabs__list"
      role="tablist"
      :aria-label="ariaLabel"
    >
      <template
        v-for="(item, index) in visibleItems"
        :key="item.value"
      >
        <span
          v-if="variant === 'divider' && index > 0"
          class="wb-tabs__divider"
          aria-hidden="true"
        ></span>
        <component
          :is="variant === 'basic' && item.closable ? 'div' : 'button'"
          :id="tabId(index)"
          :ref="
            (element) => {
              tabElements[index] = element;
            }
          "
          class="wb-tabs__tab"
          :class="{
            'is-selected': item.value === modelValue,
            'has-close': variant === 'basic' && item.closable,
            'is-disabled': item.disabled,
          }"
          type="button"
          role="tab"
          :aria-selected="item.value === modelValue"
          :aria-disabled="item.disabled || undefined"
          :aria-label="item.closable ? item.label : undefined"
          :aria-controls="slots.panel && item.value === modelValue ? panelId(index) : undefined"
          :tabindex="!item.disabled && item.value === modelValue ? 0 : -1"
          :disabled="item.disabled"
          @click="select(item, index)"
          @keydown="onKeydown($event, index)"
          @keydown.enter.self.prevent="select(item, index)"
          @keydown.space.self.prevent="select(item, index)"
        >
          <slot
            name="tab"
            :item="item"
            :selected="item.value === modelValue"
            >{{ item.label }}</slot
          >
          <button
            v-if="variant === 'basic' && item.closable"
            class="wb-tabs__close"
            type="button"
            :disabled="item.disabled"
            :aria-label="`关闭${item.label}`"
            @click.stop="requestRemove(item)"
            @keydown.stop
          >
            <WorkbenchIcon name="/ic_public_close_line_14px" />
          </button>
        </component>
      </template>
      <span
        v-if="overflowItems.length"
        class="wb-tabs__more-wrap"
      >
        <span
          v-if="variant === 'divider' && visibleItems.length"
          class="wb-tabs__divider"
          aria-hidden="true"
        ></span>
        <button
          :id="`${instanceId}-more`"
          ref="moreElement"
          class="wb-tabs__tab wb-tabs__more"
          :class="{ 'is-selected': activeIsOverflow }"
          type="button"
          :aria-description="activeIsOverflow ? `当前页签：${activeItem.label}` : undefined"
          aria-haspopup="menu"
          :aria-expanded="menuOpen"
          :aria-controls="
            [
              menuOpen ? `${instanceId}-menu` : null,
              slots.panel && activeIsOverflow ? panelId(activeIndex) : null,
            ]
              .filter(Boolean)
              .join(' ') || undefined
          "
          @click="toggleMore"
          @keydown.down.prevent="toggleMore"
          @keydown="onKeydown($event, activeIsOverflow ? activeIndex : visibleCount - 1)"
        >
          更多
        </button>
        <div
          v-if="menuOpen"
          :id="`${instanceId}-menu`"
          class="wb-tabs__menu"
          :class="{ 'wb-tabs__menu--align-right': menuAlignRight }"
          role="menu"
          :aria-labelledby="`${instanceId}-more`"
          @keydown="onMenuKeydown"
        >
          <div
            v-for="item in overflowItems"
            :key="item.value"
            class="wb-tabs__menu-row"
            role="none"
          >
            <button
              class="wb-tabs__menu-item"
              type="button"
              role="menuitemradio"
              :aria-checked="item.value === modelValue"
              :disabled="item.disabled"
              @click="selectOverflow(item)"
              @keydown.delete.prevent="requestRemove(item)"
            >
              {{ item.label }}
            </button>
            <button
              v-if="variant === 'basic' && item.closable"
              class="wb-tabs__close"
              type="button"
              role="menuitem"
              :disabled="item.disabled"
              :aria-label="`关闭${item.label}`"
              @click="requestRemove(item)"
            >
              <WorkbenchIcon name="/ic_public_close_line_14px" />
            </button>
          </div>
        </div>
      </span>
      <span
        v-if="supportsAdd && variant === 'divider' && (visibleItems.length || overflowItems.length)"
        class="wb-tabs__divider"
        aria-hidden="true"
      ></span>
      <button
        v-if="supportsAdd"
        class="wb-tabs__add"
        type="button"
        aria-label="新增页签"
        @click="emit('add')"
      >
        <WorkbenchIcon
          :name="size === 'large' ? '/ic_public_plus_line#2:213' : '/ic_public_plus_line'"
          :size="size === 'large' ? 16 : 12"
        />
      </button>
      <span
        v-if="variant === 'basic' || variant === 'rail'"
        v-show="activeIndex >= 0"
        ref="indicatorElement"
        class="wb-tabs__indicator"
        aria-hidden="true"
      ></span>
      <span
        v-if="variant === 'segment'"
        v-show="activeIndex >= 0"
        ref="segmentHighlightElement"
        class="wb-tabs__segment-highlight"
        aria-hidden="true"
      ></span>
    </div>
    <div
      ref="measureContainerElement"
      class="wb-tabs__measure"
      aria-hidden="true"
      inert
    >
      <button
        v-for="(item, index) in items"
        :key="item.value"
        :ref="
          (element) => {
            measureElements[index] = element;
          }
        "
        class="wb-tabs__tab"
        :class="{
          'is-selected': item.value === modelValue,
          'has-close': variant === 'basic' && item.closable,
        }"
        type="button"
        tabindex="-1"
      >
        <slot
          name="tab"
          :item="item"
          :selected="item.value === modelValue"
          >{{ item.label }}</slot
        >
        <span
          v-if="variant === 'basic' && item.closable"
          class="wb-tabs__close"
          ><WorkbenchIcon name="/ic_public_close_line_14px"
        /></span>
      </button>
      <button
        ref="moreMeasureElement"
        class="wb-tabs__tab"
        type="button"
        tabindex="-1"
      >
        更多
      </button>
    </div>
    <section
      v-if="activeItem && slots.panel"
      :id="panelId(activeIndex)"
      class="wb-tabs__panel"
      role="tabpanel"
      :aria-labelledby="activeIsOverflow ? undefined : tabId(activeIndex)"
      :aria-label="activeIsOverflow ? activeItem.label : undefined"
      tabindex="0"
    >
      <slot
        name="panel"
        :item="activeItem"
      ></slot>
    </section>
  </div>
</template>

<style scoped>
.wb-tabs {
  position: relative;
  min-width: 0;
  color: var(--wb-color-text-primary);
}
.wb-tabs__list {
  display: flex;
  align-items: center;
  width: max-content;
  max-width: 100%;
}
.wb-tabs--align-center > .wb-tabs__list {
  margin-inline: auto;
}
.wb-tabs--align-center.wb-tabs--rail > .wb-tabs__list {
  justify-content: center;
}
.wb-tabs__tab {
  flex: none;
  margin: 0;
  padding: 0;
  border: 0;
  color: var(--wb-color-text-secondary);
  background: transparent;
  font-family: inherit;
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
  white-space: nowrap;
  cursor: pointer;
}
.wb-tabs--large > .wb-tabs__list > .wb-tabs__tab,
.wb-tabs--large > .wb-tabs__list > .wb-tabs__more-wrap > .wb-tabs__tab,
.wb-tabs--large > .wb-tabs__measure > .wb-tabs__tab {
  font-size: var(--wb-font-body-l-font-size);
  font-weight: var(--wb-font-body-l-font-weight);
  line-height: var(--wb-font-body-l-line-height);
  letter-spacing: var(--wb-font-body-l-letter-spacing);
}
.wb-tabs__tab.is-selected,
.wb-tabs__tab:hover:not(:disabled),
.wb-tabs__tab:focus-visible {
  color: var(--wb-color-text-primary);
}
.wb-tabs__tab:focus-visible {
  outline: 1px solid var(--wb-color-border-focus);
  outline-offset: 2px;
}
.wb-tabs__tab.is-disabled,
.wb-tabs__tab:disabled {
  color: var(--wb-color-text-disabled);
  cursor: not-allowed;
}
.wb-tabs__panel {
  margin-top: var(--wb-spacing-component-lg);
  outline: none;
}
.wb-tabs__panel:empty {
  margin-top: 0;
}
.wb-tabs__panel:focus-visible {
  outline: 1px solid var(--wb-color-border-focus);
  outline-offset: 2px;
}
.wb-tabs__measure {
  position: fixed;
  visibility: hidden;
  pointer-events: none;
  display: flex;
  width: max-content;
}
.wb-tabs__more-wrap {
  position: relative;
  display: inline-flex;
  flex: none;
  align-items: center;
}
.wb-tabs__menu {
  position: absolute;
  z-index: 4;
  top: calc(100% + var(--wb-spacing-component-xs));
  right: auto;
  left: calc(-1 * (var(--wb-spacing-component-xs) + var(--wb-spacing-component-sm)));
  display: grid;
  gap: var(--wb-spacing-component-xs);
  width: max-content;
  min-width: var(--wb-asset-wb-tabs-overflow-menu-min-width);
  padding: var(--wb-spacing-component-xs);
  border-radius: var(--wb-radius-sm);
  background: var(--wb-color-surface-overlay);
  box-shadow: var(--wb-shadow-sm);
}
.wb-tabs__menu--align-right {
  right: calc(-1 * (var(--wb-spacing-component-xs) + var(--wb-spacing-component-sm)));
  left: auto;
}
.wb-tabs__menu-item {
  height: var(--wb-asset-wb-tabs-overflow-menu-item-height);
  padding-inline: var(--wb-spacing-component-sm);
  border: 0;
  border-radius: var(--wb-radius-sm);
  color: var(--wb-color-text-primary);
  background: transparent;
  font: inherit;
  text-align: left;
  white-space: nowrap;
  cursor: pointer;
}
.wb-tabs__menu-item:hover:not(:disabled),
.wb-tabs__menu-item:focus-visible {
  background: var(--wb-color-fill-hover);
  outline: none;
}
.wb-tabs__menu-item:disabled {
  color: var(--wb-color-text-disabled);
  cursor: not-allowed;
}

.wb-tabs--basic > .wb-tabs__list,
.wb-tabs--rail > .wb-tabs__list {
  position: relative;
  align-items: stretch;
  gap: var(--wb-asset-wb-tabs-basic-tab-gap);
}
.wb-tabs--rail > .wb-tabs__list {
  width: 100%;
}
.wb-tabs--basic > .wb-tabs__list > .wb-tabs__tab,
.wb-tabs--basic > .wb-tabs__list > .wb-tabs__more-wrap > .wb-tabs__tab,
.wb-tabs--basic > .wb-tabs__measure > .wb-tabs__tab,
.wb-tabs--rail > .wb-tabs__list > .wb-tabs__tab,
.wb-tabs--rail > .wb-tabs__list > .wb-tabs__more-wrap > .wb-tabs__tab,
.wb-tabs--rail > .wb-tabs__measure > .wb-tabs__tab {
  padding-bottom: calc(
    var(--wb-asset-wb-tabs-indicator-gap) + var(--wb-asset-wb-tabs-indicator-height)
  );
}
.wb-tabs__indicator {
  position: absolute;
  bottom: 0;
  left: 0;
  width: 0;
  height: var(--wb-asset-wb-tabs-indicator-height);
  z-index: 1;
  border-radius: var(--wb-radius-full);
  background: var(--wb-color-brand);
  transition:
    transform var(--wb-asset-wb-tabs-indicator-motion-duration)
      var(--wb-asset-wb-tabs-indicator-motion-easing),
    width var(--wb-asset-wb-tabs-indicator-motion-duration)
      var(--wb-asset-wb-tabs-indicator-motion-easing);
}
.wb-tabs--rail > .wb-tabs__list::after {
  position: absolute;
  z-index: 0;
  right: 0;
  bottom: 0;
  left: 0;
  height: var(--wb-asset-wb-tabs-divider-width);
  background: var(--wb-color-border-separator);
  content: '';
  pointer-events: none;
}
.wb-tabs--rail > .wb-tabs__list > .wb-tabs__tab,
.wb-tabs--rail > .wb-tabs__list > .wb-tabs__more-wrap > .wb-tabs__tab {
  position: relative;
  z-index: 1;
}
@media (prefers-reduced-motion: reduce) {
  .wb-tabs__indicator,
  .wb-tabs__segment-highlight {
    transition: none;
  }
}

.wb-tabs__divider {
  width: var(--wb-asset-wb-tabs-divider-width);
  height: var(--wb-asset-wb-tabs-divider-height);
  margin-inline: var(--wb-spacing-component-sm);
  flex: none;
  border-radius: var(--wb-radius-full);
  background: var(--wb-color-border-separator);
}
.wb-tabs__add {
  display: inline-flex;
  flex: none;
  align-items: center;
  justify-content: center;
  padding: 0;
  border: 0;
  color: var(--wb-color-text-secondary);
  background: transparent;
  cursor: pointer;
  width: auto;
  height: var(--wb-font-body-l-line-height);
}
.wb-tabs__add:hover,
.wb-tabs__add:focus-visible {
  color: var(--wb-color-text-primary);
}
.wb-tabs__add:focus-visible {
  outline: 1px solid var(--wb-color-border-focus);
  outline-offset: 2px;
}
.wb-tabs__add :deep(.workbench-icon) {
  color: inherit;
}

.wb-tabs--segment > .wb-tabs__list {
  position: relative;
  gap: var(--wb-spacing-component-xs);
  height: var(--wb-asset-wb-tabs-segment-height);
  padding: var(--wb-asset-wb-tabs-segment-inset);
  border-radius: calc(var(--wb-radius-sm) + var(--wb-asset-wb-tabs-segment-inset));
  background: var(--wb-color-fill-hover);
}
.wb-tabs--segment > .wb-tabs__list > .wb-tabs__tab,
.wb-tabs--segment > .wb-tabs__list > .wb-tabs__more-wrap > .wb-tabs__tab,
.wb-tabs--segment > .wb-tabs__measure > .wb-tabs__tab {
  position: relative;
  z-index: 1;
  height: var(--wb-asset-wb-tabs-segment-tab-height);
  padding-inline: var(--wb-asset-wb-tabs-segment-tab-padding-inline);
  border-radius: var(--wb-radius-sm);
}
.wb-tabs--segment > .wb-tabs__list > .wb-tabs__tab:not(.is-selected):hover:not(:disabled),
.wb-tabs--segment
  > .wb-tabs__list
  > .wb-tabs__more-wrap
  > .wb-tabs__tab:not(.is-selected):hover:not(:disabled) {
  background: var(--wb-color-fill-hover);
}
.wb-tabs__segment-highlight {
  position: absolute;
  top: var(--wb-asset-wb-tabs-segment-inset);
  left: 0;
  height: var(--wb-asset-wb-tabs-segment-tab-height);
  pointer-events: none;
  border-radius: var(--wb-radius-sm);
  background: var(--wb-color-surface-card-default);
  box-shadow: var(--wb-shadow-sm);
  transition:
    transform var(--wb-asset-wb-tabs-segment-motion-duration)
      var(--wb-asset-wb-tabs-segment-motion-easing),
    width var(--wb-asset-wb-tabs-segment-motion-duration)
      var(--wb-asset-wb-tabs-segment-motion-easing);
}
.wb-tabs--segment.wb-tabs--large > .wb-tabs__list {
  height: var(--wb-asset-wb-tabs-segment-height-large);
}
.wb-tabs--segment.wb-tabs--large > .wb-tabs__list > .wb-tabs__tab,
.wb-tabs--segment.wb-tabs--large > .wb-tabs__list > .wb-tabs__more-wrap > .wb-tabs__tab,
.wb-tabs--segment.wb-tabs--large > .wb-tabs__measure > .wb-tabs__tab,
.wb-tabs--segment.wb-tabs--large > .wb-tabs__list > .wb-tabs__segment-highlight {
  height: var(--wb-asset-wb-tabs-segment-tab-height-large);
}
</style>

<style>
.wb-tabs__tab.has-close {
  display: inline-flex;
  align-items: center;
  gap: var(--wb-spacing-component-sm);
}
.wb-tabs__close {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex: none;
  padding: 0;
  border: 0;
  background: transparent;
  color: inherit;
  cursor: pointer;
}
.wb-tabs__close:disabled {
  color: var(--wb-color-icon-disabled);
  cursor: not-allowed;
}
.wb-tabs__close:focus-visible {
  outline: 1px solid var(--wb-color-border-focus);
  outline-offset: var(--wb-spacing-component-xs);
}
.wb-tabs__menu-row {
  display: flex;
  align-items: center;
  gap: var(--wb-spacing-component-sm);
  padding-right: var(--wb-spacing-component-sm);
}
.wb-tabs__menu-row .wb-tabs__menu-item {
  flex: 1;
}
</style>
