<script setup>
import '../shared/disclosure-motion.css';
import { computed, nextTick, ref, watch } from 'vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import WorkbenchTooltip from '../tooltip/WorkbenchTooltip.vue';
import WorkbenchCheckbox from '../choice/WorkbenchCheckbox.vue';
import WorkbenchPagination from '../pagination/WorkbenchPagination.vue';
import { enabledLeaves, filterItems, flattenItems } from './transferModel.js';
import emptyData from './assets/empty-data.png';

const props = defineProps({
  items: { type: Array, required: true },
  title: { type: String, required: true },
  side: { type: String, required: true },
  mode: { type: String, required: true },
  checkedKeys: { type: Array, required: true },
  disabled: Boolean,
  searchable: Boolean,
  pagination: Boolean,
  pageSize: Number,
  defaultExpandedKeys: Array,
});
const emit = defineEmits(['check', 'move', 'search', 'page-change']);
const root = ref(null);
const search = ref('');
const query = computed(() => search.value.trim().toLocaleLowerCase());
const page = ref(1);
const expanded = ref(new Set(props.defaultExpandedKeys));
const focused = ref(null);
const filtered = computed(() => filterItems(props.items, query.value));
const safePageSize = computed(() =>
  Number.isInteger(props.pageSize) && props.pageSize > 0 ? props.pageSize : 6,
);
const pageCount = computed(() =>
  Math.max(1, Math.ceil(filtered.value.length / safePageSize.value)),
);
const currentPage = computed(() => Math.min(page.value, pageCount.value));
const paged = computed(() =>
  props.pagination
    ? filtered.value.slice(
        (currentPage.value - 1) * safePageSize.value,
        currentPage.value * safePageSize.value,
      )
    : filtered.value,
);
const hasTree = computed(() => props.items.some((item) => item.children.length));
const rows = computed(() => {
  const result = [];
  function walk(items, level = 1, parent = null) {
    items.forEach((item, index) => {
      const open =
        item.children.length > 0 && (Boolean(query.value) || expanded.value.has(item.key));
      result.push({ item, level, parent, index, size: items.length, open });
      if (open) walk(item.children, level + 1, item.key);
    });
  }
  walk(paged.value);
  return result;
});
const checks = computed(() => new Set(props.checkedKeys));
const eligible = computed(() => enabledLeaves(filtered.value));
const totalCount = computed(
  () => flattenItems(props.items).filter((item) => !item.children.length).length,
);
const selectedCount = computed(
  () => enabledLeaves(props.items).filter((item) => checks.value.has(item.key)).length,
);
const allChecked = computed(
  () => eligible.value.length > 0 && eligible.value.every((item) => checks.value.has(item.key)),
);
const someChecked = computed(
  () => eligible.value.some((item) => checks.value.has(item.key)) && !allChecked.value,
);
const tabKey = computed(
  () =>
    rows.value.find((row) => row.item.key === focused.value && !row.item.disabled)?.item.key ??
    rows.value.find((row) => !row.item.disabled)?.item.key,
);
function state(item) {
  const eligibleKeys = enabledLeaves([item]).map((leaf) => leaf.key);
  const count = eligibleKeys.filter((key) => checks.value.has(key)).length;
  return {
    checked: eligibleKeys.length > 0 && count === eligibleKeys.length,
    mixed: count > 0 && count < eligibleKeys.length,
  };
}
function check(item) {
  if (props.disabled || item.disabled) return;
  const keys = new Set(props.checkedKeys);
  const value = !state(item).checked;
  enabledLeaves([item]).forEach((leaf) => (value ? keys.add(leaf.key) : keys.delete(leaf.key)));
  emit('check', [...keys]);
}
function checkAll() {
  if (props.disabled) return;
  const keys = new Set(props.checkedKeys);
  eligible.value.forEach((item) => (allChecked.value ? keys.delete(item.key) : keys.add(item.key)));
  emit('check', [...keys]);
}
function toggle(row, value = !row.open) {
  if (props.disabled || row.item.disabled || query.value) return;
  const keys = new Set(expanded.value);
  if (value) keys.add(row.item.key);
  else keys.delete(row.item.key);
  expanded.value = keys;
}
async function focus(key) {
  focused.value = key;
  await nextTick();
  [...(root.value?.querySelectorAll('[data-key]') ?? [])]
    .find((element) => element.dataset.key === String(key))
    ?.focus();
}
function horizontalKey(key, row) {
  if (key === 'ArrowRight' && row.item.children.length) {
    if (!row.open) toggle(row, true);
    else return row.item.children.find((item) => !item.disabled)?.key;
  }
  if (key === 'ArrowLeft') {
    if (row.open) toggle(row, false);
    else return row.parent;
  }
}
function ignoresKey(event, row) {
  if (props.disabled || row.item.disabled || event.isComposing) return true;
  const checkbox = event.target.matches('input');
  return (event.target !== event.currentTarget && !checkbox) || (event.key === ' ' && checkbox);
}
function onKeydown(event, row) {
  if (ignoresKey(event, row)) return;
  const enabled = rows.value.filter((item) => !item.item.disabled);
  const index = enabled.findIndex((item) => item.item.key === row.item.key);
  let next;
  switch (event.key) {
    case 'ArrowDown':
      next = enabled[Math.min(index + 1, enabled.length - 1)]?.item.key;
      break;
    case 'ArrowUp':
      next = enabled[Math.max(0, index - 1)]?.item.key;
      break;
    case 'Home':
      next = enabled[0]?.item.key;
      break;
    case 'End':
      next = enabled.at(-1)?.item.key;
      break;
    case 'ArrowRight':
    case 'ArrowLeft':
      next = horizontalKey(event.key, row);
      break;
    case ' ':
    case 'Enter':
      check(row.item);
      break;
    default:
      return;
  }
  event.preventDefault();
  if (next != null) focus(next);
}
function searchChanged(value) {
  search.value = value;
  page.value = 1;
  emit('search', value);
}
function setPage(value) {
  page.value = value;
  emit('page-change', value);
}
async function move(keys) {
  const oldButtons = [...(root.value?.querySelectorAll('.wb-transfer-panel__auto-row') ?? [])];
  const index = oldButtons.indexOf(document.activeElement);
  emit('move', keys);
  await nextTick();
  if (index < 0) return;
  const buttons = [...root.value.querySelectorAll('.wb-transfer-panel__auto-row:enabled')];
  (
    buttons[Math.min(index, buttons.length - 1)] ??
    root.value.querySelector('.wb-transfer-panel__all')
  )?.focus();
}
function parts(label) {
  const index = query.value ? label.toLocaleLowerCase().indexOf(query.value) : -1;
  return index < 0
    ? null
    : [
        label.slice(0, index),
        label.slice(index, index + query.value.length),
        label.slice(index + query.value.length),
      ];
}
watch(
  () =>
    flattenItems(props.items)
      .filter((item) => item.children.length)
      .map((item) => item.key),
  (keys, oldKeys = []) => {
    if (props.side !== 'target') return;
    const previous = new Set(oldKeys);
    const next = new Set(expanded.value);
    keys.forEach((key) => {
      if (!previous.has(key)) next.add(key);
    });
    expanded.value = next;
  },
  { immediate: true },
);
watch(query, () => {
  focused.value = null;
});
watch(pageCount, () => {
  if (page.value > pageCount.value) page.value = pageCount.value;
});
</script>

<template>
  <section
    ref="root"
    class="wb-transfer-panel"
    :class="{ 'is-disabled': disabled }"
    :data-side="side"
    :aria-label="`${side === 'source' ? '可选' : '已选'}列表`"
    :aria-disabled="disabled"
  >
    <header class="wb-transfer-panel__header">
      <WorkbenchCheckbox
        v-if="mode === 'manual'"
        :label="`${title}（${selectedCount}/${totalCount}）`"
        :aria-label="`${side === 'source' ? '可选' : '已选'}列表全选`"
        :model-value="allChecked"
        :indeterminate="someChecked"
        :disabled="disabled || !eligible.length"
        @update:model-value="checkAll"
      />
      <template v-else>
        <span>{{ title }}</span>
        <button
          type="button"
          class="wb-transfer-panel__all"
          :aria-label="side === 'source' ? '添加全部可选项' : '移回全部已选项'"
          :disabled="disabled || !eligible.length"
          @click="move(eligible.map((item) => item.key))"
        >
          <WorkbenchIcon
            :name="`双箭头/大小=14,方向=${side === 'source' ? '右' : '左'}`"
            :size="14"
          />
        </button>
      </template>
    </header>
    <div
      v-if="searchable"
      class="wb-transfer-panel__search"
    >
      <div class="wb-transfer-panel__search-control">
        <WorkbenchIcon
          name="搜索_14px"

        />
        <input
          type="search"
          :aria-label="`搜索${side === 'source' ? '可选' : '已选'}项`"
          placeholder="请输入搜索内容"
          :value="search"
          :disabled="disabled"
          @input="searchChanged($event.target.value)"
        />
        <button
          v-if="search"
          type="button"
          :aria-label="`清除${side === 'source' ? '可选' : '已选'}搜索`"
          :disabled="disabled"
          @click="searchChanged('')"
        >
          <WorkbenchIcon
            name="/ic_public_close_line_10px"

          />
        </button>
      </div>
    </div>
    <div class="wb-transfer-panel__body">
      <div
        v-if="rows.length"
        class="wb-transfer-panel__list"
        :role="hasTree && mode === 'manual' ? 'tree' : 'list'"
        :aria-label="title"
        :aria-multiselectable="hasTree && mode === 'manual' ? true : undefined"
      >
        <div
          v-for="row in rows"
          :key="row.item.key"
          class="wb-transfer-panel__row"
          :class="{
            'is-disabled': disabled || row.item.disabled,
            'has-tree': hasTree && mode === 'manual',
          }"
          :data-key="row.item.key"
          :role="hasTree && mode === 'manual' ? 'treeitem' : 'listitem'"
          :tabindex="
            hasTree &&
            mode === 'manual' &&
            !disabled &&
            !row.item.disabled &&
            row.item.key === tabKey
              ? 0
              : undefined
          "
          :aria-level="hasTree ? row.level : undefined"
          :aria-posinset="hasTree ? row.index + 1 : undefined"
          :aria-setsize="hasTree ? row.size : undefined"
          :aria-expanded="hasTree && row.item.children.length ? row.open : undefined"
          :aria-disabled="disabled || row.item.disabled"
          :aria-checked="
            hasTree && mode === 'manual'
              ? state(row.item).mixed
                ? 'mixed'
                : state(row.item).checked
              : undefined
          "
          @focus.self="focused = row.item.key"
          @keydown="hasTree && mode === 'manual' && onKeydown($event, row)"
        >
          <span
            v-for="level in row.level - 1"
            :key="level"
            class="wb-transfer-panel__indent"
            aria-hidden="true"
          />
          <template v-if="mode === 'manual'">
            <button
              v-if="hasTree && row.item.children.length"
              type="button"
              class="wb-transfer-panel__toggle"
              :aria-label="`${row.open ? '收起' : '展开'}${row.item.label}`"
              :aria-expanded="row.open"
              :disabled="disabled || row.item.disabled || Boolean(query)"
              tabindex="-1"
              @click="toggle(row)"
            >
              <WorkbenchIcon
                name="结构树箭头/方向=向右" class="wb-disclosure-icon wb-disclosure-icon--branch" :class="{ 'is-expanded': row.open }"
                :size="16"
              />
            </button>
            <span
              v-else-if="hasTree"
              class="wb-transfer-panel__toggle-space"
            />
            <span class="wb-transfer-panel__text-tip"><WorkbenchTooltip :content="row.item.label" overflow-only><template #trigger>
            <div
              class="wb-transfer-panel__content"
              :class="{ 'is-checked': state(row.item).checked || state(row.item).mixed }"
            >
              <WorkbenchCheckbox
                :label="row.item.label"
                :aria-label="row.item.label"
                :model-value="state(row.item).checked"
                :indeterminate="state(row.item).mixed"
                :disabled="disabled || row.item.disabled || !enabledLeaves([row.item]).length"
                @update:model-value="check(row.item)"
              />
              <span
                v-if="query && parts(row.item.label)"
                class="wb-transfer-panel__highlight"
                aria-hidden="true"
                ><span>{{ parts(row.item.label)[0] }}</span
                ><mark>{{ parts(row.item.label)[1] }}</mark
                ><span>{{ parts(row.item.label)[2] }}</span></span
              >
            </div>
            </template></WorkbenchTooltip></span>
          </template>
          <button
            v-else
            type="button"
            class="wb-transfer-panel__auto-row"
            :aria-label="`${side === 'source' ? '添加' : '移回'}${row.item.label}`"
            :disabled="disabled || row.item.disabled"
            @click="move(row.item.leafKeys)"
          >
            <span class="wb-transfer-panel__text-tip"><WorkbenchTooltip :content="row.item.label" overflow-only><template #trigger>
            <span class="wb-transfer-panel__label"
              ><slot
                name="item"
                :item="row.item"
                :side="side"
                >{{ row.item.label }}</slot
              ></span
            >
            </template></WorkbenchTooltip></span>
            <WorkbenchIcon
              v-if="side === 'target'"
              class="wb-transfer-panel__remove"
              name="/ic_public_close_line_8px"

            />
          </button>
        </div>
      </div>
      <div
        v-else
        class="wb-transfer-panel__empty"
        role="status"
      >
        <slot
          name="empty"
          :side="side"
          :search="search"
          ><img
            v-if="!query"
            :src="emptyData"
            alt=""
          /><span>{{ query ? '未找到匹配项' : '暂无数据' }}</span></slot
        >
      </div>
    </div>
    <footer
      v-if="pagination && filtered.length"
      class="wb-transfer-panel__footer"
    >
      <WorkbenchPagination
        variant="simple"
        :total="filtered.length"
        :page-size="safePageSize"
        :model-value="currentPage"
        :disabled="disabled"
        :aria-label="`${side === 'source' ? '可选' : '已选'}列表分页`"
        @update:model-value="setPage"
      />
    </footer>
  </section>
</template>

<style scoped>
.wb-transfer-panel {
  box-sizing: border-box;
  display: flex;
  flex: 0 1 var(--transfer-panel-width);
  flex-direction: column;
  width: var(--transfer-panel-width);
  min-width: 0;
  height: var(--transfer-height);
  border-radius: var(--wb-radius-lg);
  background: var(--wb-color-surface-container);
  box-shadow: inset 0 0 0 var(--wb-asset-wb-transfer-stroke)
    var(--wb-color-border);
  overflow: hidden;
}
.wb-transfer-panel.is-disabled {
  background: var(--wb-color-fill-subtle-disabled);
  color: var(--wb-color-text-disabled);
}
.wb-transfer-panel__header {
  box-sizing: border-box;
  display: flex;
  flex: none;
  height: var(--wb-asset-wb-transfer-header);
  align-items: center;
  justify-content: space-between;
  padding-inline: var(--wb-asset-wb-transfer-inset);
  border-bottom: 1px solid var(--wb-color-border-separator);
}
.wb-transfer-panel__all {
  display: grid;
  place-items: center;
  border: 0;
  padding: 0;
  background: transparent;
  color: var(--wb-color-icon-primary);
  cursor: pointer;
}
.wb-transfer-panel__all:disabled {
  color: var(--wb-color-text-disabled);
  cursor: not-allowed;
}
.wb-transfer-panel__search {
  flex: none;
  padding: var(--wb-spacing-component-sm)
    var(--wb-asset-wb-transfer-inset) 0;
}
.wb-transfer-panel__search-control {
  box-sizing: border-box;
  display: flex;
  height: var(--wb-asset-wb-transfer-row);
  align-items: center;
  gap: var(--wb-spacing-component-xs);
  padding-inline: var(--wb-asset-wb-transfer-inset);
  border: 1px solid var(--wb-color-border);
  border-radius: var(--wb-radius-sm);
  color: var(--wb-color-icon-secondary);
}
.wb-transfer-panel__search-control:hover {
  border-color: var(--wb-color-border-hover);
}
.wb-transfer-panel__search-control:focus-within {
  border-color: var(--wb-color-border-focus);
}
.wb-transfer-panel__search-control:has(input:disabled) {
  border-color: var(--wb-color-border-disabled);
}
.wb-transfer-panel__search input {
  width: 100%;
  min-width: 0;
  border: 0;
  outline: 0;
  padding: 0;
  background: transparent;
  color: var(--wb-color-text-primary);
  font: inherit;
}
.wb-transfer-panel__search input::placeholder {
  color: var(--wb-color-text-placeholder);
}
.wb-transfer-panel__search input:disabled {
  color: var(--wb-color-text-disabled);
}
.wb-transfer-panel__search input::-webkit-search-cancel-button {
  display: none;
}
.wb-transfer-panel__search button {
  display: grid;
  place-items: center;
  border: 0;
  padding: 0;
  background: transparent;
  color: inherit;
  cursor: pointer;
}
.wb-transfer-panel__body {
  position: relative;
  display: flex;
  flex: 1;
  min-height: 0;
  overflow: auto;
  scrollbar-width: thin;
}
.wb-transfer-panel__list {
  box-sizing: border-box;
  width: 100%;
  padding: var(--wb-spacing-component-sm) var(--wb-spacing-component-xs) 0;
}
.wb-transfer-panel__row {
  box-sizing: border-box;
  position: relative;
  display: flex;
  align-items: center;
  height: var(--wb-asset-wb-transfer-row);
}
.wb-transfer-panel__row.has-tree {
  padding-inline-start: var(--wb-spacing-component-sm);
}
.wb-transfer-panel__indent {
  flex: none;
  width: var(--wb-asset-wb-transfer-indent);
}
.wb-transfer-panel__toggle,
.wb-transfer-panel__toggle-space {
  margin-inline-end: var(--wb-spacing-component-xs);
  display: grid;
  place-items: center;
  flex: none;
  width: var(--wb-asset-wb-transfer-toggle);
  height: var(--wb-asset-wb-transfer-toggle);
}
.wb-transfer-panel__toggle {
  border: 0;
  padding: 0;
  background: transparent;
  color: var(--wb-color-icon-primary);
  cursor: pointer;
}
.wb-transfer-panel__toggle:disabled {
  color: inherit;
  cursor: default;
}
.wb-transfer-panel__row.is-disabled {
  color: var(--wb-color-text-disabled);
}
.wb-transfer-panel__content {
  position: relative;
  display: flex;
  box-sizing: border-box;
  flex: 1;
  min-width: 0;
  height: 100%;
  align-items: center;
  padding-inline: var(--wb-spacing-component-sm);
  border-radius: var(--wb-radius-sm);
}
.has-tree .wb-transfer-panel__content {
  padding-inline-start: var(--wb-spacing-component-xs);
}
.wb-transfer-panel__row:not(.is-disabled) .wb-transfer-panel__content:hover {
  background: var(--wb-color-fill-hover);
}
.wb-transfer-panel__content :deep(.wb-choice) {
  width: 100%;
  min-width: 0;
}
.wb-transfer-panel__content :deep(.wb-choice__copy) {
  min-width: 0;
  overflow: hidden;
}
.wb-transfer-panel__content :deep(.wb-choice__label) {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.wb-transfer-panel__content :deep(.wb-choice__label) {
  cursor: inherit;
}
.wb-transfer-panel__content:has(.wb-transfer-panel__highlight) :deep(.wb-choice__label) {
  visibility: hidden;
}
.wb-transfer-panel__highlight {
  position: absolute;
  inset-inline-start: calc(
    var(--wb-spacing-component-sm) + var(--wb-asset-wb-transfer-toggle) +
      var(--wb-spacing-component-sm)
  );
  inset-inline-end: var(--wb-spacing-component-sm);
  pointer-events: none;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.has-tree .wb-transfer-panel__highlight {
  inset-inline-start: calc(
    var(--wb-spacing-component-xs) + var(--wb-asset-wb-transfer-toggle) +
      var(--wb-spacing-component-sm)
  );
}
.wb-transfer-panel mark {
  color: var(--wb-color-text-action);
  background: transparent;
}
.wb-transfer-panel__auto-row {
  display: flex;
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  height: 100%;
  align-items: center;
  gap: var(--wb-spacing-component-xs);
  padding: 0 var(--wb-spacing-component-sm);
  border: 0;
  border-radius: var(--wb-radius-sm);
  background: transparent;
  color: inherit;
  font: inherit;
  text-align: start;
  cursor: pointer;
}
.wb-transfer-panel__auto-row:disabled {
  cursor: not-allowed;
}
.wb-transfer-panel__auto-row:hover:enabled {
  background: var(--wb-color-fill-hover);
}
.wb-transfer-panel__label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.wb-transfer-panel__remove {
  visibility: hidden;
}
.wb-transfer-panel__auto-row:hover:enabled .wb-transfer-panel__remove,
.wb-transfer-panel__auto-row:focus-visible .wb-transfer-panel__remove {
  visibility: visible;
}
.wb-transfer-panel__row:focus-visible,
.wb-transfer-panel button:focus-visible {
  outline: 1px solid var(--wb-color-border-focus);
  outline-offset: -1px;
}
.wb-transfer-panel__empty {
  display: flex;
  flex: 1;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: var(--wb-color-text-secondary);
  font-size: var(--wb-font-body-s-font-size);
  line-height: var(--wb-font-body-s-line-height);
  font-weight: var(--wb-font-body-s-font-weight);
  letter-spacing: var(--wb-font-body-s-letter-spacing);
}
.wb-transfer-panel__empty img {
  display: block;
  width: var(--wb-asset-wb-transfer-empty-image);
  height: var(--wb-asset-wb-transfer-empty-image);
}
.wb-transfer-panel__footer {
  box-sizing: border-box;
  display: flex;
  justify-content: flex-end;
  flex: none;
  height: var(--wb-asset-wb-transfer-footer);
  padding: 0 var(--wb-asset-wb-transfer-inset)
    var(--wb-spacing-component-md);
}
</style>

<style scoped>
.wb-transfer-panel__text-tip { display: flex; min-width: 0; height: 100%; flex: 1; align-items: center; }
.wb-transfer-panel__text-tip :deep(.wb-tooltip) { display: flex; min-width: 0; width: 100%; height: 100%; align-items: center; }
</style>
