// Canonical values are leaf keys. Parent keys supplied by a consumer expand to leaves.
export function indexItems(items, inheritedDisabled = false) {
  return items.map((item) => {
    const disabled = inheritedDisabled || Boolean(item.disabled);
    const children = indexItems(item.children ?? [], disabled);
    return {
      ...item,
      label: String(item.label ?? item.title ?? item.key),
      disabled,
      children,
      leafKeys: children.length ? children.flatMap((child) => child.leafKeys) : [item.key],
    };
  });
}
export function flattenItems(items) {
  return items.flatMap((item) => [item, ...flattenItems(item.children)]);
}
export function partitionItems(items, target, side) {
  return items.flatMap((item) => {
    if (!item.children.length) return target.has(item.key) === (side === 'target') ? [item] : [];
    const children = partitionItems(item.children, target, side);
    return children.length
      ? [{ ...item, children, leafKeys: children.flatMap((child) => child.leafKeys) }]
      : [];
  });
}
export function filterItems(items, query) {
  if (!query) return items;
  return items.flatMap((item) => {
    if (item.label.toLocaleLowerCase().includes(query)) return [item];
    const children = filterItems(item.children, query);
    return children.length
      ? [{ ...item, children, leafKeys: children.flatMap((child) => child.leafKeys) }]
      : [];
  });
}
export function enabledLeaves(items) {
  return flattenItems(items).filter((item) => !item.children.length && !item.disabled);
}
