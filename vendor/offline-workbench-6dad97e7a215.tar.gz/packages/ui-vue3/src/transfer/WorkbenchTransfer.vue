<script setup>
import { useFormDisabled } from '../form/useFormDisabled.js';
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import { computed, ref } from 'vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import TransferPanel from './TransferPanel.vue';
import { indexItems, flattenItems, partitionItems, enabledLeaves } from './transferModel.js';
const props = defineProps({
  items: { type: Array, default: () => [] },
  modelValue: { type: Array, default: undefined },
  defaultValue: { type: Array, default: () => [] },
  checkedKeys: { type: Object, default: undefined },
  defaultCheckedKeys: { type: Object, default: () => ({ source: [], target: [] }) },
  mode: {
    type: String,
    default: 'manual',
    validator: (value) => ['manual', 'auto'].includes(value),
  },
  titles: { type: Array, default: () => ['可选', '已选'] },
  searchable: Boolean,
  pagination: { type: Boolean, default: true },
  pageSize: { type: Number, default: 6 },
  defaultExpandedKeys: { type: Array, default: () => [] },
  disabled: Boolean,
  label: { type: String, default: '穿梭框' },
});
const disabled = useFormDisabled(() => props.disabled);
const emit = defineEmits([
  'update:modelValue',
  'update:checkedKeys',
  'change',
  'check',
  'search',
  'page-change',
]);
const localValue = ref([...props.defaultValue]);
const localChecks = ref({
  source: [...(props.defaultCheckedKeys.source ?? [])],
  target: [...(props.defaultCheckedKeys.target ?? [])],
});
const tree = computed(() => indexItems(props.items));
const all = computed(() => flattenItems(tree.value));
const values = computed(() => props.modelValue ?? localValue.value);
const target = computed(() => {
  const keys = new Set(values.value);
  for (const item of all.value)
    if (keys.has(item.key)) item.leafKeys.forEach((key) => keys.add(key));
  return keys;
});
const panels = computed(() =>
  Object.fromEntries(
    ['source', 'target'].map((side) => [side, partitionItems(tree.value, target.value, side)]),
  ),
);
const checks = computed(() => props.checkedKeys ?? localChecks.value);
function selected(side) {
  const keys = new Set(checks.value[side] ?? []);
  for (const item of all.value)
    if (keys.has(item.key)) item.leafKeys.forEach((key) => keys.add(key));
  return enabledLeaves(panels.value[side])
    .filter((item) => keys.has(item.key))
    .map((item) => item.key);
}
function check(side, keys) {
  const next = {
    source: [...(checks.value.source ?? [])],
    target: [...(checks.value.target ?? [])],
    [side]: keys,
  };
  localChecks.value = next;
  emit('update:checkedKeys', next);
  emit('check', side, keys);
}
const announcement = ref('');
function move(side, requested = selected(side)) {
  if (disabled.value) return;
  const eligible = new Set(enabledLeaves(panels.value[side]).map((item) => item.key));
  const moved = [...new Set(requested)].filter((key) => eligible.has(key));
  if (!moved.length) return;
  const next = new Set(target.value);
  moved.forEach((key) => (side === 'source' ? next.add(key) : next.delete(key)));
  // Emit in original data order, independent of the order in which users check rows.
  const known = new Set(all.value.map((item) => item.key));
  const result = all.value
    .filter((item) => !item.children.length && next.has(item.key))
    .map((item) => item.key);
  result.push(...values.value.filter((key) => !known.has(key)));
  localValue.value = result;
  emit('update:modelValue', result);
  emit('change', result, side === 'source' ? 'right' : 'left', moved);
  check(
    side,
    (checks.value[side] ?? []).filter((key) => !moved.includes(key)),
  );
  announcement.value = `${side === 'source' ? '已添加' : '已移回'} ${moved.length} 项`;
}
defineExpose({ move });
</script>

<template>
  <div
    class="wb-transfer"
    :class="{ 'is-auto': mode === 'auto' }"
    role="group"
    :aria-label="label"
    :aria-disabled="disabled"
  >
    <template
      v-for="(side, index) in ['source', 'target']"
      :key="side"
    >
      <TransferPanel
        :items="panels[side]"
        :title="titles[index] ?? (index ? '已选' : '可选')"
        :side="side"
        :mode="mode"
        :checked-keys="selected(side)"
        :disabled="disabled"
        :searchable="searchable"
        :pagination="pagination && mode === 'manual'"
        :page-size="pageSize"
        :default-expanded-keys="defaultExpandedKeys"
        @check="check(side, $event)"
        @move="move(side, $event)"
        @search="emit('search', side, $event)"
        @page-change="emit('page-change', side, $event)"
      >
        <template #item="slotProps"
          ><slot
            name="item"
            v-bind="slotProps"
            >{{ slotProps.item.label }}</slot
          ></template
        >
        <template
          v-if="$slots.empty"
          #empty="slotProps"
          ><slot
            name="empty"
            v-bind="slotProps"
        /></template>
      </TransferPanel>
      <div
        v-if="index === 0 && mode === 'manual'"
        class="wb-transfer__actions"
      >
        <button
          type="button"
          aria-label="添加到已选"
          :disabled="disabled || !selected('source').length"
          @click="move('source')"
        >
          <WorkbenchIcon
            name="/ic_arrow_right_line#2:141"
            :size="10"
          />
        </button>
        <button
          type="button"
          aria-label="移回可选"
          :disabled="disabled || !selected('target').length"
          @click="move('target')"
        >
          <WorkbenchIcon
            name="/ic_arrow_left_line#2:144"
            :size="10"
          />
        </button>
      </div>
    </template>
    <span
      class="wb-transfer__announcement"
      aria-live="polite"
      aria-atomic="true"
      >{{ announcement }}</span
    >
  </div>
</template>

<style scoped>
.wb-transfer {
  --transfer-panel-width: var(--wb-asset-wb-transfer-panel-width);
  --transfer-height: var(--wb-asset-wb-transfer-height);
  display: flex;
  align-items: stretch;
  width: max-content;
  max-width: 100%;
  color: var(--wb-color-text-primary);
  font-family: var(--wb-font-family-sans-zh), var(--wb-font-family-sans-en);
  font-size: var(--wb-font-body-m-font-size);
  line-height: var(--wb-font-body-m-line-height);
  font-weight: var(--wb-font-body-m-font-weight);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
}
.wb-transfer.is-auto {
  --transfer-height: var(--wb-asset-wb-transfer-auto-height);
  gap: var(--wb-asset-wb-transfer-auto-gap);
}
.wb-transfer__actions {
  display: flex;
  flex: none;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: var(--wb-spacing-component-md);
  width: var(--wb-asset-wb-transfer-actions-width);
}
.wb-transfer__actions button {
  box-sizing: border-box;
  display: grid;
  place-items: center;
  flex: none;
  width: var(--wb-asset-wb-transfer-button);
  height: var(--wb-asset-wb-transfer-button);
  padding: 0;
  border: 1px solid var(--wb-color-border);
  border-radius: var(--wb-radius-sm);
  background: var(--wb-color-surface-container);
  color: var(--wb-color-icon-primary);
  cursor: pointer;
}
.wb-transfer__actions button:hover:enabled {
  background: var(--wb-color-fill-hover);
  border-color: var(--wb-color-border-hover);
}
.wb-transfer__actions button:disabled {
  color: var(--wb-color-text-disabled);
  background: var(--wb-color-fill-subtle-disabled);
  cursor: not-allowed;
}
.wb-transfer__actions button:focus-visible {
  outline: 1px solid var(--wb-color-border-focus);
  outline-offset: var(--wb-spacing-component-xs);
}
.wb-transfer__announcement {
  position: absolute;
  width: 0;
  height: 0;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
</style>
