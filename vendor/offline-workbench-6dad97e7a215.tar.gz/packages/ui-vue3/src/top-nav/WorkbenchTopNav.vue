<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue';
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import TopNavAction from './TopNavAction.vue';
import huaweiLogo from './assets/huawei-logo.png';

const props = defineProps({
  mode: {
    type: String,
    default: 'workbench',
    validator: (value) => ['portal', 'workbench'].includes(value),
  },
  userState: {
    type: String,
    default: 'authenticated',
    validator: (value) => ['guest', 'authenticated'].includes(value),
  },
  activeTab: { type: String, default: 'home' },
  currentSite: { type: String, default: 'partner' },
  currentLanguage: { type: String, default: 'zh-CN' },
  tabs: { type: Array, default: () => [] },
  sites: { type: Array, default: () => [] },
  languages: { type: Array, default: () => [] },
  userMenuItems: { type: Array, default: () => [] },
  tabMenus: { type: Object, default: () => ({}) },
  actions: { type: Array, default: null },
});

const emit = defineEmits([
  'update:activeTab',
  'select-site',
  'select-language',
  'select-user-action',
  'select-tab-entry',
  'navigate',
  'search',
  'notification',
  'login',
  'register',
  'action',
]);
const root = ref(null);
const actionsElement = ref(null);
const pressedActions = ref(new Set());
const primary = ref(null);
const brand = ref(null);
const indicatorElement = ref(null);
const moreTrigger = ref(null);
const moreMeasure = ref(null);
const activePanel = ref(null);
const mobileView = ref('main');
const megaTab = ref(null);
const viewportWidth = ref(typeof window === 'undefined' ? 1440 : window.innerWidth);
const visibleTabCount = ref(props.tabs.length);
const tabRefs = new Map();
const measureRefs = new Map();
const triggerRefs = new Map();
const openedTriggers = new Map();
const optionRefs = {
  site: [],
  language: [],
  user: [],
  more: [],
  mobile: [],
  mobileSite: [],
  mobileLanguage: [],
};
let resizeObserver;
let megaCloseTimer;
let suppressMegaFocus = false;

const currentLabel = (items, value) => items.find((item) => item.value === value)?.label ?? value;
const visibleTabs = computed(() => props.tabs.slice(0, visibleTabCount.value));
const overflowTabs = computed(() => props.tabs.slice(visibleTabCount.value));
const hasLocalTabs = computed(() => props.tabs.some((tab) => !tab.href));
const activeTabIsOverflow = computed(() =>
  overflowTabs.value.some((tab) => tab.value === props.activeTab),
);
const megaMenu = computed(() => props.tabMenus[megaTab.value] ?? null);
const megaVisible = computed(
  () => megaMenu.value && (activePanel.value === 'mega' || activePanel.value === 'more'),
);
const compactActions = computed(() => viewportWidth.value <= 1024);
const configuredActions = computed(
  () =>
    props.actions ?? [
      { type: 'search' },
      ...(props.mode === 'workbench' && props.userState === 'authenticated'
        ? [{ type: 'message' }]
        : []),
      { type: props.userState === 'guest' ? 'login-register' : 'certified' },
    ],
);
const visibleActions = computed(() => {
  const items = configuredActions.value.filter(
    (item) =>
      !item.hidden &&
      (!compactActions.value ||
        item.compact === true ||
        [
          'search',
          'login-register',
          'certified',
          'pending',
          'login',
          'register',
          'menu',
          'close',
        ].includes(item.type)),
  );
  const result = items.map((item, index) => ({ ...item, key: item.id ?? `${item.type}-${index}` }));
  if (compactActions.value && !result.some((item) => item.type === 'menu'))
    result.push({ type: 'menu', key: 'compact-menu' });
  if (compactActions.value)
    result.sort((a, b) => Number(a.type === 'menu') - Number(b.type === 'menu'));
  return result;
});
const actionPanel = (item) => {
  if (['certified', 'pending', 'login-register'].includes(item.type)) return 'user';
  if (item.type === 'language') return 'language';
  if (item.type === 'menu') return 'mobile';
  return null;
};
function activateAction(item, event) {
  if (item.disabled) return;
  const panel = actionPanel(item);
  if (panel) {
    setTriggerRef(panel, event.currentTarget);
    togglePanel(panel);
  } else {
    closePanel();
    if (item.type === 'favorite') {
      const next = new Set(pressedActions.value);
      (item.pressed ?? next.has(item.key)) ? next.delete(item.key) : next.add(item.key);
      pressedActions.value = next;
    }
    if (item.type === 'search') emit('search');
    else if (item.type === 'message') emit('notification');
    else if (item.type === 'login') emit('login');
    else if (item.type === 'register') emit('register');
  }
  emit('action', {
    type: item.type,
    id: item.id ?? item.type,
    pressed: item.type === 'favorite' ? pressedActions.value.has(item.key) : undefined,
  });
}
function actionKeydown(item, event) {
  const panel = actionPanel(item);
  if (!panel || item.disabled) return;
  setTriggerRef(panel, event.currentTarget);
  triggerKeydown(event, panel);
}
const setTabRef = (value, element) =>
  element ? tabRefs.set(value, element) : tabRefs.delete(value);
const setMeasureRef = (value, element) =>
  element ? measureRefs.set(value, element) : measureRefs.delete(value);
const setTriggerRef = (panel, element) =>
  element ? triggerRefs.set(panel, element) : triggerRefs.delete(panel);
const setMoreTrigger = (element) => {
  moreTrigger.value = element;
  setTriggerRef('more', element);
};
const setOptionRef = (panel, index, element) => {
  optionRefs[panel][index] = element;
};

function updateIndicator() {
  const directTab = tabRefs.get(props.activeTab);
  const tab = activeTabIsOverflow.value
    ? moreTrigger.value
    : directTab?.isConnected
      ? directTab
      : null;
  const list = indicatorElement.value?.parentElement;
  if (!tab || !list) return;
  const tabBox = tab.getBoundingClientRect();
  const listBox = list.getBoundingClientRect();
  if (!indicatorElement.value) return;
  indicatorElement.value.style.transform = `translateX(${tabBox.left - listBox.left}px)`;
  indicatorElement.value.style.width = `${tabBox.width}px`;
}

function measuredTabWidth(tab) {
  return measureRefs.get(tab.value)?.getBoundingClientRect().width ?? 0;
}

function updateResponsiveLayout() {
  if (typeof window === 'undefined') return;
  viewportWidth.value = window.innerWidth;
  root.value?.style.setProperty(
    '--wb-top-nav-actions-width',
    `${actionsElement.value?.offsetWidth ?? 0}px`,
  );
  positionPanel(activePanel.value);
  if (viewportWidth.value < 1024 && ['site', 'language'].includes(activePanel.value))
    activePanel.value = null;
  if (viewportWidth.value > 1024 && activePanel.value === 'mobile') activePanel.value = null;
  if (viewportWidth.value <= 1024 || !primary.value || !brand.value) {
    visibleTabCount.value = props.tabs.length;
    nextTick(updateIndicator);
    return;
  }
  const styles = getComputedStyle(root.value);
  const brandGap = Number.parseFloat(
    styles.getPropertyValue('--wb-asset-wb-top-nav-brand-to-tabs-gap'),
  );
  const gap = Number.parseFloat(styles.getPropertyValue('--wb-spacing-layout-section-gap-large'));
  const available =
    primary.value.clientWidth - brand.value.getBoundingClientRect().width - brandGap;
  const moreWidth = moreMeasure.value?.getBoundingClientRect().width ?? 0;
  const widths = props.tabs.map(measuredTabWidth);
  const totalWidth =
    widths.reduce((sum, width) => sum + width, 0) + Math.max(0, widths.length - 1) * gap;
  if (viewportWidth.value >= 1440 && totalWidth <= available) {
    visibleTabCount.value = props.tabs.length;
    nextTick(updateIndicator);
    return;
  }
  let used = 0;
  let count = 0;
  for (const tab of props.tabs) {
    const width = measuredTabWidth(tab);
    const next = used + (count ? gap : 0) + width;
    const reserve = gap + moreWidth;
    if (next + reserve > available) break;
    used = next;
    count += 1;
  }
  visibleTabCount.value = Math.max(1, Math.min(count, props.tabs.length - 1));
  nextTick(updateIndicator);
}

function reportNavigation(kind, item, extra = {}) {
  if (item?.href) emit('navigate', { kind, value: item.value, href: item.href, ...extra });
}

function positionPanel(panel) {
  if (!['language', 'user', 'mobile'].includes(panel) || !root.value) return;
  const trigger = openedTriggers.get(panel);
  if (!trigger?.isConnected) return;
  const bounds = root.value.getBoundingClientRect();
  const anchor = trigger.getBoundingClientRect();
  const gap = Number.parseFloat(
    getComputedStyle(root.value).getPropertyValue('--wb-spacing-component-xs'),
  );
  root.value.style.setProperty(
    `--wb-top-nav-${panel}-top`,
    `${anchor.bottom - bounds.top + gap}px`,
  );
  root.value.style.setProperty(
    `--wb-top-nav-${panel}-right`,
    `${Math.max(0, bounds.right - anchor.right)}px`,
  );
}

async function togglePanel(panel, focusFirst = false) {
  if (panel === 'mobile' && activePanel.value !== 'mobile') mobileView.value = 'main';
  if (panel === 'more' && activePanel.value !== 'more') megaTab.value = null;
  const opening = activePanel.value !== panel;
  if (opening) openedTriggers.set(panel, triggerRefs.get(panel));
  activePanel.value = opening ? panel : null;
  if (opening) positionPanel(panel);
  if (activePanel.value && focusFirst) {
    await nextTick();
    optionRefs[panel].find(Boolean)?.focus();
  }
}

function closePanel({ restoreFocus = false } = {}) {
  const panel = activePanel.value;
  const trigger = openedTriggers.get(panel) ?? triggerRefs.get(panel);
  activePanel.value = null;
  if (restoreFocus && panel)
    nextTick(() => {
      suppressMegaFocus = panel === 'mega';
      trigger?.focus();
      suppressMegaFocus = false;
    });
}

function cancelMegaClose() {
  if (typeof window !== 'undefined') window.clearTimeout(megaCloseTimer);
}

function openMega(tab) {
  if (suppressMegaFocus) return;
  if (viewportWidth.value <= 1024 || !props.tabMenus[tab.value]) return;
  cancelMegaClose();
  megaTab.value = tab.value;
  activePanel.value = 'mega';
  triggerRefs.set('mega', tabRefs.get(tab.value));
}

function openMegaFromMore(tab) {
  if (!props.tabMenus[tab.value]) return;
  cancelMegaClose();
  megaTab.value = tab.value;
}

function scheduleMegaClose() {
  cancelMegaClose();
  if (typeof window === 'undefined') return;
  megaCloseTimer = window.setTimeout(() => {
    if (activePanel.value === 'mega') activePanel.value = null;
    else if (activePanel.value === 'more') megaTab.value = null;
  }, 120);
}

function selectTabHome(tab) {
  if (!tab) return;
  emit('update:activeTab', tab.value);
  activePanel.value = null;
}

async function openMobileView(view) {
  mobileView.value = view;
  await nextTick();
  optionRefs[view === 'site' ? 'mobileSite' : 'mobileLanguage'].find(Boolean)?.focus();
}

function handleEscape(event) {
  if (activePanel.value === 'mobile' && mobileView.value !== 'main') {
    event.preventDefault();
    event.stopPropagation();
    const previousView = mobileView.value;
    mobileView.value = 'main';
    nextTick(() => root.value?.querySelector(`[data-mobile-view="${previousView}"]`)?.focus());
    return true;
  }
  return false;
}

function triggerKeydown(event, panel) {
  if (!['ArrowDown', 'ArrowUp'].includes(event.key)) return;
  event.preventDefault();
  togglePanel(panel, true);
}

function menuKeydown(event, panel, index) {
  const items = optionRefs[panel].filter(Boolean);
  if (!items.length) return;
  if (event.key === 'Escape') {
    if (!handleEscape(event)) {
      event.preventDefault();
      closePanel({ restoreFocus: true });
    }
    return;
  }
  if (!['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) return;
  event.preventDefault();
  const current = Math.max(0, items.indexOf(optionRefs[panel][index]));
  const target =
    event.key === 'Home'
      ? 0
      : event.key === 'End'
        ? items.length - 1
        : (current + (event.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length;
  items[target]?.focus();
}

function choose(panel, item) {
  if (panel === 'site') emit('select-site', item.value);
  if (panel === 'language') emit('select-language', item.value);
  if (panel === 'mobileSite') emit('select-site', item.value);
  if (panel === 'mobileLanguage') emit('select-language', item.value);
  if (panel === 'user') emit('select-user-action', item.value);
  if (panel === 'more' || panel === 'mobile') emit('update:activeTab', item.value);
  closePanel({ restoreFocus: true });
}

function chooseGuest(action) {
  emit(action);
  closePanel({ restoreFocus: true });
}

function handleDocumentPointer(event) {
  if (activePanel.value && !root.value?.contains(event.target)) closePanel();
}

function handleRootFocusOut() {
  requestAnimationFrame(() => {
    if (activePanel.value && !root.value?.contains(document.activeElement)) closePanel();
  });
}

function handleRootKeydown(event) {
  if (event.key === 'Escape' && activePanel.value) {
    if (!handleEscape(event)) {
      event.preventDefault();
      closePanel({ restoreFocus: true });
    }
  }
}

watch(
  () => props.activeTab,
  () => nextTick(updateIndicator),
);
watch(
  () => props.tabs,
  () => nextTick(updateResponsiveLayout),
  { deep: true },
);
watch(
  () => [props.mode, props.userState, props.actions],
  () => {
    closePanel();
    pressedActions.value = new Set();
    nextTick(updateResponsiveLayout);
  },
  { deep: true },
);
onMounted(() => {
  nextTick(updateResponsiveLayout);
  document.addEventListener('pointerdown', handleDocumentPointer);
  resizeObserver = new ResizeObserver(updateResponsiveLayout);
  if (root.value) resizeObserver.observe(root.value);
  if (actionsElement.value) resizeObserver.observe(actionsElement.value);
});
onBeforeUnmount(() => {
  document.removeEventListener('pointerdown', handleDocumentPointer);
  cancelMegaClose();
  resizeObserver?.disconnect();
});
</script>

<template>
  <header
    ref="root"
    class="wb-top-nav"
    :class="[`is-${mode}`, `is-${userState}`]"
    role="banner"
    :aria-label="mode === 'workbench' ? '伙伴工作台顶部导航' : '门户官网顶部导航'"
    @focusout="handleRootFocusOut"
    @keydown="handleRootKeydown"
  >
    <div class="wb-top-nav__utility">
      <div class="wb-top-nav__grid wb-top-nav__utility-grid">
        <button
          :ref="(element) => setTriggerRef('site', element)"
          class="wb-top-nav__utility-trigger"
          type="button"
          aria-haspopup="menu"
          :aria-expanded="activePanel === 'site'"
          aria-controls="wb-top-nav-site-panel"
          @click="togglePanel('site')"
          @keydown="triggerKeydown($event, 'site')"
        >
          <WorkbenchIcon
            class="wb-top-nav__utility-icon"
            name="WB-TOP-NAV/企业伙伴网站_12px"
          />
          <span>{{ currentLabel(sites, currentSite) }}</span>
          <WorkbenchIcon
            class="wb-top-nav__utility-arrow"
            name="/ic_arrow_down_line#103:85"
            :size="8"
          />
        </button>
        <button
          :ref="(element) => setTriggerRef('language', element)"
          class="wb-top-nav__utility-trigger"
          type="button"
          aria-haspopup="menu"
          :aria-expanded="activePanel === 'language'"
          aria-controls="wb-top-nav-language-panel"
          @click="togglePanel('language')"
          @keydown="triggerKeydown($event, 'language')"
        >
          <WorkbenchIcon
            class="wb-top-nav__utility-icon"
            name="WB-TOP-NAV/语言地球_12px"
          />
          <span>{{ currentLabel(languages, currentLanguage) }}</span>
          <WorkbenchIcon
            class="wb-top-nav__utility-arrow"
            name="/ic_arrow_down_line#103:85"
            :size="8"
          />
        </button>
      </div>
    </div>

    <Transition name="wb-top-nav-site-reveal">
      <section
        v-if="activePanel === 'site'"
        id="wb-top-nav-site-panel"
        class="wb-top-nav__site-panel"
        role="menu"
        aria-label="切换官网"
      >
        <div class="wb-top-nav__grid wb-top-nav__site-grid">
          <div class="wb-top-nav__site-current">
            <WorkbenchIcon
              class="wb-top-nav__site-current-arrow"
              name="箭头/方向=右箭头_16px"
              :color="'var(--wb-color-brand)'"
            />
            <span>当前站点：{{ currentLabel(sites, currentSite) }}</span>
          </div>
          <div class="wb-top-nav__site-list">
            <component
              :is="site.href ? 'a' : 'button'"
              v-for="(site, index) in sites.filter((item) => item.value !== currentSite)"
              :key="site.value"
              :ref="(element) => setOptionRef('site', index, element)"
              type="button"
              role="menuitem"
              :href="site.href"
              @click="
                choose('site', site);
                reportNavigation('site', site);
              "
              @keydown="menuKeydown($event, 'site', index)"
            >
              <span class="wb-top-nav__site-entry-content">
                <WorkbenchIcon
                  class="wb-top-nav__site-icon"
                  :name="site.icon || '房子/尺寸=24,面性=off'"
                  :size="24"
                  :color="'var(--wb-color-icon-secondary)'"
                />
                <span class="wb-top-nav__site-label">{{ site.label }}</span>
                <WorkbenchIcon
                  class="wb-top-nav__site-arrow"
                  name="箭头/方向=右箭头_16px"
                  :color="'var(--wb-color-icon-secondary)'"
                />
              </span>
            </component>
          </div>
        </div>
      </section>
    </Transition>

    <section
      v-if="activePanel === 'language'"
      id="wb-top-nav-language-panel"
      class="wb-top-nav__menu wb-top-nav__language-panel"
      role="menu"
      aria-label="切换语言"
    >
      <button
        v-for="(language, index) in languages"
        :key="language.value"
        :ref="(element) => setOptionRef('language', index, element)"
        type="button"
        role="menuitemradio"
        :aria-checked="language.value === currentLanguage"
        @click="choose('language', language)"
        @keydown="menuKeydown($event, 'language', index)"
      >
        <span>{{ language.label }}</span
        ><WorkbenchIcon
          v-if="language.value === currentLanguage"
          class="wb-top-nav__checkmark"
          name="/ic_public_checkmark_line_16px"
        />
      </button>
    </section>

    <div class="wb-top-nav__business">
      <div class="wb-top-nav__grid wb-top-nav__business-grid">
        <div
          ref="primary"
          class="wb-top-nav__primary"
        >
          <div
            ref="brand"
            class="wb-top-nav__brand"
          >
            <img
              class="wb-top-nav__logo"
              :src="huaweiLogo"
              alt="Huawei"
            />
            <span
              class="wb-top-nav__divider"
              aria-hidden="true"
            ></span>
            <span class="wb-top-nav__title">伙伴工作台</span>
          </div>
          <nav
            class="wb-top-nav__tabs"
            aria-label="业务导航"
          >
            <div
              class="wb-top-nav__tab-list"
              :role="hasLocalTabs ? 'tablist' : undefined"
              @mouseenter="cancelMegaClose"
              @mouseleave="scheduleMegaClose"
            >
              <component
                :is="tab.href ? 'a' : 'button'"
                v-for="tab in visibleTabs"
                :key="tab.value"
                :ref="(element) => setTabRef(tab.value, element)"
                type="button"
                :role="tab.href ? undefined : 'tab'"
                :aria-selected="tab.href ? undefined : tab.value === activeTab"
                :aria-current="tab.href && tab.value === activeTab ? 'page' : undefined"
                :tabindex="tab.href ? undefined : tab.value === activeTab ? 0 : -1"
                :aria-expanded="
                  tabMenus[tab.value] ? activePanel === 'mega' && megaTab === tab.value : undefined
                "
                @mouseenter="openMega(tab)"
                @focus="openMega(tab)"
                :href="tab.href"
                @click="
                  selectTabHome(tab);
                  reportNavigation('tab', tab);
                "
                >{{ tab.label }}</component
              >
              <div
                v-if="overflowTabs.length"
                class="wb-top-nav__more-wrap"
              >
                <button
                  :ref="setMoreTrigger"
                  class="wb-top-nav__more-trigger"
                  type="button"
                  aria-haspopup="menu"
                  :aria-expanded="activePanel === 'more'"
                  aria-controls="wb-top-nav-more-panel"
                  :role="hasLocalTabs ? 'tab' : undefined"
                  :aria-selected="hasLocalTabs ? activeTabIsOverflow : undefined"
                  @click="togglePanel('more')"
                  @keydown="triggerKeydown($event, 'more')"
                >
                  <span>更多</span>
                </button>
                <section
                  v-if="activePanel === 'more'"
                  id="wb-top-nav-more-panel"
                  class="wb-top-nav__menu wb-top-nav__more-panel"
                  role="menu"
                  aria-label="更多业务导航"
                >
                  <component
                    :is="tab.href ? 'a' : 'button'"
                    v-for="(tab, index) in overflowTabs"
                    :key="tab.value"
                    :ref="(element) => setOptionRef('more', index, element)"
                    type="button"
                    :role="tab.href ? 'menuitem' : 'menuitemradio'"
                    :aria-checked="tab.href ? undefined : tab.value === activeTab"
                    :aria-current="tab.href && tab.value === activeTab ? 'page' : undefined"
                    :aria-expanded="megaTab === tab.value && megaVisible"
                    @mouseenter="openMegaFromMore(tab)"
                    @focus="openMegaFromMore(tab)"
                    :href="tab.href"
                    @click="
                      choose('more', tab);
                      reportNavigation('tab', tab);
                    "
                    @keydown="menuKeydown($event, 'more', index)"
                    >{{ tab.label }}</component
                  >
                </section>
              </div>
              <span
                ref="indicatorElement"
                class="wb-top-nav__indicator"
                aria-hidden="true"
              ></span>
            </div>
          </nav>
          <div
            class="wb-top-nav__tab-measurer"
            aria-hidden="true"
          >
            <span
              v-for="tab in tabs"
              :key="tab.value"
              :ref="(element) => setMeasureRef(tab.value, element)"
              >{{ tab.label }}</span
            >
            <span
              ref="moreMeasure"
              class="wb-top-nav__more-measure"
              >更多</span
            >
          </div>
        </div>
        <div
          ref="actionsElement"
          class="wb-top-nav__actions"
        >
          <TopNavAction
            v-for="item in visibleActions"
            :key="item.key"
            :class="{
              'wb-top-nav__action': true,
              'wb-top-nav__desktop-search': item.type === 'search',
              'wb-top-nav__user-trigger': ['certified', 'pending', 'login-register'].includes(
                item.type,
              ),
              'wb-top-nav__hamburger': item.type === 'menu',
            }"
            :type="item.type"
            :label="item.label"
            :badge="item.badge"
            :initial="item.initial"
            :avatar-url="item.avatarUrl"
            :compact="compactActions"
            :disabled="item.disabled"
            :pressed="
              item.type === 'favorite' ? (item.pressed ?? pressedActions.has(item.key)) : undefined
            "
            :expanded="actionPanel(item) ? activePanel === actionPanel(item) : undefined"
            :controls="actionPanel(item) ? `wb-top-nav-${actionPanel(item)}-panel` : undefined"
            @click="activateAction(item, $event)"
            @keydown="actionKeydown(item, $event)"
          />
        </div>
      </div>
      <Transition name="wb-top-nav-mega-scrim">
        <div
          v-if="megaVisible"
          class="wb-top-nav__mega-scrim"
          aria-hidden="true"
          @click="closePanel()"
        ></div>
      </Transition>
      <Transition name="wb-top-nav-mega-reveal">
        <section
          v-if="megaVisible"
          class="wb-top-nav__mega-panel"
          :aria-label="`${megaMenu.label}业务菜单`"
          @mouseenter="cancelMegaClose"
          @mouseleave="scheduleMegaClose"
        >
          <div class="wb-top-nav__mega-reveal-content">
            <div class="wb-top-nav__grid wb-top-nav__mega-grid">
              <div class="wb-top-nav__mega-overview">
                <h2>{{ megaMenu.label }}</h2>
                <component
                  :is="tabs.find((tab) => tab.value === megaTab)?.href ? 'a' : 'button'"
                  type="button"
                  :href="tabs.find((tab) => tab.value === megaTab)?.href"
                  @click="
                    selectTabHome(tabs.find((tab) => tab.value === megaTab));
                    reportNavigation(
                      'home',
                      tabs.find((tab) => tab.value === megaTab),
                      { tab: megaTab },
                    );
                  "
                >
                  <span>进入首页</span
                  ><svg
                    viewBox="0 0 16 16"
                    aria-hidden="true"
                  >
                    <path d="m6 3 5 5-5 5" />
                  </svg>
                </component>
              </div>
              <div class="wb-top-nav__mega-content">
                <section
                  v-for="group in megaMenu.groups"
                  :key="group.title"
                  class="wb-top-nav__mega-group"
                >
                  <h3>{{ group.title }}</h3>
                  <nav :aria-label="group.title">
                    <component
                      :is="item.href ? 'a' : 'button'"
                      v-for="item in group.items"
                      :key="item.value"
                      type="button"
                      :href="item.href"
                      @click="
                        emit('select-tab-entry', { tab: megaTab, value: item.value });
                        reportNavigation('mega-entry', item, { tab: megaTab });
                        closePanel();
                      "
                      ><span>{{ item.label }}</span></component
                    >
                  </nav>
                </section>
              </div>
            </div>
          </div>
        </section>
      </Transition>
    </div>

    <section
      v-if="activePanel === 'user' && userState === 'authenticated'"
      id="wb-top-nav-user-panel"
      class="wb-top-nav__menu wb-top-nav__user-panel"
      role="menu"
      aria-label="我的入口"
    >
      <template
        v-for="(item, index) in userMenuItems"
        :key="item.value"
      >
        <hr v-if="item.type === 'separator'" />
        <button
          v-else
          :ref="(element) => setOptionRef('user', index, element)"
          type="button"
          role="menuitem"
          :class="{ 'is-danger': item.danger }"
          @click="choose('user', item)"
          @keydown="menuKeydown($event, 'user', index)"
        >
          {{ item.label }}
        </button>
      </template>
    </section>
    <section
      v-if="activePanel === 'user' && userState === 'guest'"
      id="wb-top-nav-user-panel"
      class="wb-top-nav__menu wb-top-nav__user-panel wb-top-nav__guest-panel"
      role="menu"
      aria-label="未登录账户"
    >
      <div class="wb-top-nav__guest-message">登录后可访问伙伴服务</div>
      <button
        :ref="(element) => setOptionRef('user', 0, element)"
        class="wb-top-nav__guest-login"
        type="button"
        role="menuitem"
        @click="chooseGuest('login')"
        @keydown="menuKeydown($event, 'user', 0)"
      >
        登录
      </button>
      <button
        :ref="(element) => setOptionRef('user', 1, element)"
        type="button"
        role="menuitem"
        @click="chooseGuest('register')"
        @keydown="menuKeydown($event, 'user', 1)"
      >
        注册
      </button>
    </section>
    <section
      v-if="activePanel === 'mobile'"
      id="wb-top-nav-mobile-panel"
      class="wb-top-nav__menu wb-top-nav__mobile-panel"
      role="menu"
      aria-label="业务导航菜单"
    >
      <template v-if="mobileView === 'main'">
        <div class="wb-top-nav__mobile-title"><span>伙伴工作台</span></div>
        <component
          :is="tab.href ? 'a' : 'button'"
          v-for="(tab, index) in tabs"
          :key="tab.value"
          :ref="(element) => setOptionRef('mobile', index, element)"
          type="button"
          :role="tab.href ? 'menuitem' : 'menuitemradio'"
          :aria-checked="tab.href ? undefined : tab.value === activeTab"
          :aria-current="tab.href && tab.value === activeTab ? 'page' : undefined"
          :href="tab.href"
          @click="
            choose('mobile', tab);
            reportNavigation('tab', tab);
          "
          @keydown="menuKeydown($event, 'mobile', index)"
          >{{ tab.label }}</component
        >
        <template v-if="viewportWidth < 1024">
          <hr />
          <button
            :ref="(element) => setOptionRef('mobile', tabs.length, element)"
            type="button"
            data-mobile-view="site"
            role="menuitem"
            @click="openMobileView('site')"
            @keydown="menuKeydown($event, 'mobile', tabs.length)"
          >
            <span>切换官网</span
            ><span class="wb-top-nav__mobile-current"
              >{{ currentLabel(sites, currentSite) }} ›</span
            >
          </button>
          <button
            :ref="(element) => setOptionRef('mobile', tabs.length + 1, element)"
            type="button"
            data-mobile-view="language"
            role="menuitem"
            @click="openMobileView('language')"
            @keydown="menuKeydown($event, 'mobile', tabs.length + 1)"
          >
            <span>切换语言</span
            ><span class="wb-top-nav__mobile-current"
              >{{ currentLabel(languages, currentLanguage) }} ›</span
            >
          </button>
        </template>
      </template>
      <template v-else-if="mobileView === 'site'">
        <button
          class="wb-top-nav__mobile-back"
          type="button"
          role="menuitem"
          @click="mobileView = 'main'"
        >
          ‹ 返回
        </button>
        <div class="wb-top-nav__mobile-title">切换官网</div>
        <component
          :is="site.href ? 'a' : 'button'"
          v-for="(site, index) in sites"
          :key="site.value"
          :ref="(element) => setOptionRef('mobileSite', index, element)"
          type="button"
          :role="site.href ? 'menuitem' : 'menuitemradio'"
          :aria-checked="site.href ? undefined : site.value === currentSite"
          :aria-current="site.href && site.value === currentSite ? 'page' : undefined"
          :href="site.href"
          @click="
            choose('mobileSite', site);
            reportNavigation('site', site);
          "
          @keydown="menuKeydown($event, 'mobileSite', index)"
          >{{ site.label
          }}<WorkbenchIcon
            v-if="site.value === currentSite"
            class="wb-top-nav__checkmark"
            name="/ic_public_checkmark_line_16px"
        /></component>
      </template>
      <template v-else>
        <button
          class="wb-top-nav__mobile-back"
          type="button"
          role="menuitem"
          @click="mobileView = 'main'"
        >
          ‹ 返回
        </button>
        <div class="wb-top-nav__mobile-title">切换语言</div>
        <button
          v-for="(language, index) in languages"
          :key="language.value"
          :ref="(element) => setOptionRef('mobileLanguage', index, element)"
          type="button"
          role="menuitemradio"
          :aria-checked="language.value === currentLanguage"
          @click="choose('mobileLanguage', language)"
          @keydown="menuKeydown($event, 'mobileLanguage', index)"
        >
          {{ language.label
          }}<WorkbenchIcon
            v-if="language.value === currentLanguage"
            class="wb-top-nav__checkmark"
            name="/ic_public_checkmark_line_16px"
          />
        </button>
      </template>
    </section>
  </header>
</template>

<style scoped>
.wb-top-nav {
  position: relative;
  z-index: 10;
  min-width: 0;
  color: var(--wb-color-text-primary);
  background: var(--wb-color-surface-overlay);
}
:is(button, a) {
  color: inherit;
  font: inherit;
}
.wb-top-nav__grid {
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  max-width: calc(
    var(--wb-asset-wb-top-nav-grid-max-width) + 2 * var(--wb-spacing-screen-edge-expanded)
  );
  margin-inline: auto;
  padding-inline: var(--wb-spacing-screen-edge-compact);
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  column-gap: var(--wb-spacing-component-lg);
}
.wb-top-nav__utility {
  height: var(--wb-asset-wb-top-nav-utility-height);
  background: var(--wb-color-fill-default);
}
.wb-top-nav__utility-grid {
  align-items: center;
}
.wb-top-nav__utility-grid > :first-child {
  grid-column: 1;
  grid-row: 1;
  justify-self: start;
}
.wb-top-nav__utility-grid > :last-child {
  grid-column: 1;
  grid-row: 1;
  justify-self: end;
}
.wb-top-nav__utility-trigger {
  height: 100%;
  display: inline-flex;
  align-items: center;
  gap: var(--wb-spacing-component-xs);
  padding: 0;
  border: 0;
  background: transparent;
  color: var(--wb-color-text-secondary);
  font-size: var(--wb-font-body-s-font-size);
  font-weight: var(--wb-font-body-s-font-weight);
  line-height: var(--wb-font-body-s-line-height);
  letter-spacing: var(--wb-font-body-s-letter-spacing);
  cursor: pointer;
}
.wb-top-nav__utility-trigger:hover,
.wb-top-nav__utility-trigger:focus-visible {
  color: var(--wb-color-text-primary);
  outline: none;
}
.wb-top-nav__utility-icon {
  display: inline-flex;
  flex: none;
}
.wb-top-nav__utility-arrow {
  transition: transform 160ms ease-out;
}
[aria-expanded='true'] > .wb-top-nav__utility-arrow {
  transform: rotate(180deg);
}
.wb-top-nav__business {
  position: relative;
  height: var(--wb-asset-wb-top-nav-business-height-compact);
  box-shadow: var(--wb-asset-wb-top-nav-business-separator-shadow);
  background: var(--wb-color-surface-overlay);
}
.wb-top-nav__business-grid {
  align-items: stretch;
}
.wb-top-nav__primary {
  min-width: 0;
  grid-column: 1;
  grid-row: 1;
  display: flex;
  align-items: stretch;
}
.wb-top-nav__brand {
  flex: none;
  display: flex;
  align-items: center;
}
.wb-top-nav__logo {
  width: var(--wb-asset-wb-top-nav-logo-width);
  height: var(--wb-icon-size-24);
  color: var(--wb-color-brand);
  fill: currentColor;
}
.wb-top-nav__divider {
  display: none;
  width: var(--wb-asset-wb-top-nav-divider-width);
  height: var(--wb-asset-wb-top-nav-brand-title-line-height);
  margin-left: var(--wb-spacing-component-lg);
  margin-right: var(--wb-asset-wb-top-nav-brand-divider-end-gap);
  background: var(--wb-color-border-separator);
}
.wb-top-nav__title {
  display: none;
  white-space: nowrap;
  font-family: inherit;
  font-size: var(--wb-font-headline-m-font-size);
  font-weight: var(--wb-font-headline-m-font-weight);
  line-height: var(--wb-asset-wb-top-nav-brand-title-line-height);
  letter-spacing: var(--wb-font-headline-m-letter-spacing);
}
.wb-top-nav__tabs {
  display: none;
  min-width: 0;
  margin-left: var(--wb-asset-wb-top-nav-brand-to-tabs-gap);
}
.wb-top-nav__tab-list {
  position: relative;
  height: 100%;
  display: flex;
  align-items: stretch;
  gap: var(--wb-spacing-layout-section-gap-large);
}
.wb-top-nav__tab-list :is(button, a) {
  position: relative;
  z-index: 1;
  flex: none;
  display: flex;
  align-items: center;
  padding: 0;
  border: 0;
  background: transparent;
  font-size: var(--wb-font-body-l-font-size);
  font-weight: var(--wb-font-body-l-font-weight);
  line-height: var(--wb-font-body-l-line-height);
  letter-spacing: var(--wb-font-body-l-letter-spacing);
  cursor: pointer;
  text-decoration: none;
}
.wb-top-nav__tab-list :is(button, a):hover,
.wb-top-nav__tab-list :is(button, a):focus-visible {
  color: var(--wb-color-brand);
  outline: none;
}
.wb-top-nav__indicator {
  position: absolute;
  z-index: 2;
  bottom: 0;
  left: 0;
  width: 0;
  height: var(--wb-asset-wb-top-nav-indicator-height);
  border-radius: var(--wb-radius-full);
  background: var(--wb-color-brand);
  transition:
    transform 200ms ease-out,
    width 200ms ease-out;
}
.wb-top-nav__mega-scrim {
  position: absolute;
  z-index: 2;
  top: 100%;
  left: 0;
  width: 100%;
  height: calc(
    100vh - var(--wb-asset-wb-top-nav-utility-height) - var(--wb-asset-wb-top-nav-business-height)
  );
  background: var(--wb-color-scrim-modal);
}
.wb-top-nav__mega-panel {
  position: absolute;
  z-index: 3;
  top: 100%;
  left: 0;
  width: 100%;
  display: grid;
  grid-template-rows: 1fr;
  overflow: hidden;
  border-block-end: var(--wb-asset-wb-top-nav-divider-width) solid
    var(--wb-color-border-separator-subtle);
  border-radius: 0;
  background: var(--wb-color-surface-overlay);
}
.wb-top-nav__mega-reveal-content {
  min-height: 0;
  overflow: hidden;
}
.wb-top-nav__grid.wb-top-nav__mega-grid {
  height: auto;
  align-items: start;
  padding-block: var(--wb-asset-wb-top-nav-mega-panel-padding-block);
  grid-template-columns: repeat(4, minmax(0, 1fr));
  column-gap: var(--wb-spacing-component-lg);
}
.wb-top-nav__mega-overview {
  grid-column: 1;
}
.wb-top-nav__mega-overview h2,
.wb-top-nav__mega-group h3 {
  margin: 0;
}
.wb-top-nav__mega-overview h2 {
  font-family: inherit;
  font-weight: var(--wb-font-display-s-font-weight);
  font-size: var(--wb-asset-wb-top-nav-mega-heading-font-size);
  line-height: var(--wb-asset-wb-top-nav-mega-heading-line-height);
  letter-spacing: var(--wb-font-display-s-letter-spacing);
}
.wb-top-nav__mega-overview :is(button, a) {
  margin-top: var(--wb-asset-wb-top-nav-mega-title-home-gap);
  display: flex;
  align-items: center;
  gap: var(--wb-spacing-component-xs);
  padding: 0;
  border: 0;
  color: var(--wb-color-text-primary);
  background: transparent;
  font-size: var(--wb-font-body-l-font-size);
  font-weight: var(--wb-font-body-l-font-weight);
  line-height: var(--wb-font-body-l-line-height);
  letter-spacing: var(--wb-font-body-l-letter-spacing);
  cursor: pointer;
  text-decoration: none;
}
.wb-top-nav__mega-overview :is(button, a):hover,
.wb-top-nav__mega-overview :is(button, a):focus-visible {
  color: var(--wb-color-text-primary);
  outline: none;
}
.wb-top-nav__mega-overview svg {
  width: var(--wb-icon-size-16);
  height: var(--wb-icon-size-16);
  fill: none;
  stroke: currentColor;
  stroke-width: 1.5;
  transition: transform 160ms ease-out;
}
.wb-top-nav__mega-overview :is(button, a):hover svg,
.wb-top-nav__mega-overview :is(button, a):focus-visible svg {
  transform: translateX(var(--wb-spacing-component-xs));
}
.wb-top-nav__mega-content {
  min-width: 0;
  grid-column: 2 / -1;
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  column-gap: var(--wb-spacing-component-lg);
  row-gap: var(--wb-asset-wb-top-nav-mega-row-gap);
}
.wb-top-nav__mega-group h3 {
  padding-inline: var(--wb-spacing-component-sm);
  font-family: inherit;
  font-size: var(--wb-font-headline-s-font-size);
  font-weight: var(--wb-font-headline-s-font-weight);
  line-height: var(--wb-font-headline-s-line-height);
  letter-spacing: var(--wb-font-headline-s-letter-spacing);
}
.wb-top-nav__mega-group nav {
  margin-top: calc(
    var(--wb-spacing-component-lg) -
      ((var(--wb-asset-wb-top-nav-mega-item-hit-height) - var(--wb-font-body-m-line-height)) / 2)
  );
  display: grid;
  gap: calc(
    var(--wb-spacing-component-md) -
      (var(--wb-asset-wb-top-nav-mega-item-hit-height) - var(--wb-font-body-m-line-height))
  );
}
.wb-top-nav__mega-group nav :is(button, a) {
  width: 100%;
  height: var(--wb-asset-wb-top-nav-mega-item-hit-height);
  box-sizing: border-box;
  display: flex;
  align-items: center;
  padding-inline: var(--wb-spacing-component-sm);
  border: 0;
  border-radius: var(--wb-radius-lg);
  color: var(--wb-color-text-secondary);
  background: transparent;
  text-align: left;
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
  cursor: pointer;
  text-decoration: none;
}
.wb-top-nav__mega-group nav :is(button, a) span {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.wb-top-nav__mega-group nav :is(button, a):hover,
.wb-top-nav__mega-group nav :is(button, a):focus-visible {
  color: var(--wb-color-text-secondary);
  background: var(--wb-color-fill-hover);
  outline: none;
}
.wb-top-nav-mega-reveal-enter-active,
.wb-top-nav-mega-reveal-leave-active {
  transition: grid-template-rows 240ms cubic-bezier(0.2, 0, 0.2, 1);
}
.wb-top-nav-mega-reveal-enter-from,
.wb-top-nav-mega-reveal-leave-to {
  grid-template-rows: 0fr;
}
.wb-top-nav-mega-scrim-enter-active {
  transition: opacity 160ms ease-out;
}
.wb-top-nav-mega-scrim-leave-active {
  transition: opacity 240ms linear;
}
.wb-top-nav-mega-scrim-enter-from,
.wb-top-nav-mega-scrim-leave-to {
  opacity: 0;
}
.wb-top-nav__more-wrap {
  position: relative;
  height: 100%;
  display: flex;
  align-items: stretch;
}
.wb-top-nav__more-trigger {
  display: flex;
  align-items: center;
  gap: var(--wb-spacing-component-xs);
}
.wb-top-nav__more-measure {
  display: inline-flex;
  align-items: center;
  gap: var(--wb-spacing-component-xs);
  font-size: var(--wb-font-body-l-font-size);
  font-weight: var(--wb-font-body-l-font-weight);
  line-height: var(--wb-font-body-l-line-height);
  letter-spacing: var(--wb-font-body-l-letter-spacing);
}
.wb-top-nav__more-panel {
  top: 100%;
  left: calc(0px - var(--wb-spacing-component-xs) - var(--wb-spacing-component-md));
  right: auto;
  width: var(--wb-asset-wb-top-nav-more-panel-width);
}
.wb-top-nav__tab-measurer {
  position: absolute;
  visibility: hidden;
  pointer-events: none;
  display: flex;
  gap: var(--wb-spacing-layout-section-gap-large);
  white-space: nowrap;
}
.wb-top-nav__actions {
  min-width: 0;
  grid-column: 1;
  grid-row: 1;
  justify-self: end;
  display: flex;
  align-items: center;
}
.wb-top-nav__business-grid > .wb-top-nav__primary {
  grid-column: 1 / -1;
  margin-inline-end: calc(var(--wb-top-nav-actions-width, 0px) + var(--wb-spacing-component-lg));
}
.wb-top-nav__business-grid > .wb-top-nav__actions {
  grid-column: 1 / -1;
}
.wb-top-nav__action {
  flex: none;
}
.wb-top-nav__site-panel {
  position: relative;
  z-index: 1;
  width: 100%;
  height: var(--wb-asset-wb-top-nav-site-panel-height);
  overflow: hidden;
  border-block-end: var(--wb-asset-wb-top-nav-divider-width) solid
    var(--wb-color-border-separator-subtle);
  background: var(--wb-color-surface-overlay);
  transform-origin: top;
}
.wb-top-nav-site-reveal-enter-active,
.wb-top-nav-site-reveal-leave-active {
  transition:
    height 240ms ease-out,
    opacity 180ms ease-out;
}
.wb-top-nav-site-reveal-enter-from,
.wb-top-nav-site-reveal-leave-to {
  height: 0;
  opacity: 0;
}
.wb-top-nav__site-grid {
  position: absolute;
  inset: 0;
  height: var(--wb-asset-wb-top-nav-site-panel-height);
  padding-block: var(--wb-asset-wb-top-nav-brand-title-line-height)
    var(--wb-spacing-layout-section-gap-large);
}
.wb-top-nav__site-current {
  grid-column: 1 / -1;
  display: flex;
  align-items: center;
  gap: var(--wb-spacing-component-sm);
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
}
.wb-top-nav__site-list {
  grid-column: 1 / -1;
  margin-top: var(--wb-asset-wb-top-nav-site-list-offset);
  display: grid;
  grid-template-columns: repeat(5, minmax(0, 1fr));
  gap: var(--wb-spacing-component-lg);
}
.wb-top-nav__site-list :is(button, a) {
  min-width: 0;
  width: 100%;
  height: var(--wb-asset-wb-top-nav-site-hover-height);
  display: grid;
  place-items: center;
  padding: 0;
  border: 0;
  border-radius: var(--wb-radius-lg);
  color: var(--wb-color-text-secondary);
  background: transparent;
  text-align: left;
  cursor: pointer;
  text-decoration: none;
}
.wb-top-nav__site-list :is(button, a):hover,
.wb-top-nav__site-list :is(button, a):focus-visible {
  background: var(--wb-color-fill-hover);
  outline: none;
}
.wb-top-nav__site-entry-content {
  width: min(100%, var(--wb-asset-wb-top-nav-site-entry-width));
  height: var(--wb-asset-wb-top-nav-site-entry-height);
  display: flex;
  align-items: center;
}
.wb-top-nav__site-icon {
  margin-right: var(--wb-spacing-component-md);
  flex: none;
  color: var(--wb-color-icon-secondary);
}
.wb-top-nav__site-label {
  margin-right: var(--wb-spacing-component-sm);
  white-space: nowrap;
}
.wb-top-nav__site-arrow {
  flex: none;
  color: var(--wb-color-icon-secondary);
}
.wb-top-nav__menu {
  position: absolute;
  z-index: 4;
  display: grid;
  gap: var(--wb-spacing-component-xs);
  padding: var(--wb-spacing-component-xs);
  border-radius: var(--wb-radius-md);
  background: var(--wb-color-surface-overlay);
  box-shadow: var(--wb-shadow-sm);
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
}
.wb-top-nav__menu :is(button, a) {
  min-width: 100%;
  height: var(--wb-asset-wb-top-nav-menu-item-height);
  padding: var(--wb-asset-wb-top-nav-menu-item-padding-block) var(--wb-spacing-component-md);
  display: flex;
  align-items: center;
  justify-content: space-between;
  border: 0;
  border-radius: var(--wb-radius-sm);
  background: transparent;
  text-align: left;
  white-space: nowrap;
  cursor: pointer;
  text-decoration: none;
}
.wb-top-nav__menu :is(button, a):hover,
.wb-top-nav__menu :is(button, a):focus-visible {
  background: var(--wb-color-fill-hover);
  outline: none;
}
.wb-top-nav__language-panel {
  top: var(--wb-top-nav-language-top);
  right: var(--wb-top-nav-language-right);
  width: var(--wb-asset-wb-top-nav-language-panel-width);
}
.wb-top-nav__checkmark {
  display: inline-flex;
}
.wb-top-nav__user-panel {
  top: var(--wb-top-nav-user-top);
  right: var(--wb-top-nav-user-right);
  width: var(--wb-asset-wb-top-nav-user-panel-width);
}
.wb-top-nav__mobile-panel {
  top: var(--wb-top-nav-mobile-top);
  right: var(--wb-top-nav-mobile-right);
  width: min(
    var(--wb-asset-wb-top-nav-mobile-panel-width),
    calc(100vw - var(--wb-spacing-screen-edge-compact) - var(--wb-spacing-screen-edge-compact))
  );
}
.wb-top-nav__mobile-title {
  min-height: var(--wb-asset-wb-top-nav-action-size);
  display: flex;
  align-items: center;
  gap: var(--wb-spacing-component-md);
  padding-inline: var(--wb-spacing-component-md);
  font-family: inherit;
  font-size: var(--wb-font-headline-m-font-size);
  font-weight: var(--wb-font-headline-m-font-weight);
  line-height: var(--wb-asset-wb-top-nav-brand-title-line-height);
  letter-spacing: var(--wb-font-headline-m-letter-spacing);
}
.wb-top-nav__mobile-current {
  max-width: 65%;
  overflow: hidden;
  color: var(--wb-color-text-secondary);
  text-overflow: ellipsis;
}
.wb-top-nav__mobile-back {
  justify-content: flex-start !important;
  color: var(--wb-color-text-secondary);
}
.wb-top-nav__mobile-panel hr {
  width: calc(100% - var(--wb-spacing-component-lg));
  height: var(--wb-asset-wb-top-nav-divider-width);
  margin: var(--wb-spacing-component-xs) var(--wb-spacing-component-sm);
  border: 0;
  background: var(--wb-color-border-separator-subtle);
}
@media (width < 1024px) {
  .wb-top-nav__utility {
    display: none;
  }
}
@media (width >= 768px) {
  .wb-top-nav__grid {
    padding-inline: var(--wb-spacing-screen-edge-expanded);
    grid-template-columns: repeat(var(--wb-layout-grid-columns-medium), minmax(0, 1fr));
  }
  .wb-top-nav__utility-grid > :first-child {
    grid-column: 1 / 6;
  }
  .wb-top-nav__utility-grid > :last-child {
    grid-column: 7 / 13;
  }
  .wb-top-nav__primary {
    grid-column: 1 / 4;
  }
  .wb-top-nav__actions {
    grid-column: 4 / 13;
  }
}
@media (width > 1024px) {
  .wb-top-nav__business {
    height: var(--wb-asset-wb-top-nav-business-height);
  }
  .wb-top-nav__primary {
    grid-column: 1 / 11;
  }
  .wb-top-nav__divider,
  .wb-top-nav__title,
  .wb-top-nav__tabs {
    display: flex;
  }
  .wb-top-nav__actions {
    grid-column: 11 / 13;
  }
}
@media (width > 1080px) {
  .wb-top-nav__grid.wb-top-nav__mega-grid {
    grid-template-columns: repeat(5, minmax(0, 1fr));
    column-gap: var(--wb-spacing-layout-section-gap-large);
  }
  .wb-top-nav__mega-content {
    grid-template-columns: repeat(4, minmax(0, 1fr));
    column-gap: var(--wb-spacing-layout-section-gap-large);
  }
}
@media (width >= 1280px) {
  .wb-top-nav__grid {
    grid-template-columns: repeat(var(--wb-layout-grid-columns-wide), minmax(0, 1fr));
  }
  .wb-top-nav__utility-grid > :first-child {
    grid-column: 1 / 9;
  }
  .wb-top-nav__utility-grid > :last-child {
    grid-column: 17 / 25;
  }
  .wb-top-nav__primary {
    grid-column: 1 / 21;
  }
  .wb-top-nav__actions {
    grid-column: 21 / 25;
  }
}
@media (width > 1920px) {
  .wb-top-nav__grid {
    max-width: var(--wb-asset-wb-top-nav-grid-max-width);
    padding-inline: 0;
  }
}
@media (width >= 1680px) {
  .wb-top-nav__site-current {
    width: var(--wb-asset-wb-top-nav-site-group-width);
    justify-self: center;
  }
  .wb-top-nav__site-list {
    width: var(--wb-asset-wb-top-nav-site-group-width);
    justify-self: center;
    grid-template-columns: repeat(5, var(--wb-asset-wb-top-nav-site-entry-width));
    column-gap: var(--wb-asset-wb-top-nav-site-entry-gap);
  }
  .wb-top-nav__site-list :is(button, a) {
    width: var(--wb-asset-wb-top-nav-site-hover-width);
    justify-self: center;
  }
}
.wb-top-nav__user-panel hr {
  width: calc(100% - var(--wb-spacing-component-lg));
  height: var(--wb-asset-wb-top-nav-divider-width);
  margin: var(--wb-spacing-component-xs) var(--wb-spacing-component-sm);
  border: 0;
  background: var(--wb-color-border-separator);
}
.wb-top-nav__menu .is-danger {
  color: var(--wb-color-error);
}
.wb-top-nav.is-portal .wb-top-nav__divider,
.wb-top-nav.is-portal .wb-top-nav__title {
  display: none;
}
.wb-top-nav__guest-panel {
  gap: var(--wb-spacing-component-sm);
  padding: var(--wb-spacing-component-md);
}
.wb-top-nav__guest-message {
  padding: var(--wb-spacing-component-sm);
  color: var(--wb-color-text-secondary);
  white-space: nowrap;
}
.wb-top-nav__menu .wb-top-nav__guest-login {
  justify-content: center;
  color: var(--wb-color-text-inverse);
  background: var(--wb-color-brand);
}
.wb-top-nav__menu .wb-top-nav__guest-login:hover,
.wb-top-nav__menu .wb-top-nav__guest-login:focus-visible {
  color: var(--wb-color-text-inverse);
  background: var(--wb-color-brand);
}
.wb-top-nav__guest-panel > button:last-child {
  justify-content: center;
  color: var(--wb-color-text-primary);
}
.sr-only {
  position: absolute;
  width: 0;
  height: 0;
  padding: 0;
  margin: 0;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
  border: 0;
}
@media (prefers-reduced-motion: reduce) {
  .wb-top-nav__indicator,
  .wb-top-nav__mega-overview svg,
  .wb-top-nav-mega-reveal-enter-active,
  .wb-top-nav-mega-reveal-leave-active,
  .wb-top-nav-mega-scrim-enter-active,
  .wb-top-nav-mega-scrim-leave-active {
    transition: none;
  }
}
</style>
