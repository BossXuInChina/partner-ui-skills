<script setup>
import { computed, useId } from 'vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import WorkbenchBadge from '../badge/WorkbenchBadge.vue';
import WorkbenchAvatar from '../avatar/WorkbenchAvatar.vue';
import TopNavDisclosureArrow from './TopNavDisclosureArrow.vue';

const props = defineProps({
  type: { type: String, required: true },
  label: { type: String, default: '' },
  badge: { type: [Number, String, Boolean], default: 0 },
  initial: { type: String, default: 'M' },
  avatarUrl: { type: String, default: '' },
  compact: { type: Boolean, default: false },
  disabled: { type: Boolean, default: false },
  expanded: { type: Boolean, default: undefined },
  pressed: { type: Boolean, default: undefined },
  controls: { type: String, default: undefined },
});
defineEmits(['click', 'keydown']);
const badgeDescriptionId = `wb-top-nav-action-${useId()}`;
const account = computed(() => ['certified', 'pending'].includes(props.type));
const labels = {
  search: '搜索',
  language: '切换语言',
  'login-register': '我的入口',
  certified: '我的入口',
  pending: '我的入口',
  favorite: '收藏',
  help: '帮助',
  message: '通知',
  assistant: '智能助手',
  menu: '打开业务导航',
  close: '关闭',
  login: '登录',
  register: '注册',
};
const accessibleLabel = computed(() => props.label || labels[props.type] || props.type);
const iconName = computed(() => {
  if (account.value && props.compact) return 'account';
  if (props.type === 'login-register') return 'account';
  if (props.type === 'menu' && props.expanded) return 'close';
  return props.type;
});
const iconSize = computed(() =>
  iconName.value === 'assistant' ? 32 : iconName.value === 'close' ? 18 : 20,
);
const badgeValue = computed(() => {
  const value =
    typeof props.badge === 'string'
      ? props.badge === '99+'
        ? 100
        : Number(props.badge)
      : props.badge;
  return Number.isInteger(value) ? value : undefined;
});
const showBadge = computed(() => props.badge === true || badgeValue.value > 0);
const badgeDescription = computed(() =>
  props.badge === true
    ? '有未读消息'
    : props.badge === '99+'
      ? '超过99条未读消息'
      : `${badgeValue.value}条未读消息`,
);
</script>

<template>
  <button
    class="wb-top-nav-action"
    :class="{
      'is-account': account && !compact,
      'is-pending': type === 'pending' && !compact,
      'is-primary': type === 'login',
      'is-text': type === 'register',
    }"
    :data-action-type="type"
    type="button"
    :disabled="disabled"
    :aria-label="accessibleLabel"
    :aria-describedby="showBadge ? badgeDescriptionId : undefined"
    :aria-expanded="expanded"
    :aria-haspopup="expanded !== undefined ? 'menu' : undefined"
    :aria-controls="controls"
    :aria-pressed="pressed"
    @click="$emit('click', $event)"
    @keydown="$emit('keydown', $event)"
  >
    <template v-if="account && !compact">
      <WorkbenchAvatar
        class="wb-top-nav__avatar"
        :size="24"
        :text="initial"
        :src="avatarUrl"
        aria-hidden="true"
      />
      <span
        v-if="type === 'pending'"
        class="wb-top-nav-action__pending-label"
        >待认证</span
      >
      <TopNavDisclosureArrow
        class="wb-top-nav-action__arrow"
        :name="`WB-TOP-NAV/action/${type === 'pending' ? 'pending-arrow' : 'account-arrow'}`"
        :size="type === 'pending' ? 14 : 12"
        :expanded="expanded"
      />
    </template>
    <span v-else-if="type === 'login' || type === 'register'">{{ labels[type] }}</span>
    <WorkbenchIcon
      v-else
      :class="{
        'wb-top-nav__user-icon': iconName === 'account',
        'wb-top-nav-action__language': iconName === 'language',
      }"
      :name="`WB-TOP-NAV/action/${iconName}`"
      :size="iconName === 'language' ? undefined : iconSize"
    />
    <WorkbenchBadge
      v-if="showBadge"
      class="wb-top-nav-action__badge"
      :variant="badge === true ? 'dot' : 'number'"
      :value="badgeValue"
      :aria-label="badgeDescription"
      placement="inline"
      aria-hidden="true"
    />
    <span
      v-if="showBadge"
      :id="badgeDescriptionId"
      class="wb-top-nav-action__sr-only"
      >{{ badgeDescription }}</span
    >
  </button>
</template>

<style scoped>
.wb-top-nav-action {
  /* Source SVG canvas 26.2539 × 20.2686; globe diameter 20, center 10.125/10.125.
     These intrinsic ratios preserve the approved asset, including the CN extension. */
  position: relative;
  box-sizing: border-box;
  width: var(--wb-asset-wb-top-nav-action-size);
  height: var(--wb-asset-wb-top-nav-action-size);
  display: inline-flex;
  flex: none;
  align-items: center;
  justify-content: center;
  gap: var(--wb-spacing-component-sm);
  padding: 0;
  border: 0;
  border-radius: var(--wb-radius-lg);
  background: transparent;
  color: var(--wb-color-text-primary);
  font: inherit;
  font-size: var(--wb-font-body-l-font-size);
  font-weight: var(--wb-font-body-l-font-weight);
  line-height: var(--wb-font-body-l-line-height);
  letter-spacing: var(--wb-font-body-l-letter-spacing);
  cursor: pointer;
}
.wb-top-nav-action__language {
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(
    calc(var(--wb-icon-size-20) * -0.50625),
    calc(var(--wb-icon-size-20) * -0.50625)
  );
}
.wb-top-nav-action:not(:disabled):is(
    :hover,
    :focus-visible,
    :active,
    [aria-expanded='true'],
    [aria-pressed='true']
  ) {
  background: var(--wb-color-fill-hover);
}
.wb-top-nav-action:focus-visible {
  outline: calc(var(--wb-asset-wb-top-nav-divider-width) * 2) solid var(--wb-color-border-focus);
  outline-offset: var(--wb-asset-wb-top-nav-divider-width);
}
.wb-top-nav-action:not(:disabled):active {
  box-shadow: inset 0 0 0 var(--wb-asset-wb-top-nav-divider-width)
    var(--wb-color-border-separator-subtle);
}
.wb-top-nav-action.is-account {
  width: auto;
  min-width: var(--wb-asset-wb-top-nav-user-entry-width);
  padding-inline: calc(
    (
        var(--wb-asset-wb-top-nav-user-entry-width) - var(--wb-asset-wb-top-nav-avatar-size) -
          var(--wb-spacing-component-sm) - var(--wb-icon-size-12)
      ) /
      2
  );
}
.wb-top-nav-action__pending-label {
  color: var(--wb-color-brand);
  white-space: nowrap;
}
.wb-top-nav-action.is-text {
  width: auto;
  padding-inline: var(--wb-spacing-component-md);
}
.wb-top-nav-action.is-primary {
  width: auto;
  min-width: calc(var(--wb-icon-size-12) * 6);
  padding-inline: var(--wb-icon-size-20);
  margin-inline-start: calc(
    var(--wb-spacing-component-sm) + var(--wb-asset-wb-top-nav-divider-width) * 2
  );
  border-radius: var(--wb-radius-md);
  background: var(--wb-color-brand);
  color: var(--wb-color-text-inverse);
}
.wb-top-nav-action.is-primary:not(:disabled):is(:hover, :focus-visible) {
  background: var(--wb-color-brand-hover);
}
.wb-top-nav-action.is-primary:not(:disabled):active {
  background: var(--wb-color-brand);
}
.wb-top-nav-action:disabled {
  color: var(--wb-color-icon-disabled);
  cursor: not-allowed;
}
.wb-top-nav-action.is-primary:disabled {
  background: var(--wb-color-brand-disabled);
  color: var(--wb-color-text-inverse);
}
.wb-top-nav-action:disabled :is(.wb-top-nav__avatar, .wb-top-nav-action__badge) {
  opacity: 0.5;
}
.wb-top-nav-action:disabled[data-action-type='assistant'] > .workbench-icon {
  opacity: 0.5;
}
.wb-top-nav-action:disabled .wb-top-nav-action__pending-label {
  color: inherit;
}
.wb-top-nav-action__badge {
  position: absolute;
  top: calc(var(--wb-spacing-component-xs) / 2);
  right: calc(var(--wb-spacing-component-xs) / 2);
}
.wb-top-nav-action__sr-only {
  position: absolute;
  width: 0;
  height: 0;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
</style>
