<script setup>
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';

defineProps({
  name: { type: String, default: 'WB-TOP-NAV/action/account-arrow' },
  size: { type: Number, default: 12 },
  expanded: { type: Boolean, default: false },
});
</script>

<template>
  <WorkbenchIcon
    class="wb-top-nav-disclosure-arrow"
    :class="{ 'is-expanded': expanded }"
    :name="name"
    :size="size"
  />
</template>

<style scoped>
.wb-top-nav-disclosure-arrow { transition: transform 160ms ease-out; }
.wb-top-nav-disclosure-arrow.is-expanded { transform: rotate(180deg); }
@media (prefers-reduced-motion: reduce) {
  .wb-top-nav-disclosure-arrow { transition: none; }
}
</style>
