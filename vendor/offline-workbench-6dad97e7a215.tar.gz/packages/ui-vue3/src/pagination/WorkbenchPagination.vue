<script setup>
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import WorkbenchSelect from '../select/WorkbenchSelect.vue';
import '../shared/disclosure-motion.css';
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import { computed, nextTick, onBeforeUnmount, onMounted, ref, useId, watch } from 'vue';

const props = defineProps({
  variant: {
    type: String,
    default: 'default',
    validator: (value) => ['default', 'full', 'simple'].includes(value),
  },
  total: { type: Number, required: true },
  modelValue: { type: Number, default: 1 },
  pageSize: { type: Number, default: 10 },
  pageSizeOptions: { type: Array, default: () => [10, 20, 50, 100] },
  middlePageCount: {
    type: Number,
    default: 3,
    validator: (value) => Number.isInteger(value) && value > 0,
  },
  simpleMode: {
    type: String,
    default: 'click',
    validator: (value) => ['click', 'select', 'input'].includes(value),
  },
  simpleEditable: { type: Boolean, default: false },
  disabled: { type: Boolean, default: false },
  ariaLabel: { type: String, default: '分页' },
});
const emit = defineEmits(['update:modelValue', 'update:pageSize', 'change', 'page-size-change']);

const sizeMenuId = `wb-pagination-${useId()}-size-menu`;
const validPageSizes = computed(() => [
  ...new Set(props.pageSizeOptions.filter((value) => Number.isInteger(value) && value > 0)),
]);
const hasData = computed(() => Number.isFinite(props.total) && props.total > 0);
const safePageSize = computed(() =>
  Number.isInteger(props.pageSize) && props.pageSize > 0 ? props.pageSize : 10,
);
const totalPages = computed(() =>
  hasData.value ? Math.max(1, Math.ceil(props.total / safePageSize.value)) : 1,
);
const currentPage = computed(() =>
  Math.min(totalPages.value, Math.max(1, Math.floor(Number(props.modelValue) || 1))),
);
const interactionDisabled = computed(() => props.disabled || !hasData.value);
const resolvedMiddlePageCount = computed(() =>
  Number.isInteger(props.middlePageCount) && props.middlePageCount > 0 ? props.middlePageCount : 3,
);
const resolvedSimpleMode = computed(() => (props.simpleEditable ? 'input' : props.simpleMode));
const jumpValue = ref(String(currentPage.value));
const sizeRoot = ref(null);
const sizeTrigger = ref(null);
const sizeMenu = ref(null);
const sizeExpanded = ref(false);

const pageItems = computed(() => {
  const count = totalPages.value;
  const current = currentPage.value;
  const middleCount = Math.min(resolvedMiddlePageCount.value, Math.max(1, count - 2));
  const edgePageCount = middleCount + 2;
  if (count <= middleCount + 4) return Array.from({ length: count }, (_, index) => index + 1);
  if (current <= middleCount + 1)
    return [
      ...Array.from({ length: edgePageCount }, (_, index) => index + 1),
      'ellipsis-end',
      count,
    ];
  if (current >= count - middleCount - 1)
    return [
      1,
      'ellipsis-start',
      ...Array.from({ length: edgePageCount }, (_, index) => count - edgePageCount + index + 1),
    ];
  const middleStart = current - Math.floor((middleCount - 1) / 2);
  return [
    1,
    'ellipsis-start',
    ...Array.from({ length: middleCount }, (_, index) => middleStart + index),
    'ellipsis-end',
    count,
  ];
});
const simplePageOptions = computed(() =>
  Array.from({ length: totalPages.value }, (_, index) => {
    const page = index + 1;
    return { value: page, label: `${page}/${totalPages.value}` };
  }),
);

watch(currentPage, (value) => {
  jumpValue.value = String(value);
});
watch(interactionDisabled, (disabled) => {
  if (disabled) sizeExpanded.value = false;
});
watch([() => props.modelValue, totalPages], () => {
  const requested = Math.floor(Number(props.modelValue) || 1);
  if (requested !== currentPage.value) emitPage(currentPage.value);
});

function emitPage(page) {
  if (page === currentPage.value && Number(props.modelValue) === page) return;
  emit('update:modelValue', page);
  emit('change', page);
  jumpValue.value = String(page);
}

function goTo(page) {
  if (interactionDisabled.value) return;
  const next = Math.min(totalPages.value, Math.max(1, Math.floor(Number(page) || 1)));
  emitPage(next);
}

function selectSimplePage(selection) {
  const [page] = Array.isArray(selection) ? selection : [];
  if (Number.isInteger(page)) goTo(page);
}

function onJumpInput(event) {
  jumpValue.value = event.target.value.replace(/[^0-9]/g, '');
  if (event.target.value !== jumpValue.value) event.target.value = jumpValue.value;
}

function commitJump() {
  if (interactionDisabled.value) return;
  if (!jumpValue.value) {
    jumpValue.value = String(currentPage.value);
    return;
  }
  const next = Math.min(totalPages.value, Math.max(1, Number.parseInt(jumpValue.value, 10)));
  jumpValue.value = String(next);
  goTo(next);
}

function changePageSize(nextSize) {
  if (interactionDisabled.value) return;
  nextSize = Number(nextSize);
  if (!Number.isInteger(nextSize) || nextSize <= 0 || nextSize === props.pageSize) return;
  emit('update:pageSize', nextSize);
  emit('page-size-change', nextSize);
  if (currentPage.value !== 1 || Number(props.modelValue) !== 1) emitPage(1);
}

function togglePageSize() {
  if (interactionDisabled.value) return;
  sizeExpanded.value = !sizeExpanded.value;
  if (sizeExpanded.value)
    nextTick(() => sizeMenu.value?.querySelector('[role="menuitemradio"]')?.focus());
}

function choosePageSize(option) {
  changePageSize(option);
  sizeExpanded.value = false;
  nextTick(() => sizeTrigger.value?.focus());
}

function onSizeKeydown(event) {
  if (event.key === 'Escape') {
    event.preventDefault();
    event.stopPropagation();
    sizeExpanded.value = false;
    nextTick(() => sizeTrigger.value?.focus());
    return;
  }
  if (!['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) return;
  event.preventDefault();
  if (!sizeExpanded.value) {
    sizeExpanded.value = true;
    nextTick(() => sizeMenu.value?.querySelector('[role="menuitemradio"]')?.focus());
    return;
  }
  const options = [...sizeMenu.value.querySelectorAll('[role="menuitemradio"]')];
  const currentIndex = options.indexOf(document.activeElement);
  const nextIndex =
    event.key === 'Home'
      ? 0
      : event.key === 'End'
        ? options.length - 1
        : event.key === 'ArrowDown'
          ? (currentIndex + 1) % options.length
          : (currentIndex - 1 + options.length) % options.length;
  options[nextIndex]?.focus();
}

function dismissPageSizeFocus(event) {
  if (
    !sizeRoot.value?.contains(event.relatedTarget) &&
    !sizeMenu.value?.contains(event.relatedTarget)
  )
    sizeExpanded.value = false;
}

function dismissPageSize(event) {
  if (!sizeRoot.value?.contains(event.target) && !sizeMenu.value?.contains(event.target))
    sizeExpanded.value = false;
}

function positionSizeLayer(menu) {
  menu.style.removeProperty('z-index');
  let layer = Number(getComputedStyle(menu).zIndex) || 0;
  for (
    let node = sizeTrigger.value.parentElement;
    node && node !== document.body;
    node = node.parentElement
  ) {
    const style = getComputedStyle(node);
    const positioned =
      style.position !== 'static' || /flex|grid/.test(getComputedStyle(node.parentElement).display);
    if (positioned && style.zIndex !== 'auto') layer = Math.max(layer, Number(style.zIndex) + 1);
  }
  menu.style.zIndex = String(layer);
}
function positionSizeMenu() {
  if (!sizeExpanded.value || !sizeMenu.value || !sizeTrigger.value) return;
  const rect = sizeTrigger.value.getBoundingClientRect();
  const menu = sizeMenu.value;
  const style = getComputedStyle(sizeRoot.value);
  positionSizeLayer(menu);
  for (const name of style)
    if (name.startsWith('--wb-')) menu.style.setProperty(name, style.getPropertyValue(name));
  menu.style.fontFamily = style.fontFamily;
  const gap = parseFloat(style.getPropertyValue('--wb-spacing-component-xs')) || 4;
  menu.style.width = `${rect.width}px`;
  const height = menu.scrollHeight;
  const above = Math.max(0, rect.top - gap * 2);
  const below = Math.max(0, innerHeight - rect.bottom - gap * 2);
  const top = above >= height || above >= below;
  const available = top ? above : below;
  menu.style.maxHeight = `${available}px`;
  const box = menu.getBoundingClientRect();
  menu.style.left = `${Math.max(gap, Math.min(rect.left, innerWidth - box.width - gap))}px`;
  menu.style.top = `${top ? rect.top - gap - box.height : rect.bottom + gap}px`;
  menu.dataset.placement = top ? 'top' : 'bottom';
}
watch(sizeExpanded, (value) => {
  if (value) nextTick(positionSizeMenu);
});
onMounted(() => {
  document.addEventListener('pointerdown', dismissPageSize);
  window.addEventListener('resize', positionSizeMenu);
  window.addEventListener('scroll', positionSizeMenu, true);
});
onBeforeUnmount(() => {
  document.removeEventListener('pointerdown', dismissPageSize);
  window.removeEventListener('resize', positionSizeMenu);
  window.removeEventListener('scroll', positionSizeMenu, true);
});
</script>

<template>
  <nav
    class="wb-pagination"
    :class="`wb-pagination--${variant}`"
    :aria-label="ariaLabel"
  >
    <div
      v-if="variant === 'full'"
      ref="sizeRoot"
      class="wb-pagination__size"
      @keydown="onSizeKeydown"
      @focusout="dismissPageSizeFocus"
    >
      <button
        ref="sizeTrigger"
        type="button"
        class="wb-pagination__size-trigger"
        :disabled="interactionDisabled"
        aria-label="每页显示数量"
        aria-haspopup="menu"
        :aria-expanded="sizeExpanded"
        :aria-controls="sizeExpanded ? sizeMenuId : undefined"
        @click="togglePageSize"
      >
        <span>{{ safePageSize }} 条/页</span>
        <span
          class="wb-pagination__size-arrow-frame"
          aria-hidden="true"
        >
          <WorkbenchIcon
            class="wb-pagination__size-arrow wb-disclosure-icon"
            :class="{ 'is-expanded': sizeExpanded }"
            name="箭头/尺寸=10, 方向=下箭头"
            :size="10"
          />
        </span>
      </button>
      <Teleport to="body">
        <div
          v-if="sizeExpanded"
          ref="sizeMenu"
          :id="sizeMenuId"
          @keydown="onSizeKeydown"
          @focusout="dismissPageSizeFocus"
          class="wb-pagination__size-menu"
          role="menu"
          aria-label="每页显示数量选项"
        >
          <button
            v-for="option in validPageSizes"
            :key="option"
            type="button"
            role="menuitemradio"
            :aria-checked="option === safePageSize"
            :class="{ 'is-selected': option === safePageSize }"
            @click="choosePageSize(option)"
          >
            <span
              class="wb-pagination__size-option-label"
              :title="`${option} 条/页`"
              >{{ option }} 条/页</span
            ><span
              v-if="option === safePageSize"
              class="wb-pagination__selected-mark-slot"
              aria-hidden="true"
              ><WorkbenchIcon
                name="完成/尺寸=14"
                :size="14"
            /></span>
          </button>
        </div>
      </Teleport>
    </div>

    <button
      class="wb-pagination__button wb-pagination__arrow"
      type="button"
      aria-label="上一页"
      :disabled="interactionDisabled || currentPage <= 1"
      @click="goTo(currentPage - 1)"
    >
      <WorkbenchIcon
        name="/ic_arrow_left_line#2:144"
        :size="10"
      />
    </button>

    <span
      v-if="variant === 'simple'"
      class="wb-pagination__summary"
      aria-live="polite"
    >
      <span
        v-if="resolvedSimpleMode === 'select'"
        class="wb-pagination__summary-select"
      >
        <WorkbenchSelect
          :model-value="[currentPage]"
          :options="simplePageOptions"
          :label="`当前页，第 ${currentPage} 页，共 ${totalPages} 页`"
          :state="interactionDisabled ? 'disabled' : 'default'"
          class="wb-pagination__page-select"
          @update:model-value="selectSimplePage"
        />
      </span>
      <template v-else>
        <span
          v-if="resolvedSimpleMode === 'input'"
          class="wb-pagination__summary-input"
        >
          <input
            :value="jumpValue"
            :disabled="interactionDisabled"
            inputmode="numeric"
            autocomplete="off"
            aria-label="当前页码"
            @input="onJumpInput"
            @keydown.enter.prevent="commitJump"
            @blur="jumpValue = String(currentPage)"
          />
        </span>
        <span v-else>{{ currentPage }}</span>
        <span aria-hidden="true">/</span>
        <span :aria-label="`共 ${totalPages} 页`">{{ totalPages }}</span>
      </template>
    </span>
    <div
      v-else
      class="wb-pagination__pages"
      aria-label="页码"
    >
      <template
        v-for="item in pageItems"
        :key="item"
      >
        <button
          v-if="typeof item === 'string'"
          class="wb-pagination__button wb-pagination__ellipsis"
          type="button"
          :aria-label="`向${item === 'ellipsis-start' ? '前' : '后'}跳转${resolvedMiddlePageCount}页`"
          :disabled="interactionDisabled"
          @click="
            goTo(
              currentPage +
                (item === 'ellipsis-start' ? -resolvedMiddlePageCount : resolvedMiddlePageCount),
            )
          "
        >
          <WorkbenchIcon
            class="wb-pagination__ellipsis-more"
            name="更多_20px"
          />
          <WorkbenchIcon
            class="wb-pagination__ellipsis-jump"
            :name="item === 'ellipsis-start' ? '双箭头/大小=10,方向=左' : '双箭头/大小=10,方向=右'"
            :size="10"
          />
        </button>
        <button
          v-else
          class="wb-pagination__button wb-pagination__page"
          :class="{ 'is-current': item === currentPage }"
          type="button"
          :aria-label="`第 ${item} 页`"
          :aria-current="item === currentPage ? 'page' : undefined"
          :disabled="interactionDisabled"
          @click="goTo(item)"
        >
          {{ item }}
        </button>
      </template>
    </div>

    <button
      class="wb-pagination__button wb-pagination__arrow"
      type="button"
      aria-label="下一页"
      :disabled="interactionDisabled || currentPage >= totalPages"
      @click="goTo(currentPage + 1)"
    >
      <WorkbenchIcon
        name="/ic_arrow_right_line#2:141"
        :size="10"
      />
    </button>

    <div
      v-if="variant !== 'simple'"
      class="wb-pagination__jump"
      role="group"
      aria-label="页码跳转"
    >
      <span class="wb-pagination__jump-input">
        <input
          :value="jumpValue"
          :disabled="interactionDisabled"
          inputmode="numeric"
          autocomplete="off"
          aria-label="跳转页码"
          @input="onJumpInput"
          @keydown.enter.prevent="commitJump"
          @blur="commitJump"
        />
      </span>
      <button
        type="button"
        :disabled="interactionDisabled"
        aria-label="跳转到输入页码"
        @click="commitJump"
      >
        跳转
      </button>
    </div>
  </nav>
</template>

<style scoped>
.wb-pagination {
  display: flex;
  align-items: center;
  gap: var(--wb-spacing-component-sm);
  color: var(--wb-color-text-primary);
  font-size: var(--wb-font-body-m-font-size);
  font-weight: var(--wb-font-body-m-font-weight);
  line-height: var(--wb-font-body-m-line-height);
  letter-spacing: var(--wb-font-body-m-letter-spacing);
}
.wb-pagination__pages {
  display: flex;
  align-items: center;
  gap: var(--wb-spacing-component-sm);
}
.wb-pagination__button,
.wb-pagination__ellipsis {
  box-sizing: border-box;
  display: inline-flex;
  width: var(--wb-asset-wb-pagination-page-button-width);
  height: var(--wb-asset-wb-pagination-control-height);
  flex: none;
  align-items: center;
  justify-content: center;
}
.wb-pagination__button {
  padding: 0;
  border: var(--wb-asset-wb-pagination-border-width) solid transparent;
  border-radius: var(--wb-radius-sm);
  background: transparent;
  color: inherit;
  font: inherit;
  cursor: pointer;
}
.wb-pagination__button:hover:not(:disabled) {
  background: var(--wb-color-fill-hover);
}
.wb-pagination__button:focus-visible,
.wb-pagination__size-trigger:focus-visible,
.wb-pagination__size-menu button:focus-visible {
  outline: var(--wb-asset-wb-pagination-border-width) solid var(--wb-color-border-focus);
  outline-offset: var(--wb-spacing-component-xs);
}
.wb-pagination__page.is-current,
.wb-pagination__page:active:not(:disabled) {
  border-color: var(--wb-color-border-focus);
  background: var(--wb-color-surface-card-default);
  color: var(--wb-color-text-primary);
}
.wb-pagination__arrow:active:not(:disabled) {
  border-color: var(--wb-color-border-focus);
  background: var(--wb-color-surface-card-default);
}
.wb-pagination__button:disabled {
  color: var(--wb-color-text-disabled);
  cursor: not-allowed;
}
.wb-pagination__arrow {
  width: var(--wb-asset-wb-pagination-arrow-button-size);
  height: var(--wb-asset-wb-pagination-arrow-button-size);
}
.wb-pagination__ellipsis {
  color: var(--wb-color-text-secondary);
}
.wb-pagination__ellipsis:hover:not(:disabled),
.wb-pagination__ellipsis:focus-visible:not(:disabled) {
  color: var(--wb-color-text-primary);
}
.wb-pagination__ellipsis-jump {
  display: none;
}
.wb-pagination__ellipsis:hover:not(:disabled) .wb-pagination__ellipsis-more,
.wb-pagination__ellipsis:focus-visible:not(:disabled) .wb-pagination__ellipsis-more {
  display: none;
}
.wb-pagination__ellipsis:hover:not(:disabled) .wb-pagination__ellipsis-jump,
.wb-pagination__ellipsis:focus-visible:not(:disabled) .wb-pagination__ellipsis-jump {
  display: inline-flex;
}
.wb-pagination__size,
.wb-pagination__jump {
  display: inline-flex;
  align-items: center;
  white-space: nowrap;
}
.wb-pagination__size {
  position: relative;
}
.wb-pagination__size-arrow-frame {
  display: inline-grid;
  width: var(--wb-asset-wb-pagination-dropdown-arrow-size);
  height: var(--wb-asset-wb-pagination-dropdown-arrow-size);
  flex: none;
  place-items: center;
}
.wb-pagination__size-arrow {
  color: var(--wb-color-text-secondary);
}
.wb-pagination__size-trigger[aria-expanded='true'] .wb-pagination__size-arrow {
  color: var(--wb-color-icon-active);
}
.wb-pagination__size-trigger:disabled .wb-pagination__size-arrow {
  color: var(--wb-color-icon-disabled);
}
.wb-pagination__size-trigger,
.wb-pagination__jump-input,
.wb-pagination__jump button {
  box-sizing: border-box;
  height: var(--wb-asset-wb-pagination-control-height);
  border: var(--wb-asset-wb-pagination-border-width) solid var(--wb-color-border);
  border-radius: var(--wb-radius-sm);
  background: var(--wb-color-surface-overlay);
  color: inherit;
  font: inherit;
}
.wb-pagination__size-trigger {
  display: inline-flex;
  width: max-content;
  align-items: center;
  justify-content: flex-start;
  gap: var(--wb-spacing-component-sm);
  padding-inline: calc(var(--wb-spacing-component-md) - var(--wb-asset-wb-pagination-border-width));
  cursor: pointer;
}
.wb-pagination__size-trigger:hover:not(:disabled) {
  border-color: var(--wb-color-border-hover);
}
.wb-pagination__summary-select {
  position: relative;
  display: inline-flex;
}
.wb-pagination__size-menu {
  position: fixed;
  z-index: 10;
  overflow-y: auto;
  display: grid;
  gap: var(--wb-spacing-component-xs);
  width: max-content;
  box-sizing: border-box;
  padding: var(--wb-spacing-component-xs);
  border-radius: var(--wb-radius-sm);
  background: var(--wb-color-surface-overlay);
  box-shadow: var(--wb-shadow-sm);
}
.wb-pagination__size-menu button {
  min-width: 0;
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--wb-spacing-component-xs);
  height: var(--wb-asset-wb-pagination-control-height);
  padding: var(--wb-spacing-component-xs) var(--wb-spacing-component-sm);
  border: 0;
  border-radius: var(--wb-radius-sm);
  background: transparent;
  color: inherit;
  font: inherit;
  text-align: start;
  cursor: pointer;
}
.wb-pagination__size-menu button:hover,
.wb-pagination__size-menu button:focus-visible {
  background: var(--wb-color-fill-hover);
}
.wb-pagination__size-option-label {
  min-width: 0;
  flex: 1;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.wb-pagination__selected-mark-slot {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: var(--wb-asset-wb-select-selected-mark-size);
  height: var(--wb-asset-wb-select-selected-mark-size);
  flex: none;
}
.wb-pagination__jump-input {
  display: inline-flex;
  width: var(--wb-asset-wb-pagination-jump-input-width);
  align-items: center;
  padding-inline: var(--wb-spacing-component-sm);
  border-start-end-radius: 0;
  border-end-end-radius: 0;
}
.wb-pagination__jump-input:focus-within {
  border-color: var(--wb-color-border-focus);
}
.wb-pagination__jump-input input {
  appearance: none;
  width: 100%;
  min-width: 0;
  padding: 0;
  border: 0;
  outline: 0;
  background: transparent;
  color: inherit;
  font: inherit;
  text-align: center;
}
.wb-pagination__jump button {
  appearance: none;
  width: var(--wb-asset-wb-pagination-jump-button-width);
  padding: 0;
  border-inline-start: 0;
  border-start-start-radius: 0;
  border-end-start-radius: 0;
  cursor: pointer;
}
.wb-pagination__jump button:focus-visible {
  border-color: var(--wb-color-border-focus);
  outline: 0;
}
.wb-pagination__jump button:hover:not(:disabled) {
  background: var(--wb-color-fill-hover);
}
.wb-pagination__size-trigger:disabled,
.wb-pagination__jump-input:has(input:disabled),
.wb-pagination__jump button:disabled {
  color: var(--wb-color-text-disabled);
  cursor: not-allowed;
}
.wb-pagination__summary {
  display: inline-flex;
  width: max-content;
  align-items: center;
  gap: var(--wb-spacing-component-sm);
  text-align: center;
  white-space: nowrap;
}
.wb-pagination__summary-input {
  box-sizing: border-box;
  display: inline-flex;
  width: var(--wb-asset-wb-pagination-page-button-width);
  height: var(--wb-asset-wb-pagination-control-height);
  align-items: center;
  padding-inline: var(--wb-spacing-component-xs);
  border: var(--wb-asset-wb-pagination-border-width) solid var(--wb-color-border);
  border-radius: var(--wb-radius-sm);
  background: var(--wb-color-fill-subtle-default);
}
.wb-pagination__summary-input:focus-within {
  border-color: var(--wb-color-border-focus);
}
.wb-pagination__summary-input input {
  appearance: none;
  width: 100%;
  min-width: 0;
  padding: 0;
  border: 0;
  outline: 0;
  background: transparent;
  color: inherit;
  font: inherit;
  text-align: center;
}
.wb-pagination__summary-input:has(input:disabled) {
  border-color: var(--wb-color-border-disabled);
  background: transparent;
  color: var(--wb-color-text-disabled);
  cursor: not-allowed;
}
.wb-pagination__page-select {
  --select-field-width: var(--wb-asset-wb-pagination-simple-select-width);
}
</style>
