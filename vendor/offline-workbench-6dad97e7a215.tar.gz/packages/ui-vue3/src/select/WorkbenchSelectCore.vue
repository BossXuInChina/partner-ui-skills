<script setup>
import { useFormDisabled } from '../form/useFormDisabled.js';
import '../shared/disclosure-motion.css';
import { useFieldControl, descriptionIds } from '../form/fieldContext.js';
import '../../../../catalog/generated/asset.tokens.css';
import ChoiceMark from '../choice/ChoiceMark.vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import '../tag/tag-surface.css';
import WorkbenchTooltip from '../tooltip/WorkbenchTooltip.vue';
import {
  computed,
  ref,
  watch,
  nextTick,
  onMounted,
  onBeforeUnmount,
  useId,
  getCurrentInstance,
} from 'vue';
const props = defineProps({
  modelValue: { type: Array, default: () => [] },
  defaultValue: { type: Array, default: () => [] },
  multiple: Boolean,
  searchable: Boolean,
  clearable: Boolean,
  searchPlaceholder: { type: String, default: '搜索选项' },
  placeholder: { type: String, default: '请选择' },
  label: String,
  required: Boolean,
  state: { type: String, default: 'default' },
  showPanel: Boolean,
  options: { type: Array, required: true },
  teleportPanel: Boolean,
  panelClass: { type: String, default: '' },
});
const emit = defineEmits(['update:modelValue', 'clear']);
const id = useId();
const instance = getCurrentInstance();
const root = ref(null);
const trigger = ref(null);
const {
  field,
  attrs: fieldAttrs,
  required: controlRequired,
} = useFieldControl(() => props.modelValue, {
  required: () => props.required,
  focus: () => trigger.value?.focus(),
  containsFocus: (node) => withinSelect(node),
});
const panel = ref(null);
const searchInput = ref(null);
const values = ref(null);
const open = ref(false);
const automaticPortal = ref(false);
const portalled = computed(() => props.teleportPanel || automaticPortal.value);
const focused = ref(false);
const overflowHovered = ref(false);
const valuesWidth = ref(0);
const searchQuery = ref('');
const overflowAnchor = ref(null);
const overflowTooltip = ref(null);
const tagMeasure = ref(null);
const tagMetrics = ref({
  font: '',
  padding: 0,
  gap: 0,
  letterSpacing: 0,
  thumbnailSize: 0,
  thumbnailGap: 0,
});
const disabled = useFormDisabled(() => props.state === 'disabled');
const expanded = computed(() => !disabled.value && (props.showPanel || open.value));
const selected = computed(() =>
  props.options.filter((option) => props.modelValue.includes(option.value)),
);
const filteredOptions = computed(() => {
  const query = searchQuery.value.trim().toLocaleLowerCase();
  return query
    ? props.options.filter((option) => option.label.toLocaleLowerCase().includes(query))
    : props.options;
});
const groupedOptions = computed(() => {
  const groups = [];
  const index = new Map();
  filteredOptions.value.forEach((option) => {
    const label = option.group || '';
    if (!index.has(label)) {
      index.set(label, groups.length);
      groups.push({ label, options: [] });
    }
    groups[index.get(label)].options.push(option);
  });
  return groups;
});
const hasGroups = computed(() => props.options.some((option) => option.group));
function displayedLabel(label) {
  const characters = Array.from(label);
  return characters.length > 7 ? `${characters.slice(0, 7).join('')}…` : label;
}
function textWidth(text) {
  const canvas = document.createElement('canvas');
  const context = canvas.getContext('2d');
  const metrics = tagMetrics.value;
  context.font = metrics.font;
  return Math.ceil(
    context.measureText(text).width +
      Array.from(text).length * metrics.letterSpacing +
      metrics.padding,
  );
}
function tagWidth(option) {
  return (
    textWidth(displayedLabel(option.label)) +
    (option.thumbnail ? tagMetrics.value.thumbnailSize + tagMetrics.value.thumbnailGap : 0)
  );
}
const visibleTags = computed(() => {
  if (!props.multiple || !valuesWidth.value) return selected.value;
  const tags = selected.value;
  const gap = tagMetrics.value.gap;
  const totalWidth = (count, hidden) =>
    tags.slice(0, count).reduce((sum, option) => sum + tagWidth(option), 0) +
    Math.max(0, count - 1) * gap +
    (hidden ? (count ? gap : 0) + textWidth(`+${hidden}`) : 0);
  if (totalWidth(tags.length, 0) <= valuesWidth.value) return tags;
  for (let count = tags.length - 1; count >= 0; count -= 1)
    if (totalWidth(count, tags.length - count) <= valuesWidth.value) return tags.slice(0, count);
  return [];
});
const hiddenTagCount = computed(() => selected.value.length - visibleTags.value.length);
const hiddenTags = computed(() => selected.value.slice(visibleTags.value.length));
const overflowTipVisible = computed(
  () => hiddenTagCount.value > 0 && overflowHovered.value && !expanded.value,
);
function positionOverflowTooltip() {
  if (!root.value || !overflowAnchor.value || !overflowTooltip.value) return;
  const anchor = overflowAnchor.value.getBoundingClientRect();
  const bounds = root.value.getBoundingClientRect();
  const scale = bounds.width / root.value.offsetWidth || 1;
  overflowTooltip.value.style.setProperty(
    '--select-overflow-center',
    `${(anchor.left + anchor.width / 2 - bounds.left) / scale}px`,
  );
  const tooltip = overflowTooltip.value;
  // Measure the occupied rows at the available width, then remove the unused
  // trailing space. Reset first so later content/size changes can grow again.
  tooltip.style.removeProperty('--select-overflow-width');
  const tipBounds = tooltip.getBoundingClientRect();
  const tags = [...tooltip.children].filter((child) => child.classList.contains('wb-select__tag'));
  if (tags.length) {
    const right = Math.max(...tags.map((tag) => tag.getBoundingClientRect().right));
    const padding = parseFloat(getComputedStyle(tooltip).paddingRight);
    tooltip.style.setProperty(
      '--select-overflow-width',
      `${Math.ceil((right - tipBounds.left) / scale + padding)}px`,
    );
  }
}
watch([overflowTipVisible, hiddenTagCount, valuesWidth, selected], () =>
  nextTick(positionOverflowTooltip),
);
watch(
  [() => props.showPanel, disabled],
  () => {
    open.value = props.showPanel && !disabled.value;
  },
  { immediate: true },
);
function panelOptions() {
  return [...(panel.value?.querySelectorAll('[role="option"]') || [])].filter(
    (node) => !node.disabled,
  );
}
function clippingAncestors() {
  const ancestors = [];
  for (
    let node = trigger.value?.parentElement;
    node && node !== document.body;
    node = node.parentElement
  ) {
    const style = getComputedStyle(node);
    if (
      [style.overflowX, style.overflowY].some((value) => value !== 'visible') ||
      style.clipPath !== 'none' ||
      /paint|strict|content/.test(style.contain)
    )
      ancestors.push(node);
  }
  return ancestors;
}
function explicitInlinePanel() {
  const supplied = instance.vnode.props || {};
  return (
    props.teleportPanel === false &&
    (Object.hasOwn(supplied, 'teleportPanel') || Object.hasOwn(supplied, 'teleport-panel'))
  );
}
function preparePanel() {
  automaticPortal.value = !explicitInlinePanel() && clippingAncestors().length > 0;
  nextTick(updatePanelPosition);
}
function keepFocusVisible() {
  const viewport = panel.value?.querySelector('.wb-select__viewport');
  const active = document.activeElement;
  if (!viewport?.contains(active)) return;
  // A caller may also constrain the panel itself; keep keyboard focus visible
  // through both scroll containers without changing their sizes or padding.
  for (const container of [viewport, panel.value]) {
    const bounds = container.getBoundingClientRect();
    const item = active.getBoundingClientRect();
    const scale = container.offsetHeight ? bounds.height / container.offsetHeight : 1;
    if (item.top < bounds.top) container.scrollTop += (item.top - bounds.top) / scale;
    else if (item.bottom > bounds.bottom)
      container.scrollTop += (item.bottom - bounds.bottom) / scale;
  }
}
function copyPortalStyle(style) {
  for (const property of style)
    if (property.startsWith('--wb-'))
      panel.value.style.setProperty(property, style.getPropertyValue(property));
  for (const property of [
    'font-family',
    'font-size',
    'font-weight',
    'line-height',
    'letter-spacing',
  ])
    panel.value.style.setProperty(property, style.getPropertyValue(property));
}
function overlayBounds(clearance) {
  const bounds = {
    top: clearance,
    bottom: window.innerHeight - clearance,
    left: clearance,
    right: window.innerWidth - clearance,
  };
  if (!portalled.value && explicitInlinePanel()) {
    for (const ancestor of clippingAncestors()) {
      const rect = ancestor.getBoundingClientRect();
      const scaleX = rect.width / ancestor.offsetWidth || 1;
      const scaleY = rect.height / ancestor.offsetHeight || 1;
      bounds.top = Math.max(bounds.top, rect.top + ancestor.clientTop * scaleY);
      bounds.bottom = Math.min(
        bounds.bottom,
        rect.top + (ancestor.clientTop + ancestor.clientHeight) * scaleY,
      );
      bounds.left = Math.max(bounds.left, rect.left + ancestor.clientLeft * scaleX);
      bounds.right = Math.min(
        bounds.right,
        rect.left + (ancestor.clientLeft + ancestor.clientWidth) * scaleX,
      );
    }
  }
  return bounds;
}
function panelMetrics() {
  const rootRect = root.value.getBoundingClientRect();
  const scaleX = portalled.value ? 1 : rootRect.width / root.value.offsetWidth || 1;
  const scaleY = portalled.value ? 1 : rootRect.height / root.value.offsetHeight || 1;
  const viewport = panel.value.querySelector('.wb-select__viewport');
  // Include padding and any existing footer/loading rows outside the scrolling viewport.
  const chromeHeight = Math.max(
    0,
    (panel.value.getBoundingClientRect().height - viewport.getBoundingClientRect().height) / scaleY,
  );
  return {
    rootRect,
    scaleX,
    scaleY,
    chromeHeight,
    naturalHeight: (viewport.scrollHeight + chromeHeight) * scaleY,
  };
}
function needsAutomaticPortal(naturalHeight, below, triggerRect, bounds) {
  return (
    !portalled.value &&
    !explicitInlinePanel() &&
    (clippingAncestors().length > 0 ||
      naturalHeight > below ||
      triggerRect.left < bounds.left ||
      triggerRect.right > bounds.right)
  );
}
function updatePanelPosition(event) {
  if (!expanded.value || !trigger.value || !panel.value) return;
  // Scrolling the menu must not pull a pointer user's scroll back to the focused option.
  if (event?.type === 'scroll' && panel.value.contains(event.target)) return;
  const triggerRect = trigger.value.getBoundingClientRect();
  const rootStyle = getComputedStyle(trigger.value);
  if (portalled.value) copyPortalStyle(rootStyle);
  const offset = parseFloat(rootStyle.getPropertyValue('--wb-spacing-component-xs')) || 0;
  const clearance = parseFloat(rootStyle.getPropertyValue('--wb-spacing-component-sm')) || 0;
  // Explicit inline consumers retain their mounting contract and clipping boundary.
  const bounds = overlayBounds(clearance);
  const { rootRect, scaleX, scaleY, chromeHeight, naturalHeight } = panelMetrics();
  const below = Math.max(0, bounds.bottom - triggerRect.bottom - offset);
  const above = Math.max(0, triggerRect.top - bounds.top - offset);
  if (needsAutomaticPortal(naturalHeight, below, triggerRect, bounds)) {
    automaticPortal.value = true;
    nextTick(updatePanelPosition);
    return;
  }
  const upwards = naturalHeight > below && above > below;
  const available = upwards ? above : below;
  const width = Math.max(0, Math.min(triggerRect.width, bounds.right - bounds.left));
  const left = Math.max(bounds.left, Math.min(triggerRect.left, bounds.right - width));
  panel.value.style.setProperty('--select-overlay-max-height', `${available / scaleY}px`);
  panel.value.style.setProperty('--select-overlay-chrome-height', `${chromeHeight}px`);
  panel.value.style.setProperty(
    '--select-overlay-viewport-height',
    `${Math.max(0, Math.floor(available / scaleY - chromeHeight))}px`,
  );
  panel.value.style.setProperty('--select-overlay-width', `${width / scaleX}px`);
  // Measure the constrained panel, including fractional line heights, before anchoring upwards.
  const height = panel.value.getBoundingClientRect().height;
  const top = upwards ? triggerRect.top - height - offset : triggerRect.bottom + offset;
  panel.value.style.setProperty(
    '--select-overlay-top',
    `${(top - (portalled.value ? 0 : rootRect.top)) / scaleY}px`,
  );
  panel.value.style.setProperty(
    '--select-overlay-left',
    `${(left - (portalled.value ? 0 : rootRect.left)) / scaleX}px`,
  );
  if (portalled.value) updatePortalLayer();
  keepFocusVisible();
}
function stackingContext(style, parent) {
  const positioned = style.position !== 'static' || /flex|grid/.test(parent.display);
  return (
    (style.zIndex !== 'auto' && positioned) ||
    style.transform !== 'none' ||
    style.perspective !== 'none' ||
    style.filter !== 'none' ||
    style.isolation === 'isolate' ||
    Number(style.opacity) < 1 ||
    /paint|strict|content/.test(style.contain)
  );
}
function updatePortalLayer() {
  panel.value.style.removeProperty('z-index');
  const owner = trigger.value.closest('.wb-modal-host, .wb-drawer-host');
  if (owner) {
    panel.value.style.zIndex = String(Number(getComputedStyle(owner).zIndex) + 1);
    return;
  }
  let outerLayer = null;
  for (
    let node = trigger.value.parentElement;
    node && node !== document.body;
    node = node.parentElement
  ) {
    const style = getComputedStyle(node);
    if (stackingContext(style, getComputedStyle(node.parentElement)))
      outerLayer = Number(style.zIndex) || 0;
  }
  if (outerLayer !== null)
    panel.value.style.zIndex = String(
      Math.max(Number(getComputedStyle(panel.value).zIndex) || 0, outerLayer + 1),
    );
}
function focusOption(index = 0) {
  nextTick(async () => {
    updatePanelPosition();
    await nextTick();
    const nodes = panelOptions();
    nodes[Math.max(0, Math.min(index, nodes.length - 1))]?.focus({ preventScroll: true });
    keepFocusVisible();
  });
}
function toggle() {
  if (disabled.value) return;
  open.value = !open.value;
  if (open.value)
    nextTick(async () => {
      updatePanelPosition();
      await nextTick();
      if (props.searchable) searchInput.value?.focus({ preventScroll: true });
      else focusOption();
    });
  else searchQuery.value = '';
}
function choose(option) {
  if (disabled.value || option.disabled) return;
  emit(
    'update:modelValue',
    props.multiple
      ? props.modelValue.includes(option.value)
        ? props.modelValue.filter((value) => value !== option.value)
        : [...props.modelValue, option.value]
      : [option.value],
  );
  if (!props.multiple) {
    open.value = false;
    trigger.value?.focus();
  }
}
function clearSelection() {
  if (disabled.value || !selected.value.length) return;
  emit('update:modelValue', []);
  emit('clear');
  searchQuery.value = '';
  trigger.value?.focus();
}
function keydown(event) {
  if (event.key === 'Escape') {
    if (!expanded.value) return;
    event.preventDefault();
    event.stopPropagation();
    open.value = false;
    trigger.value?.focus();
    return;
  }
  if (!['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) return;
  if (disabled.value) return;
  event.preventDefault();
  const nodes = panelOptions();
  const index = nodes.indexOf(document.activeElement);
  open.value = true;
  focusOption(
    event.key === 'Home'
      ? 0
      : event.key === 'End'
        ? Infinity
        : index < 0
          ? 0
          : (index + (event.key === 'ArrowDown' ? 1 : -1) + nodes.length) % nodes.length,
  );
}
function withinSelect(node) {
  return Boolean(node && (root.value?.contains(node) || panel.value?.contains(node)));
}
function outside(event) {
  if (!withinSelect(event.target)) open.value = false;
}
function blur(event) {
  if (portalled.value && panel.value?.contains(event.target)) field?.blur?.(event);
  if (!withinSelect(event.relatedTarget)) {
    focused.value = false;
    open.value = false;
  }
}
let resizeObserver;
function measureTags() {
  if (!values.value || !tagMeasure.value) return;
  const style = getComputedStyle(tagMeasure.value);
  const rootStyle = getComputedStyle(document.documentElement);
  tagMetrics.value = {
    font: style.font,
    padding: parseFloat(style.paddingLeft) + parseFloat(style.paddingRight),
    gap: parseFloat(getComputedStyle(values.value).gap) || 0,
    letterSpacing: parseFloat(style.letterSpacing) || 0,
    thumbnailSize: parseFloat(rootStyle.getPropertyValue('--wb-asset-wb-checkbox-size')) || 0,
    thumbnailGap: parseFloat(rootStyle.getPropertyValue('--wb-spacing-component-xs')) || 0,
  };
  valuesWidth.value = values.value.clientWidth;
  nextTick(positionOverflowTooltip);
}
onMounted(() => {
  if (!props.modelValue.length && props.defaultValue.length)
    emit('update:modelValue', [...props.defaultValue]);
  document.addEventListener('pointerdown', outside);
  resizeObserver = new ResizeObserver(() => {
    measureTags();
    updatePanelPosition();
  });
  if (values.value) resizeObserver.observe(values.value);
  if (tagMeasure.value) resizeObserver.observe(tagMeasure.value);
  if (trigger.value) resizeObserver.observe(trigger.value);
  document.fonts.addEventListener('loadingdone', measureTags);
  window.addEventListener('resize', updatePanelPosition);
  document.addEventListener('scroll', updatePanelPosition, true);
  measureTags();
  preparePanel();
});
watch([expanded, () => props.teleportPanel], preparePanel, { flush: 'sync' });
watch(
  panel,
  (node, previous) => {
    if (previous) resizeObserver?.unobserve(previous);
    if (node) resizeObserver?.observe(node);
    nextTick(updatePanelPosition);
  },
  { flush: 'post' },
);
watch([() => props.options, searchQuery], () => nextTick(updatePanelPosition), { deep: true });
onBeforeUnmount(() => {
  document.removeEventListener('pointerdown', outside);
  document.fonts.removeEventListener('loadingdone', measureTags);
  window.removeEventListener('resize', updatePanelPosition);
  document.removeEventListener('scroll', updatePanelPosition, true);
  resizeObserver?.disconnect();
});
watch(disabled, (value) => {
  if (value) {
    open.value = false;
    overflowHovered.value = false;
  }
});
</script>
<template>
  <div
    ref="root"
    class="wb-select"
    :class="[
      {
        'is-multiple': multiple,
        'has-value': selected.length,
        'is-open': expanded,
        'is-disabled': disabled,
        'is-focused': focused,
      },
      `is-${state}`,
    ]"
    data-grid-span="4"
    @focusout="blur"
  >
    <div class="wb-select__control">
      <button
        ref="trigger"
        type="button"
        class="wb-select__trigger"
        :disabled="disabled"
        v-bind="fieldAttrs"
        :aria-labelledby="field ? `${field.labelId} ${id}-value` : undefined"
        :role="field || controlRequired ? 'combobox' : undefined"
        :aria-label="
          [label, selected.length ? selected.map((option) => option.label).join('、') : placeholder]
            .filter(Boolean)
            .join(' ')
        "
        :aria-describedby="
          descriptionIds(
            fieldAttrs['aria-describedby'],
            overflowTipVisible ? `${id}-overflow-tip` : undefined,
          )
        "
        aria-haspopup="listbox"
        :aria-expanded="expanded"
        :aria-controls="expanded ? `${id}-list` : undefined"
        @click="toggle"
        @keydown="keydown"
        @focus="focused = true"
      >
        <span
          ref="tagMeasure"
          aria-hidden="true"
          class="wb-tag-surface wb-select__tag-measure"
          >M</span
        >
        <span
          :id="`${id}-value`"
          ref="values"
          :aria-label="
            selected.length ? selected.map((option) => option.label).join('、') : placeholder
          "
          class="wb-select__values"
        >
          <span
            v-if="!selected.length"
            class="wb-select__placeholder"
            >{{ placeholder }}</span
          >
          <template v-else-if="multiple"
            ><span
              v-for="option in visibleTags"
              :key="option.value"
              class="wb-tag-surface wb-select__tag"
              :title="option.label"
              ><img
                v-if="option.thumbnail"
                class="wb-select__tag-thumbnail"
                :src="option.thumbnail"
                alt=""
              /><span class="wb-select__tag-label">{{ displayedLabel(option.label) }}</span></span
            ><span
              v-if="hiddenTagCount"
              class="wb-select__overflow-zone"
              @mouseenter="overflowHovered = true"
              @mouseleave="overflowHovered = false"
              ><span
                ref="overflowAnchor"
                class="wb-tag-surface wb-select__tag wb-select__tag--overflow"
                >+{{ hiddenTagCount }}</span
              ></span
            ></template
          >
          <span
            v-else
            class="wb-select__text"
            :title="selected[0].label"
            >{{ selected[0].label }}</span
          >
        </span>
        <WorkbenchIcon
          v-if="!(clearable && selected.length)"
          class="wb-select__arrow wb-disclosure-icon"
          :class="{ 'is-expanded': expanded }"
          name="箭头/尺寸=10, 方向=下箭头"
          :size="10"
        />
      </button>
      <span
        v-if="clearable && selected.length"
        class="wb-select__actions"
      >
        <button
          type="button"
          class="wb-select__clear"
          :disabled="disabled"
          aria-label="清空已选项"
          @click.stop="clearSelection"
        >
          <WorkbenchIcon name="/ic_public_close_line_14px" />
        </button>
        <span
          class="wb-select__action-divider"
          aria-hidden="true"
        ></span>
        <button
          type="button"
          class="wb-select__toggle"
          :disabled="disabled"
          :aria-label="expanded ? '收起选项' : '展开选项'"
          :aria-expanded="expanded"
          :aria-controls="expanded ? `${id}-list` : undefined"
          @click="toggle"
        >
          <WorkbenchIcon
            class="wb-select__arrow wb-disclosure-icon"
            :class="{ 'is-expanded': expanded }"
            name="箭头/尺寸=10, 方向=下箭头"
            :size="10"
          />
        </button>
      </span>
    </div>
    <div
      v-if="overflowTipVisible"
      :id="`${id}-overflow-tip`"
      ref="overflowTooltip"
      class="wb-select__overflow-tooltip"
      data-overlay-kind="tooltip"
      role="tooltip"
    >
      <span
        v-for="option in hiddenTags"
        :key="option.value"
        class="wb-tag-surface wb-select__tag"
        :title="option.label"
        ><img
          v-if="option.thumbnail"
          class="wb-select__tag-thumbnail"
          :src="option.thumbnail"
          alt=""
        /><span class="wb-select__tag-label">{{ displayedLabel(option.label) }}</span></span
      ><svg
        class="wb-select__overflow-tooltip-arrow"
        viewBox="0 0 12 8"
        aria-hidden="true"
      >
        <path d="M0 0h12L7.6 5.9C6.8 7 5.2 7 4.4 5.9L0 0Z" />
      </svg>
    </div>
    <Teleport
      to="body"
      :disabled="!portalled"
    >
      <div
        v-if="expanded"
        :id="`${id}-list`"
        ref="panel"
        role="listbox"
        :aria-labelledby="field?.labelId"
        :aria-label="field ? undefined : label || '可选项'"
        :aria-multiselectable="multiple || undefined"
        class="wb-select__panel"
        :class="[{ 'is-teleported': portalled, 'is-multiple': multiple }, panelClass]"
        @keydown="keydown"
        @focusout="blur"
      >
        <div class="wb-select__viewport">
          <label
            v-if="searchable"
            class="wb-select__search"
            ><svg
              viewBox="0 0 16 16"
              aria-hidden="true"
            >
              <circle
                cx="7"
                cy="7"
                r="4.5"
              />
              <path d="m10.5 10.5 3 3" /></svg
            ><input
              ref="searchInput"
              v-model="searchQuery"
              type="search"
              :placeholder="searchPlaceholder"
              aria-label="筛选选项"
          /></label>
          <div
            v-if="!filteredOptions.length"
            class="wb-select__empty"
          >
            暂无匹配选项
          </div>
          <div
            v-for="group in groupedOptions"
            v-else
            :key="group.label || 'ungrouped'"
            class="wb-select__group"
            :class="{ 'has-heading': hasGroups }"
            role="group"
            :aria-label="group.label || undefined"
          >
            <div
              v-if="hasGroups"
              class="wb-select__group-title"
            >
              {{ group.label }}
            </div>
            <div class="wb-select__group-options">
              <button
                v-for="option in group.options"
                :key="option.value"
                type="button"
                role="option"
                :disabled="option.disabled"
                :aria-disabled="option.disabled || undefined"
                :aria-selected="modelValue.includes(option.value)"
                class="wb-select__option"
                @click="choose(option)"
              >
                <ChoiceMark
                  v-if="multiple"
                  :checked="modelValue.includes(option.value)"
                  :disabled="option.disabled"
                /><img
                  v-if="option.thumbnail"
                  class="wb-select__thumbnail"
                  :src="option.thumbnail"
                  alt=""
                /><span class="wb-select__option-tip"
                  ><WorkbenchTooltip
                    :content="option.label"
                    overflow-only
                    ><template #trigger="{ aria }"
                      ><span
                        v-bind="aria"
                        class="wb-select__option-label"
                        >{{ option.label }}</span
                      ></template
                    ></WorkbenchTooltip
                  ></span
                ><span
                  v-if="!multiple && modelValue.includes(option.value)"
                  aria-hidden="true"
                  class="wb-select__selected-mark"
                  ><WorkbenchIcon name="完成/尺寸=14"
                /></span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </Teleport>
  </div>
</template>
<style>
.wb-select {
  position: relative;
  width: var(--select-field-width, var(--wb-asset-wb-select-default-width));
  min-width: 0;
  max-width: 100%;
  color: var(--wb-color-text-primary);
}
.wb-select__label {
  display: block;
  margin-bottom: var(--wb-spacing-component-sm);
}
.wb-select__control {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  width: 100%;
  height: var(--wb-asset-wb-select-height);
  border: var(--wb-asset-wb-select-border-width) solid var(--wb-color-border);
  border-radius: var(--wb-radius-sm);
  background: var(--wb-color-surface-card-default);
}
.wb-select__trigger {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  min-width: 0;
  height: var(--wb-asset-wb-select-height);
  flex: 1;
  padding: 0 var(--wb-spacing-component-md);
  border: 0;
  background: transparent;
  color: inherit;
  font: inherit;
  text-align: left;
  cursor: pointer;
}
.wb-select__control > .wb-select__trigger:only-child {
  margin: calc(0px - var(--wb-asset-wb-select-border-width));
  flex-basis: calc(100% + var(--wb-asset-wb-select-border-width) * 2);
}
.wb-select__values {
  display: flex;
  align-items: center;
  gap: var(--wb-spacing-component-sm);
  min-width: 0;
  flex: 1;
  overflow: hidden;
}
.wb-select__text,
.wb-select__placeholder,
.wb-select__tag,
.wb-select__tag-label,
.wb-select__option-label {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  min-width: 0;
}
.wb-select__placeholder {
  color: var(--wb-color-text-placeholder);
}
.wb-select__actions {
  display: flex;
  align-self: center;
  align-items: center;
  gap: var(--wb-spacing-component-sm);
  margin-right: calc(0px - var(--wb-asset-wb-select-border-width));
  padding-right: var(--wb-spacing-component-md);
  flex: none;
}
.wb-select__clear,
.wb-select__toggle {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex: none;
  padding: 0;
  border: 0;
  background: transparent;
  color: var(--wb-color-text-secondary);
  cursor: pointer;
}
.wb-select__clear {
  width: var(--wb-asset-wb-checkbox-size);
  opacity: 0;
  visibility: hidden;
  pointer-events: none;
  height: var(--wb-asset-wb-checkbox-size);
  color: var(--wb-color-icon-secondary);
}
.wb-select:hover .wb-select__clear,
.wb-select:focus-within .wb-select__clear,
.wb-select.is-hover .wb-select__clear,
.wb-select.is-focus .wb-select__clear {
  opacity: 1;
  visibility: visible;
  pointer-events: auto;
}
.wb-select__clear:hover:not(:disabled) {
  color: var(--wb-color-icon-primary);
}
.wb-select__action-divider {
  opacity: 0;
  visibility: hidden;
  width: var(--wb-asset-wb-select-border-width);
  height: var(--wb-asset-wb-checkbox-size);
  background: var(--wb-color-border);
}
.wb-select:hover .wb-select__action-divider,
.wb-select:focus-within .wb-select__action-divider,
.wb-select.is-hover .wb-select__action-divider,
.wb-select.is-focus .wb-select__action-divider {
  opacity: 1;
  visibility: visible;
}
.wb-select__toggle {
  width: var(--wb-asset-wb-select-arrow-size);
  height: var(--wb-asset-wb-select-arrow-size);
  flex: none;
}
.wb-select__arrow {
  color: var(--wb-color-text-secondary);
}
.wb-select.is-multiple.has-value .wb-select__trigger {
  padding-block: 0;
  padding-left: var(--wb-spacing-component-xs);
}
.wb-select__tag-thumbnail {
  width: var(--wb-asset-wb-checkbox-size);
  height: var(--wb-asset-wb-checkbox-size);
  flex: none;
  border-radius: var(--wb-radius-full);
  object-fit: cover;
}
.wb-select__tag-measure {
  position: absolute;
  visibility: hidden;
  pointer-events: none;
}
.wb-select__tag--overflow {
  color: var(--wb-color-text-primary);
}
.wb-select__overflow-zone {
  display: flex;
  align-items: center;
  align-self: stretch;
  flex: 1;
  min-width: max-content;
}
.wb-select__overflow-tooltip {
  position: absolute;
  z-index: 2;
  left: var(--select-overflow-center);
  transform: translateX(-50%);
  bottom: calc(
    var(--wb-asset-wb-select-height) + var(--wb-asset-wb-popover-arrow-height) +
      var(--wb-spacing-component-xs) / 2
  );
  display: flex;
  flex-wrap: wrap;
  gap: var(--wb-spacing-component-xs);
  box-sizing: border-box;
  inline-size: var(--select-overflow-width, max-content);
  max-inline-size: 100%;
  padding: var(--wb-spacing-component-xs);
  border-radius: var(--wb-radius-sm);
  background: var(--wb-color-surface-overlay);
  box-shadow: var(--wb-shadow-lg);
  pointer-events: none;
}
.wb-select__overflow-tooltip-arrow {
  position: absolute;
  top: 100%;
  left: 50%;
  transform: translateX(-50%);
  width: var(--wb-asset-wb-popover-arrow-width);
  height: var(--wb-asset-wb-popover-arrow-height);
}
.wb-select__overflow-tooltip-arrow path {
  fill: var(--wb-color-surface-overlay);
}
.wb-select__control:hover,
.wb-select.is-hover .wb-select__control {
  border-color: var(--wb-color-border-hover);
}
.wb-select:focus-within .wb-select__control,
.wb-select.is-focus .wb-select__control {
  border-width: var(--wb-asset-wb-select-border-width);
  border-color: var(--wb-color-border-focus);
  outline: none;
  box-shadow: none;
}
.wb-select__trigger:focus-visible,
.wb-select__clear:focus-visible,
.wb-select__toggle:focus-visible {
  outline: none;
}
.wb-select.is-open .wb-select__arrow {
  color: var(--wb-color-icon-active);
}
.wb-select.is-disabled .wb-select__control {
  background: var(--wb-color-fill-subtle-disabled);
  border-color: var(--wb-color-border-disabled);
  color: var(--wb-color-text-disabled);
  outline: none;
}
.wb-select.is-disabled .wb-select__trigger,
.wb-select.is-disabled .wb-select__clear,
.wb-select.is-disabled .wb-select__toggle {
  cursor: not-allowed;
}
.wb-select.is-disabled .wb-select__arrow {
  color: var(--wb-color-icon-disabled);
}
.wb-select.is-disabled .wb-select__tag--overflow,
.wb-select.is-disabled .wb-select__placeholder {
  color: var(--wb-color-text-disabled);
}
.wb-select__panel {
  box-sizing: border-box;
  position: absolute;
  z-index: 1;
  top: var(--select-overlay-top, calc(100% + var(--wb-spacing-component-xs)));
  left: var(--select-overlay-left, 0);
  width: var(--select-overlay-width, 100%);
  display: grid;
  padding: var(--wb-spacing-component-xs);
  border: 0;
  border-radius: var(--wb-radius-md);
  background: var(--wb-color-surface-overlay);
  color: var(--wb-color-text-primary);
  box-shadow: var(--wb-shadow-base);
}
.wb-select__panel.is-teleported {
  position: fixed;
  top: var(--select-overlay-top);
  left: var(--select-overlay-left);
  width: var(--select-overlay-width);
}
.wb-select__viewport {
  min-width: 0;
  min-height: 0;
  max-height: var(--select-overlay-viewport-height);
  overflow: auto;
  overscroll-behavior: contain;
  touch-action: pan-y;
}
.wb-select__search {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  gap: var(--wb-spacing-component-xs);
  height: var(--wb-asset-wb-select-height);
  margin-bottom: var(--wb-spacing-component-xs);
  padding: 0 var(--wb-spacing-component-sm);
  border: 1px solid var(--wb-color-border);
  border-radius: var(--wb-radius-sm);
  color: var(--wb-color-text-secondary);
}
.wb-select__search:focus-within {
  border-color: var(--wb-color-border-focus);
}
.wb-select__search svg {
  width: var(--wb-asset-wb-checkbox-size);
  height: var(--wb-asset-wb-checkbox-size);
  flex: none;
  fill: none;
  stroke: currentColor;
}
.wb-select__search input {
  min-width: 0;
  flex: 1;
  padding: 0;
  border: 0;
  outline: 0;
  background: transparent;
  color: var(--wb-color-text-primary);
  font: inherit;
}
.wb-select__search input::placeholder {
  color: var(--wb-color-text-placeholder);
}
.wb-select__search input::-webkit-search-cancel-button {
  display: none;
}
.wb-select__empty {
  min-height: var(--wb-asset-wb-select-height);
  display: flex;
  align-items: center;
  padding: 0 var(--wb-spacing-component-sm);
  color: var(--wb-color-text-placeholder);
}
.wb-select__group + .wb-select__group {
  margin-top: var(--wb-spacing-component-xs);
  padding-top: var(--wb-spacing-component-sm);
  border-top: 1px solid var(--wb-color-border-separator);
}
.wb-select__group-title {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  height: var(--wb-asset-wb-select-option-height);
  padding: 0 var(--wb-spacing-component-sm);
  color: var(--wb-color-text-placeholder);
}
.wb-select__group-options {
  display: grid;
  gap: var(--wb-spacing-component-xs);
}
.wb-select__option {
  box-sizing: border-box;
  min-height: var(--wb-asset-wb-select-option-height);
  display: flex;
  align-items: center;
  justify-content: flex-start;
  gap: var(--wb-spacing-component-xs);
  min-width: 0;
  padding: var(--wb-spacing-component-xs) var(--wb-spacing-component-sm);
  border: 0;
  border-radius: var(--wb-radius-sm);
  background: transparent;
  color: inherit;
  font: inherit;
  text-align: left;
  cursor: pointer;
}
.wb-select__option:not(:disabled):hover,
.wb-select__option:not(:disabled):focus-visible {
  background: var(--wb-color-fill-hover);
  outline: none;
}
.wb-select__option-tip {
  display: block;
  min-width: 0;
  flex: 1;
}
.wb-select__option-tip > .wb-tooltip {
  display: block;
  width: 100%;
}
.wb-select__option-label {
  display: block;
  text-align: left;
}
.wb-select__option:disabled {
  color: var(--wb-color-text-disabled);
  cursor: not-allowed;
}
.wb-select.is-multiple .wb-select__option,
.wb-select__panel.is-multiple .wb-select__option {
  gap: var(--wb-spacing-component-sm);
}
.wb-select__thumbnail {
  width: var(--wb-asset-wb-select-tag-height);
  height: var(--wb-asset-wb-select-tag-height);
  flex: none;
  border-radius: var(--wb-radius-full);
  object-fit: cover;
}
.wb-select__option .wb-choice-mark {
  align-self: center;
  margin-block-start: 0;
}
.wb-select__option:not(:disabled):hover .wb-choice-mark {
  border-color: var(--wb-color-icon-primary);
}
</style>

<style>
.wb-select__selected-mark {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex: none;
  width: var(--wb-asset-wb-select-selected-mark-size);
  height: var(--wb-asset-wb-select-selected-mark-size);
}
</style>
