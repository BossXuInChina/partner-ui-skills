<script setup>
import { computed, getCurrentInstance, useAttrs } from 'vue';
import WorkbenchSelectCore from './WorkbenchSelectCore.vue';
defineOptions({ inheritAttrs: false });
const props = defineProps({
  modelValue: { type: Array, default: () => [] },
  multiple: Boolean,
  label: String,
  required: Boolean,
  state: { type: String, default: 'default' },
  showPanel: Boolean,
  options: { type: Array, required: true },
  teleportPanel: Boolean,
  panelClass: { type: String, default: '' },
  placeholder: { type: String, default: '请选择' },
});
const emit = defineEmits(['update:modelValue']);
const attrs = useAttrs();
const instance = getCurrentInstance();
function portalOptions() {
  const supplied = instance.vnode.props || {};
  return Object.hasOwn(supplied, 'teleportPanel') || Object.hasOwn(supplied, 'teleport-panel')
    ? { teleportPanel: props.teleportPanel }
    : {};
}
const approvedOptions = computed(() =>
  props.options.map((option) => ({
    value: option.value,
    label: option.label,
    disabled: option.disabled,
  })),
);
const blockedExtensionAttrs = new Set([
  'searchable',
  'clearable',
  'defaultValue',
  'default-value',
  'searchPlaceholder',
  'search-placeholder',
  'onClear',
]);
function forwardedAttrs() {
  return Object.fromEntries(
    Object.entries(attrs).filter(([key]) => !blockedExtensionAttrs.has(key)),
  );
}
</script>
<template>
  <WorkbenchSelectCore
    v-bind="{ ...forwardedAttrs(), ...portalOptions() }"
    :model-value="modelValue"
    :multiple="multiple"
    :label="label"
    :required="required"
    :state="state"
    :show-panel="showPanel"
    :options="approvedOptions"
    :panel-class="panelClass"
    :placeholder="placeholder"
    @update:model-value="emit('update:modelValue', $event)"
  >
    <template
      v-for="(_, slotName) in $slots"
      #[slotName]="slotProps"
      ><slot
        :name="slotName"
        v-bind="slotProps || {}"
    /></template>
  </WorkbenchSelectCore>
</template>
