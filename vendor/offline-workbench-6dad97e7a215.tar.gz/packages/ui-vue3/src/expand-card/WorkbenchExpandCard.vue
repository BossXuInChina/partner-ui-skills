<script setup lang="ts">
// Block: tinted business card with icon + summary title; the right arrow expands or collapses the detail.
import { useId } from 'vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
defineProps({
  expanded: { type: Boolean, default: false },
  title: { type: String, required: true },
});
const emit = defineEmits(['update:expanded']);
const id = useId();
</script>

<template>
  <section class="wb-expand-card" :class="{ 'is-expanded': expanded }">
    <header class="wb-expand-card__head">
      <span v-if="$slots.icon" class="wb-expand-card__icon"><slot name="icon" /></span>
      <span class="wb-expand-card__title"><slot name="title">{{ title }}</slot></span>
      <button
        type="button"
        class="wb-expand-card__toggle"
        :aria-label="(expanded ? '收起' : '展开') + title"
        :aria-expanded="expanded"
        :aria-controls="id"
        @click="emit('update:expanded', !expanded)"
      >
        <span class="wb-expand-card__arrow" :class="{ 'is-expanded': expanded }"><WorkbenchIcon name="/ic_arrow_down_line_12px" /></span>
      </button>
    </header>
    <div :id="id" class="wb-expand-card__body-wrap" :class="{ 'is-expanded': expanded }" :inert="!expanded">
      <div class="wb-expand-card__body"><div class="wb-expand-card__body-content"><slot /></div></div>
    </div>
  </section>
</template>

<style>
.wb-expand-card { border-radius: var(--wb-radius-md); background: var(--wb-color-surface-card-tinted); }
.wb-expand-card__head { display: flex; align-items: center; gap: var(--wb-spacing-component-md); padding: var(--wb-spacing-component-sm) var(--wb-spacing-component-lg); }
.wb-expand-card__icon { display: inline-flex; flex: none; }
.wb-expand-card__title { flex: 1; min-width: 0; color: var(--wb-color-text-primary); font-size: var(--wb-font-headline-xs-font-size); font-weight: var(--wb-font-headline-xs-font-weight); line-height: var(--wb-font-headline-xs-line-height); letter-spacing: var(--wb-font-headline-xs-letter-spacing); }
.wb-expand-card__toggle { display: inline-flex; flex: none; width: var(--wb-icon-size-12); height: var(--wb-icon-size-12); align-items: center; justify-content: center; padding: 0; border: 0; background: transparent; color: var(--wb-color-icon-primary); cursor: pointer; }
.wb-expand-card__toggle:focus-visible { outline: var(--wb-asset-wb-expand-card-focus-outline-width) solid var(--wb-color-border-focus); outline-offset: var(--wb-asset-wb-expand-card-focus-outline-width); }
.wb-expand-card__arrow { display: inline-flex; transition: transform var(--wb-asset-wb-expand-card-motion-duration) ease; }
.wb-expand-card__arrow.is-expanded { transform: rotate(180deg); }
.wb-expand-card__body-wrap { display: grid; grid-template-rows: 0fr; transition: grid-template-rows var(--wb-asset-wb-expand-card-motion-duration) ease; }
.wb-expand-card__body-wrap.is-expanded { grid-template-rows: 1fr; }
.wb-expand-card__body { min-height: 0; overflow: hidden; }
.wb-expand-card__body-content { padding: 0 var(--wb-spacing-component-lg) var(--wb-spacing-component-sm); }
@media (prefers-reduced-motion: reduce) { .wb-expand-card__arrow, .wb-expand-card__body-wrap { transition: none; } }
</style>
