<script setup lang="ts">
// Block: single-select quick filter rendered as wrapping selectable tags, for many business filters.
import type { PropType } from 'vue';
import WorkbenchTag from '../tag/WorkbenchTag.vue';
import type { FilterChipItem } from '../../types/home-blocks';
defineProps({
  modelValue: { type: String, required: true },
  items: { type: Array as PropType<FilterChipItem[]>, required: true },
  ariaLabel: { type: String, default: '筛选' },
});
const emit = defineEmits(['update:modelValue']);
</script>

<template>
  <div class="wb-filter-chips" role="group" :aria-label="ariaLabel">
    <WorkbenchTag
      v-for="item in items"
      :key="item.value"
      interactive
      :selected="modelValue === item.value"
      :label="item.count === undefined ? item.label : `${item.label}(${item.count})`"
      @select="emit('update:modelValue', item.value)"
    />
  </div>
</template>

<style>
.wb-filter-chips { display: flex; flex-wrap: wrap; gap: var(--wb-spacing-component-sm); }
</style>
