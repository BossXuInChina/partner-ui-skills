<script setup lang="ts">
import { useSlots, type PropType } from 'vue';
import { hasSlotContent } from '../card-block/slots';
const slots = useSlots();
const has = (name: string) => hasSlotContent(slots, name);
import WorkbenchTag from '../tag/WorkbenchTag.vue';
import BlockFrame from '../card-block/BlockFrame.vue';
import BlockActions from '../card-block/BlockActions.vue';
import type {
  CardVariant,
  CardSize,
  CardAction,
  CardFooter,
  CardActionEvent,
} from '../../types/card-blocks';
import playIcon from '../card-block/assets/video-play.svg';
defineProps({
  title: { type: String, default: '' },
  variant: {
    type: String as PropType<CardVariant>,
    default: 'display-white',
    validator: (value: string) =>
      ['display-white', 'display-tinted', 'operation', 'navigation'].includes(value),
  },
  size: {
    type: String as PropType<CardSize>,
    default: 'xxxl',
    validator: (value: string) => ['s', 'm', 'l', 'xl', 'xxl', 'xxxl'].includes(value),
  },
  href: { type: String, default: undefined },
  target: { type: String, default: undefined },
  rel: { type: String, default: undefined },
  headerActions: { type: Array as PropType<CardAction[]>, default: () => [] },
  footer: { type: Object as PropType<CardFooter | null>, default: null },
  actions: { type: Array as PropType<CardAction[]>, default: () => [] },
  bodySize: {
    type: Number as PropType<14>,
    default: 14,
    validator: (value: number) => [14].includes(value),
  },
  description: { type: String, default: '' },
  tags: { type: Array as PropType<string[]>, default: () => [] },
  mediaKind: {
    type: String as PropType<'image' | 'video'>,
    default: 'image',
    validator: (value: string) => ['image', 'video'].includes(value),
  },
  mediaLabel: { type: String, default: '' },
  badge: { type: String, default: '' },
});
const emit = defineEmits({ action: (_payload: CardActionEvent) => true });
</script>
<template>
  <BlockFrame
    v-bind="$props"
    title=""
    :header-actions="[]"
    class="wbc-media-card"
    data-card-block="media"
    @action="emit('action', $event)"
  >
    <template #header
      ><slot
        v-if="has('header') && variant !== 'navigation'"
        name="header"
    /></template>
    <template #footer
      ><slot
        v-if="has('footer') && variant !== 'navigation'"
        name="footer"
    /></template>
    <template #actions
      ><slot
        v-if="has('actions') && variant !== 'navigation'"
        name="actions"
    /></template>
    <div
      v-if="has('media') && variant !== 'navigation'"
      class="wbc-media wbc-media--custom"
    >
      <slot name="media" />
    </div>
    <div
      v-else
      class="wbc-media"
      role="img"
      :aria-label="mediaLabel || title || '内容封面'"
    >
      <WorkbenchTag
        v-if="mediaKind === 'video'"
        class="wbc-media-badge--regular"
        :label="badge || '视频'"
        variant="basic"
        size="small"
      />
      <span
        v-else-if="badge"
        class="wbc-media-badge-host"
        ><WorkbenchTag
          :label="badge"
          variant="corner"
          corner-tone="hot"
          placement="top-left"
          size="large"
      /></span>
      <img
        v-if="mediaKind === 'video'"
        class="wbc-play"
        :src="playIcon"
        alt=""
      />
    </div>
    <slot
      v-if="has('content') && variant !== 'navigation'"
      name="content"
    />
    <div
      v-else-if="
        title ||
        tags.length ||
        description ||
        (variant !== 'navigation' && (headerActions.length || has('header-actions')))
      "
      class="wbc-media-content"
    >
      <div
        v-if="title || tags.length || headerActions.length || has('header-actions')"
        class="wbc-media-heading"
      >
        <div
          v-if="title || headerActions.length || has('header-actions')"
          class="wbc-info-title-row"
        >
          <h3
            v-if="title"
            class="wbc-title"
          >
            {{ title }}
          </h3>
          <slot
            v-if="has('header-actions') && variant !== 'navigation'"
            name="header-actions"
          /><BlockActions
            v-else-if="variant !== 'navigation' && headerActions.length"
            header
            :items="headerActions"
            @activate="(a, event) => emit('action', { id: a.id, source: 'header', event })"
          />
        </div>
        <div
          v-if="tags.length"
          class="wbc-tags"
        >
          <span
            v-for="(tag, i) in tags"
            :key="i"
            >{{ tag }}</span
          >
        </div>
      </div>
      <p
        v-if="description"
        class="wbc-description"
      >
        {{ description }}
      </p>
    </div>
  </BlockFrame>
</template>
