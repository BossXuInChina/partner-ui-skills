<script setup>
import { useFormDisabled } from '../form/useFormDisabled.js';
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import { computed, nextTick, onBeforeUnmount, ref, useId, watch } from 'vue';
import { zipSync } from 'fflate';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import WorkbenchButton from '../button/WorkbenchButton.vue';
import WorkbenchModal from '../modal/WorkbenchModal.vue';
import ImageUploadTile from './ImageUploadTile.vue';

const props = defineProps({
  modelValue: { type: Array, default: undefined }, defaultValue: { type: Array, default: () => [] },
  multiple: { type: Boolean, default: true }, maxCount: { type: Number, default: 5 },
  maxSize: { type: Number, default: 500 * 1024 }, accept: { type: String, default: 'image/jpeg,image/png' },
  disabled: Boolean, showNames: { type: Boolean, default: true }, downloadable: Boolean, batchDownload: Boolean,
  hint: { type: String, default: undefined }, label: { type: String, default: '图片上传' },
  uploadRequest: { type: Function, default: undefined }, previewState: { type: String, default: 'default' },
});
const disabled = useFormDisabled(() => props.disabled);
const emit = defineEmits(['update:modelValue', 'change', 'reject', 'progress', 'success', 'error', 'cancel', 'remove', 'retry', 'preview', 'download', 'batch-download']);
const localItems = ref(props.defaultValue.map(item => ({ ...item })));
const items = computed(() => props.modelValue ?? localItems.value);
const limit = computed(() => props.multiple ? Math.max(1, Math.floor(props.maxCount) || 1) : 1);
const input = ref(null);
const uid = useId();
const hintId = `image-upload-${uid}`;
const message = ref('');
const preview = ref(null);
const downloading = ref(false);
const jobs = new Map();
const urls = new Map();
let sequence = 0;
let alive = true;
let pendingItems = null;
const currentItems = () => pendingItems ?? items.value;
const successful = computed(() => items.value.filter(item => ['success', 'ready'].includes(item.status) && item.url));
const help = computed(() => props.hint ?? `不超过${Math.round(props.maxSize / 1024)}KB，支持${props.accept.split(',').map(type => type.trim().replace('image/', '').replace('jpeg', 'jpg')).join('、')}，最多上传${limit.value}张图片`);

function commit(next) {
  const value = next.map(item => ({ ...item }));
  if (props.modelValue === undefined) localItems.value = value;
  else {
    // Merge simultaneous progress/completion updates before Vue reflects controlled props.
    pendingItems = value;
    void nextTick(() => { if (pendingItems === value) pendingItems = null; });
  }
  emit('update:modelValue', value);
  emit('change', value);
}
function patch(id, values) { commit(currentItems().map(item => item.id === id ? { ...item, ...values } : item)); }
function stop(id) { const job = jobs.get(id); jobs.delete(id); job?.abort(); }
function accepted(file) {
  const types = props.accept.split(',').map(type => type.trim().toLowerCase()).filter(Boolean);
  const mime = file.type.toLowerCase();
  // Only raster JPEG/PNG data is previewed by the default accept contract.
  return types.length === 0 || types.some(type => type.startsWith('.') ? file.name.toLowerCase().endsWith(type) : type.endsWith('/*') ? mime.startsWith(type.slice(0, -1)) : mime === type);
}
async function selectFiles(event) {
  const selected = Array.from(event.target.files ?? []);
  event.target.value = '';
  if (disabled.value) return;
  const next = [...currentItems()];
  const added = [];
  const rejected = [];
  for (const file of selected) {
    let reason = '';
    if (!accepted(file)) reason = '文件格式不支持';
    else if (file.size > props.maxSize) reason = `文件不能超过${Math.round(props.maxSize / 1024)}KB`;
    else if (next.length >= limit.value) reason = `最多上传${limit.value}张图片`;
    if (reason) { rejected.push(`${file.name}：${reason}`); emit('reject', { file, reason }); continue; }
    const id = `${uid}-${++sequence}`;
    const url = URL.createObjectURL(file);
    urls.set(id, url);
    const item = { id, name: file.name, file, url, status: 'ready', progress: 0 };
    added.push(item); next.push(item);
  }
  message.value = rejected.join('；');
  if (!added.length) return;
  commit(next);
  await nextTick();
  for (const item of added) {
    if (items.value.some(current => current.id === item.id)) { if (props.uploadRequest) void upload(item); }
    else { URL.revokeObjectURL(item.url); urls.delete(item.id); }
  }
}
async function upload(item) {
  if (disabled.value || !props.uploadRequest || jobs.has(item.id)) return;
  const current = currentItems().find(value => value.id === item.id);
  if (!current) return;
  const controller = new AbortController();
  jobs.set(item.id, controller);
  const valid = () => alive && jobs.get(item.id) === controller && !controller.signal.aborted && items.value.some(value => value.id === item.id);
  patch(item.id, { status: 'uploading', progress: 0, error: '' });
  await nextTick();
  if (!valid() || items.value.find(value => value.id === item.id)?.status !== 'uploading') { stop(item.id); return; }
  try {
    const result = await props.uploadRequest(current.file, {
      item: { ...current }, signal: controller.signal,
      onProgress(value) {
        if (!valid()) return;
        const progress = Math.max(0, Math.min(100, Number(value) || 0));
        patch(item.id, { progress }); emit('progress', { id: item.id, progress });
      },
    });
    if (!valid()) return;
    patch(item.id, { status: 'success', progress: 100, ...(typeof result === 'string' ? { url: result } : result?.url ? { url: result.url } : {}) });
    emit('success', { id: item.id, result });
  } catch (error) {
    if (!valid()) return;
    patch(item.id, { status: 'error', error: error?.message || '上传失败' });
    emit('error', { id: item.id, error });
  } finally { if (jobs.get(item.id) === controller) jobs.delete(item.id); }
}
function remove(item, cancel = false) {
  if (disabled.value) return;
  stop(item.id);
  commit(currentItems().filter(value => value.id !== item.id));
  emit(cancel ? 'cancel' : 'remove', { ...item });
}
function retry(item) { if (disabled.value) return; emit('retry', { ...item }); void upload(item); }
function openPreview(item) { if (disabled.value || !item.url) return; preview.value = item; emit('preview', { ...item }); }
function saveBlob(blob, name) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a'); link.href = url; link.download = name; link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
async function imageBlob(item, signal) {
  if (item.file instanceof Blob) return item.file;
  const response = await fetch(item.url, { signal });
  if (!response.ok) throw new Error('下载失败，请重试');
  return response.blob();
}
const downloads = new Set();
async function download(item) {
  if (disabled.value) return;
  message.value = '';
  const controller = new AbortController(); downloads.add(controller);
  try { const blob = await imageBlob(item, controller.signal); if (alive) { saveBlob(blob, item.name); emit('download', { ...item }); } }
  catch (error) { if (alive && !controller.signal.aborted) message.value = error.message || '下载失败，请重试'; }
  finally { downloads.delete(controller); }
}
async function downloadAll() {
  if (disabled.value || downloading.value || !successful.value.length) return;
  message.value = '';
  downloading.value = true;
  const controller = new AbortController(); downloads.add(controller);
  const selected = successful.value.map(item => ({ ...item }));
  try {
    const entries = await Promise.all(selected.map(async (item, index) => [ `${index + 1}-${item.name.replace(/[\\/]/g, '_')}`, new Uint8Array(await (await imageBlob(item, controller.signal)).arrayBuffer()) ]));
    if (!alive) return;
    saveBlob(new Blob([zipSync(Object.fromEntries(entries), { level: 0 })], { type: 'application/zip' }), '图片.zip');
    emit('batch-download', selected);
  } catch (error) { if (alive && !controller.signal.aborted) message.value = error.message || '批量下载失败，请重试'; }
  finally { downloads.delete(controller); downloading.value = false; }
}
watch(items, next => {
  const ids = new Set(next.map(item => item.id));
  for (const id of jobs.keys()) if (!ids.has(id)) stop(id);
  for (const [id, url] of urls) if (!ids.has(id)) { URL.revokeObjectURL(url); urls.delete(id); }
  if (preview.value && !ids.has(preview.value.id)) preview.value = null;
}, { flush: 'post' });
onBeforeUnmount(() => {
  alive = false;
  for (const id of jobs.keys()) stop(id);
  for (const controller of downloads) controller.abort();
  for (const url of urls.values()) URL.revokeObjectURL(url);
  urls.clear();
});
defineExpose({ selectFiles: () => { if (!disabled.value && items.value.length < limit.value) input.value?.click(); }, retry, cancel: item => remove(item, true) });
watch(disabled, (value) => { if (value) { preview.value = null; } });
</script>

<template>
  <section class="wb-image-upload" :aria-label="label" :aria-disabled="disabled || undefined">
    <div v-if="batchDownload || help" class="wb-image-upload__toolbar">
      <WorkbenchButton v-if="batchDownload" appearance="secondary" :disabled="disabled || downloading || !successful.length" @click="downloadAll"><template #icon><WorkbenchIcon name="下载_12px" /></template>{{ downloading ? '正在打包…' : '批量下载' }}</WorkbenchButton>
      <p v-if="help" :id="hintId" class="wb-image-upload__hint">{{ help }}</p>
    </div>
    <ul class="wb-image-upload__list" :aria-label="`${label}图片列表`">
      <ImageUploadTile v-for="item in items" :key="item.id" :item="item" :disabled="disabled" :show-name="showNames" :downloadable="downloadable" :preview-state="previewState" @remove="remove" @cancel="item => remove(item, true)" @retry="retry" @preview="openPreview" @download="download" />
      <li v-if="items.length < limit" class="wb-image-upload__add-item">
        <button type="button" class="wb-image-upload__add" :disabled="disabled" :aria-label="`添加图片，${label}`" :aria-describedby="help ? hintId : undefined" @click="input?.click()"><WorkbenchIcon name="上传图片_24px" /><span>添加图片</span></button>
      </li>
    </ul>
    <input ref="input" class="wb-image-upload__input" type="file" tabindex="-1" :aria-label="`选择图片，${label}`" :multiple="multiple" :accept="accept" :disabled="disabled" @change="selectFiles" />
    <p v-if="message" class="wb-image-upload__error" role="alert">{{ message }}</p>
    <span class="wb-image-upload__announcement" role="status" aria-live="polite">{{ items.length }}张图片，{{ items.filter(item => item.status === 'uploading').length }}张上传中，{{ items.filter(item => item.status === 'error').length }}张上传失败</span>
    <WorkbenchModal :model-value="Boolean(preview)" :title="preview?.name || '图片预览'" readonly size="l" @update:model-value="open => { if (!open) preview = null; }"><img v-if="preview" class="wb-image-upload__preview" :src="preview.url" :alt="preview.name" /></WorkbenchModal>
  </section>
</template>

<style scoped>
.wb-image-upload { color: var(--wb-color-text-primary); font-family: inherit; font-size: var(--wb-font-body-s-font-size); font-weight: var(--wb-font-body-s-font-weight); line-height: var(--wb-font-body-s-line-height); letter-spacing: var(--wb-font-body-s-letter-spacing); }
.wb-image-upload__toolbar { display: flex; align-items: center; flex-wrap: wrap; gap: var(--wb-asset-wb-image-upload-toolbar-gap); margin-bottom: var(--wb-asset-wb-image-upload-list-gap); }
.wb-image-upload__hint { margin: 0; color: var(--wb-color-text-secondary); }
.wb-image-upload__list { display: flex; flex-wrap: wrap; align-items: flex-start; gap: var(--wb-asset-wb-image-upload-list-gap); margin: 0; padding: 0; list-style: none; }
.wb-image-upload__add-item { flex: none; }
.wb-image-upload__add { box-sizing: border-box; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: var(--wb-asset-wb-image-upload-text-gap); width: var(--wb-asset-wb-image-upload-size); height: var(--wb-asset-wb-image-upload-size); padding: 0; border: var(--wb-asset-wb-image-upload-border-width) dashed var(--wb-color-border); border-radius: var(--wb-asset-wb-image-upload-radius); color: var(--wb-color-text-secondary); background: var(--wb-asset-wb-image-upload-add-fill); font-family: inherit; font-size: var(--wb-font-body-m-font-size); font-weight: var(--wb-font-body-m-font-weight); line-height: var(--wb-font-body-m-line-height); letter-spacing: var(--wb-font-body-m-letter-spacing); cursor: pointer; }
.wb-image-upload__add:hover:enabled { border-color: var(--wb-color-text-secondary); }
.wb-image-upload__add:focus-visible { outline: 1px solid var(--wb-color-border-focus); outline-offset: 2px; }
.wb-image-upload__add:disabled { color: var(--wb-color-text-disabled); cursor: not-allowed; }
.wb-image-upload__input { display: none; }
.wb-image-upload__error { margin: var(--wb-asset-wb-image-upload-name-gap) 0 0; color: var(--wb-color-error); }
.wb-image-upload__announcement { position: absolute; width: var(--wb-asset-wb-image-upload-sr-size); height: var(--wb-asset-wb-image-upload-sr-size); padding: 0; overflow: hidden; clip-path: inset(50%); white-space: nowrap; }
.wb-image-upload__preview { display: block; max-width: 100%; max-height: var(--wb-asset-wb-image-upload-preview-height); margin: auto; object-fit: contain; }
</style>
