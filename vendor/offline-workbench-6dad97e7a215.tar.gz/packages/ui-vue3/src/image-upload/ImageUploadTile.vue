<script setup>
import { computed } from 'vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import placeholder from './assets/placeholder.png';

const props = defineProps({
  item: { type: Object, required: true }, disabled: Boolean, showName: { type: Boolean, default: true },
  downloadable: Boolean, previewState: { type: String, default: 'default' },
});
defineEmits(['preview', 'download', 'remove', 'retry', 'cancel']);
const uploading = computed(() => props.item.status === 'uploading');
const failed = computed(() => props.item.status === 'error');
const percentage = computed(() => Math.max(0, Math.min(100, Math.round(Number(props.item.progress) || 0))));
const stateText = computed(() => uploading.value ? props.item.url ? `${percentage.value}%` : '上传中…' : failed.value ? '上传失败' : '');
</script>

<template>
  <li class="image-upload-tile" :class="{ 'image-upload-tile--hover': previewState === 'hover', 'is-disabled': disabled }" :data-status="item.status" :aria-label="`${item.name}，${stateText || (item.status === 'ready' ? '已选择' : '上传成功')}`">
    <div class="image-upload-tile__picture">
      <img :src="item.url || placeholder" :alt="item.name" draggable="false" />
      <div v-if="uploading || failed" class="image-upload-tile__status">
        <svg v-if="uploading" class="image-upload-tile__ring" viewBox="0 0 28 28" role="progressbar" :aria-label="`${item.name}上传进度`" :aria-valuenow="percentage" aria-valuemin="0" aria-valuemax="100"><circle class="image-upload-tile__ring-track" cx="14" cy="14" r="12" /><circle class="image-upload-tile__ring-arc" cx="14" cy="14" r="12" pathLength="100" /></svg>
        <WorkbenchIcon v-else name="提示/面性=off_24px" color="var(--wb-asset-wb-image-upload-white)" />
        <span>{{ stateText }}</span>
      </div>
      <div v-if="!uploading" class="image-upload-tile__actions" :class="{ 'image-upload-tile__actions--disabled': disabled }">
        <button v-if="failed" type="button" :disabled="disabled" :aria-label="`重新上传${item.name}`" @click="$emit('retry', item)"><WorkbenchIcon name="刷新_24px" /></button>
        <button v-else type="button" :disabled="disabled || !item.url" :aria-label="`预览${item.name}`" @click="$emit('preview', item)"><WorkbenchIcon name="可见不可见/可见=on_24px" /></button>
        <button v-if="!failed && downloadable" type="button" :disabled="disabled || !item.url" :aria-label="`下载${item.name}`" @click="$emit('download', item)"><WorkbenchIcon name="下载_24px" /></button>
        <button type="button" :disabled="disabled" :aria-label="`删除${item.name}`" @click="$emit('remove', item)"><WorkbenchIcon name="/ic_public_trash_line_24px" /></button>
      </div>
      <button v-if="uploading" type="button" class="image-upload-tile__cancel" :disabled="disabled" :aria-label="`取消上传${item.name}`" @click="$emit('cancel', item)"><WorkbenchIcon name="/ic_public_close_line_8px" /></button>
    </div>
    <span v-if="showName" class="image-upload-tile__name" :title="item.name">{{ item.name }}</span>
  </li>
</template>

<style scoped>
.image-upload-tile { display: flex; flex: none; flex-direction: column; gap: var(--wb-asset-wb-image-upload-name-gap); width: var(--wb-asset-wb-image-upload-size); min-width: 0; }
.image-upload-tile__picture { position: relative; width: 100%; height: var(--wb-asset-wb-image-upload-size); border-radius: var(--wb-asset-wb-image-upload-radius); overflow: hidden; }
.image-upload-tile__picture > img { display: block; width: 100%; height: 100%; object-fit: cover; }
.image-upload-tile__status { position: absolute; inset: 0; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: var(--wb-asset-wb-image-upload-text-gap); color: var(--wb-asset-wb-image-upload-white); background: var(--wb-asset-wb-image-upload-mask); }
.image-upload-tile[data-status="uploading"] .image-upload-tile__ring { position: absolute; top: var(--wb-asset-wb-image-upload-progress-top); }
.image-upload-tile[data-status="uploading"] .image-upload-tile__status > span:last-child { position: absolute; top: var(--wb-asset-wb-image-upload-progress-label-top); }
.image-upload-tile[data-status="error"] .image-upload-tile__status { gap: var(--wb-asset-wb-image-upload-name-gap); }
/* Error status remains visible until its action overlay is intentionally opened. */
.image-upload-tile[data-status="error"] .image-upload-tile__actions { background: transparent; }
.image-upload-tile[data-status="error"]:not(.is-disabled) .image-upload-tile__picture:hover .image-upload-tile__status > *, .image-upload-tile[data-status="error"]:not(.is-disabled) .image-upload-tile__picture:focus-within .image-upload-tile__status > *, .image-upload-tile--hover[data-status="error"]:not(.is-disabled) .image-upload-tile__status > * { visibility: hidden; }
.image-upload-tile__ring { box-sizing: border-box; display: block; width: var(--wb-asset-wb-image-upload-ring-size); height: var(--wb-asset-wb-image-upload-ring-size); fill: none; stroke-width: var(--wb-asset-wb-image-upload-ring-width); animation: image-upload-spin var(--wb-asset-wb-image-upload-spin-duration) linear infinite; }
.image-upload-tile__ring-track { stroke: var(--wb-asset-wb-image-upload-ring-track); }
.image-upload-tile__ring-arc { stroke: var(--wb-asset-wb-image-upload-white); stroke-linecap: round; stroke-dasharray: 50 100; }
.image-upload-tile__actions { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; gap: var(--wb-asset-wb-image-upload-action-gap); color: var(--wb-asset-wb-image-upload-white); background: var(--wb-asset-wb-image-upload-mask); opacity: 0; pointer-events: none; }
.image-upload-tile__picture:hover .image-upload-tile__actions, .image-upload-tile__picture:focus-within .image-upload-tile__actions, .image-upload-tile--hover .image-upload-tile__actions { opacity: 1; pointer-events: auto; }
.image-upload-tile__actions--disabled { display: none; }
.image-upload-tile__actions button, .image-upload-tile__cancel { display: inline-flex; flex: none; align-items: center; justify-content: center; padding: 0; border: 0; background: transparent; color: inherit; cursor: pointer; }
.image-upload-tile__actions button { width: var(--wb-asset-wb-image-upload-icon-size); height: var(--wb-asset-wb-image-upload-icon-size); }
.image-upload-tile__actions button:focus-visible, .image-upload-tile__cancel:focus-visible { outline: 1px solid currentColor; outline-offset: 1px; }
.image-upload-tile__actions button:disabled, .image-upload-tile__cancel:disabled { cursor: not-allowed; }
.image-upload-tile__cancel { position: absolute; top: var(--wb-asset-wb-image-upload-cancel-inset); right: var(--wb-asset-wb-image-upload-cancel-inset); width: var(--wb-asset-wb-image-upload-cancel-size); height: var(--wb-asset-wb-image-upload-cancel-size); color: var(--wb-asset-wb-image-upload-white); opacity: 0; }
.image-upload-tile__picture:hover .image-upload-tile__cancel, .image-upload-tile__picture:focus-within .image-upload-tile__cancel, .image-upload-tile--hover .image-upload-tile__cancel { opacity: 1; }
.image-upload-tile__name { display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
@keyframes image-upload-spin { to { transform: rotate(360deg); } }
@media (prefers-reduced-motion: reduce) { .image-upload-tile__ring { animation: none; } }
@media (hover: none) { .image-upload-tile__actions, .image-upload-tile__cancel { opacity: 1; pointer-events: auto; } }
</style>
