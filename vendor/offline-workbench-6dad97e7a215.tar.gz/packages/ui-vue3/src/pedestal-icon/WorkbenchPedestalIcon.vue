<script>
import { pedestalIcons } from '../icons/families/pedestal.js';

export default { inheritAttrs: false, pedestalIconManifest: pedestalIcons.manifest };
</script>

<script setup>
import PedestalIcon from '../icons/pedestal/WorkbenchPedestalIcon.vue';

defineProps({
  name: { type: String, required: true },
  label: { type: String, default: '' },
  size: { type: Number, default: undefined, validator: (value) => [28, 48].includes(value) },
});
</script>

<template>
  <PedestalIcon
    :name="name"
    :label="label"
    :size="size"
  />
</template>
