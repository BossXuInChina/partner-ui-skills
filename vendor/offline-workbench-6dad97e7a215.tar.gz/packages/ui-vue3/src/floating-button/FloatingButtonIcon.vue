<script setup>
import { computed } from 'vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';

const props = defineProps({ item: { type: Object, required: true } });
const names = { headset: '客服', mobile: '下载App', policy: '政策', help: '帮助', rating: '评价', collapse: '收起', expand: '展开', top: '返回顶部' };
const semantic = computed(() => props.item.iconType === 'ai' ? '企业AI助手' : names[props.item.icon]);
const defaultName = computed(() => semantic.value ? `悬浮按钮/${semantic.value}_${props.item.iconType === 'ai' ? 36 : 20}px` : '/ic_public_plus_line_20px');
</script>

<template>
  <span class="floating-button-glyph">
    <WorkbenchIcon :name="defaultName" />
  </span>
</template>

<style scoped>
.floating-button-glyph { display: inline-flex; align-items: center; justify-content: center; }
</style>
