<script setup>
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
import { computed, nextTick, reactive, ref, useId } from 'vue';
import FloatingButtonIcon from './FloatingButtonIcon.vue';
import FloatingButtonPopover from './FloatingButtonPopover.vue';

const props = defineProps({
  variant: { type: String, default: 'single', validator: value => ['single', 'group'].includes(value) },
  items: { type: Array, default: () => [] },
  expanded: { type: Boolean, default: undefined },
  ratings: { type: Object, default: undefined },
  defaultVisibleCount: { type: Number, default: undefined },
  showBackToTop: { type: Boolean, default: false },
  ariaLabel: { type: String, default: '悬浮快捷操作' },
});
const emit = defineEmits(['update:expanded', 'action', 'back-to-top', 'rating-change', 'update:ratings']);
const instanceId = `wb-floating-button-${useId()}`;
const root = ref(null);
const internalRatings = reactive({});
const ratings = computed(() => props.ratings ?? internalRatings);
const internalExpanded = ref(false);
const resolvedExpanded = computed(() => props.expanded ?? internalExpanded.value);
const dismissedPopover = ref(false);
const focusedItemId = ref(null);
function focusItem(event, item) {
  if (event.target.matches(':focus-visible') || event.target.closest('.wb-floating-button__tooltip')) focusedItemId.value = item.id;
}
function enterPopover(event, item) {
  if (event.shiftKey || item.disabled || dismissedPopover.value) return;
  const popup = event.currentTarget.parentElement.querySelector('.wb-floating-button__tooltip');
  const control = popup?.querySelector('button:not(:disabled)[tabindex="0"], a[href], input:not(:disabled)');
  if (!control) return;
  event.preventDefault();
  focusedItemId.value = item.id;
  nextTick(() => control.focus());
}
function blurItem(event, item) {
  const wrapper = event.currentTarget;
  nextTick(() => { if (!wrapper.contains(document.activeElement) && focusedItemId.value === item.id) focusedItemId.value = null; });
}
function dismissPopover(event) {
  if (event.key !== 'Escape') return;
  dismissedPopover.value = true;
  const wrapper = event.target.closest('.wb-floating-button__item, .wb-floating-button__single, .wb-floating-button__back-to-top');
  wrapper?.querySelector('.wb-floating-button__action')?.focus();
  event.stopPropagation();
}
function resetPopover(event) {
  if (event.type === 'focusin' && root.value?.contains(event.relatedTarget)) return;
  dismissedPopover.value = false;
}
const singleItem = computed(() => props.items[0]);
const effectiveVariant = computed(() => props.variant === 'group' && props.items.length < 2 ? 'single' : props.variant);
const collapsedCount = computed(() => {
  if (!Number.isFinite(props.defaultVisibleCount)) return props.items.length;
  return Math.min(props.items.length, Math.max(0, Math.floor(props.defaultVisibleCount)));
});
const hasOverflowItems = computed(() => props.items.length > collapsedCount.value);
const visibleItems = computed(() => resolvedExpanded.value ? props.items : props.items.slice(0, collapsedCount.value));

function tooltipId(item, suffix = '') {
  return `${instanceId}-${item?.id ?? 'control'}${suffix}-tooltip`;
}
function activate(item) {
  if (!item?.disabled) emit('action', item);
}
function rate(item, score) {
  if (item.disabled || !Number.isInteger(score) || score < 0 || score > 10) return;
  if (props.ratings === undefined) internalRatings[item.id] = score;
  emit('update:ratings', { ...ratings.value, [item.id]: score });
  emit('rating-change', { item, score });
}
function toggleExpanded() {
  const next = !resolvedExpanded.value;
  if (props.expanded === undefined) internalExpanded.value = next;
  emit('update:expanded', next);
}
function nearestScrollContainer() {
  let element = root.value?.parentElement;
  while (element && element !== document.body) {
    const overflowY = getComputedStyle(element).overflowY;
    if (/(auto|scroll|overlay)/.test(overflowY) && element.scrollHeight > element.clientHeight) return element;
    element = element.parentElement;
  }
  return null;
}
function backToTop() {
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const options = { top: 0, behavior: reduced ? 'auto' : 'smooth' };
  const scrollContainer = nearestScrollContainer();
  if (scrollContainer) scrollContainer.scrollTo(options);
  else window.scrollTo(options);
  emit('back-to-top');
}
</script>

<template>
  <aside ref="root" class="wb-floating-button" :class="[`wb-floating-button--${effectiveVariant}`, { 'is-popover-dismissed': dismissedPopover }]" @keydown="dismissPopover" @pointerleave="resetPopover" @focusin="resetPopover" :aria-label="ariaLabel">
    <div v-if="effectiveVariant === 'single' && singleItem" class="wb-floating-button__single" :class="{ 'is-focus-open': focusedItemId === singleItem.id }" @focusin="focusItem($event, singleItem)" @focusout="blurItem($event, singleItem)" @pointerenter="dismissedPopover = false">
      <button
        type="button"
        class="wb-floating-button__action"
        :class="{ 'is-ai': singleItem.iconType === 'ai' }"
        :aria-label="singleItem.label"
        :aria-describedby="tooltipId(singleItem)"
        :disabled="singleItem.disabled"
        @click="activate(singleItem)"
        @keydown.tab="enterPopover($event, singleItem)"
      >
        <span class="wb-floating-button__icon" aria-hidden="true">
          <slot name="icon" :item="singleItem">
            <FloatingButtonIcon :item="singleItem" />
          </slot>
        </span>
      </button>
      <FloatingButtonPopover :item="singleItem" :tooltip-id="tooltipId(singleItem)" :rating="ratings[singleItem.id]" @rate="rate(singleItem, $event)"><template v-if="$slots[singleItem.popoverType]" #default><slot :name="singleItem.popoverType" :item="singleItem" /></template></FloatingButtonPopover>
    </div>

    <template v-else-if="effectiveVariant === 'group'">
      <div class="wb-floating-button__panel">
        <div v-for="item in visibleItems" :key="item.id" class="wb-floating-button__item" :class="{ 'is-focus-open': focusedItemId === item.id }" @focusin="focusItem($event, item)" @focusout="blurItem($event, item)" @pointerenter="dismissedPopover = false">
          <button
            type="button"
            class="wb-floating-button__action"
            :class="{ 'is-ai': item.iconType === 'ai' }"
            :aria-label="item.label"
            :aria-describedby="tooltipId(item)"
            :disabled="item.disabled"
            @click="activate(item)"
            @keydown.tab="enterPopover($event, item)"
          >
            <span class="wb-floating-button__icon" aria-hidden="true">
              <slot name="icon" :item="item">
                <FloatingButtonIcon :item="item" />
              </slot>
            </span>
          </button>
          <FloatingButtonPopover :item="item" :tooltip-id="tooltipId(item)" :rating="ratings[item.id]" @rate="rate(item, $event)"><template v-if="$slots[item.popoverType]" #default><slot :name="item.popoverType" :item="item" /></template></FloatingButtonPopover>
        </div>
        <div v-if="hasOverflowItems" class="wb-floating-button__item wb-floating-button__toggle-item">
          <button
            type="button"
            class="wb-floating-button__action wb-floating-button__toggle"
            :aria-label="resolvedExpanded ? '收起悬浮按钮组' : '展开悬浮按钮组'"
            :aria-expanded="resolvedExpanded"
            :aria-describedby="tooltipId(null, '-toggle')"
            @click="toggleExpanded"
          >
            <span class="wb-floating-button__icon" aria-hidden="true">
              <FloatingButtonIcon :item="{ icon: resolvedExpanded ? 'collapse' : 'expand' }" />
            </span>
          </button>
          <span :id="tooltipId(null, '-toggle')" class="wb-floating-button__tooltip" role="tooltip">{{ resolvedExpanded ? '收起' : '展开' }}</span>
        </div>
      </div>

      <div v-if="showBackToTop" class="wb-floating-button__back-to-top">
        <button type="button" class="wb-floating-button__action" aria-label="返回顶部" :aria-describedby="tooltipId(null, '-top')" @click="backToTop">
          <span class="wb-floating-button__icon" aria-hidden="true"><FloatingButtonIcon :item="{ icon: 'top' }" /></span>
        </button>
        <span :id="tooltipId(null, '-top')" class="wb-floating-button__tooltip" role="tooltip">返回顶部</span>
      </div>
    </template>
  </aside>
</template>

<style scoped>
.wb-floating-button { position: fixed; z-index: 20; right: var(--wb-asset-wb-floating-button-right-inset); bottom: var(--wb-asset-wb-floating-button-bottom-inset); color: var(--wb-color-icon-primary); }
.wb-floating-button__single, .wb-floating-button__item, .wb-floating-button__back-to-top { position: relative; }
.wb-floating-button__single, .wb-floating-button__back-to-top { width: var(--wb-asset-wb-floating-button-hit-size); height: var(--wb-asset-wb-floating-button-hit-size); border-radius: var(--wb-radius-lg); background: var(--wb-color-surface-card-default); box-shadow: var(--wb-shadow-sm); }
.wb-floating-button__single { border-radius: var(--wb-radius-full); }
.wb-floating-button__panel { overflow: visible; width: var(--wb-asset-wb-floating-button-hit-size); padding-block: var(--wb-asset-wb-floating-button-panel-padding-block); border-radius: var(--wb-radius-lg); background: var(--wb-color-surface-card-default); box-shadow: var(--wb-shadow-sm); }
.wb-floating-button__item + .wb-floating-button__item::before { position: absolute; z-index: 1; top: 0; right: 8px; left: 8px; height: var(--wb-asset-wb-floating-button-separator-size); background: var(--wb-color-border-separator-subtle); content: ''; }
.wb-floating-button__action { display: flex; width: var(--wb-asset-wb-floating-button-hit-size); height: var(--wb-asset-wb-floating-button-hit-size); align-items: center; justify-content: center; padding: 0; border: 0; border-radius: inherit; background: transparent; color: inherit; cursor: pointer; }
.wb-floating-button__panel .wb-floating-button__action { border-radius: 0; }
.wb-floating-button__single .wb-floating-button__action { border-radius: var(--wb-radius-full); }
.wb-floating-button__back-to-top .wb-floating-button__action { border-radius: var(--wb-radius-lg); }
.wb-floating-button__action:focus-visible { position: relative; z-index: 2; outline: 2px solid var(--wb-color-border-focus); outline-offset: 2px; }
.wb-floating-button__action:disabled { color: var(--wb-color-icon-disabled); cursor: not-allowed; }
.wb-floating-button__icon { display: inline-flex; width: var(--wb-asset-wb-floating-button-icon-size); height: var(--wb-asset-wb-floating-button-icon-size); align-items: center; justify-content: center; transform: scale(1); transform-origin: center; transition: transform var(--wb-asset-wb-floating-button-icon-motion-duration) ease-out; }
.wb-floating-button__action.is-ai .wb-floating-button__icon { width: var(--wb-asset-wb-floating-button-ai-icon-size); height: var(--wb-asset-wb-floating-button-ai-icon-size); }
.wb-floating-button__action:hover:not(:disabled) .wb-floating-button__icon, .wb-floating-button__action:focus-visible .wb-floating-button__icon { transform: scale(1.2); }
.wb-floating-button__action.is-ai:hover:not(:disabled) .wb-floating-button__icon, .wb-floating-button__action.is-ai:focus-visible .wb-floating-button__icon { transform: scale(1.1111111111); }
.wb-floating-button__tooltip { position: absolute; z-index: 3; top: 50%; right: calc(100% + var(--wb-asset-wb-floating-button-tooltip-gap)); display: grid; width: max-content; max-width: var(--wb-asset-wb-floating-button-tooltip-max-width); padding: var(--wb-asset-wb-floating-button-tooltip-padding-block) var(--wb-asset-wb-floating-button-tooltip-padding-inline); border-radius: var(--wb-radius-lg); background: var(--wb-color-surface-overlay); box-shadow: var(--wb-shadow-lg); color: var(--wb-color-text-primary); font-size: var(--wb-font-body-s-font-size); font-weight: var(--wb-font-body-s-font-weight); line-height: var(--wb-font-body-s-line-height); letter-spacing: var(--wb-font-body-s-letter-spacing); opacity: 0; pointer-events: none; transform: translateY(-50%); transition: opacity 100ms ease-out; visibility: hidden; white-space: nowrap; }
.wb-floating-button__tooltip.is-info { gap: var(--wb-spacing-component-xs); min-width: var(--wb-asset-wb-floating-button-info-min-width); white-space: normal; }
.wb-floating-button__tooltip.is-qrcode { justify-items: center; gap: var(--wb-spacing-component-sm); padding: var(--wb-spacing-component-lg); }
.wb-floating-button__tooltip.is-rating { gap: var(--wb-spacing-component-md); width: var(--wb-asset-wb-floating-button-rating-tooltip-width); max-width: none; padding: var(--wb-spacing-component-lg); white-space: normal; }
.wb-floating-button__tooltip :deep(strong) { font-size: var(--wb-font-body-m-font-size); font-weight: var(--wb-font-body-m-font-weight); line-height: var(--wb-font-body-m-line-height); letter-spacing: var(--wb-font-body-m-letter-spacing); }
.wb-floating-button__tooltip.is-info :deep(span), .wb-floating-button__tooltip :deep(.wb-floating-button__rating-help) { color: var(--wb-color-text-secondary); }
.wb-floating-button__tooltip :deep(.wb-floating-button__greeting) { margin: 0; }
.wb-floating-button__tooltip :deep(.wb-floating-button__qr) { display: block; width: var(--wb-asset-wb-floating-button-qr-size); height: var(--wb-asset-wb-floating-button-qr-size); color: var(--wb-color-icon-primary); }
.wb-floating-button__tooltip :deep(.wb-floating-button__scores) { display: grid; grid-template-columns: repeat(11, 1fr); gap: var(--wb-spacing-component-xs); }
.wb-floating-button__tooltip :deep(.wb-floating-button__scores button) { display: inline-flex; width: var(--wb-asset-wb-floating-button-rating-score-size); height: var(--wb-asset-wb-floating-button-rating-score-size); align-items: center; justify-content: center; padding: 0; border: 1px solid transparent; border-radius: var(--wb-radius-sm); background: var(--wb-color-fill-hover); color: var(--wb-color-text-primary); cursor: pointer; font: inherit; }
.wb-floating-button__tooltip :deep(.wb-floating-button__scores button.is-selected) { border-color: var(--wb-color-border-focus); }
.wb-floating-button__tooltip :deep(.wb-floating-button__scores button:focus-visible) { outline: 2px solid var(--wb-color-border-focus); outline-offset: 1px; }
.wb-floating-button__tooltip :deep(.wb-floating-button__rating-help) { display: flex; justify-content: space-between; }
.wb-floating-button__tooltip::before { position: absolute; top: 0; right: calc(var(--wb-asset-wb-floating-button-tooltip-gap) * -1); width: var(--wb-asset-wb-floating-button-tooltip-gap); height: 100%; content: ''; }
.wb-floating-button__tooltip::after { position: absolute; top: 50%; right: calc(var(--wb-asset-wb-floating-button-tooltip-arrow-width) * -1); width: var(--wb-asset-wb-floating-button-tooltip-arrow-width); height: var(--wb-asset-wb-floating-button-tooltip-arrow-height); background: var(--wb-color-surface-overlay); clip-path: polygon(0 0, 100% 50%, 0 100%); content: ''; transform: translateY(-50%); }
.is-focus-open > .wb-floating-button__tooltip, .wb-floating-button__single:hover .wb-floating-button__tooltip, .wb-floating-button__item:hover .wb-floating-button__tooltip, .wb-floating-button__back-to-top:hover .wb-floating-button__tooltip, .wb-floating-button__action:focus-visible + .wb-floating-button__tooltip, .wb-floating-button__tooltip:focus-within { opacity: 1; pointer-events: auto; visibility: visible; }
.wb-floating-button__back-to-top { position: absolute; top: calc(100% + var(--wb-asset-wb-floating-button-back-to-top-gap)); right: 0; }
@media (prefers-reduced-motion: reduce) { .wb-floating-button__icon, .wb-floating-button__tooltip { transition: none; } }
.wb-floating-button.is-popover-dismissed .wb-floating-button__tooltip,
.wb-floating-button__single:has(> button:disabled) .wb-floating-button__tooltip,
.wb-floating-button__item:has(> button:disabled) .wb-floating-button__tooltip { opacity: 0; pointer-events: none; visibility: hidden; }
</style>
