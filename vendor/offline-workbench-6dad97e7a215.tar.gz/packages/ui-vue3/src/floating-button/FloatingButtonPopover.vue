<script setup>
import '../../../../foundation/generated/runtime/foundation.css';
import '../../../../catalog/generated/asset.tokens.css';
const props = defineProps({ item: { type: Object, required: true }, tooltipId: { type: String, required: true }, rating: { type: Number, default: undefined } });
const emit = defineEmits(['rate']);
const scores = Array.from({ length: 11 }, (_, index) => index);
function onScoreKey(event, score) {
  const delta = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1 }[event.key];
  const next = event.key === 'Home' ? 0 : event.key === 'End' ? 10 : delta ? (score + delta + 11) % 11 : undefined;
  if (next === undefined || props.item.disabled) return;
  event.preventDefault();
  emit('rate', next);
  event.currentTarget.parentElement.children[next]?.focus();
}
</script>

<template>
  <div :id="tooltipId" class="wb-floating-button__tooltip" :class="`is-${item.popoverType || 'label'}`" :role="item.popoverType === 'rating' ? 'dialog' : 'tooltip'" :aria-label="item.label">
    <slot>
    <template v-if="item.popoverType === 'info'"><strong>{{ item.title }}</strong><span>{{ item.description }}</span></template>
    <template v-else-if="item.popoverType === 'rating'">
      <strong>{{ item.title }}</strong>
      <div class="wb-floating-button__scores" role="radiogroup" aria-label="产品页面整体评价分数">
        <button v-for="score in scores" :key="score" type="button" role="radio" :aria-checked="rating === score" :tabindex="score === (rating ?? 0) ? 0 : -1" :disabled="item.disabled" @keydown="onScoreKey($event, score)" :class="{ 'is-selected': rating === score }" @click.stop="emit('rate', score)">{{ score }}</button>
      </div>
      <div class="wb-floating-button__rating-help"><span>非常不满意</span><span>非常满意</span></div>
    </template>
    <template v-else>{{ item.description || item.label }}</template>
    </slot>
  </div>
</template>
