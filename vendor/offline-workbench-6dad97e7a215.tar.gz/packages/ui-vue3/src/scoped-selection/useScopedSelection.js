import { computed, ref, toValue, watch } from 'vue';

export function useScopedSelection({ scope, visibleIds, disabledIds = [] }) {
  const selectedIds = ref([]);
  const available = computed(() => {
    const disabled = new Set(toValue(disabledIds) || []);
    return [...new Set(toValue(visibleIds) || [])].filter((id) => !disabled.has(id));
  });
  const selectedVisible = computed(() =>
    available.value.filter((id) => selectedIds.value.includes(id)),
  );
  const selectedCount = computed(() => selectedVisible.value.length);
  const checked = computed(
    () => available.value.length > 0 && selectedCount.value === available.value.length,
  );
  const indeterminate = computed(() => selectedCount.value > 0 && !checked.value);
  function clear() {
    selectedIds.value = [];
  }
  function toggle(id, checkedValue) {
    if (!available.value.includes(id)) return;
    selectedIds.value = checkedValue
      ? [...new Set([...selectedIds.value, id])]
      : selectedIds.value.filter((item) => item !== id);
  }
  function toggleAll(checkedValue) {
    const visible = new Set(available.value);
    selectedIds.value = checkedValue
      ? [...new Set([...selectedIds.value, ...available.value])]
      : selectedIds.value.filter((id) => !visible.has(id));
  }
  watch(() => toValue(scope), clear, { flush: 'sync' });
  watch(
    available,
    (ids) => {
      const valid = new Set(ids);
      selectedIds.value = selectedIds.value.filter((id) => valid.has(id));
    },
    { flush: 'sync' },
  );
  return { selectedIds, selectedCount, checked, indeterminate, toggle, toggleAll, clear };
}

export default useScopedSelection;
