<script setup lang="ts">
import { useSlots, type PropType } from 'vue';
import { hasSlotContent } from '../card-block/slots';
const slots = useSlots();
const has = (name: string, scope: Record<string, unknown> = {}) =>
  hasSlotContent(slots, name, scope);
import BlockFrame from '../card-block/BlockFrame.vue';
import type {
  CardSize,
  CardAction,
  CardFooter,
  CardActionEvent,
  CardLayout,
  MetricItem,
} from '../../types/card-blocks';
defineProps({
  title: { type: String, default: '' },
  variant: {
    type: String as PropType<'display-white'>,
    default: 'display-white',
    validator: (value: string) => ['display-white'].includes(value),
  },
  size: {
    type: String as PropType<CardSize>,
    default: 'xxxl',
    validator: (value: string) => ['s', 'm', 'l', 'xl', 'xxl', 'xxxl'].includes(value),
  },
  href: { type: String, default: undefined },
  target: { type: String, default: undefined },
  rel: { type: String, default: undefined },
  headerActions: { type: Array as PropType<CardAction[]>, default: () => [] },
  footer: { type: Object as PropType<CardFooter | null>, default: null },
  actions: { type: Array as PropType<CardAction[]>, default: () => [] },
  layout: {
    type: String as PropType<CardLayout>,
    default: 'row',
    validator: (value: string) => ['row', 'multi', 'column'].includes(value),
  },
  labelPosition: {
    type: String as PropType<'above' | 'below'>,
    default: 'below',
    validator: (value: string) => ['above', 'below'].includes(value),
  },
  items: { type: Array as PropType<MetricItem[]>, default: () => [] },
});
const emit = defineEmits({ action: (_payload: CardActionEvent) => true });
</script>
<template>
  <BlockFrame
    v-bind="$props"
    variant="display-white"
    class="wbc-metric-card"
    :class="{ 'wbc-card--narrow': layout === 'column' }"
    data-card-block="metrics"
    @action="emit('action', $event)"
  >
    <template #header
      ><slot
        v-if="has('header')"
        name="header"
    /></template>
    <template #header-actions
      ><slot
        v-if="has('header-actions')"
        name="header-actions"
    /></template>
    <template #footer
      ><slot
        v-if="has('footer')"
        name="footer"
    /></template>
    <template #actions
      ><slot
        v-if="has('actions')"
        name="actions"
    /></template>
    <div
      v-if="items.length"
      class="wbc-metrics"
      :class="`wbc-metrics--${layout}`"
    >
      <div
        v-for="(item, index) in items"
        :key="item.id || index"
        class="wbc-metric"
      >
        <slot
          v-if="has('item', { item, index })"
          name="item"
          :item="item"
          :index="index"
        />
        <template v-else>
          <slot
            v-if="has('icon', { item, index })"
            name="icon"
            :item="item"
            :index="index"
          />
          <div
            class="wbc-metric-copy"
            :class="{
              'wbc-metric-copy--truncate': item.truncate,
              'wbc-metric-copy--label-above': labelPosition === 'above',
            }"
          >
            <strong :title="String(item.value ?? '—')">{{ item.value ?? '—' }}</strong
            ><span :title="item.label">{{ item.label }}</span>
          </div>
        </template>
      </div>
    </div>
    <slot
      v-else-if="has('empty')"
      name="empty"
    />
    <p
      v-else
      class="wbc-empty"
    >
      暂无数据
    </p>
  </BlockFrame>
</template>
