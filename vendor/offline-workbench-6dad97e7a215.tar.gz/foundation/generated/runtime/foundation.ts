/* Generated from Workbench Foundation. Do not edit. */
export const foundationRuntime = {
  "schemaVersion": "1.0",
  "product": "workbench",
  "foundationVersion": "1.1.0",
  "sourceLockDigest": "sha256:df72f5c041c76784c6ee282b69dbb702e34f5b253b1e75c7195ee3a182c8bd7c",
  "authoringContractDigest": "sha256:cee5bfcda42a31642d3a2027913a7a7a5d38f4b7cf3910c1ce9470712dd874a9",
  "runtimeRecordCount": 155,
  "primitiveInventoryExported": false,
  "requiredTargetMappings": [
    {
      "foundationKey": "font-family-sans-en",
      "kind": "font-family-contract",
      "designName": "HarmonyOS Sans",
      "platformFallback": "Windows：Arial；macOS：San Francisco；最终 `sans-serif`"
    },
    {
      "foundationKey": "font-family-sans-zh",
      "kind": "font-family-contract",
      "designName": "鸿蒙黑体",
      "platformFallback": "Windows：Microsoft YaHei；macOS：PingFang SC；最终 `sans-serif`"
    }
  ],
  "records": [
    {
      "foundationKey": "color-alert",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#F4840C",
        "opacity": "100%",
        "css": "rgb(244 132 12 / 100%)"
      },
      "dark": {
        "color": "#F4840C",
        "opacity": "100%",
        "css": "rgb(244 132 12 / 100%)"
      }
    },
    {
      "foundationKey": "color-alert-hover",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#F69E39",
        "opacity": "100%",
        "css": "rgb(246 158 57 / 100%)"
      },
      "dark": {
        "color": "#F69E39",
        "opacity": "100%",
        "css": "rgb(246 158 57 / 100%)"
      }
    },
    {
      "foundationKey": "color-alert-subtle",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#FEF5E8",
        "opacity": "100%",
        "css": "rgb(254 245 232 / 100%)"
      },
      "dark": {
        "color": "#642802",
        "opacity": "100%",
        "css": "rgb(100 40 2 / 100%)"
      }
    },
    {
      "foundationKey": "color-border",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#C9C9C9",
        "opacity": "100%",
        "css": "rgb(201 201 201 / 100%)"
      },
      "dark": {
        "color": "#777777",
        "opacity": "100%",
        "css": "rgb(119 119 119 / 100%)"
      }
    },
    {
      "foundationKey": "color-border-disabled",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#C9C9C9",
        "opacity": "100%",
        "css": "rgb(201 201 201 / 100%)"
      },
      "dark": {
        "color": "#595959",
        "opacity": "100%",
        "css": "rgb(89 89 89 / 100%)"
      }
    },
    {
      "foundationKey": "color-border-focus",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#191919",
        "opacity": "100%",
        "css": "rgb(25 25 25 / 100%)"
      },
      "dark": {
        "color": "#F3F3F3",
        "opacity": "100%",
        "css": "rgb(243 243 243 / 100%)"
      }
    },
    {
      "foundationKey": "color-border-hover",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#191919",
        "opacity": "100%",
        "css": "rgb(25 25 25 / 100%)"
      },
      "dark": {
        "color": "#F3F3F3",
        "opacity": "100%",
        "css": "rgb(243 243 243 / 100%)"
      }
    },
    {
      "foundationKey": "color-border-separator",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#DFDFDF",
        "opacity": "100%",
        "css": "rgb(223 223 223 / 100%)"
      },
      "dark": {
        "color": "#F3F3F3",
        "opacity": "15%",
        "css": "rgb(243 243 243 / 15%)"
      }
    },
    {
      "foundationKey": "color-border-separator-subtle",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#F3F3F3",
        "opacity": "100%",
        "css": "rgb(243 243 243 / 100%)"
      },
      "dark": {
        "color": "#F3F3F3",
        "opacity": "10%",
        "css": "rgb(243 243 243 / 10%)"
      }
    },
    {
      "foundationKey": "color-brand",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#C7000B",
        "opacity": "100%",
        "css": "rgb(199 0 11 / 100%)"
      },
      "dark": {
        "color": "#C7000B",
        "opacity": "100%",
        "css": "rgb(199 0 11 / 100%)"
      }
    },
    {
      "foundationKey": "color-brand-active",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#850F12",
        "opacity": "100%",
        "css": "rgb(133 15 18 / 100%)"
      },
      "dark": {
        "color": "#E02128",
        "opacity": "100%",
        "css": "rgb(224 33 40 / 100%)"
      }
    },
    {
      "foundationKey": "color-brand-disabled",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#F59297",
        "opacity": "100%",
        "css": "rgb(245 146 151 / 100%)"
      },
      "dark": {
        "color": "#E7434A",
        "opacity": "100%",
        "css": "rgb(231 67 74 / 100%)"
      }
    },
    {
      "foundationKey": "color-brand-focus",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#C7000B",
        "opacity": "100%",
        "css": "rgb(199 0 11 / 100%)"
      },
      "dark": {
        "color": "#C7000B",
        "opacity": "100%",
        "css": "rgb(199 0 11 / 100%)"
      }
    },
    {
      "foundationKey": "color-brand-hover",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#E02128",
        "opacity": "100%",
        "css": "rgb(224 33 40 / 100%)"
      },
      "dark": {
        "color": "#EE696F",
        "opacity": "100%",
        "css": "rgb(238 105 111 / 100%)"
      }
    },
    {
      "foundationKey": "color-card-default-fill-disabled",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#FFFFFF",
        "opacity": "50%",
        "css": "rgb(255 255 255 / 50%)"
      },
      "dark": {
        "color": "#939393",
        "opacity": "10%",
        "css": "rgb(147 147 147 / 10%)"
      }
    },
    {
      "foundationKey": "color-card-tinted-fill-disabled",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#AEAEAE",
        "opacity": "5%",
        "css": "rgb(174 174 174 / 5%)"
      },
      "dark": {
        "color": "#FFFFFF",
        "opacity": "50%",
        "css": "rgb(255 255 255 / 50%)"
      }
    },
    {
      "foundationKey": "color-error",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#E02128",
        "opacity": "100%",
        "css": "rgb(224 33 40 / 100%)"
      },
      "dark": {
        "color": "#E7434A",
        "opacity": "100%",
        "css": "rgb(231 67 74 / 100%)"
      }
    },
    {
      "foundationKey": "color-error-hover",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#E7434A",
        "opacity": "100%",
        "css": "rgb(231 67 74 / 100%)"
      },
      "dark": {
        "color": "#EE696F",
        "opacity": "100%",
        "css": "rgb(238 105 111 / 100%)"
      }
    },
    {
      "foundationKey": "color-error-subtle",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#FEE7E8",
        "opacity": "100%",
        "css": "rgb(254 231 232 / 100%)"
      },
      "dark": {
        "color": "#EE0022",
        "opacity": "40%",
        "css": "rgb(238 0 34 / 40%)"
      }
    },
    {
      "foundationKey": "color-fill-default",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#191919",
        "opacity": "5%",
        "css": "rgb(25 25 25 / 5%)"
      },
      "dark": {
        "color": "#F3F3F3",
        "opacity": "20%",
        "css": "rgb(243 243 243 / 20%)"
      }
    },
    {
      "foundationKey": "color-fill-disabled",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#DFDFDF",
        "opacity": "100%",
        "css": "rgb(223 223 223 / 100%)"
      },
      "dark": {
        "color": "#595959",
        "opacity": "100%",
        "css": "rgb(89 89 89 / 100%)"
      }
    },
    {
      "foundationKey": "color-fill-hover",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#191919",
        "opacity": "5%",
        "css": "rgb(25 25 25 / 5%)"
      },
      "dark": {
        "color": "#F3F3F3",
        "opacity": "20%",
        "css": "rgb(243 243 243 / 20%)"
      }
    },
    {
      "foundationKey": "color-fill-selected",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#191919",
        "opacity": "5%",
        "css": "rgb(25 25 25 / 5%)"
      },
      "dark": {
        "color": "#F3F3F3",
        "opacity": "20%",
        "css": "rgb(243 243 243 / 20%)"
      }
    },
    {
      "foundationKey": "color-fill-subtle-default",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#FFFFFF",
        "opacity": "100%",
        "css": "rgb(255 255 255 / 100%)"
      },
      "dark": {
        "color": "#000000",
        "opacity": "0%",
        "css": "rgb(0 0 0 / 0%)"
      }
    },
    {
      "foundationKey": "color-fill-subtle-disabled",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#191919",
        "opacity": "5%",
        "css": "rgb(25 25 25 / 5%)"
      },
      "dark": {
        "color": "#F3F3F3",
        "opacity": "20%",
        "css": "rgb(243 243 243 / 20%)"
      }
    },
    {
      "foundationKey": "color-icon-active",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#191919",
        "opacity": "100%",
        "css": "rgb(25 25 25 / 100%)"
      },
      "dark": {
        "color": "#DFDFDF",
        "opacity": "100%",
        "css": "rgb(223 223 223 / 100%)"
      }
    },
    {
      "foundationKey": "color-icon-disabled",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#C9C9C9",
        "opacity": "100%",
        "css": "rgb(201 201 201 / 100%)"
      },
      "dark": {
        "color": "#939393",
        "opacity": "100%",
        "css": "rgb(147 147 147 / 100%)"
      }
    },
    {
      "foundationKey": "color-icon-hover",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#595959",
        "opacity": "100%",
        "css": "rgb(89 89 89 / 100%)"
      },
      "dark": {
        "color": "#595959",
        "opacity": "100%",
        "css": "rgb(89 89 89 / 100%)"
      }
    },
    {
      "foundationKey": "color-icon-inverse",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#FFFFFF",
        "opacity": "100%",
        "css": "rgb(255 255 255 / 100%)"
      },
      "dark": {
        "color": "#000000",
        "opacity": "100%",
        "css": "rgb(0 0 0 / 100%)"
      }
    },
    {
      "foundationKey": "color-icon-placeholder",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#AEAEAE",
        "opacity": "100%",
        "css": "rgb(174 174 174 / 100%)"
      },
      "dark": {
        "color": "#939393",
        "opacity": "100%",
        "css": "rgb(147 147 147 / 100%)"
      }
    },
    {
      "foundationKey": "color-icon-primary",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#191919",
        "opacity": "100%",
        "css": "rgb(25 25 25 / 100%)"
      },
      "dark": {
        "color": "#DFDFDF",
        "opacity": "100%",
        "css": "rgb(223 223 223 / 100%)"
      }
    },
    {
      "foundationKey": "color-icon-secondary",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#777777",
        "opacity": "100%",
        "css": "rgb(119 119 119 / 100%)"
      },
      "dark": {
        "color": "#AEAEAE",
        "opacity": "100%",
        "css": "rgb(174 174 174 / 100%)"
      }
    },
    {
      "foundationKey": "color-icon-tertiary",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#939393",
        "opacity": "100%",
        "css": "rgb(147 147 147 / 100%)"
      },
      "dark": {
        "color": "#777777",
        "opacity": "100%",
        "css": "rgb(119 119 119 / 100%)"
      }
    },
    {
      "foundationKey": "color-info-disabled",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#D0D8FD",
        "opacity": "100%",
        "css": "rgb(208 216 253 / 100%)"
      },
      "dark": {
        "color": "#2070F3",
        "opacity": "60%",
        "css": "rgb(32 112 243 / 60%)"
      }
    },
    {
      "foundationKey": "color-info-gray",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#191919",
        "opacity": "5%",
        "css": "rgb(25 25 25 / 5%)"
      },
      "dark": {
        "color": "#F3F3F3",
        "opacity": "20%",
        "css": "rgb(243 243 243 / 20%)"
      }
    },
    {
      "foundationKey": "color-info-primary",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#2070F3",
        "opacity": "100%",
        "css": "rgb(32 112 243 / 100%)"
      },
      "dark": {
        "color": "#2070F3",
        "opacity": "100%",
        "css": "rgb(32 112 243 / 100%)"
      }
    },
    {
      "foundationKey": "color-info-primary-active",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#1F55B5",
        "opacity": "100%",
        "css": "rgb(31 85 181 / 100%)"
      },
      "dark": {
        "color": "#1F55B5",
        "opacity": "100%",
        "css": "rgb(31 85 181 / 100%)"
      }
    },
    {
      "foundationKey": "color-info-primary-hover",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#668CF7",
        "opacity": "100%",
        "css": "rgb(102 140 247 / 100%)"
      },
      "dark": {
        "color": "#668CF7",
        "opacity": "100%",
        "css": "rgb(102 140 247 / 100%)"
      }
    },
    {
      "foundationKey": "color-info-primary-subtle",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#8CA3FA",
        "opacity": "100%",
        "css": "rgb(140 163 250 / 100%)"
      },
      "dark": {
        "color": "#1F55B5",
        "opacity": "100%",
        "css": "rgb(31 85 181 / 100%)"
      }
    },
    {
      "foundationKey": "color-info-primary-subtler",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#EEF3FE",
        "opacity": "100%",
        "css": "rgb(238 243 254 / 100%)"
      },
      "dark": {
        "color": "#112857",
        "opacity": "100%",
        "css": "rgb(17 40 87 / 100%)"
      }
    },
    {
      "foundationKey": "color-info-secondary",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#8CA3FA",
        "opacity": "100%",
        "css": "rgb(140 163 250 / 100%)"
      },
      "dark": {
        "color": "#1F55B5",
        "opacity": "100%",
        "css": "rgb(31 85 181 / 100%)"
      }
    },
    {
      "foundationKey": "color-info-secondary-active",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#668CF7",
        "opacity": "100%",
        "css": "rgb(102 140 247 / 100%)"
      },
      "dark": {
        "color": "#1F55B5",
        "opacity": "100%",
        "css": "rgb(31 85 181 / 100%)"
      }
    },
    {
      "foundationKey": "color-info-secondary-hover",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#B0BFFD",
        "opacity": "100%",
        "css": "rgb(176 191 253 / 100%)"
      },
      "dark": {
        "color": "#668CF7",
        "opacity": "100%",
        "css": "rgb(102 140 247 / 100%)"
      }
    },
    {
      "foundationKey": "color-info-secondary-subtle",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#EEF3FE",
        "opacity": "100%",
        "css": "rgb(238 243 254 / 100%)"
      },
      "dark": {
        "color": "#112857",
        "opacity": "100%",
        "css": "rgb(17 40 87 / 100%)"
      }
    },
    {
      "foundationKey": "color-link",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#0067D1",
        "opacity": "100%",
        "css": "rgb(0 103 209 / 100%)"
      },
      "dark": {
        "color": "#5CA2E9",
        "opacity": "100%",
        "css": "rgb(92 162 233 / 100%)"
      }
    },
    {
      "foundationKey": "color-link-active",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#004EA8",
        "opacity": "100%",
        "css": "rgb(0 78 168 / 100%)"
      },
      "dark": {
        "color": "#0067D1",
        "opacity": "100%",
        "css": "rgb(0 103 209 / 100%)"
      }
    },
    {
      "foundationKey": "color-link-disabled",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#8ABEF3",
        "opacity": "100%",
        "css": "rgb(138 190 243 / 100%)"
      },
      "dark": {
        "color": "#004EA8",
        "opacity": "100%",
        "css": "rgb(0 78 168 / 100%)"
      }
    },
    {
      "foundationKey": "color-link-hover",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#2E86DE",
        "opacity": "100%",
        "css": "rgb(46 134 222 / 100%)"
      },
      "dark": {
        "color": "#8ABEF3",
        "opacity": "100%",
        "css": "rgb(138 190 243 / 100%)"
      }
    },
    {
      "foundationKey": "color-neutral",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#191919",
        "opacity": "5%",
        "css": "rgb(25 25 25 / 5%)"
      },
      "dark": {
        "color": "#F3F3F3",
        "opacity": "20%",
        "css": "rgb(243 243 243 / 20%)"
      }
    },
    {
      "foundationKey": "color-none",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#AEAEAE",
        "opacity": "100%",
        "css": "rgb(174 174 174 / 100%)"
      },
      "dark": {
        "color": "#595959",
        "opacity": "100%",
        "css": "rgb(89 89 89 / 100%)"
      }
    },
    {
      "foundationKey": "color-none-hover",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#C9C9C9",
        "opacity": "100%",
        "css": "rgb(201 201 201 / 100%)"
      },
      "dark": {
        "color": "#F3F3F3",
        "opacity": "20%",
        "css": "rgb(243 243 243 / 20%)"
      }
    },
    {
      "foundationKey": "color-none-subtle",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#F3F3F3",
        "opacity": "100%",
        "css": "rgb(243 243 243 / 100%)"
      },
      "dark": {
        "color": "#191919",
        "opacity": "100%",
        "css": "rgb(25 25 25 / 100%)"
      }
    },
    {
      "foundationKey": "color-radio-group-fill-selected",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#FFFFFF",
        "opacity": "100%",
        "css": "rgb(255 255 255 / 100%)"
      },
      "dark": {
        "color": "#000000",
        "opacity": "100%",
        "css": "rgb(0 0 0 / 100%)"
      }
    },
    {
      "foundationKey": "color-radio-group-text-selected",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#191919",
        "opacity": "100%",
        "css": "rgb(25 25 25 / 100%)"
      },
      "dark": {
        "color": "#FFFFFF",
        "opacity": "100%",
        "css": "rgb(255 255 255 / 100%)"
      }
    },
    {
      "foundationKey": "color-scrim-modal",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#191919",
        "opacity": "30%",
        "css": "rgb(25 25 25 / 30%)"
      },
      "dark": {
        "color": "#000000",
        "opacity": "70%",
        "css": "rgb(0 0 0 / 70%)"
      }
    },
    {
      "foundationKey": "color-scrollbar-thumb-fill-hover",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#AEAEAE",
        "opacity": "100%",
        "css": "rgb(174 174 174 / 100%)"
      },
      "dark": {
        "color": "#939393",
        "opacity": "100%",
        "css": "rgb(147 147 147 / 100%)"
      }
    },
    {
      "foundationKey": "color-sidebar-submenu-fill-expanded",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#F3F3F3",
        "opacity": "50%",
        "css": "rgb(243 243 243 / 50%)"
      },
      "dark": {
        "color": "#939393",
        "opacity": "5%",
        "css": "rgb(147 147 147 / 5%)"
      }
    },
    {
      "foundationKey": "color-success",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#09AA71",
        "opacity": "100%",
        "css": "rgb(9 170 113 / 100%)"
      },
      "dark": {
        "color": "#36C18D",
        "opacity": "100%",
        "css": "rgb(54 193 141 / 100%)"
      }
    },
    {
      "foundationKey": "color-success-hover",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#36C18D",
        "opacity": "100%",
        "css": "rgb(54 193 141 / 100%)"
      },
      "dark": {
        "color": "#09AA71",
        "opacity": "100%",
        "css": "rgb(9 170 113 / 100%)"
      }
    },
    {
      "foundationKey": "color-success-primary-subtle",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#E7FBF2",
        "opacity": "100%",
        "css": "rgb(231 251 242 / 100%)"
      },
      "dark": {
        "color": "#02422E",
        "opacity": "100%",
        "css": "rgb(2 66 46 / 100%)"
      }
    },
    {
      "foundationKey": "color-surface-card-default",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#FFFFFF",
        "opacity": "100%",
        "css": "rgb(255 255 255 / 100%)"
      },
      "dark": {
        "color": "#F3F3F3",
        "opacity": "10%",
        "css": "rgb(243 243 243 / 10%)"
      }
    },
    {
      "foundationKey": "color-surface-card-tinted",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#777777",
        "opacity": "5%",
        "css": "rgb(119 119 119 / 5%)"
      },
      "dark": {
        "color": "#F3F3F3",
        "opacity": "10%",
        "css": "rgb(243 243 243 / 10%)"
      }
    },
    {
      "foundationKey": "color-surface-container",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#FFFFFF",
        "opacity": "100%",
        "css": "rgb(255 255 255 / 100%)"
      },
      "dark": {
        "color": "#191919",
        "opacity": "100%",
        "css": "rgb(25 25 25 / 100%)"
      }
    },
    {
      "foundationKey": "color-surface-elevated",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#FFFFFF",
        "opacity": "100%",
        "css": "rgb(255 255 255 / 100%)"
      },
      "dark": {
        "color": "#393939",
        "opacity": "100%",
        "css": "rgb(57 57 57 / 100%)"
      }
    },
    {
      "foundationKey": "color-surface-overlay",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#FFFFFF",
        "opacity": "100%",
        "css": "rgb(255 255 255 / 100%)"
      },
      "dark": {
        "color": "#2A2A2A",
        "opacity": "100%",
        "css": "rgb(42 42 42 / 100%)"
      }
    },
    {
      "foundationKey": "color-surface-page",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#F3F3F3",
        "opacity": "100%",
        "css": "rgb(243 243 243 / 100%)"
      },
      "dark": {
        "color": "#000000",
        "opacity": "100%",
        "css": "rgb(0 0 0 / 100%)"
      }
    },
    {
      "foundationKey": "color-table-header-fill-default",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#191919",
        "opacity": "5%",
        "css": "rgb(25 25 25 / 5%)"
      },
      "dark": {
        "color": "#F3F3F3",
        "opacity": "10%",
        "css": "rgb(243 243 243 / 10%)"
      }
    },
    {
      "foundationKey": "color-table-header-sticky-fill-default",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#F3F3F3",
        "opacity": "100%",
        "css": "rgb(243 243 243 / 100%)"
      },
      "dark": {
        "color": "#393939",
        "opacity": "100%",
        "css": "rgb(57 57 57 / 100%)"
      }
    },
    {
      "foundationKey": "color-table-row-fill-alternating",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#939393",
        "opacity": "5%",
        "css": "rgb(147 147 147 / 5%)"
      },
      "dark": {
        "color": "#777777",
        "opacity": "15%",
        "css": "rgb(119 119 119 / 15%)"
      }
    },
    {
      "foundationKey": "color-text-action",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#0067D1",
        "opacity": "100%",
        "css": "rgb(0 103 209 / 100%)"
      },
      "dark": {
        "color": "#FFFFFF",
        "opacity": "100%",
        "css": "rgb(255 255 255 / 100%)"
      }
    },
    {
      "foundationKey": "color-text-action-active",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#004EA8",
        "opacity": "100%",
        "css": "rgb(0 78 168 / 100%)"
      },
      "dark": {
        "color": "#0067D1",
        "opacity": "100%",
        "css": "rgb(0 103 209 / 100%)"
      }
    },
    {
      "foundationKey": "color-text-action-disabled",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#8ABEF3",
        "opacity": "100%",
        "css": "rgb(138 190 243 / 100%)"
      },
      "dark": {
        "color": "#004EA8",
        "opacity": "100%",
        "css": "rgb(0 78 168 / 100%)"
      }
    },
    {
      "foundationKey": "color-text-action-hover",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#2E86DE",
        "opacity": "100%",
        "css": "rgb(46 134 222 / 100%)"
      },
      "dark": {
        "color": "#8ABEF3",
        "opacity": "100%",
        "css": "rgb(138 190 243 / 100%)"
      }
    },
    {
      "foundationKey": "color-text-disabled",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#C9C9C9",
        "opacity": "100%",
        "css": "rgb(201 201 201 / 100%)"
      },
      "dark": {
        "color": "#939393",
        "opacity": "100%",
        "css": "rgb(147 147 147 / 100%)"
      }
    },
    {
      "foundationKey": "color-text-inverse",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#FFFFFF",
        "opacity": "100%",
        "css": "rgb(255 255 255 / 100%)"
      },
      "dark": {
        "color": "#FFFFFF",
        "opacity": "100%",
        "css": "rgb(255 255 255 / 100%)"
      }
    },
    {
      "foundationKey": "color-text-placeholder",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#AEAEAE",
        "opacity": "100%",
        "css": "rgb(174 174 174 / 100%)"
      },
      "dark": {
        "color": "#939393",
        "opacity": "100%",
        "css": "rgb(147 147 147 / 100%)"
      }
    },
    {
      "foundationKey": "color-text-primary",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#191919",
        "opacity": "100%",
        "css": "rgb(25 25 25 / 100%)"
      },
      "dark": {
        "color": "#FFFFFF",
        "opacity": "100%",
        "css": "rgb(255 255 255 / 100%)"
      }
    },
    {
      "foundationKey": "color-text-secondary",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#777777",
        "opacity": "100%",
        "css": "rgb(119 119 119 / 100%)"
      },
      "dark": {
        "color": "#C9C9C9",
        "opacity": "100%",
        "css": "rgb(201 201 201 / 100%)"
      }
    },
    {
      "foundationKey": "color-warning",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#FCC800",
        "opacity": "100%",
        "css": "rgb(252 200 0 / 100%)"
      },
      "dark": {
        "color": "#FCD72E",
        "opacity": "100%",
        "css": "rgb(252 215 46 / 100%)"
      }
    },
    {
      "foundationKey": "color-warning-hover",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#FCD72E",
        "opacity": "100%",
        "css": "rgb(252 215 46 / 100%)"
      },
      "dark": {
        "color": "#FDE55C",
        "opacity": "100%",
        "css": "rgb(253 229 92 / 100%)"
      }
    },
    {
      "foundationKey": "color-warning-subtle",
      "domain": "color",
      "kind": "themed-color",
      "light": {
        "color": "#FEFCE0",
        "opacity": "100%",
        "css": "rgb(254 252 224 / 100%)"
      },
      "dark": {
        "color": "#614500",
        "opacity": "100%",
        "css": "rgb(97 69 0 / 100%)"
      }
    },
    {
      "foundationKey": "font-body-l",
      "domain": "typography",
      "kind": "typography-style",
      "fontSize": "16px",
      "fontWeight": "400",
      "lineHeight": "24px",
      "letterSpacing": "0em"
    },
    {
      "foundationKey": "font-body-m",
      "domain": "typography",
      "kind": "typography-style",
      "fontSize": "14px",
      "fontWeight": "400",
      "lineHeight": "22px",
      "letterSpacing": "0em"
    },
    {
      "foundationKey": "font-body-s",
      "domain": "typography",
      "kind": "typography-style",
      "fontSize": "12px",
      "fontWeight": "400",
      "lineHeight": "20px",
      "letterSpacing": "0em"
    },
    {
      "foundationKey": "font-caption-m",
      "domain": "typography",
      "kind": "typography-style",
      "fontSize": "12px",
      "fontWeight": "400",
      "lineHeight": "20px",
      "letterSpacing": "0em"
    },
    {
      "foundationKey": "font-caption-s",
      "domain": "typography",
      "kind": "typography-style",
      "fontSize": "10px",
      "fontWeight": "400",
      "lineHeight": "18px",
      "letterSpacing": "0em"
    },
    {
      "foundationKey": "font-display-l",
      "domain": "typography",
      "kind": "typography-style",
      "fontSize": "60px",
      "fontWeight": "500",
      "lineHeight": "76px",
      "letterSpacing": "0em"
    },
    {
      "foundationKey": "font-display-m",
      "domain": "typography",
      "kind": "typography-style",
      "fontSize": "48px",
      "fontWeight": "500",
      "lineHeight": "64px",
      "letterSpacing": "0em"
    },
    {
      "foundationKey": "font-display-s",
      "domain": "typography",
      "kind": "typography-style",
      "fontSize": "36px",
      "fontWeight": "500",
      "lineHeight": "52px",
      "letterSpacing": "0em"
    },
    {
      "foundationKey": "font-display-xl",
      "domain": "typography",
      "kind": "typography-style",
      "fontSize": "72px",
      "fontWeight": "500",
      "lineHeight": "88px",
      "letterSpacing": "0em"
    },
    {
      "foundationKey": "font-display-xs",
      "domain": "typography",
      "kind": "typography-style",
      "fontSize": "24px",
      "fontWeight": "500",
      "lineHeight": "40px",
      "letterSpacing": "0em"
    },
    {
      "foundationKey": "font-family-sans-en",
      "domain": "typography",
      "kind": "font-family-contract",
      "designName": "HarmonyOS Sans",
      "platformFallback": "Windows：Arial；macOS：San Francisco；最终 `sans-serif`",
      "requiresTargetMapping": true
    },
    {
      "foundationKey": "font-family-sans-zh",
      "domain": "typography",
      "kind": "font-family-contract",
      "designName": "鸿蒙黑体",
      "platformFallback": "Windows：Microsoft YaHei；macOS：PingFang SC；最终 `sans-serif`",
      "requiresTargetMapping": true
    },
    {
      "foundationKey": "font-headline-l",
      "domain": "typography",
      "kind": "typography-style",
      "fontSize": "20px",
      "fontWeight": "500",
      "lineHeight": "28px",
      "letterSpacing": "0em"
    },
    {
      "foundationKey": "font-headline-m",
      "domain": "typography",
      "kind": "typography-style",
      "fontSize": "18px",
      "fontWeight": "500",
      "lineHeight": "26px",
      "letterSpacing": "0em"
    },
    {
      "foundationKey": "font-headline-s",
      "domain": "typography",
      "kind": "typography-style",
      "fontSize": "16px",
      "fontWeight": "500",
      "lineHeight": "24px",
      "letterSpacing": "0em"
    },
    {
      "foundationKey": "font-headline-xl",
      "domain": "typography",
      "kind": "typography-style",
      "fontSize": "24px",
      "fontWeight": "500",
      "lineHeight": "32px",
      "letterSpacing": "0em"
    },
    {
      "foundationKey": "font-headline-xs",
      "domain": "typography",
      "kind": "typography-style",
      "fontSize": "14px",
      "fontWeight": "500",
      "lineHeight": "22px",
      "letterSpacing": "0em"
    },
    {
      "foundationKey": "font-headline-xxl",
      "domain": "typography",
      "kind": "typography-style",
      "fontSize": "28px",
      "fontWeight": "500",
      "lineHeight": "36px",
      "letterSpacing": "0em"
    },
    {
      "foundationKey": "font-headline-xxs",
      "domain": "typography",
      "kind": "typography-style",
      "fontSize": "12px",
      "fontWeight": "500",
      "lineHeight": "20px",
      "letterSpacing": "0em"
    },
    {
      "foundationKey": "icon-grid-16",
      "domain": "icon",
      "kind": "length",
      "value": "16px"
    },
    {
      "foundationKey": "icon-grid-24",
      "domain": "icon",
      "kind": "length",
      "value": "24px"
    },
    {
      "foundationKey": "icon-grid-32",
      "domain": "icon",
      "kind": "length",
      "value": "32px"
    },
    {
      "foundationKey": "icon-grid-40",
      "domain": "icon",
      "kind": "length",
      "value": "40px"
    },
    {
      "foundationKey": "icon-grid-48",
      "domain": "icon",
      "kind": "length",
      "value": "48px"
    },
    {
      "foundationKey": "icon-grid-56",
      "domain": "icon",
      "kind": "length",
      "value": "56px"
    },
    {
      "foundationKey": "icon-size-12",
      "domain": "icon",
      "kind": "length",
      "value": "12px"
    },
    {
      "foundationKey": "icon-size-16",
      "domain": "icon",
      "kind": "length",
      "value": "16px"
    },
    {
      "foundationKey": "icon-size-20",
      "domain": "icon",
      "kind": "length",
      "value": "20px"
    },
    {
      "foundationKey": "icon-size-24",
      "domain": "icon",
      "kind": "length",
      "value": "24px"
    },
    {
      "foundationKey": "icon-size-32",
      "domain": "icon",
      "kind": "length",
      "value": "32px"
    },
    {
      "foundationKey": "icon-size-40",
      "domain": "icon",
      "kind": "length",
      "value": "40px"
    },
    {
      "foundationKey": "icon-size-48",
      "domain": "icon",
      "kind": "length",
      "value": "48px"
    },
    {
      "foundationKey": "icon-size-56",
      "domain": "icon",
      "kind": "length",
      "value": "56px"
    },
    {
      "foundationKey": "layout-grid-breakpoint-fixed",
      "domain": "layout",
      "kind": "length",
      "value": "1920px"
    },
    {
      "foundationKey": "layout-grid-breakpoint-medium",
      "domain": "layout",
      "kind": "length",
      "value": "768px"
    },
    {
      "foundationKey": "layout-grid-breakpoint-wide",
      "domain": "layout",
      "kind": "length",
      "value": "1280px"
    },
    {
      "foundationKey": "layout-grid-columns-medium",
      "domain": "layout",
      "kind": "number",
      "value": 12
    },
    {
      "foundationKey": "layout-grid-columns-wide",
      "domain": "layout",
      "kind": "number",
      "value": 24
    },
    {
      "foundationKey": "layout-grid-gutter",
      "domain": "layout",
      "kind": "length",
      "value": "16px"
    },
    {
      "foundationKey": "layout-grid-max-width",
      "domain": "layout",
      "kind": "length",
      "value": "1856px"
    },
    {
      "foundationKey": "layout-grid-safe-edge",
      "domain": "layout",
      "kind": "length",
      "value": "32px"
    },
    {
      "foundationKey": "radius-full",
      "domain": "radius",
      "kind": "length",
      "value": "999px"
    },
    {
      "foundationKey": "radius-lg",
      "domain": "radius",
      "kind": "length",
      "value": "8px"
    },
    {
      "foundationKey": "radius-md",
      "domain": "radius",
      "kind": "length",
      "value": "6px"
    },
    {
      "foundationKey": "radius-none",
      "domain": "radius",
      "kind": "length",
      "value": "0px"
    },
    {
      "foundationKey": "radius-sm",
      "domain": "radius",
      "kind": "length",
      "value": "4px"
    },
    {
      "foundationKey": "radius-xs",
      "domain": "radius",
      "kind": "length",
      "value": "2px"
    },
    {
      "foundationKey": "shadow-base",
      "domain": "shadow",
      "kind": "box-shadow",
      "color": "#000000",
      "opacity": "16%",
      "x": "0px",
      "y": "4px",
      "blur": "12px",
      "spread": "0px",
      "css": "0px 4px 12px 0px rgb(0 0 0 / 16%)"
    },
    {
      "foundationKey": "shadow-l-base",
      "domain": "shadow",
      "kind": "box-shadow",
      "color": "#000000",
      "opacity": "8%",
      "x": "-2px",
      "y": "0px",
      "blur": "12px",
      "spread": "0px",
      "css": "-2px 0px 12px 0px rgb(0 0 0 / 8%)"
    },
    {
      "foundationKey": "shadow-l-sm",
      "domain": "shadow",
      "kind": "box-shadow",
      "color": "#000000",
      "opacity": "8%",
      "x": "-1px",
      "y": "0px",
      "blur": "6px",
      "spread": "0px",
      "css": "-1px 0px 6px 0px rgb(0 0 0 / 8%)"
    },
    {
      "foundationKey": "shadow-lg",
      "domain": "shadow",
      "kind": "box-shadow",
      "color": "#000000",
      "opacity": "16%",
      "x": "0px",
      "y": "8px",
      "blur": "24px",
      "spread": "0px",
      "css": "0px 8px 24px 0px rgb(0 0 0 / 16%)"
    },
    {
      "foundationKey": "shadow-md",
      "domain": "shadow",
      "kind": "box-shadow",
      "color": "#000000",
      "opacity": "8%",
      "x": "0px",
      "y": "8px",
      "blur": "24px",
      "spread": "0px",
      "css": "0px 8px 24px 0px rgb(0 0 0 / 8%)"
    },
    {
      "foundationKey": "shadow-none",
      "domain": "shadow",
      "kind": "box-shadow",
      "color": "#000000",
      "opacity": "0%",
      "x": "0px",
      "y": "0px",
      "blur": "0px",
      "spread": "0px",
      "css": "0px 0px 0px 0px rgb(0 0 0 / 0%)"
    },
    {
      "foundationKey": "shadow-r-sm",
      "domain": "shadow",
      "kind": "box-shadow",
      "color": "#000000",
      "opacity": "8%",
      "x": "1px",
      "y": "0px",
      "blur": "6px",
      "spread": "0px",
      "css": "1px 0px 6px 0px rgb(0 0 0 / 8%)"
    },
    {
      "foundationKey": "shadow-sm",
      "domain": "shadow",
      "kind": "box-shadow",
      "color": "#000000",
      "opacity": "8%",
      "x": "0px",
      "y": "1px",
      "blur": "6px",
      "spread": "0px",
      "css": "0px 1px 6px 0px rgb(0 0 0 / 8%)"
    },
    {
      "foundationKey": "shadow-t-m",
      "domain": "shadow",
      "kind": "box-shadow",
      "color": "#000000",
      "opacity": "8%",
      "x": "0px",
      "y": "-1px",
      "blur": "6px",
      "spread": "0px",
      "css": "0px -1px 6px 0px rgb(0 0 0 / 8%)"
    },
    {
      "foundationKey": "shadow-xl",
      "domain": "shadow",
      "kind": "box-shadow",
      "color": "#000000",
      "opacity": "16%",
      "x": "0px",
      "y": "16px",
      "blur": "48px",
      "spread": "0px",
      "css": "0px 16px 48px 0px rgb(0 0 0 / 16%)"
    },
    {
      "foundationKey": "spacing-component-lg",
      "domain": "spacing",
      "kind": "length",
      "value": "16px"
    },
    {
      "foundationKey": "spacing-component-md",
      "domain": "spacing",
      "kind": "length",
      "value": "12px"
    },
    {
      "foundationKey": "spacing-component-sm",
      "domain": "spacing",
      "kind": "length",
      "value": "8px"
    },
    {
      "foundationKey": "spacing-component-xl",
      "domain": "spacing",
      "kind": "length",
      "value": "24px"
    },
    {
      "foundationKey": "spacing-component-xs",
      "domain": "spacing",
      "kind": "length",
      "value": "4px"
    },
    {
      "foundationKey": "spacing-dialog-padding-block-end",
      "domain": "spacing",
      "kind": "length",
      "value": "20px"
    },
    {
      "foundationKey": "spacing-dialog-padding-block-end-with-actions",
      "domain": "spacing",
      "kind": "length",
      "value": "24px"
    },
    {
      "foundationKey": "spacing-layout-action-gap",
      "domain": "spacing",
      "kind": "length",
      "value": "24px"
    },
    {
      "foundationKey": "spacing-layout-card-gap",
      "domain": "spacing",
      "kind": "length",
      "value": "16px"
    },
    {
      "foundationKey": "spacing-layout-container-block",
      "domain": "spacing",
      "kind": "length",
      "value": "20px"
    },
    {
      "foundationKey": "spacing-layout-container-inline",
      "domain": "spacing",
      "kind": "length",
      "value": "24px"
    },
    {
      "foundationKey": "spacing-layout-content-gap",
      "domain": "spacing",
      "kind": "length",
      "value": "16px"
    },
    {
      "foundationKey": "spacing-layout-section-gap",
      "domain": "spacing",
      "kind": "length",
      "value": "20px"
    },
    {
      "foundationKey": "spacing-layout-section-gap-large",
      "domain": "spacing",
      "kind": "length",
      "value": "32px"
    },
    {
      "foundationKey": "spacing-page-action-bar-padding-block",
      "domain": "spacing",
      "kind": "length",
      "value": "16px"
    },
    {
      "foundationKey": "spacing-screen-edge-compact",
      "domain": "spacing",
      "kind": "length",
      "value": "16px"
    },
    {
      "foundationKey": "spacing-screen-edge-expanded",
      "domain": "spacing",
      "kind": "length",
      "value": "32px"
    }
  ]
} as const;

export type WorkbenchFoundationKey = typeof foundationRuntime.records[number]["foundationKey"];
export type WorkbenchFoundationRuntimeRecord = typeof foundationRuntime.records[number];
