<script lang="ts">
export type { ComposerRequestContext } from './composerTypes';
</script>
<script setup lang="ts">
import { vAiTooltip } from '../foundation/aiTooltip';
import { useDeliveryMode } from '../foundation/deliveryMode';
import { nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue';
import { TrActionButton, TrSender } from '@opentiny/tiny-robot';
import { AiIcon, aiIconVNode } from '../foundation/aiIcons';
import ComposerModeSelect, { type ComposerModeOption } from './ComposerModeSelect.vue';
import type { ComposerRequestContext } from './composerTypes';
import '../foundation/aiTokens.css';
import { useAutoScrollbars } from '../foundation/useAutoScrollbars';
const props = withDefaults(
  defineProps<{ processing?: boolean; modeOptions?: ComposerModeOption[]; placeholder?: string }>(),
  { processing: false, modeOptions: () => [], placeholder: '请输入问题或 / 触发快捷操作' },
);
const draft = defineModel<string>({ default: '' });
const aiEnabled = defineModel<boolean>('aiEnabled', { default: false });
const mode = defineModel<string>('mode', { default: '' });
const emit = defineEmits<{
  submit: [query: string, context: ComposerRequestContext];
  cancel: [];
}>();
const sender = ref<InstanceType<typeof TrSender>>();
const delivery = useDeliveryMode();
const shell = ref<HTMLElement>();
useAutoScrollbars(() => shell.value, [{ selector: '.tr-sender-editor-scroll', axis: 'y' }]);
// REQ-017 (TinyRobot 0.5.1): autoSize=false; measure ProseMirror + chrome up to 287px max.
let sizeObserver: ResizeObserver | undefined;
let sizeFrame = 0;
function scheduleSize() {
  if (!sizeFrame)
    sizeFrame = requestAnimationFrame(() => {
      sizeFrame = 0;
      measureSize();
    });
}
function measureSize() {
  const root = shell.value;
  const surface = root?.querySelector<HTMLElement>('.tr-sender');
  const port = root?.querySelector<HTMLElement>('.tr-sender-editor-scroll');
  const editor = port?.querySelector<HTMLElement>('.ProseMirror');
  const actions = root?.querySelector<HTMLElement>('.tr-sender-footer');
  const layout = root?.querySelector<HTMLElement>('.tr-sender-multi-layout');
  if (!root || !surface || !port || !editor || !actions || !layout) return;
  const paint = getComputedStyle(surface);
  const overhead =
    parseFloat(paint.paddingTop) +
    parseFloat(paint.paddingBottom) +
    actions.offsetHeight +
    parseFloat(getComputedStyle(layout).rowGap);
  const minimum = overhead + parseFloat(getComputedStyle(editor).lineHeight);
  const footer = root.closest<HTMLElement>('.chat-footer');
  const panel = root.closest<HTMLElement>('.chat-panel');
  let available = 287;
  if (footer && panel) {
    const header = panel.querySelector<HTMLElement>('.tr-layout__header');
    const viewport = panel.closest<HTMLElement>('.company-assistant-viewport');
    const height = Math.min(panel.clientHeight, viewport?.clientHeight ?? Infinity);
    // Reserve 24px minimum for the scrolling main region.
    available =
      height - (header?.offsetHeight ?? 0) - (footer.offsetHeight - root.offsetHeight) - 24;
  }
  const height = Math.max(
    minimum,
    Math.min(287, available, Math.max(132, editor.offsetHeight + overhead)),
  );
  const set = (node: HTMLElement, name: string, value: number) => {
    const pixels = `${value}px`;
    if (node.style.getPropertyValue(name) !== pixels) node.style.setProperty(name, pixels);
  };
  set(root, '--composer-measured-height', height);
  if (footer) {
    set(footer, '--composer-measured-height', height);
    set(footer, '--composer-min-usable-height', minimum);
  }
  // Center native scrollbar track inside the 16px right inset without shrinking editor text width.
  const gutter = port.offsetWidth - port.clientWidth;
  const nativeTrack = parseFloat(getComputedStyle(port, '::-webkit-scrollbar').width);
  const track = gutter || (Number.isFinite(nativeTrack) ? nativeTrack : 10);
  set(root, '--composer-scroll-extension', (parseFloat(paint.paddingRight) + track) / 2);
  set(root, '--composer-native-gutter', gutter);
}
watch(
  draft,
  async () => {
    await nextTick();
    scheduleSize();
  },
  { flush: 'post' },
);
onMounted(() => {
  sizeObserver = new ResizeObserver(scheduleSize);
  for (const node of [
    shell.value,
    shell.value?.querySelector('.ProseMirror'),
    shell.value?.querySelector('.tr-sender-editor-scroll'),
    shell.value?.closest('.chat-footer'),
    shell.value?.closest('.chat-panel'),
    shell.value?.closest('.company-assistant-viewport'),
  ]) {
    if (node) sizeObserver.observe(node);
  }
  scheduleSize();
});
onBeforeUnmount(() => {
  sizeObserver?.disconnect();
  cancelAnimationFrame(sizeFrame);
});
// TinyRobot 0.5.1: modelValue parses string as HTML; use editor transaction for plain-text insertion.
function appendSuggestion(query: string) {
  const editor = sender.value?.editor;
  if (!editor) return false;
  const text = `${editor.getText().length ? '\n' : ''}${query}`;
  editor.view.dispatch(editor.state.tr.insertText(text, editor.state.doc.content.size - 1));
  return true;
}
defineExpose({ focus: () => sender.value?.editor?.commands.focus('end'), appendSuggestion });

watch(
  () => sender.value?.editor,
  (editor) => {
    if (editor)
      editor.setOptions({
        editorProps: {
          ...editor.options.editorProps,
          attributes: {
            ...(typeof editor.options.editorProps.attributes === 'object'
              ? editor.options.editorProps.attributes
              : {}),
            role: 'textbox',
            'aria-label': '输入问题',
            'aria-multiline': 'true',
          },
        },
      });
  },
);
function submit(value: string) {
  // TinyRobot 0.5.1 getText() defaults to double newlines between blocks; normalize to '\n'.
  const query = sender.value?.editor?.getText({ blockSeparator: '\n' }) ?? value;
  if (props.processing || !query.trim()) return;
  emit('submit', query, { aiEnabled: aiEnabled.value, mode: mode.value });
  draft.value = '';
}
function focusEditorSpace(event: MouseEvent) {
  const target = event.target;
  if (
    target instanceof HTMLElement &&
    target.matches(
      '.tr-sender-main, .tr-sender-content, .tr-sender-editor-wrapper, .tr-sender-editor-scroll',
    )
  )
    sender.value?.editor?.commands.focus('end');
}
function keyboard(event: KeyboardEvent) {
  // Intercept only editor Enter: the switch/select keep their own Enter/Space navigation.
  if (!(event.target instanceof HTMLElement) || !event.target.closest('[contenteditable]')) return;
  if (
    event.key === 'Enter' &&
    !event.shiftKey &&
    !event.ctrlKey &&
    !event.metaKey &&
    !event.isComposing
  ) {
    event.preventDefault();
    event.stopPropagation();
    submit(draft.value);
  }
}
</script>
<template>
  <div
    ref="shell"
    class="chat-composer"
    @keydown.capture="keyboard"
    @input="scheduleSize"
    @compositionend="scheduleSize"
    @click="focusEditorSpace"
  >
    <TrSender
      ref="sender"
      v-model="draft"
      :loading="processing"
      mode="multiple"
      :placeholder="placeholder"
      stop-text="停止生成"
      :auto-size="false"
      :max-length="2000"
      @submit="submit"
      @cancel="emit('cancel')"
    >
      <template #footer>
        <!-- TinyRobot 0.5.1 has no public Switch; keep native button switch local. -->
        <button
          v-show="!delivery"
          v-ai-tooltip="'开启后由大模型回答'"
          type="button"
          role="switch"
          class="composer-ai-toggle"
          :class="{ 'is-active': aiEnabled }"
          aria-label="AI问答"
          :aria-checked="aiEnabled"
          @click="aiEnabled = !aiEnabled"
        >
          <span class="composer-ai-switch-label">AI问答</span
          ><span
            class="composer-ai-switch-track"
            aria-hidden="true"
            ><span class="composer-ai-switch-thumb"
          /></span>
        </button>
        <span
          v-show="!delivery"
          class="composer-mode-host"
          ><ComposerModeSelect
            v-model="mode"
            :options="modeOptions"
        /></span>
      </template>
      <template #footer-right>
        <TrActionButton
          v-show="!delivery"
          v-ai-tooltip="'语音输入尚未接入'"
          :icon="aiIconVNode('composer.voice')"
          type="button"
          class="composer-icon-action"
          aria-label="语音输入（尚未接入）"
        ></TrActionButton>
        <TrActionButton
          v-show="!delivery"
          v-ai-tooltip="'上传图片尚未接入'"
          :icon="aiIconVNode('composer.image')"
          type="button"
          class="composer-icon-action"
          aria-label="上传图片（尚未接入）"
        ></TrActionButton>
        <span
          v-show="!delivery"
          class="composer-action-divider"
          aria-hidden="true"
        />
        <!-- REQ-009: keep one ActionButton instance so focus/cancel survive rapid send<->stop icon transitions. -->
        <TrActionButton
          v-ai-tooltip="processing ? '停止生成' : '发送消息'"
          :icon="aiIconVNode('composer.send')"
          type="button"
          class="composer-send-action"
          :aria-label="processing ? '停止生成' : '发送消息'"
          :disabled="!processing && !draft.trim()"
          @click="processing ? emit('cancel') : submit(draft)"
        >
          <template #icon>
            <span
              class="composer-state-icon"
              aria-hidden="true"
            >
              <Transition name="composer-icon">
                <AiIcon
                  :key="processing ? 'stop' : 'send'"
                  :name="processing ? 'composer.stop' : 'composer.send'"
                />
              </Transition>
            </span>
          </template>
        </TrActionButton>
      </template>
    </TrSender>
  </div>
</template>
<style scoped>
/* REQ-003/009/013/018 (TinyRobot 0.5.1): adapts TrSender layout/editor DOM and overlays
   six-point gradient ring/glow without altering Sender layout; recheck .tr-sender-* hooks on upgrades. */
.chat-composer {
  position: relative;
  isolation: isolate;
  width: 100%;
  height: var(--composer-measured-height, var(--partner-ai-composer-height));
  flex: none;
  min-width: 0;
  overflow: visible;
  font-size: var(--partner-ai-body-size);
  line-height: var(--partner-ai-body-line);
}
/* REQ-018: blurred multicolor focus glow behind Sender surface. */
.chat-composer::before {
  content: '';
  position: absolute;
  z-index: -1;
  inset: 0;
  border-radius: var(--partner-ai-composer-radius);
  background: var(--partner-ai-composer-stroke-image);
  filter: blur(var(--partner-ai-composer-focus-glow-blur));
  pointer-events: none;
  opacity: 0;
  transition: opacity var(--partner-ai-control-motion-duration)
    var(--partner-ai-control-motion-easing);
}
.chat-composer:has([contenteditable]:focus)::before {
  opacity: var(--partner-ai-composer-focus-glow-opacity);
}
/* REQ-013: mask-composite gradient stroke ring (Sender exposes no gradient-stroke API). */
.chat-composer::after {
  content: '';
  position: absolute;
  z-index: 1;
  inset: 0;
  box-sizing: border-box;
  padding: var(--partner-ai-composer-stroke-width);
  border-radius: var(--partner-ai-composer-radius);
  background: var(--partner-ai-composer-stroke-image);
  pointer-events: none;
  -webkit-mask:
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  mask:
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask-composite: exclude;
  opacity: var(--partner-ai-composer-stroke-opacity);
  transition: opacity var(--partner-ai-control-motion-duration)
    var(--partner-ai-control-motion-easing);
}
.chat-composer:has([contenteditable]:focus)::after {
  opacity: var(--partner-ai-composer-stroke-focus-opacity);
}
.chat-composer :deep(.tr-sender.tr-sender--multiple) {
  height: 100%;
  width: 100%;
  padding: var(--partner-ai-composer-padding-block) var(--partner-ai-composer-padding-inline);
  box-sizing: border-box;
  font-family: inherit;
  min-height: 0;
  --tr-sender-placeholder-color: var(--partner-ai-composer-placeholder-color);
  --tr-sender-font-size: var(--partner-ai-body-size);
  --tr-sender-line-height: var(--partner-ai-body-line);
  --tr-sender-border-radius: var(--partner-ai-composer-radius);
  --tr-sender-bg-color: var(--partner-ai-composer-bg);
  --tr-sender-box-shadow: var(--partner-ai-composer-shadow);
  --tr-sender-header-border-bottom: none;
  --tr-sender-multi-main-padding: 0;
  --tr-sender-footer-padding: 0;
  --tr-sender-action-gap: 0;
  --tr-sender-footer-gap: var(--partner-ai-gap-md);
  --tr-sender-gap: var(--partner-ai-gap-md);
}
.chat-composer :deep(.tr-sender-multi-layout) {
  height: 100%;
  display: flex;
  flex-direction: column;
  gap: var(--partner-ai-gap-md);
  min-height: 0;
  padding: 0;
}
.chat-composer :deep(.tr-sender .tr-sender-main) {
  flex: 1;
  min-height: 0;
  padding: 0;
  overflow: visible;
  --tr-sender-multi-main-padding: 0;
}
.chat-composer :deep(.tr-sender-content),
.chat-composer :deep(.tr-sender-editor-wrapper) {
  min-width: 0;
  height: 100%;
  min-height: 0;
}
.chat-composer :deep(.tr-sender-editor-scroll) {
  box-sizing: border-box;
  flex: none;
  width: calc(100% + var(--composer-scroll-extension, 13px));
  margin-right: calc(0px - var(--composer-scroll-extension, 13px));
  padding-right: calc(var(--composer-scroll-extension, 13px) - var(--composer-native-gutter, 0px));
  height: 100%;
  min-height: 0 !important;
  max-height: 100% !important;
  overflow-y: auto;
  overflow-x: hidden;
  overscroll-behavior: contain;
}
.chat-composer :deep(.ProseMirror) {
  height: auto;
  max-height: none;
  overflow: visible;
  transition: none;
  font-family: inherit;
  font-size: var(--partner-ai-body-size);
  line-height: var(--partner-ai-body-line);
  font-weight: var(--partner-ai-body-weight);
  letter-spacing: var(--partner-ai-body-letter-spacing);
}
.chat-composer :deep(.tr-sender-footer) {
  height: var(--partner-ai-control-size);
  min-height: var(--partner-ai-control-size);
  flex: none;
  overflow-x: auto;
  overflow-y: hidden;
  scrollbar-width: none;
}
.chat-composer :deep(.tr-sender-footer-left),
.chat-composer :deep(.tr-sender-footer-right) {
  height: var(--partner-ai-control-size);
  flex: none;
}
.composer-mode-host {
  display: contents;
}
.chat-composer :deep(.tr-sender-footer-left) {
  gap: var(--partner-ai-mode-control-gap);
}
/* Zero default gap so adjacent icon margins and divider margins control spacing. */
.chat-composer :deep(.tr-sender-footer-right) {
  gap: 0;
}
.chat-composer :deep(.composer-icon-action + .composer-icon-action) {
  margin-left: var(--partner-ai-gap-sm);
}
.chat-composer :deep(.tr-sender-submit-button) {
  display: none;
}
/* Editor focus uses the gradient ring above; forced-colors keeps a system outline. */
.chat-composer :deep([contenteditable]:focus-visible) {
  outline: none;
}
.chat-composer :deep(button) {
  font: inherit;
  cursor: pointer;
}
.chat-composer :deep(button:disabled) {
  cursor: not-allowed;
  opacity: 0.5;
}
.chat-composer :deep(button:focus-visible) {
  outline: var(--partner-ai-focus-width) solid var(--partner-ai-focus);
  outline-offset: var(--partner-ai-focus-inset);
}
.chat-composer :deep(.composer-icon-action:focus-visible),
.chat-composer :deep(.composer-send-action:focus-visible) {
  outline: var(--partner-ai-focus-width) solid var(--partner-ai-focus);
  outline-offset: var(--partner-ai-focus-inset);
}
/* Opacity crossfade between ::before/::after keeps translucent gradient endpoints clean. */
.chat-composer :deep(.composer-ai-toggle) {
  width: auto;
  margin: 0;
  display: inline-flex;
  align-items: center;
  height: var(--partner-ai-control-size);
  padding: var(--partner-ai-gap-sm) var(--partner-ai-toggle-padding-inline);
  gap: var(--partner-ai-gap-sm);
  flex: none;
  border: 0;
  border-radius: var(--partner-ai-control-radius);
  background: transparent;
  color: var(--partner-ai-switch-label-color);
  white-space: nowrap;
  transition: color var(--partner-ai-control-motion-duration)
    var(--partner-ai-control-motion-easing);
}
.chat-composer :deep(.composer-ai-toggle[aria-checked='true']) {
  color: var(--partner-ai-switch-label-active-color);
}
.composer-ai-switch-track {
  position: relative;
  display: block;
  width: var(--partner-ai-switch-width);
  height: var(--partner-ai-switch-height);
  flex: none;
  border-radius: var(--partner-ai-full-radius);
  background: transparent;
}
.composer-ai-switch-track::before,
.composer-ai-switch-track::after {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  pointer-events: none;
  transition: opacity var(--partner-ai-control-motion-duration)
    var(--partner-ai-control-motion-easing);
}
.composer-ai-switch-track::before {
  background: var(--partner-ai-switch-off-bg);
  opacity: 1;
}
.composer-ai-switch-track::after {
  background: var(--partner-ai-switch-on-bg);
  opacity: 0;
}
.composer-ai-switch-thumb {
  position: absolute;
  z-index: 1;
  top: calc((var(--partner-ai-switch-height) - var(--partner-ai-switch-thumb-size)) / 2);
  left: calc((var(--partner-ai-switch-height) - var(--partner-ai-switch-thumb-size)) / 2);
  width: var(--partner-ai-switch-thumb-size);
  height: var(--partner-ai-switch-thumb-size);
  border-radius: var(--partner-ai-full-radius);
  background: var(--partner-ai-on-accent);
  transition: transform var(--partner-ai-control-motion-duration)
    var(--partner-ai-control-motion-easing);
}
.composer-ai-toggle[aria-checked='true'] .composer-ai-switch-track::before {
  opacity: 0;
}
.composer-ai-toggle[aria-checked='true'] .composer-ai-switch-track::after {
  opacity: 1;
}
.composer-ai-toggle[aria-checked='true'] .composer-ai-switch-thumb {
  transform: translateX(calc(var(--partner-ai-switch-width) - var(--partner-ai-switch-height)));
}
.chat-composer :deep(.composer-icon-action),
.chat-composer :deep(.composer-send-action) {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: var(--partner-ai-control-size);
  height: var(--partner-ai-control-size);
  padding: var(--partner-ai-gap-sm);
  border: 0;
  flex: none;
}
.chat-composer :deep(.composer-icon-action) {
  border-radius: var(--partner-ai-control-radius);
  background: transparent;
  color: var(--partner-ai-muted);
}
.chat-composer :deep(.composer-icon-action:hover:not(:disabled)) {
  background: var(--partner-ai-hover-bg);
}
.chat-composer .composer-icon-action :deep(svg),
.chat-composer .composer-send-action :deep(svg) {
  width: var(--partner-ai-icon-size);
  height: var(--partner-ai-icon-size);
  flex: none;
}
.chat-composer :deep(.composer-send-action) {
  border-radius: var(--partner-ai-full-radius);
  background: var(--partner-ai-send-bg);
  color: var(--partner-ai-send-icon-color);
  opacity: var(--partner-ai-send-opacity);
  transition: opacity var(--partner-ai-control-motion-duration)
    var(--partner-ai-control-motion-easing);
  --tr-sender-button-hover-bg: transparent;
  --tr-sender-button-active-bg: transparent;
}
.chat-composer :deep(.composer-send-action:disabled) {
  opacity: var(--partner-ai-send-disabled-opacity);
}
.composer-state-icon {
  position: relative;
  display: block;
  width: var(--partner-ai-icon-size);
  height: var(--partner-ai-icon-size);
  flex: none;
  pointer-events: none;
}
.composer-state-icon :deep(svg) {
  position: absolute;
  inset: 0;
  transform-origin: center;
}
.composer-state-icon :deep(.composer-icon-enter-active),
.composer-state-icon :deep(.composer-icon-leave-active) {
  transition:
    opacity var(--partner-ai-control-motion-duration) var(--partner-ai-control-motion-easing),
    transform var(--partner-ai-control-motion-duration) var(--partner-ai-control-motion-easing);
}
.composer-state-icon :deep(.composer-icon-enter-from),
.composer-state-icon :deep(.composer-icon-leave-to) {
  opacity: 0;
  transform: scale(var(--partner-ai-state-icon-entry-scale));
}
.composer-action-divider {
  margin: 0 var(--partner-ai-gap-lg) 0 var(--partner-ai-gap-md);
  width: 1px;
  height: var(--partner-ai-small-icon-size);
  background: var(--partner-ai-divider);
  flex: none;
}
@media (forced-colors: active) {
  .chat-composer :deep(.tr-sender:has([contenteditable]:focus-visible)) {
    outline: var(--partner-ai-focus-width) solid Highlight;
    outline-offset: var(--partner-ai-focus-offset);
  }
}
@media (prefers-reduced-motion: reduce) {
  .chat-composer::before,
  .chat-composer::after {
    transition: none;
  }
  .chat-composer :deep(.composer-ai-toggle),
  .composer-ai-switch-track::before,
  .composer-ai-switch-track::after,
  .composer-ai-switch-thumb,
  .chat-composer :deep(.composer-send-action) {
    transition: none;
  }
  .composer-state-icon :deep(.composer-icon-enter-active),
  .composer-state-icon :deep(.composer-icon-leave-active) {
    transition: none;
  }
  .composer-state-icon :deep(.composer-icon-enter-from) {
    opacity: 1;
    transform: none;
  }
  .composer-state-icon :deep(.composer-icon-leave-active),
  .composer-state-icon :deep(.composer-icon-leave-to) {
    opacity: 0;
    transform: none;
  }
}
</style>
