<script lang="ts">
export type { WelcomeBusinessEntry } from '../composer/composerTypes';
</script>
<script setup lang="ts">
import assistantAvatar from '../../assets/assistantAvatar';
import { vAiTooltip } from '../foundation/aiTooltip';
import { createVNode, h, type Directive } from 'vue';
import { TrWelcome, TrPrompt } from '@opentiny/tiny-robot';
import { aiIconVNode } from '../foundation/aiIcons';
import type { WelcomeBusinessEntry } from '../composer/composerTypes';
import '../foundation/aiTokens.css';
const props = withDefaults(
  defineProps<{ avatarSrc?: string; fullscreen?: boolean; entries?: WelcomeBusinessEntry[] }>(),
  { avatarSrc: assistantAvatar, fullscreen: false, entries: () => [] },
);
const emit = defineEmits<{ select: [entry: WelcomeBusinessEntry] }>();
// TinyRobot 0.5.1: TrWelcome lacks title tag/slot API; set aria-level=2 and return fresh VNodes per render.
const welcomeIcon = () =>
  props.avatarSrc
    ? h('img', { src: props.avatarSrc, alt: 'AI 助手', class: 'chat-welcome-avatar' })
    : h(
        'span',
        { class: 'chat-welcome-avatar chat-welcome-avatar--fallback', 'aria-hidden': 'true' },
        [aiIconVNode('assistant.fallback')],
      );
const vWelcomeHeading: Directive<HTMLElement> = {
  mounted(el) {
    el.querySelector('.tr-welcome__title')?.setAttribute('aria-level', '2');
  },
};
function select(entry: WelcomeBusinessEntry) {
  if (!entry.disabled) emit('select', entry);
}
</script>
<template>
  <section
    v-welcome-heading
    class="chat-welcome"
    :class="{ 'is-fullscreen': fullscreen }"
    aria-label="企业AI助手欢迎区"
  >
    <div class="chat-welcome-content">
      <TrWelcome
        class="chat-welcome-intro"
        title="企业AI助手"
        description="我是您的智能客服，欢迎向我提问！"
        :icon="welcomeIcon()"
        align="center"
      />
      <div
        class="chat-welcome-entries"
        :class="{
          'is-fullscreen': fullscreen,
          'is-fullscreen-grid': fullscreen && entries.length === 3,
        }"
      >
        <!-- TinyRobot 0.5.1: TrPrompt root is a div; supply button semantics & keyboard handlers directly. -->
        <TrPrompt
          v-for="entry in entries"
          :id="entry.id"
          :key="entry.id"
          v-ai-tooltip="{
            content: `${entry.title}：${entry.description}`,
            overflowOnly: true,
            overflowSelector: '.tr-prompt__content-title,.tr-prompt__content-description',
          }"
          class="chat-welcome-entry"
          :label="entry.title"
          :description="entry.description"
          :icon="
            entry.icon
              ? createVNode(entry.icon, { 'aria-hidden': 'true' }, null, 0, null, true)
              : aiIconVNode('welcome.entry')
          "
          :disabled="entry.disabled"
          role="button"
          :tabindex="entry.disabled ? -1 : 0"
          :aria-disabled="!!entry.disabled"
          :aria-label="`${entry.title} ${entry.description}`"
          @click="select(entry)"
          @keydown.enter.prevent="select(entry)"
          @keydown.space.prevent
          @keyup.space.prevent="select(entry)"
        />
      </div>
    </div>
  </section>
</template>
<style scoped>
/* REQ-003/015 (TinyRobot 0.5.1): adapts TrWelcome/TrPrompt DOM and subtracts handle/header/scrollbar
   offsets so welcome cards stay panel-aligned; recheck .tr-welcome / .tr-prompt hooks on upgrades. */
.chat-welcome {
  container: partner-ai-welcome / inline-size;
  flex: 1;
  min-height: 0;
  min-width: 0;
  height: 100%;
  overflow-y: auto;
  overflow-x: hidden;
  overscroll-behavior: contain;
  scrollbar-width: thin;
  box-sizing: border-box;
  padding: max(
      0px,
      calc(
        var(--partner-ai-welcome-origin) -
          var(--partner-chat-handle-height, var(--partner-ai-handle-area-height)) -
          var(--partner-chat-toolbar-height, var(--partner-ai-header-height))
      )
    )
    var(
      --partner-ai-layout-safe-inset,
      var(--partner-ai-safe-inset, var(--partner-ai-safe-inset-compact))
    )
    var(--partner-ai-welcome-padding-block-end);
}
.chat-welcome {
  padding-right: max(
    0px,
    calc(
      var(
          --partner-ai-layout-safe-inset,
          var(--partner-ai-safe-inset, var(--partner-ai-safe-inset-compact))
        ) -
        var(--partner-ai-native-scrollbar-gutter, 0px)
    )
  );
}
.chat-welcome.is-fullscreen {
  display: flex;
  flex-direction: column;
  padding-block: var(--partner-ai-welcome-padding-block-end);
}
.chat-welcome.is-fullscreen > .chat-welcome-content {
  flex: none;
  width: 100%;
  margin-block: auto;
}
.chat-welcome .chat-welcome-intro {
  padding: 0;
}
.chat-welcome-intro :deep(.tr-welcome__icon) {
  margin: 0;
  display: flex;
  flex: none;
}
/* Center intrinsic title group without rounding fractional text metrics. */
.chat-welcome-intro :deep(.tr-welcome__title-wrapper) {
  display: flex;
  align-items: center;
  position: relative;
  left: 50%;
  transform: translateX(-50%);
  width: max-content;
  max-width: 100%;
  gap: var(--partner-ai-gap-lg);
  min-width: 0;
}
.chat-welcome-intro :deep(.chat-welcome-avatar) {
  display: block;
  width: var(--partner-ai-welcome-avatar-size);
  height: var(--partner-ai-welcome-avatar-size);
  flex: none;
  object-fit: contain;
}
.chat-welcome-intro :deep(.chat-welcome-avatar--fallback) {
  display: grid;
  place-items: center;
  border-radius: var(--partner-ai-welcome-avatar-radius);
  color: var(--partner-ai-on-accent);
  background: var(--partner-ai-accent);
}
.chat-welcome-intro :deep(.chat-welcome-avatar--fallback svg) {
  width: var(--partner-ai-icon-size);
  height: var(--partner-ai-icon-size);
}
.chat-welcome-intro :deep(.tr-welcome__title) {
  margin: 0;
  min-width: 0;
  font-size: var(--partner-ai-welcome-title-size);
  line-height: var(--partner-ai-welcome-title-line);
  font-weight: var(--partner-ai-heading-weight);
  color: var(--partner-ai-text);
}
.chat-welcome-intro :deep(.tr-welcome__description) {
  margin: var(--partner-ai-gap-md) 0 0;
  text-align: center;
  font-size: var(--partner-ai-welcome-body-size);
  line-height: var(--partner-ai-welcome-body-line);
  font-weight: var(--partner-ai-body-weight);
  color: var(--partner-ai-text);
}
.chat-welcome-entries {
  display: grid;
  width: 100%;
  max-width: var(--partner-ai-welcome-card-max-width);
  gap: var(--partner-ai-welcome-card-gap);
  margin-top: var(--partner-ai-welcome-entry-gap);
  margin-inline: auto;
}
.chat-welcome .chat-welcome-entry {
  --tr-prompt-border-radius: var(--partner-ai-welcome-card-radius);
  position: relative;
  display: flex;
  align-items: center;
  gap: var(--partner-ai-gap-lg);
  width: 100%;
  height: var(--partner-ai-welcome-card-height);
  padding: var(--partner-ai-welcome-card-padding-block)
    var(--partner-ai-welcome-card-padding-inline);
  box-sizing: border-box;
  min-width: 0;
  border: 0;
  border-radius: var(--tr-prompt-border-radius);
  background: var(--partner-ai-panel-bg);
  box-shadow: var(--partner-ai-welcome-card-shadow);
  text-align: left;
  font: inherit;
  cursor: pointer;
}
/* Gradient hover ring overlay via mask-composite. */
.chat-welcome-entry::after {
  content: '';
  position: absolute;
  inset: 0;
  box-sizing: border-box;
  padding: 1px;
  border-radius: inherit;
  background: var(--partner-ai-composer-stroke-image);
  pointer-events: none;
  -webkit-mask:
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  mask:
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask-composite: exclude;
  opacity: 0;
  transition: opacity var(--partner-ai-control-motion-duration)
    var(--partner-ai-control-motion-easing);
}
.chat-welcome-entry:hover:not(.disabled):not([aria-disabled='true'])::after {
  opacity: 1;
}
.chat-welcome-entry:hover:not(.disabled):not([aria-disabled='true']) {
  background: var(--partner-ai-panel-bg);
  box-shadow: var(--partner-ai-welcome-card-hover-shadow);
}
.chat-welcome-entry:focus-visible {
  outline: var(--partner-ai-focus-width) solid var(--partner-ai-focus);
  outline-offset: var(--partner-ai-focus-inset);
}
.chat-welcome-entry.disabled {
  opacity: var(--partner-ai-disabled-opacity);
  cursor: not-allowed;
}
@media (prefers-reduced-motion: reduce) {
  .chat-welcome-entry::after {
    transition: none;
  }
}
.chat-welcome-entry :deep(> svg) {
  width: var(--partner-ai-icon-size);
  height: var(--partner-ai-icon-size);
  flex: none;
}
.chat-welcome-entry :deep(.tr-prompt__content) {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: stretch;
  gap: var(--partner-ai-gap-sm);
  min-width: 0;
}
.chat-welcome-entry :deep(.tr-prompt__content-title) {
  font-size: var(--partner-ai-welcome-card-title-size);
  line-height: var(--partner-ai-welcome-card-title-line);
  font-weight: var(--partner-ai-heading-weight);
  color: var(--partner-ai-text);
}
.chat-welcome-entry :deep(.tr-prompt__content-description) {
  font-size: var(--partner-ai-body-size);
  line-height: var(--partner-ai-body-line);
  font-weight: var(--partner-ai-body-weight);
  color: var(--partner-ai-muted);
}
.chat-welcome-entry :deep(.tr-prompt__content-title),
.chat-welcome-entry :deep(.tr-prompt__content-description) {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.chat-welcome-entries.is-fullscreen .chat-welcome-entry {
  height: auto;
  min-height: var(--partner-ai-welcome-card-height);
}
.chat-welcome-entries.is-fullscreen .chat-welcome-entry :deep(.tr-prompt__content-title),
.chat-welcome-entries.is-fullscreen .chat-welcome-entry :deep(.tr-prompt__content-description) {
  white-space: normal;
  overflow: visible;
  overflow-wrap: anywhere;
  text-overflow: clip;
}
@container partner-ai-welcome (min-width:1040px) {
  .chat-welcome-entries.is-fullscreen-grid {
    max-width: var(--partner-ai-fullscreen-welcome-max-width, 1040px);
    grid-template-columns: repeat(3, minmax(336px, 1fr));
  }
}
</style>
