<script setup lang="ts">
import assistantAvatar from '../../assets/assistantAvatar';
import { vAiTooltip } from '../foundation/aiTooltip';
import { useDeliveryMode } from '../foundation/deliveryMode';
import { computed, toRef, markRaw, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue';
import {
  TrActionButton,
  TrBubbleList,
  TrBubbleProvider,
  TrLayout,
  BubbleRenderers,
  type BubbleContentRendererMatch,
  type BubbleBoxRendererMatch,
  type BubbleListProps,
  type BubbleEvent,
  type ChatMessageContentItem,
} from '@opentiny/tiny-robot';
import { AiIcon, aiIconVNode, provideAiIcons, type AiIconMap } from '../foundation/aiIcons';
import type { UIMessage, ChatDisplayStopSnapshot } from '../messages/chatContent';
import type { ConversationViewState } from '../history/conversationHistory';
import { hasChatOutput, resolveChatContent } from '../messages/chatContent';
import FallbackRenderer from '../messages/FallbackRenderer.vue';
import type { ChatWindowMode } from './chatWindow';
import type { ChatToolbarAction } from './chatToolbar';
import AnswerBox from '../messages/AnswerBox.vue';
import DisplayedTextRenderer from '../messages/DisplayedTextRenderer.vue';
import { presentedRenderer } from '../messages/presentedRenderer';
import '../messages/messageStyles.css';
import '../foundation/aiTokens.css';
import ChatComposer from '../composer/ChatComposer.vue';
import ChatWelcome from './ChatWelcome.vue';
import type {
  ComposerModeOption,
  ComposerRequestContext,
  WelcomeBusinessEntry,
} from '../composer/composerTypes';
import MessagePrompts from '../messages/MessagePrompts.vue';
import ComposerSuggestions from '../composer/ComposerSuggestions.vue';
import type {
  ChatSuggestion,
  ChatSuggestionPill,
  MessagePromptsResolver,
} from '../composer/chatSuggestions';
import '../composer/suggestionStyles.css';
import '../foundation/scrollbarStyles.css';
import { useSuggestionShadows } from '../foundation/useSuggestionShadows';
import { useAutoScrollbars } from '../foundation/useAutoScrollbars';
const props = withDefaults(
  defineProps<{
    icons?: AiIconMap;
    windowMode?: ChatWindowMode;
    fullscreen?: boolean;
    messages: UIMessage[];
    processing: boolean;
    continuationAvailable?: boolean;
    error: string;
    aborted: boolean;
    renderers?: BubbleContentRendererMatch[];
    avatarSrc?: string;
    toolbarActions?: ChatToolbarAction[];
    modeOptions?: ComposerModeOption[];
    welcomeEntries?: WelcomeBusinessEntry[];
    suggestionPills?: ChatSuggestionPill[];
    messagePrompts?: MessagePromptsResolver;
    requestContext?: ComposerRequestContext;
    newConversationDisabled?: boolean;
    conversationId?: string;
    conversationView?: ConversationViewState;
    historyAvailable?: boolean;
    historyOpen?: boolean;
    closable?: boolean;
  }>(),
  {
    icons: undefined,
    continuationAvailable: false,
    windowMode: undefined,
    fullscreen: undefined,
    renderers: () => [],
    toolbarActions: () => [],
    avatarSrc: assistantAvatar,
    modeOptions: () => [],
    welcomeEntries: () => [],
    suggestionPills: () => [],
    messagePrompts: undefined,
    newConversationDisabled: false,
    requestContext: undefined,
    conversationId: undefined,
    conversationView: undefined,
    historyAvailable: false,
    historyOpen: false,
    closable: false,
  },
);
provideAiIcons(toRef(props, 'icons'));
const emit = defineEmits<{
  close: [];
  windowModeChange: [mode: ChatWindowMode];
  fullscreenChange: [value: boolean];
  windowDragStart: [event: PointerEvent];
  windowDragKeydown: [event: KeyboardEvent];
  send: [query: string, context: ComposerRequestContext];
  abort: [snapshot?: ChatDisplayStopSnapshot];
  retry: [];
  event: [event: BubbleEvent];
  toolbarAction: [action: ChatToolbarAction];
  newConversation: [];
  historyOpen: [anchor: HTMLElement];
  conversationViewChange: [view: ConversationViewState];
  composerChange: [context: ComposerRequestContext];
  welcomeAction: [entry: WelcomeBusinessEntry];
}>();
const draft = ref('');
const delivery = useDeliveryMode();
// Presentation can outlive transport; capture serializable snapshot when stopped mid-stream.
const presenting = ref<Record<string, { busy: boolean; capture: () => ChatMessageContentItem[] }>>(
  {},
);
const displayStopped = ref<Record<string, boolean>>({});
const uiProcessing = computed(
  () => props.processing || Object.values(presenting.value).some((item) => item.busy),
);
function stopPresentation() {
  // Stop targets the actively recovering/presenting assistant turn, not an already completed turn.
  const replies = displayMessages.value.filter((message) => message.role === 'assistant');
  const message =
    replies.find((message) => message.recovering) ??
    replies.reverse().find((message) => presenting.value[message.id]?.busy) ??
    replies.find((message) => !message.state?.completion);
  if (!message) {
    if (props.processing) emit('abort');
    return;
  }
  const messageIndex = displayMessages.value.findIndex((item) => item.id === message.id);
  const source = props.messages[messageIndex];
  const thinking = source
    ? resolveChatContent(source)
        .filter((part) => part.type === 'thinking-content')
        .map((part) => ({ ...part, status: 'interrupted' }))
    : [];
  const parts = [...thinking, ...(presenting.value[message.id]?.capture() ?? [])].flatMap(
    (part) => {
      try {
        return [JSON.parse(JSON.stringify(part)) as ChatMessageContentItem];
      } catch {
        return [];
      }
    },
  );
  displayStopped.value = { ...displayStopped.value, [message.id]: true };
  emit('abort', { messageId: source?.id, messageIndex, parts });
}
const showSuggestionPills = computed(
  () => props.messages.length > 0 && props.suggestionPills.length > 0,
);
const composer = ref<InstanceType<typeof ChatComposer>>();
function sendSuggestion(item: ChatSuggestion) {
  if (item.disabled) return;
  submit(item.query ?? item.label, { aiEnabled: aiEnabled.value, mode: mode.value });
}
const promptsByMessage = computed(() =>
  props.messages.map((message) =>
    message.role?.startsWith('assistant') &&
    !message.loading &&
    !message.recovering &&
    !message.replyError &&
    !(props.error && message === props.messages.at(-1)) &&
    message.state?.completion === 'completed'
      ? (props.messagePrompts?.(message) ?? [])
      : [],
  ),
);
const aiEnabled = ref(false);
const mode = ref(props.modeOptions.find((option) => !option.disabled)?.value ?? '');
watch([aiEnabled, mode], () =>
  emit('composerChange', { aiEnabled: aiEnabled.value, mode: mode.value }),
);
watch(
  () => props.modeOptions,
  (options) => {
    if (!options.some((option) => option.value === mode.value && !option.disabled))
      mode.value = options.find((option) => !option.disabled)?.value ?? '';
  },
  { deep: true },
);
function resetComposer() {
  draft.value = '';
  aiEnabled.value = false;
  mode.value = props.modeOptions.find((option) => !option.disabled)?.value ?? '';
}
defineExpose({ resetComposer, captureView, locateReply });
watch(
  () => props.messages.length,
  (length, before) => {
    if (!props.conversationId && !length && before) resetComposer();
  },
);
watch(
  () => props.conversationId,
  () => {
    displayStopped.value = {};
    presenting.value = {};
  },
);
watch(
  () => props.messages.length,
  (length) => {
    if (!length) {
      displayStopped.value = {};
      presenting.value = {};
    }
  },
);
const placeholderActions = [
  { id: 'agent', label: 'agent 模块切换', icon: 'panel.mode' },
  { id: 'new', label: '新建对话', icon: 'panel.newConversation' },
  { id: 'history', label: '历史对话记录', icon: 'panel.history' },
] as const;
const fullscreenLabel = computed(() => (props.fullscreen ? '退出全屏' : '进入全屏'));
const visiblePlaceholderActions = computed(() =>
  placeholderActions.filter((action) => !props.fullscreen || action.id !== 'agent'),
);
const windowActionLabel = computed(() =>
  props.windowMode === undefined
    ? 'agent 模块切换'
    : props.windowMode === 'floating'
      ? '切换为侧栏模式'
      : '切换为悬浮模式',
);
function toggleWindowMode() {
  if (props.windowMode && !props.fullscreen)
    emit('windowModeChange', props.windowMode === 'sidebar' ? 'floating' : 'sidebar');
}
function toolbarClick(id: string, event: MouseEvent) {
  if (id === 'agent') toggleWindowMode();
  else if (id === 'new') emit('newConversation');
  else if (id === 'history' && props.historyAvailable && event.currentTarget instanceof HTMLElement)
    emit('historyOpen', event.currentTarget);
}
const main = ref<HTMLElement>();
const {
  suggestionShadows: contentEdgeShadows,
  scheduleSuggestionShadows: scheduleContentShadows,
  shadowClipStyle: contentShadowClip,
} = useSuggestionShadows(
  main,
  () => [props.messages, props.welcomeEntries, props.processing, props.conversationId],
  {
    itemSelector:
      '.chat-scroll .tr-bubble__box,.chat-scroll .dislike-feedback-card,.chat-scroll .message-prompt,.chat-welcome .chat-welcome-entry',
    portSelector: '.chat-scroll,.chat-welcome',
    nativeGutterOnly: true,
  },
);
useAutoScrollbars(
  () => main.value?.closest<HTMLElement>('.chat-panel') ?? undefined,
  [
    { selector: '.chat-scroll,.chat-welcome', axis: 'y' },
    { selector: '.table-wrap:not(.agreement-table__viewport)', axis: 'x' },
  ],
);
const canScrollUp = ref(false);
const canScrollDown = ref(false);
let resizeObserver: ResizeObserver | undefined;
let observedScrollPort: HTMLElement | undefined;
// TinyRobot 0.5.1: disable its mount-time autoScroll and follow only when user stays at bottom.
const followBottom = ref(true);
let lastFollowedScrollTop: number | undefined;
let scrollFrame = 0;
let modeScrollFrame = 0;
let readingAnchor: { node: HTMLElement; offset: number; fraction: number } | undefined;
function captureReadingAnchor(scroll: HTMLElement | null | undefined) {
  if (!scroll || (followBottom.value && scroll.matches('.chat-scroll'))) return undefined;
  const viewportTop = scroll.getBoundingClientRect().top;
  const anchor = Array.from(
    scroll.querySelectorAll<HTMLElement>(
      'p,li,h1,h2,h3,h4,pre,tr,[data-reply-key],.chat-welcome-entry',
    ),
  )
    .map((node) => ({ node, box: node.getBoundingClientRect() }))
    .filter((item) => item.box.height > 0 && item.box.bottom > viewportTop)
    .sort(
      (a, b) =>
        Math.max(0, a.box.top - viewportTop) - Math.max(0, b.box.top - viewportTop) ||
        a.box.height - b.box.height,
    )[0];
  if (!anchor) return undefined;
  const offset = anchor.box.top - viewportTop;
  return { node: anchor.node, offset, fraction: offset < 0 ? -offset / anchor.box.height : 0 };
}
// Preserve visible semantic anchor across fullscreen reflows (Sender editor selector targets TinyRobot 0.5.1).
watch(
  () => [props.windowMode, props.fullscreen] as const,
  ([, expanded], previous) => {
    const scroll = main.value?.querySelector<HTMLElement>('.chat-scroll,.chat-welcome');
    const input = composer.value?.$el.querySelector('.tr-sender-editor-scroll') as
      HTMLElement | undefined;
    const top = scroll?.scrollTop;
    const inputTop = input?.scrollTop;
    const following = followBottom.value;
    const reflow = expanded !== previous[1];
    const anchor = reflow ? readingAnchor : undefined;
    cancelAnimationFrame(modeScrollFrame);
    modeScrollFrame = requestAnimationFrame(() => {
      modeScrollFrame = 0;
      if (scroll && top !== undefined) {
        if (following && scroll.matches('.chat-scroll')) scroll.scrollTop = scroll.scrollHeight;
        else if (anchor?.node.isConnected) {
          const box = anchor.node.getBoundingClientRect();
          scroll.scrollTop +=
            box.top -
            scroll.getBoundingClientRect().top -
            (anchor.fraction ? -anchor.fraction * box.height : anchor.offset);
        } else scroll.scrollTop = top;
        lastFollowedScrollTop = scroll.scrollTop;
      }
      if (input && inputTop !== undefined) input.scrollTop = inputTop;
      followBottom.value = following;
      updateFade();
      publishView();
    });
  },
  { flush: 'pre' },
);
function onScroll(event: Event) {
  scheduleContentShadows();
  if (modeScrollFrame) return;
  const scroll = main.value?.querySelector('.chat-scroll');
  // Ignore delayed scroll events from our own programmatic scroll-to-bottom.
  if (scroll && event.target === scroll && scroll.scrollTop !== lastFollowedScrollTop)
    followBottom.value = scroll.scrollHeight - scroll.clientHeight - scroll.scrollTop <= 20;
  updateFade();
  publishView();
}
function followReply() {
  if (scrollFrame) return;
  scrollFrame = requestAnimationFrame(() => {
    scrollFrame = 0;
    syncFollowReply();
  });
}
function syncFollowReply() {
  const scroll = main.value?.querySelector('.chat-scroll');
  if (scroll && followBottom.value) {
    scroll.scrollTop = scroll.scrollHeight;
    lastFollowedScrollTop = scroll.scrollTop;
  }
  updateFade();
}
function followRenderedReply() {
  void nextTick(() => {
    if (!modeScrollFrame) syncFollowReply();
  });
}
function updateFade() {
  // REQ-015: subtract measured classic scrollbar width from safe inset so bubble widths stay stable.
  for (const port of main.value?.querySelectorAll<HTMLElement>('.chat-scroll,.chat-welcome') ??
    []) {
    if (observedScrollPort !== port) {
      if (observedScrollPort) resizeObserver?.unobserve(observedScrollPort);
      observedScrollPort = port;
      resizeObserver?.observe(port);
    }
    const gutter = `${port.offsetWidth - port.clientWidth}px`;
    if (port.style.getPropertyValue('--partner-ai-native-scrollbar-gutter') !== gutter)
      port.style.setProperty('--partner-ai-native-scrollbar-gutter', gutter);
  }
  const scroll = main.value?.querySelector('.chat-scroll');
  canScrollUp.value = !!scroll && scroll.scrollTop > 1;
  canScrollDown.value =
    !!scroll && scroll.scrollHeight - scroll.clientHeight - scroll.scrollTop > 1;
  if (!modeScrollFrame)
    readingAnchor = captureReadingAnchor(
      main.value?.querySelector<HTMLElement>('.chat-scroll,.chat-welcome'),
    );
}
// Detect new user turns even when user + assistant placeholder arrive in one batched update.
watch(
  () => {
    const users = props.messages.filter((message) => message.role === 'user');
    return [props.conversationId, users.length, users.at(-1)?.id] as const;
  },
  ([conversationId, count, id], [previousConversationId, previousCount, previousId]) => {
    if (conversationId !== previousConversationId) return;
    if (!props.messages.length || count > previousCount || (count > 0 && id !== previousId)) {
      followBottom.value = true;
      lastFollowedScrollTop = undefined;
      syncFollowReply();
    }
  },
  { flush: 'post' },
);
watch(
  () => [props.messages, props.processing, props.error, props.aborted, presenting.value],
  async () => {
    await nextTick();
    followReply();
  },
  { deep: true, flush: 'post' },
);
let restoringView = false;
function captureView(): ConversationViewState {
  return {
    draft: draft.value,
    aiEnabled: aiEnabled.value,
    mode: mode.value,
    scrollTop: main.value?.querySelector('.chat-scroll')?.scrollTop ?? 0,
    followBottom: followBottom.value,
  };
}
// REQ-024: locate answer via AnswerBox data-reply-key attribute; verify Box attr forwarding on upgrades.
async function locateReply(id: string) {
  await nextTick();
  const scroll = main.value?.querySelector<HTMLElement>('.chat-scroll');
  const reply = Array.from(scroll?.querySelectorAll<HTMLElement>('[data-reply-key]') ?? []).find(
    (node) => node.dataset.replyKey === id,
  );
  if (!scroll || !reply) return false;
  cancelAnimationFrame(scrollFrame);
  scrollFrame = 0;
  followBottom.value = false;
  reply.tabIndex = -1;
  reply.setAttribute('aria-label', '关联AI回答');
  reply.focus({ preventScroll: true });
  scroll.scrollTop += reply.getBoundingClientRect().top - scroll.getBoundingClientRect().top;
  lastFollowedScrollTop = scroll.scrollTop;
  updateFade();
  publishView();
  return true;
}
function publishView() {
  if (!restoringView && props.conversationId) emit('conversationViewChange', captureView());
}
watch([draft, aiEnabled, mode], publishView);
watch(
  () => props.conversationId,
  async () => {
    if (!props.conversationId) return;
    restoringView = true;
    cancelAnimationFrame(scrollFrame);
    scrollFrame = 0;
    const state = props.conversationView;
    draft.value = state?.draft ?? '';
    aiEnabled.value = state?.aiEnabled ?? false;
    mode.value = props.modeOptions.some(
      (option) => option.value === state?.mode && !option.disabled,
    )
      ? state!.mode
      : (props.modeOptions.find((option) => !option.disabled)?.value ?? '');
    followBottom.value = state?.followBottom ?? true;
    await nextTick();
    const scroll = main.value?.querySelector('.chat-scroll');
    if (scroll) {
      scroll.scrollTop = followBottom.value ? scroll.scrollHeight : (state?.scrollTop ?? 0);
      lastFollowedScrollTop = scroll.scrollTop;
    }
    updateFade();
    restoringView = false;
  },
  { flush: 'post', immediate: true },
);
onMounted(() => {
  resizeObserver = new ResizeObserver(followReply);
  if (main.value) resizeObserver.observe(main.value);
  followReply();
});
onBeforeUnmount(() => {
  resizeObserver?.disconnect();
  cancelAnimationFrame(scrollFrame);
  cancelAnimationFrame(modeScrollFrame);
});
const allRenderers = computed<BubbleContentRendererMatch[]>(() => [
  ...props.renderers.map((match) => ({ ...match, renderer: presentedRenderer(match.renderer) })),
  // TinyRobot 0.5.1 routes text to fallback by default; register explicit user/assistant text renderers.
  {
    find: (message, content) => message.role === 'user' && content.type === 'text',
    renderer: markRaw(BubbleRenderers.Text),
    priority: 5,
  },
  {
    find: (message, content) =>
      message.role === 'assistant' && content.type === 'text' && !message.loading,
    renderer: markRaw(DisplayedTextRenderer),
    priority: 5,
  },
  {
    find: (message, content) => message.role === 'assistant' && content.type === 'image_url',
    renderer: presentedRenderer(BubbleRenderers.Image),
    priority: 5,
  },
]);
const fallbackRenderer = presentedRenderer(FallbackRenderer);
const displayMessages = computed(() =>
  props.messages.map((message, index) => {
    const parts = resolveChatContent(message).filter((part) => part.type !== 'thinking-content');
    const display = {
      ...message,
      content: parts.length ? parts : [{ type: 'text', text: '' }],
      uiPartsOrdered: true,
      id: message.id ?? `message-${index}`,
      role: message.role?.startsWith('assistant') ? 'assistant' : message.role || 'assistant',
    };
    // TinyRobot 0.5.1 wraps remaining items in Reasoning if reasoning_content stays present.
    delete display.reasoning_content;
    delete display.uiParts;
    delete display.renderContent;
    return display;
  }),
);
const groups: Exclude<BubbleListProps['groupStrategy'], string | undefined> = (messages) =>
  messages.map((message, index) => ({
    role: message.role ?? 'assistant',
    messages: [message],
    messageIndexes: [index],
    startIndex: index,
  }));
const boxRenderers = computed<BubbleBoxRendererMatch[]>(() => [
  {
    find: (messages) => messages[0]?.role === 'assistant',
    renderer: markRaw(AnswerBox),
    attributes: (messages) => {
      const id = messages[0]?.id ?? '';
      const index = displayMessages.value.findIndex((message) => message.id === id);
      const message = messages[0] as UIMessage | undefined;
      // REQ-010: terminal state belongs to each reply; props.aborted is legacy fallback when state.completion is absent.
      const stopped =
        displayStopped.value[id] ||
        message?.state?.completion === 'aborted' ||
        (!message?.state?.completion &&
          props.aborted &&
          !props.processing &&
          index === displayMessages.value.length - 1);
      const source = props.messages[index] ?? message;
      const hasOutput = !!source && hasChatOutput(source);
      const reasoning =
        source && resolveChatContent(source).find((part) => part.type === 'thinking-content');
      const hasThinking = !!reasoning;
      const failure =
        message?.replyError ||
        (index === displayMessages.value.length - 1 ? props.error : '') ||
        (message?.state?.completion === 'error' ? '本次回答生成失败，请重试。' : '');
      const active =
        !!message?.recovering ||
        (props.processing &&
          !message?.state?.completion &&
          index === displayMessages.value.length - 1);
      return {
        replyKey: id,
        busy: uiProcessing.value,
        loading: !!message?.loading,
        stopped,
        hasOutput,
        failure,
        active,
        completion: message?.state?.completion,
        thinking: reasoning
          ? { content: String(reasoning.content ?? ''), status: reasoning.status }
          : undefined,
        expectedParts: Array.isArray(message?.content)
          ? message.content.flatMap((part, index) =>
              part.type === 'text'
                ? part.text
                  ? [{ index, signature: String(part.text) }]
                  : []
                : [{ index, signature: JSON.stringify(part) }],
            )
          : [],
        onDisplayBusy: (busy: boolean, capture?: () => ChatMessageContentItem[]) => {
          if (!capture) {
            if (presenting.value[id]) {
              const next = { ...presenting.value };
              delete next[id];
              presenting.value = next;
            }
            return;
          }
          if (presenting.value[id]?.busy !== busy || presenting.value[id]?.capture !== capture)
            presenting.value = { ...presenting.value, [id]: { busy, capture } };
        },
        onDisplayChange: followRenderedReply,
        onFeedback: (feedback: { reasons: string[]; detail: string }) =>
          emit('event', { name: 'chat:feedback', payload: { index, messageId: id, ...feedback } }),
        canContinue: props.continuationAvailable && hasOutput && !!(failure || stopped),
        progressText: !hasThinking && !stopped && active ? '正在思考中...' : '',
        onRegenerate: () => {
          displayStopped.value = { ...displayStopped.value, [id]: false };
          if (failure && index === displayMessages.value.length - 1) emit('retry');
          else emit('event', { name: 'chat:regenerate', payload: index });
        },
        onContinue: () => {
          displayStopped.value = { ...displayStopped.value, [id]: false };
          emit('event', { name: 'chat:continue', payload: index });
        },
      };
    },
  },
]);
// Synchronous latch covers the render gap before parent processing prop updates.
const submitting = ref(false);
function submit(value: string, context: ComposerRequestContext, preserveDraft = false) {
  if (uiProcessing.value || submitting.value || !value.trim()) return;
  submitting.value = true;
  followBottom.value = true;
  try {
    emit('send', value, { ...context });
    if (!preserveDraft) draft.value = '';
  } finally {
    void nextTick(() => {
      submitting.value = false;
    });
  }
}
function sendPrompt(item: ChatSuggestion, event?: KeyboardEvent) {
  if (item.disabled || event?.repeat) return;
  submit(item.query ?? item.label, { aiEnabled: aiEnabled.value, mode: mode.value }, true);
}
function welcome(entry: WelcomeBusinessEntry) {
  if (props.processing) return;
  emit('welcomeAction', entry);
  if (entry.query) submit(entry.query, { aiEnabled: false, mode: mode.value });
}
</script>
<template>
  <TrLayout
    mode="normal"
    class="chat-panel"
    :class="{ 'is-fullscreen': fullscreen }"
  >
    <template #header>
      <div
        v-show="!fullscreen"
        class="chat-handle-row"
      >
        <div
          v-ai-tooltip="{
            content:
              windowMode === 'sidebar'
                ? '按住拖动可转为悬浮窗；单击保持侧栏，也可按 Enter 切换'
                : windowMode === 'floating'
                  ? '拖动移动窗口；也可用方向键移动，Shift 加速'
                  : '',
            placement: 'top',
          }"
          class="chat-handle-area"
          :class="{ 'is-draggable': !!windowMode }"
          :aria-hidden="!windowMode ? true : undefined"
          :role="windowMode ? 'button' : undefined"
          :tabindex="windowMode ? 0 : -1"
          :aria-label="
            windowMode === 'sidebar'
              ? '拖动将 AI 侧栏转为悬浮窗（也可按 Enter）'
              : windowMode === 'floating'
                ? '移动 AI 悬浮窗（方向键移动，Shift 加速）'
                : undefined
          "
          @pointerdown="windowMode && emit('windowDragStart', $event)"
          @keydown="windowMode && emit('windowDragKeydown', $event)"
        >
          <span class="chat-handle" />
        </div>
      </div>
      <header
        class="chat-header"
        :class="{ 'is-welcome': !messages.length }"
      >
        <div
          v-if="messages.length"
          class="chat-identity"
        >
          <img
            v-if="avatarSrc"
            class="chat-identity-avatar"
            :src="avatarSrc"
            alt="AI 助手"
          /><span
            v-else
            class="assistant-avatar"
            ><AiIcon name="assistant.fallback"
          /></span>
          <h2>企业AI助手</h2>
        </div>
        <div
          class="chat-toolbar-actions"
          role="group"
          aria-label="AI 助手操作"
        >
          <TrActionButton
            v-if="toolbarActions.length && windowMode && !fullscreen"
            v-ai-tooltip="{ content: windowActionLabel, placement: 'top' }"
            :icon="aiIconVNode('panel.mode', { windowMode })"
            type="button"
            class="chat-toolbar-action"
            :aria-label="windowActionLabel"
            :aria-pressed="windowMode === 'floating'"
            @click="toggleWindowMode"
          />
          <div
            v-if="toolbarActions.length"
            class="chat-configurable-actions chat-configurable-actions--custom"
          >
            <button
              v-for="action in toolbarActions"
              :key="action.id"
              type="button"
              class="chat-toolbar-action"
              :disabled="action.disabled"
              @click="emit('toolbarAction', action)"
            >
              {{ action.label }}
            </button>
          </div>
          <div
            v-else
            class="chat-configurable-actions"
          >
            <TrActionButton
              v-for="action in visiblePlaceholderActions"
              :key="action.id"
              v-ai-tooltip="{
                content:
                  action.id === 'agent' && windowMode
                    ? windowActionLabel
                    : action.id === 'new' || (action.id === 'history' && historyAvailable)
                      ? action.label
                      : `${action.label}（尚未接入）`,
                placement: 'top',
                disabled: action.id === 'history' && historyOpen,
              }"
              :icon="aiIconVNode(action.icon, action.id === 'agent' ? { windowMode } : {})"
              type="button"
              class="chat-toolbar-action"
              :disabled="action.id === 'new' && newConversationDisabled"
              :aria-label="action.id === 'agent' ? windowActionLabel : action.label"
              :aria-pressed="
                action.id === 'agent' && windowMode ? windowMode === 'floating' : undefined
              "
              :aria-haspopup="action.id === 'history' && historyAvailable ? 'dialog' : undefined"
              :aria-expanded="action.id === 'history' && historyAvailable ? historyOpen : undefined"
              @click="toolbarClick(action.id, $event)"
            ></TrActionButton>
          </div>
          <TrActionButton
            v-if="fullscreen !== undefined"
            v-show="!delivery"
            v-ai-tooltip="{ content: fullscreenLabel, placement: 'top' }"
            :icon="aiIconVNode(fullscreen ? 'panel.exitFullscreen' : 'panel.fullscreen')"
            type="button"
            class="chat-toolbar-action chat-fullscreen-action"
            :aria-label="fullscreenLabel"
            :aria-pressed="fullscreen"
            @click="emit('fullscreenChange', !fullscreen)"
          />
          <TrActionButton
            v-if="closable"
            v-ai-tooltip="{ content: '收起 AI 侧栏', placement: 'top' }"
            :icon="aiIconVNode('panel.close')"
            type="button"
            class="chat-close-action"
            aria-label="收起 AI 侧栏"
            @click="emit('close')"
          />
          <slot name="toolbar-end" />
        </div>
      </header>
    </template>
    <template #main>
      <div
        ref="main"
        class="chat-main"
        :class="{ 'can-scroll-up': canScrollUp, 'can-scroll-down': canScrollDown }"
        @scroll.capture="onScroll"
      >
        <div
          class="content-edge-shadows"
          :style="contentShadowClip"
          aria-hidden="true"
        >
          <span
            v-for="shadow in contentEdgeShadows"
            :key="shadow.key"
            :style="shadow.style"
          />
        </div>
        <ChatWelcome
          v-if="!messages.length"
          :fullscreen="fullscreen"
          :avatar-src="avatarSrc"
          :entries="welcomeEntries"
          @select="welcome"
        />
        <TrBubbleProvider
          v-else
          :content-renderer-matches="allRenderers"
          :box-renderer-matches="boxRenderers"
          :fallback-content-renderer="fallbackRenderer"
        >
          <TrBubbleList
            :key="conversationId"
            class="chat-scroll"
            :class="{ 'is-following': followBottom }"
            :messages="displayMessages"
            :group-strategy="groups"
            :auto-scroll="false"
            content-render-mode="single"
            :content-resolver="resolveChatContent"
            :role-configs="{
              assistant: { shape: 'rounded' },
              user: { placement: 'end', shape: 'corner' },
            }"
            @bubble-event="emit('event', $event)"
          >
            <template #after="{ messageIndexes }">
              <MessagePrompts
                v-if="
                  promptsByMessage[messageIndexes[0]!]?.length &&
                  !presenting[displayMessages[messageIndexes[0]!]?.id ?? '']?.busy
                "
                :items="promptsByMessage[messageIndexes[0]!]!"
                :disabled="uiProcessing || submitting"
                :data-message-id="displayMessages[messageIndexes[0]!]?.id"
                @select="sendPrompt"
              />
            </template>
          </TrBubbleList>
        </TrBubbleProvider>
      </div>
    </template>
    <template #footer>
      <footer
        class="chat-footer"
        :class="{ 'has-suggestions': showSuggestionPills }"
      >
        <ComposerSuggestions
          v-if="showSuggestionPills"
          :items="suggestionPills"
          :disabled="uiProcessing || submitting"
          @select="sendSuggestion"
        />
        <div class="composer">
          <ChatComposer
            ref="composer"
            v-model="draft"
            v-model:ai-enabled="aiEnabled"
            v-model:mode="mode"
            :processing="uiProcessing"
            :mode-options="modeOptions"
            @submit="submit"
            @cancel="stopPresentation"
          />
        </div>
        <p class="composer-note">内容由AI生成，无法确保准确性和完整性，仅供参考。</p>
      </footer>
    </template>
  </TrLayout>
</template>

<style scoped>
/* REQ-003/014/017 (TinyRobot 0.5.1): local TrLayout/ActionButton overrides adapt handle, header,
   footer height, and focus rings without touching upstream internals; recheck .tr-* hooks on upgrades. */
.chat-panel .chat-handle-row {
  height: var(--partner-chat-handle-height, var(--partner-ai-handle-area-height));
  display: flex;
  align-items: center;
  justify-content: center;
  flex: none;
}
.chat-panel .chat-handle-area {
  width: var(--partner-ai-handle-hit-width);
  max-width: 100%;
  height: var(--partner-chat-handle-height, var(--partner-ai-handle-area-height));
}
.chat-panel .chat-handle-area.is-draggable {
  cursor: grab;
  touch-action: none;
}
.chat-panel .chat-handle-area.is-draggable:active {
  cursor: grabbing;
}
.chat-panel .chat-handle-area.is-draggable:focus-visible {
  outline: none;
}
.chat-panel .chat-handle-area.is-draggable:focus-visible .chat-handle {
  outline: var(--partner-ai-focus-width) solid var(--partner-ai-focus);
  outline-offset: var(--partner-ai-focus-offset);
}
.chat-panel .chat-handle {
  width: var(--partner-ai-handle-width);
  height: var(--partner-ai-handle-height);
  border-radius: var(--partner-ai-full-radius);
  transition:
    width var(--partner-ai-handle-motion-duration, var(--partner-ai-control-motion-duration))
      var(--partner-ai-control-motion-easing),
    height var(--partner-ai-handle-motion-duration, var(--partner-ai-control-motion-duration))
      var(--partner-ai-control-motion-easing);
}
.chat-panel .chat-handle-area.is-draggable:is(:hover, :focus-visible) .chat-handle {
  width: var(--partner-ai-handle-active-width);
  height: var(--partner-ai-handle-active-height);
}
@media (prefers-reduced-motion: reduce) {
  .chat-panel .chat-handle {
    transition: none;
  }
}
.chat-panel .chat-main :deep(.chat-scroll) {
  padding-left: var(--partner-ai-layout-safe-inset);
  padding-right: max(
    0px,
    calc(var(--partner-ai-layout-safe-inset) - var(--partner-ai-native-scrollbar-gutter, 0px))
  );
}
/* Disable browser scroll anchoring while auto-following bottom to avoid premature upward jumps. */
.chat-panel .chat-main :deep(.chat-scroll.is-following) {
  overflow-anchor: none;
}
.chat-panel .chat-header {
  height: var(--partner-chat-toolbar-height, var(--partner-ai-header-height));
  padding: 0 var(--partner-ai-layout-safe-inset);
  gap: var(--partner-ai-gap-lg);
  overflow: visible;
}
.chat-panel .chat-header.is-welcome {
  justify-content: flex-end;
}
.chat-panel .chat-header.is-welcome .chat-toolbar-actions {
  max-width: 100%;
}
.chat-panel .chat-identity {
  gap: var(--partner-ai-gap-md);
  overflow: hidden;
}
.chat-panel .chat-identity-avatar,
.chat-panel .chat-identity .assistant-avatar {
  width: var(--partner-ai-header-avatar-size);
  height: var(--partner-ai-header-avatar-size);
}
.chat-panel .chat-identity h2 {
  font-size: var(--partner-ai-header-title-size);
  font-weight: var(--partner-ai-heading-weight);
  line-height: var(--partner-ai-header-title-line);
  letter-spacing: var(--partner-ai-heading-letter-spacing, 0);
}
.chat-panel .chat-toolbar-actions {
  gap: var(--partner-ai-gap-lg);
  max-width: calc(100% - var(--partner-ai-header-avatar-size) - var(--partner-ai-gap-lg));
  flex: 0 0 auto;
}
.chat-panel .chat-configurable-actions {
  gap: var(--partner-ai-gap-lg);
  overflow-y: hidden;
}
.chat-panel :deep(.chat-toolbar-action),
.chat-panel .chat-toolbar-actions :deep(.chat-close-action) {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: var(--partner-ai-control-size);
  height: var(--partner-ai-control-size);
  min-width: var(--partner-ai-control-size);
  padding: var(--partner-ai-gap-sm);
  flex: none;
}
.chat-panel :deep(.chat-toolbar-action svg),
.chat-panel .chat-toolbar-actions :deep(.chat-close-action svg) {
  width: var(--partner-ai-icon-size);
  height: var(--partner-ai-icon-size);
}
.chat-configurable-actions
  :deep(.chat-toolbar-action svg[data-ai-icon-color='inherit'] [stroke='#191919']) {
  stroke: currentColor;
}
.chat-toolbar-actions :deep(.chat-toolbar-action:focus-visible) {
  outline: var(--partner-ai-focus-width) solid var(--partner-ai-focus);
  outline-offset: var(--partner-ai-focus-inset);
}
.chat-panel .chat-configurable-actions--custom :deep(.chat-toolbar-action) {
  width: auto;
  padding: var(--partner-ai-gap-sm) var(--partner-ai-gap-md);
}
.chat-panel .chat-footer {
  height: calc(
    var(--partner-chat-footer-height, var(--partner-ai-footer-height)) +
      var(--composer-measured-height, 132px) - 132px
  );
  padding: var(--partner-ai-footer-padding-block) var(--partner-ai-layout-safe-inset);
  grid-template-rows: minmax(0, 1fr) var(--partner-ai-disclaimer-height);
  gap: var(--partner-ai-footer-gap);
  overflow: visible;
}
.chat-panel .chat-footer .composer {
  padding: 0;
  overflow: visible;
  align-items: end;
}
.chat-panel .chat-footer .composer-note {
  color: var(--partner-ai-disclaimer-color);
  height: var(--partner-ai-disclaimer-height);
  line-height: var(--partner-ai-disclaimer-height);
}
.chat-panel.is-fullscreen .chat-main :deep(.chat-scroll),
.chat-panel.is-fullscreen .chat-footer {
  box-sizing: border-box;
  width: 100%;
  max-width: calc(
    var(--partner-ai-fullscreen-content-max-width, 800px) + 2 * var(--partner-ai-layout-safe-inset)
  );
  align-self: center;
  margin-inline: auto;
}
.chat-panel.is-fullscreen .chat-main :deep(.chat-welcome) {
  box-sizing: border-box;
  width: 100%;
  max-width: calc(
    var(--partner-ai-fullscreen-welcome-max-width, 1040px) + 2 * var(--partner-ai-layout-safe-inset)
  );
  align-self: center;
  margin-inline: auto;
}
</style>
