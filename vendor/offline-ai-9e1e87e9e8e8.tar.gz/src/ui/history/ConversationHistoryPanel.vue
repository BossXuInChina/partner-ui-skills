<script setup lang="ts">
import { vAiTooltip } from '../foundation/aiTooltip';
import { useDeliveryMode } from '../foundation/deliveryMode';
import { computed, nextTick, onBeforeUnmount, onMounted, ref, useId, watch } from 'vue';
import { TrHistory, type HistoryItem } from '@opentiny/tiny-robot';
import { AiIcon } from '../foundation/aiIcons';
import { useAutoScrollbars } from '../foundation/useAutoScrollbars';
import ConversationMoreMenu from './ConversationMoreMenu.vue';
import { groupConversationHistory, type ConversationRecord } from './conversationHistory';
const props = defineProps<{
  anchor: HTMLElement;
  open: boolean;
  records: ConversationRecord[];
  selected: string;
  busy: boolean;
  error: string;
  readFailed: boolean;
  blocked: boolean;
  clear: () => Promise<boolean>;
  remove: (id: string) => Promise<boolean>;
  select: (id: string) => Promise<boolean>;
}>();
const emit = defineEmits<{ close: []; closed: []; pin: [id: string]; reload: [] }>();
const delivery = useDeliveryMode();
const id = `history-${useId().replace(/[^a-zA-Z0-9-]/g, '')}`;
let changingPane = false;
const visible = ref(false);
const moreId = ref('');
const deleting = ref<HistoryItem>();
const deleteFailure = ref('');
const query = ref('');
const earlier = ref(false);
const confirming = ref(false);
const style = ref<Record<string, string>>({});
const search = ref<HTMLInputElement>();
const cancel = ref<HTMLButtonElement>();
const clearButton = ref<HTMLButtonElement>();
const content = ref<HTMLElement>();
const list = ref<HTMLElement>();
useAutoScrollbars(() => content.value, [{ selector: '.history-list', axis: 'y' }]);
const now = ref(Date.now());
const groups = computed(() =>
  groupConversationHistory(props.records, query.value, earlier.value, now.value),
);
const hasRecords = computed(() =>
  props.records.some((item) => item.messages.length || item.view.draft),
);
const hasEarlier = computed(() =>
  props.records.some(
    (item) =>
      !item.pinned &&
      item.updatedAt < now.value - 30 * 86400000 &&
      (item.messages.length || item.view.draft),
  ),
);
let observer: ResizeObserver | undefined;
let frame = 0;
let enterFrame = 0;
let leaveTimer = 0;
// REQ-016 (TinyRobot 0.5.1): use native non-modal popover top layer with TrHistory slots/tokens
// and REQ-015 list scrollbars (no generic Robot popup body API).
function position() {
  const hostElement = props.anchor.closest('.chat-panel');
  const host = hostElement?.getBoundingClientRect() ?? props.anchor.getBoundingClientRect();
  const box = props.anchor.getBoundingClientRect();
  const viewportWidth = document.documentElement.clientWidth;
  const viewportHeight = document.documentElement.clientHeight;
  const width = Math.max(0, Math.min(300, host.width - 24, viewportWidth - 24));
  const left = Math.max(
    12,
    host.left + 12,
    Math.min(box.right - width, host.right - width - 12, viewportWidth - width - 12),
  );
  const top = Math.max(12, Math.min(box.bottom + 8, viewportHeight - 100));
  // Keep the composer reachable when the history list has enough room above it.
  const composerTop = hostElement?.querySelector('.composer')?.getBoundingClientRect().top;
  const bottom = Math.min(
    host.bottom - 12,
    viewportHeight - 12,
    composerTop && composerTop - top >= 80 ? composerTop - 8 : Infinity,
  );
  const next = {
    left: `${left}px`,
    top: `${top}px`,
    width: `${width}px`,
    maxHeight: `${Math.min(520, Math.max(80, bottom - top))}px`,
  };
  const port = list.value;
  if (port) {
    const gutter = port.offsetWidth - port.clientWidth;
    const nativeTrack = parseFloat(getComputedStyle(port, '::-webkit-scrollbar').width);
    const track = gutter || (Number.isFinite(nativeTrack) ? nativeTrack : 14);
    // Center scrollbar track inside the right 16px inset via native gutter measurement.
    Object.assign(next, {
      '--history-scroll-extension': `${(16 + track) / 2}px`,
      '--history-native-gutter': `${gutter}px`,
    });
  }
  if (JSON.stringify(style.value) !== JSON.stringify(next)) style.value = next;
}
// Track anchor during host translate/drag animations where ResizeObserver won't fire.
function followAnchor() {
  position();
  frame = requestAnimationFrame(followAnchor);
}
function close(restore = true) {
  if (!props.open || props.busy) return;
  if (deleting.value) void cancelDelete();
  else if (moreId.value) moreId.value = '';
  else if (confirming.value) void cancelClear();
  else {
    if (restore) props.anchor.focus({ preventScroll: true });
    emit('close');
  }
}
function outside(event: PointerEvent) {
  if (!props.open) return;
  if (
    event.target instanceof Node &&
    !content.value?.contains(event.target) &&
    !props.anchor.contains(event.target)
  ) {
    if (props.busy) return;
    if (content.value?.contains(document.activeElement))
      props.anchor.focus({ preventScroll: true });
    emit('close');
  }
}
function focusOutside(event: FocusEvent) {
  if (!props.open || changingPane) return;
  if (
    event.target instanceof Node &&
    !content.value?.contains(event.target) &&
    !props.anchor.contains(event.target) &&
    !props.busy
  )
    emit('close');
}
function escape(event: KeyboardEvent) {
  if (props.open && event.key === 'Escape' && !document.querySelector('dialog[open]')) {
    event.preventDefault();
    event.stopPropagation();
    close();
  }
}
async function requestDelete(item: HistoryItem) {
  if (!item.id || props.busy || props.blocked) return;
  changingPane = true;
  moreId.value = '';
  deleteFailure.value = '';
  deleting.value = item;
  await nextTick();
  cancel.value?.focus();
  changingPane = false;
}
async function cancelDelete() {
  changingPane = true;
  const recordId = deleting.value?.id;
  deleting.value = undefined;
  deleteFailure.value = '';
  await nextTick();
  const trigger = [
    ...(content.value?.querySelectorAll<HTMLButtonElement>('.history-more') ?? []),
  ].find((button) => button.dataset.recordId === recordId);
  (trigger ?? search.value)?.focus({ preventScroll: true });
  changingPane = false;
}
async function deleteOne() {
  const item = deleting.value;
  if (!item?.id || props.busy || props.blocked) return;
  if (await props.remove(item.id)) {
    deleting.value = undefined;
    deleteFailure.value = '';
    await nextTick();
    search.value?.focus();
  } else deleteFailure.value = '删除失败，对话仍保留，请重试。';
}
async function confirmClear() {
  if (props.blocked || props.busy) return;
  confirming.value = true;
  await nextTick();
  cancel.value?.focus();
}
async function cancelClear() {
  confirming.value = false;
  await nextTick();
  clearButton.value?.focus();
}
async function clearAll() {
  if (!props.blocked && (await props.clear())) {
    confirming.value = false;
    await nextTick();
    search.value?.focus();
  }
}
async function choose(item: HistoryItem) {
  if (!item.id || props.busy || props.blocked) return;
  if (await props.select(item.id)) emit('close');
}
onMounted(async () => {
  if (!props.open) {
    emit('closed');
    return;
  }
  position();
  content.value?.showPopover();
  // Keep mounted through leave so reopening reverses the CSS transition cleanly.
  if (content.value) void content.value.offsetHeight;
  enterFrame = requestAnimationFrame(() => {
    visible.value = props.open;
  });
  props.anchor.setAttribute('aria-controls', id);
  document.addEventListener('pointerdown', outside, true);
  document.addEventListener('focusin', focusOutside);
  document.addEventListener('keydown', escape, true);
  followAnchor();
  observer = new ResizeObserver(position);
  const host = props.anchor.closest('.chat-panel');
  if (host) observer.observe(host);
  window.addEventListener('resize', position);
  window.addEventListener('scroll', position, true);
  await nextTick();
  search.value?.focus({ preventScroll: true });
});
function finishLeave(event?: TransitionEvent) {
  if (event && (event.target !== content.value || event.propertyName !== 'opacity')) return;
  if (!props.open) {
    window.clearTimeout(leaveTimer);
    emit('closed');
  }
}
watch(
  () => props.open,
  (open) => {
    cancelAnimationFrame(enterFrame);
    window.clearTimeout(leaveTimer);
    visible.value = open;
    if (!open) {
      moreId.value = '';
      const duration = content.value
        ? parseFloat(getComputedStyle(content.value).transitionDuration) * 1000
        : 0;
      leaveTimer = window.setTimeout(() => finishLeave(), duration + 20);
    } else void nextTick(() => search.value?.focus({ preventScroll: true }));
  },
);
onBeforeUnmount(() => {
  cancelAnimationFrame(frame);
  cancelAnimationFrame(enterFrame);
  window.clearTimeout(leaveTimer);
  observer?.disconnect();
  window.removeEventListener('resize', position);
  window.removeEventListener('scroll', position, true);
  document.removeEventListener('pointerdown', outside, true);
  document.removeEventListener('focusin', focusOutside);
  document.removeEventListener('keydown', escape, true);
  if (content.value?.contains(document.activeElement)) props.anchor.focus({ preventScroll: true });
  if (props.anchor.getAttribute('aria-controls') === id)
    props.anchor.removeAttribute('aria-controls');
  // Native top layer clears once local leave finishes.
});
</script>
<template>
  <section
    :id="id"
    ref="content"
    popover="manual"
    class="conversation-history-panel history-content"
    :class="{ 'is-visible': visible }"
    role="dialog"
    aria-modal="false"
    :aria-labelledby="`${id}-${deleting || confirming ? 'title' : 'browse-title'}`"
    :style="style"
    @transitionend="finishLeave"
  >
    <template v-if="deleting">
      <h2 :id="`${id}-title`">删除这条对话？</h2>
      <p class="history-delete-title">「{{ deleting.title }}」</p>
      <p>将永久删除这条对话的全部消息和输入草稿，无法撤销。</p>
      <p v-if="deleting.id === selected">删除当前对话后将回到新对话；正在生成的回复将停止。</p>
      <p
        v-if="deleteFailure"
        class="history-error"
        role="alert"
      >
        {{ deleteFailure }}
      </p>
      <div class="history-confirm-actions">
        <button
          ref="cancel"
          class="button button--quiet"
          :disabled="busy"
          @click="cancelDelete"
        >
          取消</button
        ><button
          class="button button--primary"
          :disabled="busy || blocked"
          @click="deleteOne"
        >
          {{ busy ? '删除中…' : '确认删除' }}
        </button>
      </div>
    </template>
    <template v-else-if="confirming">
      <h2 :id="`${id}-title`">清空全部历史对话？</h2>
      <p>将删除本产品全部历史对话，包含置顶会话、所有消息和输入草稿。此操作无法撤销。</p>
      <p
        v-if="error"
        class="history-error"
        role="alert"
      >
        {{ error }}
      </p>
      <div class="history-confirm-actions">
        <button
          ref="cancel"
          class="button button--quiet"
          :disabled="busy"
          @click="cancelClear"
        >
          取消</button
        ><button
          class="button button--primary"
          :disabled="busy || blocked"
          @click="clearAll"
        >
          {{ busy ? '清空中…' : '确认清空' }}
        </button>
      </div>
    </template>
    <div
      v-show="!confirming && !deleting"
      class="history-browse"
    >
      <header class="history-heading">
        <h2 :id="`${id}-browse-title`">历史对话</h2>
        <button
          ref="clearButton"
          v-ai-tooltip="{ content: '清空历史', disabled: !open, closeOnPointerLeave: true }"
          class="history-clear"
          type="button"
          aria-label="清空历史"
          :disabled="busy || blocked || !hasRecords"
          @click="confirmClear"
        >
          <AiIcon
            name="history.clear"
            aria-hidden="true"
          />
        </button>
      </header>
      <div class="history-search-core">
        <AiIcon
          name="history.search"
          class="history-search-icon"
          aria-hidden="true"
        /><input
          ref="search"
          v-model="query"
          class="history-search"
          type="search"
          aria-label="搜索历史对话标题"
          placeholder="搜索历史对话"
          autocomplete="off"
        /><button
          v-if="query"
          v-ai-tooltip="{ content: '清除搜索', disabled: !open, closeOnPointerLeave: true }"
          class="history-search-clear"
          aria-label="清除搜索"
          type="button"
          @click="
            query = '';
            search?.focus();
          "
        >
          <AiIcon
            name="history.clearSearch"
            aria-hidden="true"
          />
        </button>
      </div>
      <p
        v-if="blocked"
        class="history-hint"
      >
        请先完成或取消当前业务编辑。
      </p>
      <p
        v-if="error"
        class="history-error"
        role="alert"
      >
        {{ error }}
        <button
          class="text-button"
          :disabled="busy"
          @click="emit('reload')"
        >
          {{ readFailed ? '重新读取' : '重试保存' }}
        </button>
      </p>
      <div
        ref="list"
        class="history-list"
        :aria-busy="busy"
      >
        <!-- Supply keyboard buttons via TrHistory slots (0.5.1 rows are clickable divs); recheck .tr-* selectors on upgrade. -->
        <TrHistory
          v-if="groups.length"
          :data="groups"
          :selected="selected"
          :menu-items="[]"
          @item-click="choose"
        >
          <template #item-prefix="{ item }"
            ><button
              v-if="!delivery"
              v-ai-tooltip="{
                content: item.pinned ? '取消置顶' : '置顶',
                disabled: !open,
                closeOnPointerLeave: true,
              }"
              class="history-pin"
              :aria-label="`${item.pinned ? '取消置顶' : '置顶'}：${item.title}`"
              :aria-pressed="item.pinned"
              :disabled="busy"
              @click.stop="item.id && emit('pin', item.id)"
            >
              <AiIcon
                name="history.pin"
                aria-hidden="true"
              /></button
            ><ConversationMoreMenu
              :title="item.title"
              :record-id="item.id ?? ''"
              :open="moreId === item.id"
              :parent-open="open"
              :disabled="busy || blocked"
              @toggle="moreId = moreId === item.id ? '' : (item.id ?? '')"
              @close="moreId === item.id && (moreId = '')"
              @action="(action) => action.id === 'delete' && requestDelete(item)"
          /></template>
          <template #item-title="{ item }"
            ><button
              v-ai-tooltip="{
                content: item.title,
                overflowOnly: true,
                overflowSelector: 'span',
                disabled: !open,
              }"
              class="history-title"
              :aria-label="`切换会话：${item.title}`"
              :aria-current="item.id === selected ? 'true' : undefined"
              :disabled="busy || blocked"
              @click.stop="choose(item)"
            >
              <span>{{ item.title }}</span>
            </button></template
          >
        </TrHistory>
        <p
          v-else
          class="history-empty"
        >
          {{ query.trim() ? '未找到匹配的历史对话' : '暂无历史对话' }}
        </p>
        <button
          v-if="hasEarlier && !query.trim()"
          class="history-earlier text-button"
          :aria-expanded="earlier"
          @click="earlier = !earlier"
        >
          {{ earlier ? '收起更早对话' : '查看更早对话' }}
        </button>
      </div>
    </div>
  </section>
</template>
<style scoped>
/* Workbench popover/search/motion tokens adapted locally (268px menu body). */
.conversation-history-panel {
  --history-motion-duration: var(--partner-ai-history-motion-duration, 200ms);
  --history-motion-easing: var(--partner-ai-history-motion-easing, cubic-bezier(0.2, 0, 0, 1));
  position: fixed;
  inset: auto;
  margin: 0;
  box-sizing: border-box;
  width: var(--partner-ai-history-width);
  max-height: var(--partner-ai-history-max-height);
  border: 0;
  border-radius: var(--partner-ai-history-radius);
  background: var(--partner-ai-overlay-bg);
  color: var(--partner-ai-text);
  box-shadow: var(--partner-ai-overlay-shadow);
  font-family: var(--partner-ai-font-family, inherit);
  overflow: visible;
}
.conversation-history-panel::backdrop {
  background: transparent;
  pointer-events: none;
}
.history-content {
  display: flex;
  flex-direction: column;
  gap: var(--partner-ai-history-gap);
  padding: var(--partner-ai-history-padding);
}
/* Keep DropdownMenu Teleport targets mounted while confirmation toggles panes. */
.history-browse {
  display: flex;
  flex-direction: column;
  gap: var(--partner-ai-history-gap);
  min-height: 0;
  flex: 0 1 auto;
}
.history-heading {
  display: flex;
  align-items: center;
  gap: var(--partner-ai-history-gap);
  height: var(--partner-ai-history-row-height);
  min-height: var(--partner-ai-history-row-height);
  flex: none;
}
.history-content h2 {
  margin: 0;
  flex: 1;
  font-size: var(--partner-ai-history-heading-size);
  line-height: var(--partner-ai-history-heading-line);
  font-weight: var(--partner-ai-heading-weight);
}
/* REQ-025: 8px radius for local icon buttons without touching Robot internals. */
.history-clear,
.history-pin,
.history-search-clear {
  border-radius: var(--partner-ai-control-radius);
}
.history-clear {
  display: flex;
  align-items: center;
  justify-content: center;
  width: var(--partner-ai-control-size);
  height: var(--partner-ai-control-size);
  flex: none;
  padding: var(--partner-ai-gap-sm);
  border: 0;
  background: transparent;
  color: var(--partner-ai-icon-secondary);
  cursor: pointer;
}
.history-clear:hover {
  background: var(--partner-ai-hover-bg);
  color: var(--partner-ai-icon-primary);
}
.history-clear :deep(svg) {
  width: var(--partner-ai-icon-size);
  height: var(--partner-ai-icon-size);
}
.history-search-core {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  height: var(--partner-ai-control-size);
  min-height: var(--partner-ai-control-size);
  flex: none;
  padding-left: var(--partner-ai-gap-lg);
  border: var(--partner-ai-border-width) solid var(--partner-ai-border);
  border-radius: var(--partner-ai-radius-sm);
  background: var(--partner-ai-subtle-bg);
  font-size: var(--partner-ai-body-size);
  line-height: var(--partner-ai-body-line);
}
.history-search-core:hover {
  border-color: var(--partner-ai-border-hover);
}
.history-search-core:focus-within {
  border-color: var(--partner-ai-focus);
}
.history-search-icon {
  width: var(--partner-ai-history-search-icon-size);
  height: var(--partner-ai-history-search-icon-size);
  flex: none;
  margin-right: var(--partner-ai-gap-md);
  color: var(--partner-ai-icon-placeholder);
}
.history-search {
  height: 100%;
  min-width: 0;
  width: 100%;
  flex: 1;
  padding: 0 var(--partner-ai-gap-lg) 0 0;
  border: 0;
  outline: 0;
  background: transparent;
  color: var(--partner-ai-text);
  font: inherit;
}
.history-search:focus-visible {
  outline: 0;
  box-shadow: none;
}
.history-search::placeholder {
  color: var(--partner-ai-placeholder);
  opacity: 1;
}
.history-search::-webkit-search-cancel-button {
  display: none;
}
.history-search-clear {
  display: grid;
  place-items: center;
  align-self: stretch;
  flex: none;
  padding: 0 var(--partner-ai-gap-lg);
  border: 0;
  background: transparent;
  color: var(--partner-ai-icon-secondary);
  cursor: pointer;
}
.history-search-clear :deep(svg) {
  width: var(--partner-ai-history-search-icon-size);
  height: var(--partner-ai-history-search-icon-size);
}
/* REQ-016: row owns outer 4px right inset; more button pads SVG only. */
.history-list {
  box-sizing: border-box;
  flex: 0 1 auto;
  min-height: 0;
  width: calc(100% + var(--history-scroll-extension, 15px));
  margin-right: calc(0px - var(--history-scroll-extension, 15px));
  padding-right: calc(var(--history-scroll-extension, 15px) - var(--history-native-gutter, 0px));
  overflow-y: auto;
  overflow-x: hidden;
  overscroll-behavior: contain;
  --tr-history-group-title-color: var(--partner-ai-muted);
  --tr-history-group-title-font-size: var(--partner-ai-body-size);
  --tr-history-group-title-line-height: var(--partner-ai-body-line);
  --tr-history-item-color: var(--partner-ai-text);
  --tr-history-item-font-size: var(--partner-ai-body-size);
  --tr-history-item-line-height: var(--partner-ai-body-line);
  --tr-history-item-hover-bg: var(--partner-ai-hover-bg);
  --tr-history-item-selected-bg: var(--partner-ai-history-selected-bg);
  --tr-history-item-selected-color: var(--partner-ai-history-selected-text);
  --tr-history-item-border-radius: var(--partner-ai-radius-md);
  --tr-history-item-padding: 0 var(--partner-ai-gap-sm) 0 var(--partner-ai-gap-md);
  --tr-history-group-title-padding: 0 var(--partner-ai-gap-md);
  --tr-history-group-space-y: 8px;
  --tr-history-item-space-y: 0;
}
/* TinyRobot 0.5.1 DOM adapters: row/title geometry and empty action slot; recheck on upgrade. */
.history-list :deep(.tr-history__item-actions) {
  display: none;
}
.history-list :deep(.tr-history__group-title) {
  display: flex;
  align-items: center;
  height: var(--partner-ai-history-row-height);
  margin: 0;
  padding: 0 var(--partner-ai-gap-md);
  font-weight: var(--partner-ai-body-weight);
}
.history-list :deep(.tr-history__item) {
  min-width: 0;
  height: var(--partner-ai-history-row-height);
  box-sizing: border-box;
  gap: 0;
  font-weight: var(--partner-ai-body-weight);
}
/* Adapt native scrollbar paint for .history-list; useAutoScrollbars supplies hot/alpha state. */
@supports selector(::-webkit-scrollbar) {
  .history-list {
    scrollbar-width: auto;
    scrollbar-color: auto;
  }
  .history-list::-webkit-scrollbar {
    width: var(--partner-ai-scrollbar-size);
  }
  .history-list::-webkit-scrollbar-track {
    background: transparent;
  }
  .history-list::-webkit-scrollbar-thumb {
    background-color: var(--partner-ai-scrollbar-fill);
    border: var(--scrollbar-ai-safe, var(--partner-ai-scrollbar-safe)) solid transparent;
    background-clip: padding-box;
    border-radius: var(--partner-ai-scrollbar-radius);
  }
  .history-list[data-ai-scrollbar-state='hidden'][data-ai-scrollbar-hot='false']::-webkit-scrollbar-thumb {
    background-color: transparent;
  }
}
.history-pin,
.history-title {
  border: 0;
  background: transparent;
  color: inherit;
  font: inherit;
  cursor: pointer;
}
.history-title {
  order: -1;
  display: flex;
  align-items: center;
  min-width: 0;
  flex: 1;
  height: var(--partner-ai-history-row-height);
  padding: 0;
  margin-right: var(--partner-ai-gap-md);
  text-align: left;
}
.history-title span {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.history-pin {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  width: var(--partner-ai-control-size);
  height: var(--partner-ai-control-size);
  padding: var(--partner-ai-gap-sm);
  margin-right: calc(0px - var(--partner-ai-gap-sm));
  flex: none;
  opacity: 0;
  pointer-events: none;
  color: var(--partner-ai-icon-secondary);
}
/* Match the more action's 24px hover paint without shrinking its trigger. */
.history-pin::before {
  content: '';
  position: absolute;
  width: var(--partner-ai-icon-size);
  height: var(--partner-ai-icon-size);
  border-radius: var(--partner-ai-control-radius);
  pointer-events: none;
}
.history-pin:hover:not(:disabled)::before {
  background: var(--partner-ai-hover-bg);
}
.history-pin :deep(svg) {
  position: relative;
  width: var(--partner-ai-icon-size);
  height: var(--partner-ai-icon-size);
}
.history-pin[aria-pressed='true'] {
  color: var(--partner-ai-accent);
}
/* REQ-016: selected row tint + inherit orange-60 pin ink. */
.history-list :deep(.tr-history__item.selected) {
  background: var(--tr-history-item-selected-bg);
  color: var(--tr-history-item-selected-color);
}
.history-list :deep(.tr-history__item.selected) .history-pin,
.history-list :deep(.tr-history__item.selected .history-row-menu) {
  color: inherit;
}
.history-list :deep(.tr-history__item:hover) .history-pin,
.history-pin:focus-visible {
  opacity: 1;
  pointer-events: auto;
}
@media (hover: none), (pointer: coarse) {
  .history-pin {
    opacity: 1;
    pointer-events: auto;
  }
}
.history-delete-title {
  overflow-wrap: anywhere;
}
.history-confirm-actions {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  width: max-content;
  max-width: 100%;
  align-self: flex-end;
  gap: var(--partner-ai-history-gap);
}
.history-content p {
  margin: 0;
  font-size: var(--partner-ai-body-size);
  line-height: var(--partner-ai-body-line);
}
.history-empty,
.history-hint {
  color: var(--partner-ai-muted);
  padding: var(--partner-ai-gap-md) 0;
}
.history-error {
  color: var(--partner-ai-accent);
}
.history-earlier {
  display: flex;
  align-items: center;
  height: var(--partner-ai-history-row-height);
  margin: 0;
  padding: 0;
}
.history-content button:focus-visible {
  outline: var(--partner-ai-focus-width) solid var(--partner-ai-focus);
  outline-offset: var(--partner-ai-focus-near-offset);
}
.history-content button:disabled {
  opacity: var(--partner-ai-disabled-opacity);
  cursor: not-allowed;
}
.conversation-history-panel {
  transition:
    transform var(--history-motion-duration) var(--history-motion-easing),
    opacity var(--history-motion-duration) var(--history-motion-easing);
  transform: translateY(calc(0px - var(--partner-ai-history-motion-offset)));
  opacity: 0;
  pointer-events: none;
}
.conversation-history-panel.is-visible {
  transform: translateY(0);
  opacity: 1;
  pointer-events: auto;
}
@media (prefers-reduced-motion: reduce) {
  .conversation-history-panel {
    transition: none;
    transform: none;
  }
}
</style>
