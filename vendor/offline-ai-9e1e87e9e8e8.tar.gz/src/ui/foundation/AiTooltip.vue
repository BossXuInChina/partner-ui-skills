<script setup lang="ts">
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue';
import './actionTooltip.css';
import { claimTooltip, releaseTooltip } from './tooltipCoordinator';

// REQ-014 (TinyRobot 0.5.1): independent native-popover tooltip fallback until
// TinyRobot exposes a public Tooltip; directive supplies our own native root.
const props = defineProps<{
  trigger: HTMLElement;
  id: string;
  content: string;
  placement?: 'top' | 'bottom';
  disabled?: boolean;
  overflowOnly?: boolean;
  overflowSelector?: string;
  closeOnPointerLeave?: boolean;
}>();
const panel = ref<HTMLElement>();
const hitArea = ref<HTMLElement>();
const open = ref(false);
const owner = { close: dismiss };
const theme = ref<Record<string, string>>({});
let pointerInside = false;
let focusInside = false;
let dismissed = false;
let hideTimer: ReturnType<typeof setTimeout> | undefined;
let observer: ResizeObserver | undefined;
let textObserver: MutationObserver | undefined;
let positionFrame = 0;
let unmounted = false;
const observedText = new Set<HTMLElement>();
// REQ-014: overflow selectors adapt TinyRobot 0.5.1 Prompt/Pill classes; recheck on upgrade.
const portal = props.trigger.closest<HTMLElement>('[popover]');
function textElements() {
  return props.overflowSelector
    ? [...props.trigger.querySelectorAll<HTMLElement>(props.overflowSelector)]
    : [props.trigger];
}
function clipped() {
  return (
    !props.overflowOnly ||
    textElements().some(
      (el) => el.scrollWidth > el.clientWidth || el.scrollHeight > el.clientHeight,
    )
  );
}
function observeText() {
  const next = new Set(props.overflowOnly ? textElements() : []);
  for (const el of observedText)
    if (!next.has(el)) {
      if (el !== props.trigger) observer?.unobserve(el);
      observedText.delete(el);
    }
  for (const el of next)
    if (!observedText.has(el)) {
      observer?.observe(el);
      observedText.add(el);
    }
}
function reconcile() {
  observeText();
  const next = available() && !dismissed && (pointerInside || focusInside);
  if (next !== open.value) sync();
  else position();
}
const shown = computed(() => open.value && !!props.content && !props.disabled);
const tokens = [
  'bg',
  'text',
  'size',
  'line',
  'weight',
  'letter-spacing',
  'padding-x',
  'padding-y',
  'radius',
  'shadow',
  'font-family',
];
function captureTheme() {
  const style = getComputedStyle(props.trigger);
  const next: Record<string, string> = {};
  for (const name of tokens) {
    const token = `--partner-ai-tooltip-${name}`;
    const value = style.getPropertyValue(token).trim();
    if (value) next[token] = value;
  }
  // Propagate resolved fontFamily across body portals when token inherits.
  if (
    !next['--partner-ai-tooltip-font-family'] ||
    next['--partner-ai-tooltip-font-family'] === 'inherit'
  )
    next['--partner-ai-tooltip-font-family'] = style.fontFamily;
  theme.value = next;
}
function available() {
  return (
    !props.disabled &&
    !!props.content &&
    clipped() &&
    !props.trigger.matches(':disabled,[aria-disabled="true"]') &&
    !props.trigger.closest('[inert]')
  );
}
function describe(value: boolean) {
  const descriptions = new Set(
    (props.trigger.getAttribute('aria-describedby') ?? '').split(/\s+/).filter(Boolean),
  );
  if (value) descriptions.add(props.id);
  else descriptions.delete(props.id);
  if (descriptions.size)
    props.trigger.setAttribute('aria-describedby', [...descriptions].join(' '));
  else props.trigger.removeAttribute('aria-describedby');
}
function sync() {
  clearTimeout(hideTimer);
  const next = available() && !dismissed && (pointerInside || focusInside);
  // Close any superseded owner tooltip before opening ours.
  if (next) claimTooltip(owner, props.trigger);
  else releaseTooltip(owner);
  open.value = next;
  describe(next);
  if (open.value) {
    captureTheme();
    void nextTick(position);
  }
}
// Entering the trigger clears Escape suppression; entering only the hover bridge does not.
function enter(event: Event) {
  if (event.currentTarget === props.trigger) dismissed = false;
  pointerInside = true;
  sync();
}
function leave(event: Event) {
  pointerInside = false;
  // History hints dismiss immediately on pointer leave; keyboard focus remains until blur/Escape.
  if (props.closeOnPointerLeave && event.currentTarget === props.trigger) sync();
  else hide();
}
function focus() {
  dismissed = false;
  focusInside = true;
  sync();
}
function blur() {
  focusInside = false;
  hide();
}
function hide() {
  clearTimeout(hideTimer);
  hideTimer = setTimeout(() => {
    if (!pointerInside && !focusInside) dismissed = false;
    sync();
  }, 100);
}
function dismiss() {
  clearTimeout(hideTimer);
  dismissed = true;
  open.value = false;
  describe(false);
  releaseTooltip(owner);
}
function keydown(event: KeyboardEvent) {
  if (event.key !== 'Escape' || !shown.value) return;
  // Ignore Escape once pointer and focus both left (during the 100ms hover grace).
  if (!pointerInside && !focusInside) {
    dismiss();
    return;
  }
  // REQ-022: background hints must not consume foreground modal Escape.
  const doc = props.trigger.ownerDocument;
  const modals = [...doc.querySelectorAll<HTMLDialogElement>('dialog:modal')];
  const foreground = modals.filter((modal) => modal.contains(doc.activeElement)).at(-1);
  if (!available() || (modals.length && !foreground?.contains(props.trigger))) {
    dismiss();
    return;
  }
  event.preventDefault();
  event.stopPropagation();
  dismiss();
}
function position() {
  const element = panel.value;
  if (!shown.value || !element) return;
  const trigger = props.trigger.getBoundingClientRect();
  const rect = element.getBoundingClientRect();
  const viewportWidth = document.documentElement.clientWidth;
  const viewportHeight = document.documentElement.clientHeight;
  if (
    !available() ||
    !props.trigger.isConnected ||
    !trigger.width ||
    !trigger.height ||
    getComputedStyle(props.trigger).visibility !== 'visible' ||
    trigger.bottom <= 0 ||
    trigger.top >= viewportHeight ||
    trigger.right <= 0 ||
    trigger.left >= viewportWidth
  ) {
    dismiss();
    return;
  }
  // Dismiss if trigger scrolls completely outside a clipped ancestor.
  for (let ancestor = props.trigger.parentElement; ancestor; ancestor = ancestor.parentElement) {
    const style = getComputedStyle(ancestor);
    const bounds = ancestor.getBoundingClientRect();
    if (
      (/(auto|scroll|hidden|clip)/.test(style.overflowY) &&
        (trigger.bottom <= bounds.top || trigger.top >= bounds.bottom)) ||
      (/(auto|scroll|hidden|clip)/.test(style.overflowX) &&
        (trigger.right <= bounds.left || trigger.left >= bounds.right))
    ) {
      dismiss();
      return;
    }
  }
  const offset = 11;
  const edge = 4;
  let side = props.placement ?? 'top';
  const above = trigger.top - edge;
  const below = viewportHeight - trigger.bottom - edge;
  if (
    (side === 'top' ? above : below) < rect.height + offset &&
    (side === 'top' ? below > above : above > below)
  )
    side = side === 'top' ? 'bottom' : 'top';
  const left = Math.min(
    Math.max(edge, trigger.left + (trigger.width - rect.width) / 2),
    Math.max(edge, viewportWidth - edge - rect.width),
  );
  const top = Math.min(
    Math.max(edge, side === 'top' ? trigger.top - rect.height - offset : trigger.bottom + offset),
    Math.max(edge, viewportHeight - edge - rect.height),
  );
  element.dataset.placement = side;
  // Transformed popover acts as fixed containing block during entry/leave; offset coordinates.
  const portalStyle = portal && getComputedStyle(portal);
  const relative = portal && portalStyle?.transform !== 'none';
  const origin = relative ? portal.getBoundingClientRect() : { left: 0, top: 0 };
  element.style.left = `${left - origin.left}px`;
  element.style.top = `${top - origin.top}px`;
  // Keep 12px arrow aimed at trigger within rounded corner bounds.
  const style = getComputedStyle(element);
  const corner = side === 'top' ? 'Bottom' : 'Top';
  const minArrow = Math.min(rect.width / 2, 6 + parseFloat(style[`border${corner}LeftRadius`]));
  const maxArrow = Math.max(
    rect.width / 2,
    rect.width - 6 - parseFloat(style[`border${corner}RightRadius`]),
  );
  element.style.setProperty(
    '--tooltip-arrow-left',
    `${Math.min(Math.max(minArrow, trigger.left + trigger.width / 2 - left), maxArrow) - 6}px`,
  );
  // Carve centered header grip out of hover bridge hit area so it remains reachable.
  const grip = props.trigger
    .closest('.chat-header')
    ?.closest('.chat-panel')
    ?.querySelector<HTMLElement>('.chat-handle-area');
  const bounds = grip?.getBoundingClientRect();
  const hitTop = top - (side === 'bottom' ? offset : 0);
  if (hitArea.value) {
    const x1 = Math.max(0, (bounds?.left ?? left) - left);
    const x2 = Math.min(rect.width, (bounds?.right ?? left) - left);
    const y1 = Math.max(0, (bounds?.top ?? hitTop) - hitTop);
    const y2 = Math.min(rect.height + offset, (bounds?.bottom ?? hitTop) - hitTop);
    hitArea.value.style.clipPath =
      bounds?.width && bounds.height && x2 > x1 && y2 > y1
        ? `path(evenodd, "M0 0H${rect.width}V${rect.height + offset}H0Z M${x1} ${y1}H${x2}V${y2}H${x1}Z")`
        : '';
  }
}
// Track moving anchor (drag/mode/entry) without ResizeObserver; stays outside TinyRobot internals.
function followAnchor() {
  if (positionFrame || !shown.value || unmounted) return;
  positionFrame = requestAnimationFrame(() => {
    positionFrame = 0;
    position();
    followAnchor();
  });
}
watch(shown, async (value) => {
  if (!value) {
    cancelAnimationFrame(positionFrame);
    positionFrame = 0;
    releaseTooltip(owner);
  }
  describe(value);
  await nextTick();
  position();
  followAnchor();
});
watch(panel, (value, previous) => {
  if (previous) observer?.unobserve(previous);
  if (value) observer?.observe(value);
  position();
});
watch(
  () => [
    props.content,
    props.disabled,
    props.placement,
    props.overflowOnly,
    props.overflowSelector,
  ],
  () => {
    if (shown.value) captureTheme();
    void nextTick(reconcile);
  },
);
onMounted(() => {
  props.trigger.addEventListener('pointerenter', enter);
  props.trigger.addEventListener('pointerleave', leave);
  props.trigger.addEventListener('focus', focus);
  props.trigger.addEventListener('blur', blur);
  props.trigger.addEventListener('click', dismiss);
  props.trigger.addEventListener('pointerdown', dismiss);
  // Window capture handles the shown tooltip before parent menus consume Escape.
  window.addEventListener('keydown', keydown, true);
  window.addEventListener('resize', reconcile);
  document.addEventListener('scroll', position, true);
  observer = new ResizeObserver(reconcile);
  observer.observe(props.trigger);
  observeText();
  textObserver = new MutationObserver(reconcile);
  textObserver.observe(props.trigger, {
    subtree: true,
    childList: true,
    characterData: true,
    attributes: true,
    attributeFilter: ['class', 'style'],
  });
});
onBeforeUnmount(() => {
  unmounted = true;
  clearTimeout(hideTimer);
  cancelAnimationFrame(positionFrame);
  releaseTooltip(owner);
  describe(false);
  observer?.disconnect();
  textObserver?.disconnect();
  observedText.clear();
  props.trigger.removeEventListener('pointerenter', enter);
  props.trigger.removeEventListener('pointerleave', leave);
  props.trigger.removeEventListener('focus', focus);
  props.trigger.removeEventListener('blur', blur);
  props.trigger.removeEventListener('click', dismiss);
  props.trigger.removeEventListener('pointerdown', dismiss);
  window.removeEventListener('keydown', keydown, true);
  window.removeEventListener('resize', reconcile);
  document.removeEventListener('scroll', position, true);
});
</script>
<template>
  <Teleport :to="portal ?? 'body'">
    <span
      v-if="shown"
      :id="id"
      ref="panel"
      class="partner-ai-tooltip-content"
      role="tooltip"
      :style="theme"
      :class="{ 'is-trigger-only': closeOnPointerLeave }"
      @pointerenter="enter"
      @pointerleave="leave"
    >
      <span
        ref="hitArea"
        class="partner-ai-tooltip-hit-area"
        aria-hidden="true"
      />
      <svg
        class="partner-ai-tooltip-arrow"
        viewBox="0 0 12 8"
        aria-hidden="true"
      >
        <path d="M0 0h12L7.6 5.9C6.8 7 5.2 7 4.4 5.9L0 0Z" /></svg
      >{{ content }}
    </span>
  </Teleport>
</template>
