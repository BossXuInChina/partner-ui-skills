# 小灵思考动效来源

用户于2026-10-21提供的 `xiaoling-340.zip`，本地来源：`xiaoling-340.zip（本地绝对路径省略）`。选取包内 `src/` 的思考态Vue包装、无依赖JavaScript控制器及声明文件；不运行附件脚本、不引入额外运行库。数据保留340 viewBox与原始逐帧轨迹。JS实现通过声明文件接入，不代表完整TypeScript改写。

状态 `thinking` 循环；`completed` 在下一十字帧收尾；`interrupted` 立即暂停。业务正文状态与动画状态分离，由消息DOM展示确认驱动动画完成。修改：包装增加只读DOM状态标记供状态核对，并监听运行时reduced-motion变更；控制器/轨迹保持来源实现。
