import { computed, onBeforeUnmount, ref, watch, type Ref } from 'vue';
import type { UIMessage } from '../ui/messages/chatContent';
import type { ComposerRequestContext } from '../ui/composer/composerTypes';
import { createClientId } from '../ui/foundation/clientId';
import {
  browserConversationStorage,
  defaultHistoryNamespace,
  emptyConversationView,
  validateConversationSnapshot,
  type ConversationHistoryOptions,
  type ConversationRecord,
  type ConversationSnapshot,
  type ConversationViewState,
} from '../ui/history/conversationHistory';

interface ConversationEngine {
  messages: Ref<UIMessage[]>;
  error: Ref<string>;
  lastQuery: Ref<string>;
  activeRequestContext: Ref<ComposerRequestContext>;
  reset(): Promise<void>;
  restore(messages: UIMessage[]): void;
  stopAndSnapshot(): Promise<UIMessage[]>;
  snapshotMessages(): UIMessage[];
}
export function useConversationHistory(
  engine: ConversationEngine,
  options: ConversationHistoryOptions = {},
) {
  const namespace = options.namespace ?? defaultHistoryNamespace;
  const storage = options.storage ?? browserConversationStorage;
  const records = ref<ConversationRecord[]>([]);
  const activeId = ref('');
  const ready = ref(false);
  const busy = ref(false);
  const storageError = ref('');
  const readFailed = ref(false);
  let paused = false;
  let disposed = false;
  let timer: ReturnType<typeof setTimeout> | undefined;
  let writes: Promise<void> = Promise.resolve();
  let recoveringRead = false;
  let deletingId: string | undefined;
  let viewDuringDelete: { id: string; view: ConversationViewState } | undefined;
  const clone = <T>(value: T): T => JSON.parse(JSON.stringify(value));
  function blank(): ConversationRecord {
    return {
      id: createClientId(),
      title: '新对话',
      updatedAt: Date.now(),
      pinned: false,
      messages: [],
      view: emptyConversationView(),
      lastQuery: '',
      error: '',
      requestContext: { aiEnabled: false, mode: '' },
    };
  }
  const active = computed(() => records.value.find((item) => item.id === activeId.value));
  const view = computed(() => active.value?.view ?? emptyConversationView());
  function capture(touch = false) {
    const item = active.value;
    if (!item || (paused && !recoveringRead) || !ready.value) return;
    item.messages = clone(engine.snapshotMessages());
    item.error = engine.error.value;
    item.lastQuery = engine.lastQuery.value;
    item.requestContext = { ...engine.activeRequestContext.value };
    const query = item.messages.find((message) => message.role === 'user')?.content;
    if (typeof query === 'string') item.title = query.trim().slice(0, 80) || '新对话';
    else if (!item.messages.length) item.title = item.view.draft.trim().slice(0, 80) || '新对话';
    if (touch) item.updatedAt = Date.now();
  }
  function snapshot(): ConversationSnapshot {
    return clone({ version: 1, activeId: activeId.value, conversations: records.value });
  }
  function write(value = snapshot()) {
    // Serialize writes so queued streams cannot resurrect cleared records; block writes while readFailed.
    if (readFailed.value)
      return Promise.reject(new Error('请先重新读取历史，避免覆盖未读取的数据'));
    const job = writes.catch(() => {}).then(() => storage.write(namespace, value));
    writes = job;
    return job;
  }
  async function flush() {
    clearTimeout(timer);
    if (readFailed.value) return false;
    try {
      capture();
      await write();
      storageError.value = '';
      return true;
    } catch (failure) {
      const name = failure instanceof Error ? failure.name : '';
      storageError.value =
        name === 'QuotaExceededError'
          ? '历史保存失败：浏览器存储空间不足。当前内容仅在本页，请先复制重要内容；空间恢复后可重试保存。'
          : name === 'SecurityError'
            ? '历史保存失败：浏览器未允许此页面写入存储。当前内容仅在本页，请先复制重要内容，并向管理员确认站点存储权限后重试。'
            : '历史保存失败，当前内容仍在本页；请重试。';
      return false;
    }
  }
  function schedule() {
    if (paused || !ready.value) return;
    clearTimeout(timer);
    timer = setTimeout(() => {
      void flush();
    }, 180);
  }
  async function load() {
    if (busy.value) return;
    recoveringRead = ready.value && readFailed.value;
    busy.value = true;
    paused = true;
    let saveRecovered = false;
    try {
      const value = await storage.read(namespace);
      if (disposed) return;
      const data = value && validateConversationSnapshot(clone(value));
      // Merge durable storage with live active edits/stream after a failed read lifts.
      capture();
      const current = active.value;
      const hasPending =
        recoveringRead && records.value.some((item) => item.messages.length || item.view.draft);
      const pending = hasPending
        ? records.value.filter(
            (item) => item === current || item.messages.length || item.view.draft,
          )
        : [];
      const restored = data?.conversations ?? [];
      const ids = new Set(restored.map((item) => item.id));
      for (const item of pending) {
        if (ids.has(item.id)) item.id = createClientId();
        ids.add(item.id);
      }
      records.value = [...restored, ...pending];
      if (!records.value.length) records.value.push(blank());
      const keepCurrent = !!current && pending.includes(current);
      activeId.value = keepCurrent
        ? current.id
        : records.value.some((item) => item.id === data?.activeId)
          ? data!.activeId
          : records.value[0]!.id;
      if (!keepCurrent) {
        const item = active.value!;
        engine.restore(clone(item.messages));
        engine.error.value = item.error;
        engine.lastQuery.value = item.lastQuery;
        engine.activeRequestContext.value = { ...item.requestContext };
      }
      readFailed.value = false;
      if (!hasPending) storageError.value = '';
      saveRecovered = hasPending;
    } catch (failure) {
      readFailed.value = true;
      const reason =
        failure instanceof Error && failure.name === 'SecurityError'
          ? '浏览器未允许此页面读取存储。'
          : '';
      storageError.value = `历史读取失败，未覆盖已有存储。${reason}当前内容仅在本页；请先复制重要内容，再重新读取。`;
      if (!active.value) {
        const item = blank();
        records.value = [item];
        activeId.value = item.id;
      }
    } finally {
      ready.value = true;
      paused = false;
      busy.value = false;
      recoveringRead = false;
    }
    if (saveRecovered && !disposed) await flush();
  }
  async function change(id?: string) {
    if (!ready.value || busy.value || (id && !records.value.some((item) => item.id === id)))
      return false;
    if (id === activeId.value) return true;
    busy.value = true;
    clearTimeout(timer);
    try {
      // kit reset awaits abort/finally; capture after abort to retain stopped reply.
      capture();
      paused = true;
      const outgoing = active.value!;
      const saved = await engine.stopAndSnapshot();
      await engine.reset();
      outgoing.messages = saved;
      if (!id) {
        const item = blank();
        records.value.push(item);
        id = item.id;
      }
      activeId.value = id;
      const incoming = active.value!;
      engine.restore(clone(incoming.messages));
      engine.error.value = incoming.error;
      engine.lastQuery.value = incoming.lastQuery;
      engine.activeRequestContext.value = { ...incoming.requestContext };
    } finally {
      paused = false;
      busy.value = false;
    }
    await flush();
    return true;
  }
  async function pin(id: string) {
    if (busy.value || readFailed.value) return;
    clearTimeout(timer);
    capture();
    const item = records.value.find((item) => item.id === id);
    if (!item) return;
    busy.value = true;
    const previous = item.pinned;
    item.pinned = !previous;
    try {
      await write();
      storageError.value = '';
    } catch {
      item.pinned = previous;
      storageError.value = '置顶保存失败，请重试。';
    } finally {
      busy.value = false;
    }
  }
  async function clear() {
    if (!ready.value || busy.value) return false;
    busy.value = true;
    clearTimeout(timer);
    capture();
    paused = true;
    try {
      // Commit empty snapshot before mutating visible records so failures leave UI intact.
      await write({ version: 1, activeId: '', conversations: [] });
      await engine.reset();
      const item = blank();
      records.value = [item];
      activeId.value = item.id;
      storageError.value = '';
      return true;
    } catch {
      storageError.value = '清空失败，历史记录仍保留。请重试。';
      return false;
    } finally {
      paused = false;
      busy.value = false;
    }
  }
  async function remove(id: string) {
    if (
      !ready.value ||
      busy.value ||
      readFailed.value ||
      !records.value.some((item) => item.id === id)
    )
      return false;
    busy.value = true;
    clearTimeout(timer);
    capture();
    paused = true;
    deletingId = id;
    viewDuringDelete = undefined;
    const removingActive = id === activeId.value;
    let removed = false;
    try {
      if (removingActive) {
        // Restore stopped snapshot locally in case backend delete fails.
        const saved = await engine.stopAndSnapshot();
        engine.restore(saved);
        active.value!.messages = clone(saved);
      }
      const candidate = snapshot();
      candidate.conversations = candidate.conversations.filter((item) => item.id !== id);
      if (removingActive) {
        const item = blank();
        candidate.conversations.push(item);
        candidate.activeId = item.id;
      }
      // Pause autosave across serialized delete so in-flight streams cannot resurrect removed ID.
      await write(candidate);
      if (removingActive) await engine.reset();
      records.value = candidate.conversations;
      activeId.value = candidate.activeId;
      storageError.value = '';
      removed = true;
    } catch {
      storageError.value = '删除失败，历史对话仍保留。请重试。';
    } finally {
      paused = false;
      busy.value = false;
      const pendingView = viewDuringDelete as
        { id: string; view: ConversationViewState } | undefined;
      if (pendingView?.id === activeId.value && active.value)
        active.value.view = { ...pendingView.view };
      deletingId = undefined;
      viewDuringDelete = undefined;
      // Flush stream deltas received while deleting another record.
      capture(!!pendingView);
      if (!disposed && (!removingActive || !removed)) schedule();
    }
    return removed;
  }
  function updateView(value: ConversationViewState) {
    if (!active.value || !ready.value) return;
    // Keep drafts typed during another record's delete, without carrying them into a new blank successor.
    if (paused && deletingId) {
      viewDuringDelete = { id: activeId.value, view: { ...value } };
      return;
    }
    if ((paused || busy.value) && !recoveringRead) return;
    const before = active.value.view;
    active.value.view = { ...value };
    capture(before.draft !== value.draft);
    schedule();
  }
  watch(
    [engine.messages, engine.error],
    () => {
      capture(true);
      schedule();
    },
    { deep: true, flush: 'sync' },
  );
  function pagehide() {
    if (ready.value && !readFailed.value && !paused) void flush();
  }
  if (typeof window !== 'undefined') window.addEventListener('pagehide', pagehide);
  onBeforeUnmount(() => {
    disposed = true;
    clearTimeout(timer);
    window.removeEventListener('pagehide', pagehide);
    if (!paused && ready.value && !readFailed.value) void flush();
  });
  void load();
  return {
    records,
    activeId,
    view,
    ready,
    busy,
    storageError,
    readFailed,
    load,
    flush,
    change,
    pin,
    clear,
    remove,
    updateView,
  };
}
