import { computed, onBeforeUnmount, ref } from 'vue';
import { useMessage, type ChatCompletion, type UseMessageOptions } from '@opentiny/tiny-robot-kit';
import type { Agreement, AgreementAssistantAdapter, AssistantPart } from '../adapters/contracts';
import {
  hasChatOutput,
  resolveChatContent,
  type ChatDisplayStopSnapshot,
  type UIMessage,
} from '../ui/messages/chatContent';
import type { ComposerRequestContext } from '../ui/composer/composerTypes';
type UICompletion = ChatCompletion & {
  uiPart?: AssistantPart;
  requestContext?: ComposerRequestContext;
  generation?: number;
};
type ThinkingPart = AssistantPart & {
  type: 'unsupported';
  originalType: 'thinking-content';
  content: string;
  status: 'thinking' | 'completed' | 'interrupted';
};
function isThinkingPart(part: AssistantPart): part is ThinkingPart {
  const item = part as AssistantPart & { content?: unknown; status?: unknown };
  return (
    part.type === 'unsupported' &&
    part.originalType === 'thinking-content' &&
    typeof item.content === 'string' &&
    ['thinking', 'completed', 'interrupted'].includes(String(item.status))
  );
}
function mergeStreamedPart(
  parts: AssistantPart[] | undefined,
  incoming: AssistantPart,
): AssistantPart[] {
  const next = [...(parts ?? [])];
  if (isThinkingPart(incoming)) {
    const index = next.findIndex(isThinkingPart);
    if (index >= 0) next[index] = incoming;
    else next.push(incoming);
  } else next.push(incoming);
  return next;
}
function appendStreamedText(parts: AssistantPart[] | undefined, text: string): AssistantPart[] {
  const next = [...(parts ?? [])];
  const last = next.at(-1);
  if (last?.type === 'text') next[next.length - 1] = { ...last, text: last.text + text };
  else next.push({ type: 'text', text });
  return next;
}
function interruptThinking(message: UIMessage<AssistantPart> | undefined) {
  const parts = message?.uiParts;
  const index = parts?.findIndex(isThinkingPart) ?? -1;
  const part = index >= 0 ? parts?.[index] : undefined;
  if (part && isThinkingPart(part) && part.status === 'thinking') {
    message!.thinkingStatus = 'interrupted';
    message!.uiParts = [...parts!];
    const replacement = { ...part, status: 'interrupted' as const };
    message!.uiParts[index] = replacement;
  }
}
export function useAgreementAssistant(adapter: AgreementAssistantAdapter) {
  const error = ref('');
  const lastQuery = ref('');
  const activeRequestContext = ref<ComposerRequestContext>({ aiEnabled: false, mode: '' });
  const resetting = ref(false);
  let generation = 0;
  let chunkId = 0;
  // REQ-029 (kit 0.4.0): recovery reuses the existing message ref since kit send() always allocates a new placeholder.
  const recoveryState = ref<'idle' | 'processing' | 'completed' | 'error' | 'aborted'>('idle');
  let recoveryController: AbortController | undefined;
  let recoveryMessage: UIMessage<AssistantPart> | undefined;
  let pendingRequest: Promise<void> | undefined;
  const engine = useMessage({
    requestMessageFields: ['role', 'content'],
    // REQ-005 (kit 0.4.0): capture terminal completion state via finally hook (not sent in transport).
    plugins: [
      {
        name: 'partner-reply-completion',
        onFinally({ currentTurn, requestState }) {
          // REQ-010 (kit 0.4.0): early abort before first delta leaves role=''; stamp assistant role explicitly.
          for (const message of currentTurn)
            if (!message.role || message.role.startsWith('assistant')) {
              message.role ||= 'assistant';
              message.state = { ...message.state, completion: requestState };
            }
        },
      },
    ],
    // kit 0.4.0 declares a generic provider; this bridge always yields ChatCompletion chunks.
    responseProvider: async function* (body, signal) {
      const query = body.messages.filter((item) => item.role === 'user').at(-1)?.content ?? '';
      // REQ-003: snapshot routing context per submission; reject stale chunks via generation/signal.
      const requestGeneration = generation;
      const requestContext = { ...activeRequestContext.value };
      for await (const event of adapter.stream(query, signal, requestContext)) {
        signal.throwIfAborted();
        if (requestGeneration !== generation) return;
        const chunk: UICompletion = {
          id: `local-${++chunkId}`,
          object: 'chat.completion.chunk',
          created: Math.floor(Date.now() / 1000),
          model: 'consumer-adapter',
          system_fingerprint: null,
          choices: [
            {
              index: 0,
              message: undefined,
              delta: {
                role: 'assistant',
                ...(event.kind === 'text' ? { content: event.text } : {}),
              },
              logprobs: null,
              finish_reason: null,
            },
          ],
          ...(event.kind === 'part' ? { uiPart: event.part } : {}),
          requestContext,
          generation: requestGeneration,
        };
        yield chunk;
      }
    } as UseMessageOptions['responseProvider'],
    onCompletionChunk({ currentMessage, chunk }, runDefault) {
      if ((chunk as UICompletion).generation !== generation) return;
      runDefault(); // Required in kit 0.4.0 for delta merge and metadata.
      currentMessage.requestContext = (chunk as UICompletion).requestContext;
      // Preserve chronological text/card order without replacing kit's transport string.
      const text = chunk.choices[0]?.delta?.content;
      if (typeof text === 'string' && text)
        currentMessage.uiParts = appendStreamedText(
          currentMessage.uiParts as AssistantPart[] | undefined,
          text,
        );
      currentMessage.uiPartsOrdered = true;
      const part = (chunk as UICompletion).uiPart;
      if (part) {
        currentMessage.uiParts = mergeStreamedPart(
          currentMessage.uiParts as AssistantPart[] | undefined,
          part,
        );
        if (isThinkingPart(part)) {
          // Envelope supersedes reasoning_content for new mock messages; legacy field stays supported.
          delete currentMessage.reasoning_content;
          delete currentMessage.thinkingStatus;
        }
      }
      // Publish new array reference so BubbleList sees demo-owned UI part updates.
      engine.messages.value = [...engine.messages.value];
    },
  });
  const messages = computed(() => engine.messages.value as UIMessage<AssistantPart>[]);
  async function send(
    query: string,
    context: ComposerRequestContext = { aiEnabled: false, mode: '' },
  ) {
    if (isProcessing.value || resetting.value || !query.trim()) return;
    const requestGeneration = generation;
    recoveryState.value = 'idle';
    error.value = '';
    lastQuery.value = query;
    activeRequestContext.value = { ...context };
    // kit 0.4.0 send(message) preserves edge whitespace that sendMessage() trims; recheck on upgrade.
    const timestamp = Math.floor(Date.now() / 1000);
    const run = engine.send({
      role: 'user',
      content: query,
      metadata: { createdAt: timestamp, updatedAt: timestamp },
    });
    pendingRequest = run;
    try {
      await run;
    } catch (failure) {
      if (requestGeneration === generation) {
        error.value = failure instanceof Error ? failure.message : '查询失败，请重试。';
        const reply = messages.value.at(-1);
        interruptThinking(reply);
        if (reply) reply.replyError = error.value;
      }
    } finally {
      if (pendingRequest === run) pendingRequest = undefined;
    }
  }
  function updateRecord(record: Agreement) {
    for (const message of messages.value)
      for (const part of message.uiParts ?? []) {
        if (part.type === 'agreement-table')
          part.agreements = part.agreements.map((item) =>
            item.id === record.id ? { ...record } : item,
          );
      }
  }
  async function reset() {
    if (resetting.value) return;
    resetting.value = true;
    generation++;
    try {
      await abortRequest();
      await pendingRequest?.catch(() => {});
      engine.messages.value = [];
      recoveryState.value = 'idle';
      error.value = '';
      lastQuery.value = '';
      activeRequestContext.value = { aiEnabled: false, mode: '' };
    } finally {
      resetting.value = false;
    }
  }
  const isProcessing = computed(
    () => engine.isProcessing.value || recoveryState.value === 'processing',
  );
  const requestState = computed(() =>
    recoveryState.value === 'idle' ? engine.requestState.value : recoveryState.value,
  );
  async function recover(index: number, append: boolean) {
    const reply = messages.value[index];
    if (
      isProcessing.value ||
      resetting.value ||
      !Number.isInteger(index) ||
      !reply ||
      reply.role === 'user'
    )
      return;
    if (
      append &&
      (!adapter.continueStream ||
        !hasChatOutput(reply) ||
        !['error', 'aborted'].includes(String(reply.state?.completion)))
    )
      return;
    const query = messages.value
      .slice(0, index)
      .reverse()
      .find((message) => message.role === 'user')?.content;
    if (typeof query !== 'string' || !query.trim()) return;
    const context = { ...(reply.requestContext ?? { aiEnabled: false, mode: '' }) };
    const previous = {
      query,
      content: typeof reply.content === 'string' ? reply.content : '',
      parts: JSON.parse(JSON.stringify(reply.uiParts ?? [])) as AssistantPart[],
      context,
    };
    const token = ++generation;
    const controller = new AbortController();
    recoveryController = controller;
    recoveryMessage = reply;
    recoveryState.value = 'processing';
    activeRequestContext.value = context;
    lastQuery.value = query;
    error.value = '';
    reply.role = 'assistant';
    reply.id ??= `message-${index}`;
    reply.replyError = undefined;
    reply.state = { ...reply.state, completion: undefined };
    reply.recovering = true;
    if (!append) {
      reply.content = '';
      reply.uiParts = [];
      delete reply.reasoning_content;
      delete reply.thinkingStatus;
      delete reply.renderContent;
    } else if (!reply.uiPartsOrdered)
      reply.uiParts = [
        ...(reply.uiParts ?? []).filter(isThinkingPart),
        ...(resolveChatContent(reply).filter(
          (part) => part.type !== 'thinking-content',
        ) as AssistantPart[]),
      ];
    reply.uiPartsOrdered = true;
    reply.loading = !hasChatOutput(reply);
    const run = (async () => {
      try {
        const stream = append
          ? adapter.continueStream!(previous, controller.signal)
          : adapter.stream(query, controller.signal, context);
        for await (const delta of stream) {
          // A consumer may ignore abort and yield late. Both guards precede every mutation.
          if (controller.signal.aborted || token !== generation) return;
          reply.loading = false;
          if (delta.kind === 'part') {
            reply.uiParts = mergeStreamedPart(reply.uiParts, delta.part);
            if (isThinkingPart(delta.part)) {
              delete reply.reasoning_content;
              delete reply.thinkingStatus;
            }
            engine.messages.value = [...engine.messages.value];
          } else {
            reply.uiParts = appendStreamedText(reply.uiParts, delta.text);
            reply.content = String(reply.content ?? '') + delta.text;
          }
        }
        if (!controller.signal.aborted && token === generation) {
          reply.state = { ...reply.state, completion: 'completed' };
          recoveryState.value = 'completed';
        }
      } catch (failure) {
        if (!controller.signal.aborted && token === generation) {
          const reason = failure instanceof Error ? failure.message : '本次回答生成失败，请重试。';
          // Only report error globally when it affects the latest message.
          error.value = index === messages.value.length - 1 ? reason : '';
          reply.replyError = reason;
          reply.state = { ...reply.state, completion: 'error' };
          recoveryState.value = 'error';
        }
      } finally {
        if (token === generation) {
          reply.loading = false;
          reply.recovering = false;
          recoveryController = undefined;
          recoveryMessage = undefined;
        }
      }
    })();
    pendingRequest = run;
    try {
      await run;
    } finally {
      if (pendingRequest === run) pendingRequest = undefined;
    }
  }
  async function abortRequest(snapshot?: ChatDisplayStopSnapshot) {
    // Freeze stopped message to its visible snapshot so late transport deltas cannot restore unseen content.
    const index = snapshot
      ? messages.value.findIndex(
          (message, index) =>
            index === snapshot.messageIndex &&
            (!snapshot.messageId || message.id === snapshot.messageId) &&
            (!message.role || message.role.startsWith('assistant')),
        )
      : -1;
    if (snapshot && index >= 0) {
      generation++;
      const current = messages.value[index]!;
      const parts = JSON.parse(JSON.stringify(snapshot.parts)) as AssistantPart[];
      const stopped: UIMessage<AssistantPart> = {
        ...current,
        content: parts
          .filter((part) => part.type === 'text')
          .map((part) => part.text)
          .join(''),
        uiParts: parts,
        uiPartsOrdered: true,
        loading: false,
        recovering: false,
        replyError: undefined,
        thinkingStatus: 'interrupted',
        state: { ...current.state, completion: 'aborted' },
      };
      delete stopped.reasoning_content;
      delete stopped.renderContent;
      engine.messages.value = engine.messages.value.map((message, messageIndex) =>
        messageIndex === index ? stopped : message,
      ) as typeof engine.messages.value;
      recoveryState.value = 'aborted';
      error.value = '';
    }
    if (recoveryController) {
      generation++;
      recoveryController.abort();
      recoveryController = undefined;
      if (recoveryMessage) {
        interruptThinking(recoveryMessage);
        recoveryMessage.loading = false;
        recoveryMessage.recovering = false;
        recoveryMessage.state = { ...recoveryMessage.state, completion: 'aborted' };
      }
      recoveryMessage = undefined;
      recoveryState.value = 'aborted';
      error.value = '';
      // Do not wait for an adapter that ignores cancellation. Late output is guarded.
      pendingRequest = undefined;
    } else {
      interruptThinking(messages.value.at(-1));
      await engine.abortRequest();
    }
  }
  const regenerate = (index: number) => recover(index, false);
  const continueReply = (index: number) => recover(index, true);
  const retry = () => regenerate(messages.value.length - 1);
  onBeforeUnmount(() => {
    void abortRequest();
  });
  // REQ-016: restore through kit's public messages ref after the old request has settled.
  function restore(history: UIMessage[]) {
    recoveryState.value = 'idle';
    engine.messages.value = history as typeof engine.messages.value;
  }
  function snapshotMessages() {
    return [...messages.value];
  }
  async function stopAndSnapshot() {
    generation++;
    // kit 0.4.0 clears loading before finally; await settlement so aborted streams record completion=aborted.
    await abortRequest();
    await pendingRequest?.catch(() => {});
    const history = JSON.parse(JSON.stringify(snapshotMessages())) as UIMessage[];
    return history;
  }
  return {
    ...engine,
    isProcessing,
    requestState,
    abortRequest,
    messages,
    error,
    lastQuery,
    send,
    reset,
    restore,
    snapshotMessages,
    stopAndSnapshot,
    resetting,
    activeRequestContext,
    regenerate,
    continueReply,
    updateRecord,
    retry,
  };
}
