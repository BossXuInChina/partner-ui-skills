# Huawei Partner AI UI

2026-10-28交付快照`2026-10-28-handoff-0.3.0`保留该时点的标准Vue3 + TypeScript + Vite源码、预览及独立组件包，其实际内容与验证以归档内manifest/verification为准。当前工作区已继续修改，旧归档不能代表当前源码或当前构建。产品配置权限以交接页及COMPONENTS配置清单为准，公司私有平台注册与内网构建仍待接入验证。

本软件使用 HarmonyOS Sans Fonts。Copyright 2021 Huawei Device Co., Ltd. 字体原件和许可仅用于独立预览，组件包不含字库，由宿主统一提供字体，参阅 [字体接入与许可](docs/FONTS.md)。


设计开发交接先读 [HANDOFF.md](docs/HANDOFF.md)，预览入口 `/overview.html`。组件总览、当前Demo与当前构建消费同一份组件源码；重新交付归档须以重新验证后的快照为准。

Workbench来源边界：本地harness的Demo vendor及Studio移植仅用于演示工具，非公司内部正式/批准的资产源码。AI产品内另有保留来源的自包含Tooltip、滚动等最小适配，不导入Demo闭包；历史设计参考不构成运行时Token依赖或公司生产批准。正式接入由内部团队确认批准资产，分类见[交付职责清单](docs/COMPONENTS.md)。

当前评审版本 **0.3.0**。最新启动、公开接口、Sender/欢迎态配置、AI语义token、定制/升级风险与交付边界以[DELIVERY.md](docs/DELIVERY.md)为准。首次进入默认欢迎态，新建取消旧流并清理会话；后文保留旧轮次来源/验证背景，旧候选尺寸不再作为当前规范。

2026-10-20历史轮次仅收口交付分类与说明；当前交付状态见顶部2026-10-28更新。当前目录是唯一编辑工作区；私有GitHub `main/d928bb8a` 已从本地 `ba37028` 独立导入，原目录仍无remote。后续按[同步边界](docs/COMPONENTS.md#当前工作区与新远端的衔接)以远端main为父提交导入审核后的文件差量，保留其干净历史与说明，不直接推送原仓历史。

AI UI 公共样式采用独立设计 Token，默认值与引用链在包内闭合，不再导入或读取 Workbench Token。业务 Demo 仍保留其 Workbench 资产。默认声明、最终参数、来源与宿主 CSS 隔离限制见 [AI_TOKENS.md](docs/AI_TOKENS.md)，本轮范围与证据见 [AI_TOKEN_INDEPENDENCE.md](docs/AI_TOKEN_INDEPENDENCE.md)。

演示宿主默认进入交易导航下的智慧续签作业区；通过顶部“首页”可进入复用的 Workbench 公司信息页，保留注册信息、伙伴联系人、伙伴地址交互。交易入口是本地演示导航，不代表正式业务路由。官网导航全宽，下方侧栏支持默认挤压式和覆盖式；完整页面视口1920px起外宽480px、安全内距20px，否则420px、安全内距16px，内距包含在外宽内。

## 启动与入口

Node.js ≥22.12.0、pnpm 11.19.0：

```sh
pnpm install --frozen-lockfile
pnpm dev
```

- 主预览：<http://127.0.0.1:4178/>，默认 R2 演示宿主。
- 独立场景：<http://127.0.0.1:4178/renderer.html>。
- 首轮独立聊天回归入口：<http://127.0.0.1:4178/?view=assistant>。
- 构建预览：`pnpm build` 后先停 dev，再运行 `pnpm preview`，同为 4178。

点击业务页右下角机器人按钮唤醒助手。挤压式收窄业务区，覆盖式保持业务宽度；两者使用相同进退场轨迹。顶部导航保持全宽，两区独立滚动，业务滚动条默认隐藏、交互时显现。Studio可切换侧栏布局；两种侧栏均可切换或拖出悬浮窗。助手保持挂载，隐藏时 inert/不可聚焦；切换保留消息、输入草稿、业务编辑、滚动和流式状态。支持键盘唤醒、Escape、关闭按钮及入口焦点恢复。

按钮组复用原 FloatingButton 样式：48px命中尺寸、8px圆角、4px上下padding及原阴影。按钮锚定业务视口右边32px、底边178px；返回顶部距主组24px、底距106px。覆盖式侧栏保持业务区位置；挤压式在原页面位置仍能完整容纳时不移动页面，否则仅移动避免裁切所需的距离。定位框不占布局空间且自身不拦截业务指针，实际按钮可交互。

用户指定的 100×100 透明机器人原图用于 AI 按钮；两份素材均通过正式 Library 引用流程获取、保留文件身份并查看。原图和参考图位于 `.artifacts/library-assets/`，SHA/版本记录在 `.artifacts/round2/library-assets.json`。

## 产品与演示边界

| 路径 | 用途 |
| --- | --- |
| `src/ui/` | 按 foundation / panel / messages / composer / history 组织的消费层 UI；公共出口以 src/index.ts 为准 |
| `src/business/AgreementAssistantPanel.vue` | 可独立嵌入的 AI 业务面板，无重复页面外壳 |
| `src/business/useAgreementPanel.ts` | 当前查询、编辑、确认与操作保护逻辑 |
| `src/adapters/contracts.ts` | 消费方传输和操作接口 |
| `src/index.ts` | 产品入口：面板、通用聊天、卡片/表格及接口 |
| `src/demo/` | R2 页面、网站导航、悬浮组、用户头像与选定 Workbench 源码；仅演示 |
| `src/preview/`、`src/App.vue` | iframe Studio 与场景切换；仅预览 |
| `src/data/`、`mockAdapter.ts` | 虚构数据/模拟操作；仅预览 |

完整的职责、公开入口、消费方式、类型与来源对照见 [COMPONENTS.md](docs/COMPONENTS.md)。`ChatPanel` 是通用呈现入口，业务团队通过现有 `renderers` 提供自己的业务卡；`AgreementAssistantPanel` 是现成的协议会话组合，`AgreementTable` 是公开协议领域组件，Demo虚构数据与Workbench状态标签不属于其产品交付。内部Sender/Prompts/Pills仍通过面板配置使用，不新增独立出口。

`RenewalAssistant` 整页仍供首轮回归入口使用，**不再从 0.2.0 产品入口导出**。产品用法：

```vue
<script setup lang="ts">
import { AgreementAssistantPanel, type AgreementAssistantAdapter } from 'huawei-partner-ai-ui'
import 'huawei-partner-ai-ui/styles.css'
const props = defineProps<{ adapter: AgreementAssistantAdapter }>()
</script>
<template>
  <div style="height: 700px">
    <AgreementAssistantPanel :adapter="props.adapter" theme="workbench" />
  </div>
</template>
```

`pnpm build` 输出 `dist/` 演示及 `dist-lib/` 产品。构建时记录真实产品模块闭包并拒绝 demo/preview/fixture/整页外壳进入产品；证据为 `.artifacts/round2/product-boundary.json`。本地 tarball 独立消费测试检查 Vue 3.5.13、类型、构建和浏览器渲染，消费方需实现可取消流和服务端幂等。

## 依赖、来源与验证

Vue 3.5.13、TinyRobot 0.5.1、kit 0.4.0、根 svgs 0.3.5 保持不变；robot 内部依赖 svgs 0.5.1 正常并存。Workbench演示依赖采用本地自包含的选定源码/样式/资源闭包与声明边界，未依赖原工程运行。迁入的JS SFC不是完整TypeScript改写，以实际编译和浏览器行为验证；本工程UI、控制器和公共接口继续类型检查。

当前来源与本地适配差异见 [SOURCES.md](docs/SOURCES.md)和`src/demo/vendor/workbench/source-provenance.json`，包括导入路径、导航显示、原生弹层、悬浮按钮与分页避让接入。原Workbench工程只读，早期`.artifacts/round2/ported-sources.json`仅是当时来源证据。字体与许可仅作为预览可选资源保留，组件交付不含字库，见[FONTS.md](docs/FONTS.md)。

R2历史轮次按根[AGENTS.md](AGENTS.md)分层验证：当时执行lint/types/build，R2/顶部导航/挤压/状态/弹层/头像按钮组，以及受影响聊天行为的定向Chromium回归；产品公共入口改变，补实际包边界与独立消费。该轮没有重跑原Workbench全量、无关主题宽度排列或无关依赖重装。范围、耗时和结果记录于`.artifacts/round2/verification.json`，首轮证据保留在Git `a55a1ac`；这些不是2026-10-20文档整改的新测试结果。

公司 TurboUI 7.1.0 / Starling pc-runtime 7.1.7、正式manifest + entry样例/schema、loader与真实宿主/API尚未验证；不预设index.json扫描或manifest.component字段，详见[INTEGRATION.md](docs/INTEGRATION.md)。当前查询仍使用虚构协议示例，并未接入联系人/地址真实业务。未执行真实业务操作；GitHub私有初始导入已单独完成，本轮不推送。人工视觉确认、Windows/其他浏览器和极窄移动端尚待后续验收。

本次基础布局修复以 7fe629d 为基线。演示宿主复用 Drawer 的 Task-local 动效候选 200ms / cubic-bezier(0.2, 0, 0, 1)，业务区同步挤压/恢复；支持 reduced-motion、反向切换、焦点防过期与 preventScroll。正式 Foundation 尚无 Drawer 动效决策。最新定向范围与结果见 `.artifacts/layout-fix/verification.json`；产品包、依赖未变化，未重装或重复包消费。

悬浮定位修复以 `0718c75` 为基线，仅恢复演示 CSS 的 right token（8 → 32px），bottom 不变。960 / 1280 常屏 Studio、2240 铺满窗口的开关、滚动、输入、弹层与焦点定向检查 3 项通过（3.2 秒）；未执行全量回归、安装或产品重建。来源、修复前后业务视口坐标与首次数值判断误报说明见 `.artifacts/floating-position/verification.json`。


## 历史迭代记录

以下记录保留当时的需求、实现与验证，不作为当前设计值或交付结论；当前规范以顶部链接的交接文档和运行组件为准。

### 侧栏固定结构候选

侧栏占据官网导航下方全部可用高度，组件维持挂载。顶部为居中横条视觉区域与操作栏；中部 TinyRobot BubbleList 独立滚动，状态反馈通过公开 `after` 插槽随内容显示；底部为固定发送区和“内容由 AI 生成，请核实后使用。”。长输入仅在 Sender 内部滚动，消息与输入长度不改变头尾高度。默认挤压侧栏，受控悬浮／横条拖动见下方REQ-008本地增量。

当前默认配置：横条区域 **24px**、操作栏 **48px**、发送底区 **200px**（132px输入＋20px声明＋16px gap＋上下各16px）。有Pills附加48px。可用宿主 CSS 配置覆盖：`--partner-chat-handle-height`、`--partner-chat-toolbar-height`、`--partner-chat-footer-height`。宿主需为底区提供足够空间容纳发送按钮和免责声明；小于本轮验证高度的窗口仍需确认布局策略。

`AgreementAssistantPanel` 和 `ChatPanel` 新增 `avatarSrc`、`toolbarActions: ChatToolbarAction[]`、`toolbar-action` 事件及 `toolbar-end` 插槽。配置按钮仅发出事件，由消费方处理；右侧末尾插槽保留宿主关闭入口。按钮配置变化不创建新会话；可配置部分横向溢出时内部滚动，末尾关闭入口固定可见。未传`avatarSrc`时，面板默认使用用户指定的透明机器人头像（包内`src/assets/assistant-avatar.png`）；显式URL优先，空字符串保留语义图标回退。Demo及总览复用该公共资源，来源见[docs/SOURCES.md](docs/SOURCES.md)。

```vue
<script setup lang="ts">
import { AgreementAssistantPanel, type AgreementAssistantAdapter, type ChatToolbarAction } from 'huawei-partner-ai-ui'
const props = defineProps<{ adapter: AgreementAssistantAdapter; avatarUrl: string; closeSidebar: () => void }>()
// 以下按钮是本地 UI 入口。
const actions: ChatToolbarAction[] = [{ id: 'info', label: '说明' }]
function handleAction(action: ChatToolbarAction) { console.info(action.id) }
</script>
<template>
  <div style="height: 650px; --partner-chat-toolbar-height: 64px; --partner-chat-footer-height: 216px">
    <AgreementAssistantPanel :adapter="props.adapter" :avatar-src="props.avatarUrl"
      :toolbar-actions="actions" @toolbar-action="handleAction">
      <template #toolbar-end><button @click="props.closeSidebar">关闭助手</button></template>
    </AgreementAssistantPanel>
  </div>
</template>
```

当前证据在 `.artifacts/sidebar-structure/verification.json`：代表高度 600/900/1100 的固定几何、长消息/输入、开关状态；关联发送/重试/中止/Drawer/动效；原入口 right32/bottom178。因公共组件变化，补 lint、类型、演示与产品构建、包边界及离线缓存的独立 tarball 消费（含配置更新、焦点、禁用、末尾插槽和尺寸覆盖）。本工程未重装，依赖未变，未运行无关全量或原 Workbench 测试。


气泡/分隔线样式更新以 `9f8e963` 为基线。使用 TinyRobot 0.5.1 原生 Box 与公开 CSS tokens：user 浅色主题底、agent 文字纯白底，两者无边框并复用 Workbench shadow-sm；业务卡片/表格的已有背景、边框和阴影保留，其 TinyRobot 外层透明且无额外 padding/阴影。顶部/发送区分隔线及侧栏边界可见线已移除，顶部横条保留。按用户批准的轻量规则，只做 diff、相关 SFC lint、同一页面两主题样式确认（约2秒、1张截图）；未新增或运行测试套件、构建、重装或包消费。`.artifacts/bubble-style/verification.json` 为本次证据；此前18项自动化和 tarball 对应 `9f8e963` 布局基线，不作为新样式的自动化验收。


## 当前工作区：输入/消息修复与 Studio 预览

Studio 顶部「一期交付效果」可在新页面查看当前源码按一期交付可见性呈现的本地模拟：发送区只显示发送／停止，隐藏全屏与收藏入口；完整功能预览仍保留。两种预览使用不同的本地历史命名空间。此入口不是旧版交付包，也不代表内网或生产验证。

最新 UI 修复保留 Sender 原阴影，在发送区预留空间，移除激活下划线并保留整框键盘焦点；发送/停止入口为32px圆形。所有 agent 内容（含流式、业务结果和状态反馈）使用 TinyRobot 原生 Box，白底无边框带阴影；业务结果在气泡内清除重复表面，独立卡片组件不变。内容区12px羽化仅出现在可继续滚动的边缘，到首/尾时消退，键盘焦点进入内容时隐藏，不截获点击。固定头尾、右32/底178入口及两主题保持。

此前输入/消息与检视实现采用轻量验收（历史记录）：三项UI合并一次页面确认（2.1秒）；检视2项最小交互检查（2.4秒）及键入保护相关补查（1.8秒）；1条已有消息用例（5.4秒）；必要lint/types和产品边界构建（154ms），没有全量/重装/包消费。真实证据与未覆盖项见 `.artifacts/inspector-round/verification.json`。按用户新指示保留完整工作区改动，未自动提交；已有commit历史保持。


Studio 内置元素检视已于 2026-10-21 下架，使用独立 Chrome 扩展获取本地页面效果。场景切换、铺满窗口、Token 与渐变调试继续保留；历史验收证据不代表当前版本验证。

## 长需求协作

在 [collaboration/README.md](collaboration/README.md) 查看索引和使用方法；消息排版草稿为 [REQ-001](collaboration/requests/REQ-001-message-typography/request.md)。用户编辑正文与迭代记录后，在聊天中指出编号与版本。草稿不会自动执行；协作目录只在源码工作区提供，不进入产品dist/tarball。


## REQ-008 本地窗口模式增量

顶部agent按钮切换挤压侧栏／悬浮窗，floating恢复业务全宽。侧栏顶部原横条按住移动超过5px，直接进入悬浮并在同一次手势继续拖动；单击或轻微抖动保持侧栏。支持pointer capture、触摸与键盘（侧栏Enter／Space脱离，浮窗方向键移动、Shift加速）；按钮首入浮窗靠右，拖出按当前抓取点连续定位，位置在本次宿主会话内记忆并按可见工作区限制。关闭／重开保持最后模式、消息、草稿和流式请求。默认420/480响应式宽度及现有渐变／欢迎／追问／输入规范保持。

产品通过可选受控`windowMode`和三项窗口事件接入，未传prop的旧消费方保持原占位行为。宿主职责和公开接口见[INTEGRATION.md](docs/INTEGRATION.md)，需求记录见[REQ-008](collaboration/requests/REQ-008-assistant-window/request.md)。本地源码／dist-lib验证增量已纳入本次里程碑；未打包、未覆盖原交付ZIP。综合盘点见[AI_UI_AUDIT.md](docs/AI_UI_AUDIT.md)。

## AI UI 定制规范与组件总览

访问 `http://127.0.0.1:4178/overview.html`，或点击 Studio 顶部「AI UI 规范 ↗」。当前4178由本机launchd后台任务管理，聊天任务结束后在当前登录会话中继续运行；无需重复执行 `pnpm dev`。独立页面提供来源地图、现有语义token、可独立定位的组件/状态与设计开发接入片段；公开组件、面板配置、源码片段和仅Demo资产按交付职责区分。目录可搜索定位，示例不改业务demo样式。此页与示例数据仅在应用预览中，未进入公共库；API摘要不是公司平台注册manifest，内网构建与真实API仍待接入验证。需求与迭代见[REQ-027](collaboration/requests/REQ-027-ai-ui-overview/request.md)。

本机预览服务标识：`gui/501/local.codex.huawei-partner-ai-ui.preview4178`。日志与plist位于 `.artifacts/req-027-overview/service/`；此登记不设开机自启。若改用手动前台启动，先仅停止该服务：`launchctl bootout gui/$(id -u)/local.codex.huawei-partner-ai-ui.preview4178`，然后执行 `pnpm dev`；重新注销/开机后的后台启动：从本工程目录运行 `launchctl bootstrap gui/$(id -u) "$PWD/.artifacts/req-027-overview/service/preview-4178.plist"`。不终止其他端口服务。

统一语义图标支持内网应用局部替换与默认回退：见 [图标接入文档](docs/ICONS.md)。公开入口提供 `AiIconProvider` / `AiIcon`，`ChatPanel` / `AgreementAssistantPanel` 支持 `icons`；规范总览示例 `/overview.html#icon-integration`。
