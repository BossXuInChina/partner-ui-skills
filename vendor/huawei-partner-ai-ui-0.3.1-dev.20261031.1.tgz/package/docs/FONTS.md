# AI UI 字体接入

2026-10-26交付契约：组件包不包含字体文件、`@font-face`或字体资源URL。字体由宿主统一加载公司批准的字体；AI UI继承字体家族，继续固定字号、字重、行高和字间距。

## 宿主接入

宿主通过自己的字体资源服务与`@font-face`加载字体，并在应用祖先设置`font-family`。组件默认继承，无需复制AI项目字库，也不读取`--wb-*`。

```css
/* Company Sans由公司宿主自行注册/加载，此处只声明使用。 */
.company-app {
  font-family: "Company Sans", sans-serif;
}
```

需要跨嵌套AI根统一指定字体家族时，宿主可在应用祖先设置现有的可选Token：

```css
.company-app {
  --partner-ai-font-family: "Company Sans", sans-serif;
}
```

`--partner-ai-font-family:inherit`继承祖先提供的同名Token；没有Token时，组件的`font-family:var(--partner-ai-font-family,inherit)`继承实际父级字体。宿主未加载自定义字体时使用自己的浏览器回退。仅对接字体家族，不使用`font:inherit`覆盖AI字阶。模式菜单、建议集合、Tooltip及区域/全局Dialog在浮层边界传递来源元素已解析的字体家族。

字体接入属于宿主集成责任，只使用公司批准字体；产品不能据此修改AI字号、字重、行高、字间距或其他视觉规范。不同字体可能改变换行和字形宽度，内部接入时须验证长文本、省略和发送区。

## 固定字阶

| 内容 | 字号 / 行高 / 字重 |
| --- | --- |
| H0 / H1 / H2 / H3 | 20/28/500、18/26/500、16/24/500、14/22/500 |
| 正文 / 辅助文案 | 14/22/400、12/20/400 |
| 欢迎标题 / 说明 | 32/40/500、16/24/400 |

## 独立预览的可选字体

Vue脚手架中的预览入口显式导入`src/preview/optional-fonts.css`，由演示宿主加载本地HarmonyOS Sans/SC，保留当前设计效果。该入口不被公共`src/index.ts`或`styles.css`引用，不进入组件源码闭包、`dist-lib`或npm tarball。移除预览入口这条导入即可使用预览宿主自己的字体。

预览资源原件位于`src/assets/fonts/harmonyos-sans/`，两份TTF合计20,959,232字节，许可与来源说明同目录保留。原件来自只读Workbench提交`888140421f9e3367ba9217e7046aec5b7c9fa55b`，未转换、裁剪或修改。仅预览构建输出字体，原始许可同时保留在预览`dist/fonts/harmonyos-sans/LICENSE.txt`。

This preview software uses HarmonyOS Sans Fonts. Copyright 2021 Huawei Device Co., Ltd. 使用/转分发预览字体须保留原声明与LICENSE；详细原件SHA见源目录README。生产宿主字体许可由宿主维护。

## 验证与历史

本次无字库交付的实际检查范围以`2026-10-26-host-fonts-0.3.0`外层verification与POST_ASSEMBLY为准。2026-10-19曾验证包内字体、相对URL与字阶，作者工作区证据在`.artifacts/ai-fonts-20261019/`；该历史结果不代表当前组件仍携带字体。此前含字库的交付目录保持原样。
