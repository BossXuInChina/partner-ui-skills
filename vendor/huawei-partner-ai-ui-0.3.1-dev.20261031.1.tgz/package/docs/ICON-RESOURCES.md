# AI UI 本地图标资源

2026-10-26 按本次聊天确认的资源替换。所有运行图形在 `src/assets/ai-icons/` 内自包含；不导入 Workbench 图标组件，不在运行时访问原资源目录。

当前集中保存38份源SVG。它们是本包共享组件assets，运行图形编译到组件库JavaScript，随组件包分发；源码SVG不依赖运行时磁盘路径。资源本地化不代表所有位置均允许替换，产品配置权限与技术入口见[语义图标接入](ICONS.md#产品交付配置边界2026-10-26澄清)。

`source/` 完整保存 SVG，`provenance.json` 记录来源及 SHA-256（随包附带副本 `docs/icon-resource-provenance.json`），`artwork.ts` 是生成的 Vue 渲染数据。维护命令为 `python3 scripts/import-local-ai-icons.py`，只在设计资源实际更新时运行；构建不依赖 Python 或相邻项目。

| 用途 | 本地资源 |
| --- | --- |
| 新对话、历史、关闭 | 新对话.svg、历史对话.svg、关闭窗口.svg |
| 侧边栏 / 悬浮窗目标模式 | 平铺.svg / 浮窗.svg；沿用 `panel.mode` 覆盖键，按钮展示目标模式 |
| 模式主图标 / 下拉 | 深度思考icon16.svg / 下拉箭头.svg |
| 思考内容展开 | 深度思考-展开箭头.svg；12px，箭头与正文同时过渡；减少动态效果偏好禁用动画 |
| 语音、图片、发送、停止 | 对应 AI图标 SVG；24px |
| 重新生成、复制、清空历史 | 重新生成.svg、类型=复制.svg、清空历史.svg；24px |
| 点赞、点踩、收藏 | 各自 default / 激活 SVG；24px，随原有按压态切换 |
| 欢迎卡 | 紫色 / 蓝色 / 绿色渐变 SVG；24px |
| 全屏 / 退出全屏 | 激活全屏.svg / 退出全屏.svg；原生24px画板，自带图形留白 |
| 业务导航卡下钻 | 业务卡-下钻箭头.svg；24px，独立于消息追问箭头 |
| 智慧卡片详情箭头 | workbench-smartActionRight.svg；Workbench ic_arrow_right_line_10px（2:141），原生10px，继承链接颜色 |
| 右箭头、成功状态 | 向右箭头.svg、状态图标-成功.svg |
| 智慧渐变标记 | workbench-smartFilled.svg；24px面性原件1857:773，保留既有渐变mask；不与AI头像回退的线性资源共用 |
| 搜索、置顶、更多、AI头像回退、勾、错误、加号 | 从 Workbench 自有 SVG 源文件复制到 `source/workbench-*.svg`；详见来源清单 |

单色图形继承现有语义颜色，渐变、成功绿与收藏激活金色保留原色。零透明度编辑层、裁剪与几何保持不变；defs 引用使用每实例唯一 ID，避免多卡片串色。

全屏/退出全屏使用2026-10-26新增的两份独立资源，画板与工具栏槽位均为24px，图形位于约17px的内部区域；直接保留原生viewBox，不再额外缩放或通过变换生成退出形态。

公共 `AiIconProvider` / `icons` 覆盖机制、语义键与 SVG 槽位保持兼容；宿主自定义图标仍优先。TinyRobot 内部传递依赖依照锁文件保留，不用替换图形的工作改动其依赖版本。
