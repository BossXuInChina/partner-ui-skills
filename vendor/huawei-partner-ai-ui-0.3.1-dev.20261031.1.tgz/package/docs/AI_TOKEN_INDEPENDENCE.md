2026-10-26更新：组件包已剥离字库。字体家族由宿主提供并向下继承，字体大小/字重/行高仍由AI UI维护；下文2026-10-19的包内字体记录为历史状态，当前合同见[FONTS.md](FONTS.md)。

# AI UI 独立语义 Token 整改记录 · 2026-10-19

历史阶段状态：源码整改与字体接入在本任务收尾时完成，当时未打包、提交、推送或合并；下文保留各轮原始证据。后续这些源码已纳入本地检查点ba37028，并单独映射到私有GitHub main初始提交d928bb8a。2026-10-20仅收口分类/文档，没有生成新包、新提交或再次推送；当前边界见[COMPONENTS.md](COMPONENTS.md)。上述状态均不代表新视觉批准或公司内网验收。

分支 `feat/ai-ui-interactions-20261019`，基线提交 `77b25a8`。开始前保存了已有源码、文档、工作区 diff 与状态；证据目录为 `.artifacts/token-independence-20261019/`。原有 Pills demo、mock、Tooltip 与测试改动保留；其中 Tooltip 只叠加此次 Token 消费迁移。`preservation.json` 对原脏文件逐项比对。元素检视、移植 vendor、Workbench 源工程、package.json 与 pnpm-lock.yaml 均未改。

## 实际变更

- `src/index.ts` 移除 Workbench Token 库存导入。AI 默认值留在 `aiTokens.css`，智慧呈现参数留在 `workspaceIntelligence.css`，宿主外壳参数留在 `src/host/`；引用链在产品包内闭合。`--partner-ai-text` 默认明确为 `#191919`，字体不读取宿主 `--partner-font-*`。
- 公共样式、历史搜索／列表／菜单、滚动条、回复按钮、导航卡、智慧呈现、AiAlert、Tooltip、模式菜单、Dialog／Drawer 与宿主外壳改用对应 AI 语义参数。补齐字阶、字重、关键间距与尺寸、圆角、描边、渐变、阴影和动效消费；不把参数分散硬编码到各组件。
- Tooltip／UiDialog 不再复制 Workbench 变量。Tooltip 字族通过 AI 语义参数传递。原事件、Popover／Dialog、原生滚动和 TinyRobot 0.5.1 DOM 适配保持，未新增基础组件或架构层。
- 四层侧栏渐变与 Sender 六色描边、容器单位、比例计算、16／20px 安全留白、全文800／欢迎1040上限等原规则保留。SVG／mask 几何、布局0／100%、焦点描边和算法容差不机械拆为 Token。
- 保留已发现的两种把手动效：产品默认160ms，Demo显式150ms。独立宿主外壳原来透明，继续透明；显式 AI 范围与业务Demo保留原白色／对应主题表面。没有自行统一设计数值。
- 总览改为 AI 独立语义、AI 包内基础、宿主布局三类；显示默认声明、包内递归解析值、当前计算值、源文件及完整引用链。删除“AI 继承 Workbench 映射”的当前说明；历史来源保留。全部来源查询首批样例限制保持原80上界，不放宽测试阈值。

## 静态审计口径与数量

使用 Vite 实际库模块闭包，按唯一产品 `src` 文件去重，排除注释，统计 CSS `var()` 与 JS 字面量 `getPropertyValue()` 消费；对 AI 默认声明递归跟踪变量引用。不同主题／状态重复声明只取第一条默认。动态前缀复制另行人工检查，不把它伪装成可穷尽的静态调用计数。`native-scrollbar-gutter` 为 ChatPanel 实测后 `setProperty` 的运行时几何，不是缺失默认。

| 范围 | 改前 | 改后 |
| --- | ---: | ---: |
| 唯一产品源码模块文件 | 55 | 54 |
| 直接 Workbench 变量消费次数 | 250 | 0 |
| 直接 Workbench 变量不同名称 | 89 | 0 |
| 可递归到 Workbench 的 AI 默认声明 | 119 | 0 |
| AI 默认声明中的包外引用边 | 117 | 0 |
| AI 默认声明数 | 213 | 305 |
| 未声明且非运行时赋值的 AI 引用 | 0 | 0 |

新增声明用于本次明确遗漏的公共业务、历史、浮层、滚动条与几何角色；增加 Token 数量不代表新增视觉参数。构建后的公共 CSS 无 `--wb-*` 声明或引用，产品边界 `forbidden=[]`。Demo／预览仍可加载自己的 Workbench 资产，未纳入公共包闭包。

证据：`before/token-audit.json`、`after/token-audit.json`、`after/product-boundary.json`。复跑：

```sh
PARTNER_EVIDENCE_DIR=.artifacts/token-independence-20261019/after pnpm build
PARTNER_EVIDENCE_DIR=.artifacts/token-independence-20261019/after PARTNER_REQUIRE_INDEPENDENT=1 node scripts/audit-ai-tokens.mjs
PARTNER_EVIDENCE_DIR=.artifacts/token-independence-20261019/after PARTNER_TOKEN_BASELINE=.artifacts/token-independence-20261019/before/token-consumer.json node scripts/verify-token-consumer.mjs
```

独立消费脚本复制 `dist-lib`，使用公共导出与工程锁定的本地二进制／依赖；不执行 npm pack、包安装或 tarball 测试。既有 `pnpm test:consumer` 会打包，故本次遵照用户“不打包”要求使用上述等效针对性消费验证。

## 实际验证与限制

| 检查 | 结果与实际耗时 | 范围／证据 |
| --- | --- | --- |
| 改前构建 | 通过 | `before/build.log`，含类型、应用、库、声明与边界 |
| 改前现有定向基线 | 23通过／1失败，23.6s | `before/browser.json`；原 composer 用例期待 footer200，而既有 Pills 状态实际248；未修改产品或该断言 |
| 改前独立消费 | 13状态通过，11.29s | `before/token-consumer.json` |
| lint | 通过，3.87s | `lint-final.log` |
| typecheck | 通过，3.09s | `typecheck-final.log` |
| build | 通过，16.20s | `build-final.log`；应用、库、声明、边界，无依赖或锁文件变更；保留已有大chunk提示 |
| 静态 Token 审计 | 通过 | Workbench直接／间接0，包外默认引用0，未解析AI引用0 |
| 严格独立消费 | 39场景通过，18.76s | `after/token-consumer.json`：13状态×正常／无Workbench声明／宿主改写同名变量，关键计算样式相对改前与正常均无差异；字体、颜色、渐变、间距、尺寸、圆角、边框、阴影、动效与伪元素 |
| 公共样式受影响矩阵 | 初次69通过／15失败，约1.7min | `after/browser.json`；14个spec，84用例，不称全仓通过 |
| Token总览／AiAlert及结构修正 | 18通过／1失败，12.2s；修正外壳后该1项通过2.5s | `after/token-ui-recheck.json`、`after/overview-shell-recheck.json`，保留原80样例阈值 |
| 全屏焦点最小重验 | 1通过，2.4s | `after/focus-recheck.json`；初轮并发下有退出动效／Escape时序失败，不宣称消除了时序风险 |
| Tooltip最终语义字族验证 | 8通过，13.3s | `after/tooltip-semantic-recheck.json`，含响应宽度、reduced-motion、浮层、拖动、碰撞及原有hit-area |

独立消费覆盖侧栏／悬浮／全屏的欢迎与消息状态、草稿保留、模式菜单键盘关闭、历史菜单及更多操作、Tooltip、区域弹窗、区域Drawer、全局原生Dialog、焦点，以及独立WorkspaceSmartCard／Tag、Summary、NavigationCard、AgreementTable与AiAlert。只使用本机 Chromium headless；没有打开／激活可见浏览器窗口。

首轮有效用例按相同文件／标题去重并以受修改影响的最小重验替换：当时92个受影响用例中80项通过、12项保留失败；不是全量通过。首轮失败归因与改前准确复现见下文，后续夹具修复结果另记。

临时隔离基线的前两次尝试分别受 macOS `/var` 实路径与 Vue 缓存URL不一致干扰，不能作为有效旧基线证据；并发默认输出曾导致 trace 路径冲突。另一次 `pnpm --dir <临时目录> exec vite` 意外触发临时目录自动依赖安装，因忽略esbuild构建脚本退出。原工程未重装、锁文件未改；没有执行 approve-builds 或绕过审批。该尝试不作冻结锁验证。之后改为调用工程锁定二进制，独立输出、相同Vue缓存URL，保留原始诊断日志。

### 剩余12项的改前复现

最终准确的旧基线使用开始时保存的源码、锁定依赖、相同 Vue 缓存 URL 与独立测试输出。`before/diagnostic-browser-canonical.json` / `diagnostic-tests-canonical.log` 中12项全部在整改前复现相同错误类型，耗时47.07s；未把前三次无效诊断当作证明。

| 数量 | 原有用例 | 改前与改后相同失败 |
| --- | --- | --- |
| 3 | auto-scrollbars：Sender／touch／Pills dwell | 欢迎态夹具没有 `.tr-suggestion-pills__container`，等待属性失败 |
| 3 | scrollbar：420／480／touch | 欢迎态夹具没有 `.composer-suggestions` |
| 3 | sender-height：420／480／short floating | 旧 metrics 访问缺失的 `.composer-suggestion`，读取矩形时报null |
| 2 | business-navigation：1280／2240 | 找不到旧名称“打开续签作业区”的按钮 |
| 1 | history：stream switch | slow夹具没有出现“停止生成”按钮 |

首轮未通过改产品、改夹具或降阈值规避这些失败；后续经授权修复夹具前置条件，见下节。初始 composer 200/248 断言基线失败仍单独保留，不能声称工程全绿。

## 后续收尾

补齐既有按钮、Drawer、字段、表格标题与图标、描边和焦点尺寸等明确遗漏后，AI默认声明从首轮305增加到322；公共源码闭包仍54文件，Workbench直接消费0、不同名称0、间接默认0、包外默认引用0、未解析AI引用0。总览从源码实时读取；`AI_TOKENS.md`已同步当前默认声明、最终值与来源行号。后续公共业务组件扩改按用户指示暂停。

夹具前置条件修复后，首轮12个失败用例中11个通过；剩余 short-floating 场景恢复执行后触发Home最小Sender断言（期望86px，实际102px）。准确改前源码亦复现86/102，不修改该断言或现有尺寸规则。`followup/previous-failures.json`为8通过/4失败（38.60s），`remaining-four.json`为3通过/1失败（6.95s），`before-floating-minimum.json`保留改前复现（2.36s）；3个语义契约场景（1.94s）和1个集合呈现场景（5.82s）通过。这些是定向结果，不重新宣称全仓或92项完整重跑通过。

经用户授权，将原始HarmonyOS Sans／SC与LICENSE复制到AI包内，通过AI字体Token消费；字号、行高、字重、间距与几何规则保持。字体开发/独立消费共12样例及2个欢迎/正文补验通过；最终lint、typecheck、build通过，包边界无demo/preview/mock。字体来源、原件校验、资源体积、子路径URL修复与验证范围见 [FONTS.md](FONTS.md) 和 `.artifacts/ai-fonts-20261019/`。未重复此前39场景矩阵。

## 剩余边界

Token 独立不等同于任意宿主 CSS 隔离。宿主 reset、标签／同名类、较高优先级或 `!important`、TinyRobot 全局规则、字体、body浮层样式、原生 top layer、层叠与容器尺寸仍可能影响呈现。没有新增 Shadow DOM／iframe，不承诺前缀足以阻挡任意宿主CSS。

公司内网构建、schema、真实API、跨浏览器、真机输入法／触屏、跨文档浮层未验证。依赖／锁文件没变，未重复正式干净安装；没有执行 tarball／ZIP 打包、推送、合并或自动提交。仍有上述既有断言问题，不能视为正式全绿交付门禁。

预览：`http://127.0.0.1:4178/overview.html?page=tokens`（默认声明／最终值／引用链）；`http://127.0.0.1:4178/renderer.html`（现有业务Demo）；`/overview.html?page=panel`、`workspace-card`、`business-navigation`、`handoff` 可查看对应组件。用户既有4178后台服务保留。

## 本次改动文件

- `src/styles.css`
- `src/index.ts`
- `src/demo/demo.css`
- `src/ui/aiTokens.css`
- `src/ui/scrollbarStyles.css`
- `src/ui/ChatComposer.vue`
- `src/ui/ConversationHistoryPanel.vue`
- `src/ui/autoScrollbarStyles.css`
- `src/ui/AiTooltip.vue`
- `src/ui/dialogMotion.ts`
- `src/ui/actionTooltip.css`
- `src/ui/ConversationMoreMenu.vue`
- `src/ui/AiAlert.vue`
- `src/ui/ChatPanel.vue`
- `src/ui/UiDialog.vue`
- `src/ui/messageStyles.css`
- `src/ui/ChatWelcome.vue`
- `src/ui/globalDialogMotion.ts`
- `src/host/assistantWindow.css`
- `src/host/AssistantHostLayout.vue`
- `src/business/WorkspaceSmartCard.vue`
- `src/business/BusinessNavigationCard.vue`
- `src/business/workspaceIntelligence.css`
- `src/preview/overview/TokenSample.vue`
- `src/preview/overview/tokenInventory.ts`
- `src/preview/overview/HandoffGuide.vue`
- `src/preview/overview/TokenBoard.vue`
- `src/preview/overview/TokenDetails.vue`
- `src/preview/overview/OverviewDocument.vue`
- `scripts/audit-ai-tokens.mjs`
- `scripts/verify-token-consumer.mjs`
- `tests/ai-alert.spec.ts`
- `tests/overview-tokens.spec.ts`
- `tests/overview-structure.spec.ts`
- `README.md`
- `docs/AI_TOKENS.md`
- `docs/DELIVERY.md`
- `docs/SOURCES.md`
- `docs/AI_UI_AUDIT.md`
- `docs/AI_TOKEN_INDEPENDENCE.md`
