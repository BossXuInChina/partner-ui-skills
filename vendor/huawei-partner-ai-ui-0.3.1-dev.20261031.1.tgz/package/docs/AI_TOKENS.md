# AI 独立语义 Token（0.3.0 源码预览 · 2026-10-28）

AI UI 是面向多个业务团队的独立设计规范。字体家族由宿主提供，组件包不含字库；原始 HarmonyOS Sans／SC 与许可仅供预览可选加载，见 [字体接入](FONTS.md)；现有字阶和几何参数未改。除字体家族显式继承宿主外，公共组件的视觉默认参数在本包内闭合：`--partner-ai-*` 与 `--partner-host-*` 不引用 `--wb-*`。历史选值来源与运行时依赖分开记录，不要求接收方提供 Workbench 映射。`src/workbench-tokens.css` 仅由预览／Demo 入口加载，已从公共 `src/index.ts` 移除。

协议表格表头使用既有 `--partner-ai-heading-weight`（默认 500 / Medium）；单元格与操作文字沿用 `--partner-ai-body-weight`（默认 400）。表头字号及行高仍为正文档 14px / 22px，不新增表头专用 Token。`AgreementTable` 的单元格左右内边距复用 `spacing-sm`（8px），固定行高40px，列与滚动由组件自身负责；`table-header-padding` / `table-cell-padding` 仍供普通 Markdown 表格消费，不用于覆盖业务表格。

Sender 占位文字使用独立 `composer-placeholder-color`，默认引用一级文本色的40%不透明度；浅色为 `rgb(25 25 25 / 40%)`。通用 `placeholder` 仍用于历史搜索，`feedback-placeholder` 用于反馈输入，其浅色默认均为 `#AEAEAE`；三者用途和覆盖入口分开。总览中按对应场景名称查看，Sender不再在组件内绕过AI Token单独计算颜色。

2026-10-28 Sender 设计修订：渐变内描边为 1.5px，默认透明度 0.2、编辑聚焦时 0.6；聚焦恢复六色弥散光，模糊 5px、透明度 0.25（原 0.5 的一半）。普通黑色投影仍为 none。摘要卡描边宽度独立为 1px；覆盖 Sender 描边宽度不再联动摘要卡。

2026-10-28 输入建议滚动修订：Pills 默认隐藏滚动条及原滚动槽占位补偿，仍保留32px行高、阴影留白和距Sender的16px间距。原滚动条尺寸/颜色Token不删除，内部恢复显示时继续消费。滚轮方向转换属于交互逻辑，不新增视觉Token。

本轮保持当前已确认视觉数值与交互，未执行 Shadow DOM／iframe 改造；没有打包、提交、推送或合并。当前交接总览：`http://127.0.0.1:4178/overview.html?page=tokens`。

## 2026-10-27 · 基础与组件语义两层收敛

本批首次新增的76项参数精简为44项：12项新增基础参数、32项必要组件语义参数，其余直接复用既有基础参数。现有默认视觉值保持；反馈卡与 Toast 的固定亮色外观继续在深色、aurora 宿主中保留。本批以外的历史组件参数未作全量重命名。

| 层级 | 职责与当前使用 |
| --- | --- |
| 基础 Token | `color-*` 固定色板、`body-*` / `caption-*` / `large-body-*` 字阶、`spacing-*` 间距、`radius-*` 圆角、描边/焦点、控件高度及滚动条轨道/安全边距 |
| 组件语义 Token | 独立宽高、固定表面、选中/禁用状态、光学对齐、阴影和动效；默认可引用基础色板，组件按角色覆盖 |

新增基础项为 `color-white`、`color-neutral-900/500/400/300/200`、`color-brand-700`、`color-green-600`、`radius-lg/xl`、`large-body-size/line`。中性色板不会随宿主主题自动切换；主题语义色仍由原有的 text、border 等参数负责。

- 反馈输入和提交按钮都属于正文档，直接使用 body 字阶；原因和计数使用 caption 字号。计数行高12px是特殊布局，仍独立保留。
- 反馈输入高度和按钮宽度虽然同为88px，继续分别保留 `feedback-input-height` 和 `feedback-button-width`。占位色、禁用色、提交背景、选中态、卡片阴影也保留各自语义。
- 表格与反馈输入复用滚动条基础尺寸；表格滑块高度按同一轨道减去上下安全边距计算，默认仍为6px、悬停10px。表格文字1px微调与1px描边没有合并。
- Toast 保留独立最小高度46px、视口留白、表面、阴影、图标和状态色；普通字阶、间距和圆角使用基础层。`toast-top`、`toast-padding`及动效入口保持。独立使用时，基础层与 Toast 默认一起声明到 `.ai-toast`，浮层继续传递来源参数和字体。

组件中已删除的44个细分参数不保留同义别名。下表为迁移关系，名称省略 `--partner-ai-`；多个基础参数组合用于保留原始几何。

| 原组件参数 | 当前基础参数或计算 |
| --- | --- |
| `feedback-gap` | `spacing-lg` |
| `feedback-padding` | `spacing-lg` |
| `feedback-radius` | `radius-xl` |
| `feedback-weight` | `body-weight` |
| `feedback-title-size` | `large-body-size` |
| `feedback-title-line` | `large-body-line` |
| `feedback-reasons-gap` | `spacing-sm` |
| `feedback-reason-radius` | `radius-sm` |
| `feedback-reason-size` | `caption-size` |
| `feedback-reason-line` | `caption-line` |
| `feedback-border-width` | `border-width` |
| `feedback-input-radius` | `radius-sm` |
| `feedback-input-inline-inset` | `spacing-md` |
| `feedback-input-size` | `body-size` |
| `feedback-input-line` | `body-line` |
| `feedback-letter-spacing` | `body-letter-spacing` |
| `feedback-count-color` | `color-neutral-500` |
| `feedback-count-size` | `caption-size` |
| `feedback-button-height` | `control-size` |
| `feedback-button-radius` | `radius-sm` |
| `feedback-submit-radius` | `radius-md` |
| `feedback-submit-text` | `color-white` |
| `feedback-focus-width` | `focus-width` |
| `feedback-focus-offset` | `focus-control-offset` |
| `feedback-scrollbar-size` | `scrollbar-small-size` |
| `feedback-scrollbar-safe` | `scrollbar-small-safe` |
| `feedback-scrollbar-safe-hover` | `scrollbar-small-safe-hover` |
| `feedback-scrollbar-radius` | `scrollbar-radius` |
| `feedback-scrollbar-color` | `color-neutral-200` |
| `feedback-scrollbar-hover-color` | `color-neutral-400` |
| `toast-gap` | `spacing-sm` |
| `toast-bottom-inset` | `spacing-lg` |
| `toast-radius` | `radius-lg` |
| `toast-font-size` | `body-size` |
| `toast-font-weight` | `body-weight` |
| `toast-line-height` | `body-line` |
| `toast-letter-spacing` | `body-letter-spacing` |
| `toast-error-symbol-color` | `color-white` |
| `table-cell-padding-inline` | `spacing-sm` |
| `table-scrollbar-track-size` | `scrollbar-size` |
| `table-scrollbar-thumb-color` | `color-neutral-200` |
| `feedback-button-padding` | `var(spacing-xs) var(spacing-md)` |
| `table-scrollbar-thumb-size` | `calc(var(scrollbar-size) - var(scrollbar-safe) * 2)` |
| `table-scrollbar-thumb-hover-size` | `calc(var(scrollbar-size) - var(scrollbar-safe-hover) * 2)` |

SVG路径/坐标、0/100%结构值和实测滚动槽宽度保留为本地数据，不按数值相同并入视觉参数。

## 操作图标颜色语义

图标资源和图标颜色分别配置：资源沿用 `AiIconProvider`／面板 `icons`，颜色覆盖组件自身 `.partner-ai` 根上的下列 token。普通单色资源使用 `currentColor`，不把文字 token 或 Workbench token 直接写进替换 SVG。既有 `icon-primary/secondary` 保留原值，新增14个颜色别名／状态入口，不改变当前默认视觉。

| Token（省略 `--partner-ai-`） | 浅色／深色默认 | 消费范围 |
| --- | --- | --- |
| `icon-primary` / `icon-secondary`（复用） | `#191919/#777777`；深色 `#DFDFDF/#AEAEAE` | 历史清空 hover、历史普通操作 |
| `icon-default` | `text` → `#191919`／`#FFFFFF` | 顶部按钮、消息操作、追问、模式图标 |
| `icon-hover` / `icon-active` / `icon-disabled` | 均引用 `icon-default` | 对应悬停、按下／已按下、禁用墨色 |
| `icon-muted` | `muted` → `#777777`／`#C9C9C9` | Sender 语音、图片 |
| `icon-muted-hover` / `icon-muted-active` / `icon-muted-disabled` | 均引用 `icon-muted` | Sender 次要图标对应状态 |
| `icon-inverse` | 两主题均固定白色 | 固定反白语义，不引用深色为黑色的 `on-accent` |
| `send-icon-color`（复用） | 引用 `icon-inverse`，默认保持白色 | 发送／停止所有状态；可独立覆盖 |
| `icon-placeholder` / `icon-link` / `icon-accent` | 分别引用 `placeholder` / `link` / `accent` | 搜索占位、原生链接图标映射、历史置顶 |
| `mode-disabled-icon-color` | `disabled-text` → `#C9C9C9`／`#939393` | 模式菜单禁用勾选；不改选项文字 |
| `history-selected-icon-color` | `history-selected-text` → `#C76207` | 历史选中行置顶／更多；优先于置顶强调色 |

`icon-default/muted` 不直接替换成 `icon-primary/secondary`：二者深色取值不同。禁用保持原容器透明度（ActionButton 0.4、Sender 次要／模式触发／历史0.5、发送既有 `send-disabled-opacity`），不叠加第二层 SVG opacity，也不默认改成灰色。模式菜单已有“禁用墨色”单独保留。焦点沿用当前墨色和既有轮廓，不新增焦点色。

AI 消费层将其映射到 TinyRobot0.5.1公开的 `--tr-icon-color-default/hover/active/disabled/link`。ActionButton仍直接读取文字变量，因此在公共 icon 槽的 `data-ai-icon` SVG上补颜色，文字、尺寸和按钮行为不变；模式body浮层复制AI参数后重新映射。历史继续复用primary/secondary与既有清空悬停、置顶、选中行优先级。状态适配集中在 `src/ui/foundation/aiIcons.css`，上游升级时复核ActionButton是否已支持原生图标变量，以及History选中行`.selected`类。

范围只含公共 AI 顶部／消息／Sender／模式／历史操作与追问箭头，未扩展公共业务卡片。`original`多色路径、智慧渐变mask、品牌／头像图片和发送白色边界继续按[图标接入合同](ICONS.md)处理；不批量重写SVG路径，也不改TinyRobot源码。

## REQ-023 业务跳转卡片（工作区增量）

2026-10-26按[Pixso5703:63](https://pixso.cn/app/design/ajJNlOy184lAXZfN9Z1yNg?item-id=5703:63)更新：默认白底，1px描边`#C9C9C9`；hover增加单层`rgb(25 25 25 / 5%)`填充，描边变为`#191919`。`navigation-bg`映射到`panel-bg`，`navigation-border`映射到`border`，`navigation-hover-border`映射到一级`text`，主题覆盖仍由包内token负责。

`--partner-ai-navigation-padding-inline/block` 保留 16/12px（历史选值 Foundation component-lg/md），`navigation-gap`独立声明12px，`navigation-icon-size`为16px。REQ-023 v0.4按用户指定将`navigation-radius`映射到既有回复卡片`summary-radius`（12px）；不修改工作区智慧卡片独立的`smart-card-radius`（8px）。标题沿用既有message-h3 14/22与heading-weight500；v0.5正文沿用body及一级text，折行增高，16px箭头相对整个内容居中且不压缩。原生焦点使用既有focus色。

hover填充与内描边分层绘制，不占内容尺寸、不叠加第二层灰底、不使用阴影。复用现有control-motion 160ms/ease-out，reduced-motion关闭过渡。箭头使用本地`业务卡-下钻箭头.svg`，保留24px原生画板。

组件 `BusinessNavigationCard` 只发宿主意图；`business-navigation` renderer复用 `workspace:navigate` / `workspaceNavigate`，目标解析不属于token或卡片。接入合同见[HOST_LAYOUT](HOST_LAYOUT.md)，不依赖未交付的协作需求目录。

## 渐变角色独立调参（2026-10-20）

2026-10-29 更新：带描边和无描边智慧卡各自改为柔和蓝、暖黄、粉三层渐变，无描边款颜色从顶部向下淡至白色；带描边款使用 Pixso 提供的 1px 角向渐变（色点各 40%）。Pixso 底色 SVG 未提供，两款底色均以截图近似，用户已确认视觉效果无问题；现行值以 CSS 为准，角向描边暂不支持渐变调试器的逐色点编辑。

发送按钮 `send-bg`、回复摘要 `summary-bg`、带描边智慧卡 `smart-card-bg`、无描边智慧卡 `smart-embedded-bg` 各自持有独立背景声明。摘要为四层圆形径向渐变，发送按钮为五层圆形径向渐变；两款智慧卡为各自独立的三层椭圆径向渐变，圆心与半径使用百分比，随卡片尺寸变化。摘要保留固定 Y(px) 和超范围坐标，发送按钮保留负中心、负 stop 与超过 100% 的 stop；准确参数以 CSS 为准。

调参初始值、恢复默认和复制值读取正式声明，不裁剪或归一化。摘要、两款智慧卡和标签的背景层透明度均为 100%；只作用于背景伪元素，不改变文字、图标或描边透明度。发送按钮保留正常、禁用与停止状态及动效。

`smart-icon-gradient` 独立使用 114deg 三色线性渐变，并被工作区及回复摘要默认智慧图标使用。`smart-gradient` 保留旧线性色板；标签背景使用独立五层径向渐变，背景透明度为 100%，不随智慧图标变化。四个背景色点随标签宽度横向延展、纵向半径保持不变；左上紫粉色点从约 133px 起扩展，其余色点从 200px 起扩展，以减少长标签中的大面积白区。首层白色圆形高光自动对齐全部高亮数据片段整体包围盒中心；无高亮时使用正式默认中心。调参弹窗可编辑纯文本片段并切换普通、高亮、加粗类型；临时文案不进入正式内容或复制 CSS，复制值保留首层当前实际中心与自适应表达式。标题 `smart-title-gradient` 使用独立 135deg 线性渐变，色点位置为 `-43.34%`、`22.87%`、`44.01%` 和 `100%`；负落点与小数精度均由正式 Token 保留。带描边智慧卡使用独立角向渐变描边，Sender 与回复摘要的径向描边不受影响。

总览分别提供角色入口，调试结果只写入当前弹窗沙箱；关闭、重开及切换角色恢复当前规范值。复制 CSS 包含该背景及其背景层透明度；手动调参不回写产品默认声明。沙箱预览居中并提供 25%–400% 查看倍率及恢复 100%；只缩放观察表面，组件布局、容器查询、真实尺寸和复制 CSS 不随倍率变化。

## REQ-020 智慧卡片（工作区增量）

`AiSummaryCard`在`.partner-ai`作用域内消费以下语义token。背景和描边使用两个独立装饰层，正文与logo保持不透明；没有输入focus态或外发光。

| token（省略`--partner-ai-`） | 默认值 / 关系 |
| --- | --- |
| summary-bg / summary-bg-opacity | 独立四层圆形径向渐变 / 1 |
| summary-stroke-image / summary-stroke-width | 引用 composer-stroke-image / 独立 1px |
| summary-stroke-opacity | 独立静态0.2，不引用composer focus参数 |
| summary-padding / summary-gap | AI 独立12px / AI gap-sm（4px） |
| summary-logo-size / summary-radius | AI icon-size（24px）/ 12px首版默认 |
| summary-block-gap | message-business-gap（20px） |
| table-radius | AI 独立8px，仅table-clip内层裁切；外层table-card不裁阴影 |

正文复用body-size/body-line/body-weight/text（14px/22px/400/一级文本色）。卡片填满当前回复内容区，不增加气泡外壳或阴影。logo默认使用本地 `smart.mark` 面性SVG（`workbench-smartFilled.svg`，来源见图标清单），以useId隔离的alpha mask使用独立 `smart-icon-gradient` 线性渐变；容器24px、图形20px（SVG源画布24×24），图形opacity1。摘要背景是独立四层径向渐变，背景层opacity1，色点本身保留各自透明度。可用组件的`logo`属性替换为图片URL或Vue组件并绕过默认mask；技术接口不代表产品日常换图权限，品牌变更须设计侧确认。2026-10-26已移除Demo注入的WorkbenchTag“本地示例”及表格状态Tag；摘要不再附加演示标签，协议表状态默认显示普通文本。产品卡片仍保留原有tags/status内容插槽，未引入demo/vendor依赖。

公共默认层为 `src/ui/foundation/aiTokens.css`、业务智慧呈现的 `src/business/workspaceIntelligence.css` 和宿主范围的 `src/host/`，均随产品样式入口交付。颜色、字体、通用间距、尺寸、圆角、描边、渐变、阴影、动效均有包内声明；AI 参数保留现有需求与源码依据。阴影分别为 agent 16px、Sender 聚焦六色弥散光、欢迎卡 0/4/50/-10/5%，各自独立。REQ-001 v0.5用户底色改为orange-5（Foundation正式键`orange-05`，color-scale.md:61，#FEF5E8）：AI 用户气泡独立声明 `rgb(254 245 232 / 100%)`，不再引用 Workbench palette 或会随 Aurora 改色的告警别名；Workbench/Aurora用户气泡均保持准确orange-05。无阴影、圆角、上下13px/左右16px与单行48px不变。

覆盖作用于**组件自身的.partner-ai根节点**，例如给AgreementAssistantPanel传style，或使用自己的`.product-host .partner-ai`规则。不要只在外层祖先声明后期待覆盖子根默认声明。公开--partner-chat-toolbar-height/footer-height/handle-height仍优先于AI默认尺寸，保持既有宿主协议。

```vue
<AgreementAssistantPanel :adapter="adapter"
  style="--partner-ai-accent:#0067b8; --partner-ai-user-bubble-bg:#eef6ff" />
```

REQ-011：面板实际宽度<480px默认安全边距16px，≥480px默认20px；沿用420/480外宽两档，侧栏／悬浮均由具名`partner-ai-panel`尺寸容器判定，不使用浏览器宽度。`--partner-ai-safe-inset`仍可在.partner-ai根显式覆写，未覆写时由TrLayout body解析`--partner-ai-layout-safe-inset`；compact/wide默认token分别16/20px，root的safe-inset默认initial表示启用自适应。header/main/footer、欢迎区和Pills消费同一解析结果。REQ-003 v1.9最新欢迎卡规则覆盖原两档40px外边距：卡组填充实际安全内容区且最大400px，480px面板卡宽400px居中（左右40px），420px面板卡宽388px（左右16px），含悬浮420；Pills首项左侧跟随安全边距，横向滚动视口右侧仍延伸到面板边缘。发送框内部H16/V12及消息自身padding独立保持。

面板safe-inset与message-padding独立；不会把左右安全留白加到外宽以外。footer高度由composer高、免责声明高、gap、上下padding推导；改相关几何token时保持关联关系，或显式使用既有宿主高度覆盖。TrLayout的官方背景变量、Box的官方padding/color/radius/shadow变量、Sender的官方radius/padding/shadow变量映射AI层；内部.tr-*选择器只负责必要布局/滚动适配，见DELIVERY.md升级说明。

欢迎122起点、32px标题/40px候选行高、卡82、头像48、Sender132/16圆角、user上下13、36px回复操作区为AI专属；其它映射值从下表可查。欢迎icon/文字gap12、fallback头像圆角12、toggle横padding0（REQ-003 v1.3已定稿）、模式最大160/弹层最小180是有注释的保守候选，产品可覆写。

剩余常量：0/100%、flex/grid/居中计算、1px边框和分隔线、2px焦点描边与3px轮廓距离、可访问隐藏1px裁剪、portal安全8px和z-index21000；表格最小列宽为原型内容防折行约束。1920/420/480属于demo宿主响应式参考，Studio/demo注册变量不进入本接口。业务 Demo 的 Workbench 资产及旧原型外壳不属于本轮全量语义化范围。公共表格、字段、弹窗、历史记录和业务呈现中明确遗漏的关键参数已补语义 Token；基础布局、SVG/mask 几何、算法容差仍保留。

工作区REQ-005新增独立建议token：`suggestion-height=32px`、`suggestion-font-size/line-height`映射Body S（12px/20px）、`suggestion-radius=8px`、`suggestion-padding-inline=12px`、`suggestion-gap=8px`、`suggestion-composer-gap=16px`、`suggestion-shadow=0 4px 16px 0 rgb(0 0 0 / 12%)`、`suggestion-shadow-space=16px`、`suggestion-scrollbar-size=8px`、`prompt-arrow-size=10px`、`prompt-arrow-shift=4px`，均带`--partner-ai-`前缀。只作用于输入建议/消息追问，不覆盖Welcome字体或卡片高度。有建议时在宿主基础footer高度上附加建议行及间距48px，见DELIVERY.md；未重新打包既有交付物。

REQ-005 v0.3补充：`--partner-ai-message-prompts-gap`独立声明 `16px`，只控制消息追问项之间的纵向边缘间距。Pills项目间距及追问文字/箭头gap继续8px；欢迎卡片不引用该token。

Pills 集合菜单按最长选项文本加现有选项／面板内边距自适应宽度，`--partner-ai-suggestion-popover-max-width:300px` 为统一上限，可在 `.partner-ai` 根覆写。窄宿主继续限制可用宽度；超过上限的选项单行省略，仅截断项通过既有 Tooltip 在 hover／键盘 focus 时显示全文。菜单固定向上，空间受限时内部滚动，不翻转向下；总览局部示例预留420px高度。标题区与演示待开放项已移除，选择问题后直接发送，并清空输入草稿。

2026-10-29：侧栏与悬浮态共用白色基础底色，依据 Pixso 截图近似上方淡蓝、下方淡暖色光晕；原设计中的椭圆 SVG 未提供，非原始参数还原，用户已确认视觉效果无问题。沿用 420×784px 参考画布和圆形光晕的宽高缩放规则，当前参数以 `aiTokens.css` 为准。

ChatPanel以`container-type:size`提供实际面板宽高，完整TrLayout body通过公开`--tr-layout-bg`绘制唯一背景，其后代位置的cqw/cqh对应面板尺寸，而不是浏览器viewport。header/main/footer透明，外层只保留底色；不会在每个子区重复绘制。既有宿主尺寸协议不变，无新增观察器/监听；气泡、欢迎卡、Sender及12px内容mask保持原实现。完整参考原值与公式见对应需求正文；未重新打包既有交付物。

## 作用域、来源与宿主风险

在组件自身 `.partner-ai` 根覆盖语义 Token；父级同名变量不能自动越过子根默认声明。可选 `AssistantHostLayout` 的外壳参数使用其根上的 `--partner-host-*`。Tooltip 根也拥有默认值；模式菜单、Tooltip 和 UiDialog 仅复制解析后的 AI 参数到浮层，不复制 Workbench 变量。

把手动效保留现有效果：公共产品默认 `160ms`，业务 Demo 显式覆写 `150ms`，两者均使用 `ease-out`。公共宿主外壳保持原独立消费的透明背景；业务 Demo 显式保留白色外壳。显式 `data-wb-theme="dark"` 兼容选择器仍在，但其值也由 AI 包自行声明，不读取 Workbench Token。Aurora 既有别名与业务配色保持。

Token 前缀与 `.partner-ai` 范围不是任意宿主 CSS 的隔离边界。宿主 reset、元素或同名类规则、较高优先级／`!important`、字体及 TinyRobot 全局样式、body 浮层规则、原生 dialog/popover 和层叠上下文仍可能影响呈现。此次验证只证明不加载／改写 `--wb-*` 不再影响所测 AI 样式，不能据此承诺抵抗任意 CSS。Shadow DOM、iframe、跨文档浮层不在本次整改中。

历史来源详见 [SOURCES.md](SOURCES.md)；原需求参数、选定 Foundation 颜色、TinyRobot 0.5.1 实测值和 Workbench 小范围移植都保留来源，不把本轮实现标成新视觉批准或公司正式资产。总览不再把 Workbench 库存列为 AI 的“继承基础 Token”。

## 默认声明与包内最终值

以下从当前源码默认声明生成，第一条声明为默认值；主题／状态覆写由真实样例读取。长复合表达式保留在链接源码与总览中；`initial`、`calc`、容器单位不伪造为固定像素。包内语义间引用会递归展开，表中来源表示默认参数所属文件。

| Token（省略 `--partner-ai-`；宿主保留全名） | 默认声明 | 默认最终值／规则 | 来源 |
| --- | --- | --- | --- |
| `color-white` | `#FFFFFF` | `#FFFFFF` | [aiTokens.css:12](../src/ui/foundation/aiTokens.css) |
| `color-neutral-900` | `#191919` | `#191919` | [aiTokens.css:13](../src/ui/foundation/aiTokens.css) |
| `color-neutral-500` | `#777777` | `#777777` | [aiTokens.css:14](../src/ui/foundation/aiTokens.css) |
| `color-neutral-400` | `#AEAEAE` | `#AEAEAE` | [aiTokens.css:15](../src/ui/foundation/aiTokens.css) |
| `color-neutral-300` | `#C9C9C9` | `#C9C9C9` | [aiTokens.css:16](../src/ui/foundation/aiTokens.css) |
| `color-neutral-200` | `#DFDFDF` | `#DFDFDF` | [aiTokens.css:17](../src/ui/foundation/aiTokens.css) |
| `color-brand-700` | `#C7000B` | `#C7000B` | [aiTokens.css:18](../src/ui/foundation/aiTokens.css) |
| `color-green-600` | `#09AA71` | `#09AA71` | [aiTokens.css:19](../src/ui/foundation/aiTokens.css) |
| `radius-lg` | `8px` | `8px` | [aiTokens.css:20](../src/ui/foundation/aiTokens.css) |
| `radius-xl` | `16px` | `16px` | [aiTokens.css:21](../src/ui/foundation/aiTokens.css) |
| `large-body-size` | `16px` | `16px` | [aiTokens.css:22](../src/ui/foundation/aiTokens.css) |
| `large-body-line` | `24px` | `24px` | [aiTokens.css:23](../src/ui/foundation/aiTokens.css) |
| `body-size` | `14px` | `14px` | [aiTokens.css:24](../src/ui/foundation/aiTokens.css) |
| `body-line` | `22px` | `22px` | [aiTokens.css:25](../src/ui/foundation/aiTokens.css) |
| `body-weight` | `400` | `400` | [aiTokens.css:26](../src/ui/foundation/aiTokens.css) |
| `caption-size` | `12px` | `12px` | [aiTokens.css:27](../src/ui/foundation/aiTokens.css) |
| `caption-line` | `20px` | `20px` | [aiTokens.css:28](../src/ui/foundation/aiTokens.css) |
| `body-letter-spacing` | `0em` | `0em` | [aiTokens.css:29](../src/ui/foundation/aiTokens.css) |
| `spacing-xs` | `4px` | `4px` | [aiTokens.css:30](../src/ui/foundation/aiTokens.css) |
| `spacing-sm` | `8px` | `8px` | [aiTokens.css:31](../src/ui/foundation/aiTokens.css) |
| `spacing-md` | `12px` | `12px` | [aiTokens.css:32](../src/ui/foundation/aiTokens.css) |
| `spacing-lg` | `16px` | `16px` | [aiTokens.css:33](../src/ui/foundation/aiTokens.css) |
| `spacing-xl` | `24px` | `24px` | [aiTokens.css:34](../src/ui/foundation/aiTokens.css) |
| `radius-xs` | `2px` | `2px` | [aiTokens.css:35](../src/ui/foundation/aiTokens.css) |
| `radius-sm` | `4px` | `4px` | [aiTokens.css:36](../src/ui/foundation/aiTokens.css) |
| `radius-md` | `6px` | `6px` | [aiTokens.css:37](../src/ui/foundation/aiTokens.css) |
| `border-width` | `1px` | `1px` | [aiTokens.css:38](../src/ui/foundation/aiTokens.css) |
| `focus-width` | `2px` | `2px` | [aiTokens.css:39](../src/ui/foundation/aiTokens.css) |
| `focus-control-offset` | `2px` | `2px` | [aiTokens.css:40](../src/ui/foundation/aiTokens.css) |
| `control-size` | `32px` | `32px` | [aiTokens.css:41](../src/ui/foundation/aiTokens.css) |
| `scrollbar-small-size` | `10px` | `10px` | [aiTokens.css:42](../src/ui/foundation/aiTokens.css) |
| `scrollbar-small-safe` | `3px` | `3px` | [aiTokens.css:43](../src/ui/foundation/aiTokens.css) |
| `scrollbar-small-safe-hover` | `2px` | `2px` | [aiTokens.css:44](../src/ui/foundation/aiTokens.css) |
| `scrollbar-size` | `14px` | `14px` | [aiTokens.css:45](../src/ui/foundation/aiTokens.css) |
| `scrollbar-safe` | `4px` | `4px` | [aiTokens.css:46](../src/ui/foundation/aiTokens.css) |
| `scrollbar-safe-hover` | `2px` | `2px` | [aiTokens.css:47](../src/ui/foundation/aiTokens.css) |
| `scrollbar-radius` | `999px` | `999px` | [aiTokens.css:48](../src/ui/foundation/aiTokens.css) |
| `panel-bg` | `rgb(255 255 255 / 100%)` | `rgb(255 255 255 / 100%)` | [aiTokens.css:54](../src/ui/foundation/aiTokens.css) |
| `sidebar-reference-width` | `420` | `420` | [aiTokens.css:59](../src/ui/foundation/aiTokens.css) |
| `sidebar-reference-height` | `784` | `784` | [aiTokens.css:60](../src/ui/foundation/aiTokens.css) |
| `sidebar-bg` | `#FFFFFF` | `#FFFFFF` | [aiTokens.css:62](../src/ui/foundation/aiTokens.css) |
| `sidebar-radius-unit` | `calc((100cqw / var(--partner-ai-sidebar-reference-width) + 100cqh / var(--partner-ai-sidebar-reference-height)) / 2)` | `calc((100cqw / 420 + 100cqh / 784) / 2)` | [aiTokens.css:63](../src/ui/foundation/aiTokens.css) |
| `sidebar-bg-image` | [复合表达式／规则](../src/ui/foundation/aiTokens.css) | [复合表达式／规则](../src/ui/foundation/aiTokens.css) | [aiTokens.css:65](../src/ui/foundation/aiTokens.css) |
| `page-bg` | `rgb(243 243 243 / 100%)` | `rgb(243 243 243 / 100%)` | [aiTokens.css:65](../src/ui/foundation/aiTokens.css) |
| `text` | `#191919` | `#191919` | [aiTokens.css:66](../src/ui/foundation/aiTokens.css) |
| `muted` | `rgb(119 119 119 / 100%)` | `rgb(119 119 119 / 100%)` | [aiTokens.css:67](../src/ui/foundation/aiTokens.css) |
| `overlay-bg` | `rgb(255 255 255 / 100%)` | `rgb(255 255 255 / 100%)` | [aiTokens.css:68](../src/ui/foundation/aiTokens.css) |
| `tooltip-bg` | `rgb(255 255 255 / 100%)` | `rgb(255 255 255 / 100%)` | [aiTokens.css:70](../src/ui/foundation/aiTokens.css) |
| `tooltip-text` | `rgb(25 25 25 / 100%)` | `rgb(25 25 25 / 100%)` | [aiTokens.css:71](../src/ui/foundation/aiTokens.css) |
| `tooltip-size` | `14px` | `14px` | [aiTokens.css:73](../src/ui/foundation/aiTokens.css) |
| `tooltip-line` | `22px` | `22px` | [aiTokens.css:74](../src/ui/foundation/aiTokens.css) |
| `tooltip-weight` | `400` | `400` | [aiTokens.css:75](../src/ui/foundation/aiTokens.css) |
| `tooltip-letter-spacing` | `0em` | `0em` | [aiTokens.css:76](../src/ui/foundation/aiTokens.css) |
| `tooltip-padding-x` | `8px` | `8px` | [aiTokens.css:77](../src/ui/foundation/aiTokens.css) |
| `tooltip-padding-y` | `4px` | `4px` | [aiTokens.css:78](../src/ui/foundation/aiTokens.css) |
| `tooltip-radius` | `6px` | `6px` | [aiTokens.css:79](../src/ui/foundation/aiTokens.css) |
| `tooltip-shadow` | `0px 8px 24px 0px rgb(0 0 0 / 16%)` | `0px 8px 24px 0px rgb(0 0 0 / 16%)` | [aiTokens.css:80](../src/ui/foundation/aiTokens.css) |
| `tooltip-font-family` | `var(--partner-ai-font-family,inherit)` | `var(--partner-ai-font-family,inherit)` | [aiTokens.css:81](../src/ui/foundation/aiTokens.css) |
| `accent` | `rgb(199 0 11 / 100%)` | `rgb(199 0 11 / 100%)` | [aiTokens.css:81](../src/ui/foundation/aiTokens.css) |
| `accent-subtle` | `rgb(254 231 232 / 100%)` | `rgb(254 231 232 / 100%)` | [aiTokens.css:82](../src/ui/foundation/aiTokens.css) |
| `on-accent` | `rgb(255 255 255 / 100%)` | `rgb(255 255 255 / 100%)` | [aiTokens.css:83](../src/ui/foundation/aiTokens.css) |
| `hover-bg` | `rgb(25 25 25 / 5%)` | `rgb(25 25 25 / 5%)` | [aiTokens.css:84](../src/ui/foundation/aiTokens.css) |
| `border` | `rgb(201 201 201 / 100%)` | `rgb(201 201 201 / 100%)` | [aiTokens.css:85](../src/ui/foundation/aiTokens.css) |
| `border-hover` | `rgb(25 25 25 / 100%)` | `rgb(25 25 25 / 100%)` | [aiTokens.css:86](../src/ui/foundation/aiTokens.css) |
| `divider` | `rgb(223 223 223 / 100%)` | `rgb(223 223 223 / 100%)` | [aiTokens.css:87](../src/ui/foundation/aiTokens.css) |
| `focus` | `rgb(25 25 25 / 100%)` | `rgb(25 25 25 / 100%)` | [aiTokens.css:88](../src/ui/foundation/aiTokens.css) |
| `disabled-text` | `rgb(201 201 201 / 100%)` | `rgb(201 201 201 / 100%)` | [aiTokens.css:89](../src/ui/foundation/aiTokens.css) |
| `font-family` | `inherit` | `inherit` | [aiTokens.css:92](../src/ui/foundation/aiTokens.css) |
| `heading-weight` | `500` | `500` | [aiTokens.css:93](../src/ui/foundation/aiTokens.css) |
| `safe-inset` | `initial` | `initial` | [aiTokens.css:96](../src/ui/foundation/aiTokens.css) |
| `safe-inset-compact` | `16px` | `16px` | [aiTokens.css:97](../src/ui/foundation/aiTokens.css) |
| `safe-inset-wide` | `20px` | `20px` | [aiTokens.css:98](../src/ui/foundation/aiTokens.css) |
| `scroll-fade-size` | `12px` | `12px` | [aiTokens.css:100](../src/ui/foundation/aiTokens.css) |
| `gap-sm` | `4px` | `4px` | [aiTokens.css:101](../src/ui/foundation/aiTokens.css) |
| `gap-md` | `8px` | `8px` | [aiTokens.css:102](../src/ui/foundation/aiTokens.css) |
| `gap-lg` | `12px` | `12px` | [aiTokens.css:103](../src/ui/foundation/aiTokens.css) |
| `icon-size` | `24px` | `24px` | [aiTokens.css:104](../src/ui/foundation/aiTokens.css) |
| `smart-icon-artwork-size` | `20px` | `20px` | [aiTokens.css:105](../src/ui/foundation/aiTokens.css) |
| `small-icon-size` | `16px` | `16px` | [aiTokens.css:106](../src/ui/foundation/aiTokens.css) |
| `mode-icon-size` | `14px` | `14px` | [aiTokens.css:108](../src/ui/foundation/aiTokens.css) |
| `arrow-icon-size` | `12px` | `12px` | [aiTokens.css:109](../src/ui/foundation/aiTokens.css) |
| `control-radius` | `var(--partner-ai-radius-lg)` | `8px` | [aiTokens.css:110](../src/ui/foundation/aiTokens.css) |
| `panel-radius` | `8px` | `8px` | [aiTokens.css:111](../src/ui/foundation/aiTokens.css) |
| `full-radius` | `999px` | `999px` | [aiTokens.css:112](../src/ui/foundation/aiTokens.css) |
| `fullscreen-content-max-width` | `800px` | `800px` | [aiTokens.css:115](../src/ui/foundation/aiTokens.css) |
| `fullscreen-welcome-max-width` | `1040px` | `1040px` | [aiTokens.css:117](../src/ui/foundation/aiTokens.css) |
| `header-height` | `48px` | `48px` | [aiTokens.css:118](../src/ui/foundation/aiTokens.css) |
| `header-avatar-size` | `40px` | `40px` | [aiTokens.css:119](../src/ui/foundation/aiTokens.css) |
| `header-title-size` | `20px` | `20px` | [aiTokens.css:120](../src/ui/foundation/aiTokens.css) |
| `header-title-line` | `28px` | `28px` | [aiTokens.css:121](../src/ui/foundation/aiTokens.css) |
| `handle-area-height` | `24px` | `24px` | [aiTokens.css:122](../src/ui/foundation/aiTokens.css) |
| `handle-width` | `34px` | `34px` | [aiTokens.css:123](../src/ui/foundation/aiTokens.css) |
| `handle-height` | `4px` | `4px` | [aiTokens.css:124](../src/ui/foundation/aiTokens.css) |
| `footer-gap` | `16px` | `16px` | [aiTokens.css:125](../src/ui/foundation/aiTokens.css) |
| `footer-padding-block` | `16px` | `16px` | [aiTokens.css:126](../src/ui/foundation/aiTokens.css) |
| `footer-height` | `calc(var(--partner-ai-composer-height) + var(--partner-ai-disclaimer-height) + var(--partner-ai-footer-gap) + var(--partner-ai-footer-padding-block) * 2)` | `calc(132px + 20px + 16px + 16px * 2)` | [aiTokens.css:127](../src/ui/foundation/aiTokens.css) |
| `disclaimer-height` | `20px` | `20px` | [aiTokens.css:128](../src/ui/foundation/aiTokens.css) |
| `disclaimer-color` | `#AEAEAE` | `#AEAEAE` | [aiTokens.css:129](../src/ui/foundation/aiTokens.css) |
| `user-bubble-bg` | `rgb(254 245 232 / 100%)` | `rgb(254 245 232 / 100%)` | [aiTokens.css:131](../src/ui/foundation/aiTokens.css) |
| `agent-bubble-bg` | `rgb(255 255 255 / 100%)` | `rgb(255 255 255 / 100%)` | [aiTokens.css:131](../src/ui/foundation/aiTokens.css) |
| `agent-core-data-color` | `#09AA71` | `#09AA71` | [aiTokens.css:134](../src/ui/foundation/aiTokens.css) |
| `agent-bubble-shadow` | `0 0 16px 0 rgb(0 0 0 / 8%)` | `0 0 16px 0 rgb(0 0 0 / 8%)` | [aiTokens.css:135](../src/ui/foundation/aiTokens.css) |
| `bubble-radius` | `24px` | `24px` | [aiTokens.css:136](../src/ui/foundation/aiTokens.css) |
| `message-padding` | `16px` | `16px` | [aiTokens.css:137](../src/ui/foundation/aiTokens.css) |
| `message-gap` | `24px` | `24px` | [aiTokens.css:138](../src/ui/foundation/aiTokens.css) |
| `reply-feedback-gap` | `24px` | `24px` | [aiTokens.css:139](../src/ui/foundation/aiTokens.css) |
| `table-row-height` | `40px` | `40px` | [aiTokens.css:140](../src/ui/foundation/aiTokens.css) |
| `table-radius` | `8px` | `8px` | [aiTokens.css:141](../src/ui/foundation/aiTokens.css) |
| `user-padding-block` | `13px` | `13px` | [aiTokens.css:142](../src/ui/foundation/aiTokens.css) |
| `message-business-gap` | `20px` | `20px` | [aiTokens.css:143](../src/ui/foundation/aiTokens.css) |
| `reply-action-size` | `36px` | `36px` | [aiTokens.css:144](../src/ui/foundation/aiTokens.css) |
| `reply-action-inset` | `6px` | `6px` | [aiTokens.css:145](../src/ui/foundation/aiTokens.css) |
| `reply-action-gap` | `12px` | `12px` | [aiTokens.css:146](../src/ui/foundation/aiTokens.css) |
| `message-title-size` | `20px` | `20px` | [aiTokens.css:147](../src/ui/foundation/aiTokens.css) |
| `message-title-line` | `28px` | `28px` | [aiTokens.css:148](../src/ui/foundation/aiTokens.css) |
| `message-h1-size` | `18px` | `18px` | [aiTokens.css:149](../src/ui/foundation/aiTokens.css) |
| `message-h1-line` | `26px` | `26px` | [aiTokens.css:150](../src/ui/foundation/aiTokens.css) |
| `message-h2-size` | `16px` | `16px` | [aiTokens.css:151](../src/ui/foundation/aiTokens.css) |
| `message-h2-line` | `24px` | `24px` | [aiTokens.css:152](../src/ui/foundation/aiTokens.css) |
| `message-h3-size` | `14px` | `14px` | [aiTokens.css:153](../src/ui/foundation/aiTokens.css) |
| `message-h3-line` | `22px` | `22px` | [aiTokens.css:154](../src/ui/foundation/aiTokens.css) |
| `composer-height` | `132px` | `132px` | [aiTokens.css:156](../src/ui/foundation/aiTokens.css) |
| `composer-radius` | `16px` | `16px` | [aiTokens.css:157](../src/ui/foundation/aiTokens.css) |
| `composer-bg` | `rgb(255 255 255 / 100%)` | `rgb(255 255 255 / 100%)` | [aiTokens.css:157](../src/ui/foundation/aiTokens.css) |
| `composer-placeholder-color` | `color-mix(in srgb, var(--partner-ai-text) 40%, transparent)` | `color-mix(in srgb, #191919 40%, transparent)` | [aiTokens.css:159](../src/ui/foundation/aiTokens.css) |
| `composer-shadow` | `none` | `none` | [aiTokens.css:161](../src/ui/foundation/aiTokens.css) |
| `composer-padding-block` | `12px` | `12px` | [aiTokens.css:162](../src/ui/foundation/aiTokens.css) |
| `composer-padding-inline` | `16px` | `16px` | [aiTokens.css:163](../src/ui/foundation/aiTokens.css) |
| `composer-stroke-width` | `1.5px` | `1.5px` | [aiTokens.css:168](../src/ui/foundation/aiTokens.css) |
| `composer-stroke-opacity` | `0.2` | `0.2` | [aiTokens.css:169](../src/ui/foundation/aiTokens.css) |
| `composer-stroke-focus-opacity` | `0.6` | `0.6` | [aiTokens.css:170](../src/ui/foundation/aiTokens.css) |
| `composer-focus-glow-opacity` | `0.25` | `0.25` | [aiTokens.css:173](../src/ui/foundation/aiTokens.css) |
| `composer-focus-glow-blur` | `5px` | `5px` | [aiTokens.css:174](../src/ui/foundation/aiTokens.css) |
| `composer-stroke-left-color` | `#A766D9` | `#A766D9` | [aiTokens.css:175](../src/ui/foundation/aiTokens.css) |
| `composer-stroke-right-color` | `#FF9CB2` | `#FF9CB2` | [aiTokens.css:176](../src/ui/foundation/aiTokens.css) |
| `composer-stroke-top-left-color` | `#ED7B29` | `#ED7B29` | [aiTokens.css:177](../src/ui/foundation/aiTokens.css) |
| `composer-stroke-top-right-color` | `#FFDB8C` | `#FFDB8C` | [aiTokens.css:178](../src/ui/foundation/aiTokens.css) |
| `composer-stroke-bottom-left-color` | `#EC7DE8` | `#EC7DE8` | [aiTokens.css:179](../src/ui/foundation/aiTokens.css) |
| `composer-stroke-bottom-right-color` | `#8084EF` | `#8084EF` | [aiTokens.css:180](../src/ui/foundation/aiTokens.css) |
| `composer-stroke-left-position` | `0% 50%` | `0% 50%` | [aiTokens.css:181](../src/ui/foundation/aiTokens.css) |
| `composer-stroke-right-position` | `100% 50%` | `100% 50%` | [aiTokens.css:182](../src/ui/foundation/aiTokens.css) |
| `composer-stroke-top-left-position` | `25% 0%` | `25% 0%` | [aiTokens.css:183](../src/ui/foundation/aiTokens.css) |
| `composer-stroke-top-right-position` | `75% 0%` | `75% 0%` | [aiTokens.css:184](../src/ui/foundation/aiTokens.css) |
| `composer-stroke-bottom-left-position` | `25% 100%` | `25% 100%` | [aiTokens.css:185](../src/ui/foundation/aiTokens.css) |
| `composer-stroke-bottom-right-position` | `75% 100%` | `75% 100%` | [aiTokens.css:186](../src/ui/foundation/aiTokens.css) |
| `composer-stroke-corner-extent` | `38% 70%` | `38% 70%` | [aiTokens.css:187](../src/ui/foundation/aiTokens.css) |
| `composer-stroke-side-extent` | `56% 110%` | `56% 110%` | [aiTokens.css:188](../src/ui/foundation/aiTokens.css) |
| `composer-stroke-image` | [复合表达式／规则](../src/ui/foundation/aiTokens.css) | [复合表达式／规则](../src/ui/foundation/aiTokens.css) | [aiTokens.css:189](../src/ui/foundation/aiTokens.css) |
| `mode-radius` | `8px` | `8px` | [aiTokens.css:191](../src/ui/foundation/aiTokens.css) |
| `mode-panel-radius` | `6px` | `6px` | [aiTokens.css:192](../src/ui/foundation/aiTokens.css) |
| `menu-option-radius` | `4px` | `4px` | [aiTokens.css:193](../src/ui/foundation/aiTokens.css) |
| `menu-panel-padding` | `4px` | `4px` | [aiTokens.css:194](../src/ui/foundation/aiTokens.css) |
| `mode-control-gap` | `16px` | `16px` | [aiTokens.css:195](../src/ui/foundation/aiTokens.css) |
| `mode-panel-shadow` | `0px 1px 6px 0px rgb(0 0 0 / 8%)` | `0px 1px 6px 0px rgb(0 0 0 / 8%)` | [aiTokens.css:196](../src/ui/foundation/aiTokens.css) |
| `suggestion-height` | `32px` | `32px` | [aiTokens.css:198](../src/ui/foundation/aiTokens.css) |
| `suggestion-font-size` | `12px` | `12px` | [aiTokens.css:199](../src/ui/foundation/aiTokens.css) |
| `suggestion-line-height` | `20px` | `20px` | [aiTokens.css:200](../src/ui/foundation/aiTokens.css) |
| `suggestion-radius` | `8px` | `8px` | [aiTokens.css:201](../src/ui/foundation/aiTokens.css) |
| `suggestion-padding-inline` | `12px` | `12px` | [aiTokens.css:202](../src/ui/foundation/aiTokens.css) |
| `suggestion-gap` | `8px` | `8px` | [aiTokens.css:203](../src/ui/foundation/aiTokens.css) |
| `suggestion-composer-gap` | `16px` | `16px` | [aiTokens.css:204](../src/ui/foundation/aiTokens.css) |
| `suggestion-shadow` | `0 4px 16px 0 rgb(0 0 0 / 12%)` | `0 4px 16px 0 rgb(0 0 0 / 12%)` | [aiTokens.css:205](../src/ui/foundation/aiTokens.css) |
| `suggestion-shadow-space` | `16px` | `16px` | [aiTokens.css:206](../src/ui/foundation/aiTokens.css) |
| `suggestion-scrollbar-size` | `8px` | `8px` | [aiTokens.css:207](../src/ui/foundation/aiTokens.css) |
| `suggestion-popover-max-width` | `300px` | `300px` | [aiTokens.css:209](../src/ui/foundation/aiTokens.css) |
| `prompt-arrow-size` | `10px` | `10px` | [aiTokens.css:210](../src/ui/foundation/aiTokens.css) |
| `prompt-arrow-shift` | `4px` | `4px` | [aiTokens.css:211](../src/ui/foundation/aiTokens.css) |
| `message-prompts-gap` | `8px` | `8px` | [aiTokens.css:213](../src/ui/foundation/aiTokens.css) |
| `toggle-padding-inline` | `0px` | `0px` | [aiTokens.css:214](../src/ui/foundation/aiTokens.css) |
| `switch-label-color` | `var(--partner-ai-muted)` | `rgb(119 119 119 / 100%)` | [aiTokens.css:221](../src/ui/foundation/aiTokens.css) |
| `switch-label-active-color` | `var(--partner-ai-text)` | `#191919` | [aiTokens.css:222](../src/ui/foundation/aiTokens.css) |
| `switch-off-bg` | `rgba(174,174,174,1)` | `rgba(174,174,174,1)` | [aiTokens.css:223](../src/ui/foundation/aiTokens.css) |
| `switch-on-bg` | `linear-gradient(121deg, rgb(145 192 253 / 98.8%) -19.01%, rgb(255 143 171 / 78.05%) 23.89%, rgba(253,181,99,1) 85.04%)` | `linear-gradient(121deg, rgb(145 192 253 / 98.8%) -19.01%, rgb(255 143 171 / 78.05%) 23.89%, rgba(253,181,99,1) 85.04%)` | [aiTokens.css:224](../src/ui/foundation/aiTokens.css) |
| `send-bg` | [复合表达式／规则](../src/ui/foundation/aiTokens.css) | [复合表达式／规则](../src/ui/foundation/aiTokens.css) | [aiTokens.css:228](../src/ui/foundation/aiTokens.css) |
| `smart-icon-gradient` | `linear-gradient(114deg, rgba(145,192,253,0.81) 0%, rgba(255,143,171,0.91) 50%, rgb(251 199 86 / 100%) 68.87%)` | `linear-gradient(114deg, rgba(145,192,253,0.81) 0%, rgba(255,143,171,0.91) 50%, rgb(251 199 86 / 100%) 68.87%)` | [aiTokens.css:230](../src/ui/foundation/aiTokens.css) |
| `send-icon-color` | `var(--partner-ai-icon-inverse)` | `rgb(255 255 255 / 100%)` | [aiTokens.css:231](../src/ui/foundation/aiTokens.css) |
| `send-opacity` | `1` | `1` | [aiTokens.css:232](../src/ui/foundation/aiTokens.css) |
| `send-disabled-opacity` | `0.4` | `0.4` | [aiTokens.css:233](../src/ui/foundation/aiTokens.css) |
| `summary-bg` | [复合表达式／规则](../src/ui/foundation/aiTokens.css) | [复合表达式／规则](../src/ui/foundation/aiTokens.css) | [aiTokens.css:236](../src/ui/foundation/aiTokens.css) |
| `summary-bg-opacity` | `1` | `1` | [aiTokens.css:237](../src/ui/foundation/aiTokens.css) |
| `summary-stroke-image` | `var(--partner-ai-composer-stroke-image)` | [复合表达式／规则](../src/ui/foundation/aiTokens.css) | [aiTokens.css:238](../src/ui/foundation/aiTokens.css) |
| `summary-stroke-width` | `1px` | `1px` | [aiTokens.css:240](../src/ui/foundation/aiTokens.css) |
| `summary-stroke-opacity` | `0.2` | `0.2` | [aiTokens.css:241](../src/ui/foundation/aiTokens.css) |
| `summary-padding` | `12px` | `12px` | [aiTokens.css:242](../src/ui/foundation/aiTokens.css) |
| `summary-gap` | `var(--partner-ai-gap-sm)` | `4px` | [aiTokens.css:243](../src/ui/foundation/aiTokens.css) |
| `summary-logo-size` | `var(--partner-ai-icon-size)` | `24px` | [aiTokens.css:244](../src/ui/foundation/aiTokens.css) |
| `summary-radius` | `12px` | `12px` | [aiTokens.css:245](../src/ui/foundation/aiTokens.css) |
| `summary-block-gap` | `var(--partner-ai-message-business-gap)` | `20px` | [aiTokens.css:246](../src/ui/foundation/aiTokens.css) |
| `navigation-padding-inline` | `16px` | `16px` | [aiTokens.css:248](../src/ui/foundation/aiTokens.css) |
| `navigation-padding-block` | `12px` | `12px` | [aiTokens.css:249](../src/ui/foundation/aiTokens.css) |
| `navigation-gap` | `12px` | `12px` | [aiTokens.css:250](../src/ui/foundation/aiTokens.css) |
| `navigation-icon-size` | `16px` | `16px` | [aiTokens.css:251](../src/ui/foundation/aiTokens.css) |
| `navigation-border-width` | `1px` | `1px` | [aiTokens.css:252](../src/ui/foundation/aiTokens.css) |
| `navigation-border` | `var(--partner-ai-border)` | `rgb(201 201 201 / 100%)` | [aiTokens.css:253](../src/ui/foundation/aiTokens.css) |
| `navigation-hover-border` | `var(--partner-ai-text)` | `#191919` | [aiTokens.css:254](../src/ui/foundation/aiTokens.css) |
| `navigation-radius` | `var(--partner-ai-summary-radius)` | `12px` | [aiTokens.css:257](../src/ui/foundation/aiTokens.css) |
| `control-motion-duration` | `160ms` | `160ms` | [aiTokens.css:261](../src/ui/foundation/aiTokens.css) |
| `control-motion-easing` | `ease-out` | `ease-out` | [aiTokens.css:262](../src/ui/foundation/aiTokens.css) |
| `state-icon-entry-scale` | `0.9` | `0.9` | [aiTokens.css:264](../src/ui/foundation/aiTokens.css) |
| `switch-width` | `28px` | `28px` | [aiTokens.css:265](../src/ui/foundation/aiTokens.css) |
| `switch-height` | `16px` | `16px` | [aiTokens.css:266](../src/ui/foundation/aiTokens.css) |
| `switch-thumb-size` | `12px` | `12px` | [aiTokens.css:267](../src/ui/foundation/aiTokens.css) |
| `mode-max-width` | `160px` | `160px` | [aiTokens.css:268](../src/ui/foundation/aiTokens.css) |
| `mode-panel-min-width` | `0px` | `0px` | [aiTokens.css:269](../src/ui/foundation/aiTokens.css) |
| `welcome-origin` | `122px` | `122px` | [aiTokens.css:271](../src/ui/foundation/aiTokens.css) |
| `welcome-avatar-size` | `48px` | `48px` | [aiTokens.css:272](../src/ui/foundation/aiTokens.css) |
| `welcome-avatar-radius` | `12px` | `12px` | [aiTokens.css:273](../src/ui/foundation/aiTokens.css) |
| `welcome-title-size` | `32px` | `32px` | [aiTokens.css:274](../src/ui/foundation/aiTokens.css) |
| `welcome-title-line` | `40px` | `40px` | [aiTokens.css:275](../src/ui/foundation/aiTokens.css) |
| `welcome-body-size` | `16px` | `16px` | [aiTokens.css:276](../src/ui/foundation/aiTokens.css) |
| `welcome-body-line` | `24px` | `24px` | [aiTokens.css:277](../src/ui/foundation/aiTokens.css) |
| `welcome-entry-gap` | `48px` | `48px` | [aiTokens.css:278](../src/ui/foundation/aiTokens.css) |
| `welcome-card-height` | `82px` | `82px` | [aiTokens.css:279](../src/ui/foundation/aiTokens.css) |
| `welcome-card-radius` | `16px` | `16px` | [aiTokens.css:281](../src/ui/foundation/aiTokens.css) |
| `welcome-card-max-width` | `400px` | `400px` | [aiTokens.css:284](../src/ui/foundation/aiTokens.css) |
| `welcome-card-gap` | `16px` | `16px` | [aiTokens.css:285](../src/ui/foundation/aiTokens.css) |
| `welcome-card-padding-block` | `16px` | `16px` | [aiTokens.css:286](../src/ui/foundation/aiTokens.css) |
| `welcome-card-padding-inline` | `24px` | `24px` | [aiTokens.css:287](../src/ui/foundation/aiTokens.css) |
| `welcome-card-shadow` | `0 4px 50px -10px rgb(0 0 0 / 5%)` | `0 4px 50px -10px rgb(0 0 0 / 5%)` | [aiTokens.css:288](../src/ui/foundation/aiTokens.css) |
| `welcome-card-hover-shadow` | `0 4px 50px -10px rgb(0 0 0 / 10%)` | `0 4px 50px -10px rgb(0 0 0 / 10%)` | [aiTokens.css:289](../src/ui/foundation/aiTokens.css) |
| `welcome-card-title-size` | `16px` | `16px` | [aiTokens.css:290](../src/ui/foundation/aiTokens.css) |
| `welcome-card-title-line` | `24px` | `24px` | [aiTokens.css:291](../src/ui/foundation/aiTokens.css) |
| `scrollbar-thumb` | `rgb(25 25 25 / 20%)` | `rgb(25 25 25 / 20%)` | [aiTokens.css:293](../src/ui/foundation/aiTokens.css) |
| `scrollbar-thumb-dark` | `rgb(243 243 243 / 30%)` | `rgb(243 243 243 / 30%)` | [aiTokens.css:294](../src/ui/foundation/aiTokens.css) |
| `scrollbar-thumb-hover` | `#AEAEAE` | `#AEAEAE` | [aiTokens.css:294](../src/ui/foundation/aiTokens.css) |
| `scrollbar-fill` | `var(--partner-ai-scrollbar-thumb)` | `rgb(25 25 25 / 20%)` | [aiTokens.css:296](../src/ui/foundation/aiTokens.css) |
| `scrollbar-hover` | `var(--partner-ai-scrollbar-thumb-hover)` | `#AEAEAE` | [aiTokens.css:297](../src/ui/foundation/aiTokens.css) |
| `caption-letter-spacing` | `0em` | `0em` | [aiTokens.css:300](../src/ui/foundation/aiTokens.css) |
| `heading-letter-spacing` | `0em` | `0em` | [aiTokens.css:301](../src/ui/foundation/aiTokens.css) |
| `button-font-size` | `12px` | `12px` | [aiTokens.css:302](../src/ui/foundation/aiTokens.css) |
| `button-line-height` | `20px` | `20px` | [aiTokens.css:303](../src/ui/foundation/aiTokens.css) |
| `button-letter-spacing` | `0em` | `0em` | [aiTokens.css:304](../src/ui/foundation/aiTokens.css) |
| `accent-hover` | `#E02128` | `#E02128` | [aiTokens.css:304](../src/ui/foundation/aiTokens.css) |
| `fill` | `rgb(25 25 25 / 5%)` | `rgb(25 25 25 / 5%)` | [aiTokens.css:305](../src/ui/foundation/aiTokens.css) |
| `error` | `#E02128` | `#E02128` | [aiTokens.css:306](../src/ui/foundation/aiTokens.css) |
| `error-bg` | `#FEE7E8` | `#FEE7E8` | [aiTokens.css:307](../src/ui/foundation/aiTokens.css) |
| `alert` | `#F4840C` | `#F4840C` | [aiTokens.css:308](../src/ui/foundation/aiTokens.css) |
| `alert-bg` | `#FEF5E8` | `#FEF5E8` | [aiTokens.css:309](../src/ui/foundation/aiTokens.css) |
| `success` | `#09AA71` | `#09AA71` | [aiTokens.css:310](../src/ui/foundation/aiTokens.css) |
| `link` | `#0067D1` | `#0067D1` | [aiTokens.css:311](../src/ui/foundation/aiTokens.css) |
| `action-text` | `#0067D1` | `#0067D1` | [aiTokens.css:312](../src/ui/foundation/aiTokens.css) |
| `action-text-hover` | `#2E86DE` | `#2E86DE` | [aiTokens.css:313](../src/ui/foundation/aiTokens.css) |
| `icon-primary` | `#191919` | `#191919` | [aiTokens.css:314](../src/ui/foundation/aiTokens.css) |
| `icon-secondary` | `#777777` | `#777777` | [aiTokens.css:315](../src/ui/foundation/aiTokens.css) |
| `icon-default` | `var(--partner-ai-text)` | `#191919` | [aiTokens.css:321](../src/ui/foundation/aiTokens.css) |
| `icon-hover` | `var(--partner-ai-icon-default)` | `#191919` | [aiTokens.css:322](../src/ui/foundation/aiTokens.css) |
| `icon-active` | `var(--partner-ai-icon-default)` | `#191919` | [aiTokens.css:323](../src/ui/foundation/aiTokens.css) |
| `icon-disabled` | `var(--partner-ai-icon-default)` | `#191919` | [aiTokens.css:324](../src/ui/foundation/aiTokens.css) |
| `icon-muted` | `var(--partner-ai-muted)` | `rgb(119 119 119 / 100%)` | [aiTokens.css:325](../src/ui/foundation/aiTokens.css) |
| `icon-muted-hover` | `var(--partner-ai-icon-muted)` | `rgb(119 119 119 / 100%)` | [aiTokens.css:326](../src/ui/foundation/aiTokens.css) |
| `icon-muted-active` | `var(--partner-ai-icon-muted)` | `rgb(119 119 119 / 100%)` | [aiTokens.css:327](../src/ui/foundation/aiTokens.css) |
| `icon-muted-disabled` | `var(--partner-ai-icon-muted)` | `rgb(119 119 119 / 100%)` | [aiTokens.css:328](../src/ui/foundation/aiTokens.css) |
| `icon-inverse` | `rgb(255 255 255 / 100%)` | `rgb(255 255 255 / 100%)` | [aiTokens.css:329](../src/ui/foundation/aiTokens.css) |
| `icon-placeholder` | `var(--partner-ai-placeholder)` | `#AEAEAE` | [aiTokens.css:330](../src/ui/foundation/aiTokens.css) |
| `icon-link` | `var(--partner-ai-link)` | `#0067D1` | [aiTokens.css:331](../src/ui/foundation/aiTokens.css) |
| `icon-accent` | `var(--partner-ai-accent)` | `rgb(199 0 11 / 100%)` | [aiTokens.css:332](../src/ui/foundation/aiTokens.css) |
| `mode-disabled-icon-color` | `var(--partner-ai-disabled-text)` | `rgb(201 201 201 / 100%)` | [aiTokens.css:333](../src/ui/foundation/aiTokens.css) |
| `history-selected-icon-color` | `var(--partner-ai-history-selected-text)` | `#C76207` | [aiTokens.css:334](../src/ui/foundation/aiTokens.css) |
| `placeholder` | `#AEAEAE` | `#AEAEAE` | [aiTokens.css:334](../src/ui/foundation/aiTokens.css) |
| `subtle-bg` | `#FFFFFF` | `#FFFFFF` | [aiTokens.css:335](../src/ui/foundation/aiTokens.css) |
| `overlay-shadow` | `0px 8px 24px 0px rgb(0 0 0 / 16%)` | `0px 8px 24px 0px rgb(0 0 0 / 16%)` | [aiTokens.css:337](../src/ui/foundation/aiTokens.css) |
| `navigation-bg` | `var(--partner-ai-panel-bg)` | `rgb(255 255 255 / 100%)` | [aiTokens.css:338](../src/ui/foundation/aiTokens.css) |
| `navigation-hover-bg` | `var(--partner-ai-hover-bg)` | `rgb(25 25 25 / 5%)` | [aiTokens.css:339](../src/ui/foundation/aiTokens.css) |
| `welcome-padding-block-end` | `24px` | `24px` | [aiTokens.css:340](../src/ui/foundation/aiTokens.css) |
| `welcome-fullscreen-padding-block` | `24px` | `24px` | [aiTokens.css:341](../src/ui/foundation/aiTokens.css) |
| `handle-hit-width` | `64px` | `64px` | [aiTokens.css:342](../src/ui/foundation/aiTokens.css) |
| `handle-active-width` | `40px` | `40px` | [aiTokens.css:343](../src/ui/foundation/aiTokens.css) |
| `handle-active-height` | `8px` | `8px` | [aiTokens.css:344](../src/ui/foundation/aiTokens.css) |
| `handle-motion-duration` | `160ms` | `160ms` | [aiTokens.css:347](../src/ui/foundation/aiTokens.css) |
| `history-width` | `300px` | `300px` | [aiTokens.css:348](../src/ui/foundation/aiTokens.css) |
| `history-max-height` | `520px` | `520px` | [aiTokens.css:349](../src/ui/foundation/aiTokens.css) |
| `history-radius` | `24px` | `24px` | [aiTokens.css:350](../src/ui/foundation/aiTokens.css) |
| `history-padding` | `16px` | `16px` | [aiTokens.css:351](../src/ui/foundation/aiTokens.css) |
| `history-gap` | `8px` | `8px` | [aiTokens.css:352](../src/ui/foundation/aiTokens.css) |
| `history-row-height` | `40px` | `40px` | [aiTokens.css:353](../src/ui/foundation/aiTokens.css) |
| `history-heading-size` | `16px` | `16px` | [aiTokens.css:354](../src/ui/foundation/aiTokens.css) |
| `history-heading-line` | `24px` | `24px` | [aiTokens.css:355](../src/ui/foundation/aiTokens.css) |
| `history-search-icon-size` | `14px` | `14px` | [aiTokens.css:356](../src/ui/foundation/aiTokens.css) |
| `history-motion-duration` | `200ms` | `200ms` | [aiTokens.css:357](../src/ui/foundation/aiTokens.css) |
| `history-motion-easing` | `cubic-bezier(0.2,0,0,1)` | `cubic-bezier(0.2,0,0,1)` | [aiTokens.css:358](../src/ui/foundation/aiTokens.css) |
| `history-motion-offset` | `6px` | `6px` | [aiTokens.css:359](../src/ui/foundation/aiTokens.css) |
| `history-selected-bg` | `rgb(170 104 45 / 10%)` | `rgb(170 104 45 / 10%)` | [aiTokens.css:361](../src/ui/foundation/aiTokens.css) |
| `history-selected-text` | `#C76207` | `#C76207` | [aiTokens.css:362](../src/ui/foundation/aiTokens.css) |
| `history-menu-min-width` | `130px` | `130px` | [aiTokens.css:363](../src/ui/foundation/aiTokens.css) |
| `table-header-bg` | `rgb(25 25 25 / 5%)` | `rgb(25 25 25 / 5%)` | [aiTokens.css:363](../src/ui/foundation/aiTokens.css) |
| `table-row-divider` | `#F3F3F3` | `#F3F3F3` | [aiTokens.css:364](../src/ui/foundation/aiTokens.css) |
| `table-action-active` | `#004EA8` | `#004EA8` | [aiTokens.css:365](../src/ui/foundation/aiTokens.css) |
| `table-header-divider-height` | `16px` | `16px` | [aiTokens.css:367](../src/ui/foundation/aiTokens.css) |
| `table-action-label-offset` | `1px` | `1px` | [aiTokens.css:368](../src/ui/foundation/aiTokens.css) |
| `table-min-width` | `750px` | `750px` | [aiTokens.css:369](../src/ui/foundation/aiTokens.css) |
| `table-header-padding` | `10px 12px` | `10px 12px` | [aiTokens.css:370](../src/ui/foundation/aiTokens.css) |
| `table-cell-padding` | `12px` | `12px` | [aiTokens.css:371](../src/ui/foundation/aiTokens.css) |
| `status-padding` | `2px 8px` | `2px 8px` | [aiTokens.css:372](../src/ui/foundation/aiTokens.css) |
| `button-min-height` | `32px` | `32px` | [aiTokens.css:373](../src/ui/foundation/aiTokens.css) |
| `button-padding` | `5px 12px` | `5px 12px` | [aiTokens.css:374](../src/ui/foundation/aiTokens.css) |
| `button-gap` | `6px` | `6px` | [aiTokens.css:375](../src/ui/foundation/aiTokens.css) |
| `field-height` | `36px` | `36px` | [aiTokens.css:376](../src/ui/foundation/aiTokens.css) |
| `field-padding` | `6px 10px` | `6px 10px` | [aiTokens.css:377](../src/ui/foundation/aiTokens.css) |
| `dialog-width` | `400px` | `400px` | [aiTokens.css:378](../src/ui/foundation/aiTokens.css) |
| `dialog-viewport-gutter` | `32px` | `32px` | [aiTokens.css:379](../src/ui/foundation/aiTokens.css) |
| `dialog-padding` | `24px` | `24px` | [aiTokens.css:380](../src/ui/foundation/aiTokens.css) |
| `dialog-title-size` | `18px` | `18px` | [aiTokens.css:381](../src/ui/foundation/aiTokens.css) |
| `dialog-title-line` | `26px` | `26px` | [aiTokens.css:382](../src/ui/foundation/aiTokens.css) |
| `dialog-shadow` | `0px 16px 48px 0px rgb(0 0 0 / 16%)` | `0px 16px 48px 0px rgb(0 0 0 / 16%)` | [aiTokens.css:383](../src/ui/foundation/aiTokens.css) |
| `dialog-scrim` | `rgb(25 25 25 / 30%)` | `rgb(25 25 25 / 30%)` | [aiTokens.css:383](../src/ui/foundation/aiTokens.css) |
| `dialog-motion-duration` | `200ms` | `200ms` | [aiTokens.css:385](../src/ui/foundation/aiTokens.css) |
| `dialog-motion-easing` | `cubic-bezier(0.2,0,0,1)` | `cubic-bezier(0.2,0,0,1)` | [aiTokens.css:386](../src/ui/foundation/aiTokens.css) |
| `drawer-width` | `440px` | `440px` | [aiTokens.css:387](../src/ui/foundation/aiTokens.css) |
| `drawer-motion-duration` | `200ms` | `200ms` | [aiTokens.css:388](../src/ui/foundation/aiTokens.css) |
| `drawer-motion-easing` | `cubic-bezier(0.2,0,0,1)` | `cubic-bezier(0.2,0,0,1)` | [aiTokens.css:389](../src/ui/foundation/aiTokens.css) |
| `toast-bottom` | `24px` | `24px` | [aiTokens.css:391](../src/ui/foundation/aiTokens.css) |
| `feedback-width` | `448px` | `448px` | [aiTokens.css:394](../src/ui/foundation/aiTokens.css) |
| `feedback-bg` | `var(--partner-ai-color-white)` | `#FFFFFF` | [aiTokens.css:395](../src/ui/foundation/aiTokens.css) |
| `feedback-text` | `var(--partner-ai-color-neutral-900)` | `#191919` | [aiTokens.css:396](../src/ui/foundation/aiTokens.css) |
| `feedback-shadow` | `0 0 16px rgb(0 0 0 / 8%)` | `0 0 16px rgb(0 0 0 / 8%)` | [aiTokens.css:397](../src/ui/foundation/aiTokens.css) |
| `feedback-title-max-width` | `400px` | `400px` | [aiTokens.css:398](../src/ui/foundation/aiTokens.css) |
| `feedback-reason-height` | `28px` | `28px` | [aiTokens.css:399](../src/ui/foundation/aiTokens.css) |
| `feedback-reason-padding` | `3px 11px` | `3px 11px` | [aiTokens.css:400](../src/ui/foundation/aiTokens.css) |
| `feedback-reason-bg` | `rgb(119 119 119 / 5%)` | `rgb(119 119 119 / 5%)` | [aiTokens.css:401](../src/ui/foundation/aiTokens.css) |
| `feedback-selected-text` | `rgb(0 0 0 / 90%)` | `rgb(0 0 0 / 90%)` | [aiTokens.css:402](../src/ui/foundation/aiTokens.css) |
| `feedback-border` | `var(--partner-ai-color-neutral-300)` | `#C9C9C9` | [aiTokens.css:403](../src/ui/foundation/aiTokens.css) |
| `feedback-input-height` | `88px` | `88px` | [aiTokens.css:404](../src/ui/foundation/aiTokens.css) |
| `feedback-input-padding` | `4px 0 2px 12px` | `4px 0 2px 12px` | [aiTokens.css:405](../src/ui/foundation/aiTokens.css) |
| `feedback-placeholder` | `var(--partner-ai-color-neutral-400)` | `#AEAEAE` | [aiTokens.css:406](../src/ui/foundation/aiTokens.css) |
| `feedback-count-line` | `12px` | `12px` | [aiTokens.css:407](../src/ui/foundation/aiTokens.css) |
| `feedback-button-width` | `88px` | `88px` | [aiTokens.css:408](../src/ui/foundation/aiTokens.css) |
| `feedback-submit-bg` | `var(--partner-ai-color-brand-700)` | `#C7000B` | [aiTokens.css:409](../src/ui/foundation/aiTokens.css) |
| `feedback-disabled-bg` | `rgb(25 25 25 / 5%)` | `rgb(25 25 25 / 5%)` | [aiTokens.css:410](../src/ui/foundation/aiTokens.css) |
| `feedback-disabled-color` | `var(--partner-ai-color-neutral-300)` | `#C9C9C9` | [aiTokens.css:411](../src/ui/foundation/aiTokens.css) |
| `spinner-size` | `12px` | `12px` | [aiTokens.css:412](../src/ui/foundation/aiTokens.css) |
| `spinner-duration` | `800ms` | `800ms` | [aiTokens.css:413](../src/ui/foundation/aiTokens.css) |
| `message-scroll-padding-block` | `24px` | `24px` | [aiTokens.css:417](../src/ui/foundation/aiTokens.css) |
| `suggestion-option-min-height` | `40px` | `40px` | [aiTokens.css:418](../src/ui/foundation/aiTokens.css) |
| `text-button-padding` | `var(--partner-ai-gap-sm)` | `4px` | [aiTokens.css:419](../src/ui/foundation/aiTokens.css) |
| `table-title-padding` | `var(--partner-ai-gap-lg) var(--partner-ai-spacing-lg)` | `12px 16px` | [aiTokens.css:420](../src/ui/foundation/aiTokens.css) |
| `drawer-padding` | `var(--partner-ai-dialog-padding)` | `24px` | [aiTokens.css:421](../src/ui/foundation/aiTokens.css) |
| `drawer-compact-padding` | `var(--partner-ai-spacing-lg)` | `16px` | [aiTokens.css:422](../src/ui/foundation/aiTokens.css) |
| `field-radius` | `var(--partner-ai-radius-sm)` | `4px` | [aiTokens.css:423](../src/ui/foundation/aiTokens.css) |
| `dialog-icon-size` | `40px` | `40px` | [aiTokens.css:424](../src/ui/foundation/aiTokens.css) |
| `auxiliary-icon-size` | `18px` | `18px` | [aiTokens.css:425](../src/ui/foundation/aiTokens.css) |
| `disabled-opacity` | `0.5` | `0.5` | [aiTokens.css:426](../src/ui/foundation/aiTokens.css) |
| `focus-offset` | `3px` | `3px` | [aiTokens.css:429](../src/ui/foundation/aiTokens.css) |
| `focus-inset` | `-2px` | `-2px` | [aiTokens.css:430](../src/ui/foundation/aiTokens.css) |
| `focus-near-offset` | `1px` | `1px` | [aiTokens.css:431](../src/ui/foundation/aiTokens.css) |
| `spinner-stroke-width` | `2px` | `2px` | [aiTokens.css:432](../src/ui/foundation/aiTokens.css) |
| `toast-top` | `24px` | `24px` | [aiTokens.css:438](../src/ui/foundation/aiTokens.css) |
| `toast-padding` | `12px 16px` | `12px 16px` | [aiTokens.css:439](../src/ui/foundation/aiTokens.css) |
| `toast-viewport-gutter` | `32px` | `32px` | [aiTokens.css:440](../src/ui/foundation/aiTokens.css) |
| `toast-min-height` | `46px` | `46px` | [aiTokens.css:441](../src/ui/foundation/aiTokens.css) |
| `toast-bg` | `var(--partner-ai-color-white)` | `#FFFFFF` | [aiTokens.css:442](../src/ui/foundation/aiTokens.css) |
| `toast-text` | `var(--partner-ai-color-neutral-900)` | `#191919` | [aiTokens.css:443](../src/ui/foundation/aiTokens.css) |
| `toast-shadow` | `0 8px 24px rgb(0 0 0 / 16.0784%)` | `0 8px 24px rgb(0 0 0 / 16.0784%)` | [aiTokens.css:444](../src/ui/foundation/aiTokens.css) |
| `toast-icon-size` | `14px` | `14px` | [aiTokens.css:445](../src/ui/foundation/aiTokens.css) |
| `toast-success-color` | `var(--partner-ai-color-green-600)` | `#09AA71` | [aiTokens.css:446](../src/ui/foundation/aiTokens.css) |
| `toast-error-fallback-color` | `#F23030` | `#F23030` | [aiTokens.css:447](../src/ui/foundation/aiTokens.css) |
| `toast-z-index` | `2147483647` | `2147483647` | [aiTokens.css:448](../src/ui/foundation/aiTokens.css) |
| `toast-motion-duration` | `200ms` | `200ms` | [aiTokens.css:449](../src/ui/foundation/aiTokens.css) |
| `toast-motion-easing` | `cubic-bezier(0.2,0,0,1)` | `cubic-bezier(0.2,0,0,1)` | [aiTokens.css:450](../src/ui/foundation/aiTokens.css) |
| `toast-entry-scale` | `0.9` | `0.9` | [aiTokens.css:451](../src/ui/foundation/aiTokens.css) |
| `layout-safe-inset` | `var(--partner-ai-safe-inset,var(--partner-ai-safe-inset-compact))` | `var(--partner-ai-safe-inset,16px)` | [aiTokens.css:507](../src/ui/foundation/aiTokens.css) |
| `data-emphasis` | `rgb(199 98 7 / 100%)` | `rgb(199 98 7 / 100%)` | [workspaceIntelligence.css:4](../src/business/workspaceIntelligence.css) |
| `smart-gradient` | `linear-gradient(135deg, rgba(145,192,253,0.81) 0%, rgba(255,143,171,0.91) 50%, rgba(251,174,86,1) 100%)` | `linear-gradient(135deg, rgba(145,192,253,0.81) 0%, rgba(255,143,171,0.91) 50%, rgba(251,174,86,1) 100%)` | [workspaceIntelligence.css:7](../src/business/workspaceIntelligence.css) |
| `smart-tag-bg` | [复合表达式／规则](../src/business/workspaceIntelligence.css) | [复合表达式／规则](../src/business/workspaceIntelligence.css) | [workspaceIntelligence.css:12](../src/business/workspaceIntelligence.css) |
| `smart-title-gradient` | `linear-gradient(135deg, #4F88DE -43.34%, #DF5C8A 22.87%, rgb(255 99 71 / 100%) 44.01%, rgb(245 176 107 / 100%) 100%)` | `linear-gradient(135deg, #4F88DE -43.34%, #DF5C8A 22.87%, rgb(255 99 71 / 100%) 44.01%, rgb(245 176 107 / 100%) 100%)` | [workspaceIntelligence.css:14](../src/business/workspaceIntelligence.css) |
| `smart-icon-size` | `24px` | `24px` | [workspaceIntelligence.css:15](../src/business/workspaceIntelligence.css) |
| `smart-tag-height` | `28px` | `28px` | [workspaceIntelligence.css:16](../src/business/workspaceIntelligence.css) |
| `smart-tag-padding-inline` | `12px` | `12px` | [workspaceIntelligence.css:17](../src/business/workspaceIntelligence.css) |
| `smart-tag-gap` | `4px` | `4px` | [workspaceIntelligence.css:18](../src/business/workspaceIntelligence.css) |
| `smart-tag-bg-opacity` | `1` | `1` | [workspaceIntelligence.css:20](../src/business/workspaceIntelligence.css) |
| `smart-tag-radius` | `4px` | `4px` | [workspaceIntelligence.css:21](../src/business/workspaceIntelligence.css) |
| `smart-tag-stroke` | `rgb(255 255 255 / 60%)` | `rgb(255 255 255 / 60%)` | [workspaceIntelligence.css:22](../src/business/workspaceIntelligence.css) |
| `smart-tag-stroke-width` | `1px` | `1px` | [workspaceIntelligence.css:23](../src/business/workspaceIntelligence.css) |
| `smart-card-padding-inline` | `24px` | `24px` | [workspaceIntelligence.css:24](../src/business/workspaceIntelligence.css) |
| `smart-card-padding-top` | `20px` | `20px` | [workspaceIntelligence.css:25](../src/business/workspaceIntelligence.css) |
| `smart-card-padding-bottom` | `28px` | `28px` | [workspaceIntelligence.css:26](../src/business/workspaceIntelligence.css) |
| `smart-embedded-padding-inline` | `16px` | `16px` | [workspaceIntelligence.css:27](../src/business/workspaceIntelligence.css) |
| `smart-embedded-padding-block` | `12px` | `12px` | [workspaceIntelligence.css:28](../src/business/workspaceIntelligence.css) |
| `smart-card-radius` | `8px` | `8px` | [workspaceIntelligence.css:29](../src/business/workspaceIntelligence.css) |
| `smart-card-bg` | [复合表达式／规则](../src/business/workspaceIntelligence.css) | [复合表达式／规则](../src/business/workspaceIntelligence.css) | [workspaceIntelligence.css:36](../src/business/workspaceIntelligence.css) |
| `smart-embedded-bg` | [复合表达式／规则](../src/business/workspaceIntelligence.css) | [复合表达式／规则](../src/business/workspaceIntelligence.css) | [workspaceIntelligence.css:37](../src/business/workspaceIntelligence.css) |
| `smart-card-base-bg` | `#FFFFFF` | `#FFFFFF` | [workspaceIntelligence.css:38](../src/business/workspaceIntelligence.css) |
| `smart-embedded-bg-opacity` | `1` | `1` | [workspaceIntelligence.css:39](../src/business/workspaceIntelligence.css) |
| `smart-card-bg-opacity` | `1` | `1` | [workspaceIntelligence.css:40](../src/business/workspaceIntelligence.css) |
| `smart-card-stroke` | [Pixso 角向渐变](../src/business/workspaceIntelligence.css) | [复合表达式／规则](../src/business/workspaceIntelligence.css) | [workspaceIntelligence.css:41](../src/business/workspaceIntelligence.css) |
| `smart-card-stroke-opacity` | `1` | `1` | [workspaceIntelligence.css:42](../src/business/workspaceIntelligence.css) |
| `smart-header-height` | `28px` | `28px` | [workspaceIntelligence.css:43](../src/business/workspaceIntelligence.css) |
| `smart-title-gap` | `8px` | `8px` | [workspaceIntelligence.css:44](../src/business/workspaceIntelligence.css) |
| `smart-content-gap` | `16px` | `16px` | [workspaceIntelligence.css:45](../src/business/workspaceIntelligence.css) |
| `smart-list-gap` | `12px` | `12px` | [workspaceIntelligence.css:46](../src/business/workspaceIntelligence.css) |
| `smart-number-size` | `16px` | `16px` | [workspaceIntelligence.css:47](../src/business/workspaceIntelligence.css) |
| `smart-number-bg` | `rgb(25 25 25 / 5%)` | `rgb(25 25 25 / 5%)` | [workspaceIntelligence.css:48](../src/business/workspaceIntelligence.css) |
| `smart-title-size` | `16px` | `16px` | [workspaceIntelligence.css:49](../src/business/workspaceIntelligence.css) |
| `smart-title-line` | `24px` | `24px` | [workspaceIntelligence.css:50](../src/business/workspaceIntelligence.css) |
| `smart-title-weight` | `700` | `700` | [workspaceIntelligence.css:51](../src/business/workspaceIntelligence.css) |
| `smart-number-font-size` | `10px` | `10px` | [workspaceIntelligence.css:52](../src/business/workspaceIntelligence.css) |
| `smart-number-radius` | `4px` | `4px` | [workspaceIntelligence.css:53](../src/business/workspaceIntelligence.css) |
| `smart-number-weight` | `700` | `700` | [workspaceIntelligence.css:54](../src/business/workspaceIntelligence.css) |
| `smart-number-offset` | `3px` | `3px` | [workspaceIntelligence.css:55](../src/business/workspaceIntelligence.css) |
| `smart-card-stroke-width` | `1px` | `1px` | [workspaceIntelligence.css:56](../src/business/workspaceIntelligence.css) |
| `smart-emphasis-weight` | `700` | `700` | [workspaceIntelligence.css:57](../src/business/workspaceIntelligence.css) |
| `smart-action-gap` | `4px` | `4px` | [workspaceIntelligence.css:58](../src/business/workspaceIntelligence.css) |
| `smart-action-icon-size` | `10px` | `10px` | [workspaceIntelligence.css:59](../src/business/workspaceIntelligence.css) |
| `smart-action-radius` | `2px` | `2px` | [workspaceIntelligence.css:60](../src/business/workspaceIntelligence.css) |
| `smart-tabs-gap` | `32px` | `32px` | [workspaceIntelligence.css:61](../src/business/workspaceIntelligence.css) |
| `smart-tabs-indicator-gap` | `var(--partner-ai-spacing-sm)` | `8px` | [workspaceIntelligence.css:62](../src/business/workspaceIntelligence.css) |
| `smart-tabs-indicator-height` | `2px` | `2px` | [workspaceIntelligence.css:63](../src/business/workspaceIntelligence.css) |
| `smart-tabs-motion-duration` | `200ms` | `200ms` | [workspaceIntelligence.css:64](../src/business/workspaceIntelligence.css) |
| `--partner-host-motion-duration` | `200ms` | `200ms` | [AssistantHostLayout.vue:53](../src/host/AssistantHostLayout.vue) |
| `--partner-host-motion-easing` | `cubic-bezier(0.2,0,0,1)` | `cubic-bezier(0.2,0,0,1)` | [AssistantHostLayout.vue:53](../src/host/AssistantHostLayout.vue) |
| `--partner-host-shadow` | `0 0 48px rgba(0,0,0,.16)` | `0 0 48px rgba(0,0,0,.16)` | [AssistantHostLayout.vue:53](../src/host/AssistantHostLayout.vue) |
| `--partner-host-floating-shadow` | `0 8px 48px rgba(0,0,0,.16)` | `0 8px 48px rgba(0,0,0,.16)` | [AssistantHostLayout.vue:53](../src/host/AssistantHostLayout.vue) |
| `--partner-host-entry-offset` | `24px` | `24px` | [AssistantHostLayout.vue:53](../src/host/AssistantHostLayout.vue) |
| `--partner-host-resize-inset` | `24px` | `24px` | [AssistantHostLayout.vue:53](../src/host/AssistantHostLayout.vue) |
| `--partner-host-focus` | `#191919` | `#191919` | [AssistantHostLayout.vue:53](../src/host/AssistantHostLayout.vue) |
| `--partner-host-focus-width` | `2px` | `2px` | [AssistantHostLayout.vue:53](../src/host/AssistantHostLayout.vue) |
| `--partner-host-focus-inset` | `-2px` | `-2px` | [AssistantHostLayout.vue:53](../src/host/AssistantHostLayout.vue) |
| `--partner-host-floating-radius` | `24px` | `24px` | [assistantWindow.css:6](../src/host/assistantWindow.css) |
| `--partner-host-surface` | `transparent` | `transparent` | [assistantWindow.css:7](../src/host/assistantWindow.css) |

收尾审计补充：`--partner-ai-mode-icon-size=14px`（REQ-006）、`--partner-ai-scroll-fade-size=12px`（REQ-007）已集中。REQ-009 v0.2按最新聊天更正采用关闭默认文本、开启一级文本；两层背景opacity交叉过渡，避免直接插值background-image。开关28×16/thumb12、按钮32/SVG槽24及实际禁用逻辑保持。发送/生成共用精确渐变与纯白token；生成中不禁用、整按钮opacity1，图标为居中10×10/radius2实心方块，停止/完成后恢复官方箭头并按草稿决定opacity0.4/1。锁定IconArrowUp的currentColor变为纯白，不改path/viewBox/stroke-width，不给填充图标追加stroke。

动效依据只读核对相邻Workbench：`catalog/generated/asset.tokens.css`的`--wb-asset-wb-switch-motion-duration:160ms`，`packages/ui-vue3/src/switch/WorkbenchSwitch.vue`实际`ease-out`；Message同一token表及`message/message-motion.css`使用entry-scale0.9。产品在AI语义层自包含这些值，不导入demo资产，不修改Workbench或TinyRobot源码。发送控件位于TrSender公开`footer-right`插槽，使用TrActionButton公开`icon`插槽、disabled/tooltip和hover/active变量；固定24px槽内的Vue Transition负责opacity与scale，按钮实例及停止操作始终保留。开关thumb、双背景、文字色、整按钮透明度及图标使用160ms/ease-out；`prefers-reduced-motion:reduce`关闭这些过渡。升级复核公开slot、Tooltip属性/事件转发与官方SVG。模式弹层圆角`--partner-ai-mode-panel-radius=6px`、AI模块到触发器gap`--partner-ai-mode-control-gap=16px`保持。综合历史清单与未迁移业务样式见[AI_UI_AUDIT.md](AI_UI_AUDIT.md)，其中REQ-006旧停止图标记录由本次需求覆盖。


REQ-008 v0.5 / REQ-027 v0.5：悬浮外壳经共享宿主私有token `--partner-host-floating-radius` 固定当前默认24px；只在owned宿主边界消费。普通panel-radius仍8px，Sender/欢迎卡16px、其他菜单与卡片语义保持，不能因同为24px而把浮窗与消息气泡token混用。历史选值含本地 harness 演示参考，非公司内部正式资产源码；当前 AI 默认参数独立，不需要 Workbench 映射。业务 Demo 资产仍由内部团队提供批准替代。


工作区全屏专用：`--partner-ai-fullscreen-content-max-width:800px` 控制正文与发送区的居中列最大内容宽度，不含原有16/20px安全边距。在面板 `.partner-ai` 根覆盖；不改变侧栏420/480px或悬浮420px宽度协议。全屏欢迎区独立使用`--partner-ai-fullscreen-welcome-max-width:1040px`；恰好三张卡片且实际安全内容≥1040px时三列，每张336px、gap16，当前示例82px高，长标题/说明自然换行增高。普通/回退欢迎卡组仍使用独立400px上限；字号、图标与内边距token不变，消息与发送框仍800px。


2026-10-27 设计修改：用户确认设计稿已更新，消息列表上下内边距统一为 24px，包含窄屏；消息之间的间距、气泡内部间距及面板左右安全边距保持不变。本记录依据当前聊天，未核验设计稿节点。


2026-10-27：历史菜单选中项底色按 [Pixso 10:305493](https://pixso.cn/app/design/CLJAQ3dAcZtiO7IR5r0GNQ?item-id=10:305493) 调整为 `#AA682D`、10% 不透明度，使用独立的 `--partner-ai-history-selected-bg`，不再引用用户消息气泡底色。


2026-10-27：模式菜单默认与触发按钮等宽（覆盖先前 98px 方案）、面板圆角 6px、选项圆角 4px；常见问题菜单与其对齐面板圆角、4px 面板内边距和 4px 选项圆角，宽度仍按问题内容自适应。

## 智慧页签（2026-10-30）

`WorkspaceSmartTabs` 使用 AI 自包含 Token，不读取 `--wb-*`。`smart-tabs-gap` 为32px，`smart-tabs-indicator-gap` 引用 `spacing-sm`（8px），`smart-tabs-indicator-height` 为2px，`smart-tabs-motion-duration` 为200ms；字阶复用 body，颜色复用 text/muted/color-brand-700，智慧标记复用24px smart-icon。选中线一次绘制完整图文宽度，不拼接两段圆角。详见 [SMART_TABS](SMART_TABS.md)。
