# AI UI 交付职责与消费清单

2026-10-29接入说明：优先安装组件 tarball 并按需导入公开组件；备选源码模块用于审核后合并实现。目录用途、两种接入方式与9个模块边界见 [产品开发接入指引](DEVELOPER_START.md)。交付身份以本次外层 manifest / verification 为准，下述早期打包状态只代表当时快照。

2026-10-28工作区说明：本文对照当前 `src/index.ts` 与实现维护；尚未把本轮增量重新组装成交付包。`2026-10-26-solid-smart-0.3.0` 是既有交付快照，版本号同为0.3.0也不能代表当前源码。历史包的内容与验证以各自 manifest / verification 为准，保留原样；公司私有平台注册、内网构建与真实业务API仍待接入验证。

历史分类整理：v0.1 · 2026-10-20。公开出口现以当前 `src/index.ts` 为准；本清单不定义新的包或平台注册格式。package 版本仍为0.3.0，历史产物不能代表当前源码。

## 产品开发配置权限（2026-10-26建议）

本节用于代码交付管控，区分业务内容和AI UI基础规范；不以slot/prop是否存在判断可修改权限。以下是建议白名单，当前未改动公共API或运行时限制。

| 业务可配置 | 对应入口 | 必须保持的基础规范 |
| --- | --- | --- |
| 首页Prompt卡片标题、描述、业务图标、query、数量/顺序、禁用状态 | `welcomeEntries: WelcomeBusinessEntry[]` | 图标尺寸、卡片布局/间距/圆角/字体/hover与交互 |
| 输入建议、常见问题、推荐追问的文案/query/顺序/禁用状态 | `suggestionPills`、`messagePrompts` | 箭头、控件视觉、弹层及键盘交互 |
| 已支持模式的标识/名称/禁用状态和请求处理 | `modeOptions`、composer上下文及事件 | 模式图标、下拉/选中图形与菜单行为；不开放option.icon自由换图 |
| 导航卡标题、描述、业务目标和宿主路由处理 | `BusinessNavigationCard`的title/description/target/navigate | 下钻箭头和卡片默认/hover规范 |
| 业务回复数据、自有业务卡片、业务办理、业务API及存储 | `renderers/contentRenderers`、adapter、业务事件、historyOptions | 基础消息壳、标准工具栏/回复/历史/发送/思考图标及动效 |
| 宿主区域、窗口状态及自有业务扩展动作 | 宿主layout/window接口、toolbarActions、toolbar-end | 标准系统动作含义/图形、焦点/弹层/滚动和会话保留行为 |

既有AI UI图标建议仅将首页`welcomeEntries[].icon`作为常规产品配置。产品自有业务renderer内的业务图标由其自有卡片负责。AI头像、智慧AI标记和品牌变更需由设计/AI UI维护者统一确认；`AiIconProvider/icons`、主题及CSS token覆盖属于维护能力，不能作为产品自由更改标准图形、颜色、字阶、尺寸、圆角和动效的依据。技术接口仍存在，不等于已从API层禁止修改。

完整图标资源、slot/prop实现核查及权限说明见[ICONS](ICONS.md#产品交付配置边界2026-10-26澄清)。

## 职责、公开入口、消费方式与来源

源码目录按实现职责组织，交付清单按消费角色组织；位于 `src/business/` 不表示只能用于 Demo，位于 `src/ui/` 也不表示已独立公开。

| 职责 | 公开入口 / 内部实现 | 消费方式 | 来源与边界 |
| --- | --- | --- | --- |
| 通用聊天呈现 | `ChatPanel`、`resolveChatContent` | 宿主持有消息、请求状态与发送/取消/重试逻辑，通过 `renderers` 接入自有业务卡 | 本项目消费层组合 TinyRobot 0.5.1；不是内置任意业务 API 的会话控制器 |
| 公开 AI 呈现与基础能力 | `AiSummaryCard`、`WorkspaceSmartIcon`、`WorkspaceSmartTag`、`WorkspaceSmartCard`、`WorkspaceSmartTabs`、`BusinessNavigationCard`、`AiAlert`、`AiToast`、`AiIcon`、`AiIconProvider`、`defaultAiIcons` | 包根按需导入；文本、数据与导航处理由业务方提供；品牌和图标遵循上述配置权限 | 本项目自包含实现，复用公开 SVG；AI Token 与字阶在包内闭合，字体家族由宿主提供，不读取 Workbench Token |
| 可选宿主适配 | `AssistantHostLayout`、`BusinessOverlayHost`、`UiDialog`、`useAssistantHostLayout`、`useAssistantWindow` | 宿主提供有限尺寸、导航/业务区域及弹层边界，保持同一面板挂载 | 本项目宿主组合与原生 dialog/portal；不接管业务传输 |
| 协议领域组件与会话组合 | `AgreementTable`、`AgreementAssistantPanel`；内部 `AgreementRenderer`、`useAgreementPanel`、`useAgreementAssistant` | 协议表消费真实 `Agreement[]`；面板消费 `AgreementAssistantAdapter`，组合会话、历史与协议操作 | 本项目领域实现，属于产品公共闭包；不是通用表格、任意业务会话控制器或公司业务卡标准 |
| 内部产品组合 | `ChatComposer`、`ComposerModeSelect`、`ChatWelcome`、`AnswerBox`、`MessagePrompts`、`ComposerSuggestions`、`SuggestionCollection`、历史面板、Tooltip 等 | 通过公开面板的 props/events/slots 使用；源码交付片段仅在同包源码中集成 | 组合官方基础组件与有说明的最小本地适配；没有独立包出口，不开放 deep import |
| Demo / Studio / 测试工具 | `src/demo/`、`src/preview/`、`src/data/`、`mockAdapter.ts`、整页 `RenewalAssistant` | 仅本地效果、示例和验证，不从产品包消费 | Workbench vendor、总览导航/检视移植及虚构数据均排除在产品闭包外；本地 harness 不是公司正式/批准源码 |

宿主侧栏布局由 `AssistantHostLayout.sidebarBehavior?: ChatSidebarBehavior` 选择：`push`（默认）压缩业务轨道，`overlay` 保持业务原宽并覆盖工作区右侧。它与 `windowMode: sidebar | floating`、`fullscreen` 分开；两种策略均可悬浮、连续拖离与全屏，切换保留同一面板实例。两种侧栏共用右侧锚点、侧栏宽度+24px的关闭位移与200ms动效，只有push改变业务网格。完整场景和接入见 [HOST_LAYOUT](HOST_LAYOUT.md)。

协议字段、详情动作属于 `AgreementTable` 的领域合同；虚构协议、金额、mock 流与 Demo 状态标签属于示例。协议组件继续公开导出，不能因总览示例使用虚构数据而归为“仅预览”。

`AgreementTable` 表头使用 14px / 22px、Medium（500），正文单元格及操作文字使用 14px / 22px、400。字重分别复用现有 AI 标题和正文字重 Token；字体家族由宿主提供。此视觉规范不改变 `agreements`、`open` 或 `status` 插槽契约。表格字重、单元格左右8px内边距、列宽与滚动由 `AgreementTable` 统一负责，独立示例和消息内渲染采用同一实现；消息层的普通表格排版仅匹配 Markdown，不覆盖业务组件。通用消息段落间距也仅作用于 Markdown 与 TinyRobot 原生文本，不给业务卡片内部段落追加间距。

输入建议 Pills 默认隐藏横向滚动条及其热区，但保留原生滚动能力。鼠标位于可见建议行时，纵向滚轮转换为横向滚动；边界及无溢出时交还外层，触控板横向手势、Shift＋滚轮、缩放、触屏和键盘沿原生/既有逻辑处理。滚动不触发发送；单击仍直接发送并清空草稿。原滚动条及延迟显隐通过内部 `ComposerSuggestions.scrollbarVisible` 选项保留，不新增公开面板参数。

鼠标左键按住200ms后进入可拖动态，水平移动超过6px时内容跟随拖动，显示抓取光标；不附加惯性。长按、拖动和明显移动后松开都不发送消息或打开菜单；快速单击继续沿用原行为。拖动时关闭集合菜单并抑制文字提示，触屏仍使用原生滑动。Esc、窗口失焦、指针取消、数据变化和组件卸载均结束手势，保留当前滚动位置。200ms/6px属于本地交互策略，不新增视觉Token。

## 公开类型清单

所有名称从 `huawei-partner-ai-ui` 包根导入，具体定义以 `src/index.ts` 为准；此表不增加子路径。

| 对应职责 | 公开类型 |
| --- | --- |
| 消息、状态与面板 | `UIMessage`、`ChatDisplayStopSnapshot`、`AiAlertProps`、`AiAlertType`、`AiToastProps`、`AiToastType`、`ChatWindowMode`、`ChatToolbarAction` |
| 输入、欢迎与建议配置 | `ComposerModeOption`、`ComposerRequestContext`、`WelcomeBusinessEntry`、`ChatSuggestion`、`ChatSuggestionCollection`、`ChatSuggestionPill`、`MessagePromptsResolver` |
| 历史存储与视图 | `ConversationHistoryOptions`、`ConversationStorage`、`ConversationSnapshot`、`ConversationRecord`、`ConversationViewState` |
| AI 呈现、导航与品牌 | `IntelligenceFragment`、`IntelligenceTag`、`IntelligenceItem`、`IntelligenceLogo`、`WorkspaceAnalysisRequest`、`BusinessNavigationTarget`、`BusinessNavigationEvent`、`AiIconName`、`AiIconMap`、`AiIconDefinition`、`AiIconColor` |
| 宿主及业务事件 | `AssistantHostLayoutOptions`、`ChatSidebarBehavior`、`AgreementBusinessAction`、`BusinessActionMode`、`BusinessDialogScope`、`WorkspaceNavigation` |
| 协议传输与领域内容 | `Agreement`、`AgreementAssistantAdapter`、`AssistantDelta`、`AssistantPart`、`AssistantContinuationRequest` |

## 选择消费路径

通用业务先使用 `ChatPanel`，由业务控制器提供 `UIMessage[]`、processing/error 等状态并处理 send/abort/retry/event。业务团队可自建卡片，通过 TinyRobot 公开的 `BubbleContentRendererMatch` 配置 `ChatPanel.renderers`；它是上游类型，不是本包新增导出。卡片、回调与路由实现留在业务应用中，消息中只保存可序列化内容，不把 Vue 组件存入历史。

`ChatPanel` 的 `abort(snapshot?: ChatDisplayStopSnapshot)` 保持原无参处理器兼容。停止按钮会持续可用到传输与逐步展示都结束；在展示尚未完成时停止，快照携带 `messageId?: string`、`messageIndex: number`、`parts: ChatMessageContentItem[]`（上游TinyRobot内容类型）。`parts` 为可序列化的完整思考内容与已显示源片段，不包含DOM或渲染getter。独立面板的消息所有者应按索引及可用ID校验回答、保存停止快照并标记 `completion: aborted`，再持久化自己的历史；只取消请求而忽略快照，不能保证重建后仍保留相同可见片段。现成 `AgreementAssistantPanel` 已接线到自身会话/历史所有者；停止、失败与空输出继续保留思考反馈，操作栏仍遵循生成/展示与停止态门禁。

已有协议业务可使用 `AgreementAssistantPanel`，通过 `contentRenderers` 组合业务卡；内部匹配 priority 为 -10，数值更小的自定义匹配优先。该面板的 adapter 仍要求 `stream`、`updateAgreement`、`renewAgreement`，`continueStream` 可选。其他业务不必为了使用聊天 UI 伪造协议操作。当前没有独立公开的通用会话控制器，本轮不抽取该控制器、不改 `AssistantPart` 领域 union。接入细节见 [INTEGRATION](INTEGRATION.md)。

统一引入 `huawei-partner-ai-ui/styles.css`，使用 `.partner-ai` 作用域并提供实际可用高度。`workbench` 是兼容保留的主题标识，不表示读取 Workbench Token；Token 独立也不等于隔离任意宿主 CSS。尺寸与弹层合同见 [HOST_LAYOUT](HOST_LAYOUT.md)，参数见 [AI_TOKENS](AI_TOKENS.md)。

总览的 15 份默认实例包含 10 份公开包示例和 5 份源码集成示例。Sender、消息、追问、输入建议、历史局部片段使用内部组件，不意味着对应公开叶子组件不存在：例如 `AiSummaryCard`、`BusinessNavigationCard` 已公开，消息壳仍是内部实现。Prompts/Pills 通过 `messagePrompts` / `suggestionPills` 配置消费；独立说明页不等于独立导出。目录与包根、`styles.css` 契约保持原样。

## 三种 Workbench 来源不得混写

2026-10-26当前源码核查：公共`src/ui`、`src/business`（产品入口依赖闭包）、`src/host`不导入Workbench vendor组件，也不使用`--wb-*`变量；AI回复Demo已移除WorkbenchTag注入，摘要无演示Tag，协议状态按文本呈现。产品构建闭包另由build:lib的product-boundary检查。

其余仍存在的Workbench内容属于明确的演示宿主：公司信息页面、顶栏、浮钮；`AgreementRenewalsWorkspace`中的Button/Input。它们不作为AI基础组件交付。2026-10-29更新：该智慧示例原先使用Workbench Table，现改为复用AI公开的 `AgreementTable`，与回复内协议表格共用字段、样式及滚动行为；详情仅显示本地演示反馈。`WorkspaceSmartTag`是本工程原生AI智慧组件，不是WorkbenchTag。包内Tooltip/滚动/弹层适配以及预览字体、部分本地SVG保留历史Workbench来源，但已自包含，不依赖相邻工程或vendor运行组件。

两种 `WorkspaceSmartCard` 已包含标题、智慧标记、序号、正文强调、详情链接及箭头、内部间距与背景描边，消费方传入结构化内容即可呈现。智慧页签已独立为公开 `WorkspaceSmartTabs`（见 [智慧页签合同](SMART_TABS.md)），包含智慧标记、选中线及键盘行为。“外层业务卡＋表格＋分隔线＋内嵌智慧卡”仍为 Demo 组合，由业务方按需配置，不绑定进智慧卡或页签。

| 来源角色 | 实际范围 | 交付口径 |
| --- | --- | --- |
| 演示资产 | `src/demo/vendor/workbench`、总览导航及检视工具的选定 JS/Vue 闭包 | 仅 Demo/Studio；非公司正式/批准源码，不进产品闭包；正式接入由内部团队提供批准资产 |
| 历史参考 | 配色、间距、几何、动效和交互来源记录 | 保留来源与原设计权利；不是 AI 运行时 Token 依赖，也不证明公司生产批准 |
| 产品自包含适配 | Tooltip、模式选择、原生滚动与弹层等已注明来源的本地实现 | 按实际依赖进入产品闭包，公开与内部边界分别以包入口为准；不导入 Demo vendor，保留官方 API 缺口与升级复核说明 |

组件源码、运行时和npm包均不携带字库。字体由宿主统一提供，AI UI只继承字体家族，字阶保持规范；HarmonyOS字体原件与许可仅供Vue脚手架的预览入口可选加载。2026-10-20用户指定的机器人头像也以公共资产副本作为面板默认形象随包交付，保留`avatarSrc`覆盖；其余Demo品牌图片仍排除在产品闭包之外。细节见 [SOURCES](SOURCES.md)、[FONTS](FONTS.md)；公司正式资产与真实宿主验收仍由内部团队确认。

## 当前工作区与新远端的衔接

当前本地目录是本轮唯一编辑工作区。已完成的基线映射为本地 `ba37028f995fd335100e5fd5570c254ad6b7dbd3` → 私有 GitHub `main` 初始提交 `d928bb8a2321e487d172af04ac5d5a0469e5c5a2`。两者历史独立；原目录无 remote，本轮不新增提交、remote、clone或推送；当前交付状态见顶部更新。

后续需要同步时，以新远端最新 `main` 为父提交导入审核后的文件级差量，同时审查删除项和远端新增改动，保留其 `.gitignore`、`docs/GITHUB_IMPORT.md`、来源清单并更新真实哈希。不要直接推送/合并原仓历史，不覆盖远端或 force push；已有本地证据与用户改动保留。执行规则以远端 [GitHub 初始导入与后续同步](https://github.com/BossXuInChina/huawei-partner-ai-ui/blob/main/docs/GITHUB_IMPORT.md) 为准，不同时开展第二条独立编辑线。

## 待内部确认

公司 TurboUI/Starling 的正式微组件打包格式、manifest + entry 样例/schema、loader、运行时共享、资源与生命周期约定，以及真实 API/权限/幂等仍待内部团队确认。`delivery-templates/company-card` 仅是薄适配参考。分类不等于平台注册。标准 npm 仍维持单包；备选源码模块按真实依赖提取，不新增独立 npm 出口或公司 manifest 字段。

## 通用 Toast（2026-10-27）

从包根导入 `AiToast` 和 `AiToastProps` / `AiToastType`；调用方传入 `v-model`（boolean）、`message`，可选 `type="success" | "error"`（默认 success）和 `duration`（默认 2000 毫秒后开始退出动画，0 不自动关闭）。自动消失时发送 `update:modelValue(false)` 和 `close`。图标内置，无需外部传入。

```vue
<AiToast v-model="noticeVisible" message="复制成功" />
```

白底、14px 成功图标、8px 间距、12px / 16px 内边距、8px 圆角、14px / 22px 正文和阴影来自 Pixso `5711:1`。位于 ChatPanel 内时，在该侧栏内部水平居中，距该侧栏 AI 顶部导航（`.chat-header`）下沿 24px；跟随侧栏移动、缩放和页面滚动，消息滚动不改变位置，收起侧栏时关闭。局部无导航时距面板顶部 24px；独立使用时回退到视口顶部 24px。`AiToast` 的顶部间距使用 `--partner-ai-toast-top`（旧 bottom 参数仅为协议业务提示保留），保留 `--partner-ai-toast-padding`，字体继承宿主。普通 DOM 浮层通过 Teleport 挂载到所属 document 的 body（原生 dialog 内则留在该 dialog），避免被面板滚动或 transform 裁切，并随页面一起绘制；跨 portal 保留宿主字体与 AI Token，不抢焦点；每个 document 仅显示最新一条通知。连续相同通知应重新打开 v-model，或使用新的组件 key，以重置消失计时。不依赖 HTML Popover API。

点赞显示“感谢您的反馈！”，取消点赞显示“已取消点赞”。回复复制仅在剪贴板写入成功后显示“复制成功”，失败显示错误通知；旧的隐藏状态文字已移除，避免重复播报。点踩反馈卡片通过有效校验并提交后，关闭卡片、恢复点踩按钮焦点，并显示“已提交，非常感谢您的支持！”。`chat:feedback` 仍由宿主消费；当前通知表示本地反馈已交出，不代表真实业务 API 已接入。通知组件仅呈现结果，不提交业务请求。

Toast 动效沿用 Workbench Message：200ms、`cubic-bezier(0.2,0,0,1)`、0.9→1 缩放并淡入，退出反向；`prefers-reduced-motion` 下无动效。对应 AI 参数为 `--partner-ai-toast-motion-duration` / `--partner-ai-toast-motion-easing` / `--partner-ai-toast-entry-scale`，不运行时引用原 Workbench。
