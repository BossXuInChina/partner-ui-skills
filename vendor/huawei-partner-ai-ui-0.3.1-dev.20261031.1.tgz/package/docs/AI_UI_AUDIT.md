# AI UI 综合盘点与本地里程碑

2026-10-19 增量：本文以下为历史审计快照，其中 Foundation → AI 映射已由独立 AI 默认参数取代。当前整改与实际验证见 [AI_TOKEN_INDEPENDENCE.md](AI_TOKEN_INDEPENDENCE.md)，当前默认表见 [AI_TOKENS.md](AI_TOKENS.md)。

历史审计快照：其中操作类协议卡已由REQ-027 v0.5退役，旧条目不代表当前可用组件；Workbench本地资产仅demo、非公司内部正式/批准源码。

核对日期：2026-10-13。分支 `feat/r2-squeezed-sidebar`，提交前基线 `a8f4c5c`。范围为已授权的 REQ-003 v1.8、REQ-005 v0.3、REQ-006 v0.3、REQ-007 v0.2、REQ-008 v0.2 及相关消息／宿主回归。本报告不把“待验收”改为用户视觉验收，不计算缺乏定义的代码复用百分比。

已读取工程 AGENTS.md、协作索引、上述需求及现有验证记录；工程与上级目录未发现额外 `.agents` / `.codex` 技能目录。原 Workbench 只读，本轮未编辑它。源码与资产来源继续见 [SOURCES.md](SOURCES.md)。

## 1. 实际组件复用

以下以安装的 `node_modules/@opentiny/tiny-robot/dist/index.d.ts`、各组件发布 JS 和 `dist/style.css` 为准；SVG、类型导入、kit hook 单独列出，不算 UI 组件复用。

| 通用功能 | 实际官方组件／接口 | 本地边界与适配证据 |
| --- | --- | --- |
| 实例主题 | `TrThemeProvider` | `AgreementAssistantPanel.vue`：theme、color-mode、target-element 指向唯一实例根；Foundation/AI 样式也在 `.partner-ai`，不修改宿主 html 主题。 |
| 头／消息区／底区 | `TrLayout` | `ChatPanel.vue`：normal 模式及 header/main/footer slots；背景变量透明；`.tr-layout__main/content` 最小尺寸与滚动适配在 `styles.css`。 |
| 消息列表、角色、事件与 renderer | `TrBubbleList`、`TrBubbleProvider` | `ChatPanel.vue`：messages、groupStrategy、contentResolver、roleConfigs、renderer matches/attributes、bubble-event、after slot；一条回复共用 Box。autoScroll=false 为公开选项，本地 followReply/onScroll 保持向上阅读与流式跟随。 |
| 气泡／文本 | `BubbleRenderers.Box`、`BubbleRenderers.Markdown` | `AnswerBox.vue` 使用官方 Box/default slot；`ChatPanel.vue` 文本 renderer；`messageStyles.css` 映射 Box/text 变量，内部 `.tr-bubble__body/content/box` 调整宽表格与布局。不是另造气泡。 |
| 多行输入／发送／中止 | `TrSender` | `ChatComposer.vue`：v-model、loading、mode、placeholder、auto-size、max-length、submit/cancel、footer/footer-right；暴露的 editor 用于焦点及 ARIA。固定132px与编辑器局部滚动需要 `.tr-sender-*` / `.ProseMirror` 适配。 |
| 输入动作、顶部默认动作、回复动作 | `TrActionButton`（内部 Tooltip） | `ChatComposer.vue`、`ChatPanel.vue`、`AnswerBox.vue`：icon VNode/Component、tooltip/placement、disabled、原生 type/ARIA/events；32px或36px尺寸由本地 token/CSS 保持。Tooltip 的 focus/hover reset 需局部覆盖，升级复查属性转发和焦点环。 |
| 欢迎身份与说明 | `TrWelcome` | `ChatWelcome.vue`：title、description、icon、align；内部 title-wrapper/icon/title/description 局部布局。0.5.1 无 title tag/slot API，`vWelcomeHeading` 改 aria-level=2；avatarSrc 使用本地 img VNode。 |
| 首页大卡 | `TrPrompt` | `ChatWelcome.vue`：label、description、icon、disabled；官方 radius 变量及局部 content/ellipsis；div 根加 role/button、tabindex、Enter/Space 与禁用守卫，保持82px、radius16、面板总左右40px。 |
| 发送区建议 | `TrSuggestionPills`、`TrSuggestionPillButton` | `ChatPanel.vue`：default slot、overflow-mode=scroll、item、disabled、click；`suggestionStyles.css` 映射 palette/shadow；内部 container 适配单行、阴影空间及 hover 滚动条，本地键盘只操作滚动区。 |
| 消息追问 | `TrPrompt` | `ChatPanel.vue` 的 BubbleList.after 中逐项 Prompt，label/badge VNode/disabled；`suggestionStyles.css` 映射 title/padding/radius/bg，内部 content/badge 调整尾箭头。`TrPrompts` 无逐项 slot，因此直接使用公开 Prompt，保持逐项键盘和 ARIA。 |
| 回复反馈 | `TrActionButton`，未使用 `TrFeedback` | `AnswerBox.vue` 本地 copy/rate/saved/regenerate 状态；0.5.1 `FeedbackProps.actions` 可接 icon/onClick，但无逐项 disabled/aria-pressed API及 item slot，无法直接保留已确认流式禁用和切换状态。保留最小业务编排，不重复基础按钮。 |
| 模式单选 | 本地 `ComposerModeSelect` | 安装包 `DropdownMenuItem` 仅 id/text，slots 仅 trigger，发布实现为 click 的 li；无逐项 disabled/selected/键盘 listbox API。保留禁用跳过、active descendant、Home/End/方向键、Escape/Tab、焦点恢复及实例主题 Teleport；源码已补缺口与升级注释。 |
| AI 开关 | 本地原生 button/role=switch | 安装0.5.1 无公开 `TrSwitch`；demo WorkbenchSwitch 带表单/loading 闭包，不引入产品。28×16/12px thumb、文字与开关gap4、无横padding；原生 Enter/Space。 |
| 业务弹层 | 本地 `UiDialog` / 原生 dialog | TinyRobot0.5.1 无对应公开通用 Dialog/Drawer 导出；保留根内 top layer、showModal、初始焦点、Tab、Escape/遮罩与恢复。业务 dirty/busy/失败上下文由 useAgreementPanel 管理。 |
| 进度／错误／兜底 | Box 内本地文本、spinner、FallbackRenderer | active reply 的 progressText 在同一 Box 内，避免额外壳与双spinner；error/aborted 经 after/Box；fallback 为未知结构内容，不假装官方业务 renderer。spinner 是小范围 CSS，非新增基础组件体系。 |
| 窗口模式／横条拖动 | Layout + ActionButton；宿主定位本地 | `chatWindow.ts` 是公开类型；`ChatPanel` 仅发受控窗口事件。`src/demo/useAssistantWindow.ts` 负责捕获、边界、键盘、resize及清理。官方 Layout.floating 会 Teleport body、按视口限制并带 aria-hidden 横条，不能满足嵌入工作区和既有键盘合同。 |
| 协议卡／表格／操作表单 | 本地领域组件、HTML table/form | `AgreementCard/Table/Renderer` 与 adapter 合同是业务 UI；不以官方通用组件强行替代领域数据、幂等、错误和dirty状态。自定义 toolbarActions 的文字按钮及宿主 toolbar-end 是扩展 API，不计官方按钮复用。 |

`useAgreementAssistant.ts` 实际调用 kit0.4.0 `useMessage`、responseProvider、onCompletionChunk/runDefault、plugin.onFinally；这是状态／流式引擎复用，非组件。根 svgs0.3.5 实际提供 Sparkles、TypeAll、NewSession、History、ArrowUp、Voice、Shell、ArrowDown、Check、ArrowRight、Refresh、Copy、Like、Dislike 等图标，不计作基础组件。图片／停止／收藏为已有最小本地线性SVG；官方图片／停止形态不符，根版本无同等收藏轮廓。Voice 保留官方路径，局部 viewBox `5.5 5.5 22 22`；升级需重新量边界。仅调整 #191919 ink 的 fill/stroke，未重画官方图标。

## 2. Foundation → AI → TinyRobot

唯一 AI 默认层在 `src/ui/foundation/aiTokens.css`；Workbench Foundation 本地副本为 `src/workbench-tokens.css`（来源说明与既有 hashes 见 SOURCES）。下表列出当前真实映射，完整 AI 默认表见 [AI_TOKENS.md](AI_TOKENS.md)。

| Foundation／规范输入 | AI 语义输入 | TinyRobot 变量／消费者 |
| --- | --- | --- |
| surface-container/page、text-primary/secondary、brand | panel-bg/page-bg/text/muted/accent | `styles.css` 保留兼容 `--ai-*` → `--tr-container-bg-default/page-bg-default/text-primary/text-secondary/color-primary`；局部气泡、Sender、Prompt/Pills直接引用AI层。 |
| Body M 14/22/400、Caption M 12/20 | body-size/line/weight、caption-size/line | `--tr-bubble-text-font-size/line-height/color`、`--tr-sender-font-size/line-height`，Markdown/body本地文字。Sender weight/family/letter-spacing经局部CSS。 |
| component-xs/sm/md/lg/xl=4/8/12/16/24 | gap-sm/md/lg、安全留白、padding、message-gap、mode-control-gap | `--tr-bubble-list-gap/box-padding`、`--tr-sender-gap/footer-gap/footer-padding/action-gap/multi-main-padding`，本地Layout与按钮几何。注意gap-lg当前值12，mode-control-gap独立16，不按名字猜值。 |
| icon32/24/16/12、radius-lg8/full999 | control/icon/small/arrow-size、control-radius/full-radius | ActionButton外部尺寸、Prompt/Sender图标CSS；未宣称全都有官方尺寸token。模式功能图标独立14。 |
| REQ消息24圆角、orange-10、agent shadow | bubble-radius/user-bubble-bg/agent-bubble-bg/shadow | `--tr-bubble-box-bg/border/padding/shadow/shape-rounded-radius/shape-corner-radius`；messageStyles最终决定角色样式。 |
| REQ发送132高/16圆角、原Sender阴影 | composer-height/radius/bg/shadow | `--tr-sender-border-radius/bg-color/box-shadow`；`header-border-bottom:none`。外部132高，内部slots/editor局部适配。 |
| Body S12/20、32高/8圆角/12 Hpad、0/4/16黑12% | suggestion-* | `--tr-suggestion-pill-button-bg-color/hover-bg-color/color/box-shadow`；Prompt `--tr-prompt-title-font-size/line-height/font-weight/color/padding/border-radius/bg/bg-hover/bg-active/bg-disabled`。 |
| 用户精确侧栏渐变 | sidebar-bg/bg-image | 只绘制本地 `.chat-panel`；`--tr-layout-bg/header-bg/main-bg/footer-bg:transparent`，`--tr-layout-main-min-width:0px`；内容mask独立12px。 |
| headline字号/字重、欢迎82高/16圆角/40 inset | welcome-*/heading-weight | TrWelcome内部文字CSS；大卡 `--tr-prompt-border-radius`，独立于32px追问，不用Pills字体覆盖。 |

扫描去除注释后统计本地 src 的 var()/getPropertyValue 消费（不把类型或文档提及算消费）：114个AI定义，无重复定义、无未引用定义、无未定义AI引用。`mode-panel-min-width`由 positionPanel 读 computed style，不因缺少var()误报。45个声明过的 `--tr-*` 名称全部存在于安装 style.css；这是名称核对，实际视觉/状态效果另由浏览器与独立消费验证。

作用域与剩余问题：

- `.partner-ai`自身声明默认值，宿主覆盖要作用在组件根，祖先同名值不能越过子根声明。直接消费ChatPanel也必须按既有合同提供 `.partner-ai` 根及足够高度。模式body Teleport复制解析后的AI变量和font-family，避免依赖demo变量；可覆写全局portal的宿主规则仍需自行验证。
- 本轮将messageStyles中的旧 `--ai-page/accent/accent-soft`消费改为对应AI语义输入；兼容别名仍用于旧业务层，未删除以免改变其它消费者。
- Foundation库存有未被AI使用的变量，这是来源库存，不为零未使用删改生成文件。src扫描中7个asset/candidate变量来自demo Foundation/候选资源（`src/demo/demo.css`），不属于产品AI缺失变量；公开入口和库模块不引用这些demo文件。
- `styles.css`同时包含旧原型壳／业务表单及后续ChatPanel覆盖；存在被更具体规则覆盖的header/footer/Box候选值、白色Box回退 `#fff`、chat-feedback多条padding。未在此次尾声大规模删层：它也服务独立业务展示，移除需明确消费范围。旧 `--partner-chat-user-bubble-bg/bubble-shadow`候选回退被最终AI消息层覆盖；目前只承诺文档中的三个高度协议，新的视觉覆盖应使用AI token。
- 卡、表格、drawer、modal、toast的spacing/font/radius仍多处直接写值（`styles.css` 的 `.button/.status-pill/.agreement-card/.table-title/th/td/.drawer/.field/.confirm-modal/.toast`）。可分业务组件后续收敛，当前不宣称全仓语义化。18px通用button SVG规则由聊天特定24px覆盖；通用强调字重500、辅助400也是旧规则，后续清理需验证独立组件。

## 3. 硬编码分类与本次处理

| 类别 | 真实例子 | 判断／处理 |
| --- | --- | --- |
| 应集中视觉值 | 模式图标14px、scroll mask12px、switch-off直接取wb-color-none | 本轮新增mode-icon-size、scroll-fade-size、switch-off-bg语义token，保持值；Prompt content重复规则合并。 |
| 已集中规范值 | Sender132/16、switch28×16/thumb12、欢迎82/16/40、follow-up32/8/gap16、阴影和用户气泡orange-10 | 在aiTokens中合法字面量，无需为消灭字面量继续拆散。用户渐变312.17/672.61及固定圆心原值完整保留。 |
| 需后续业务样式收敛 | 上节业务字段、按钮、弹层和旧回退样式 | 保留问题清单；不改变此次批准的设计或做重大组件迁移。 |
| SVG几何 | viewBox、path、坐标、rx、stroke-width及#191919属性匹配 | 不是主题尺寸硬编码；用于真实矢量路径或锁定包ink适配。mask中的#000是alpha几何，不是产品黑色色板。 |
| 布局／可访问性 | 0/100%、minmax、1px边线、2px focus/outline offsets、1px屏幕阅读器裁剪 | 合理基础常量，保留；不每个数字创建token。 |
| 数学／边界／算法 | onScroll底部距离20、fade容差1、portal视口安全8/12及offset4、Date.now()/1000、generation；宿主clamp、floor、0.85、edge12、max800、键盘10/40 | 各自为协议/容差/算法或宿主参考策略；不与视觉gap强行共用。宿主几何集中在useAssistantWindow，未来产品策略由宿主配置。 |
| demo／测试数据 | 420/480与1920 breakpoint、mock建议、虚构协议、测试长文本 | 演示或验收输入，不能当作真实业务API，也不纳入产品模块。 |

本轮文档纠偏：AI_TOKENS中旧toggle Hpadding6改为已批准0；README旧16/56/204区域说明改为24/48/200及Pills附加48；DELIVERY空模式状态改为当前可聚焦no-op／显式或全部禁用仍不可用。未修改需求正文版本或伪造批准历史。

## 4. 版本、升级与接入边界

实际安装及package/lock保持 Vue3.5.13、robot0.5.1、kit0.4.0、根svgs0.3.5；robot依赖svgs0.5.1继续并存。package.json/pnpm-lock.yaml相对基线无diff，未发现patch-package、patchedDependencies、overrides配置或新增patch；本轮不编辑node_modules，不宣称对官方发布包做了新的全量hash校验。

升级脆弱点集中：Layout main/content；Bubble body/content/box；Sender multiple布局、footer左右动作组、editor-scroll、native-submit与ProseMirror；Welcome标题及heading directive；Prompt content/badge及disabled class；Pills container/overflow-scroll；Tooltip focus reset及属性转发；SVG ink attribute/viewBox。源码注释说明需求、公开API/内部DOM边界与复核点。官方类型中的editor exposure、renderer attributes、BubbleList.after/groupStrategy、kit finally顺序也必须复核。大规模迁移必须先证明保留键盘／禁用／焦点／滚动／流式行为。

产品入口 `src/index.ts`；本轮增加ChatSuggestion/MessagePromptsResolver及ChatWindowMode公开类型与对应组件props/events。构建边界插件确认demo/preview/data/mock/旧RenewalAssistant未进入产品JS；声明检查无demo、Studio、collaboration。package.files仍是dist-lib/README/docs允许清单，需求目录、.artifacts、deliverables、ZIP不加入。Studio检视ported闭包无此次编辑，不作为TypeScript完整改写。

窗口为受控宿主行为：单实例保持挂载，宿主承担尺寸／定位／capture／关闭／resize／焦点和reduced-motion；ChatPanel只发事件并保存本地滚动偏移。无handler的语音、图片、历史、未受控agent为安全no-op，真实配置disabled和业务busy/dirty状态保持；点赞/收藏仅本地状态。真实stream、鉴权、上传、语音、历史存储、服务端幂等及公司manifest schema仍未接入。具体合同见 [INTEGRATION.md](INTEGRATION.md)。

## 5. 验证与定稿规范

此次里程碑运行一次AI受影响矩阵（14个spec，70项），覆盖跨任务整合后的状态／宽度／滚动／键盘／焦点／弹层。未扩大到原Workbench全量或重跑不受影响的Studio检视套件。证据保留于 `.artifacts/final-ai-audit/`，不纳入提交。

| 检查 | 实际结果与耗时 | 边界 |
| --- | --- | --- |
| pnpm lint | 通过，1.283s | 收尾源码版本；测试修正后又确认lint/typecheck。 |
| pnpm typecheck | 通过，1.607s | Vue及TS；不冒充ported JS完整TS改写。 |
| pnpm build | 通过，8.752s | 应用、库、库声明；库边界通过（forbidden=[]）。已有大chunk提示保留。 |
| 首次70项矩阵 | 66过、3失败、1条件skip，78.892s | 失败均为sidebar-structure旧footer200断言，REQ-005当前demo实际248；未改阈值、未改产品规避失败。旧包预览需PARTNER_LEGACY_PREVIEW_URL，未启动。 |
| sidebar-structure修正后定向重跑 | 3/3通过，7.469s；有效合并范围69过／1条件skip | 更新为批准的200+32+16=248，并新增建议32高、到Sender16与Sender132精确断言；三个高度600/900/1100，其余有效66项复用。 |
| window独立消费 | 通过，12.6s | 临时app直接复制dist-lib/public exports，锁定依赖磁盘复用，声明/构建/事件/旧消费方/主题/草稿验证；不是tarball安装。 |
| suggestions独立消费 | 通过，9.384s | 同样直接复制dist-lib；npm仅pack --dry-run核对允许清单，无生成包；覆盖填入不发送、终态追问、空配置、尺寸token和宿主主题。 |
| 冻结锁干净安装 | 复用既有 `.artifacts/clean-rebuild.json` passed | package/lock未改，本次未重装；旧证据不代表本轮新增源码已在干净安装中重跑。 |
| REQ-007精确渐变 | 复用原420/480实测 `.artifacts/req-007/preview.json`（11.199s）；源码核对 | 外背景表达式未改；此次只集中12px mask值，related scroll/focus场景随矩阵验证，未新增全主题截图。 |
| Studio检视／Safari／Firefox／真机touch／内网 | 未在本轮验证 | Studio可复用其前序范围证据；浏览器touch仅Chromium模拟。真实手机键盘/visualViewport、完全裁剪或零尺寸宿主、公司构建/schema/业务API仍未测。 |

已定稿值的代码与验收一致：REQ003 Body14/22/400及placeholder；AI文字左开关右28×16、gap4/Hpad0、到模式gap16；模式14/radius8；右动作32/SVG24、4/8/12间距；欢迎82/radius16/总inset40；REQ005追问32/radius8/gap16、箭头10/gap8/hover4、Pills32/8/Hpad12/body12/距Sender16/阴影黑12%/单行横滚；REQ006线性与安全占位；REQ007原渐变及12mask；REQ008窗口单实例／pointer／键盘／边界／清理。没有发现这些定稿规范的产品回归；旧测试期望不同已明确处理，视觉验收仍保留需求原状态。

## 6. 本地提交范围

仅暂存已授权AI里程碑相关源码、接口、宿主示例、测试、两份非打包消费脚本、AGENTS/README/协作需求与接入/token文档及本报告。对暂存diff作秘密与意外文件检查，排除 `.artifacts`、临时截图/trace、构建输出、旧ZIP、deliverables、node_modules和无关Studio改动。提交完整SHA由最终响应提供，避免在提交内容中循环自引用。

不push、不上传Library、不生成或更新交付tarball/ZIP；已有评审包没有此次增量。工作区原有及本轮`.artifacts`继续保留，不宣称全干净。剩余业务样式收敛与重大组件替换仅列问题，未扩大实施。
