# AiAlert 接入（REQ-029）

## 版本核实与边界

本工程锁定 `@opentiny/tiny-robot@0.5.1`。已核对安装包 `package.json` 的 `main/module: dist/index.js`、运行时导出列表、`dist/index.d.ts` 和实际组件目录：没有公开 `Alert` / `TrAlert` 或 Alert 组件目录。[官方组件目录](https://docs.opentiny.design/tiny-robot/guide/quick-start)也未列出 Alert；网站仅作旁证，以锁定安装包为准。

因此 `src/ui/messages/AiAlert.vue` 为消费方原生 Vue 组件，不修改 TinyRobot 源码、不依赖其内部 DOM，也不导入 demo vendor 的 WorkbenchAlert。升级 TinyRobot 时复核是否提供支持无背景、无边框及单一播报区域的公开 Alert，再决定是否替换内部实现。默认错误图标复用根 SVG 包 0.3.5 的公开 `IconError`；robot 内部 0.5.1 SVG 依赖不变。

## 公共契约

从 AI 模块入口导入 `AiAlert`、`AiAlertProps`、`AiAlertType`。类型只包含本次需要的 `'error' | 'neutral'`，默认 `neutral`；`message` 必填、`description` 可选且均按纯文本渲染。不提供重试、关闭或恢复事件，业务动作继续由原消息操作栏负责。

```vue
<script setup lang="ts">
import { AiAlert } from 'huawei-partner-ai-ui';
import 'huawei-partner-ai-ui/styles.css';
</script>
<template>
  <div class="partner-ai">
    <AiAlert type="error" message="生成中断，已保留以上内容" description="连接已断开。" />
    <AiAlert type="neutral" message="已停止生成" />
  </div>
</template>
```

沿用 `.partner-ai` 的现有 token 作用域。透明底、无边框/阴影/内边距，正文 `--partner-ai-body-size/body-line`（14/22），图标 `--partner-ai-small-icon-size`（16），图文 `--partner-ai-gap-md`（8），原因与主文 `--partner-ai-gap-sm`（4）。错误主文和图标使用 `--wb-color-error`，原因/中性主文使用 `--partner-ai-muted`。无需新增颜色别名。单独使用时宿主负责外围尺寸和间距。

错误默认有图标，主动停止默认无图标。可以通过已有 `AiIconProvider` / `ChatPanel.icons` / `AgreementAssistantPanel.icons` 的 `'alert.error'` 键替换错误图标；单实例可用 `#icon` 插槽覆盖（中性状态也支持）。插槽只放装饰性本地 SVG，外层已设 `aria-hidden`，不放按钮、链接或独立播报节点。

组件根节点按类型提供 `role="alert"` 或 `role="status"`，`aria-atomic="true"`，利用角色隐含 live 语义，不为图标、主文或原因再创建 live 区域。若宿主已有统一播报区，给此实例传 `role="none" aria-live="off"`，由宿主管理。实际辅助技术语音播报仍需人工验收。

## 消息与总览集成

`AnswerBox.vue` 已消费组件，`.answer-failure/.answer-stopped` 根类继续保留复制排除、间距和现有定位契约。错误和主动停止互斥；真实错误原因在空正文/部分正文时均可显示，原正文保持正常颜色。重试、继续、恢复时清理错误及停止状态仍由既有 REQ-029 引擎管理；没有额外错误卡片或重复重试按钮。

总览消息页 `http://127.0.0.1:4178/overview.html?page=messages#messages-alerts` 已直接复用 `src/preview/AiAlertExamples.vue`，提供状态、图标替换、播报覆盖及接入片段。仅增加该预览组件的可选 embedded 承载，独立页面默认表现与产品实现保持。独立源码开发预览地址：`http://127.0.0.1:4178/src/preview/ai-alert.html`。该页面现已纳入原型应用构建；不进入产品库闭包。

原业务预览 `http://127.0.0.1:4178/` 可选「无正文失败 / 重试」「部分失败 / 不支持续写」「部分失败 / mock续写」，打开 AI 后发送问题检查原消息恢复。没有接入真实模型/API。

## 验证约束

本轮仅 headless 定向场景、lint、typecheck、独立源码消费与产品闭包核查。用户禁止打包，因此未运行 `pnpm build` 或会执行 `npm pack` 的 `pnpm test:consumer`；源码消费不代替正式构建产物/包消费门禁。实际结果见 `.artifacts/req-029-ai-alert/REPORT.md`。
