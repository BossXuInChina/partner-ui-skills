# pic-ai-card 源码迁入与待确认接口

当前交付分类与公开类型以[COMPONENTS.md](COMPONENTS.md)为索引。Workbench资产边界分为Demo vendor/Studio工具、历史设计参考、产品自包含适配三类：前者不进产品；参考与适配保留来源及权利，不代表公司正式/批准源码。产品Tooltip、滚动等本地适配不导入Demo闭包，AI Token不读取Workbench变量。正式接入由内部团队确认批准组件与资产，见[SOURCES.md](SOURCES.md)。

## 结果展示与思考保留（2026-10-21 源码增量）

`ChatPanel` 的新回答在 TinyRobot 0.5.1 公开 content renderer 边界逐步提交 Markdown 源码前缀（本地呈现节奏约90字/秒）；适配器返回整段或流式增量均可。业务块保持完整结构，按内容顺序淡入；复用 `--partner-ai-control-motion-duration` / `--partner-ai-control-motion-easing`（当前160ms / ease-out），不改变卡片内部文字。自定义 renderer 的匹配优先级、属性与事件保留；其根元素淡入需要适配 Vue 的元素/Fragment 根边界，升级 Vue 或 TinyRobot 时复核。

内置协议控制器在 `UIMessage.uiParts` 保存完整显示序列并设置可序列化的 `uiPartsOrdered:true`，`content` 继续保存传输文字；resolver 使用这份序列避免文字重复和卡片重排。未设置该标记且 `content` 为字符串的旧历史继续兼容原来的合并/摘要前置规则。直接消费 `ChatPanel` 的宿主在 `content` 数组中提供的明确顺序也会保留，思考区统一置于顶部。

思考原文保留在同一标题下，完成即折叠，可反复展开；没有原文时保留反馈行，不生成灰卡或虚构模型思维。思考区到普通正文复用 `--partner-ai-message-padding`（当前16px），业务块仍用 `--partner-ai-message-business-gap`（当前20px）；内部头体8px、padding/段落12px和思考中204px上限保持。小灵默认2倍速，文字队列、卡片淡入和最后绘制均确认后才向下一个十字姿态收尾。

停止按钮保留到前端展示队列结束。用户停止冻结已显示前缀，立即停止动效并取消待展示项；网络失败则同步保留已经收到的有效内容快照并显示错误，不继续排队。完整接收内容仍留在消息源/历史中，恢复历史静态完整展示；重试从头重启。`prefers-reduced-motion:reduce` 下正文直接呈现、卡片无淡入，小灵静态。以上均为源码行为，本轮未构建发布产物或验证真实后端。

## REQ-029 同气泡错误与可选续写（源码增量）

`AgreementAssistantPanel` 的错误、停止、重试、重新生成和继续生成均更新原回答；重试/重新生成调用原问题的 `stream` 从头回答，继续调用可选的 `continueStream` 追加增量，始终保留草稿和后续消息。`continueStream` 缺省时不会显示「继续生成」，已有两参数 `stream` adapter无需修改。

```ts
import type { AgreementAssistantAdapter, AssistantContinuationRequest } from 'huawei-partner-ai-ui';

// 添加到业务方自己的 adapter；仅当实际接口支持追加时提供此方法。
// 不要将下面的端口委托给 stream(query, signal) 从头再答。
const continueStream: NonNullable<AgreementAssistantAdapter['continueStream']> =
  (request: AssistantContinuationRequest, signal: AbortSignal) => {
    // request.query: 原问题；content: 已保留正文；parts: 已保留结构化内容；context: 原提交模式。
    // 返回 AsyncIterable<AssistantDelta>，只包含新增 text / part。
    // 真实服务的续写token、会话构造、权限和传输由消费方提供。
    return businessContinuationTransport(request, signal);
  };
```

上面的 `businessContinuationTransport` 是消费方实际实现的占位名，不是本包导出。必须响应 `AbortSignal`；UI也通过代次检查拒绝旧请求的迟到数据。本工程未连接真实模型、续写API或付费调用，仅 demo 的「部分失败 / mock续写」提供本地追加计时流。

直接消费 `ChatPanel` 时，继续保留原 `messages / processing / error / aborted` props及`retry / event`事件。新增可选 `continuationAvailable`（默认false），部分失败/停止才显示继续；处理 `event.name === 'chat:continue'` 的消息index，并自行更新同一消息。`chat:regenerate(index)`表示从头回答；最新失败的重试仍发出原 `retry`。`UIMessage.replyError?` 与 `state.completion: 'error'` 将失败归属到具体消息；恢复时清除旧错误、将completion置undefined并设 `recovering:true`，结束后清除recovering并记录completed/error/aborted。旧的全局error只回退到最后一条回答，业务方也须清除它以避免旧错误遮住恢复态。

消息外壳继续使用TinyRobot公开Box；图标动作继续用ActionButton。0.5.1没有文字ActionButton API，单个原生「继续生成」按钮是这一缺口的局部适配，升级时应复核。错误原因应由adapter提供真实、可理解的文案；不要抛原始堆栈作为用户提示。

本轮只交付源码预览。`node scripts/verify-recovery-source-consumer.mjs`检查独立源码消费及公共模块闭包，复用锁定依赖，不构建/打包/安装，不能替代正式产物消费门禁。

## REQ-020 结构化智慧回复（工作区增量）

公共入口新增`AiSummaryCard`；`AssistantPart`接受`{type:'ai-summary',text:string}`，由adapter返回`{kind:'part',part}`。新流的有序uiParts和明确content数组保留文字/卡片顺序；未标记的字符串旧历史合并content/uiParts后仍稳定前置ai-summary，不复制正文。内置业务renderer在原AnswerBox内容slot中展示，仍共享一组回复操作。文本以Vue插值展示，不执行HTML或从普通Markdown猜测卡片。

`AgreementAssistantPanel`新增可选`contentRenderers?: BubbleContentRendererMatch[]`，默认空；沿用TinyRobot公开类型和priority规则（数值小的优先），内置业务匹配priority为-10。消费方可为ai-summary配置-20的renderer，在其中组合`AiSummaryCard`的`text`、可选`logo: string | Component`和`tags`插槽。直接使用卡片时将其放入`.partner-ai`主题作用域，并按原合同引入产品公开样式。保留原面板、不提供该参数的消费方式。

logo默认使用根TinyRobot svgs0.3.5的公开`IconSparkles`作为独立SVG alpha mask，正常强度复用发送渐变；实例useId避免mask冲突，正式logo由宿主提供；renderer组件和logo配置属于运行时UI配置，不进入历史消息。Demo首页三入口的精确问题定义在`src/data/welcomeExamples.ts`，分别返回智慧卡片优先/短正文随后、正确H0～H3语义树纯文本、正文+协议业务表格、金额公式与辅助说明；不按任意子串匹配。2026-10-26已移除Demo专用WorkbenchTag渲染器：摘要不再显示“本地示例”标签，协议状态默认显示普通文本；直接使用产品内置AgreementRenderer，保留详情等业务操作事件。`AgreementTable.status`仍为内容插槽，不代表业务可以自由修改基础视觉。示例问题不是产品策略或后端状态。

`agreement-table`可选`calculation:{formula:string,note:string}`由消费方提供可序列化展示文本，不执行代码。表格复用原组件与.table-wrap滚动区，8px仅裁切内层table-clip，外层保留阴影空间；formula/note位于表格后操作区前。Demo比例和金额仅为虚构测算，不是业务政策。

本轮不修改Workbench兄弟工程依赖、不生成兼容包或tarball。`node scripts/verify-summary-source-consumer.mjs`只验证复制的公共源码闭包、Vue3.5.13类型消费与demo依赖排除，复用磁盘锁定依赖；不能替代正式交付时的构建产物、干净安装和独立包消费验收。

本候选提供可迁入的 Vue 源码与独立本地消费包。公司构建链和宿主加载协议尚未验证。

0.3.0新增可选stream第三参数`ComposerRequestContext`、modeOptions/welcomeEntries配置、composerChange/welcomeAction事件、默认欢迎态与newConversation/reset。最新接口、AI token覆盖和公司目录映射以DELIVERY.md、AI_TOKENS.md及交付薄适配示例为准。模式下拉为自包含body Teleport，并复制当前实例AI语义token；旧消费方业务Dialog仍保留全页top layer；REQ-022可选区域适配见[HOST_LAYOUT.md](HOST_LAYOUT.md)。不会把demo、Studio变量或真实模型权限混进公共UI。

## 可迁入代码

- `src/index.ts` 导出 AgreementAssistantPanel、AgreementTable、ChatPanel 及接口类型；`src/business/` 是协议领域组件与消息 renderer，`src/ui/` 是公共聊天/Dialog 封装。
- 消费方实现 `AgreementAssistantAdapter.stream(query, signal)`，返回 AsyncIterable<AssistantDelta>。可以将消费方实际流式传输转成 text/part；不要把 mockAdapter、fixtures 或 Preview Studio 带入公司产品包。
- 操作实现 `updateAgreement(id, {owner}, {signal, idempotencyKey})` 与 `renewAgreement(id, context)`，返回消费方校验后的完整 Agreement。前端仅保护当前实例重复提交；服务端必须验证权限并实现幂等，不应依赖前端禁用按钮实现全局一致性。
- kit 0.4.0 在 useAgreementAssistant 中桥接为实际 ChatCompletion delta。必须持续响应 AbortSignal，否则第三方 abortRequest 可能等待传输结束。保留本地 UI parts 在消息展示中，通过字段白名单只把 role/content 交给传输 bridge。
- 按适配契约返回统一错误或抛 Error。失败保留当前编辑/确认上下文，重试继续使用同一 idempotencyKey。页面卸载时请求和操作 signal 会取消。
- 基础 CSS 通过 TinyRobot 原包引入；候选 CSS 位于自己的 .partner-ai 根节点。TrThemeProvider targetElement 指向实例唯一 ID。旧消费方Drawer/确认框保留原生全页modal；可选BusinessOverlayHost提供区域portal与局部inert，明确全局确认使用scope=global，详见[HOST_LAYOUT.md](HOST_LAYOUT.md)。
- 固定 Vue 3.5.13 / robot 0.5.1 / kit 0.4.0 / 根 svgs 0.3.5。robot 自身另依赖 svgs 0.5.1，正常保留。宿主已有 Vue 时，应确保同一运行时实例；原 Workbench 的 @workbench/ui-vue3 精确 Vue 3.5.42 包不能直接装入此基线。

## 公开消费路径与实例边界（本次独立盘点）

### 业务团队提供自己的卡片

通用业务使用公开`ChatPanel.renderers`，由自己的控制器提供消息和流式状态；`UIMessage`支持可序列化内容项，renderer消费TinyRobot公开的`BubbleContentRendererMatch`类型并处理业务事件。卡片组件、网络与路由留在业务应用，不导入本工程demo、不把Vue组件或回调持久化，也不要求扩展本工程协议专用的`AssistantPart` union。

现有协议应用可通过`AgreementAssistantPanel.contentRenderers`传入同类匹配，组合自己的卡片；数值更小的priority优先于内置-10匹配。该面板仍要求`AgreementAssistantAdapter`的stream/updateAgreement/renewAgreement，continueStream可选；它不是任意业务的通用会话控制器。`AgreementTable`公开合同保留，Demo虚构数据和Workbench状态标签不进入产品包。本轮不抽取控制器、不新增导出或平台注册字段。

### 既有接入合同

- `ChatPanel` 是呈现组件：消费方管理消息、processing/error、send/abort/retry/event；它不创建业务 adapter。需包裹 `.partner-ai` 并提供有限高度。
- `AgreementAssistantPanel` 组合真实 `ChatPanel`、会话控制器与 `AgreementAssistantAdapter`。`adapter` 在实例初始化时捕获，传输能力变化时由宿主安排安全卸载/重挂载；不要假设运行中替换 prop 会切换旧控制器。挂载期间关闭侧栏仍保留请求，真正卸载才取消。
- `AssistantHostLayout` 是可选宿主，负责同一已挂载面板的侧栏/浮窗尺寸、移动和关闭 inert，不提供业务 transport 或全屏模式。完整组合示例见 [HOST_LAYOUT.md](HOST_LAYOUT.md)。
- JS 从包根导入，产品 CSS 单独导入 `huawei-partner-ai-ui/styles.css`。库构建 external 现有 Vue/TinyRobot 入口；版本与 dependencies 保持锁文件现状。TinyRobot 官方基础 CSS 仍可能包含全局规则，本轮未改第三方 CSS，也未承诺符合公司 scoped CSS 门禁。
- 同一 Vue app 的多个面板使用 Vue `useId` 区分 DOM ID；同一文档若有多个 `createApp`，宿主应在 mount 前为每个 app 配置不同 `app.config.idPrefix`，并确认只加载同一 Vue runtime。各持久化面板应显式给出不同 `historyOptions.namespace` 或独立 storage；默认 namespace 相同会指向同一历史，不应当作独立存储隔离。
- 总览 `defaultExamples.ts` 的15个默认实例与代码文本取自同一组 `examples/*Example.vue`，只转换导入路径。10份走公开包入口（含独立智慧页签）；Sender、消息、追问、输入建议、历史5份含内部 UI 源码导入，页面明确标为“源码集成示例”。完整高级场景是另一组验证用例，不代表这些局部片段可从 npm 子路径导入。

模块级可变容器仅用于 Tooltip 元素/协调作用域、按文档的滚动锁/退场动画和按容器的区域退场，使用 WeakMap；消息、adapter请求、业务幂等与宿主坐标在实例内部。这里是源码盘点结论，真实平台卸载、跨文档/多个Vue runtime、第三方样式隔离和真实接口仍待内部团队验收。

### 按职责定位源码

`src/ui/` 分为 `foundation/`（Token、图标、提示、滚动、Dialog及基础工具）、`panel/`（面板与欢迎）、`messages/`（气泡、状态、追问及消息解析）、`composer/`（输入、模式与推荐）、`history/`（历史呈现与契约）。这是本项目消费层职责分组；借鉴TinyRobot按组件封装与统一入口的方式，不代表上游源码目录。业务组合和控制器仍在 `src/business/`，宿主适配在 `src/host/`，业务端口在 `src/adapters/`；demo/preview/Studio不进入产品闭包。`src/ui/clientId.ts`与`src/ui/globalDialogMotion.ts`仅为检视工具和只读demo vendor保留内部兼容转发，不是包出口。

总览 `/overview.html?page=prompts`、`/overview.html?page=suggestion-pills` 分别展示消息追问与单条/集合输入建议，保留完整场景入口。局部示例与ChatPanel复用内部 `MessagePrompts`、`ComposerSuggestions` 和 `fillComposerSuggestion`；追问直接发送且保留草稿，Pills只追加填入并聚焦，欢迎态不显示Pills。组件包仍通过公开 `ChatPanel / AgreementAssistantPanel` 的 `messagePrompts / suggestionPills` 配置消费，不新增独立组件API或npm深路径导出。源码目录迁移不改变包根和 `styles.css` 契约。

## 平台注册与内部组件

`src/index.ts` 导出组件只表明本地可消费入口，不代表它们均应注册为平台卡片。是否将完整 AgreementAssistantPanel 注册为独立平台组件，由实际宿主设计决定；ChatPanel、AgreementTable、renderer、dialog 通常属于内部 UI 子组件。

按当前用户给定的边界，正式卡片入口是 **manifest + entry 描述对象**，`module` / `panel` 可选；JSON 文件名示例为 `my-card.json`。这只确认入口形态，不确认字段、扫描/生成过程或 loader API。旧的 `index.json` 扫描及 `manifest.json.component` 写入说法不再作为接入依据。项目暂不生成该 JSON 或可部署 manifest；取得正式样例与 schema 后，再由平台团队建立并验证适配。

## 公司接入必须确认

1. TurboUI 7.1.0 与 Starling pc-runtime 7.1.7 的实际依赖、Vue/runtime 兼容范围和正式构建命令。
2. 正式 manifest + entry 描述对象样例（例如 `my-card.json`）及 schema；确认可选 `module` / `panel` 的含义、实际字段、资源/CSS、props/events 与 loader 约定，不预设 component 数组或扫描生成规则。
3. 宿主按模块还是全局对象加载组件，Vue 是否 external/shared，生命周期、卸载、路由和离页保存约定。
4. 查询和流式协议、错误/重试/取消、鉴权/授权/审计、操作幂等与服务端数据校验。
5. 宿主布局高度、主题/字体作用域、dialog 或 Teleport 容器、z-index、焦点管理和浏览器支持矩阵。
6. 由内网工程维护者执行真实生产构建、manifest 校验、宿主浏览器测试与人工视觉确认。

本轮没有公司凭据、真实数据、内网 URL、私有工具模拟或真实业务操作。内部生产验收待以上定义和网络环境就绪后进行。

0.2.0 的网站导航、R2 公司信息页面和悬浮组属于演示宿主；2026-10-20用户指定的机器人头像已有公共资产副本，随 AI 面板默认交付，保留`avatarSrc`覆盖，见[SOURCES.md](SOURCES.md)。公司接入消费 AI 面板及所需子组件。入口与宿主滚动由消费方提供；可选宿主布局模块见[HOST_LAYOUT.md](HOST_LAYOUT.md)，保持组件挂载以保留状态。


侧栏布局候选新增 `ChatToolbarAction` 类型、`avatarSrc` / `toolbarActions` props、`toolbar-action` 事件和 `toolbar-end` 插槽。操作按钮只提供本地呈现与事件；真实操作必须由宿主注入。末尾插槽用于宿主关闭入口并保持键盘焦点可达。宿主提供可用高度，三个 `--partner-chat-*-height` CSS 配置覆盖视觉区域/工具栏/底区；当前像素默认值只是候选。未提供`windowMode`时横条仍是`aria-hidden`装饰；受控悬浮／拖动接入见下文。


## REQ-008 受控窗口模式与拖动（本地增量）

`ChatWindowMode = 'sidebar' | 'floating'`由公共入口导出。`ChatPanel`和`AgreementAssistantPanel`有同一接口：

| prop / event | 合同 |
| --- | --- |
| `windowMode?: ChatWindowMode` | 受控展示状态。未提供时沿用agent占位no-op和装饰横条；提供时顶部agent按钮有“切换为悬浮／侧栏模式”的名称与aria-pressed。业务`modeOptions`不受影响。自定义toolbarActions仍保持事件与禁用状态，窗口按钮置于其前。 |
| `window-mode-change(mode)` | 按钮请求下一个模式；消费方更新受控prop并调整宿主布局。快速连续激活时，宿主可按自己的当前模式反转，避免同一渲染批次里的旧prop建议值重复。 |
| `window-drag-start(event: PointerEvent)` | 受控sidebar／floating横条均发出原生pointerdown，转发保持同步，event.currentTarget为可捕获指针的横条元素。宿主同步处理，不能等await后读取currentTarget。组件本身不定位或捕获指针。 |
| `window-drag-keydown(event: KeyboardEvent)` | 受控sidebar／floating横条均发出原生keydown。宿主提供sidebar的Enter／Space脱离及floating方向键／Shift、preventDefault；未处理按键仍走原焦点／Escape流程。 |

宿主必须保持同一个组件挂载，只改变现有包装层布局与位置，不能用按模式v-if/key的双实例实现。悬浮时释放挤压轨道，给包装层明确width/height/left/top，不加modal蒙层。宿主负责pointer capture与up/cancel/lost capture/blur/visibility/关闭/模式/resize/卸载清理、可见区域边界、位置记忆、关闭inert与焦点、动画和reduced-motion。公共组件按窗口模式变化保留本地消息与Sender滚动偏移；视口变大后原偏移超过新最大值时按浏览器可滚动范围限制。

参考`CompanyAssistantHost.vue`和`src/demo/useAssistantWindow.ts`：默认sidebar；顶部按钮首入floating靠右、位置边距12px。REQ-012覆盖旧浮窗尺寸：悬浮默认宽420px（受嵌入工作区上限缩小），REQ-012 v0.2未手调高度基准910px，工作区不足时从底部向上裁剪，保持现有顶部锚定与导航排除，向下取整到CSS整数像素并受固定内容最小值约束；只有侧栏继续按完整宿主视口判420/480。sidebar横条pointerdown先捕获为pending，移动距离超过5 CSS px才脱离；按实际侧栏矩形加完整手势delta定位，保留同一捕获，不跳到默认浮窗位置。拖出来源的窗口位置边界允许贴工作区可见边缘（0px），以免顶／右边12px强制留白造成阈值时跳跃；宽度仍保留12px安全边距；高度最大不越过可见工作区，整个窗口始终clamp在可见区域。480px侧栏变420px浮窗时按抓取横向比例补偿坐标，中心grip在同次capture中跟随指针。只有这次有意脱离跳过mode watcher的清理，外部模式按钮、关闭和尺寸变化照常结束捕获；pointerup/cancel/lost capture及左键mouseup备用处理清理pending和active。sidebar的Enter／Space作为键盘脱离方式，floating方向键10px／Shift40px；移动触摸仅顶部横条禁原生pan（REQ-012的底部拉伸热区单独处理高度）。关闭后保持最后模式／位置，重开恢复；消息、草稿、AI开关、业务模式与请求实例没有重建。状态仅存在当前宿主挂载期间，不提供持久化。业务dialog继续沿用既有协议，与无蒙层的浮窗模式独立。

参考宿主包装层保留独立的底部高度separator，当前8px透明热区与顶部移动条分开，不提供横向拉伸。pointer只修改高度并固定顶部／宽度；上下方向键10px、Shift40px，Home最小、End当前顶部到可见底部的最大值。与移动共用单一capture生命周期；Escape取消当前抓取、保留已调整值，up/cancel/lost capture/左键mouseup/blur/隐藏/关闭/模式/有效工作区变化/卸载清理。空闲Escape仍沿用关闭行为。

工作区是`.company-demo-workspace`实际矩形与宿主本地visualViewport的交集：位于业务导航下方，在Studio里还受iframe可用高度限制，排除Studio工具区及业务导航，不取整页innerHeight。顶部／底部固定尺寸取现有slot内容类的计算高度，最小浮窗仍=移动区+工具栏+现有footer（包含Pills）+24px中间区+16px既有安全余量，实际随固定slot与Sender最小可用高度测量。正常布局仍固定头部／底部、仅main滚动，底边热区为不占布局的8px透明覆盖层，位于footer底部padding，两端各避让24px圆角，不显示横条，不拦截Sender、免责声明和Pills；移除旧16px占位后这部分空间由面板内容使用，保留原最小/最大高度。工作区不足时优先完整可见：垂直12px留白按可用高度递减至0，窗口尺寸以实际边界clamp；内层滚动呈现完整固定内容，底部separator保持可见。低于8px时热区也缩到剩余高度；零面积无法提供可见控制，宿主应提供非零可操作区域。

首次悬浮及尚未手调时使用910px偏好；实际最大值为当前顶部以下空间（按钮首入保留上下12px安全距），不足只临时裁剪底部，空间恢复后回910px。resize不按所需高度反推上移顶部，已移动窗口的顶部锚点保持，只有极小工作区无法从原锚点呈现移动／拉伸控制时才限制到可见边界。手调后本次宿主挂载会话记住像素偏好，模式切换／关闭重开保持；临时缩小仅clamp显示值，恢复空间时恢复偏好。不使用localStorage、不按模式重建panel，原消息、草稿、滚动、AI开关和流式请求仍由同一组件保留。公共`src/index.ts`／props／events／tokens合同未新增；消费方负责业务可用区域、宿主定位与高度拉伸入口、capture取消和会话记忆。REQ-022已将该host hook作为可选消费模块导出；旧面板消费不会自动获得宿主策略，须按[HOST_LAYOUT.md](HOST_LAYOUT.md)接入。

REQ-012 v0.2参考宿主以模式私有token选择单层aside阴影：sidebar `0 0 48px 0 rgba(0,0,0,.16)`；floating `0 8px 48px 0 rgba(0,0,0,.16)`，不改offset、不在内层panel叠加。workspace overflow visible让左侧阴影画到业务区，host根overflow hidden仍限定嵌入边界，导航z30在窗口z25之上；阴影无独立命中节点，页面不新增横向滚动。公共ChatPanel顶部grip本地CSS默认34×4、hover/focus-visible40×8，维持居中24px命中区；复用Workbench图标150ms动效token与产品160ms fallback、ease-out，reduced-motion无transition。无新增公开API或样式消费作用域。

TinyRobot0.5.1 `TrLayout`的floating公开API会Teleport到body、按视口clamp且附带独立aria-hidden拖动条，不能满足此嵌入工作区／既有横条键盘合同。参考宿主继续使用normal Layout公开slots和ActionButton；只做最小几何适配，不新增基础组件。升级时复核官方API及ChatPanel中Sender滚动DOM适配。REQ-022将该hook迁入src/host/useAssistantWindow.ts并导出，demo路径仅兼容转发；现有宿主也可选择直接使用新的AssistantHostLayout，详见[HOST_LAYOUT.md](HOST_LAYOUT.md)。

REQ-008此前的本地验证曾更新dist-lib，不生成tarball或覆盖既有交付ZIP；REQ-012本轮只更新源码并做定向检查，未构建dist-lib。独立消费验证脚本为`node scripts/verify-window-consumer.mjs`，复制dist-lib/public exports至临时应用，复用磁盘锁定依赖，验证声明、构建、受控模式／拖动事件、旧消费方不传prop兼容和产品边界；不等同于干净安装或公司内网验收。


REQ-022 增量：公开可选宿主布局、业务区弹层、显式业务事件接管和工作区导航事件；前文“仅demo提供宿主hook”的历史描述由[HOST_LAYOUT.md](HOST_LAYOUT.md)取代。既有0.3.0包未重建。

统一语义图标支持内网应用局部替换与默认回退：见 [图标接入文档](ICONS.md)。公开入口提供 `AiIconProvider` / `AiIcon`，`ChatPanel` / `AgreementAssistantPanel` 支持 `icons`；规范总览示例 `/overview.html#icon-integration`。


## REQ-027 v0.5：业务呈现范围

当前demo仅组合本项目BusinessNavigationCard导航呈现、AgreementTable协议字段表和智慧组件，不是完备业务卡标准。无实际场景的操作类协议卡及其内置part/公开出口已退役；通用UIMessage/resolveChatContent、自定义BubbleContentRendererMatch、业务open/renew契约保持。协议表的详情动作、跳转卡、智慧卡与原消息操作栏保留。旧历史不被删除，外部自定义渲染器仍可处理自有序列化part。正式业务卡型应由实际场景和内部批准组件定义。


## 思考展示与 Loading 资源

`ChatPanel` 在显示副本中将原生 `reasoning_content`、旧历史 `collapsible-text` 和本地思考扩展归一为一个 `thinking-content` 内容块，并移除副本中的原生字段，避免 TinyRobot 0.5.1 默认 Reasoning renderer 再次包裹正文。保存的消息和正常业务卡片保留。完成、停止和失败以每条消息的终态为准；历史中不能继续的进行态按中断显示。

`AnswerBox` 持续持有每条消息的同一个 `ThinkingContent`，从等待阶段到思考正文及最终回答不重挂载标题动画。归一后的思考项仅交给 Box，普通内容仍走 TinyRobot/业务 renderer，避免重复展示。思考中灰卡含 padding 最大204px，完成立即折叠，手动展开不限高；中断不显示完成。

默认32px透明动效复用用户提供的小灵SVG轨迹与无依赖RAF控制器，来源见 `src/ui/messages/motion/SOURCE.md`。`status` 管正文，`motionStatus` 管动画：思考结束后最终答复继续分片展示；普通文本 renderer 提交当前版本并经过绘制确认、且回复成功终止后，动画才在下一十字姿态收尾。中断清除待确认回调并立即停住；完成历史首次挂载静态，不重播。TinyRobot0.5.1当前没有独立打字队列；未来替换为有队列的文本renderer时，必须在其 drain 回报后确认，不能仅依赖服务端结束。

`motionAsset` 仍兼容普通图片/SVG URL，其内部播放行为由图片资产负责；默认脚本动效由内联组件管理，无Lottie依赖。公开面板没有新增动画prop/slot；本地演示文字不代表模型内部思维。
