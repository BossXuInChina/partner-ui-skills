# 产品开发从哪里接入（2026-10-30）

常规交接只需发送本次 `huawei-partner-ai-ui-components-0.3.0/` 文件夹或对应 ZIP。组件包已包含安装用 tarball、运行时、类型、完整产品源码、示例、接入文档与备选 `source-modules/`；产品开发不需要另外接收完整 Vue 预览工程。

推荐安装组件 tarball，按需导入公开组件。需要把实现合入既有代码仓库时，使用备选源码模块。两种方式共享同一份产品源码与视觉规范，选择一种作为相同组件的实现来源。

## 交付包里的目录分别做什么

| 内容 | 开发如何使用 |
| --- | --- |
| `huawei-partner-ai-ui-0.3.0.tgz` | **推荐接入物**。在真实业务工程安装，按组件名导入，统一引入库样式。 |
| `huawei-partner-ai-ui-components-0.3.0/` | tarball、编译产物、类型、产品源码、同源示例与交接文档集合；不是要求整体复制到业务工程的应用。 |
| 组件目录中的 `source/` | 完整产品依赖闭包，可重建、审查或整体源码合并；不含演示页面、虚构业务数据和 mock。 |
| `huawei-partner-ai-ui-vue-scaffold-0.3.0/` | 查看效果和调试的 Vue3 工程，含 Studio、Demo、mock 与构建预览。业务开发不需要把该工程整体合入产品。 |
| 组件目录内的 `source-modules/` / 外层同名 ZIP | **备选源码合并方案**。按功能提取实现及真实依赖，输出到新暂存目录，再由产品团队做文件差量合并。 |
| `company-card-example/` | 公司卡片薄适配参考；正式平台注册 schema 与内网构建仍需内部确认。 |

## A. 安装组件包，按需使用（推荐）

在产品现有工程中安装实际交付 tarball。路径根据解压位置调整，例如：

```sh
yarn add file:../delivery/huawei-partner-ai-ui-0.3.0.tgz
# 使用 pnpm 的消费工程：
# pnpm add ../delivery/huawei-partner-ai-ui-0.3.0.tgz
```

沿用公司的 workspace、锁文件和构建入口。交付版本继续为0.3.0，更新时核对日期目录、源码快照与 tarball 的 SHA-256，不能仅凭版本号认定已更新。

在应用入口引入一次 `huawei-partner-ai-ui/styles.css`，组件按名从 `huawei-partner-ai-ui` 导入。运行时仍需要匹配的 Vue 3.5.13 与锁定 TinyRobot 依赖；内部构建须保证 Vue 单实例、能处理 ES module/CSS/图片，具体见 HANDOFF、FONTS 与 HOST_LAYOUT。字体家族由宿主提供，AI UI字阶和基础视觉保持。

| 业务需要 | 选用入口 | 产品开发负责 |
| --- | --- | --- |
| 已有会话控制器，接入通用 AI 对话界面 | `ChatPanel` | 消息、请求/流式、取消、历史与存储、业务卡 renderer、权限和路由。 |
| 协议查询/修改/续签场景 | `AgreementAssistantPanel` | 按 `AgreementAssistantAdapter` 接入真实服务与操作；这是协议业务组合。 |
| 只需要某类展示组件 | `AiSummaryCard`、`WorkspaceSmartCard/Tag/Icon/Tabs`、`AgreementTable`、`BusinessNavigationCard`、`AiAlert`、`AiToast` 等公开入口 | 提供数据、事件处理与可用尺寸；无需挂整套会话面板。 |
| 页面需要侧栏/浮窗及区域弹层 | `AssistantHostLayout` / `BusinessOverlayHost` 等可选宿主适配 | 接入实际工作区、业务布局、焦点、弹层和状态归属。 |

一个通用面板包装示例（实际请求交给产品控制器）：

```vue
<script setup lang="ts">
import { ChatPanel, type UIMessage, type ChatDisplayStopSnapshot } from 'huawei-partner-ai-ui';
const props = defineProps<{ messages:UIMessage[]; processing:boolean; aborted:boolean; error:string }>();
const emit = defineEmits<{ send:[query:string]; abort:[snapshot?:ChatDisplayStopSnapshot] }>();
</script>
<template>
  <section class="partner-ai" style="height:700px;min-height:0">
    <ChatPanel v-bind="props" @send="emit('send',$event)" @abort="emit('abort',$event)" />
  </section>
</template>
```

`abort` 的可选快照需要消息所有者持久化，再取消传输；这样停止后的历史不会补回尚未显示的内容。直接使用 `ChatPanel` 时，包装容器须带 `.partner-ai` 样式作用域（如上例）；协议组合已自带该作用域。宿主可用高度必须明确，不宜在高度为0或无约束的容器中挂面板。真实业务 API、鉴权、流式协议与公司平台注册不会由安装包自动完成。

标准组件包的对外出口仍只有包根和 `styles.css`。Sender、消息壳、历史局部菜单等内部组件不提供 npm 深层导入合同；普通业务优先通过公开面板的 props、事件、slots 和业务 renderer 使用。总览中的源码片段不是新的 npm 公开出口。

## B. 按源码模块合并（备选）

适合内部不能直接消费该 tarball、已有同类控制器需要替换呈现层，或必须做源码级审核和合并的团队。采用源码后，接收团队负责维护内部 props、状态联动与后续升级；公开包的稳定出口承诺不自动扩展到内部叶子组件。

本次附9个功能模块：

| 模块名 | 包含的主要内容 | 性质 |
| --- | --- | --- |
| `composer` | Sender、模式选择、Pills 与集合 | 内部源码入口 |
| `messages` | 消息壳、思考、追问、点踩卡片 | 内部源码入口 |
| `history` | 历史菜单与更多菜单 | 内部源码入口 |
| `feedback` | Toast 与 AiAlert | 公开组件的源码 |
| `intelligence` | 智慧卡/标签/图标与摘要 | 公开组件的源码 |
| `business-cards` | 协议表格与业务导航卡 | 公开组件的源码 |
| `host` | 宿主布局、区域弹层与相关 hook | 公开宿主适配的源码 |
| `panel` | 通用 ChatPanel 与实际依赖 | 公开面板的源码 |
| `agreement` | 协议助手组合与实际依赖 | 协议业务源码 |

每个选择包含真实依赖，所以选面板时也会包含其输入、消息等依赖。不是只复制一个 `.vue` 文件，也不承诺每个模块不依赖其他实现。共享 Token、CSS、图标、类型和工具保留原路径；同一版合并一次。交付未新增9套独立版本的 npm 包，也未修改现有 SDK 的 exports。

从 `source-modules/` 执行：

```sh
node select-modules.mjs --modules composer,feedback --output ./selected-ai-ui
```

工具只写到**不存在的新目录**；不自动覆盖产品仓库。`selection.json` 列出模块与源码 SHA，`src/` 保留原有相对路径，`entries/` 提供对应源码入口。多个模块通过 selector 合成一次后再合并，可去重共享文件。`ready-modules/` 也提供9个单模块 ZIP，均带依赖；需要多个时优先合成一次。

将暂存区中的 `src/`、需要的 `entries/` 和 `bootstrap.ts` 作为一棵相邻目录树合入产品，再按审核结果调整本地入口。不要用暂存区的 package/tsconfig/锁文件覆盖公司工程；这些配置只用于独立核验。源码中的 `.vue`、TypeScript、CSS、资源导入必须由产品构建器处理。

`bootstrap.ts` 统一加载 TinyRobot 基础样式和 AI 基础样式；应用中只加载一次。源码合并还必须保留一期设置，例如在自己的应用初始化时：

```ts
import { createApp } from 'vue';
import App from './App.vue';
import { installPhaseOne } from './selected-ai-ui/bootstrap';
const app = createApp(App);
installPhaseOne(app);
app.mount('#app');
```

已有宿主不方便修改全局应用时，可在 AI 包装组件 `setup` 中 `provide(phaseOneKey,true)`（key 从同一份 `bootstrap.ts` 导入）。导出暂存区另带 `.env.production` 和示例构建定义，独立构建默认启用一期。把源码移入宿主后要复核配置，防止恢复完整调试入口。字阶、图标和基础视觉仍由 AI UI 维护，源码可编辑不等于允许随意改设计基线。

合并前后分别核对文件差量、依赖、共享 Vue、样式级联与一期入口。涉及面板时验证发送/停止/历史、焦点、滚动与侧栏状态；独立智慧卡或通知则验证其数据、样式和事件。与现有同名文件冲突时由团队评审合并，不盲目覆盖。

## 本次交付验证与内部接入边界

最终产物身份、标准组件消费、备选模块的类型/编译/后台浏览器结果，以外层 `manifest.json`、`verification.json` 与 `evidence/POST_ASSEMBLY.json` 为准。内部 Yarn/Lerna、TurboUI/Starling、平台注册 schema、真实业务 API、其他浏览器与设备仍由接收团队验收。
