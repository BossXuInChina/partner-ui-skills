# 0.3.0 Vue脚手架交付与产品接入

2026-10-26交付更新：本轮已获用户授权，按标准Vue3 + TypeScript + Vite结构组装当前源码、预览及独立组件包。交付标识为`2026-10-26-solid-smart-0.3.0`，实际产物与验证以该目录的manifest/verification为准；下文更早日期的“不打包”描述仅属历史记录。产品配置权限以交接页及COMPONENTS配置清单为准，公司私有平台注册与内网构建仍待接入验证。

当前接收方导航、真实目录、能力状态与内部验收以[HANDOFF.md](HANDOFF.md)为入口，职责与完整公开清单见[COMPONENTS.md](COMPONENTS.md)。2026-10-20历史轮次仅统一分类和说明；当前package沿用0.3.0，以日期交付标识和散列区分。2026-10-15的REQ-027 v0.8及后续r3属于历史本地交付，旧包保持原样，以各自日期目录、源码与构建SHA识别，不能代表当前源码。下文任务条目的打包/提交状态仅适用于当时轮次。变更见[CHANGELOG](CHANGELOG.md)。

这是本地评审源码，未公网发布。正式交付时 verification.json / manifest.json 记录当次源码与构建散列；只有提供已核对的提交时才记录 localCommit。TinyRobot官方源码、node_modules、patch-package均未修改。TurboUI7.1.0、Starling cli-utils1.7.9 / pc-runtime7.1.7内网构建、平台注册schema与真实业务API未验证；不伪造可运行内网manifest。见[INTEGRATION.md](INTEGRATION.md)及交付内的公司卡片适配说明。

## 交付内容与启动

- **组件接入包**：标准npm tarball、选定产品可读源码、锁文件、重建配置、文档、公司卡片薄适配示例。产品tarball仅含dist-lib、README/docs/package.json与TINYROBOT-LICENSE.txt；不含Studio、demo、mock、虚构数据、collaboration、.artifacts、node_modules、用户截图或凭据。
- **Vue脚手架包**：标准Vue3 + TypeScript + Vite目录，包含相同版本的dist构建资产、完整可读原型源码、R2业务示例、mock、Studio、锁文件与说明。无node_modules、.artifacts、collaboration、Git、私人截图/凭据。示例源资产来自本工程选定Workbench依赖闭包，来源与许可见[SOURCES.md](SOURCES.md)。

最终版本、文件清单、验证记录与SHA-256见交付目录manifest.json、verification.json、SHA256SUMS；不会交付中间失败包。用户参考截图只用于本地修正，不加入包。

原型包解压后（Node≥22.12.0）：

```sh
node preview.mjs
# http://127.0.0.1:4180/，端口占用时：node preview.mjs --port 4181
# 仅在需要同可信局域网预览时显式开启：
node preview.mjs --lan
# 或 node preview.mjs --lan --port 4181
```

默认仅绑定 127.0.0.1；`--lan` 才绑定 0.0.0.0，并打印本机有效 IPv4 地址与端口。开启后，同可信 LAN 内能连接此端口的人可以查看构建预览（无登录认证）；Ctrl+C 停止。仅提供 dist 静态资产（含构建时复制的 docs 文档），不提供源码、目录列表或上传/API，拒绝越界路径及指向根外的符号链接。不自动开启分享、不修改防火墙或网络安全设置。本次实际监听及本机网卡IP访问结果见交付外层evidence/POST_ASSEMBLY.json；从本机访问网卡IP不等同另一台设备访问，真实跨设备可达性仍未验证。

需要HTTP，不承诺file://。主页点业务区域右下角机器人，默认欢迎态；点入口卡或输入后开始会话。AI问答默认关闭，走本地业务模拟；激活才走本地AI问答模拟与思考文案。标准/简洁为demo传入的示例选项，不是正式产品策略。新建取消旧流并回欢迎态；历史会话已在当前源码实现；语音/图片仍为占位，模型与业务 API 未接入。

修改源码需`pnpm install --frozen-lockfile`。原型`pnpm dev`（4178）/`pnpm build`；选定组件源码包`pnpm build:lib`。锁定Node≥22.12.0、pnpm11.19.0，首次安装需要联网或依赖缓存。

产品安装：`pnpm add ./huawei-partner-ai-ui-0.3.0.tgz`，导入`huawei-partner-ai-ui`与`huawei-partner-ai-ui/styles.css`。

```vue
<script setup lang="ts">
import { AgreementAssistantPanel, type AgreementAssistantAdapter,
  type ComposerModeOption, type WelcomeBusinessEntry } from 'huawei-partner-ai-ui'
import 'huawei-partner-ai-ui/styles.css'
const props = defineProps<{ adapter: AgreementAssistantAdapter; avatarSrc: string }>()
// 下面仅展示形状；模式、文案、图标和指令由产品配置。
const modes: ComposerModeOption[] = [{ value:'product-mode', label:'产品模式' }]
const entries: WelcomeBusinessEntry[] = [
  { id:'query', title:'业务标题', description:'业务说明', query:'产品查询指令' }
]
</script>
<template>
  <div style="height:700px">
    <AgreementAssistantPanel :adapter="props.adapter" :avatar-src="props.avatarSrc"
      :mode-options="modes" :welcome-entries="entries" />
  </div>
</template>
```

产品宿主提供实际可用高度及导航下方挤压布局；组件不附带网站导航/开关。CompanyAssistantHost为原型参考：完整同源页面视口<1920px外宽420px，≥1920px外宽480px；左右16px内含外宽。真正受限嵌入只限制到可用宽度。跨域宿主viewport转发未接入。

## 公开接口

入口为src/index.ts（dist-lib/index.js与index.d.ts），样式入口为styles.css。完整导出按[交付职责清单](COMPONENTS.md)区分通用聊天、公开AI呈现、宿主适配与协议领域。ChatPanel由业务控制器管理消息和请求，可通过renderers接入自有业务卡；AgreementAssistantPanel是包含历史/协议操作的领域组合，AgreementTable是公开协议表而非仅Demo资产。ChatComposer、ComposerModeSelect、ChatWelcome、MessagePrompts、ComposerSuggestions、SuggestionCollection等仍为内部产品组件，不额外公开子入口。

| AgreementAssistantPanel props | 说明 |
| --- | --- |
| adapter（必填） | 消费方拥有的流式/操作接口，无内置URL或凭据 |
| theme / avatarSrc | workbench或aurora，默认workbench；默认包内机器人头像；avatarSrc显式URL优先，空字符串为语义图标回退 |
| autoStart | 默认false，欢迎态不自动查询；旧消费方可显式true或调用start() |
| modeOptions | ComposerModeOption[]，默认空时可聚焦no-op；显式disabled或配置全部禁用时不可用 |
| welcomeEntries | WelcomeBusinessEntry[]，默认空；设计配置三张卡，标题/说明各一行，超长省略并保留title提示，不撑破82px |
| suggestionPills | ChatSuggestionPill[]，默认空；支持单条或问题集合，选择后直接发送对应问题并清空输入草稿 |
| messagePrompts | MessagePromptsResolver，可选；按对应成功完成的assistant消息返回追问列表，点击直接发送，保留未发送草稿 |
| toolbarActions | 保留宿主动作；为空时默认模块、新建、历史；只有新建接本地重置 |

| events / exposed | 说明 |
| --- | --- |
| status / toolbarAction | 沿用业务dirty/busy状态及宿主动作透传 |
| composerChange | `{aiEnabled,mode}`真实状态；不会改变当前请求的已捕获上下文 |
| welcomeAction | 配置入口对象。有query时内部发送业务查询，无query时仅通知产品 |
| toolbar-end slot | 宿主关闭入口；demo的焦点/动画由CompanyAssistantHost负责 |
| currentStatus(), discardDraft(), reset(), newConversation(), start() | 原状态API保留；reset/new先取消旧流，再清消息/输入。dirty或业务操作中阻止新建 |

ChatPanel还接收messages/processing/error/aborted/renderers、展示配置与requestContext。新增`send(query, context)`第二参数，旧单参数监听兼容；newConversation事件交由消费方清会话，resetComposer()清本地输入。组件不自行调用业务API。

REQ-005建议配置（已纳入本次源码交付）：ChatPanel与AgreementAssistantPanel均支持上述两类建议配置，`ChatSuggestion`为`{ id:string; label:string; query?:string; disabled?:boolean }`，没有query时使用label；`ChatSuggestionPill = ChatSuggestion | ChatSuggestionCollection`，集合为`{ id, label, items:ChatSuggestion[], disabled? }`。单条或集合中的问题选中后直接发送其query（缺省时使用label），并清空已有输入草稿。集合使用0.5.1公开`TrSuggestionPopover`的manual/show/data/appendTo与trigger/header/body插槽；原生按钮补齐禁用、方向键、Home/End、Escape、Tab、关闭/外点及焦点返回。弹层随宿主移动与视口变化避让，空间不足以放下96px内容时关闭，不覆盖发送区。消息追问直接通过现有send链路发送，保留原草稿，使用当前AI开关和业务模式，生成中及同批重复激活受保护；`MessagePromptsResolver`为`(message:UIMessage)=>ChatSuggestion[]`。它仅针对`message.state.completion === 'completed'`的assistant消息调用。AgreementAssistantPanel通过kit0.4公共onFinally记录每条回复completed/aborted/error；直接使用ChatPanel的宿主须设置这项终态，无状态的旧消息不凭空推断完成。两类配置为空时不保留占位。新建清除消息即清除对应追问；Pills是当前业务入口配置，仍可用于新会话。

有Pills时底区在原`--partner-chat-footer-height`基础值（或默认推导值）之上增加48px，即32px建议行+16px间距；无Pills时既有宿主高度协议不变。输入框保持132px。滚动视口右侧到面板边缘，左侧完整首项保持16px；上下及首末完整项预留阴影空间，移动穿过边界的部分项由视口裁剪。鼠标进入热区只改变滚动条颜色，固定槽位不跳动；触摸滚动和焦点滚入保持，左右/Home/End可滚动热区。生成/重置期间两类建议禁用，输入草稿和AI/模式状态仍保留。示例只在demo，不代表真实模型建议。

```ts
interface ComposerRequestContext { aiEnabled:boolean; mode:string }
interface ComposerModeOption { value:string; label:string; icon?:Component; disabled?:boolean }
interface WelcomeBusinessEntry {
  id:string; title:string; description:string; icon?:Component; query?:string; disabled?:boolean
}
// 可选第三参数向后兼容；取消/幂等由消费方接口承担。
stream(query:string, signal:AbortSignal, context?:ComposerRequestContext): AsyncIterable<AssistantDelta>
```

发送时复制AI/mode，重试和重新生成保留该请求上下文。新建使用AbortSignal与代际保护，拒绝迟到输出/旧重新生成finally污染新会话。mock的AI路径仅添加本地演示回复；未接真实LLM/思考链、麦克风、上传、历史、持久化或真实业务权限。

## 实际TinyRobot定制与升级边界

| 官方能力 | 本地包装/槽与覆盖 |
| --- | --- |
| TrThemeProvider | partner-ai范围内主题，不写html主题 |
| TrLayout(mode=normal) | header/main/footer公开槽；固定头尾与独立滚动 |
| TrBubbleProvider / TrBubbleList | renderer matches/attributes/groupStrategy/content resolver，一条回复共用一个Box；关闭原生 autoScroll，由本地包装跟随底部，向上阅读暂停跟随，新查询恢复；kit角色串仅展示归一化 |
| BubbleRenderers.Box / Markdown | AnswerBox包装唯一原生气泡背景；标题/正文/列表、user48px单行、16px内边距、表格局部横滚、36px反馈区；progressText气泡内进度，无第二卡/双圈 |
| TrSender | ChatComposer包装v-model/loading/submit/cancel、footer/footer-right公开槽；132px高、16px圆角、左右16上下12 padding、32px发送action区 |
| TrSuggestionPills / TrSuggestionPillButton | 公开default槽、item、overflowMode=scroll；本地CSS预留阴影/固定滚动条，原生按钮保持禁用/键盘语义 |
| TrPrompt | 追问沿用公开label/badge VNode；因TrPrompts0.5.1无逐项slot，直接Prompt声明div按钮语义和键盘守卫；局部content/badge布局适配，不影响Welcome |
| SVG包 / 自建组件 | 直接消费官方SVG；自包含单选body Teleport参照Workbench select，无demo运行时依赖；欢迎组件只呈现配置 |

内部CSS选择器依赖集中于styles.css、messageStyles.css、ChatPanel/ChatComposer局部样式：tr-layout__main/body、tr-bubble__body/content/box、tr-sender-main/multi-layout/footer/editor-scroll/content/submit-button、ProseMirror。公开TinyRobot token优先；内部DOM用于固定几何/滚动/焦点，源码注释标明需求与覆盖原因。升级须复查editor exposed API、Box槽、分组/流式回调、portal主题/焦点、内部DOM/CSS优先级和独立包消费。

欢迎红框仅头像/标题/问候语相对面板水平居中，起点122px；avatar48、title32、body16，纵向8/48px及卡82px/16px保持。未给定的icon/文字gap12、标题行高40等为保守候选。

## AI语义token与剩余常量

组件包不含字库、@font-face或字体URL；宿主提供公司批准字体，AI UI仅继承字体家族，字号/字重/行高保持。独立预览可选加载本地HarmonyOS Sans/SC并保留许可，见[FONTS.md](FONTS.md)。统一入口src/ui/foundation/aiTokens.css，token清单、来源和覆盖示例见[AI_TOKENS.md](AI_TOKENS.md)。AI UI 为独立设计规范；颜色、字阶、间距、尺寸、圆角、描边、渐变、阴影和动效由包内 AI Token 声明，引用链不依赖宿主 `--wb-*`。orange-05（#FEF5E8）及既有精确参数保持。panel/message/composer/actions/welcome统一引用；气泡内padding与面板safe inset独立，避免叠加/连带改变。

未机械token化0/100%、flex/grid/居中计算、1px边框/分隔线、2px焦点描边与3pxoutline offset、屏幕阅读器1px裁剪、portal安全8px/层级21000。表格字段最小列宽为原型内容防折行约束；1920/420/480由demo宿主负责，不混入产品注册或Studio token接口。升级/修改时按用途核对，不全局强制取整。

## 依赖与验证范围

Vue3.5.13、TinyRobot0.5.1、kit0.4.0、根svgs0.3.5；保留robot内部svgs0.5.1，锁文件为准。其余直接版本见package.json/pnpm-lock.yaml。没有改官方源码、强行覆盖传递依赖或重装原工程。

本轮最终 lint/typecheck、应用/库构建、完整本地浏览器用例矩阵（含新增流式滚动回归）、独立包消费、HTTP预览与包边界检查，详细结果/数量/耗时见交付 verification.json。冻结锁文件干净安装结果在依赖及锁文件未变范围内复用；不把本地完整矩阵称为跨平台或内网全量验收。已有大chunk提示仍存在。视觉验收、Windows/其它浏览器、内网构建/manifest schema、真实业务API与跨域协议未验证。Studio旧JS选定依赖经编译与相关浏览器检查，不冒充完整TS重写。


REQ-008本地增量（未重打交付ZIP）：`ChatWindowMode`及`windowMode`/`window-mode-change`/`window-drag-start`/`window-drag-keydown`现已作为公共面板消费接口。窗口几何、capture生命周期、关闭焦点和位置记忆由宿主承担，详见INTEGRATION.md；demo宿主实现不进入产品dist-lib。既有tarball/ZIP不包含本次增量；本次禁止打包，独立消费改用临时工程直接消费构建exports，验证范围需与正式打包/干净安装区分。


REQ-022 源码工作区增量：可选AssistantHostLayout、BusinessOverlayHost、useAssistantHostLayout/useAssistantWindow、UiDialog与业务事件接管现已加入公共入口，详见[HOST_LAYOUT.md](HOST_LAYOUT.md)。原包“布局全部由产品实现”的职责说明对旧消费保持适用；新产品可选用本地宿主适配模块，导航/业务页面/API仍由产品提供。普通业务弹层在配置provider后限定业务作业区，明确全局确认保留top layer语义。未改公司页面WorkbenchModal，不宣称任意内网宿主已兼容。该增量已纳入2026-10-26交付，旧日期ZIP/tarball不含此增量。


2026-10-14 本地阶段收尾：今日可归属源码/测试/文档与统一语义图标接入合并为本地阶段提交，保留旧需求待视觉验收状态；内网资源由消费方通过Provider/面板icons导入，见[ICONS.md](ICONS.md)、[本轮定向验收](ICON_VALIDATION.md)。已执行最终应用/库构建与无打包独立消费，本次不更新旧交付ZIP/tarball、不push、不发布。上述历史条目的“未提交/未构建”描述保留为其当时任务结果，不代表本次阶段收尾状态。


当前Workbench演示资产非公司内部正式/批准源码，正式接入须由内部团队替换批准组件与资产。REQ-027 v0.5已退役无场景操作类协议卡；上述为当前源码出口；本次按2026-10-26快照重新构建，历史日期交付包保持原样。


一期交付包默认隐藏 Sender 的 AI 开关、模式、语音和图片入口，以及顶部全屏、回复收藏和历史置顶入口；本地预览继续保留这些控件。全屏、收藏和置顶等源码能力保留，隐藏入口不禁止宿主通过既有接口控制全屏。回复停止后保留已显示内容并隐藏该条回复的操作区。


Agent 回复核心数据（2026-10-27）：业务自定义 renderer 在回复内容中显式使用 `<span class="agent-core-data">3 份协议</span>`，颜色为 `--partner-ai-agent-core-data-color`（默认 `#09AA71`），字重 500（Medium），字号继承上下文。样式仅作用于 Agent 消息内容，不自动识别数字或改变普通加粗；普通 Markdown 文本不会自动生成这个 class。
