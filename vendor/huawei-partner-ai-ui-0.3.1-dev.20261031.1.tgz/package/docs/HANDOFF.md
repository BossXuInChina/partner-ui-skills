# 设计开发交接入口

2026-10-29接入说明：优先安装组件 tarball 并按需导入公开组件；备选源码模块用于审核后合并实现。目录用途、两种接入方式与9个模块边界见 [产品开发接入指引](DEVELOPER_START.md)。交付身份以本次外层 manifest / verification 为准，下述早期打包状态只代表当时快照。

2026-10-28工作区说明：本文对照当前 `src/index.ts` 与实现维护；尚未把本轮增量重新组装成交付包。`2026-10-26-solid-smart-0.3.0` 是既有交付快照，版本号同为0.3.0也不能代表当前源码。历史包的内容与验证以各自 manifest / verification 为准，保留原样；公司私有平台注册、内网构建与真实业务API仍待接入验证。

历史说明（2026-10-20）：当时package版本为0.3.0，仅统一分类、公开消费与来源说明。既有同版本包以2026-10-26交付标识和源码散列区分。职责与完整公开清单见[COMPONENTS.md](COMPONENTS.md)，本地目录与新GitHub main的历史衔接也在该文档中说明。

历史交付：2026-10-15已获聊天授权执行正式本地交付，范围包含REQ-027 v0.8，随后交付r3，合入普通HTTP历史/详情兼容与图标高级示例布局。旧包以各自日期目录、源码快照SHA和构建文件SHA识别，不能代表后续源码。实际产物与检查结果以对应交付外层manifest.json、verification.json及evidence/POST_ASSEMBLY.json为准，不代表公司内网验收或最终视觉批准。变更见[CHANGELOG](CHANGELOG.md)。

## 先看效果，再查规范，最后接入

原型目录包含 `preview.mjs`、`dist/`、`overview.html`、`index.html`、`renderer.html`、`src/`、`docs/`、`scripts/`、`tests/`、配置与锁文件、`TINYROBOT-LICENSE.txt`。从原型根执行：

```sh
node preview.mjs
```

打开 <http://127.0.0.1:4180/overview.html>。三个入口分别通向完整业务效果、组件规范和接入验收。Studio 在 `/`，整体业务场景在 `/renderer.html`；组件规范使用 `overview.html?page=组件分类`。所有页面与 iframe 由包内构建资产提供，不使用相邻 Workbench 仓库。端口占用时用 `node preview.mjs --port 4181` 并相应改变 URL。Ctrl+C 停止。默认只绑定本机；可选可信 LAN 参数及边界见 [DELIVERY](DELIVERY.md)。

组件交付不含字库，宿主统一提供公司批准字体；AI UI继承字体家族，字阶固定。接入见[FONTS.md](FONTS.md)。独立预览保留可选字体入口。

Node >=22.12.0。查看构建预览不需要安装；修改源码需要 pnpm 11.19.0。从原型根执行 `pnpm install --frozen-lockfile`、`pnpm dev`（4178）；完整重建用 `pnpm build`。网页文档由构建复制到 `dist/docs/`，文件阅读使用 `docs/`。不承诺 file:// 运行。

## 组件包从哪里开始

先按[职责清单](COMPONENTS.md)选择公开入口：通用业务使用`ChatPanel`和自己的控制器/业务卡renderer；协议业务可使用`AgreementAssistantPanel`。后者包含协议传输与操作要求，不是任意业务的通用会话控制器。`AgreementTable`继续作为协议领域组件公开，Demo里的虚构数据不进入产品。下述目录描述既有交付结构，当前增量须重新验证和组装后才进入新产物。

正式组件包根有 `README.md`、`dist-lib/`、`docs/`、`TINYROBOT-LICENSE.txt`、`company-card-example/`、`examples/`、`source/` 和同版 `huawei-partner-ai-ui-0.3.0.tgz`。结构审计模式不含构建产物。

- 消费：从真实消费项目安装 tarball，使用实际相对路径。若消费项目和组件包目录同级，例如 `pnpm add ../huawei-partner-ai-ui-components-0.3.0/huawei-partner-ai-ui-0.3.0.tgz`。包根导入组件，单独导入 `huawei-partner-ai-ui/styles.css`。
- 源码：先进入组件包 `source/`，执行 `pnpm install --frozen-lockfile`、`pnpm typecheck`、`pnpm lint`、`pnpm build:lib`。入口 `source/src/index.ts`，重建输出 `source/dist-lib/`，可自行比较组件包根的已验收 `dist-lib/`。不要从组件包根执行源码重建命令。
- 公共源码按 `src/index.ts` 的完整本地依赖闭包导出。包含 host、业务呈现、样式与类型；禁止 demo、preview、vendor、data、mockAdapter、Studio、collaboration 进入产品闭包。
- npm 内容维持明确允许清单：`dist-lib/`、`docs/`、`README.md`、`package.json`、`TINYROBOT-LICENSE.txt`。包含用户指定的产品默认机器人头像；其余原型品牌图片和演示 vendor不携带，资源来源与覆盖方式见[SOURCES.md](SOURCES.md)。

总览15份默认实例与代码直接来自 `src/preview/overview/examples/` 的同一 Vue 文件，展示时仅转换导入路径。默认示例按页面语义展示独立组件或真实消息片段；面板/欢迎使用完整面板。“在完整场景中查看”按需打开同页本地场景，返回保留原示例状态。

其中10份只使用公开包入口（含摘要、导航卡与智慧页签）；Sender、消息、追问、输入建议、历史5份局部片段直接复用内部源码组件，并在页面明确标注“源码集成示例”。将这类片段保存到组件交付目录的 `examples/SenderExample.vue` 等位置时，`../source/src/ui/` 指向同包真实源码；这不是 npm 子路径导出，也不要求把 preview 导入产品闭包。只安装 tarball 的消费方应使用公开 `ChatPanel` / `AgreementAssistantPanel`，接入页保留完整公开面板及同源代码。组件包不包含 preview 目录，真实业务 adapter 与数据由接收方提供；历史示例仅内存，交互输出明确标为演示反馈。图标高级验证、显式 mock 续写和异常控件仍是可选验证工具。

本地默认演示保留全屏、收藏和历史置顶等能力；一期交付使用既有构建标志或Studio预览provider隐藏对应入口，未删除实现。完整演示的入口可见性不能代替一期交付验收。

独立 `ChatPanel` 接入须处理可选的 `abort(snapshot?: ChatDisplayStopSnapshot)` 载荷：`messageId?`、`messageIndex`、`parts` 保存完整思考与已展示源内容。宿主校验回答身份后持久化快照和停止状态，再取消传输，保证重新挂载/恢复历史后不补回未展示内容；旧无参处理器仍兼容。`AgreementAssistantPanel` 已在自身消息所有者中接线。停止入口覆盖传输与内容展示两个阶段，生成/展示中及主动停止后不显示完成态回复操作。

## 来源与能力状态

| 范围 | 当前状态 | 正式接入责任 |
| --- | --- | --- |
| TinyRobot 0.5.1 基础 UI | 使用公开组件、属性、插槽、token，必要内部 DOM 适配有升级说明 | 内部团队按 [DELIVERY](DELIVERY.md) 复核升级点 |
| AI 新增呈现、AiAlert、宿主适配、31 个语义图标维护键 | 本地已实现；以公共入口与 [ICONS](ICONS.md)、[AI_ALERT](AI_ALERT.md) 为准 | 消费方提供资源、场景与事件处理 |
| 协议字段表、导航与智慧组合的数据/业务 | 组件呈现已实现；业务数据与流式计时为 mock | 业务方实现数据、路由、权限与幂等 |
| 产品内自包含适配与历史参考 | Tooltip、滚动等保留来源及升级说明，不导入Demo vendor；AI Token默认值包内闭合 | 内部团队确认正式资产与宿主兼容，不把本地参考称公司正式源码 |
| continueStream | 可选续写端口；预览仅显式 mock，旧 adapter 可不实现 | 支持续写的业务方实现追加语义；从头生成不能冒充续写 |
| Loading | 本地XiaolingThinking SVG思考反馈；没有公共面板动效资源prop/slot或loading图标键 | 动效由AI UI维护，不通过内部DOM或CSS注入替换 |
| Workbench Table / Tabs / 业务外壳 / Studio 移植 | 仅 demo，非公司内部正式/批准源码，不进入 AI 产品公开闭包 | 内部团队替换为公司批准的组件与资产 |
| 操作类 AgreementCard | 已移除 | 保留导航、Table、智慧卡与通用消息操作；不接入旧操作卡 |

## 内部接入验收清单

| 负责人 | 需要完成 | 当前未验证范围 |
| --- | --- | --- |
| 设计与接收方 | 审核整体效果、默认/高级状态、来源与文案；确认侧栏 0 / 浮窗 24px、摘要/导航真实对话次序 | 最终视觉审核 |
| 内部工程维护者 | 在既有 Yarn / Lerna workspace 接入，沿用内部锁文件与生产命令；验证 Vue 3.5.13 单运行时、依赖版本及 CSS 作用域 | 内部安装、编译、运行时共享；不以原型 pnpm 配置替代内部工程 |
| 平台团队 | 确认 TurboUI 7.1.0、Starling cli-utils 1.7.9 / pc-runtime 7.1.7；取得 manifest + entry 描述对象的正式样例/schema（JSON例 my-card.json，module/panel可选），校验 loader、props/events、生命周期和资源路径 | 私有依赖、schema、正式平台注册和生产构建；company-card-example 只是参考 |
| 业务团队 | 对接鉴权、权限、AbortSignal、请求上下文、流式/重试/续写、历史存储、修改/续签幂等 | 真实 API、真实数据、持久化与审计 |
| 宿主团队 | 分别验收push/overlay策略与侧栏/悬浮/全屏；切换保留会话、草稿、滚动、执行中请求；验收窄屏、键盘焦点、弹层 document 边界、IME、触屏和 reduced-motion | 跨浏览器、真实辅助技术、跨域宿主和真机 |
| 交付方与接收方 | 正式打包时按当次源码/构建散列完成质量、受影响矩阵、独立消费与包边界验收 | 历史交付的验证仅覆盖对应快照；当前增量需当次质量、受影响矩阵、独立消费及包边界证据，不替代公司内网验收 |

错误原因当前可能直接呈现 adapter 的原始 `Error.message`。正式 adapter 应提供可向用户展示的文案，避免把服务器诊断或敏感信息原样传入；本轮仅记录接入限制，没有扩展错误处理修复。

## 追溯与导出复核

导出规则在原型包 `scripts/assemble-delivery.py`。`--check-structure` 只复制当前源码做临时结构审计，不读取旧 dist、不安装、不创建 ZIP/tarball；显式 `--output` 必须指向不存在的临时目录。正式组装仍要求当次验证证据的 `validatedSourceSha256` 和 `buildOutputsSha256` 与当前源码、应用和库产物一致，旧验证报告不能授权新组装。

结构审计/交付生成 `docs/SOURCE_PROVENANCE.json`，记录包内源文件 SHA、公共闭包及 demo 来源状态；正式交付另有 `verification.json`、`CONTENT-SHA256SUMS` 和外层 manifest/checksums。此源码工作区不预先生成这些交付文件。旧文档中 `.artifacts/`、`collaboration/` 和相邻仓库路径只描述作者工作区的历史来源，不是接收方启动命令或包内文件；接收方以实际清单及包内源文件为准，无需访问作者机器或相邻仓库。
