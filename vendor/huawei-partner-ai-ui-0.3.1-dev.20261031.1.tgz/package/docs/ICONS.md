# 语义图标接入

本文区分**产品开发的业务配置权限**与**AI UI维护者的技术扩展能力**。有slot、prop或Provider不自动代表产品可以改变基础规范；按业务职责决定开放范围。锁定依赖和本地资源保持现状，以下交付权限为2026-10-26讨论形成的建议，尚未执行公共API收窄。

## 产品交付配置边界（2026-10-26澄清）

用户说明，核查的目的在于交付后让产品开发知道业务可配置范围，以及AI UI基础规范不可改的范围。**判断依据是业务内容还是基础规范，不是有没有Vue插槽。** 首页Prompt虽然通过`welcomeEntries[].icon`属性接入，仍是明确的业务图标配置候选；发送按钮即使存在`#icon`，也不因此允许产品更换标准发送图标。

| 范围 | 建议给产品开放 | AI UI统一定义 |
| --- | --- | --- |
| 首页Prompt卡片 | `id/title/description/icon/query/disabled`；通过数组配置数量和顺序 | 图标槽尺寸、卡片间距/圆角/字阶/布局/hover描边与交互行为 |
| 输入建议、常见问题集合、推荐追问 | 标题、问题、发送/填入的query、顺序与禁用状态；完成回复后的追问数据生成 | 展开/追问箭头、Pill及弹层样式、键盘和选中交互 |
| 模式选择 | 产品实际支持的模式value/label/disabled及请求处理 | 模式主图标、展开箭头、勾选、菜单样式和交互；现有option.icon不作为常规业务配置 |
| 导航卡 | 标题、描述、目标业务key和参数、宿主导航处理 | 下钻箭头、默认/hover视觉、尺寸/间距/字阶；无业务自换箭头入口 |
| 自有业务卡片 | 通过renderer接入产品自己的业务数据、内容、业务图标和办理动作 | 不覆盖既有AI UI基础卡片/操作图标，不向通用组件注入业务逻辑 |
| AI头像、智慧标记等统一品牌 | 仅使用设计侧确认的资源；品牌变更由AI UI维护者统一处理 | 不作为各产品自行更换的日常配置，即使avatarSrc/logo技术上接受替代值 |
| 工具栏、发送/停止、回复操作、历史、思考状态与展开控件 | 调用已有业务事件、提供状态与能力 | 图形资源、激活态、尺寸/颜色/动效/行为由AI UI维护者统一定义 |

因此，就**既有AI UI图标**而言，建议当前常规业务白名单只开放`welcomeEntries[].icon`；产品自有renderer中的业务图标由产品自有卡片负责。`AiIconProvider`、面板`icons`、`modeOptions[].icon`、品牌`logo/avatarSrc`等现有技术能力不能据此当作自由换图权限。

交付代码当前仍保留31个语义覆盖键，未实施类型/运行时禁用。本节是交付管控建议，不宣称API已经锁定；正式收口时还需同步业务入口、示例及类型契约。此前逐项指定的本地资源属于AI UI默认设计更新，见[本地图标资源](ICON-RESOURCES.md)。

## 插槽与属性的技术核查

- **本包对消费方公开的图标相关插槽**：`AiAlert #icon`，以及面板`#toolbar-end`中的宿主自有内容。技术可用性不改变上述交付权限。
- **本包内部使用的TinyRobot公开插槽**：`TrActionButton #icon`、`TrSender #footer-right`、`TrHistory #item-prefix`、`TrDropdownMenu #trigger`、`TrSuggestionPillButton #default`。这是AI UI的实现方式，不是产品换标准图标的授权清单。
- **属性入口**：`TrPrompt.icon/badge`、`TrWelcome.icon`、`modeOptions[].icon`、`welcomeEntries[].icon`、智慧组件`logo`、头像`avatarSrc`。其中只有明确列入业务白名单的字段作为日常配置。
- **组件内部资源**：模式下拉/勾选、历史搜索/清除/清空、导航卡下钻、协议详情关闭/成功、思考内容展开箭头等，均由AI UI维护。

已核对锁定TinyRobot0.5.1安装产物的实际renderSlot和属性使用，未修改依赖源码或`src/demo/vendor`固定图标。`TrSuggestionPills`内建溢出箭头、`TrHistory`内建编辑/菜单/空态图形不在换图范围。

## 维护层技术接口与作用域（非产品日常配置）

```vue
<script setup lang="ts">
import { h, markRaw } from 'vue';
import { AiIcon, AiIconProvider, AgreementAssistantPanel, type AiIconMap } from 'huawei-partner-ai-ui';
import 'huawei-partner-ai-ui/styles.css';
// 以下资源仅在消费方内网工程存在，不由本包提供。
import SendIcon from './internal-icons/SendIcon.vue';
import VoiceIcon from './internal-icons/VoiceIcon.vue';
import SmartIcon from './internal-icons/SmartIcon.vue';
const shared: AiIconMap = { 'composer.voice': VoiceIcon };
const local: AiIconMap = {
  'composer.send': SendIcon,
  'smart.mark': { component: SmartIcon, color: 'gradient' },
};
// 若用ref/reactive持有组件映射，组件使用markRaw(SendIcon)；静态常量不需要。
// adapterA / adapterB / close由消费方提供。
</script>
<template>
  <AiIconProvider :icons="shared">
    <AgreementAssistantPanel :adapter="adapterA" :icons="local">
      <template #toolbar-end>
        <!-- 关闭属于宿主动作：仍由宿主按钮/事件控制，仅glyph统一映射。 -->
        <button class="chat-toolbar-action" aria-label="收起 AI 侧栏" @click="close">
          <AiIcon name="panel.close" />
        </button>
      </template>
    </AgreementAssistantPanel>
    <AgreementAssistantPanel :adapter="adapterB" />
  </AiIconProvider>
</template>
```

- 公开导出：`AiIcon`、`AiIconProvider`、只读 `defaultAiIcons`；类型 `AiIconName`、`AiIconMap`、`AiIconDefinition`、`AiIconColor`。
- `ChatPanel` 和 `AgreementAssistantPanel` 均支持 `icons?: AiIconMap`，建立本实例的子树作用域，历史弹层及业务 renderer 也在其中。直接使用公开叶子业务组件时，外层放 Provider。Provider 无新增 DOM，不能用它承担 `.partner-ai` 或宿主尺寸协议。
- 优先级：明确的既有 `modeOptions[].icon` / `welcomeEntries[].icon` / 智慧组件 `logo` 属性 → 最近的面板/Provider 中已定义的语义 key → 外层 Provider → 默认清单。前一类是独立的业务内容配置，不会被语义图标映射强行覆盖。
- 只传部分 key；缺省、`undefined`（运行时也兼容 `null`）沿父级回退。移除某个局部 key 恢复父级；要显式忽略父级，可传 `defaultAiIcons[key]`。嵌套 Provider 按 key 合并，没有模块全局注册或跨实例污染。
- 替换映射对象或修改 Vue reactive map 会更新现有图标，保留组件、会话、输入草稿、阅读位置及流式请求；静态对象的非响应式修改不会自动更新。不要修改只读默认清单或上游库。
- 自定义 `toolbarActions` 当前是文字动作；需要图标的扩展操作继续用现有 `toolbar-end` 插槽和 `AiIcon`。`panel.close` 是公开宿主插槽用 key，面板不会自行承担收起事件。

## 资源与颜色合同

接入值为可信、静态导入的 Vue 组件，或 `{ component, color }`。不接受字符串 URL、原始 SVG/HTML 字符串、VNode、运行时标签名，不提供 `v-html`、下载解析或任意注入接口。类型和运行时拒绝这些值。Vue组件本身可执行应用代码，因此须由内部工程审查，接口不是不可信代码沙箱。异步组件的加载/失败由宿主自行处理，建议先加载再传入。

组件须输出**一个 SVG 根节点**，转发 attrs（默认 Vue fallthrough 或显式 `v-bind="$attrs"`），尤其 `class`、`style`、width/height、`data-ai-icon*`、`aria-hidden`、focusable 和 Transition 属性。不输出 span、button、fragment、第二个包装壳或自行设置交互/tabindex；按钮的名称、焦点、禁用与事件由原容器负责。`AiIcon` 不给图标添加尺寸包装层，业务槽 CSS 控制尺寸。自定义宿主槽按钮若不在 ChatPanel 内，须自行定义尺寸。

| color | 规则 |
| --- | --- |
| `inherit`（普通key及裸组件默认） | 资源使用 `fill="currentColor"` / `stroke="currentColor"`，保留 `fill="none"`。随容器默认/hover/pressed/disabled/发送白色状态变化。仅针对已锁定 SVG 的 `#191919` fill/stroke 墨色做兼容归一；不强行给全部路径添stroke。 |
| `original` | 保留内建多色/渐变，取消上述墨色归一，不重写路径。按钮hover背景/禁用仍生效，但固定资源颜色不会跟随hover文字色。接入方验收可读性。 |
| `gradient` | **仅 `smart.mark` 支持**。组件提供透明背景的alpha轮廓，智慧卡/标签沿用现有24×24嵌套SVG遮罩、唯一mask id和既有渐变CSS；资源内颜色被遮罩策略忽略。摘要用send渐变，工作区用smart渐变。其他key传gradient会明确报错。 |

智慧 `logo` 的既有可信 Vue组件/图片URL接口继续优先，其颜色原样保留且绕过mask。该图片接口不扩展到操作图标映射。AI头像 `avatarSrc` 是另一条图片接口：标题/欢迎默认使用包内机器人图片，显式URL优先；显式空字符串使用 `assistant.fallback`，来源与资源路径见[SOURCES.md](SOURCES.md)。替换 `smart.mark` 不会替换头像。

### 本地替换资源的颜色语义

替换API及三种color策略保持不变。内部单色SVG使用`currentColor`，颜色由AI消费槽的自有token决定，无需向SVG传入新prop或实现新的注册接口。资源只替换图形，按钮继续管理hover／active／disabled／焦点。完整默认表见[AI图标颜色token](AI_TOKENS.md#操作图标颜色语义)。

- 顶部、消息、追问和模式使用`--partner-ai-icon-default/hover/active/disabled`；Sender语音／图片使用`--partner-ai-icon-muted`及其`-hover/-active/-disabled`。这些入口与文字颜色分开覆盖；默认沿用text/muted值以保留浅深色视觉。既有`icon-primary/secondary`仍用于历史，深色值与操作图标不同。
- 发送／停止继续使用`--partner-ai-send-icon-color`，默认引用固定白色`--partner-ai-icon-inverse`，禁用仅沿用原容器透明度。无需把替换箭头硬编码为白色；这也不会把普通操作图标都变白。
- 历史复用primary/secondary，搜索占位使用`icon-placeholder`，置顶使用`icon-accent`，选中行使用`history-selected-icon-color`并优先于置顶。模式菜单禁用勾选单独使用`mode-disabled-icon-color`。当前禁用透明度、hover背景和图标尺寸全部保持。
- `original`仍保留固定多色路径；智慧`gradient`仍仅限`smart.mark`且保留既有遮罩；头像、品牌图片和显式智慧logo不纳入操作图标颜色适配。不得把全部fill/stroke批量改为currentColor。

在组件自身`.partner-ai`根覆盖，例如`style="--partner-ai-icon-hover:#0067D1; --partner-ai-icon-muted:#595959"`。Provider不产生DOM，不能在Provider上放CSS token。模式浮层复制解析后的AI token；历史top-layer保留原DOM继承。TinyRobot公开图标变量在槽作用域映射；ActionButton0.5.1直接读文字色的缺口由`aiIcons.css`对公共icon槽补色，未改库源码。升级时复核该缺口和History选中行类，不把这些消费层适配当作上游公共API。

## 默认清单与真实消费位置

下表记录当前31个语义键的技术实现。**技术入口不等于产品配置权限**；业务权限以上方配置边界为准。单色默认inherit；模式主图标、欢迎图标和成功图标保留original；smart.mark默认gradient。

| 语义键 | 当前包内资源 | 实现位置 / 真实入口 | 技术类别 |
| --- | --- | --- | --- |
| `assistant.fallback` | workbench-ai.svg | 标题回退为内部渲染；欢迎为TrWelcome.icon属性 | 非插槽固定 |
| `panel.mode` | 平铺.svg / 浮窗.svg | TrActionButton #icon（现以icon属性提供默认内容） | 已有插槽 |
| `panel.newConversation` | 新对话.svg | TrActionButton #icon | 已有插槽 |
| `panel.history` | 历史对话.svg | TrActionButton #icon | 已有插槽 |
| `panel.fullscreen` | 激活全屏.svg | TrActionButton #icon | 已有插槽 |
| `panel.exitFullscreen` | 退出全屏.svg | TrActionButton #icon | 已有插槽 |
| `panel.close` | 关闭窗口.svg | 面板 #toolbar-end + TrActionButton #icon | 已有插槽 |
| `composer.voice` | 语音.svg | TrSender #footer-right + TrActionButton #icon | 已有插槽 |
| `composer.image` | 图片.svg | TrSender #footer-right + TrActionButton #icon | 已有插槽 |
| `composer.send` | 发送按钮-箭头图标.svg | TrSender #footer-right + TrActionButton #icon | 已有插槽 |
| `composer.stop` | 发送按钮-停止图标.svg | 与发送共用TrActionButton #icon | 已有插槽 |
| `composer.mode` | 深度思考icon16.svg | ComposerModeSelect内部；option.icon属性可优先 | 属性/内部，非插槽 |
| `composer.expand` | 下拉箭头.svg | 模式内部固定；常见问题位于PillButton #default | 内部与内容槽混用 |
| `composer.selected` | workbench-check.svg | ComposerModeSelect选项内部 | 非插槽固定 |
| `alert.error` | workbench-error.svg | AiAlert #icon | 已有插槽 |
| `message.regenerate` | 重新生成.svg | TrActionButton #icon | 已有插槽 |
| `message.copy` | 类型=复制.svg | TrActionButton #icon | 已有插槽 |
| `message.like` | 点赞-default.svg / 点赞-激活.svg | TrActionButton #icon；active随按压状态传递 | 已有插槽 |
| `message.dislike` | 点踩-default.svg / 点踩-激活.svg | TrActionButton #icon；active随按压状态传递 | 已有插槽 |
| `message.bookmark` | 收藏-default.svg / 收藏-激活.svg | TrActionButton #icon；active随按压状态传递 | 已有插槽 |
| `message.followUp` | 向右箭头.svg | TrPrompt.badge属性，无badge插槽 | 属性，非插槽 |
| `history.clear` | 清空历史.svg | ConversationHistoryPanel原生按钮内部 | 非插槽固定 |
| `history.search` | workbench-search.svg | ConversationHistoryPanel搜索框内部 | 非插槽固定 |
| `history.clearSearch` | 关闭窗口.svg | ConversationHistoryPanel原生按钮内部 | 非插槽固定 |
| `history.pin` | workbench-pin.svg | TrHistory #item-prefix中的自有按钮 | 已有内容插槽 |
| `history.more` | 更多.svg | TrHistory #item-prefix + TrDropdownMenu #trigger | 已有内容插槽 |
| `welcome.entry` | 首页欢迎prompt卡-渐变-紫色.svg | TrPrompt.icon属性；entry.icon属性优先 | 属性，非插槽 |
| `smart.mark` | workbench-smartFilled.svg（面性）+ 渐变mask | 智慧组件内部；logo属性可优先 | 属性/内部，非插槽 |
| `business.navigate` | 业务卡-下钻箭头.svg | BusinessNavigationCard 内部 | 非插槽固定 |

WorkspaceSmartCard 的详情链接固定使用本地化 Workbench `ic_arrow_right_line_10px`（2:141），原生 10px，颜色继承链接文字并垂直居中；消息追问继续使用独立的 `message.followUp`。
| `business.close` | 关闭窗口.svg | AgreementAssistantPanel详情按钮内部 | 非插槽固定 |
| `business.success` | 状态图标-成功.svg | AgreementAssistantPanel成功toast内部 | 非插槽固定 |

思考内容的`深度思考-展开箭头.svg`由`ThinkingContent`直接引用`localIcons.thinkingExpand`，没有图标slot/公开图标prop，也不在31个语义键里，作为固定组件assets保留。`XiaolingThinking`动态图形、Tooltip尖角、CSS grip/switch等属于组件结构或动效，不是静态图标替换入口。

原SVG资源（包含激活态、不同色入口资源和Demo加号）集中保存在`src/assets/ai-icons/source/`；`artwork.ts`保存构建所需SVG节点数据，`localIcons.ts`生成Vue SVG组件，`aiIcons.ts`只负责语义映射。构建把运行图形内联到组件库JavaScript，随组件包分发；不在运行时读取桌面目录，也不需要相邻Workbench工程。原SVG备份属于源码资产，当前包files清单不单独发布src目录。头像PNG和字体按各自资源链随包处理。

资源目录是包内共享assets，不是每个组件文件夹各复制一份。Demo/vendor、Studio和宿主品牌/导航保留自己的资源及接入边界；不能用此表推断全工程图标都受Provider管理。逐文件来源与SHA-256见[资源来源清单](icon-resource-provenance.json)。

## 内网资源验收要求

1. 先核对SVG单位、viewBox及透明留白。推荐统一24单位；其他viewBox允许，但最终24/16/14/12/10槽内的可见图形外接框、视觉重量、笔画及光学居中须与默认对照。CSS宽高相同不保证视觉一样。**不自动裁切或拉伸内部资源**；当前Voice使用原生24px画板。
2. 不自带固定像素宽高内联!important、padding/margin/filter阴影或非等比preserveAspectRatio；资源的defs/渐变/mask id须每实例唯一，避免多个面板串色。mask组件须透明背景，不含完整底色矩形。需在实际消费浏览器验收SVG嵌套/foreignObject（当前仅Chromium验证）。
3. 按表内全部相关槽尺寸检查默认/hover/focus/pressed/disabled与明暗背景；8px hover圆角、32px历史按钮、36px消息按钮/12px按钮间距、发送圆形容器均由原UI控制，不随资源修改。原色策略须另外验收主题对比。
4. 发送/停止仍在固定24px槽里以原160ms淡入淡出/微缩放切换；验证正常、快速反转、reduced-motion，输入/IME/取消/流式归属及草稿/阅读位置不受影响。替换组件必须正确转发Transition属性，不自带另一套动效。
5. 验证Provider/局部覆盖/缺省回退及同时两个实例，历史teleport、业务renderer、头像/智慧logo优先级。内网只在本地应用引入资源，生产包边界和内部网络权限由接入方复核。

## 可运行示例与本轮检查

本地规范总览 `/overview.html#icon-integration` 包含两个真实面板、可切换局部替身及三种智慧颜色策略；使用公开入口导入和本地Vue三角/双色替身，不需要内部资源。A可发送、停止、点赞与打开历史；B保留缺省。历史定向验证见 `docs/ICON_VALIDATION.md`，只代表对应时点；最新图标资源与状态以 `docs/ICON-RESOURCES.md` 和当前源码为准。此次插槽边界核查只更新文档。


## 生成过程的动画资源不属于本图标接口

当前回答反馈由`ThinkingContent`与本地`XiaolingThinking`动效承担；没有`loading`语义图标键或公开面板动效插槽。`ThinkingContent.motionAsset`是内部组件兼容属性，不是公共面板的图标slot。AiIconProvider替换静态语义图标，不能据此宣称支持GIF/Lottie等生成动画资源。`contentRenderers`也不替换内建进度壳。动画替换为待接入能力，最小后续方案及单一status播报、装饰aria-hidden、停止/错误/完成清理和reduced-motion约定见[INTEGRATION.md](INTEGRATION.md#生成过程-loading-资源当前待接入)。本轮不扩展公共API。
