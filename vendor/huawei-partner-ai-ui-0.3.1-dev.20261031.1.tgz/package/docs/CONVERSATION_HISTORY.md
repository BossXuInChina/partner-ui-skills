# 历史会话接入

`AgreementAssistantPanel` 默认历史入口复用原生manual popover非模态浮层和 TinyRobot0.5.1 `TrHistory`。新建保留旧会话，切换停止并等待正在生成的请求后恢复消息、草稿、AI／模式、阅读位置、最近请求和错误；业务编辑未保存时阻止切换。`ChatPanel` 的 `conversationId`／`conversationView`／`conversationViewChange` 供自有会话控制器接入，`historyAvailable`／`historyOpen`／`historyOpen`事件承载弹层入口；默认不代替自有控制器持久化。

## 配置

```vue
<AgreementAssistantPanel :adapter="businessAdapter" :history-options="historyOptions" />
```

```ts
import type { ConversationHistoryOptions, ConversationStorage } from 'huawei-partner-ai-ui';

// 由消费方实现，write 必须在持久化提交后resolve，失败reject。
const storage: ConversationStorage = {
  read: namespace => repository.readSnapshot(namespace),
  write: (namespace, snapshot) => repository.commitSnapshot(namespace, snapshot),
};
const historyOptions: ConversationHistoryOptions = {
  namespace: `my-product:tenant-${tenantId}:user-${userId}:history:v1`,
  storage,
};
```

选项在挂载时解析。账号／租户切换应按身份重新挂载；各产品必须分配自己的命名空间。默认namespace为 `partner-ai:agreement-history:v1`，存储是浏览器localStorage中单键JSON，适用于本地单页会话；演示使用独立的 `partner-ai:demo:agreement-history:v1`，不会调用真实业务历史API。

快照 `ConversationSnapshot` 包含version1、activeId和conversations。每条记录包含id、title、updatedAt（UTC毫秒）、pinned、可JSON序列化的UI messages、输入／阅读view、lastQuery、error、requestContext。标题来自第一条用户消息（最多80字符），未发送的草稿会话使用草稿标题；空白会话不出现在列表。搜索标题后分组，置顶互斥，其余按更新时间倒序；7／30天按累计24小时分段，边界分别为 `[now−7d,+∞)`、`[now−30d,now−7d)`、`<now−30d`。

## 持久化语义

写入排队并合并流式／草稿变更。清空确认包含所有置顶、消息与草稿，仅写此namespace的空快照，成功才清除界面；失败保持原数据。置顶失败回滚；读失败阻止覆盖未读数据，显式重新读取可重试。kit0.4.0的clear／deleteConversation没有等待底层异步删除，本实现没有依赖这两个API。

刷新不会重新发送中断请求，部分输出保留并标记停止。`reset()`维持既有清除当前会话／输入语义；需要保留当前会话时使用公开 `newConversation()`。产品不承诺跨标签页合并、跨设备同步、加密、旧schema迁移或突然退出时自定义异步后端未完成的提交。存储配额／权限失败会显示错误，并保留当前页内内容。

UI升级复核：TrHistory公开slots/token/selected；局部隐藏空菜单的 `.tr-history__item-actions` 适配；原生Popover支持、非模态焦点／Escape／外部关闭及进退场；kit abortRequest与实际请求finally顺序。没有改TinyRobot源码或引入mock到产品闭包。

菜单300px宽、max-height520px、padding16px；仅.history-list滚动，复用共享useAutoScrollbars的原生显隐。无全局遮罩，外点可继续操作页面；Escape恢复触发器焦点，Tab可离开。header40px，32px常规搜索框与列表各间隔8px；分组／条目40px高、14px。pin行hover／键盘focus-visible显示，触屏始终可见。进退场垂直6px和淡入淡出复用Workbench200ms／cubic-bezier(0.2,0,0,1)，6px为消费选择；reduced-motion取消位移与transition。

REQ-016 v0.3：面板圆角24px。当前项由activeId／TrHistory.selected控制；选中底色复用用户气泡 `--partner-ai-user-bubble-bg`，文字和选中行pin使用 `--wb-color-orange-60`。选中底色在hover保持。所指定orange-60／orange-05配色小字号对比度实测约3.754:1，未达到WCAG AA常规文本4.5:1；保留指定色并记录此限制，不声明文本对比度通过。

REQ-016 v0.4：每条会话右侧更多菜单复用TrDropdownMenu／IconMenu2，新增单条删除。公开UI要求用户逐次确认永久删除及全消息／草稿范围；没有自动删除或恢复承诺。候选快照可靠提交后才移除UI，失败保留；删除当前先停止并等待请求finally，成功后新建空白会话；删除其它不打断当前流式，期间delta补存。事务暂停／排队autosave避免目标复活。DropdownMenu键盘roles／tabindex是局部0.5.1 DOM适配，升级需复核；浏览区在确认时v-show保留，确保公开appendTo节点与延迟销毁兼容。现有namespace／storage契约不变，没有新增绕过确认的公开删除方法。

REQ-016 v0.5：历史pin／更多／顶部clear统一32px容器与24px SVG；相邻图标控件gap0，SVG盒之间8px留白。标题到首图标仍8px，文字宽度保持180px，原截断Tooltip与所有事件不改。

REQ-016 v0.6：更多32px点击容器右缘到行底色右缘为4px，仅将公开item-padding右侧改为4px，左侧8px保持。wrapper无重复间距；SVG24／相邻gap0保持，标题宽度增为184px，截断行为不改。


## r3：普通HTTP与读取恢复

会话ID和详情操作ID通过内部createClientId生成；优先crypto.randomUUID，非安全HTTP缺少该函数时使用crypto.getRandomValues生成UUIDv4。它不是认证、授权或凭据接口。两种安全随机能力均不可用时明确失败，不使用Math.random或假保存。普通HTTP仍需浏览器允许localStorage；不同origin的历史独立，不自动跨localhost/LAN地址/端口迁移。

读取失败的错误不会再被自动保存错误覆盖，也不会写入未成功读取的存储。重复失败保留当前页正文和草稿；成功重试读取会把持久历史与当前有效会话合并，ID冲突时保留两条并重分配当前页ID，当前活动正文/草稿/请求不被旧记录替换。合并结果真实写入成功后才撤下错误。配额与SecurityError写入失败分别说明原因，不声称页内保留就是持久保存。跨标签页并发合并与旧schema迁移仍未提供。
