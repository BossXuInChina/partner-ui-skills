# 公开版本锁定记录

## 当前 Vue 消费范围（2026-10-31）

产品包将 Vue 声明为 `peerDependencies.vue: >=3.5.13 <=3.5.42`，由宿主提供单一 Vue 实例；不再把 Vue 作为产品运行时 dependencies。工程开发与冻结锁干净重建仍固定 `devDependencies.vue: 3.5.13`。独立消费者默认使用 3.5.13，可用 `--vue-version` 或 `PARTNER_CONSUMER_VUE_VERSION` 指定范围内的精确稳定版本；范围、预发布版本和 npm/URL 协议不作为版本参数接受。

本次验收矩阵为 3.5.13 与 3.5.42：分别独立安装同一实际产品 tarball、类型检查、构建和原有 headless 消费行为，并检查依赖图中只有一个实际 Vue 安装及浏览器版本。实际结果以本次机器验收报告为准，不把 peer 范围声明当作已验证其中所有补丁版本或生产批准。TinyRobot/kit/两版 svgs 的既有版本与字体/产品边界不变。

## 历史基线（2026-10-12）

核验日期：2026-10-12。依据官方 registry manifest、实际安装 package.json、发布 dist 类型/JS、严格 peer 安装与本机测试。完整依赖图在 `pnpm-lock.yaml`。

| 包 | 精确版本 | 实际 Vue peer | 结论 |
| --- | --- | --- | --- |
| vue | 3.5.13 | — | 全树使用 3.5.13 |
| @opentiny/tiny-robot | 0.5.1 | ^3.3.11 | 接受 3.5.13 |
| @opentiny/tiny-robot-kit | 0.4.0 | >=3.0.0 | 接受 3.5.13 |
| @opentiny/tiny-robot-svgs（根） | 0.3.5 | >=3.0.0 | 接受 3.5.13，Vite 解析并实际渲染图标 |
| @opentiny/tiny-robot-svgs（robot 内部） | 0.5.1 | >=3.0.0 | robot 的直接传递依赖，未覆盖 |
| dompurify | 3.3.1 | — | 满足 robot peer ^3.3.1 |
| markdown-it | 14.1.0 | — | 满足 robot peer ^14.1.0 |

未观察到这三个指定包之间的实质 peer 冲突。根 SVG 版本不代表 robot 内部版本；并存两个版本可能增加打包体积。未擅自升级或强制覆盖公司基线。

三个 TinyRobot 包没有 exports map。robot 的 main/module/types 为 dist/index.js / dist/index.js / dist/index.d.ts；kit 为 dist/index.js / dist/index.mjs / dist/index.d.ts；svgs 只有 module=dist/tiny-robot-svgs.js 与 types=dist/index.d.ts，没有 main。应用使用包根导入，Vite 构建/浏览器与独立消费均实际验证。没有使用未发布 sender/extensions 内部路径。

使用的公开接口：TrLayout、TrBubbleList、TrBubbleProvider、BubbleRenderers.Markdown、useBubbleEventFn、TrSender、TrThemeProvider。kit 0.4.0 responseProvider 接收 requestBody/AbortSignal 并返回 AsyncGenerator；本地 bridge 产出 ChatCompletion，`onCompletionChunk` 必须调用 runDefault 才执行默认 delta 合并。

已发布 Sender 的默认提交控件为 div，且 Tiptap 状态更新有双 requestAnimationFrame 延迟。候选通过公开 footer-right slot、v-model 与组件暴露的 editor 配置补上可访问按钮/输入标记；组件外层明确处理 Enter，保留 Shift+Enter 换行和输入法 composing 行为。无 TinyRobot 源码修改。

官方快速开始用于了解安装与总体使用方式；网站可领先锁定版本，实际 API 以安装的 0.5.1/0.4.0 类型和实现为依据。未运行 CLI：v0.5.1 标签 add.js 使用 0.5.1-alpha.2，basic 模板 Vue ^3.5.30 / Vite ^8.0.1 与基线不同。

元数据、integrity、入口与 lockfile SHA-256 在 `.artifacts/version-lock.json`；原始公开 manifest 在 `.artifacts/dependency-audit/`。

来源：[官方快速开始](https://docs.opentiny.design/tiny-robot/guide/quick-start.html)、[robot registry](https://registry.npmjs.org/@opentiny/tiny-robot/0.5.1)、[kit registry](https://registry.npmjs.org/@opentiny/tiny-robot-kit/0.4.0)、[svgs registry](https://registry.npmjs.org/@opentiny/tiny-robot-svgs/0.3.5)、[CLI 版本](https://github.com/opentiny/tiny-robot/blob/v0.5.1/packages/cli/bin/commands/add.js)。
