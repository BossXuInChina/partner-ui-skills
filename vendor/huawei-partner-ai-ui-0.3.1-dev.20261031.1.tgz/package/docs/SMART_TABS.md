# 智慧页签 · WorkspaceSmartTabs

从 `huawei-partner-ai-ui` 导入组件及 `WorkspaceSmartTab` 类型，应用入口引入一次 `huawei-partner-ai-ui/styles.css`，在 `.partner-ai` 作用域中使用。无需 Workbench 依赖。

```vue
<script setup lang="ts">
import { ref } from 'vue';
import { WorkspaceSmartTabs, type WorkspaceSmartTab } from 'huawei-partner-ai-ui';
const selected=ref('overview');
const items:WorkspaceSmartTab[]=[
  {value:'overview',label:'续签概览',smart:true},
  {value:'records',label:'协议数据'},
];
</script>
<template>
  <section class="partner-ai" style="height:auto">
    <WorkspaceSmartTabs v-model="selected" :items="items" aria-label="协议工作区">
      <template #panel="{item}">
        <div v-if="item.value==='overview'">智慧内容由业务方组合</div>
        <div v-else>协议数据由业务方提供</div>
      </template>
    </WorkspaceSmartTabs>
  </section>
</template>
```

## 字段、事件与插槽

- `modelValue:string`、`items:readonly WorkspaceSmartTab[]` 必填。每项包含唯一稳定的 `value`、纯文本 `label`；可选 `smart:boolean`、`disabled:boolean`，默认均为false。
- `align: 'center' | 'start'` 默认center；`ariaLabel` 默认“智慧页签”，多个实例使用不同名称。同页多个独立 Vue 应用时，由宿主为各应用设置不同的 `app.config.idPrefix`，避免 Vue `useId` 的跨应用 ID 冲突。
- `update:modelValue(value)`、`change(item)` 只在用户选择新的可用项时发出。选中值不存在或已禁用时无选中内容，首个可用项可通过键盘进入；组件不擅自修改业务选中值。
- 可选 `panel` 插槽接收 `{item}`。各项内容分别挂载、非选中项通过隐藏保留；切换保留本地状态。大型异步内容由业务方按需加载。未提供插槽时只呈现页签条。内容与页签间距由插槽内业务布局负责，不生成空白高度。

## 已封装的设计与交互

14/22/400文字，24px智慧图标、图文间距8px，项间距32px。2px选中线覆盖图标和文字的整体宽度，与正文间距8px，200ms ease-out；减少动态效果偏好下无过渡。颜色、字号、图标及间距为统一规范，不作为业务日常任意配置。

左右方向键循环切换可用项，Home/End切换首尾；Enter/Space激活。禁用项不可操作。窄容器采用原生横向滚动，键盘目标自动进入可见范围，只滚动页签条。智慧图标为装饰，不改变可访问名称；有内容插槽时 tab 与 tabpanel 相互关联。

本组件只管理页签与内容容器，不请求模型、不执行路由，不内置表格或卡片。表格、卡片、业务页面可单独或组合放入 panel 插槽。

## 来源与维护

TinyRobot 0.5.1 不提供通用 Tabs API，本实现保留最小原生 tablist。外观参考已确认的 Workbench basic 页签，运行时及Token自包含，不依赖 Demo/vendor；详情见 SOURCES.md。后续升级复核官方 API 与可访问性、隐藏后显示、溢出和动态配置。
