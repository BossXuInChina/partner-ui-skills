# 2026-10-14 语义图标接入验收与本地阶段提交范围

本轮依据当前聊天明确授权：内部图标可替换成为公共接入能力，完成后将今日可归属优化与本次能力做本地阶段提交；不推送、不打产品归档、不发布。工程和父目录没有相关 `.agents/skills` 可读；已读 AGENTS.md、今日全量报告及 REQ-027 总览。未变更依赖/锁文件、上游 TinyRobot 或相邻仓库，保留今日修改和历史。

## 交付范围

- 28个语义key及只读默认清单。公开 `AiIcon`、`AiIconProvider`、四项配套类型；`ChatPanel` / `AgreementAssistantPanel.icons` 建立局部作用域，缺省继承/回退，多个实例隔离，动态配置不卸载会话组件。
- 覆盖面板顶部、发送/停止、模式、回复操作、追问、欢迎fallback、历史（包括teleport）、智慧标识及公开业务导航/协议详情/成功提示。Studio及Workbench宿主独立资产保持边界，头像图片和既有logo/内容图标配置分别处理。
- `inherit` / `original` / 仅智慧支持的 `gradient` 颜色策略；保留默认SVG/本地确认图形、24px常规和14/12/16/10px例外、8px按钮hover、容器/间距以及原发送/停止160ms微缩放淡入淡出。
- 接入方式、默认语义映射、部分替换代码、viewBox/留白/attrs/唯一id和内网资源验收要求见 [ICONS.md](ICONS.md)。规范总览 `/overview.html#icon-integration` 使用两个真实面板和本地Vue三角/双色替身，无内部资源。

## 实际检查与复用

最终有效定向矩阵：**10个测试文件、59个独立场景通过，0跳过、0重试、0flaky**。并非重新运行今日完整211项；未受影响范围复用 `.artifacts/audit-20261014/REPORT.md` 的210pass / 1旧包条件skip。定向矩阵保留各轮报告，按独立场景复用有效通过，不将重复执行累加。

| 检查 | 最终结果 / 实际耗时 |
| --- | --- |
| `pnpm lint` | 全工程0错误0警告，1.47秒 |
| `pnpm typecheck` | 通过，2.46秒 |
| `PARTNER_EVIDENCE_DIR=.artifacts/icon-integration pnpm build` | 应用/库JS/CSS/公开声明通过；总墙钟未独立计时，Vite应用5.43秒、库0.258秒 |
| 10文件定向 `pnpm test` | 57pass / 1新测试类名错误，51.176秒；其余57项有效结果复用 |
| 仅修正历史替换场景复验 | 1pass，4.948秒 |
| 新增替身发送/停止逐帧（正常+reduced）复验 | 1pass，4.013秒 |
| `node scripts/verify-icon-consumer.mjs` | 最终dist-lib/公开exports复制到隔离临时工程：独立类型、负向类型、Vite构建、后台headless运行通过，8.36秒；无pack/install |
| 产品模块闭包 | 85模块，forbidden=[]，无demo/preview/data/mock/Studio/协作文档 |
| npm files dry-run | 使用临时cache，允许清单内仅dist-lib/README/docs；无归档生成。新增本报告后复核文件清单 |
| headless示例实图 / 服务 | 已查看真实替身/默认两面板与智慧渐变画面，pageerror=0；原launchd4178 running，PID66874仍监听，未停止或重启 |
| `git diff --check` / 候选清单 | 通过；逐路径筛选代码/测试/文档/入口，排除全部临时证据、日志、截图/归档及无关路径；候选均文本、无symlink/大文件 |

定向文件：`icon-integration`、`function-icons`、`composer`、`reply-stop`、`history-menu`、`ai-summary`、`workspace-intelligence`、`business-navigation`、`suggestions`、`overview`。

有效矩阵覆盖：父Provider与局部映射/双实例/运行时移除回退；真实模式菜单键盘与回焦；草稿/活跃请求/本地反馈状态保留；发送停止逐帧/禁用/160ms与reduced；默认Voice特殊viewBox及替换资源自主viewBox；回复36×36/24px及12px间隔、点赞/点踩/收藏、10px追问；历史搜索14px/更多置顶24px/teleport/关闭回焦；智慧双实例mask唯一id/原色黑红不被归一/继承文字色/恢复默认渐变；公开导航箭头尺寸；欢迎配置动态节点数/空态/禁用；既有总览窄宽、滚动、弹层与真实Studio。独立消费另覆盖图片头像和显式智慧logo优先级，4个无效资源/非法gradient运行时拒绝，字符串/未知语义key负向类型检查。

原始证据保留于 `.artifacts/icon-integration/`：`valid-test-inventory.json`、各轮browser JSON/log/失败trace、`icon-consumer.json`、`product-boundary.json`、构建与质量日志、`overview-icons.png`；它们不进入本地源码提交或产品模块。

## 失败依据与修正

首轮1pass/4fail（24.175秒）：真实Vue编译块/VNode归属缺口。TinyRobot把图标prop VNode作为动态组件渲染，调用方同时跟踪另一份未挂载节点，更新时出现null emitsOptions。统一内部工厂以新VNode及Vue `createVNode` 的isBlockNode标记隔离prop节点；保留公开组件API、实际SVG单根和原Transition，不改上游。动态欢迎的显式内容图标也使用相同的脱离编译块方式。升级复核注释保留。

第二轮3pass/2fail（7.778秒）：新测试在正常0.9→1缩放的中间帧读取24px外接框，实际21.6px；改为等待原精确24px终值，保留实际动效并新增逐帧验证。新历史检查误用了`.tr-history-item`，纠正为锁定组件真实`.tr-history__item`，不修改产品CSS或放宽断言。

逐帧首轮失败（8.920秒）：reduced场景把旧图形瞬时隐藏的leave-to节点也算作进入动画；修正为严格验证新stop图形opacity=1/scale=1，且实际getAnimations=0。正常场景仍严格验证enter/leave中间帧的opacity/0.9～1微缩放。所有原失败保留，无重试掩盖、增大timeout或降低阈值。

独立消费首轮严格尺寸也在缩放中间帧采样；改为等待精确24px，最终通过。npm默认cache触发EPERM；使用本任务/tmp cache完成dry-run，没有更改用户cache权限。第一次沙箱浏览器无法访问4178而误尝试启动服务（listen EPERM），随后经沙箱审批后台访问原服务；无审批拒绝，未触碰已运行服务。

## 提交边界与剩余限制

本地阶段提交包含今日已完成且可归属的产品/宿主/历史/智慧/导航/Tooltip/滚动/动效优化、Studio检视与总览、关联测试和需求/接入文档，以及本次图标能力。提交今日既存修改不表示本轮再次实施Studio或新的UI优化；原需求文档的待视觉验收状态保留，不伪造批准。所有`.artifacts`既存/本轮生成内容留在工作区，用户文件不删除；没有发现额外无法归属的源码修改。具体hash与提交后工作区核验由最终回复给出。

`pnpm test:consumer` 会打tarball/install，本轮按用户限制使用无打包独立构建产物消费；未进行发布包安装/干净重装。库构建仍有既存renderer大chunk提示，未改阈值。仅本机Chromium headless；内网真实资源、公司生产构建/平台注册schema/业务API、跨浏览器及真机IME/触屏、外部durable存储仍未验证。资源必须为可信SVG单根组件并转发attrs，视觉viewBox/留白/笔画需内网团队验收；本接口不执行自动几何修正，也不是不可信组件代码沙箱。没有已确认未修复缺陷或执行阻塞；今晚在本地提交后停止。
