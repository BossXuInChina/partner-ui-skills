# 设计与许可来源

2026-10-19 当前规范：AI UI 公共样式已改为独立的包内 `--partner-ai-*`／`--partner-host-*` 默认值，`src/index.ts` 不再导入 `src/workbench-tokens.css`。下述 Foundation／Workbench 记录保留历史选值和移植来源，不再表示 AI 的运行时映射；业务 Demo 继续使用其原资产。当前字体家族继承宿主，字阶与其余视觉默认值仍由AI UI维护。完整默认声明、最终值和风险见 [AI_TOKENS.md](AI_TOKENS.md)。


## Workbench资产状态（当前约束）

来源角色按[COMPONENTS.md](COMPONENTS.md)区分：`src/demo/vendor`和preview内总览导航/检视移植仅供Demo/Studio，不进入产品闭包；Foundation配色、间距、动效等保留历史设计参考，不再作为AI运行时Token输入；产品内Tooltip、模式选择、滚动与弹层等自包含适配按实际依赖进入产品闭包，不导入Demo vendor，并保留缺口与升级复核说明。不能笼统把全部参考/适配称为“仅Demo”。

上述本地harness不是公司内部正式/批准的资产源码；参考或自包含不等于生产批准，正式接入由内部团队确认公司批准的组件与资产。HarmonyOS字体原件仅作为独立预览的可选资源保留；2026-10-26起不随组件源码闭包、公共样式或npm包交付，见[FONTS.md](FONTS.md)。授权读取/移植与公司内部正式资产批准是不同事项；下文来源版本、许可和hash用于追溯，不证明公司生产适用性，原设计权利保留。

0.3.0新增ChatComposer/ComposerModeSelect/ChatWelcome为本工程自包含组件。Select视觉参考本工程已移植的WorkbenchSelectCore样式与Foundation token，不运行时导入demo闭包；AI专属尺寸/色值/阴影集中于src/ui/foundation/aiTokens.css并标注REQ-001/003来源。当前参数及内网交付边界见DELIVERY.md、AI_TOKENS.md，以下旧候选尺寸仅保留来源背景。

Workbench Foundation **1.1.0** 来自用户授权只读参考的同级 `huawei-partner-workbench-harness`，读取时 HEAD 为 `888140421f9e3367ba9217e7046aec5b7c9fa55b`，仓库无未提交改动。仅选择 Foundation runtime CSS 及 PreviewControls/usePreviewRuntime/usePrototypeNavigation/RendererApp 的相关协议模式参考；没有复制整套工程，也没有跨目录源码依赖。

`src/workbench-tokens.css` 保留原始 token 解析值，将选择器改为 `.partner-ai` 作用域。REQ-001 v0.5另从只读`foundation/source/color-scale.md:61`选出已有设计键`orange-05`（#FEF5E8），在本包导出`--wb-color-orange-05`；light的`--wb-color-alert-subtle`改用该变量，解析值不变。用户气泡直接引用palette token，避免Aurora告警色覆写影响指定橙色，原Workbench未改。原文件与本地副本的 SHA-256、转换方式在 `SOURCE_PROVENANCE.json` 的 selectedOriginRecords/design-provenance.json。Foundation在此仅为本地harness的演示参考，不代表公司内部批准的设计真值；本地候选复用来自本次授权，不构成对私有设计规范的公开再许可。Aurora 的紫色/青绿和渐变为本任务新增候选值，不回写原 Foundation。

字阶使用 Workbench 的 PC 12px 辅助文字、14px 正文、16px 卡片标题、18px 浮层标题、20px 页面标题及 48px KPI。2026-10-19字体收尾：经用户授权，已从上述只读Workbench复制原始 HarmonyOS Sans／HarmonyOS Sans SC 可变TTF和LICENSE到AI自身 `src/assets/fonts/harmonyos-sans/`，逐字节保留，当时公共构建携带字体；2026-10-26已将其剥离，当前仅预览入口可选加载，原件与许可保持。详细家族、400–700注册范围、SHA-256与消费路径见 [FONTS.md](FONTS.md) 及资源目录README。

TinyRobot、kit、svgs 的 npm 包许可均为 MIT。OpenTiny 官方 v0.5.1 的许可原文保留于 `TINYROBOT-LICENSE.txt`；依赖保持正常 npm 包形态，不修改第三方源码或抹去原许可。其他 npm 传递依赖许可保留在各安装包内，正式内部发布由消费方按完整锁文件执行其常规第三方审查。

预览协议借鉴 Workbench 的同 origin、预期 source、请求 ID 与离页检查模式，改写为独立 `partner-ai-preview-v1` 协议，去除公司场景特例。controls 显式经 `resolveProps` 映射到 mock options。未迁移检视器、历史版本库和旧交付脚本。

## 0.2.0 精确 R2 场景移植

2026-10-28 本地增量：经用户确认，将宿主页同步到只读 Workbench 当前工作区的公司信息页面与依赖，包含页级间距、rail 一级页签、当前 TopNav/图标与表单/表格等控件。来源 HEAD 为 `b335ce11d4431b5ea48fc731d7e45af3767bb7ae`，来源当时有未提交改动；本次取实际文件快照，不将 HEAD 冒充完整来源身份。逐文件来源/本地哈希及保留适配见 `src/demo/vendor/workbench/source-provenance.json`。沿用本地可选 `showTopNav`、FloatingButton `scrollTarget`/ARIA、native 全局 Modal/隔离适配；原 Workbench 未修改。宿主移除旧16px页首覆盖，页面使用自己的当前间距；业务版心和悬浮组共享版心上限，仅补偿实际原生滚动槽。业务滚动条复用现有空闲显隐生命周期，默认透明、交互显示，不改变滚动能力。下述旧 HEAD/文件数量为原始移植记录，本轮来源以新增快照为准；产品/历史交付归档未替换。

原 Workbench HEAD 仍为 `888140421f9e3367ba9217e7046aec5b7c9fa55b`。`src/demo/vendor/workbench` 包含精确 R2 场景、它实际依赖的注册信息 R7，以及选定组件/外置样式/华为 logo 的 61 文件依赖闭包。来源 SHA-256、当地副本 SHA-256 与适配说明记录在 `SOURCE_PROVENANCE.json` 的 selectedOriginRecords/ported-sources.json。没有复制原包 package.json/工具链、安装原 Vue 3.5.42 包或跨目录引用源码。

Foundation runtime 与 Catalog asset tokens 原值保留，仅在演示 renderer 中加载；另选出实际使用的 Candidate modal stack token。原 JS SFC 通过本地组件声明边界接入，在 Vue 3.5.13 下编译与浏览器测试。只增加可选 showTopNav、悬浮组 scrollTarget 和入口 ARIA，原表格、筛选、隐私遮挡、表单与导航交互保持原实现。

原设计和华为品牌图资产权利仍属于原来源，本次为用户授权的私有候选复用，不授予公开再许可。用户提供的 Library 图片按确切 ID materialize：头像 `libfile_3e9606565ba08191bd2ecf3339886a45`，参考图 `libfile_45b248430d6881918d2e3d883d6c377f`；原图未编辑，副本保留相同 bytes 和 Library xattrs。参考图及演示业务源码不进入产品包；头像原为Demo素材，2026-10-20按用户指定转为产品默认AI形象，见下节。


## 产品默认 AI 头像（2026-10-20）

用户指定 `src/demo/assets/weknow-avatar.png` 为产品 AI 形象；其同字节副本位于 `src/assets/assistant-avatar.png`，100×100透明PNG，SHA-256 `fcac8ab389c74d1522125e387a0147c9ea506308898ecf04ab69955cecd70086`。未编辑、裁剪或重采样，原Demo路径保留兼容。公共模块、Demo和总览通过 `src/assets/assistantAvatar.ts` 统一引用公共副本，不从Demo闭包取资源。

`ChatPanel`／`AgreementAssistantPanel`／内部`ChatWelcome`缺省使用该资源，交付示例继承同一默认值；显式`avatarSrc`优先，空字符串保留`assistant.fallback`语义图标回退。既有40px标题头像、48px欢迎头像、36px Demo入口和40px总览品牌槽位及contain比例保持。功能图标、欢迎入口图标和`smart.mark`渐变标识继续按[ICONS.md](ICONS.md)工作。

PNG以`?no-inline`导入，库构建生成与`index.js`相邻的`assistant-avatar.png`，通过`import.meta.url`相对解析；`dist-lib`允许清单包含该资源，源码组装由公共入口依赖闭包包含PNG。权利及Library来源仍如上，不授予公开再许可，也不代表公司内部正式资产批准。

## 悬浮定位核对（0718c75 后）

只读来源均在原 Workbench HEAD `888140421f9e3367ba9217e7046aec5b7c9fa55b`：

- `catalog/source/components/wb-floating-button/spec.md:28`：主要点击区 48px，右 32px、底 178px，返回顶部间距 24px，验证 2–6 项。
- `catalog/source/components/wb-floating-button/manifest.json:95`：right intent 为距视口右侧；bottom intent 为主交互区底边距视口底部。`catalog/generated/asset.tokens.css:104` 等生成值一致。
- `packages/ui-vue3/src/floating-button/FloatingButton.vue:169`：fixed 视口定位；203 行返回顶部 absolute / top:100%+gap，故返回顶部底距 178−24−48=106px。宽度不改变 right/bottom；group 少于 2 项回退 single，折叠只改变可见项，无定位覆盖。
- `studio/scenarios/WB-FLOATING-BUTTON-V1/components/FloatingButton.vue` 仅透传原组件。R2 的 `studio/scenarios/WB-P5-COMPANY-CONTACTS-ADDRESSES-R2-20260928/pages/CompanyContactsAddresses.vue` 没有 FloatingButton 调用，不存在 R2 定位特例。

新工程仅恢复 `src/demo/demo.css` 的 right 原 token，保留既有 absolute 业务视口锚定。Studio iframe 是 renderer 视口；居中 `.company-content-frame` 与滚动条均不是锚点。AI 关闭时业务视口占满 renderer，展开时终止于侧栏左边，主组始终右距 32px/底距 178px；侧栏适配由演示宿主承担，原 FloatingButton 源码与产品 UI 未变。不引入占位轨道。

浏览器首次检查曾把横向裁剪的表格“显示姓氏”按钮误判为遮挡。随后临时隐藏悬浮组验证底层命中，确认该按钮已被表格自身裁剪；测试只判定原本可以命中的可见控件。失败记录与最终定向证据分别保留，未借此修改业务布局。测试只覆盖 960/1280/2240 及记录的滚动位置，不宣称全量窄屏可用；Foundation 的 `<768px` 内容栅格仍无正式规则。


## 固定侧栏结构候选

采用用户明确的整体布局：视觉横条、固定顶部操作栏、独立滚动中区、固定底部发送区与指定免责声明。TinyRobot 0.5.1 发布包的 `TrLayout mode="normal"` 负责区域，`TrBubbleList.after` 为状态反馈公开扩展点，`TrSender` 保留编辑器/键盘/字数/提交中止能力；约束其容器使长输入内部滚动，未修改 TinyRobot 源码。工具栏 props/events/slot 是候选封装的公开接口。

本轮几何来源为已有 `component-lg16`、`component-md12`、`component-sm8`、`component-xs4`、正文行高22、caption行高20。横条区域16；操作栏 `2×16+2×12=56`；底区 `5×22+2×16+20+5×8+2=204`，为输入最多五行、按钮、声明、间距和边框留出候选空间。三个高度均可覆盖，不回写 Foundation、不宣称用户确认的正式参数。当时头像复用原 Library 透明100×100资产，仅演示宿主传入其 URL；2026-10-20的产品默认资源接入见上节。


## 元素检视移植

只读来源为原 Workbench HEAD888140421f9e3367ba9217e7046aec5b7c9fa55b：`apps/studio-vue3/src/ElementInspector.vue`、`studio/runtime-preview-vue3/src/inspection/useElementInspection.js`、`apps/studio-vue3/src/styles/inspector-ui.css` 及 preview-runtime.css 的 element-inspector 局部规则。`PrototypeWorkspace.vue` 的全屏悬浮工具/面板形态与 usePreviewRuntime 检视会话模式用于宿主适配，未复制完整Studio。

适配根节点、独立消息通道、来源与会话校验；删除Token扫描/展示，隐藏背景URL，不读取输入值/正文/HTML；保持检视锁定并增加键入、双击及上下文操作保护。保留父级、清除、样式/盒模型、Option/Alt间距；工具可收起换边，局部几何限制给发送区留空间。移植JS通过本地声明边界而不是全量TS重写。原版权/许可来源不变，不授予公开再许可。工具与相关数据排除产品包。


## 2026-10-28 全局复查补充适配

后续设计修订：公司示例浮钮现锚定业务视口右侧，不再受版心限制。以下版心定位及分页避让是当时的历史记录；当前布局与进退场行为以 [HOST_LAYOUT.md](HOST_LAYOUT.md) 和 [CHANGELOG.md](CHANGELOG.md) 的最新修订为准。分页安全留白能力仍保留。

公司宿主的版心内浮钮在宽屏滚动时与联系人分页跳转区域相交。本地 `PartnerContactTable` 仅在真实 `WorkbenchPagination` 调用处，通过公开原生根元素 `style` 传入可选的 `--company-pagination-floating-clearance` 外边距，默认0；Demo宿主按浮钮rail、页面/卡片内距和基础间隔计算避让量，当前32px。分页控件样式、浮钮版心位置和原纵向几何保持不变，不添加每帧布局追踪。该适配只进入Demo，来源上游哈希保留，本地哈希与 `hostAdaptations` 已更新。后续更新vendor须复核分页单根属性透传。

公司宿主在自有 `.chat-composer` 区域使用捕获阶段处理无前景弹层时的Escape，避开锁定版本Sender编辑器无菜单也preventDefault的keymap；有效Tooltip、菜单、原生Dialog和全屏仍优先处理。此为宿主快捷键适配，不修改TinyRobot依赖。

## REQ-014 独立功能提示适配

`src/ui/foundation/AiTooltip.vue` 与 `actionTooltip.css` 自包含适配只读 `huawei-partner-workbench-harness/packages/ui-vue3/src/tooltip/WorkbenchTooltip.vue` 的 hover/focus/Esc、定位模型与箭头路径；读取源码 SHA-256 为 `ebd50884e8dabfa0ad95ea33522e59682a75e64c7132adb86b08ad1c6b81392b`。白底、Body-M14/22、4/8内边距、6px圆角、shadow-lg复用本项目已选 Foundation token；12×8箭头、1px重叠、11px桥与452px最大宽度来自原 Tooltip/Catalog popover参数。

保留原设计权利归属，不授予公开再许可。适配移除 demo/Foundation runtime 引用，只依赖已声明 Vue；以 `aiTooltip.ts` 原生指令接入现有触发器，不插入布局包装。TrActionButton 0.5.1 缺少公开 focus/Esc控制与通用触发器接口，故经续办授权采用本地最小可访问性回退；省略内置 tooltip prop，不改 upstream、不使用传递依赖深路径或私有实例。升级需复核公共 Tooltip能力，再评估替换此回退。

REQ-016 v0.3另选出只读兄弟Workbench `huawei-partner-workbench-r5-recovery/foundation/source/color-scale.md:67` 的已有confirmed设计键orange-60（#C76207），通过本包 `.partner-ai` 作用域导出 `--wb-color-orange-60`。历史选中项背景直接复用 `--partner-ai-user-bubble-bg`（orange-05），文字与可见pin引用orange-60 token；不在组件中写颜色字面值，不改原Workbench。

REQ-022 v0.6增量：本工程选定WorkbenchModal.vue/overlay isolation.js在保留原来源的基础上做native全局模态及scroll lease适配；动效值只读参考原WB-MODAL-V1候选规范200ms/cubic-bezier(0.2,0,0,1)，没有修改原Workbench兄弟工程。此JS闭包仍由组件声明和实际浏览器行为校验，不声称TS改写；仍排除产品闭包。

### 总览分类导航（REQ-027 v0.5，仅本地文档）

`src/preview/overview/ported/WorkbenchSideNavigation.vue`直接移植本地harness的`studio/scenarios/WB-SIDE-NAV-V1/components/WorkbenchSideNavigation.vue`，选用其candidate SideNav tokens；来源SHA及最小href/路由/文档列宽适配见该目录README。保留原JS实现，以声明边界接入和实际浏览器行为验证，不称TS重写。仅用于demo演示，非公司内部正式/批准资产源码；不进入公共产品闭包、dist-lib或tarball。许可与原设计权利保留，正式接入须内部团队替换批准资产。

### 通用 Toast（2026-10-27）

设计来源：[Pixso Toast · 5711:1](https://pixso.cn/app/design/ajJNlOy184lAXZfN9Z1yNg?item-id=5711:1)。经本机 Pixso MCP `design_to_code`（Vue）与节点截图核对；两条实例文本分别为“复制成功”和“已提交，非常感谢您的支持！”。成功图标使用 `5703:8039` 导出的原始 14×14 SVG path，内嵌在 `src/ui/foundation/AiToast.vue`；保留设计权利归属，不授予公开再许可。原始导出与资源、清理审计保存在本地 `.artifacts/toast-20261027/pixso/`，不进入产品包。

TinyRobot 0.5.1 无公开 Toast，采用最小普通 DOM / Teleport 浮层适配；不访问其内部 DOM，不新增依赖。错误通知用于剪贴板失败，复用项目错误色；错误叉号为本地补充图形，并非 `5711:1` 的成功实例。字体遵循本项目宿主继承合同，未把设计导出字体带入产品。升级时复核 TinyRobot 公开通知 API 和宿主浏览器浮层显示。

Toast 动效来源（2026-10-27）：只读核对原 Workbench `packages/ui-vue3/src/message/message-motion.css`、`catalog/source/components/wb-message/manifest.json` 与 Catalog/API。沿用其中 200ms / cubic-bezier(0.2,0,0,1) / 0.9 缩放及淡入淡出，通过独立 AI 参数和原生 Popover 的 display/overlay 过渡自包含实现；没有引入 Workbench 的组件、Token 或演示闭包。位置按本轮要求改为侧栏导航下方 24px。

点踩补充反馈多行输入框（2026-10-27）：按用户要求只读核对并自包含移植 `huawei-partner-workbench-harness/packages/ui-vue3/src/input/WorkbenchInput.vue` 的 textarea 分支样式/计数布局与 gutter 测量；数值来自 `catalog/source/components/wb-input/manifest.json`、`foundation/generated/runtime/foundation.css`，滚动条绘制参考 `packages/ui-vue3/src/scrollbar/scrollbar.css`。不导入原工程或demo/vendor、不附带原表单/Search依赖；宿主字体继承和卡片200字符硬限制沿用本工程。

2026-10-27 显示兼容修正：原生 Popover 版本在自动化捕获中可见，但用户持续反馈实际环境看不到，尚未证实根因。已改为随页面绘制的普通 DOM 浮层，保留原有位置、图标、字体/Token 和缩放淡入淡出，排除对原生 top-layer 合成的依赖。


协议业务表格样式（2026-10-27）：按用户要求只读核对 `huawei-partner-workbench-harness/packages/ui-vue3/src/table/WorkbenchTable.vue`、`TableScrollArea.vue`、`packages/ui-vue3/src/scrollbar/WorkbenchScrollbar.vue` 和 `catalog/generated/asset.tokens.css`。本工程自包含适配表头 14/22、40px 行高、8px 横向内边距、16px 表头分隔线、14/22 操作文字及底部覆盖式 14px 滚动轨道；保留原协议数据、状态插槽和详情事件。表格没有 Workbench 固定列能力，未复制完整 Table 组件；原 Workbench 工程保持只读，未声明设计视觉验收或生产发布。

2026-10-28 设计修订：协议表格表头字重调整为 Medium（500），复用 AI 标题字重 Token；正文和操作文字仍为 400。此修订发生在 `2026-10-28-handoff-0.3.0` 本地交付归档之后，旧归档保留原快照；后续交付需重新构建并验证。

2026-10-30 智慧页签：`WorkspaceSmartTabs.vue` 为本项目自包含 TypeScript/Vue 实现，视觉参考本工程 `src/demo/vendor/workbench/ui/tabs/WorkbenchTabs.vue` 的 basic 页签与已确认智慧图标适配。保留14/22字阶、32px项间距、2px选中线和200ms ease-out；智慧标记/选中线由组件内部拥有。未复制整套 Workbench Tabs、多变体、关闭/新增或更多菜单；窄宽采用原生横向滚动。TinyRobot 0.5.1 无通用 Tabs API，升级时复核。产品不导入 demo/vendor 或原 Workbench 工程。
