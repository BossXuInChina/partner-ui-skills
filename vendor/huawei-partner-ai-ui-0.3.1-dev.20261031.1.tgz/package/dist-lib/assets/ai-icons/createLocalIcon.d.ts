import { type VNode } from 'vue';
interface LocalIconNode {
    tag: string;
    attrs: Record<string, string>;
    children: LocalIconNode[];
}
export interface LocalIconArtwork {
    source: string;
    attrs: Record<string, string>;
    children: LocalIconNode[];
}
/** Trusted build-time SVG data only. Keep one SVG root for Robot's public icon slots.
 * Per-instance defs prevent repeated welcome cards from sharing clips/gradients;
 * hosts own size and semantic paint. No HTML injection or dependency DOM access. */
export declare function createLocalIcon(name: string, artwork: LocalIconArtwork, activeArtwork?: LocalIconArtwork): import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    active: BooleanConstructor;
}>, () => VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    active: BooleanConstructor;
}>> & Readonly<{}>, {
    active: boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export {};
