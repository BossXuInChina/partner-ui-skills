import assistantAvatar from './assistant-avatar.png?no-inline';
export default assistantAvatar;
