import { type Ref } from 'vue';
/** Consumer-owned workspace expansion; native menus/dialogs keep Escape priority.
 * Robot 0.5.1 Layout has no workspace fullscreen API. No browser Fullscreen API,
 * dependency DOM hooks or new panel instance; recheck Layout on upgrades. */
export declare function useAssistantFullscreen(open: Ref<boolean>, fullscreen: Ref<boolean>): {
    toggle: () => void;
    escape: (event: KeyboardEvent) => boolean;
};
