export declare function lockModalScroll(doc: Document): () => void;
