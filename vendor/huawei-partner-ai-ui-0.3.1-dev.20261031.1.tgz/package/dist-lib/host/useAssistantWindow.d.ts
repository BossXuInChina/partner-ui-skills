import { type Ref } from 'vue';
import type { ChatWindowMode } from '../ui/panel/chatWindow';
export declare function useAssistantWindow(workspace: Ref<HTMLElement | undefined>, mode: Ref<ChatWindowMode>, open: Ref<boolean>, fullscreen?: Ref<boolean>): {
    style: import("vue").ComputedRef<{
        left: string;
        top: string;
        width: string;
        height: string;
        '--assistant-content-min-height': string;
        '--assistant-resize-handle-height': string;
    } | {
        left?: undefined;
        top?: undefined;
        width?: undefined;
        height?: undefined;
        '--assistant-content-min-height'?: undefined;
        '--assistant-resize-handle-height'?: undefined;
    }>;
    dragging: Ref<boolean, boolean>;
    resizing: Ref<boolean, boolean>;
    compact: import("vue").ComputedRef<boolean>;
    height: import("vue").ComputedRef<number>;
    minimumHeight: import("vue").ComputedRef<number>;
    resizeMaximum: import("vue").ComputedRef<number>;
    start: (event: PointerEvent) => void;
    keyboard: (event: KeyboardEvent) => void;
    resizeStart: (event: PointerEvent) => void;
    resizeKeyboard: (event: KeyboardEvent) => void;
};
