import { type Ref } from 'vue';
/** Visible business rectangle, in local viewport coordinates. No guessed nav height. */
export declare function useHostRegion(region: Ref<HTMLElement | undefined>): {
    bounds: Ref<{
        left: number;
        top: number;
        width: number;
        height: number;
    }, {
        left: number;
        top: number;
        width: number;
        height: number;
    } | {
        left: number;
        top: number;
        width: number;
        height: number;
    }>;
    style: import("vue").ComputedRef<{
        [k: string]: string;
    }>;
    measure: () => void;
};
