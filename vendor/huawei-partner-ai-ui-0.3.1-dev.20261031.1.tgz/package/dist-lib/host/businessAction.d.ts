import type { Agreement } from '../adapters/contracts';
/** Runtime UI events; hosts own routing, permissions and business operations. */
export type AgreementBusinessAction = {
    type: 'open' | 'renew';
    agreement: Agreement;
};
export type WorkspaceNavigation = {
    target: string;
    params?: Record<string, string>;
};
export type BusinessActionMode = 'default' | 'host';
export type BusinessDialogScope = 'region' | 'global';
export declare function isWorkspaceNavigation(value: unknown): value is WorkspaceNavigation;
