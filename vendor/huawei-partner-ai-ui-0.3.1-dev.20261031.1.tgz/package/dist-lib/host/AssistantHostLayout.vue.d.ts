import './assistantWindow.css';
import type { ChatSidebarBehavior, ChatWindowMode } from '../ui/panel/chatWindow';
type __VLS_Props = {
    open: boolean;
    windowMode?: ChatWindowMode;
    sidebarBehavior?: ChatSidebarBehavior;
    fullscreen?: boolean;
    viewportWidth?: number;
    overlayLayer?: number;
};
declare function switchMode(): void;
declare var __VLS_1: {}, __VLS_9: {}, __VLS_11: {
    windowMode: ChatWindowMode;
    fullscreen: boolean;
    toggleFullscreen: () => void;
    switchMode: typeof switchMode;
    dragStart: (event: PointerEvent) => void;
    dragKeydown: (event: KeyboardEvent) => void;
};
type __VLS_Slots = {} & {
    navigation?: (props: typeof __VLS_1) => any;
} & {
    default?: (props: typeof __VLS_9) => any;
} & {
    assistant?: (props: typeof __VLS_11) => any;
};
declare const __VLS_base: import("vue").DefineComponent<__VLS_Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:windowMode": (mode: ChatWindowMode) => any;
    "update:fullscreen": (value: boolean) => any;
}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{
    "onUpdate:windowMode"?: ((mode: ChatWindowMode) => any) | undefined;
    "onUpdate:fullscreen"?: ((value: boolean) => any) | undefined;
}>, {
    fullscreen: boolean;
    windowMode: ChatWindowMode;
    sidebarBehavior: ChatSidebarBehavior;
    viewportWidth: number;
    overlayLayer: number;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
declare const __VLS_export: __VLS_WithSlots<typeof __VLS_base, __VLS_Slots>;
declare const _default: typeof __VLS_export;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
