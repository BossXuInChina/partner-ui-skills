import type { InjectionKey, Ref } from 'vue';
export interface BusinessOverlayContext {
    target: Ref<HTMLElement | undefined>;
    stack: Ref<symbol[]>;
}
export declare const businessOverlayKey: InjectionKey<BusinessOverlayContext>;
