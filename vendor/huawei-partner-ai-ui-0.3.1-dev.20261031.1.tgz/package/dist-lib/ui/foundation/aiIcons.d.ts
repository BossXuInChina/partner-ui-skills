import { type Component, type PropType, type Ref } from 'vue';
import './aiIcons.css';
/** Trusted, locally imported Vue SVG components only; never SVG text, HTML or URLs.
 * inherit: currentColor ink; original: preserve multicolor; gradient: smart masks only. */
export type AiIconColor = 'inherit' | 'original' | 'gradient';
export interface AiIconDefinition {
    component: Component;
    color?: AiIconColor;
}
declare const defaults: {
    'assistant.fallback': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    'panel.mode': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            windowMode: {
                type: StringConstructor;
                default: undefined;
            };
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            windowMode: {
                type: StringConstructor;
                default: undefined;
            };
        }>> & Readonly<{}>, {
            windowMode: string;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    'panel.newConversation': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    'panel.history': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    'panel.fullscreen': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    'panel.exitFullscreen': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    'panel.close': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    'composer.voice': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    'composer.image': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    'composer.send': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    'composer.stop': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    'composer.mode': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
        color: "original";
    };
    'composer.expand': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    'composer.selected': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    'alert.error': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    'message.regenerate': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    'message.copy': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    'message.like': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    'message.dislike': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    'message.bookmark': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    'message.followUp': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    'history.clear': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    'history.search': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    'history.clearSearch': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    'history.pin': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    'history.more': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    'welcome.entry': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
        color: "original";
    };
    'smart.mark': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
        color: "gradient";
    };
    'business.navigate': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    'business.close': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    'business.success': {
        component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            active: BooleanConstructor;
        }>> & Readonly<{}>, {
            active: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
        color: "original";
    };
};
export type AiIconName = keyof typeof defaults;
export type AiIconMap = Partial<Record<AiIconName, Component | AiIconDefinition>>;
export declare const defaultAiIcons: Readonly<Record<AiIconName, Readonly<AiIconDefinition>>>;
type IconScope = Readonly<Ref<AiIconMap>>;
/** Internal scope adapter shared by panels and the public Provider. No global registry:
 * reactivity follows prop replacement/deep reactive edits, with nearest defined override. */
export declare function provideAiIcons(local: Readonly<Ref<AiIconMap | undefined>>): IconScope;
export declare function useAiIconDefinition(name: AiIconName): import("vue").ComputedRef<AiIconDefinition>;
/** Public icon slot adapter. A single SVG root preserves TinyRobot's native slot,
 * transitions and sizing selectors. No additional DOM wrapper or event owner. */
export declare const AiIcon: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    name: {
        type: PropType<AiIconName>;
        required: true;
    };
}>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    name: {
        type: PropType<AiIconName>;
        required: true;
    };
}>> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export declare const AiIconProvider: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    icons: {
        type: PropType<AiIconMap>;
        default: undefined;
    };
}>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>[] | undefined, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    icons: {
        type: PropType<AiIconMap>;
        default: undefined;
    };
}>> & Readonly<{}>, {
    icons: Partial<Record<"assistant.fallback" | "panel.mode" | "panel.newConversation" | "panel.history" | "panel.fullscreen" | "panel.exitFullscreen" | "panel.close" | "composer.voice" | "composer.image" | "composer.send" | "composer.stop" | "composer.mode" | "composer.expand" | "composer.selected" | "alert.error" | "message.regenerate" | "message.copy" | "message.like" | "message.dislike" | "message.bookmark" | "message.followUp" | "history.clear" | "history.search" | "history.clearSearch" | "history.pin" | "history.more" | "welcome.entry" | "smart.mark" | "business.navigate" | "business.close" | "business.success", AiIconDefinition | Component>>;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
/** TinyRobot renders icon/badge VNodes as dynamic components. Keep these detached
 * prop VNodes out of the caller's compiled block: otherwise Vue tracks an unmounted
 * copy there while TinyRobot owns its clone (null emitsOptions on updates).
 * Fresh VNodes + public createVNode isBlockNode prevent reuse/ownership collisions;
 * recheck this adapter with Vue/TinyRobot upgrades. No dependency DOM access. */
export declare function aiIconVNode(name: AiIconName, attrs?: Record<string, unknown>): import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>;
export {};
