/** Transient notifications; the host owns the result of any business operation. */
export type AiToastType = 'success' | 'error';
export interface AiToastProps {
    modelValue: boolean;
    message: string;
    type?: AiToastType;
    /** Milliseconds before dismissing; 0 keeps the notification open. */
    duration?: number;
}
