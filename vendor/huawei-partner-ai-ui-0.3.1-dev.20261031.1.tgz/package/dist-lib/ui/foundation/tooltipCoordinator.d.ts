type TooltipOwner = {
    close: () => void;
};
export declare function claimTooltip(owner: TooltipOwner, trigger: HTMLElement): void;
export declare function releaseTooltip(owner: TooltipOwner): void;
export {};
