import './actionTooltip.css';
type __VLS_Props = {
    trigger: HTMLElement;
    id: string;
    content: string;
    placement?: 'top' | 'bottom';
    disabled?: boolean;
    overflowOnly?: boolean;
    overflowSelector?: string;
    closeOnPointerLeave?: boolean;
};
declare const __VLS_export: import("vue").DefineComponent<__VLS_Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
