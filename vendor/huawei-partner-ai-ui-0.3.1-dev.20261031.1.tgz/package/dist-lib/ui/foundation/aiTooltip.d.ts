import { type Directive } from 'vue';
export type AiTooltipOptions = {
    content: string;
    placement?: 'top' | 'bottom';
    disabled?: boolean;
    overflowOnly?: boolean;
    overflowSelector?: string;
    closeOnPointerLeave?: boolean;
};
type Value = string | AiTooltipOptions | undefined;
export declare const vAiTooltip: Directive<HTMLElement, Value>;
export {};
