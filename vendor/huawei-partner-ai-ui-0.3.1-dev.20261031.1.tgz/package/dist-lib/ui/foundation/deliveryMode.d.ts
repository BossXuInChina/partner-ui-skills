import { type InjectionKey } from 'vue';
export declare const deliveryPreviewKey: InjectionKey<boolean>;
export declare function useDeliveryMode(): boolean;
