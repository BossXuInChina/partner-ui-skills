export declare function createRegionDrawerMotion(surface: HTMLElement, dialog: HTMLDialogElement, container: HTMLElement, key: string, release: (superseded: boolean) => void): {
    enter(): void;
    leave(removeNode: () => void): void;
};
