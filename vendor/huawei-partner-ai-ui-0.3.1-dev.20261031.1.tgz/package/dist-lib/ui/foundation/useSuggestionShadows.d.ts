import { type Ref } from 'vue';
type ShadowPaintOptions = {
    itemSelector: string;
    portSelector: string;
    nativeGutterOnly: boolean;
};
export declare function useSuggestionShadows(footer: Ref<HTMLElement | undefined>, source: () => unknown, options?: ShadowPaintOptions): {
    suggestionShadows: import("vue").ShallowRef<{
        key: number;
        style: Record<string, string>;
    }[], {
        key: number;
        style: Record<string, string>;
    }[]>;
    scheduleSuggestionShadows: () => void;
    shadowClipStyle: import("vue").ShallowRef<Record<string, string>, Record<string, string>>;
};
export {};
