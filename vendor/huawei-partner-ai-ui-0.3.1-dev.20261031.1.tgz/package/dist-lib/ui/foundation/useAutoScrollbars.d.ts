import './autoScrollbarStyles.css';
type Surface = {
    selector: string;
    axis: 'x' | 'y';
    hoverDelayMs?: number;
};
export declare function useAutoScrollbars(getRoot: () => HTMLElement | undefined, surfaces: Surface[]): void;
export {};
