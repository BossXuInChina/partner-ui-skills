/** REQ-022 v0.6: true native global modality, Workbench's 200ms opacity motion,
 * retained real DOM and interruption continuity. Native ::backdrop is animated
 * for UiDialog; the local full-screen Workbench shell already contains its mask.
 * Only declared popup controls/registered feedback are moved into the modal,
 * because a body portal outside a native modal is implicitly inert. */
export declare function createGlobalDialogMotion(surface: HTMLElement, dialog: HTMLDialogElement, key: string, release: (superseded: boolean) => void, options?: {
    nativeBackdrop?: boolean;
    drawer?: boolean;
    feedbackRoots?: () => HTMLElement[];
}): {
    enter(): void;
    leave(removeNode: () => void): void;
};
