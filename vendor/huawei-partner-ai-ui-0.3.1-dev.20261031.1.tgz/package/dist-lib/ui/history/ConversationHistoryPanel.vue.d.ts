import { type ConversationRecord } from './conversationHistory';
type __VLS_Props = {
    anchor: HTMLElement;
    open: boolean;
    records: ConversationRecord[];
    selected: string;
    busy: boolean;
    error: string;
    readFailed: boolean;
    blocked: boolean;
    clear: () => Promise<boolean>;
    remove: (id: string) => Promise<boolean>;
    select: (id: string) => Promise<boolean>;
};
declare const __VLS_export: import("vue").DefineComponent<__VLS_Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    close: () => any;
    pin: (id: string) => any;
    closed: () => any;
    reload: () => any;
}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{
    onClose?: (() => any) | undefined;
    onPin?: ((id: string) => any) | undefined;
    onClosed?: (() => any) | undefined;
    onReload?: (() => any) | undefined;
}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
