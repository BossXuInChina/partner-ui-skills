import type { UIMessage } from '../messages/chatContent';
import type { ComposerRequestContext } from '../composer/composerTypes';
import type { HistoryGroup } from '@opentiny/tiny-robot';
export interface ConversationViewState extends ComposerRequestContext {
    draft: string;
    scrollTop: number;
    followBottom: boolean;
}
export interface ConversationRecord {
    id: string;
    title: string;
    updatedAt: number;
    pinned: boolean;
    messages: UIMessage[];
    view: ConversationViewState;
    lastQuery: string;
    error: string;
    requestContext: ComposerRequestContext;
}
export interface ConversationSnapshot {
    version: 1;
    activeId: string;
    conversations: ConversationRecord[];
}
export interface ConversationStorage {
    read(namespace: string): Promise<ConversationSnapshot | null>;
    write(namespace: string, snapshot: ConversationSnapshot): Promise<void>;
}
export interface ConversationHistoryOptions {
    namespace?: string;
    storage?: ConversationStorage;
}
export declare const defaultHistoryNamespace = "partner-ai:agreement-history:v1";
export declare const emptyConversationView: () => ConversationViewState;
export declare const browserConversationStorage: ConversationStorage;
export declare function validateConversationSnapshot(value: ConversationSnapshot): ConversationSnapshot;
export declare function groupConversationHistory(records: ConversationRecord[], query: string, earlier: boolean, now?: number): HistoryGroup<ConversationRecord>[];
