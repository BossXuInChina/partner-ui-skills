import { type DropdownMenuItem } from '@opentiny/tiny-robot';
type __VLS_Props = {
    title: string;
    recordId: string;
    open: boolean;
    parentOpen: boolean;
    disabled: boolean;
};
declare const __VLS_export: import("vue").DefineComponent<__VLS_Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    close: () => any;
    toggle: () => any;
    action: (action: DropdownMenuItem) => any;
}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{
    onClose?: (() => any) | undefined;
    onToggle?: (() => any) | undefined;
    onAction?: ((action: DropdownMenuItem) => any) | undefined;
}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
