import type { WelcomeBusinessEntry } from '../composer/composerTypes';
import '../foundation/aiTokens.css';
export type { WelcomeBusinessEntry } from '../composer/composerTypes';
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<{
    avatarSrc?: string;
    fullscreen?: boolean;
    entries?: WelcomeBusinessEntry[];
}, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    select: (entry: WelcomeBusinessEntry) => any;
}, string, import("vue").PublicProps, Readonly<{
    avatarSrc?: string;
    fullscreen?: boolean;
    entries?: WelcomeBusinessEntry[];
}> & Readonly<{
    onSelect?: ((entry: WelcomeBusinessEntry) => any) | undefined;
}>, {
    entries: WelcomeBusinessEntry[];
    fullscreen: boolean;
    avatarSrc: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
