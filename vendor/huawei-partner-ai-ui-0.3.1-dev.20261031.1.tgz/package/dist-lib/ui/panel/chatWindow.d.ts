/** Window presentation belongs to the host, independently of the composer's business mode. */
export type ChatWindowMode = 'sidebar' | 'floating';
/** Host policy for a docked sidebar; floating/fullscreen retain their own geometry. */
export type ChatSidebarBehavior = 'push' | 'overlay';
