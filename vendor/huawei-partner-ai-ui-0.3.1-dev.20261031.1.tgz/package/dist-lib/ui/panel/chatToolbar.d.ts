/** Presentation-only actions. Consumers handle the event and inject any operation themselves. */
export interface ChatToolbarAction {
    id: string;
    label: string;
    disabled?: boolean;
}
