import type { ChatSuggestion, ChatSuggestionCollection } from './chatSuggestions';
type __VLS_Props = {
    item: ChatSuggestionCollection;
    disabled: boolean;
    dragging?: boolean;
};
declare const __VLS_export: import("vue").DefineComponent<__VLS_Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    select: (item: ChatSuggestion) => any;
}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{
    onSelect?: ((item: ChatSuggestion) => any) | undefined;
}>, {
    dragging: boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
