import type { ChatSuggestion, ChatSuggestionPill } from './chatSuggestions';
import '../foundation/aiTokens.css';
import './suggestionStyles.css';
type __VLS_Props = {
    items: ChatSuggestionPill[];
    disabled?: boolean;
    scrollbarVisible?: boolean;
};
declare const __VLS_export: import("vue").DefineComponent<__VLS_Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    select: (item: ChatSuggestion) => any;
}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{
    onSelect?: ((item: ChatSuggestion) => any) | undefined;
}>, {
    disabled: boolean;
    scrollbarVisible: boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
