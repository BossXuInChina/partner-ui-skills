import { type ComposerModeOption } from './ComposerModeSelect.vue';
import type { ComposerRequestContext } from './composerTypes';
import '../foundation/aiTokens.css';
export type { ComposerRequestContext } from './composerTypes';
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<{
    processing?: boolean;
    modeOptions?: ComposerModeOption[];
    placeholder?: string;
} & {
    modelValue?: string;
    aiEnabled?: boolean;
    mode?: string;
}, {
    focus: () => boolean | undefined;
    appendSuggestion: (query: string) => boolean;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    cancel: () => any;
    submit: (query: string, context: ComposerRequestContext) => any;
    "update:modelValue": (value: string) => any;
    "update:aiEnabled": (value: boolean) => any;
    "update:mode": (value: string) => any;
}, string, import("vue").PublicProps, Readonly<{
    processing?: boolean;
    modeOptions?: ComposerModeOption[];
    placeholder?: string;
} & {
    modelValue?: string;
    aiEnabled?: boolean;
    mode?: string;
}> & Readonly<{
    onCancel?: (() => any) | undefined;
    onSubmit?: ((query: string, context: ComposerRequestContext) => any) | undefined;
    "onUpdate:modelValue"?: ((value: string) => any) | undefined;
    "onUpdate:aiEnabled"?: ((value: boolean) => any) | undefined;
    "onUpdate:mode"?: ((value: string) => any) | undefined;
}>, {
    placeholder: string;
    processing: boolean;
    modeOptions: ComposerModeOption[];
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
