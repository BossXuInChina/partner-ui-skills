import { type Ref } from 'vue';
export declare function useSuggestionDrag(root: Ref<HTMLElement | undefined>): {
    dragPhase: Ref<"dragging" | "idle" | "armed", "dragging" | "idle" | "armed">;
    cancelDrag: () => void;
};
