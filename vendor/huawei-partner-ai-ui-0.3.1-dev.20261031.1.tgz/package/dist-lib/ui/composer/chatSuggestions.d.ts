import type { UIMessage } from '../messages/chatContent';
/** Caller-owned labels/queries. No sample choices or network capability in the product. */
export interface ChatSuggestion {
    id: string;
    label: string;
    query?: string;
    disabled?: boolean;
}
/** A caller-owned collection opens a picker; each child sends its selected query. */
export interface ChatSuggestionCollection {
    id: string;
    label: string;
    items: ChatSuggestion[];
    disabled?: boolean;
}
export type ChatSuggestionPill = ChatSuggestion | ChatSuggestionCollection;
/** Called only for completed assistant messages (state.completion === 'completed'). */
export type MessagePromptsResolver = (message: UIMessage) => ChatSuggestion[];
