import '../foundation/scrollbarStyles.css';
export type ThinkingStatus = 'thinking' | 'completed' | 'interrupted';
type __VLS_Props = {
    content: string;
    status: ThinkingStatus;
    expanded?: boolean;
    /** Motion stays active through final-answer display; body status is independent. */
    motionStatus?: ThinkingStatus;
    /** Compatibility image URL; scripted SVG uses the default inline motion. */
    motionAsset?: string;
    /** Preserve the progress row after interruption even before reasoning text arrives. */
    showEmptyInterrupted?: boolean;
};
declare const __VLS_export: import("vue").DefineComponent<__VLS_Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:expanded": (value: boolean) => any;
}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{
    "onUpdate:expanded"?: ((value: boolean) => any) | undefined;
}>, {
    expanded: boolean;
    motionStatus: ThinkingStatus;
    motionAsset: string;
    showEmptyInterrupted: boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
