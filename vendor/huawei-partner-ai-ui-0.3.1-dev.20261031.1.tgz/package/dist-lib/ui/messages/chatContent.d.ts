import type { BubbleMessage, ChatMessageContentItem } from '@opentiny/tiny-robot';
import type { ComposerRequestContext } from '../composer/composerTypes';
export type UIMessage<Part extends ChatMessageContentItem = ChatMessageContentItem> = BubbleMessage & {
    uiParts?: Part[]; /** New streams store the complete display sequence here; content retains transport text. */
    uiPartsOrdered?: boolean;
    renderContent?: ChatMessageContentItem[];
    reasoning_content?: string;
    thinkingStatus?: 'thinking' | 'completed' | 'interrupted';
    requestContext?: ComposerRequestContext;
    replyError?: string;
    recovering?: boolean;
};
/** Owner-persisted snapshot when Stop freezes answer presentation after transport.
 * Parts contain JSON-cloned source prefixes and already visible blocks, never DOM/getters. */
export interface ChatDisplayStopSnapshot {
    messageId?: string;
    messageIndex: number;
    parts: ChatMessageContentItem[];
}
export declare function hasChatOutput(message: UIMessage): boolean;
export declare function resolveChatContent(message: UIMessage): ChatMessageContentItem[];
