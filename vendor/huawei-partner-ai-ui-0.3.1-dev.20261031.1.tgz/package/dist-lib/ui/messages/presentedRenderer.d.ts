import { type Component } from 'vue';
import type { BubbleContentRendererProps } from '@opentiny/tiny-robot';
/** Keep public matches, attributes and events while sequencing their paint. */
export declare function presentedRenderer(renderer: Component<BubbleContentRendererProps>): Component<BubbleContentRendererProps>;
