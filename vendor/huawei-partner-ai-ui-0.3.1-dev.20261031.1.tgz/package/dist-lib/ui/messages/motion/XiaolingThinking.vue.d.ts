import type { XiaolingThinkingState } from './xiaolingThinking.js';
export type ThinkingMotionStatus = 'thinking' | 'completed' | 'interrupted';
declare const _default: typeof __VLS_export;
export default _default;
declare const __VLS_export: import("vue").DefineComponent<{
    status: ThinkingMotionStatus;
    size?: number | string;
    speed?: number;
    label?: string;
    respectReducedMotion?: boolean;
}, {
    start: () => void | undefined;
    finish: () => void | undefined;
    pause: () => void | undefined;
    resume: () => void | undefined;
    getFrame: () => number;
    getState: () => XiaolingThinkingState;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    settled: (frame: number, time: number) => any;
    "state-change": (state: XiaolingThinkingState, target: number | null) => any;
}, string, import("vue").PublicProps, Readonly<{
    status: ThinkingMotionStatus;
    size?: number | string;
    speed?: number;
    label?: string;
    respectReducedMotion?: boolean;
}> & Readonly<{
    onSettled?: ((frame: number, time: number) => any) | undefined;
    "onState-change"?: ((state: XiaolingThinkingState, target: number | null) => any) | undefined;
}>, {
    label: string;
    size: number | string;
    speed: number;
    respectReducedMotion: boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
