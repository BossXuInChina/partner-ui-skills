import { type ChatMessageContentItem, type BubbleBoxRendererProps } from '@opentiny/tiny-robot';
import { type ThinkingStatus } from './ThinkingContent.vue';
type __VLS_Props = BubbleBoxRendererProps & {
    replyKey: string;
    busy: boolean;
    loading: boolean;
    progressText?: string;
    stopped?: boolean;
    hasOutput?: boolean;
    failure?: string;
    canContinue?: boolean;
    active?: boolean;
    completion?: string;
    thinking?: {
        content: string;
        status: ThinkingStatus;
    };
    expectedParts?: {
        index: number;
        signature: string;
    }[];
};
declare var __VLS_12: {};
type __VLS_Slots = {} & {
    default?: (props: typeof __VLS_12) => any;
};
declare const __VLS_base: import("vue").DefineComponent<__VLS_Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    regenerate: () => any;
    continue: () => any;
    displayBusy: (value: boolean, capture?: (() => ChatMessageContentItem[]) | undefined) => any;
    displayChange: () => any;
    feedback: (value: {
        reasons: string[];
        detail: string;
    }) => any;
}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{
    onRegenerate?: (() => any) | undefined;
    onContinue?: (() => any) | undefined;
    onDisplayBusy?: ((value: boolean, capture?: (() => ChatMessageContentItem[]) | undefined) => any) | undefined;
    onDisplayChange?: (() => any) | undefined;
    onFeedback?: ((value: {
        reasons: string[];
        detail: string;
    }) => any) | undefined;
}>, {
    active: boolean;
    thinking: {
        content: string;
        status: ThinkingStatus;
    };
    placement: "start" | "end";
    completion: string;
    shape: "corner" | "rounded" | "none";
    progressText: string;
    stopped: boolean;
    hasOutput: boolean;
    failure: string;
    canContinue: boolean;
    expectedParts: {
        index: number;
        signature: string;
    }[];
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
declare const __VLS_export: __VLS_WithSlots<typeof __VLS_base, __VLS_Slots>;
declare const _default: typeof __VLS_export;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
