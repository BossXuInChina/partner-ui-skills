import type { ChatMessageContentItem } from '@opentiny/tiny-robot';
import type { ComputedRef, InjectionKey, Ref } from 'vue';
export interface AnswerDisplay {
    live: Ref<boolean>;
    epoch: Ref<number>;
    cancelled: ComputedRef<boolean>;
    failed: ComputedRef<boolean>;
    ready(index: number): boolean;
    acknowledge(index: number, signature: string): void;
    changed(): void;
    register(index: number, capture: () => ChatMessageContentItem | undefined): () => void;
}
export declare const answerDisplayKey: InjectionKey<AnswerDisplay>;
