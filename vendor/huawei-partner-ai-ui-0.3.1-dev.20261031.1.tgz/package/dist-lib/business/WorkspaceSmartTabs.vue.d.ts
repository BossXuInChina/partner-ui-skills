import type { WorkspaceSmartTab } from './workspaceSmartTabs';
import './workspaceIntelligence.css';
type __VLS_Props = {
    modelValue: string;
    items: readonly WorkspaceSmartTab[];
    ariaLabel?: string;
    align?: 'start' | 'center';
};
declare var __VLS_6: {
    item: WorkspaceSmartTab;
};
type __VLS_Slots = {} & {
    panel?: (props: typeof __VLS_6) => any;
};
declare const __VLS_base: import("vue").DefineComponent<__VLS_Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    change: (item: WorkspaceSmartTab) => any;
    "update:modelValue": (value: string) => any;
}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{
    onChange?: ((item: WorkspaceSmartTab) => any) | undefined;
    "onUpdate:modelValue"?: ((value: string) => any) | undefined;
}>, {
    ariaLabel: string;
    align: "start" | "center";
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
declare const __VLS_export: __VLS_WithSlots<typeof __VLS_base, __VLS_Slots>;
declare const _default: typeof __VLS_export;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
