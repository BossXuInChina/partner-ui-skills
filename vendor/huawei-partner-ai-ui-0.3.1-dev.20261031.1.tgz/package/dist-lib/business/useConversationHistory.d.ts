import { type Ref } from 'vue';
import type { UIMessage } from '../ui/messages/chatContent';
import type { ComposerRequestContext } from '../ui/composer/composerTypes';
import { type ConversationHistoryOptions, type ConversationRecord, type ConversationViewState } from '../ui/history/conversationHistory';
interface ConversationEngine {
    messages: Ref<UIMessage[]>;
    error: Ref<string>;
    lastQuery: Ref<string>;
    activeRequestContext: Ref<ComposerRequestContext>;
    reset(): Promise<void>;
    restore(messages: UIMessage[]): void;
    stopAndSnapshot(): Promise<UIMessage[]>;
    snapshotMessages(): UIMessage[];
}
export declare function useConversationHistory(engine: ConversationEngine, options?: ConversationHistoryOptions): {
    records: Ref<{
        id: string;
        title: string;
        updatedAt: number;
        pinned: boolean;
        messages: {
            name?: string | undefined;
            content?: string | {
                [x: string]: any;
                type: string;
            }[] | undefined;
            reasoning_content?: string | undefined;
            tool_calls?: {
                [x: string]: any;
                id: string;
                type: "function" | string;
                function: {
                    name: string;
                    arguments: string;
                };
            }[] | undefined;
            tool_call_id?: string | undefined;
            role?: string | undefined;
            id?: string | undefined;
            loading?: boolean | undefined;
            state?: Record<string, unknown> | undefined;
            uiParts?: {
                [x: string]: any;
                type: string;
            }[] | undefined;
            uiPartsOrdered?: boolean | undefined;
            renderContent?: {
                [x: string]: any;
                type: string;
            }[] | undefined;
            thinkingStatus?: "thinking" | "completed" | "interrupted" | undefined;
            requestContext?: {
                aiEnabled: boolean;
                mode: string;
            } | undefined;
            replyError?: string | undefined;
            recovering?: boolean | undefined;
        }[];
        view: {
            draft: string;
            scrollTop: number;
            followBottom: boolean;
            aiEnabled: boolean;
            mode: string;
        };
        lastQuery: string;
        error: string;
        requestContext: {
            aiEnabled: boolean;
            mode: string;
        };
    }[], ConversationRecord[] | {
        id: string;
        title: string;
        updatedAt: number;
        pinned: boolean;
        messages: {
            name?: string | undefined;
            content?: string | {
                [x: string]: any;
                type: string;
            }[] | undefined;
            reasoning_content?: string | undefined;
            tool_calls?: {
                [x: string]: any;
                id: string;
                type: "function" | string;
                function: {
                    name: string;
                    arguments: string;
                };
            }[] | undefined;
            tool_call_id?: string | undefined;
            role?: string | undefined;
            id?: string | undefined;
            loading?: boolean | undefined;
            state?: Record<string, unknown> | undefined;
            uiParts?: {
                [x: string]: any;
                type: string;
            }[] | undefined;
            uiPartsOrdered?: boolean | undefined;
            renderContent?: {
                [x: string]: any;
                type: string;
            }[] | undefined;
            thinkingStatus?: "thinking" | "completed" | "interrupted" | undefined;
            requestContext?: {
                aiEnabled: boolean;
                mode: string;
            } | undefined;
            replyError?: string | undefined;
            recovering?: boolean | undefined;
        }[];
        view: {
            draft: string;
            scrollTop: number;
            followBottom: boolean;
            aiEnabled: boolean;
            mode: string;
        };
        lastQuery: string;
        error: string;
        requestContext: {
            aiEnabled: boolean;
            mode: string;
        };
    }[]>;
    activeId: Ref<string, string>;
    view: import("vue").ComputedRef<ConversationViewState>;
    ready: Ref<boolean, boolean>;
    busy: Ref<boolean, boolean>;
    storageError: Ref<string, string>;
    readFailed: Ref<boolean, boolean>;
    load: () => Promise<void>;
    flush: () => Promise<boolean>;
    change: (id?: string) => Promise<boolean>;
    pin: (id: string) => Promise<void>;
    clear: () => Promise<boolean>;
    remove: (id: string) => Promise<boolean>;
    updateView: (value: ConversationViewState) => void;
};
export {};
