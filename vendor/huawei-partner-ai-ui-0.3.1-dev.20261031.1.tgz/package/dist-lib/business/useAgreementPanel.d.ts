import type { BubbleContentRendererMatch, BubbleEvent } from '@opentiny/tiny-robot';
import type { Agreement, AgreementAssistantAdapter } from '../adapters/contracts';
import type { ConversationHistoryOptions } from '../ui/history/conversationHistory';
import { type AgreementBusinessAction, type BusinessActionMode, type WorkspaceNavigation } from '../host/businessAction';
export declare function useAgreementPanel(props: {
    adapter: AgreementAssistantAdapter;
    autoStart: boolean;
    historyOptions?: ConversationHistoryOptions;
    businessActionMode?: BusinessActionMode;
}, emit: (type: 'status', state: {
    dirty: boolean;
    busy: boolean;
}) => void, onBusinessAction?: (action: AgreementBusinessAction) => void, onWorkspaceNavigate?: (navigation: WorkspaceNavigation) => void): {
    scopeId: string;
    messages: import("vue").ComputedRef<import("../index.ts").UIMessage<import("../index.ts").AssistantPart>[]>;
    isProcessing: import("vue").ComputedRef<boolean>;
    requestState: import("vue").ComputedRef<import("@opentiny/tiny-robot-kit").RequestState>;
    send: (query: string, context?: import("../index.ts").ComposerRequestContext) => Promise<void>;
    retry: () => Promise<void>;
    abortRequest: (snapshot?: import("../index.ts").ChatDisplayStopSnapshot) => Promise<void>;
    reset: () => Promise<void>;
    resetting: import("vue").Ref<boolean, boolean>;
    activeRequestContext: import("vue").Ref<{
        aiEnabled: boolean;
        mode: string;
    }, import("../index.ts").ComposerRequestContext | {
        aiEnabled: boolean;
        mode: string;
    }>;
    error: import("vue").Ref<string, string>;
    selected: import("vue").Ref<{
        id: string;
        name: string;
        partner: string;
        owner: string;
        endDate: string;
        amount: string;
        status: "\u5F85\u7EED\u7B7E" | "\u5BA1\u6279\u4E2D" | "\u5DF2\u7EED\u7B7E";
    } | null, Agreement | {
        id: string;
        name: string;
        partner: string;
        owner: string;
        endDate: string;
        amount: string;
        status: "\u5F85\u7EED\u7B7E" | "\u5BA1\u6279\u4E2D" | "\u5DF2\u7EED\u7B7E";
    } | null>;
    originalOwner: import("vue").Ref<string, string>;
    confirmation: import("vue").Ref<{
        id: string;
        name: string;
        partner: string;
        owner: string;
        endDate: string;
        amount: string;
        status: "\u5F85\u7EED\u7B7E" | "\u5BA1\u6279\u4E2D" | "\u5DF2\u7EED\u7B7E";
    } | null, Agreement | {
        id: string;
        name: string;
        partner: string;
        owner: string;
        endDate: string;
        amount: string;
        status: "\u5F85\u7EED\u7B7E" | "\u5BA1\u6279\u4E2D" | "\u5DF2\u7EED\u7B7E";
    } | null>;
    discard: import("vue").Ref<boolean, boolean>;
    operationBusy: import("vue").Ref<boolean, boolean>;
    operationError: import("vue").Ref<string, string>;
    toast: import("vue").Ref<string, string>;
    dirty: import("vue").ComputedRef<boolean>;
    records: import("vue").ComputedRef<Agreement[]>;
    pendingCount: import("vue").ComputedRef<number>;
    renderers: BubbleContentRendererMatch[];
    currentStatus: () => {
        dirty: boolean;
        busy: boolean;
    };
    discardDraft: () => void;
    applyBusinessUpdate: (agreement: Agreement) => void;
    handleEvent: (event: BubbleEvent) => void;
    closeDrawer: () => void;
    saveEdit: () => Promise<void>;
    confirmRenew: () => Promise<void>;
    newConversation: () => Promise<boolean>;
    history: {
        records: import("vue").Ref<{
            id: string;
            title: string;
            updatedAt: number;
            pinned: boolean;
            messages: {
                name?: string | undefined;
                content?: string | {
                    [x: string]: any;
                    type: string;
                }[] | undefined;
                reasoning_content?: string | undefined;
                tool_calls?: {
                    [x: string]: any;
                    id: string;
                    type: "function" | string;
                    function: {
                        name: string;
                        arguments: string;
                    };
                }[] | undefined;
                tool_call_id?: string | undefined;
                role?: string | undefined;
                id?: string | undefined;
                loading?: boolean | undefined;
                state?: Record<string, unknown> | undefined;
                uiParts?: {
                    [x: string]: any;
                    type: string;
                }[] | undefined;
                uiPartsOrdered?: boolean | undefined;
                renderContent?: {
                    [x: string]: any;
                    type: string;
                }[] | undefined;
                thinkingStatus?: "thinking" | "completed" | "interrupted" | undefined;
                requestContext?: {
                    aiEnabled: boolean;
                    mode: string;
                } | undefined;
                replyError?: string | undefined;
                recovering?: boolean | undefined;
            }[];
            view: {
                draft: string;
                scrollTop: number;
                followBottom: boolean;
                aiEnabled: boolean;
                mode: string;
            };
            lastQuery: string;
            error: string;
            requestContext: {
                aiEnabled: boolean;
                mode: string;
            };
        }[], import("../index.ts").ConversationRecord[] | {
            id: string;
            title: string;
            updatedAt: number;
            pinned: boolean;
            messages: {
                name?: string | undefined;
                content?: string | {
                    [x: string]: any;
                    type: string;
                }[] | undefined;
                reasoning_content?: string | undefined;
                tool_calls?: {
                    [x: string]: any;
                    id: string;
                    type: "function" | string;
                    function: {
                        name: string;
                        arguments: string;
                    };
                }[] | undefined;
                tool_call_id?: string | undefined;
                role?: string | undefined;
                id?: string | undefined;
                loading?: boolean | undefined;
                state?: Record<string, unknown> | undefined;
                uiParts?: {
                    [x: string]: any;
                    type: string;
                }[] | undefined;
                uiPartsOrdered?: boolean | undefined;
                renderContent?: {
                    [x: string]: any;
                    type: string;
                }[] | undefined;
                thinkingStatus?: "thinking" | "completed" | "interrupted" | undefined;
                requestContext?: {
                    aiEnabled: boolean;
                    mode: string;
                } | undefined;
                replyError?: string | undefined;
                recovering?: boolean | undefined;
            }[];
            view: {
                draft: string;
                scrollTop: number;
                followBottom: boolean;
                aiEnabled: boolean;
                mode: string;
            };
            lastQuery: string;
            error: string;
            requestContext: {
                aiEnabled: boolean;
                mode: string;
            };
        }[]>;
        activeId: import("vue").Ref<string, string>;
        view: import("vue").ComputedRef<import("../index.ts").ConversationViewState>;
        ready: import("vue").Ref<boolean, boolean>;
        busy: import("vue").Ref<boolean, boolean>;
        storageError: import("vue").Ref<string, string>;
        readFailed: import("vue").Ref<boolean, boolean>;
        load: () => Promise<void>;
        flush: () => Promise<boolean>;
        change: (id?: string) => Promise<boolean>;
        pin: (id: string) => Promise<void>;
        clear: () => Promise<boolean>;
        remove: (id: string) => Promise<boolean>;
        updateView: (value: import("../index.ts").ConversationViewState) => void;
    };
    switchConversation: (id?: string) => Promise<boolean>;
    clearHistory: () => Promise<boolean>;
    removeConversation: (id: string) => Promise<boolean>;
};
