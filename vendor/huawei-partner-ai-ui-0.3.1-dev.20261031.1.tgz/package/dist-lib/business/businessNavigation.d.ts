import type { WorkspaceNavigation } from '../host/businessAction';
/** REQ-023 uses the host's REQ-022 navigation contract, avoiding a second router.
 * target is a host-owned key. Emission requests navigation; it is not success. */
export type BusinessNavigationTarget = WorkspaceNavigation;
export type BusinessNavigationEvent = {
    name: 'workspace:navigate';
    payload: BusinessNavigationTarget;
};
