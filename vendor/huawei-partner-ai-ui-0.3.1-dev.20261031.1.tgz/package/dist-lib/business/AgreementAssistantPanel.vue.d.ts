import { type BubbleContentRendererMatch } from '@opentiny/tiny-robot';
import { type AiIconMap } from '../ui/foundation/aiIcons';
import type { AgreementAssistantAdapter } from '../adapters/contracts';
import type { ChatWindowMode } from '../ui/panel/chatWindow';
import type { ChatToolbarAction } from '../ui/panel/chatToolbar';
import type { ComposerModeOption, ComposerRequestContext, WelcomeBusinessEntry } from '../ui/composer/composerTypes';
import type { ChatSuggestionPill, MessagePromptsResolver } from '../ui/composer/chatSuggestions';
import type { ConversationHistoryOptions } from '../ui/history/conversationHistory';
import type { AgreementBusinessAction, BusinessActionMode, BusinessDialogScope, WorkspaceNavigation } from '../host/businessAction';
type __VLS_Props = {
    icons?: AiIconMap;
    businessActionMode?: BusinessActionMode;
    businessDialogScope?: BusinessDialogScope;
    windowMode?: ChatWindowMode;
    fullscreen?: boolean;
    adapter: AgreementAssistantAdapter;
    theme?: 'workbench' | 'aurora';
    autoStart?: boolean;
    avatarSrc?: string;
    toolbarActions?: ChatToolbarAction[];
    modeOptions?: ComposerModeOption[];
    welcomeEntries?: WelcomeBusinessEntry[];
    suggestionPills?: ChatSuggestionPill[];
    messagePrompts?: MessagePromptsResolver;
    historyOptions?: ConversationHistoryOptions;
    contentRenderers?: BubbleContentRendererMatch[];
};
declare function newConversation(): Promise<void>;
declare function resetAll(): Promise<void>;
declare function canSendQuery(): boolean;
declare function sendQuery(query: string, context?: ComposerRequestContext): Promise<boolean>;
declare function getMessages(): {
    id: string;
    name?: string | undefined;
    content?: import("@opentiny/tiny-robot").ChatMessageContent | undefined;
    reasoning_content?: string;
    tool_calls?: import("@opentiny/tiny-robot").ToolCall[] | undefined;
    tool_call_id?: string | undefined;
    role?: string;
    loading?: boolean;
    state?: Record<string, unknown> | undefined;
    uiParts?: import("../index.ts").AssistantPart[] | undefined;
    uiPartsOrdered?: boolean;
    renderContent?: import("@opentiny/tiny-robot").ChatMessageContentItem[];
    thinkingStatus?: "thinking" | "completed" | "interrupted";
    requestContext?: ComposerRequestContext;
    replyError?: string;
    recovering?: boolean;
}[];
declare var __VLS_31: {};
type __VLS_Slots = {} & {
    'toolbar-end'?: (props: typeof __VLS_31) => any;
};
declare const __VLS_base: import("vue").DefineComponent<__VLS_Props, {
    applyBusinessUpdate: (agreement: import("../index.ts").Agreement) => void;
    currentStatus: () => {
        dirty: boolean;
        busy: boolean;
    };
    discardDraft: () => void;
    reset: typeof resetAll;
    newConversation: typeof newConversation;
    canSendQuery: typeof canSendQuery;
    sendQuery: typeof sendQuery;
    getMessages: typeof getMessages;
    locateReply: (id: string) => Promise<boolean> | undefined;
    start: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    status: (state: {
        dirty: boolean;
        busy: boolean;
    }) => any;
    windowModeChange: (mode: ChatWindowMode) => any;
    fullscreenChange: (value: boolean) => any;
    windowDragStart: (event: PointerEvent) => any;
    windowDragKeydown: (event: KeyboardEvent) => any;
    toolbarAction: (action: ChatToolbarAction) => any;
    composerChange: (context: ComposerRequestContext) => any;
    welcomeAction: (entry: WelcomeBusinessEntry) => any;
    businessAction: (action: AgreementBusinessAction) => any;
    workspaceNavigate: (navigation: WorkspaceNavigation) => any;
}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{
    onStatus?: ((state: {
        dirty: boolean;
        busy: boolean;
    }) => any) | undefined;
    onWindowModeChange?: ((mode: ChatWindowMode) => any) | undefined;
    onFullscreenChange?: ((value: boolean) => any) | undefined;
    onWindowDragStart?: ((event: PointerEvent) => any) | undefined;
    onWindowDragKeydown?: ((event: KeyboardEvent) => any) | undefined;
    onToolbarAction?: ((action: ChatToolbarAction) => any) | undefined;
    onComposerChange?: ((context: ComposerRequestContext) => any) | undefined;
    onWelcomeAction?: ((entry: WelcomeBusinessEntry) => any) | undefined;
    onBusinessAction?: ((action: AgreementBusinessAction) => any) | undefined;
    onWorkspaceNavigate?: ((navigation: WorkspaceNavigation) => any) | undefined;
}>, {
    fullscreen: boolean;
    windowMode: ChatWindowMode;
    icons: Partial<Record<"assistant.fallback" | "panel.mode" | "panel.newConversation" | "panel.history" | "panel.fullscreen" | "panel.exitFullscreen" | "panel.close" | "composer.voice" | "composer.image" | "composer.send" | "composer.stop" | "composer.mode" | "composer.expand" | "composer.selected" | "alert.error" | "message.regenerate" | "message.copy" | "message.like" | "message.dislike" | "message.bookmark" | "message.followUp" | "history.clear" | "history.search" | "history.clearSearch" | "history.pin" | "history.more" | "welcome.entry" | "smart.mark" | "business.navigate" | "business.close" | "business.success", import("../index.ts").AiIconDefinition | import("vue").Component>>;
    theme: "workbench" | "aurora";
    modeOptions: ComposerModeOption[];
    avatarSrc: string;
    toolbarActions: ChatToolbarAction[];
    welcomeEntries: WelcomeBusinessEntry[];
    suggestionPills: ChatSuggestionPill[];
    messagePrompts: MessagePromptsResolver;
    businessActionMode: BusinessActionMode;
    businessDialogScope: BusinessDialogScope;
    autoStart: boolean;
    historyOptions: ConversationHistoryOptions;
    contentRenderers: BubbleContentRendererMatch[];
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
declare const __VLS_export: __VLS_WithSlots<typeof __VLS_base, __VLS_Slots>;
declare const _default: typeof __VLS_export;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
