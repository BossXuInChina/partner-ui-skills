import type { BusinessNavigationTarget } from '../adapters/contracts';
type __VLS_Props = {
    title: string;
    description?: string;
    target: BusinessNavigationTarget;
};
declare const __VLS_export: import("vue").DefineComponent<__VLS_Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    navigate: (target: import("..").WorkspaceNavigation) => any;
}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{
    onNavigate?: ((target: import("..").WorkspaceNavigation) => any) | undefined;
}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
