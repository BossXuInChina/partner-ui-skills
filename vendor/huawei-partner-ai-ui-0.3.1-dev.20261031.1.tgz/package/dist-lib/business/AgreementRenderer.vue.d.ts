import { type BubbleContentRendererProps } from '@opentiny/tiny-robot';
import type { Agreement } from '../adapters/contracts';
type __VLS_Props = BubbleContentRendererProps;
declare var __VLS_24: {
    agreement: Agreement;
};
type __VLS_Slots = {} & {
    'table-status'?: (props: typeof __VLS_24) => any;
};
declare const __VLS_base: import("vue").DefineComponent<__VLS_Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
declare const __VLS_export: __VLS_WithSlots<typeof __VLS_base, __VLS_Slots>;
declare const _default: typeof __VLS_export;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
