import { type UseMessageOptions } from '@opentiny/tiny-robot-kit';
import type { Agreement, AgreementAssistantAdapter, AssistantPart } from '../adapters/contracts';
import { type ChatDisplayStopSnapshot, type UIMessage } from '../ui/messages/chatContent';
import type { ComposerRequestContext } from '../ui/composer/composerTypes';
export declare function useAgreementAssistant(adapter: AgreementAssistantAdapter): {
    isProcessing: import("vue").ComputedRef<boolean>;
    requestState: import("vue").ComputedRef<import("@opentiny/tiny-robot-kit").RequestState>;
    abortRequest: (snapshot?: ChatDisplayStopSnapshot) => Promise<void>;
    messages: import("vue").ComputedRef<UIMessage<AssistantPart>[]>;
    error: import("vue").Ref<string, string>;
    lastQuery: import("vue").Ref<string, string>;
    send: (query: string, context?: ComposerRequestContext) => Promise<void>;
    reset: () => Promise<void>;
    restore: (history: UIMessage[]) => void;
    snapshotMessages: () => UIMessage<AssistantPart>[];
    stopAndSnapshot: () => Promise<UIMessage[]>;
    resetting: import("vue").Ref<boolean, boolean>;
    activeRequestContext: import("vue").Ref<{
        aiEnabled: boolean;
        mode: string;
    }, ComposerRequestContext | {
        aiEnabled: boolean;
        mode: string;
    }>;
    regenerate: (index: number) => Promise<void>;
    continueReply: (index: number) => Promise<void>;
    updateRecord: (record: Agreement) => void;
    retry: () => Promise<void>;
    processingState: import("vue").Ref<import("@opentiny/tiny-robot-kit").RequestProcessingState | undefined>;
    responseProvider: import("vue").Ref<UseMessageOptions["responseProvider"]>;
    sendMessage: (content: string) => Promise<void>;
};
