import type { IntelligenceLogo, IntelligenceFragment } from './workspaceIntelligence';
type __VLS_Props = {
    fragments: readonly IntelligenceFragment[];
    logo?: IntelligenceLogo;
    autoFollowHighlight?: boolean;
};
declare const __VLS_export: import("vue").DefineComponent<__VLS_Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    activate: () => any;
    highlightCenter: (center: {
        x: number;
        y: number;
    }) => any;
}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{
    onActivate?: (() => any) | undefined;
    onHighlightCenter?: ((center: {
        x: number;
        y: number;
    }) => any) | undefined;
}>, {
    autoFollowHighlight: boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
declare const _default: typeof __VLS_export;
export default _default;
