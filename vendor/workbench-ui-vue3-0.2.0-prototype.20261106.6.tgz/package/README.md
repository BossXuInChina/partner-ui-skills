# Vue 3 组件包

`@workbench/ui-vue3` 当前仍为开发资格，准确版本与通道以 [package.json](package.json) 和随包的 `release.json` 为准。包清单声明 ESM、类型和显式 CSS 入口；Vue 是 peer dependency。组件库稳定发布通过独立发布检查，业务目标接入另行验证；`productionEligible=false` 继续表示没有业务目标生产资格。当前尚未发布到包注册表。

本包是外部 Workbench 的设计/demo 实现，不是公司内部 AUI 生产源码；公司卡片包与宿主接入边界见[项目入口](../../README.md)。

## 2026-10-22 登记快照与验证

本批增加 `WorkbenchSteps`、`WorkbenchFooter`、`WorkbenchTree`、`WorkbenchTimeline`、`WorkbenchTransfer`、`WorkbenchCascader`、`WorkbenchDatePicker`、`WorkbenchTimePicker`、`WorkbenchImageUpload`、`WorkbenchUpload`。关联公开辅助导出为 `WorkbenchTransferPanel`、`WorkbenchCascaderPanel`、`WorkbenchCascaderOverflow`、`WorkbenchDatePanel`、`WorkbenchImageUploadTile`、`WorkbenchUploadFileItem`、`WorkbenchUploadFileList`；资格继承各自原型资产，API 以生成索引为准。

旧场景组件转发到公开包，消费者仍须显式导入 `@workbench/ui-vue3/styles.css`；Cascader 独立预览曾因漏载该 CSS 失败，已修复并真实复验。新增 10 项实现无 Candidate/Studio 运行时依赖，生成 Catalog/API 与依赖边界检查通过。人工视觉验收仍 pending，生产 Registry 与包版本没有因本次登记自动提升。

本轮官方独立消费者流程在两套仓外安装中通过类型、构建、浏览器及 JS/声明/exports/CSS 负例，共 17 项通过；随后 prototype-export 因仓库 Breadcrumb 格式门禁失败，整体验收为 FAIL。Source 交付依赖收集仍有 PreviewPanel 路径与外部依赖支持缺口，不能把 dist 消费成功当作 Source 验收。ImageUpload 使用的 fflate 在 dist 中打包；依赖审计仍记录其解压 API 公告，当前组件只调用压缩 API，具体适用性需独立评估。

完整当前结果、失败和耗时见 [本地审查](../../.artifacts/runs/WB-BATCH-REGISTER-AUDIT-20261022/AUDIT.md)。本节是当前登记/测试快照；下方历史交付证据不能覆盖后续源码变化。

## 构建与消费

在仓库根目录执行：

```bash
pnpm install --frozen-lockfile
pnpm run ui:build
pnpm run test:package-consumer
```

消费方从公开入口导入组件，并在自己的入口显式加载样式：

```ts
import { WorkbenchButton, WorkbenchForm, WorkbenchFormItem, WorkbenchTable } from '@workbench/ui-vue3';
import '@workbench/ui-vue3/styles.css';
```

构建将生成的 Foundation/Catalog 样式与组件样式打入 `dist/styles.css`，中立 UI 类型声明随产物编译，消费者不需要引用本仓私有源码、生成目录或内部合同包。字体文件不在 UI 包内；消费方需自行提供符合许可和设计要求的字体。

[源码入口](src/index.ts) 是导出实现的单一来源；产物由 [构建器](../../harness/scripts/build-ui-package.mjs) 生成。Form、Card、Table、Message、Skeleton、Collapse 的组合支持 API 继承所属资产的资格；内部子部件不因此全部变成公开组件。API 与家族映射以 [调用契约索引](../../studio/generated/component-api.json) 为准，源码路径保留用于 Inspector 定位，不能作为跨包执行入口。

## 验证边界

`test:package-consumer` 在新建仓外目录安装冻结 tarball，并自行安装构建、类型及浏览器工具；再次执行冻结离线安装。它验证模块解析、真实交互、Teleport 样式及缺失 JS、类型、exports、CSS 的负例。类型正反例使用真实 `vue-tsc`，不以通配声明掩盖错误。路径与解析图检查不代表操作系统沙箱。

工程消费闭包已经有 G4 定向证据；最终集成验证和对应提交的 CI 状态需单独核验。真实内网运行、生产资格、P5 与人工设计批准不由这些测试授予。早期未晋升的 Select 扩展属于历史 Draft 记录；本轮已有 Select 的登记快照已更新，当前公开 API 以源码入口和生成契约为准。

## 项目版本与两种交付模式

Harness 项目基线 0.2.0 不等于本包版本；本包准确版本仍由自身清单声明。开发工程可选择精选组件 Source 交付或公开 dist Package 消费；包方式保留公开导入及显式 styles.css，安装冻结 tarball 并验证实际解析位置。此前记录的两种方式完整本地验收是历史证据，不覆盖当前工作区；2026-10-22 的失败边界见上方快照。本包仍为私有原型资格，未向注册表发布，也未取得真实目标生产资格。

## 组件包独立验证

`pnpm run test:library-consumer` 仅验证公开包：两次仓外安装（含冻结离线安装）、类型、构建、真实浏览器交互及缺失产物负例。收据明确 `validationScope=package-only`，通过不授予资产批准、稳定发布或业务生产资格。

`test:package-consumer` 与 `test:library-consumer` 现在都执行包验证；`test:prototype-consumer` 保留包消费及页面原型导出重建的完整链路。`verify` 默认验证组件库维护，`verify:full` 保留整仓集成检查及原型交付验证。

## 可读取的设计与调用资料

运行所需 Token 已包含在 `styles.css` 中。构建同步生成并通过公开子入口提供：

- `@workbench/ui-vue3/tokens.json`：语义 Token、主题值及 CSS 变量；与实际样式逐项核对。
- `@workbench/ui-vue3/components.json`：公开组件、Block、运行时 Pattern、图标帮助器及 Props、Events、Slots、实例方法与组合规则。
- `@workbench/ui-vue3/release.json`：包版本、组件库通道、范围和业务目标资格。

上述资料从现有真值及真实实现生成，不要求消费方读取本仓库源码或 Studio。公开资料不包含内部实现和过程路径。当前仍是 development 通道，生成清单本身不授予稳定发布资格。

## 稳定包准备

`pnpm run library:release -- --version <正式版本> --output <新目录> --approval <发布批准记录>` 验证全部公开运行时资产及其依赖、当前 Catalog 批准、源码指纹和实际人工来源。随后在新目录准备包，检查独立安装、类型、构建、浏览器和缺失产物反例，输出带哈希的 tarball 与收据。缺失或过期证据会阻断；当前源码清单与历史批准保持原样。这个命令不会自动发布到注册表。
