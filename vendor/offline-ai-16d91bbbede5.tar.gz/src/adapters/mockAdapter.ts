import { reactive } from 'vue';
import type { AgreementAssistantAdapter, AssistantDelta, AssistantPart } from './contracts';
import { agreements } from '../data/agreements';
import { typographyReply } from '../data/messageTypography';
import { businessNavigationExampleQuery, businessNavigationExamplePart, welcomeExampleQueries, welcomeGuideBeforeNavigation, welcomeGuideNavigationParts, welcomeGuideAfterNavigation, welcomeTableCalculation } from '../data/welcomeExamples';
export type MockScenario = 'ready' | 'loading' | 'empty' | 'error' | 'long' | 'unknown' | 'typography' | 'interrupted' | 'resumable';
export type MockOptions = { scenario: MockScenario; delay: number; failSave?: boolean; failRenew?: boolean };
export function delay(ms: number, signal: AbortSignal): Promise<void> {
  signal.throwIfAborted();
  return new Promise((resolve, reject) => {
    const onAbort = () => { clearTimeout(timer); reject(new DOMException('已中止', 'AbortError')); };
    const timer = setTimeout(() => { signal.removeEventListener('abort', onAbort); resolve(); }, ms);
    signal.addEventListener('abort', onAbort, { once: true });
  });
}
function thinkingPart(content: string, status: 'thinking' | 'completed' | 'interrupted'): AssistantPart {
  // Demo-only serializable envelope; keep the public AssistantPart domain union unchanged.
  return {type:'unsupported',originalType:'thinking-content',content,status} as AssistantPart;
}
/** This module belongs to preview tooling and is excluded from src/index.ts and the library build. */
export function createMockAdapter(options: MockOptions): AgreementAssistantAdapter & { stats: { searches: number; saves: number; renewals: number } } {
  const records = structuredClone(agreements);
  const stats = reactive({ searches: 0, saves: 0, renewals: 0 });
  const completed = new Map<string, typeof agreements[number]>();
  const find = (id: string) => { const item = records.find(item => item.id === id); if (!item) throw new Error('未找到协议'); return item; };
  return {
    stats,
    async *stream(query, signal, context): AsyncGenerator<AssistantDelta> {
      stats.searches++;
      if (query === '演示思考流程') {
        const disclaimer = '以下是本地演示文本，仅用于展示思考内容组件，不代表模型内部思维。';
        const thought = `${disclaimer}\n\n先把问题拆成目标、约束和需要核验的信息，再按优先级组织答复。\n\n本次界面演示会持续追加较长内容，用来观察思考中的高度上限、内部滚动和底部跟随行为。用户如果向上查看较早的内容，后续更新会保留当前位置，不会强行拉回底部。\n\n演示完成后正文会自动收起；点击“已完成思考”可查看完整内容，展开后正文自然增长，不再限制高度。这个过程只驱动本地模拟数据，不调用模型或业务接口。\n\n最后，回复区域会给出一段普通文本，供核对思考展示与常规消息内容的顺序。`;
        yield {kind:'part',part:thinkingPart('', 'thinking')};
        for (let offset=0; offset<thought.length; offset+=32) {
          await delay(Math.max(90, options.delay * 2),signal);
          yield {kind:'part',part:thinkingPart(thought.slice(0,offset+32), 'thinking')};
        }
        await delay(Math.max(90, options.delay * 2),signal);
        yield {kind:'part',part:thinkingPart(thought, 'completed')};
        await delay(Math.max(90, options.delay * 2),signal);
        const answer='本地模拟答复：思考区已完成并收起。你可以展开检查完整正文；此回复不代表真实模型输出。';
        for (let offset=0;offset<answer.length;offset+=4) {
          signal.throwIfAborted();
          yield {kind:'text',text:answer.slice(offset,offset+4)};
          await delay(Math.max(45,options.delay),signal);
        }
        return;
      }
      await delay(options.scenario === 'loading' ? 4000 : options.delay * 2, signal);
      if (['interrupted','resumable'].includes(options.scenario) && stats.searches===1) {
        yield {kind:'text',text:'已保留的本地模拟内容：请先核对协议负责人。'};
        await delay(options.delay,signal); throw new Error('本地模拟连接中断。');
      }
      if ((options.scenario === 'error' && stats.searches === 1) || query.includes('模拟失败')) throw new Error('查询服务暂时不可用，请重试。');
      // REQ-003 prototype routing: explicit AI requests get a local mock preface only. No LLM
      // endpoint, microphone, image upload or persistence is connected by this adapter.
      if (context?.aiEnabled) yield {kind:'text',text:`本地 AI 问答演示（模式：${context.mode || '未选择'}）。以下内容为本地模拟回复。\n\n`};
      const summaryPart = { type:'ai-summary', text:`建议优先核对近期到期的 ${records.length} 份协议，确认负责人及续签意向，再安排评审与续签申请。对审批中的协议持续跟进进度，避免重复发起。` } as const;
      // REQ-023: a serializable intent, never a URL or a fake successful jump.
      if (query === businessNavigationExampleQuery) {
        yield { kind:'text', text:'可打开本地续签作业区，筛选虚构伙伴协议并查看详情。' };
        yield { kind:'part', part:structuredClone(businessNavigationExamplePart) }; return;
      }
      // Everyday demo collection questions get matching local replies; selecting
      // an option only fills Sender, and this branch runs after explicit send.
      if (query === '查看续签材料准备指引') {
        yield {kind:'text',text:'续签材料准备（本地模拟）：\n\n1. 整理原协议及到期信息。\n2. 确认续签范围、期限和双方负责人。\n3. 补充服务调整说明与预算测算。\n4. 记录待伙伴确认事项，再按实际流程安排评审。\n\n以上仅为虚构业务示例，不代表正式材料要求。'};
        return;
      }
      if (query === '查看续签办理流程') {
        yield {kind:'text',text:'续签办理流程（本地模拟）：\n\n1. 核对待续签协议与双方负责人。\n2. 确认合作范围、期限和续签意向。\n3. 整理材料及示例预算，安排内部评审。\n4. 根据实际审批结果办理续签并跟进状态。\n\n此处不会提交真实申请，具体流程以业务系统为准。'};
        return;
      }
      // REQ-020 v0.4: three exact welcome queries select distinct local outputs.
      // Return after each example; REQ-023 explicitly adds navigation under H2
      // only in the guide, without leaking summary/agreement result cards into it.
      if (query === welcomeExampleQueries.summary) {
        yield {kind:'part',part:summaryPart};
        yield {kind:'text',text:'已结合近期到期协议整理伙伴续签建议。'}; return;
      }
      if (query === welcomeExampleQueries.text) {
        for (const section of welcomeGuideBeforeNavigation.split('\n\n')) { await delay(options.delay,signal); yield {kind:'text',text:section+'\n\n'}; }
        for (const part of welcomeGuideNavigationParts) yield {kind:'part',part:structuredClone(part)};
        await delay(options.delay,signal);
        yield {kind:'part',part:{type:'text',text:welcomeGuideAfterNavigation}};
        return;
      }
      if (query === welcomeExampleQueries.business) {
        yield {kind:'text',text:'以下为虚构伙伴协议的续签预算示例，可横向查看各字段并核对金额测算。'};
        yield {kind:'part',part:{type:'agreement-table',agreements:structuredClone(records),total:records.length,calculation:welcomeTableCalculation(records)}}; return;
      }
      if(options.scenario==='typography'||query.includes('排版示例')){
        for(const section of typographyReply.split('\n\n')){await delay(options.delay,signal);yield {kind:'text',text:section+'\n\n'};}
        return;
      }
      if (options.scenario === 'empty' || query.includes('空结果')) {
        yield { kind: 'text', text: '未找到符合条件的协议。试试扩大到未来 90 天，或换一个伙伴名称。' };
        yield { kind: 'part', part: { type: 'empty-result' } }; return;
      }
      // REQ-020: opt-in local example on existing follow-up queries. The structured
      // part is serializable; normal queries and AI routing keep their current behavior.
      const summaryRequested = ['智慧卡片', '查询需要跟进的待续签协议'].includes(query);
      if (summaryRequested) yield { kind: 'part', part: summaryPart };
      const preface = summaryRequested ? ['已结合近期到期协议整理跟进建议。'] : ['我已查询未来 90 天内到期的协议。', `\n找到 **${records.length} 份待跟进协议**，以下按到期日期排序。`, '\n你可以从表格查看详情和调整负责人；续签作业由业务工作区承接。'];
      for (const text of preface) {
        await delay(options.delay, signal); yield { kind: 'text', text };
      }
      await delay(options.delay, signal);
      yield { kind: 'part', part: { type: 'agreement-table', agreements: structuredClone(records), total: records.length } };
      if (options.scenario === 'long') {
        for (let i = 0; i < 16; i++) { await delay(options.delay, signal); yield { kind: 'text', text: `\n\n跟进建议 ${i + 1}：核对协议范围及续签负责人，提前安排续签评审。` }; }
      }
      if (options.scenario === 'unknown') yield { kind: 'part', part: { type: 'unsupported', originalType: 'future-business-card' } };
    },
    // Only this explicit local scenario advertises genuine append-only deltas.
    ...(options.scenario==='resumable' ? { async *continueStream(_request, signal:AbortSignal):AsyncGenerator<AssistantDelta> {
      for (const text of ['\n\n以下为本地 mock 续写。','继续核对材料，确认后安排评审。']) { await delay(options.delay*3,signal); yield {kind:'text',text}; }
    } } : {}),
    async updateAgreement(id, patch, context) {
      stats.saves++; await delay(450, context.signal);
      if (options.failSave && stats.saves === 1) throw new Error('保存失败，草稿已保留。请重试。');
      if (!patch.owner.trim()) throw new Error('负责人不能为空');
      const item = find(id); Object.assign(item, patch); return { ...item };
    },
    async renewAgreement(id, context) {
      if (completed.has(context.idempotencyKey)) return { ...completed.get(context.idempotencyKey)! };
      stats.renewals++; await delay(500, context.signal);
      if (options.failRenew && stats.renewals === 1) throw new Error('续签申请提交失败，请重试。');
      const item = find(id); item.status = '审批中'; completed.set(context.idempotencyKey, { ...item }); return { ...item };
    },
  };
}
