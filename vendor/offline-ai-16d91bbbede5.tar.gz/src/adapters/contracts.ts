/** Consumer owned data and operation contracts. No URLs, credentials or network client live here. */
import type { ComposerRequestContext } from '../ui/composer/composerTypes';
import type { BusinessNavigationTarget } from '../business/businessNavigation';
export type Agreement = {
  id: string; name: string; partner: string; owner: string; endDate: string; amount: string;
  status: '待续签' | '审批中' | '已续签';
};
export type { BusinessNavigationTarget } from '../business/businessNavigation';
export type AssistantPart =
  // REQ-023: serializable Markdown after an inline business block keeps real
  // reading order; ChatPanel already delegates text parts to Robot Markdown.
  | { type: 'text'; text: string }
  | { type: 'business-navigation'; title: string; description?: string; target: BusinessNavigationTarget }
  | { type: 'ai-summary'; text: string }
  | { type: 'agreement-table'; agreements: Agreement[]; total: number; calculation?: { formula: string; note: string } }
  | { type: 'empty-result' }
  | { type: 'unsupported'; originalType: string };
export type AssistantDelta = { kind: 'text'; text: string } | { kind: 'part'; part: AssistantPart };
/** Append-only continuation: the consumer owns resume tokens, history and transport.
 * Return only new deltas, never replay the supplied content/parts or restart the query. */
export type AssistantContinuationRequest = { query: string; content: string; parts: AssistantPart[]; context: ComposerRequestContext };
export interface AgreementAssistantAdapter {
  /** Optional third argument preserves existing two-argument consumers; routing stays consumer owned. */
  stream(query: string, signal: AbortSignal, context?: ComposerRequestContext): AsyncIterable<AssistantDelta>;
  /** Optional capability; legacy stream-only adapters never advertise continuation. */
  continueStream?(request: AssistantContinuationRequest, signal: AbortSignal): AsyncIterable<AssistantDelta>;
  updateAgreement(id: string, patch: Pick<Agreement, 'owner'>, context: { signal: AbortSignal; idempotencyKey: string }): Promise<Agreement>;
  renewAgreement(id: string, context: { signal: AbortSignal; idempotencyKey: string }): Promise<Agreement>;
}
