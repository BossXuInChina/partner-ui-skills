<script setup lang="ts">
import { onBeforeUnmount, onMounted, ref } from 'vue';
import UiDialog from './ui/foundation/UiDialog.vue';
import PreviewControls from './preview/PreviewControls.vue';
import { defaults, type PreviewConfig } from './preview/scenarios';
import { channel, trusted, type RuntimeMessage } from './preview/protocol';
const view = new URLSearchParams(location.search).get('view');
const deliveryPreview = view === 'delivery';
const rendererUrl = deliveryPreview ? '/renderer.html?view=delivery' : view === 'assistant' ? '/renderer.html?view=assistant' : '/renderer.html';
const config = ref<PreviewConfig>(structuredClone(defaults));
const frame = ref<HTMLIFrameElement>();
const pending = ref(false);
const fullscreen = ref(false);
const confirmLeave = ref(false);
const error = ref('');
const ready = ref(false);
let serial = 0;
let proposed: PreviewConfig | null = null;
const exchanges = new Map<string, { type: string; resolve: (value: RuntimeMessage) => void; timer: ReturnType<typeof setTimeout> }>();
function exchange(type: string, response: string, data: Record<string, unknown> = {}) { return new Promise<RuntimeMessage>((resolve, reject) => { const requestId = `studio-${++serial}`; const timer = setTimeout(() => { exchanges.delete(requestId); reject(new Error('预览未响应，当前画面已保留。')); }, 2500); exchanges.set(requestId, { type: response, resolve, timer }); frame.value?.contentWindow?.postMessage(JSON.parse(JSON.stringify({ channel, type, requestId, ...data })), location.origin); }); }
function onMessage(event: MessageEvent) {
  if (!trusted(event, frame.value?.contentWindow ?? null)) return;
  const data = event.data as RuntimeMessage;
  if (data.type === 'fullscreen-exit') fullscreen.value = false;
  if (data.type === 'ready') { void initialize(); }
  if (data.requestId) { const waiter = exchanges.get(data.requestId); if (waiter && (data.type === waiter.type || data.type === 'error')) { clearTimeout(waiter.timer); exchanges.delete(data.requestId); waiter.resolve(data); } }
}
async function initialize() { ready.value = false; const result = await exchange('configure', 'configured', { config: config.value }).catch(() => null); ready.value = result?.type === 'configured'; if (!ready.value) error.value = '预览初始化失败，请刷新。'; }
async function apply(next: PreviewConfig, discard = false) {
  pending.value = true; error.value = '';
  try { if (discard) await exchange('discard', 'discarded'); const result = await exchange('configure', 'configured', { config: next }); if (result.type === 'error') throw new Error(result.message); config.value = next; }
  catch (failure) { error.value = failure instanceof Error ? failure.message : '无法切换预览'; }
  finally { pending.value = false; }
}
async function change(next: PreviewConfig) {
  if (pending.value || !ready.value) return;
  // A host-layout choice preserves the running adapter and any unsaved business edit.
  if(next.scenario===config.value.scenario && next.controls.delay===config.value.controls.delay){await apply(next);return;}
  pending.value = true; error.value = '';
  try { const status = await exchange('leave-check', 'leave-status'); if (status.busy) { error.value = '正在保存或提交，请完成后再切换。'; return; } if (status.dirty) { proposed = next; confirmLeave.value = true; return; } pending.value = false; await apply(next); }
  catch (failure) { error.value = failure instanceof Error ? failure.message : '无法检查当前编辑'; }
  finally { pending.value = false; }
}
function answer(accepted: boolean) { confirmLeave.value = false; const next = proposed; proposed = null; if (accepted && next) void apply(next, true); }
function keydown(event: KeyboardEvent) { if (event.key === 'Escape' && fullscreen.value) fullscreen.value = false; }
onMounted(() => { window.addEventListener('message', onMessage); window.addEventListener('keydown', keydown); });
onBeforeUnmount(() => { window.removeEventListener('message', onMessage); window.removeEventListener('keydown', keydown); for (const value of exchanges.values()) clearTimeout(value.timer); });
</script>
<template><div class="studio-shell" :class="{ 'is-fullscreen': fullscreen }"><header><PreviewControls :config="config" :delivery="deliveryPreview" :fullscreen="fullscreen" :disabled="pending || !ready" :host-layout-available="view!=='assistant'" @change="change" @fullscreen="fullscreen = !fullscreen" /></header><p v-if="error" class="studio-error" role="alert">{{ error }}</p><div class="studio-stage"><iframe ref="frame" :src="rendererUrl" title="协议续签助手候选预览" /></div><footer class="studio-footer"><span>Vue 3.5.13 · TinyRobot 0.5.1 · kit 0.4.0</span><span>虚构数据 · 本地模拟操作</span></footer><UiDialog v-if="confirmLeave" title-id="studio-confirm-title" @close="answer(false)"><section class="studio-confirm-content"><h2 id="studio-confirm-title">放弃未保存的修改？</h2><p>当前负责人编辑尚未保存。切换场景会清除草稿。</p><div><button data-initial-focus @click="answer(false)">继续编辑</button><button @click="answer(true)">放弃并切换</button></div></section></UiDialog></div></template>
