// User-selected product identity, copied unchanged from demo/assets/weknow-avatar.png.
// Keep avatarSrc overrides and the explicit empty-string semantic-icon fallback.
// Emit a package-relative asset in Vite library builds; no demo runtime dependency.
import assistantAvatar from './assistant-avatar.png?no-inline';
export default assistantAvatar;
