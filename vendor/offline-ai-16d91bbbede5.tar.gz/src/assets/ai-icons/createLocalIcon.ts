import { defineComponent, h, useId, type VNode } from 'vue';

interface LocalIconNode { tag: string; attrs: Record<string, string>; children: LocalIconNode[] }
export interface LocalIconArtwork { source: string; attrs: Record<string, string>; children: LocalIconNode[] }

/** Trusted build-time SVG data only. Keep one SVG root for Robot's public icon slots.
 * Per-instance defs prevent repeated welcome cards from sharing clips/gradients;
 * hosts own size and semantic paint. No HTML injection or dependency DOM access. */
export function createLocalIcon(name: string, artwork: LocalIconArtwork, activeArtwork?: LocalIconArtwork) {
  return defineComponent({
    name, inheritAttrs: false,
    props: { active: Boolean },
    setup(props, { attrs }) {
      const prefix = `ai-icon-${useId().replace(/[^a-zA-Z0-9-]/g, '')}-`;
      function attributes(source: Record<string, string>) {
        return Object.fromEntries(Object.entries(source).map(([key, value]) => [key,
          key === 'id' ? prefix + value : value.replace(/url\(#([^)]+)\)/g, (_match, id: string) => `url(#${prefix}${id})`),
        ]));
      }
      function node(source: LocalIconNode): VNode {
        return h(source.tag, attributes(source.attrs), source.children.map(node));
      }
      return () => {
        const resource = props.active && activeArtwork ? activeArtwork : artwork;
        return h('svg', { ...attributes(resource.attrs), ...attrs, 'data-ai-resource': resource.source }, resource.children.map(node));
      };
    },
  });
}
