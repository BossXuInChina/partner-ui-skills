import { defineComponent, h } from 'vue';
import { artwork } from './artwork';
import { createLocalIcon } from './createLocalIcon';

export const localIcons = {
  ...Object.fromEntries(Object.entries(artwork).map(([key, resource]) => [key, createLocalIcon(`LocalAi${key}`, resource)])) as Record<keyof typeof artwork, ReturnType<typeof createLocalIcon>>,
  like: createLocalIcon('LocalAiLike', artwork.like, artwork.likeActive),
  dislike: createLocalIcon('LocalAiDislike', artwork.dislike, artwork.dislikeActive),
  bookmark: createLocalIcon('LocalAiBookmark', artwork.bookmark, artwork.bookmarkActive),
};

/** The toolbar describes the destination mode. Keep panel.mode as the override key
 * for both states so existing caller-provided icon maps continue to work. */
export const LocalWindowModeIcon = defineComponent({
  name: 'LocalWindowModeIcon', inheritAttrs: false,
  props: { windowMode: { type: String, default: undefined } },
  setup: (props, { attrs }) => () => h(props.windowMode === 'floating' ? localIcons.sidebar : localIcons.floating, attrs),
});
