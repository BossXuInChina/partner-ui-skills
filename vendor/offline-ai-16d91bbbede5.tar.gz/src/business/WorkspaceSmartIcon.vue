<script setup lang="ts">
import { useId } from 'vue';
import { AiIcon, useAiIconDefinition } from '../ui/foundation/aiIcons';
import type { IntelligenceLogo } from './workspaceIntelligence';
import './workspaceIntelligence.css';
defineProps<{ logo?: IntelligenceLogo }>();
const smartIcon = useAiIconDefinition('smart.mark');
const maskId = `workspace-smart-${useId().replace(/[^a-zA-Z0-9-]/g, '')}`;
</script>
<template>
  <!-- Local 24px filled artwork is copied byte-for-byte; gradient uses its alpha
       silhouette. Custom logo retains its existing precedence. Review
       mask/foreignObject support and public icon geometry on SVG upgrades. -->
  <span class="workspace-smart-icon" aria-hidden="true">
    <img v-if="typeof logo === 'string'" :src="logo" alt="">
    <component :is="logo" v-else-if="logo" />
    <AiIcon v-else-if="smartIcon.color !== 'gradient'" name="smart.mark" /><svg v-else viewBox="0 0 24 24" focusable="false">
      <defs><mask :id="maskId" x="0" y="0" width="24" height="24" maskUnits="userSpaceOnUse" style="mask-type:alpha"><AiIcon name="smart.mark" width="24" height="24" style="width:24px;height:24px" /></mask></defs>
      <foreignObject x="0" y="0" width="24" height="24" :mask="`url(#${maskId})`"><div xmlns="http://www.w3.org/1999/xhtml" class="workspace-smart-icon__paint" /></foreignObject>
    </svg>
  </span>
</template>
<style scoped>
.workspace-smart-icon { display:inline-flex; align-items:center; justify-content:center; flex:none; width:var(--partner-ai-smart-icon-size); height:var(--partner-ai-smart-icon-size); opacity:1; }
.workspace-smart-icon > img,.workspace-smart-icon :deep(svg) { display:block; width:var(--partner-ai-smart-icon-artwork-size); height:var(--partner-ai-smart-icon-artwork-size); object-fit:contain; }
.workspace-smart-icon__paint { width:100%; height:100%; background:var(--partner-ai-smart-icon-gradient); }
</style>
