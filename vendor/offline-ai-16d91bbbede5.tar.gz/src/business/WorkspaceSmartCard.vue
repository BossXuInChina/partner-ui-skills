<script setup lang="ts">
import { computed } from 'vue';
import { localIcons } from '../assets/ai-icons/localIcons';
import WorkspaceSmartIcon from './WorkspaceSmartIcon.vue';
import WorkspaceSmartTag from './WorkspaceSmartTag.vue';
import { intelligenceSentence, type IntelligenceItem, type IntelligenceLogo, type IntelligenceTag } from './workspaceIntelligence';
import type { WorkspaceNavigation } from '../host/businessAction';
const SmartActionArrow = localIcons.smartActionRight;
const props = withDefaults(defineProps<{ title: string; items: readonly IntelligenceItem[]; variant?: 'outlined' | 'embedded'; tag?: IntelligenceTag; logo?: IntelligenceLogo }>(), { variant:'outlined', tag:undefined, logo:undefined });
defineEmits<{ navigate: [navigation: WorkspaceNavigation]; activate: [] }>();
const sentences = computed(() => props.items.map(item => ({ ...item, fragments:intelligenceSentence(item.fragments) })));
</script>
<template>
  <!-- REQ-024: workspace guidance has its own shell/semantics, separate from
       AI answer summaries. Outlined follows the Pixso ring and subtle fill; embedded
       uses its own H16/V12 inset inside the host business card. Native
       text action is minimal: Robot0.5.1 has no general text-button API; reuse
       the local Workbench 10px arrow and link color. Recheck the button API on upgrade. No backend calls. -->
  <section class="workspace-smart-card" :class="`workspace-smart-card--${variant}`" :aria-label="title">
    <header class="workspace-smart-card__header">
      <div class="workspace-smart-card__title"><WorkspaceSmartIcon :logo="logo" /><h3>{{ title }}</h3></div>
      <WorkspaceSmartTag v-if="tag" :fragments="tag.fragments" :logo="logo" @activate="$emit('activate')" />
    </header>
    <slot v-if="$slots.body" name="body" />
    <ol v-else class="workspace-smart-card__list">
      <li v-for="(item, index) in sentences" :key="item.id" class="workspace-smart-card__item">
        <span class="workspace-smart-card__number" aria-hidden="true">{{ index + 1 }}</span>
        <p class="workspace-smart-card__sentence"><span v-for="(fragment, fragmentIndex) in item.fragments" :key="fragmentIndex" class="intelligence-fragment" :class="fragment.emphasis && `intelligence-fragment--${fragment.emphasis}`">{{ fragment.text }}</span>；<button v-if="item.action" type="button" role="link" class="workspace-smart-card__action" @click="$emit('navigate', item.action.navigation)">{{ item.action.label }}<SmartActionArrow aria-hidden="true" focusable="false" /></button></p>
      </li>
    </ol>
    <div v-if="$slots.footer" class="workspace-smart-card__footer"><slot name="footer" /></div>
  </section>
</template>
<style scoped>
.workspace-smart-card { position:relative; isolation:isolate; width:100%; min-width:0; box-sizing:border-box; border-radius:var(--partner-ai-smart-card-radius); color:var(--partner-ai-text); }
/* Each variant owns independent paint and background opacity. Only
   this pseudo-element fades; title, text, icon and the existing ring keep theirs. */
.workspace-smart-card::after { content:''; position:absolute; z-index:-2; inset:0; border-radius:inherit; pointer-events:none; }
.workspace-smart-card--outlined::after { background:var(--partner-ai-smart-card-bg); opacity:var(--partner-ai-smart-card-bg-opacity); }
.workspace-smart-card--embedded::after { background:var(--partner-ai-smart-embedded-bg); opacity:var(--partner-ai-smart-embedded-bg-opacity); }
.workspace-smart-card--outlined { padding:var(--partner-ai-smart-card-padding-top) var(--partner-ai-smart-card-padding-inline) var(--partner-ai-smart-card-padding-bottom); background:var(--partner-ai-smart-card-base-bg); }
/* Pixso conic-gradient ring, masked to 1px; no input glow. */
.workspace-smart-card--outlined::before { content:''; position:absolute; z-index:-1; inset:0; border-radius:inherit; padding:var(--partner-ai-smart-card-stroke-width); background:var(--partner-ai-smart-card-stroke); opacity:var(--partner-ai-smart-card-stroke-opacity); -webkit-mask:linear-gradient(#fff 0 0) content-box,linear-gradient(#fff 0 0); mask:linear-gradient(#fff 0 0) content-box,linear-gradient(#fff 0 0); -webkit-mask-composite:xor; mask-composite:exclude; pointer-events:none; }
.workspace-smart-card--embedded { padding:var(--partner-ai-smart-embedded-padding-block) var(--partner-ai-smart-embedded-padding-inline); border:0; background:var(--partner-ai-smart-card-base-bg); }
.workspace-smart-card__footer { margin-top:var(--partner-ai-smart-content-gap); }
.workspace-smart-card__header { display:flex; flex-wrap:wrap; align-items:center; justify-content:space-between; min-height:var(--partner-ai-smart-header-height); gap:var(--partner-ai-smart-title-gap) var(--partner-ai-smart-content-gap); }
.workspace-smart-card__title { display:flex; align-items:center; min-width:0; gap:var(--partner-ai-smart-title-gap); }
.workspace-smart-card__title h3 { margin:0; background:var(--partner-ai-smart-title-gradient); background-clip:text; -webkit-text-fill-color:transparent; font-size:var(--partner-ai-smart-title-size); line-height:var(--partner-ai-smart-title-line); font-weight:var(--partner-ai-smart-title-weight); overflow-wrap:anywhere; }
.workspace-smart-card__header > .workspace-smart-tag { margin-left:auto; }
.workspace-smart-card__list { display:flex; flex-wrap:wrap; gap:var(--partner-ai-smart-list-gap); list-style:none; margin:var(--partner-ai-smart-content-gap) 0 0; padding:0; }
/* Content-sized horizontal items, never equal columns. Item-to-item gap12 is
   independent from the existing number/text/action gaps16. */
.workspace-smart-card__item { display:flex; align-items:flex-start; gap:var(--partner-ai-smart-content-gap); flex:0 1 auto; min-width:0; max-width:100%; }
.workspace-smart-card--outlined .workspace-smart-card__sentence { flex:0 1 auto; }
.workspace-smart-card--embedded .workspace-smart-card__list { flex-direction:column; }
.workspace-smart-card--embedded .workspace-smart-card__item { flex:none; }
.workspace-smart-card__number { display:inline-flex; align-items:center; justify-content:center; flex:none; width:var(--partner-ai-smart-number-size); height:var(--partner-ai-smart-number-size); margin-top:var(--partner-ai-smart-number-offset); border-radius:var(--partner-ai-smart-number-radius); background:var(--partner-ai-smart-number-bg); font-size:var(--partner-ai-smart-number-font-size); line-height:var(--partner-ai-smart-number-size); font-weight:var(--partner-ai-smart-number-weight); font-variant-numeric:tabular-nums; }
.workspace-smart-card__sentence { flex:0 1 auto; min-width:0; margin:0; font-size:var(--partner-ai-body-size); line-height:var(--partner-ai-body-line); font-weight:var(--partner-ai-body-weight); overflow-wrap:anywhere; white-space:pre-wrap; }
/* Consumer-owned WorkspaceNavigation uses a native keyboard-capable button
   with link semantics; no invented href/URL. Inline flow keeps text/link gap16
   and the label/arrow together, never pushes the link to the row's far edge. */
.workspace-smart-card__action { display:inline-flex; vertical-align:baseline; align-items:center; gap:var(--partner-ai-smart-action-gap); margin-inline-start:var(--partner-ai-smart-content-gap); padding:0; border:0; background:transparent; color:var(--partner-ai-action-text); text-align:left; font-size:var(--partner-ai-body-size); line-height:var(--partner-ai-body-line); white-space:nowrap; cursor:pointer; }
.workspace-smart-card__action :deep(svg) { width:var(--partner-ai-smart-action-icon-size); height:var(--partner-ai-smart-action-icon-size); flex:none; }
.workspace-smart-card__action:hover { color:var(--partner-ai-action-text-hover); }
.workspace-smart-card__action:focus-visible { outline:var(--partner-ai-focus-width) solid var(--partner-ai-focus); outline-offset:var(--partner-ai-focus-offset); border-radius:var(--partner-ai-smart-action-radius); }
</style>
