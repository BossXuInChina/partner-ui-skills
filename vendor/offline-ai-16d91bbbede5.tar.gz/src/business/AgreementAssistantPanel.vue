<script setup lang="ts">
import assistantAvatar from '../assets/assistantAvatar';
import { TrThemeProvider, type BubbleContentRendererMatch } from '@opentiny/tiny-robot';
import { computed, toRef, ref } from 'vue';
import { AiIcon, provideAiIcons, type AiIconMap } from '../ui/foundation/aiIcons';
import ChatPanel from '../ui/panel/ChatPanel.vue';
import UiDialog from '../ui/foundation/UiDialog.vue';
import type { AgreementAssistantAdapter } from '../adapters/contracts';
import { useAgreementPanel } from './useAgreementPanel';
import type { ChatWindowMode } from '../ui/panel/chatWindow';
import type { ChatToolbarAction } from '../ui/panel/chatToolbar';
import type { ComposerModeOption, ComposerRequestContext, WelcomeBusinessEntry } from '../ui/composer/composerTypes';
import type { ChatSuggestionPill, MessagePromptsResolver } from '../ui/composer/chatSuggestions';
import ConversationHistoryPanel from '../ui/history/ConversationHistoryPanel.vue';
import type { ConversationHistoryOptions } from '../ui/history/conversationHistory';
import type { AgreementBusinessAction, BusinessActionMode, BusinessDialogScope, WorkspaceNavigation } from '../host/businessAction';
// ChatPanel normalizes reasoning once and uses ThinkingContent for both the
// row-only loading fallback and reasoning body. Public loading artwork injection
// remains unavailable; preserve stop, reduced-motion and message ownership on upgrades.
const props = withDefaults(defineProps<{ icons?: AiIconMap; businessActionMode?: BusinessActionMode; businessDialogScope?: BusinessDialogScope; windowMode?: ChatWindowMode; fullscreen?: boolean; adapter: AgreementAssistantAdapter; theme?: 'workbench' | 'aurora'; autoStart?: boolean; avatarSrc?: string; toolbarActions?: ChatToolbarAction[]; modeOptions?: ComposerModeOption[]; welcomeEntries?: WelcomeBusinessEntry[]; suggestionPills?: ChatSuggestionPill[]; messagePrompts?: MessagePromptsResolver; historyOptions?:ConversationHistoryOptions; contentRenderers?:BubbleContentRendererMatch[] }>(), { icons: undefined, businessActionMode: 'default', businessDialogScope: undefined, windowMode: undefined, fullscreen: undefined, theme: 'workbench', autoStart: false, toolbarActions: () => [], avatarSrc: assistantAvatar, modeOptions:()=>[], welcomeEntries:()=>[], suggestionPills:()=>[], messagePrompts:undefined, historyOptions:undefined, contentRenderers:()=>[] });
provideAiIcons(toRef(props, 'icons'));
const emit = defineEmits<{ businessAction:[action:AgreementBusinessAction]; workspaceNavigate:[navigation:WorkspaceNavigation]; windowModeChange:[mode:ChatWindowMode]; fullscreenChange:[value:boolean]; windowDragStart:[event:PointerEvent]; windowDragKeydown:[event:KeyboardEvent]; status: [state: { dirty: boolean; busy: boolean }]; toolbarAction: [action: ChatToolbarAction]; composerChange:[context:ComposerRequestContext]; welcomeAction:[entry:WelcomeBusinessEntry] }>();
const { scopeId,messages,isProcessing,requestState,send,retry,abortRequest,resetting,activeRequestContext,error,selected,confirmation,discard,operationBusy,operationError,toast,dirty,renderers,currentStatus,discardDraft,applyBusinessUpdate,handleEvent,closeDrawer,saveEdit,confirmRenew,newConversation:clearConversation,history,switchConversation,clearHistory,removeConversation } = useAgreementPanel(props, emit, action => emit('businessAction', action), navigation => emit('workspaceNavigate', navigation));
// REQ-020: forward TinyRobot's public renderer matches so hosts can compose
// business content without importing their UI/assets into this product package.
// Matches retain TinyRobot priority semantics; callbacks/components are never persisted.
const allContentRenderers = computed(() => [...props.contentRenderers, ...renderers]);
const chat = ref<InstanceType<typeof ChatPanel>>();
// REQ-003: only explicit first send starts a default conversation. New/reset aborts the old
// stream before clearing UI state; legacy consumers can still opt into autoStart or call start().
const historyAnchor=ref<HTMLElement>(), historyShown=ref(false);
function saveView() { if(chat.value)history.updateView(chat.value.captureView()); }
async function newConversation() { saveView(); await clearConversation(); }
async function selectHistory(id:string) { saveView(); return switchConversation(id); }
async function removeHistory(id:string){saveView();return removeConversation(id);}
function openHistory(anchor:HTMLElement) { saveView(); historyShown.value=historyAnchor.value===anchor?!historyShown.value:true; historyAnchor.value=anchor; }
// A remount immediately reloads durable history: create/flush a blank active
// conversation before returning, retaining the outgoing history instead of racing
// its pending autosave against a bare engine reset.
async function resetAll() { await newConversation(); chat.value?.resetComposer(); }
// REQ-024 optional host query/read/locate port. Guards match the actual composer;
// requesting analysis preserves its draft and explicit submitted context. Hosts
// own duplicate protection/business intent; this API never opens a workspace.
function canSendQuery() { return history.ready.value && !history.busy.value && !resetting.value && !isProcessing.value && !operationBusy.value && !dirty.value; }
async function sendQuery(query: string, context?: ComposerRequestContext) {
  if (!canSendQuery() || !query.trim()) return false;
  await send(query, context); return true;
}
// kit may omit ids; mirror ChatPanel's display fallback so host location uses
// the same current-turn identity. Return snapshots, not the mutable message ref.
function getMessages() { return messages.value.map((message,index) => ({...message,id:message.id ?? `message-${index}`})); }
defineExpose({ applyBusinessUpdate, currentStatus, discardDraft, reset:resetAll, newConversation, canSendQuery, sendQuery, getMessages, locateReply: (id:string) => chat.value?.locateReply(id), start: () => { if (!messages.value.length) void send('查询待续签协议'); } });
</script>
<template>
<div :id="scopeId" class="partner-ai agreement-assistant-panel" :data-ai-theme="theme"><TrThemeProvider :theme="theme" color-mode="light" :target-element="`#${scopeId}`"><ChatPanel ref="chat" :window-mode="windowMode" :fullscreen="fullscreen" :messages="messages" :processing="isProcessing || resetting || history.busy.value || !history.ready.value" :conversation-id="history.activeId.value" :conversation-view="history.view.value" history-available :history-open="historyShown" :error="error" :continuation-available="!!adapter.continueStream" :aborted="requestState === 'aborted'" :renderers="allContentRenderers" :avatar-src="avatarSrc" :toolbar-actions="toolbarActions" :mode-options="modeOptions" :welcome-entries="welcomeEntries" :suggestion-pills="suggestionPills" :message-prompts="messagePrompts" :request-context="activeRequestContext" :new-conversation-disabled="operationBusy || dirty || resetting || history.busy.value || !history.ready.value" @fullscreen-change="emit('fullscreenChange', $event)" @history-open="openHistory" @conversation-view-change="history.updateView" @new-conversation="newConversation" @composer-change="emit('composerChange', $event)" @welcome-action="emit('welcomeAction', $event)" @window-mode-change="emit('windowModeChange', $event)" @window-drag-start="emit('windowDragStart', $event)" @window-drag-keydown="emit('windowDragKeydown', $event)" @toolbar-action="emit('toolbarAction', $event)" @send="send" @abort="abortRequest" @retry="retry" @event="handleEvent"><template #toolbar-end><slot name="toolbar-end" /></template></ChatPanel>
      <ConversationHistoryPanel v-if="historyAnchor" :open="historyShown" :anchor="historyAnchor" :records="history.records.value" :selected="history.activeId.value" :busy="history.busy.value" :error="history.storageError.value" :read-failed="history.readFailed.value" :blocked="operationBusy || dirty" :clear="clearHistory" :remove="removeHistory" :select="selectHistory" @pin="history.pin" @reload="history.readFailed.value ? history.load() : history.flush()" @close="historyShown=false" @closed="!historyShown && (historyAnchor=undefined)" />
      <p v-if="history.storageError.value && !historyAnchor" class="history-storage-warning" role="alert">{{ history.storageError.value }}</p>
      <UiDialog v-if="selected" :scope="businessDialogScope" :theme="theme" :title-id="`${scopeId}-detail`" drawer @close="closeDrawer"><div class="drawer"><header><div><p class="eyebrow">协议详情</p><h2 :id="`${scopeId}-detail`">{{ selected.name }}</h2></div><button class="icon-button" aria-label="关闭详情" data-initial-focus :disabled="operationBusy" @click="closeDrawer"><AiIcon name="business.close" /></button></header><div class="drawer-body"><span class="status-pill">{{ selected.status }}</span><dl><dt>协议编号</dt><dd>{{ selected.id }}</dd><dt>合作伙伴</dt><dd>{{ selected.partner }}</dd><dt>到期日期</dt><dd>{{ selected.endDate }}</dd><dt>协议金额</dt><dd>{{ selected.amount }}</dd></dl><label class="field"><span>协议负责人</span><input v-model="selected.owner" maxlength="40" :disabled="operationBusy" @input="operationError = ''"></label><p class="drawer-note">请核对负责人后保存。续签申请需另行确认。</p><p v-if="operationError" class="error-box" role="alert">{{ operationError }}</p></div><footer><button class="button button--quiet" :disabled="operationBusy" @click="closeDrawer">取消</button><button class="button button--primary" :disabled="operationBusy || !dirty" @click="saveEdit">{{ operationBusy ? '保存中…' : '保存修改' }}</button></footer></div></UiDialog>
      <UiDialog v-if="confirmation" :scope="businessDialogScope" :theme="theme" :title-id="`${scopeId}-confirm`" @close="!operationBusy && (confirmation = null)"><section class="confirm-modal"><span class="confirm-icon">↻</span><h2 :id="`${scopeId}-confirm`">确认发起续签？</h2><p>将为「{{ confirmation.name }}」创建续签申请。确认信息无误后继续。</p><p v-if="operationError" class="error-box" role="alert">{{ operationError }}</p><div class="modal-actions"><button class="button button--quiet" data-initial-focus :disabled="operationBusy" @click="confirmation = null">再想想</button><button class="button button--primary" :disabled="operationBusy" @click="confirmRenew">{{ operationBusy ? '提交中…' : '确认发起' }}</button></div></section></UiDialog>
      <UiDialog v-if="discard" :scope="businessDialogScope" :theme="theme" :title-id="`${scopeId}-discard`" @close="discard = false"><section class="confirm-modal"><h2 :id="`${scopeId}-discard`">放弃未保存的修改？</h2><p>离开后将恢复原负责人。</p><div class="modal-actions"><button class="button button--quiet" data-initial-focus @click="discard = false">继续编辑</button><button class="button button--primary" @click="discardDraft">放弃修改</button></div></section></UiDialog>
      <div v-if="toast" class="toast" role="status"><AiIcon name="business.success" />{{ toast }}</div>

</TrThemeProvider></div>
</template>

<style scoped>
.history-storage-warning { position:absolute; top:72px; left:16px; right:16px; z-index:2; margin:0; padding:var(--partner-ai-gap-md); border:var(--partner-ai-border-width) solid var(--partner-ai-border); border-radius:var(--partner-ai-control-radius); background:var(--partner-ai-overlay-bg); color:var(--partner-ai-accent); font-size:var(--partner-ai-caption-size); }
</style>
