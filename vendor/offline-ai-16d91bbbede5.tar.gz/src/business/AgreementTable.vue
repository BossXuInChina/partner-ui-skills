<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref, watch, nextTick } from 'vue';
import type { Agreement } from '../adapters/contracts';
const props = defineProps<{ agreements: Agreement[] }>();
defineEmits<{ open: [agreement: Agreement] }>();

// Workbench TableScrollArea (read-only source) paints a 14px track over the
// bottom edge while its viewport remains the sole horizontal scroll owner.
// This local adaptation has no fixed columns or Workbench runtime dependency.
const viewport=ref<HTMLElement>(), table=ref<HTMLTableElement>(), track=ref<HTMLElement>();
const width=ref(0), total=ref(0), left=ref(0), dragging=ref(false);
let observer:ResizeObserver|undefined, drag:{x:number;scroll:number;scale:number;travel:number;range:number}|undefined;
const overflow=computed(()=>total.value-width.value>1);
const thumbWidth=computed(()=>total.value ? width.value*width.value/total.value : 0);
const travel=computed(()=>Math.max(0,width.value-thumbWidth.value));
const thumbLeft=computed(()=>total.value>width.value ? left.value/(total.value-width.value)*travel.value : 0);
function measure(){const el=viewport.value;if(!el)return;width.value=el.clientWidth;total.value=el.scrollWidth;left.value=el.scrollLeft;}
function down(event:PointerEvent){
  const el=viewport.value,bar=track.value;if(!el||!bar||event.button!==0||!overflow.value||travel.value<=0)return;
  el.focus({preventScroll:true});const rect=bar.getBoundingClientRect(),scale=rect.width/bar.clientWidth||1,range=total.value-width.value;
  if(!(event.target instanceof Element && event.target.closest('.agreement-table__thumb'))) el.scrollLeft=((event.clientX-rect.left)/scale-thumbWidth.value/2)/travel.value*range;
  drag={x:event.clientX,scroll:el.scrollLeft,scale,travel:travel.value,range};dragging.value=true;bar.setPointerCapture(event.pointerId);event.preventDefault();
}
function move(event:PointerEvent){if(drag&&viewport.value)viewport.value.scrollLeft=drag.scroll+(event.clientX-drag.x)/drag.scale/drag.travel*drag.range;}
function end(){drag=undefined;dragging.value=false;}
function keydown(event:KeyboardEvent){
  const el=viewport.value;if(!el||event.target!==el)return;
  const delta=event.key==='ArrowLeft'?-40:event.key==='ArrowRight'?40:event.key==='PageUp'?-el.clientWidth:event.key==='PageDown'?el.clientWidth:undefined;
  if(delta!==undefined){event.preventDefault();el.scrollLeft+=delta;}
  else if(event.key==='Home'||event.key==='End'){event.preventDefault();el.scrollLeft=event.key==='Home'?0:el.scrollWidth;}
}
onMounted(()=>{observer=new ResizeObserver(measure);if(viewport.value)observer.observe(viewport.value);if(table.value)observer.observe(table.value);measure();});
onBeforeUnmount(()=>{observer?.disconnect();end();});
watch(()=>props.agreements,()=>void nextTick(measure),{deep:true});
</script>

<template>
  <!-- Styling and bottom-overlay track follow Workbench Table; public data/events and status slot remain local. -->
  <div class="table-clip agreement-table">
    <div ref="viewport" class="table-wrap agreement-table__viewport" role="region" aria-label="协议列表横向滚动区域" tabindex="0" @scroll="measure" @keydown="keydown">
      <table ref="table"><thead><tr><th>协议名称</th><th>协议编号</th><th>合作伙伴</th><th>到期日期</th><th>协议金额</th><th>状态</th><th>操作</th></tr></thead><tbody>
        <tr v-for="item in agreements" :key="item.id"><td>{{ item.name }}</td><td>{{ item.id }}</td><td>{{ item.partner }}</td><td>{{ item.endDate }}</td><td>{{ item.amount }}</td><td><slot name="status" :agreement="item">{{ item.status }}</slot></td><td><button class="agreement-table__action" type="button" @click="$emit('open', item)"><span>详情</span></button></td></tr>
      </tbody></table>
    </div>
    <div v-if="overflow" ref="track" class="agreement-table__track" :class="{'is-dragging':dragging}" aria-hidden="true" @pointerdown="down" @pointermove="move" @pointerup="end" @pointercancel="end" @lostpointercapture="end"><div class="agreement-table__thumb" :style="{width:`${thumbWidth}px`,transform:`translateX(${thumbLeft}px)`}" /></div>
  </div>
</template>

<style scoped>
/* Values ported from WorkbenchTable.vue, TableScrollArea.vue and its generated
   table/scrollbar tokens; keep this component self-contained and review on upgrade. */
.table-clip { position:relative; isolation:isolate; width:100%; max-width:100%; min-width:0; border-radius:var(--partner-ai-table-radius); overflow:hidden; }
.agreement-table .agreement-table__viewport { width:100%; overflow-x:auto; overflow-y:hidden; scrollbar-width:none; overscroll-behavior-x:contain; }
.agreement-table .agreement-table__viewport::-webkit-scrollbar { display:none; }
.agreement-table .agreement-table__viewport:focus-visible { outline:var(--partner-ai-focus-width) solid var(--partner-ai-focus); outline-offset:var(--partner-ai-focus-inset); }
.agreement-table table { width:max-content; min-width:max(100%,var(--partner-ai-table-min-width)); border-spacing:0; border-collapse:separate; table-layout:fixed; color:var(--partner-ai-text); background:var(--partner-ai-panel-bg); font-size:var(--partner-ai-body-size); font-weight:var(--partner-ai-body-weight); line-height:var(--partner-ai-body-line); letter-spacing:var(--partner-ai-body-letter-spacing); }
.agreement-table th,.agreement-table td { box-sizing:border-box; height:var(--partner-ai-table-row-height); padding:0 var(--partner-ai-spacing-sm); border:0; border-bottom:var(--partner-ai-border-width) solid var(--partner-ai-divider); text-align:start; vertical-align:middle; white-space:nowrap; font:inherit; }
.agreement-table th { position:relative; color:var(--partner-ai-text); font-weight:var(--partner-ai-heading-weight); background-color:var(--partner-ai-panel-bg); background-image:linear-gradient(var(--partner-ai-table-header-bg),var(--partner-ai-table-header-bg)); }
.agreement-table th:not(:last-child)::after { content:''; position:absolute; top:50%; inset-inline-end:0; width:var(--partner-ai-border-width); height:var(--partner-ai-table-header-divider-height); background:var(--partner-ai-divider); transform:translateY(-50%); }
.agreement-table td { background:var(--partner-ai-panel-bg); border-bottom-color:var(--partner-ai-table-row-divider); }
.agreement-table tbody tr:hover td { background:var(--partner-ai-hover-bg); }
.agreement-table .agreement-table__action { border:0; padding:0; color:var(--partner-ai-action-text); background:transparent; font:inherit; text-align:start; cursor:pointer; }
.agreement-table__action span { position:relative; top:var(--partner-ai-table-action-label-offset); }
.agreement-table .agreement-table__action:hover { color:var(--partner-ai-action-text-hover); text-decoration:underline; }
.agreement-table .agreement-table__action:active { color:var(--partner-ai-table-action-active); text-decoration:underline; }
.agreement-table .agreement-table__action:focus-visible { outline:var(--partner-ai-border-width) solid var(--partner-ai-focus); outline-offset:var(--partner-ai-focus-control-offset); text-decoration:underline; }
.agreement-table__track { position:absolute; left:0; right:0; bottom:0; height:var(--partner-ai-scrollbar-size); z-index:4; touch-action:none; user-select:none; overflow:hidden; }
.agreement-table__thumb { position:absolute; bottom:0; height:calc(var(--partner-ai-scrollbar-size) - var(--partner-ai-scrollbar-safe) * 2); border-radius:var(--partner-ai-scrollbar-radius); background:var(--partner-ai-color-neutral-200); }
.agreement-table__track:hover .agreement-table__thumb,.agreement-table__track.is-dragging .agreement-table__thumb { height:calc(var(--partner-ai-scrollbar-size) - var(--partner-ai-scrollbar-safe-hover) * 2); background:var(--partner-ai-scrollbar-thumb-hover); }
</style>
