<script setup lang="ts">
import { computed, nextTick, onBeforeUnmount, onMounted, ref, useId, useSlots, watch } from 'vue';
import WorkspaceSmartIcon from './WorkspaceSmartIcon.vue';
import type { WorkspaceSmartTab } from './workspaceSmartTabs';
import './workspaceIntelligence.css';
const props=withDefaults(defineProps<{modelValue:string;items:readonly WorkspaceSmartTab[];ariaLabel?:string;align?:'start'|'center'}>(),{ariaLabel:'智慧页签',align:'center'});
const emit=defineEmits<{'update:modelValue':[value:string];change:[item:WorkspaceSmartTab]}>();
const slots=useSlots(), id=`workspace-tabs-${useId()}`;
const port=ref<HTMLElement>(), track=ref<HTMLElement>(), indicator=ref<HTMLElement>();
const active=computed(()=>props.items.findIndex(item=>item.value===props.modelValue&&!item.disabled));
const entry=computed(()=>active.value>=0?active.value:props.items.findIndex(item=>!item.disabled));
let observer:ResizeObserver|undefined, frame=0;
const tabId=(index:number)=>`${id}-tab-${index}`, panelId=(index:number)=>`${id}-panel-${index}`;
function tab(index:number) {return track.value?.querySelectorAll<HTMLButtonElement>('[role=tab]')[index];}
function measure() {
  frame=0;
  const node=tab(active.value);
  if(!node||!indicator.value)return;
  indicator.value.style.width=`${node.offsetWidth}px`;
  indicator.value.style.transform=`translateX(${node.offsetLeft}px)`;
  reveal(active.value);
}
function schedule() {if(!frame)frame=requestAnimationFrame(measure);}
function reveal(index:number) {
  const node=tab(index), viewport=port.value;if(!node||!viewport)return;
  // Scroll only the tab strip; keyboard selection must not move the host page.
  const left=node.offsetLeft,right=left+node.offsetWidth;
  if(left<viewport.scrollLeft)viewport.scrollLeft=left;
  else if(right>viewport.scrollLeft+viewport.clientWidth)viewport.scrollLeft=right-viewport.clientWidth;
}
function select(item:WorkspaceSmartTab,index:number,focus=false) {
  if(item.disabled)return;
  if(item.value!==props.modelValue){emit('update:modelValue',item.value);emit('change',item);}
  if(focus)void nextTick(()=>{tab(index)?.focus({preventScroll:true});reveal(index);});
}
function keydown(event:KeyboardEvent,index:number) {
  if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;
  const enabled=props.items.flatMap((item,i)=>item.disabled?[]:[i]);if(!enabled.length)return;
  event.preventDefault();
  const at=enabled.indexOf(index),direction=event.key==='ArrowRight'?1:-1;
  const target=event.key==='Home'?enabled[0]!:event.key==='End'?enabled.at(-1)!:enabled[(Math.max(0,at)+direction+enabled.length)%enabled.length]!;
  select(props.items[target]!,target,true);
}
watch(()=>[props.modelValue,props.items,props.align],()=>{void nextTick(()=>{schedule();if(active.value>=0)reveal(active.value);});},{deep:true});
onMounted(()=>{
  observer=new ResizeObserver(schedule);if(port.value)observer.observe(port.value);if(track.value)observer.observe(track.value);
  document.fonts?.addEventListener('loadingdone',schedule);schedule();
});
onBeforeUnmount(()=>{observer?.disconnect();cancelAnimationFrame(frame);document.fonts?.removeEventListener('loadingdone',schedule);});
</script>
<template>
  <!-- TinyRobot 0.5.1 exposes no general Tabs API. This minimal native tablist
       carries the confirmed Workbench basic-tab geometry with AI-owned tokens;
       no demo/vendor or Workbench runtime imports. Recheck upstream on upgrade.
       Native horizontal overflow replaces hidden-menu measurement, so all tabs
       remain reachable after hidden hosts resize. Panel slots stay mounted. -->
  <div class="workspace-smart-tabs" :class="`workspace-smart-tabs--${align}`">
    <div ref="port" class="workspace-smart-tabs__viewport">
      <div ref="track" class="workspace-smart-tabs__list" role="tablist" :aria-label="ariaLabel">
        <button v-for="(item,index) in items" :id="tabId(index)" :key="item.value" type="button" role="tab" class="workspace-smart-tabs__tab" :aria-selected="index===active" :aria-controls="slots.panel?panelId(index):undefined" :disabled="item.disabled" :tabindex="index===entry?0:-1" @click="select(item,index)" @keydown="keydown($event,index)">
          <span class="workspace-smart-tabs__label"><WorkspaceSmartIcon v-if="item.smart" />{{ item.label }}</span>
        </button>
        <span v-show="active>=0" ref="indicator" class="workspace-smart-tabs__indicator" aria-hidden="true" />
      </div>
    </div>
    <template v-if="slots.panel"><section v-for="(item,index) in items" v-show="index===active" :id="panelId(index)" :key="item.value" class="workspace-smart-tabs__panel" role="tabpanel" :aria-labelledby="tabId(index)" tabindex="0"><slot name="panel" :item="item" /></section></template>
  </div>
</template>
<style scoped>
.workspace-smart-tabs { min-width:0; width:100%; }
.workspace-smart-tabs__viewport { display:flex; overflow-x:auto; scrollbar-width:none; }
.workspace-smart-tabs__viewport::-webkit-scrollbar { display:none; }
.workspace-smart-tabs__list { position:relative; display:flex; flex:none; width:max-content; gap:var(--partner-ai-smart-tabs-gap); margin-inline:auto; }
.workspace-smart-tabs--start .workspace-smart-tabs__list { margin-inline:0; }
.workspace-smart-tabs__tab { display:flex; align-items:flex-start; flex:none; height:calc(var(--partner-ai-body-line) + var(--partner-ai-smart-tabs-indicator-gap) + var(--partner-ai-smart-tabs-indicator-height)); padding:0; margin:0; border:0; background:transparent; color:var(--partner-ai-muted); font-size:var(--partner-ai-body-size); line-height:var(--partner-ai-body-line); font-weight:var(--partner-ai-body-weight); white-space:nowrap; cursor:pointer; }
.workspace-smart-tabs__label { display:flex; align-items:center; height:var(--partner-ai-body-line); gap:var(--partner-ai-spacing-sm); }
.workspace-smart-tabs__tab[aria-selected=true],.workspace-smart-tabs__tab:hover:not(:disabled) { color:var(--partner-ai-text); }
.workspace-smart-tabs__tab:disabled { color:var(--partner-ai-muted); cursor:not-allowed; }
.workspace-smart-tabs__tab:focus-visible { outline:var(--partner-ai-focus-width) solid var(--partner-ai-focus); outline-offset:calc(-1 * var(--partner-ai-focus-width)); border-radius:var(--partner-ai-radius-xs); }
.workspace-smart-tabs__indicator { position:absolute; bottom:0; left:0; height:var(--partner-ai-smart-tabs-indicator-height); border-radius:var(--partner-ai-radius-xs); background:var(--partner-ai-color-brand-700); pointer-events:none; transition:transform var(--partner-ai-smart-tabs-motion-duration) ease-out,width var(--partner-ai-smart-tabs-motion-duration) ease-out; }
.workspace-smart-tabs__panel { min-width:0; }
.workspace-smart-tabs__panel:focus-visible { outline:var(--partner-ai-focus-width) solid var(--partner-ai-focus); outline-offset:calc(-1 * var(--partner-ai-focus-width)); }
@media(prefers-reduced-motion:reduce) { .workspace-smart-tabs__indicator { transition:none; } }
</style>
