<script setup lang="ts">
import { TrThemeProvider } from '@opentiny/tiny-robot';
import { ref } from 'vue';
import { AiIcon } from '../ui/foundation/aiIcons';
import { localIcons } from '../assets/ai-icons/localIcons';
import ChatPanel from '../ui/panel/ChatPanel.vue';
import UiDialog from '../ui/foundation/UiDialog.vue';
import type { AgreementAssistantAdapter } from '../adapters/contracts';
import { useAgreementPanel } from './useAgreementPanel';
const props = withDefaults(defineProps<{ adapter: AgreementAssistantAdapter; theme?: 'workbench' | 'aurora'; autoStart?: boolean }>(), { theme: 'workbench', autoStart: false });
const emit = defineEmits<{ status: [state: { dirty: boolean; busy: boolean }] }>();
const { scopeId,messages,isProcessing,requestState,send,retry,abortRequest,resetting,activeRequestContext,error,selected,confirmation,discard,operationBusy,operationError,toast,dirty,records,pendingCount,renderers,currentStatus,discardDraft,handleEvent,closeDrawer,saveEdit,confirmRenew,newConversation:clearConversation } = useAgreementPanel(props, emit);
const chat=ref<InstanceType<typeof ChatPanel>>();
async function newConversation(){if(await clearConversation())chat.value?.resetComposer();}
defineExpose({ currentStatus, discardDraft, reset: newConversation });
</script>
<template>
  <div :id="scopeId" class="partner-ai" :data-ai-theme="theme">
    <TrThemeProvider :theme="theme" color-mode="light" :target-element="`#${scopeId}`">
      <div class="app-frame">
        <aside class="sidebar" aria-label="助手工作空间"><div class="brand"><span class="brand-mark">P</span><div><b>Partner Hub</b><small>伙伴协同 · AI</small></div></div><p class="sidebar-section">工作空间</p><div class="nav-item active"><AiIcon name="assistant.fallback" />协议续签助手</div><div class="sidebar-summary"><span>待续签</span><b>{{ pendingCount }}</b><small>本次查询结果</small></div><div class="sidebar-bottom"><p>从查询到跟进<br>让每份协议及时续签</p><div class="profile"><span class="avatar">林</span><span>林悦<small>伙伴运营 · 虚构角色</small></span></div></div></aside>
        <main class="main-area"><header class="topbar"><nav class="breadcrumb" aria-label="当前位置">协议管理 <span>/</span> <b>AI 助手</b></nav><span class="workspace-label">伙伴运营工作空间</span></header><section class="page-heading"><div><p class="eyebrow"><AiIcon name="assistant.fallback" />智能伙伴助手<span class="online-dot" />在线</p><h1>协议续签助手</h1><p>查询即将到期的协议，核对详情并开始续签。</p></div><button class="button button--quiet" :disabled="operationBusy" @click="newConversation"><component :is="localIcons.plus" />新建对话</button></section>
          <section class="content-grid"><ChatPanel ref="chat" :messages="messages" :processing="isProcessing || resetting" :error="error" :aborted="requestState === 'aborted'" :renderers="renderers" :request-context="activeRequestContext" :new-conversation-disabled="operationBusy || dirty || resetting" @new-conversation="newConversation" @send="send" @abort="abortRequest" @retry="retry" @event="handleEvent" /><aside class="insights"><div class="insights-heading"><AiIcon name="assistant.fallback" /><h2>续签概览</h2></div><div class="overview-number"><strong>{{ records.length }}</strong><span>份协议待跟进</span></div><p class="overview-caption">本次查询 · 未来 90 天内到期</p><div class="metric-list"><div><span>待发起续签</span><b>{{ pendingCount }} 份</b></div><div><span>审批处理中</span><b>{{ records.length - pendingCount }} 份</b></div></div><div class="insight-divider" /><h3>你还可以问</h3><button class="quick-prompt" :disabled="isProcessing" @click="send('查询本月到期协议')">本月有哪些协议到期？<span>↗</span></button><button class="quick-prompt" :disabled="isProcessing" @click="send('查询需要跟进的待续签协议')">查看需要我跟进的续签<span>↗</span></button><p class="privacy-note">当前使用虚构协议数据。所有操作都经过确认。</p></aside></section>
        </main>
      </div>
      <UiDialog v-if="selected" :title-id="`${scopeId}-detail`" drawer @close="closeDrawer"><div class="drawer"><header><div><p class="eyebrow">协议详情</p><h2 :id="`${scopeId}-detail`">{{ selected.name }}</h2></div><button class="icon-button" aria-label="关闭详情" data-initial-focus :disabled="operationBusy" @click="closeDrawer"><AiIcon name="business.close" /></button></header><div class="drawer-body"><span class="status-pill">{{ selected.status }}</span><dl><dt>协议编号</dt><dd>{{ selected.id }}</dd><dt>合作伙伴</dt><dd>{{ selected.partner }}</dd><dt>到期日期</dt><dd>{{ selected.endDate }}</dd><dt>协议金额</dt><dd>{{ selected.amount }}</dd></dl><label class="field"><span>协议负责人</span><input v-model="selected.owner" maxlength="40" :disabled="operationBusy" @input="operationError = ''"></label><p class="drawer-note">请核对负责人后保存。续签申请需另行确认。</p><p v-if="operationError" class="error-box" role="alert">{{ operationError }}</p></div><footer><button class="button button--quiet" :disabled="operationBusy" @click="closeDrawer">取消</button><button class="button button--primary" :disabled="operationBusy || !dirty" @click="saveEdit">{{ operationBusy ? '保存中…' : '保存修改' }}</button></footer></div></UiDialog>
      <UiDialog v-if="confirmation" :title-id="`${scopeId}-confirm`" @close="!operationBusy && (confirmation = null)"><section class="confirm-modal"><span class="confirm-icon">↻</span><h2 :id="`${scopeId}-confirm`">确认发起续签？</h2><p>将为「{{ confirmation.name }}」创建续签申请。确认信息无误后继续。</p><p v-if="operationError" class="error-box" role="alert">{{ operationError }}</p><div class="modal-actions"><button class="button button--quiet" data-initial-focus :disabled="operationBusy" @click="confirmation = null">再想想</button><button class="button button--primary" :disabled="operationBusy" @click="confirmRenew">{{ operationBusy ? '提交中…' : '确认发起' }}</button></div></section></UiDialog>
      <UiDialog v-if="discard" :title-id="`${scopeId}-discard`" @close="discard = false"><section class="confirm-modal"><h2 :id="`${scopeId}-discard`">放弃未保存的修改？</h2><p>离开后将恢复原负责人。</p><div class="modal-actions"><button class="button button--quiet" data-initial-focus @click="discard = false">继续编辑</button><button class="button button--primary" @click="discardDraft">放弃修改</button></div></section></UiDialog>
      <div v-if="toast" class="toast" role="status"><AiIcon name="business.success" />{{ toast }}</div>
    </TrThemeProvider>
  </div>
</template>
