import type { Component } from 'vue';
import type { WorkspaceNavigation } from '../host/businessAction';

/** REQ-024: consumers explicitly mark semantics, including paired units/words.
 * No digit inference, HTML, URLs or automatic requests belong to these views. */
export type IntelligenceFragment = { text: string; emphasis?: 'bold' | 'data' };
export type IntelligenceTag = { fragments: readonly IntelligenceFragment[] };
export type IntelligenceItem = {
  id: string;
  fragments: readonly IntelligenceFragment[];
  action?: { label: string; navigation: WorkspaceNavigation };
};
export type IntelligenceLogo = Component | string;
export type WorkspaceAnalysisRequest = { analysisId: string; query: string };

/** Only trim supplied terminal semicolons; rendering supplies exactly one. */
export function intelligenceSentence(fragments: readonly IntelligenceFragment[]): IntelligenceFragment[] {
  const result = fragments.map(fragment => ({ ...fragment }));
  for (let index = result.length - 1; index >= 0; index--) {
    const item = result[index]!;
    item.text = item.text.replace(/[；;\s]+$/u, '');
    if (item.text) break;
  }
  return result;
}
