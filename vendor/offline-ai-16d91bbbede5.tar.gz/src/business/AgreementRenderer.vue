<script setup lang="ts">
import { computed } from 'vue';
import { useBubbleEventFn, type BubbleContentRendererProps } from '@opentiny/tiny-robot';
import AgreementTable from './AgreementTable.vue';
import AiSummaryCard from './AiSummaryCard.vue';
import BusinessNavigationCard from './BusinessNavigationCard.vue';
import { resolveChatContent } from '../ui/messages/chatContent';
import type { Agreement, AssistantPart, BusinessNavigationTarget } from '../adapters/contracts';
import type { BusinessNavigationEvent } from './businessNavigation';
const props = defineProps<BubbleContentRendererProps>();
const part = computed(() => resolveChatContent(props.message)[props.contentIndex] as AssistantPart | undefined);
const emit = useBubbleEventFn();
function open(agreement: Agreement) { emit({ name: 'agreement:open', payload: agreement.id }); }
function navigate(target: BusinessNavigationTarget) {
  const event: BusinessNavigationEvent = { name: 'workspace:navigate', payload: target };
  emit(event);
}
</script>
<template>
  <AiSummaryCard v-if="part?.type === 'ai-summary'" :text="part.text" />
  <BusinessNavigationCard v-else-if="part?.type === 'business-navigation'" :title="part.title" :description="part.description" :target="part.target" @navigate="navigate" />
  <div v-else-if="part?.type === 'agreement-table'" class="table-card">
    <header class="table-title"><h3>近期到期协议</h3><span>共 {{ part.total }} 份 · 按到期时间排序</span></header>
    <AgreementTable :agreements="part.agreements" @open="open"><template v-if="$slots['table-status']" #status="slotProps"><slot name="table-status" v-bind="slotProps" /></template></AgreementTable>
    <div v-if="part.calculation" class="table-calculation"><p class="table-calculation__formula">{{ part.calculation.formula }}</p><p class="table-calculation__note">{{ part.calculation.note }}</p></div>
  </div>
  <div v-else-if="part?.type === 'empty-result'" class="empty-result"><span aria-hidden="true">○</span><h3>没有符合条件的协议</h3><p>调整时间范围或关键词后再查询。</p></div>
</template>

<style scoped>
/* Serializable consumer-owned formula/notes follow table paint, outside its clip.
   Reuse REQ-001 body/caption tokens; do not interpret formulas as executable code. */
.table-calculation { margin-top:var(--partner-ai-message-business-gap); }
.table-calculation .table-calculation__formula { margin:0; white-space:pre-wrap; overflow-wrap:anywhere; color:var(--partner-ai-text); font-size:var(--partner-ai-body-size); font-weight:var(--partner-ai-body-weight); line-height:var(--partner-ai-body-line); }
.table-calculation .table-calculation__note { margin:var(--partner-ai-gap-md) 0 0; color:var(--partner-ai-muted); font-size:var(--partner-ai-caption-size); font-weight:var(--partner-ai-body-weight); line-height:var(--partner-ai-caption-line); }
</style>
