<script setup lang="ts">
import { useId, type Component } from 'vue';
import { AiIcon, useAiIconDefinition } from '../ui/foundation/aiIcons';
defineProps<{ text: string; logo?: Component | string }>();
const smartIcon = useAiIconDefinition('smart.mark');
const logoMaskId = `summary-logo-${useId().replace(/[^a-zA-Z0-9-]/g, '')}`;
</script>

<template>
  <!-- REQ-020: business content inside the native reply Box. The default mark uses
       self-contained local artwork; provenance is recorded beside the SVG source. Consumers may
       provide an image URL/component; tags stay in a slot owned by the renderer.
       No Robot internal DOM hooks or input focus paint are used here. -->
  <section class="ai-summary-card" aria-label="智能综合回复">
    <span class="ai-summary-card__logo" aria-hidden="true">
      <img v-if="typeof logo === 'string'" :src="logo" alt="">
      <component :is="logo" v-else-if="logo" />
      <!-- Reuse the public icon as an alpha mask, without copying/repainting its
           paths. The HTML paint inside SVG uses the independent smart-icon gradient;
           useId prevents cross-card mask collisions. Recheck SVG mask/foreignObject
           support with the consumer browser matrix; custom logos bypass this layer. -->
      <AiIcon v-else-if="smartIcon.color !== 'gradient'" name="smart.mark" /><svg v-else class="ai-summary-card__gradient-logo" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
        <defs><mask :id="logoMaskId" x="0" y="0" width="24" height="24" maskUnits="userSpaceOnUse" style="mask-type:alpha"><AiIcon name="smart.mark" width="24" height="24" style="width:24px;height:24px" /></mask></defs>
        <foreignObject x="0" y="0" width="24" height="24" :mask="`url(#${logoMaskId})`"><div xmlns="http://www.w3.org/1999/xhtml" class="ai-summary-card__logo-paint" /></foreignObject>
      </svg>
    </span>
    <div class="ai-summary-card__body">
      <p class="ai-summary-card__text">{{ text }}</p>
      <div v-if="$slots.tags" class="ai-summary-card__tags"><slot name="tags" /></div>
    </div>
  </section>
</template>

<style scoped>
.ai-summary-card { position:relative; isolation:isolate; display:flex; align-items:flex-start; gap:var(--partner-ai-summary-gap); width:100%; min-width:0; box-sizing:border-box; margin:var(--partner-ai-summary-block-gap) 0 0; padding:var(--partner-ai-summary-padding); border:0; border-radius:var(--partner-ai-summary-radius); background:transparent; box-shadow:none; color:var(--partner-ai-text); }
/* Independent paint layers preserve full-opacity content. Mask only the 1px
   ring, as Sender does; card opacity is static and never follows editor focus.
   Recheck mask support with the host browser matrix when upgrading the runtime. */
.ai-summary-card::before,.ai-summary-card::after { content:''; position:absolute; inset:0; border-radius:inherit; pointer-events:none; }
.ai-summary-card::before { z-index:-2; background:var(--partner-ai-summary-bg); opacity:var(--partner-ai-summary-bg-opacity); }
.ai-summary-card::after { z-index:-1; box-sizing:border-box; padding:var(--partner-ai-summary-stroke-width); background:var(--partner-ai-summary-stroke-image); opacity:var(--partner-ai-summary-stroke-opacity); -webkit-mask:linear-gradient(#fff 0 0) content-box,linear-gradient(#fff 0 0); mask:linear-gradient(#fff 0 0) content-box,linear-gradient(#fff 0 0); -webkit-mask-composite:xor; mask-composite:exclude; }
.ai-summary-card__logo { display:flex; align-items:center; justify-content:center; flex:none; width:var(--partner-ai-summary-logo-size); height:var(--partner-ai-summary-logo-size); color:var(--partner-ai-text); }
.ai-summary-card__logo>img,.ai-summary-card__logo :deep(svg) { display:block; width:var(--partner-ai-smart-icon-artwork-size); height:var(--partner-ai-smart-icon-artwork-size); object-fit:contain; }
.ai-summary-card__logo-paint { width:100%; height:100%; background:var(--partner-ai-smart-icon-gradient); opacity:1; }
.ai-summary-card__body { flex:1; min-width:0; }
.ai-summary-card__text { margin:0 !important; color:var(--partner-ai-text); font-size:var(--partner-ai-body-size); font-weight:var(--partner-ai-body-weight); line-height:var(--partner-ai-body-line); white-space:pre-wrap; overflow-wrap:anywhere; }
/* Keep the summary's no-tag spacing stable; Markdown paragraph spacing is scoped separately. */
:global(.partner-ai .chat-scroll) .ai-summary-card .ai-summary-card__text { margin:0 !important; }
.ai-summary-card__tags { display:flex; flex-wrap:wrap; gap:var(--partner-ai-gap-sm); margin-top:var(--partner-ai-gap-md); }
:global(.partner-ai .chat-panel .chat-scroll .answer-content>.ai-summary-card:first-child) { margin-top:0; }
/* Only the new content block owns this adjacent business gap; existing cards,
   Box dimensions and the shared action footer retain their current behavior. */
:global(.partner-ai .chat-panel .chat-scroll .answer-content>.ai-summary-card + .table-card),
:global(.partner-ai .chat-panel .chat-scroll .answer-content>.ai-summary-card + .markdown-body) { margin-top:var(--partner-ai-summary-block-gap); }
</style>
