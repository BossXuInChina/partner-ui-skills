/** Stable values are unique within a tab group; labels are plain text. */
export interface WorkspaceSmartTab {
  value: string;
  label: string;
  smart?: boolean;
  disabled?: boolean;
}
