import { computed, markRaw, onBeforeUnmount, ref, useId, watch } from 'vue';
import type { BubbleContentRendererMatch, BubbleEvent } from '@opentiny/tiny-robot';
import AgreementRenderer from './AgreementRenderer.vue';
import type { Agreement, AgreementAssistantAdapter } from '../adapters/contracts';
import { useAgreementAssistant } from './useAgreementAssistant';
import { useConversationHistory } from './useConversationHistory';
import type { ConversationHistoryOptions } from '../ui/history/conversationHistory';
import { createClientId } from '../ui/foundation/clientId';
import { isWorkspaceNavigation, type AgreementBusinessAction, type BusinessActionMode, type WorkspaceNavigation } from '../host/businessAction';
export function useAgreementPanel(props: { adapter: AgreementAssistantAdapter; autoStart: boolean; historyOptions?: ConversationHistoryOptions; businessActionMode?: BusinessActionMode }, emit: (type: 'status', state: { dirty: boolean; busy: boolean }) => void, onBusinessAction?: (action: AgreementBusinessAction) => void, onWorkspaceNavigate?: (navigation: WorkspaceNavigation) => void) {
const scopeId = `partner-ai-${useId().replace(/[^a-zA-Z0-9-]/g, '')}`;
const assistant = useAgreementAssistant(props.adapter);
const { messages, isProcessing, requestState, send, retry, abortRequest, reset, resetting, activeRequestContext, error, updateRecord,regenerate,continueReply } = assistant;
const history = useConversationHistory(assistant, props.historyOptions);
const selected = ref<Agreement | null>(null);
const originalOwner = ref('');
const confirmation = ref<Agreement | null>(null);
const discard = ref(false);
const operationBusy = ref(false);
const operationError = ref('');
const toast = ref('');
const renewed = new Set<string>();
let operationController: AbortController | null = null;
let operationKey = '';
let toastTimer: ReturnType<typeof setTimeout> | undefined;
const dirty = computed(() => !!selected.value && selected.value.owner !== originalOwner.value);
const records = computed(() => {
  const result = new Map<string, Agreement>();
  for (const message of messages.value) for (const part of message.uiParts ?? []) {
    if (part.type === 'agreement-table') for (const item of part.agreements) result.set(item.id, item);
  }
  return [...result.values()];
});
const pendingCount = computed(() => records.value.filter(record => record.status === '待续签').length);
const renderers: BubbleContentRendererMatch[] = [{ find: (_message, content) => ['ai-summary', 'business-navigation', 'agreement-table', 'empty-result'].includes(content.type), renderer: markRaw(AgreementRenderer), priority: -10 }];
watch(history.ready, ready => { if (ready && props.autoStart && !messages.value.length) void send('查询待续签协议'); },{immediate:true});
onBeforeUnmount(() => { operationController?.abort(); clearTimeout(toastTimer); });
function currentStatus() { const state = { dirty: dirty.value, busy: operationBusy.value }; emit('status', state); return state; }
function discardDraft() { selected.value = null; confirmation.value = null; discard.value = false; operationError.value = ''; }

function notify(text: string) { toast.value = text; clearTimeout(toastTimer); toastTimer = setTimeout(() => { toast.value = ''; }, 3200); }
function applyBusinessUpdate(agreement: Agreement) { updateRecord({ ...agreement }); if (agreement.status !== '待续签') renewed.add(agreement.id); }
function handleEvent(event: BubbleEvent) {
  // REQ-022: navigation remains a host event; never interpret targets as URLs.
  if (event.name === 'workspace:navigate') { if (isWorkspaceNavigation(event.payload)) onWorkspaceNavigate?.(event.payload); return; }
  if(event.name==='chat:continue'){if(!operationBusy.value&&!dirty.value)void continueReply(Number(event.payload));return;}
  if(event.name==='chat:regenerate'){if(!operationBusy.value&&!dirty.value)void regenerate(Number(event.payload));return;}
  const record = records.value.find(item => item.id === event.payload);
  if (!record || operationBusy.value || !['agreement:open', 'agreement:renew'].includes(event.name)) return;
  if (event.name === 'agreement:renew' && (record.status !== '待续签' || renewed.has(record.id))) return;
  if (props.businessActionMode !== 'host' && (selected.value || confirmation.value)) { notify('请先完成或关闭当前业务操作'); return; }
  onBusinessAction?.({ type: event.name === 'agreement:open' ? 'open' : 'renew', agreement: { ...record } });
  // Explicit ownership prevents observational event listeners from duplicating overlays.
  if (props.businessActionMode === 'host') return;
  operationError.value = ''; operationKey = createClientId();
  if (event.name === 'agreement:open') { selected.value = { ...record }; originalOwner.value = record.owner; }
  if (event.name === 'agreement:renew' && record.status === '待续签' && !renewed.has(record.id)) confirmation.value = record;
}
function closeDrawer() { if (operationBusy.value) return; if (dirty.value) discard.value = true; else selected.value = null; }
async function saveEdit() {
  if (!selected.value || operationBusy.value) return;
  if (!selected.value.owner.trim()) { operationError.value = '负责人不能为空。'; return; }
  operationBusy.value = true; operationError.value = ''; const controller = operationController = new AbortController();
  // Consumer transports may settle after unmount despite cancellation. Never
  // update retained messages or start a new toast timer for an aborted operation.
  try { const updated = await props.adapter.updateAgreement(selected.value.id, { owner: selected.value.owner.trim() }, { signal: controller.signal, idempotencyKey: operationKey }); if (controller.signal.aborted) return; updateRecord(updated); selected.value = null; notify('负责人已更新'); }
  catch (failure) { if (!controller.signal.aborted) operationError.value = failure instanceof Error ? failure.message : '保存失败，请重试。'; }
  finally { operationBusy.value = false; operationController = null; }
}
async function confirmRenew() {
  if (!confirmation.value || operationBusy.value || renewed.has(confirmation.value.id)) return;
  operationBusy.value = true; operationError.value = ''; const controller = operationController = new AbortController();
  try { const updated = await props.adapter.renewAgreement(confirmation.value.id, { signal: controller.signal, idempotencyKey: operationKey }); if (controller.signal.aborted) return; renewed.add(updated.id); updateRecord(updated); confirmation.value = null; notify('已提交续签申请'); }
  catch (failure) { if (!controller.signal.aborted) operationError.value = failure instanceof Error ? failure.message : '提交失败，请重试。'; }
  finally { operationBusy.value = false; operationController = null; }
}
async function switchConversation(id?:string) { if (operationBusy.value || dirty.value || resetting.value) { notify('请先完成或取消当前编辑'); return false; } const changed=await history.change(id); if (changed) { discardDraft(); renewed.clear(); } return changed; }
async function newConversation() { return switchConversation(); }
async function clearHistory() { if (operationBusy.value || dirty.value || resetting.value) return false; const cleared=await history.clear(); if (cleared) { discardDraft(); renewed.clear(); } return cleared; }
async function removeConversation(id:string) {
  if(operationBusy.value||dirty.value||resetting.value)return false;
  const removingActive=id===history.activeId.value,removed=await history.remove(id);
  if(removed&&removingActive){discardDraft();renewed.clear();}
  return removed;
}

return { scopeId,messages,isProcessing,requestState,send,retry,abortRequest,reset,resetting,activeRequestContext,error,selected,originalOwner,confirmation,discard,operationBusy,operationError,toast,dirty,records,pendingCount,renderers,currentStatus,discardDraft,applyBusinessUpdate,handleEvent,closeDrawer,saveEdit,confirmRenew,newConversation,history,switchConversation,clearHistory,removeConversation };
}
