<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref, watch, nextTick } from 'vue';
import type { BusinessColumn } from './businessTable';
import { vAiTooltip } from '../ui/foundation/aiTooltip';
const props = withDefaults(defineProps<{ columns: BusinessColumn[]; rows: Record<string, unknown>[]; label?: string; rowKey?: string; minWidth?: number; fit?: boolean; ellipsis?: boolean; cellText?: (row: Record<string, unknown>, column: BusinessColumn) => string }>(), { label: '业务数据', rowKey: 'id', minWidth: undefined, fit: false, ellipsis: false, cellText: undefined });

// Workbench TableScrollArea (read-only source) paints a 14px track over the
// bottom edge while its viewport remains the sole horizontal scroll owner.
// This local adaptation has no fixed columns or Workbench runtime dependency.
const viewport=ref<HTMLElement>(), table=ref<HTMLTableElement>(), track=ref<HTMLElement>();
function textFor(row:Record<string, unknown>, column:BusinessColumn) { return props.cellText?.(row,column) ?? String(row[column.key] ?? ''); }
const width=ref(0), total=ref(0), left=ref(0), dragging=ref(false);
let observer:ResizeObserver|undefined, drag:{x:number;scroll:number;scale:number;travel:number;range:number}|undefined;
const overflow=computed(()=>total.value-width.value>1);
const thumbWidth=computed(()=>total.value ? width.value*width.value/total.value : 0);
const travel=computed(()=>Math.max(0,width.value-thumbWidth.value));
const thumbLeft=computed(()=>total.value>width.value ? left.value/(total.value-width.value)*travel.value : 0);
function measure(){const el=viewport.value;if(!el)return;width.value=el.clientWidth;total.value=el.scrollWidth;left.value=el.scrollLeft;}
function down(event:PointerEvent){
  const el=viewport.value,bar=track.value;if(!el||!bar||event.button!==0||!overflow.value||travel.value<=0)return;
  el.focus({preventScroll:true});const rect=bar.getBoundingClientRect(),scale=rect.width/bar.clientWidth||1,range=total.value-width.value;
  if(!(event.target instanceof Element && event.target.closest('.business-table__thumb'))) el.scrollLeft=((event.clientX-rect.left)/scale-thumbWidth.value/2)/travel.value*range;
  drag={x:event.clientX,scroll:el.scrollLeft,scale,travel:travel.value,range};dragging.value=true;bar.setPointerCapture(event.pointerId);event.preventDefault();
}
function move(event:PointerEvent){if(drag&&viewport.value)viewport.value.scrollLeft=drag.scroll+(event.clientX-drag.x)/drag.scale/drag.travel*drag.range;}
function end(){drag=undefined;dragging.value=false;}
function keydown(event:KeyboardEvent){
  const el=viewport.value;if(!el||event.target!==el)return;
  const delta=event.key==='ArrowLeft'?-40:event.key==='ArrowRight'?40:event.key==='PageUp'?-el.clientWidth:event.key==='PageDown'?el.clientWidth:undefined;
  if(delta!==undefined){event.preventDefault();el.scrollLeft+=delta;}
  else if(event.key==='Home'||event.key==='End'){event.preventDefault();el.scrollLeft=event.key==='Home'?0:el.scrollWidth;}
}
onMounted(()=>{observer=new ResizeObserver(measure);if(viewport.value)observer.observe(viewport.value);if(table.value)observer.observe(table.value);measure();});
onBeforeUnmount(()=>{observer?.disconnect();end();});
watch(()=>[props.rows, props.columns],()=>void nextTick(measure),{deep:true});
</script>

<template>
  <!-- Styling and bottom-overlay track follow Workbench Table; public data/events and status slot remain local. -->
  <div class="table-clip business-table" :class="{ 'is-fit': fit, 'is-ellipsis': ellipsis }" :style="minWidth === undefined ? undefined : { '--business-table-min-width': `${Math.max(0, minWidth)}px` }">
    <div ref="viewport" class="table-wrap business-table__viewport" role="region" :aria-label="`${label}横向滚动区域`" tabindex="0" @scroll="measure" @keydown="keydown">
      <table ref="table" :aria-label="label"><thead><tr><th v-for="column in columns" :key="column.key" v-ai-tooltip="{ content: column.title, disabled: !ellipsis, overflowOnly: true, overflowSelector: '.business-table__content' }" :tabindex="ellipsis ? 0 : undefined"><span class="business-table__content">{{ column.title }}</span></th></tr></thead><tbody>
        <tr v-for="(row, index) in rows" :key="String(row[rowKey] ?? index)"><td v-for="column in columns" :key="column.key" v-ai-tooltip="{ content: textFor(row,column), disabled: !ellipsis, overflowOnly: true, overflowSelector: '.business-table__content, .business-table__content *' }" :tabindex="ellipsis ? 0 : undefined"><div class="business-table__content"><slot name="cell" :row="row" :column="column">{{ row[column.key] }}</slot></div></td></tr>
      </tbody></table>
    </div>
    <div v-if="overflow" ref="track" class="business-table__track" :class="{'is-dragging':dragging}" aria-hidden="true" @pointerdown="down" @pointermove="move" @pointerup="end" @pointercancel="end" @lostpointercapture="end"><div class="business-table__thumb" :style="{width:`${thumbWidth}px`,transform:`translateX(${thumbLeft}px)`}" /></div>
  </div>
</template>

<style scoped>
/* Values ported from WorkbenchTable.vue, TableScrollArea.vue and its generated
   table/scrollbar tokens; keep this component self-contained and review on upgrade. */
.table-clip { position:relative; isolation:isolate; width:100%; max-width:100%; min-width:0; border-radius:var(--partner-ai-table-radius); overflow:hidden; }
.business-table .business-table__viewport { width:100%; overflow-x:auto; overflow-y:hidden; scrollbar-width:none; overscroll-behavior-x:contain; overscroll-behavior-y:auto; }
.business-table .business-table__viewport::-webkit-scrollbar { display:none; }
.business-table .business-table__viewport:focus-visible { outline:var(--partner-ai-focus-width) solid var(--partner-ai-focus); outline-offset:var(--partner-ai-focus-inset); }
.business-table table { width:max-content; min-width:max(100%,var(--business-table-min-width,var(--partner-ai-table-min-width))); border-spacing:0; border-collapse:separate; table-layout:fixed; color:var(--partner-ai-text); background:var(--partner-ai-panel-bg); font-size:var(--partner-ai-body-size); font-weight:var(--partner-ai-body-weight); line-height:var(--partner-ai-body-line); letter-spacing:var(--partner-ai-body-letter-spacing); }
.business-table.is-fit table { width:100%; }
.business-table.is-ellipsis th,.business-table.is-ellipsis td { overflow:hidden; text-overflow:ellipsis; }
.business-table.is-ellipsis .business-table__content { display:block; min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.business-table.is-ellipsis :is(th,td):focus-visible { outline:var(--partner-ai-focus-width) solid var(--partner-ai-focus); outline-offset:var(--partner-ai-focus-inset); }
.business-table th,.business-table td { box-sizing:border-box; height:var(--partner-ai-table-row-height); padding:0 var(--partner-ai-spacing-sm); border:0; border-bottom:var(--partner-ai-border-width) solid var(--partner-ai-divider); text-align:start; vertical-align:middle; white-space:nowrap; font:inherit; }
.business-table th { position:relative; color:var(--partner-ai-text); font-weight:var(--partner-ai-heading-weight); background-color:var(--partner-ai-panel-bg); background-image:linear-gradient(var(--partner-ai-table-header-bg),var(--partner-ai-table-header-bg)); }
.business-table th:not(:last-child)::after { content:''; position:absolute; top:50%; inset-inline-end:0; width:var(--partner-ai-border-width); height:var(--partner-ai-table-header-divider-height); background:var(--partner-ai-divider); transform:translateY(-50%); }
.business-table td { background:var(--partner-ai-panel-bg); border-bottom-color:var(--partner-ai-table-row-divider); }
.business-table tbody tr:hover td { background:var(--partner-ai-hover-bg); }
.business-table .business-table__action { border:0; padding:0; color:var(--partner-ai-action-text); background:transparent; font:inherit; text-align:start; cursor:pointer; }
.business-table__action span { position:relative; top:var(--partner-ai-table-action-label-offset); }
.business-table .business-table__action:hover { color:var(--partner-ai-action-text-hover); text-decoration:underline; }
.business-table .business-table__action:active { color:var(--partner-ai-table-action-active); text-decoration:underline; }
.business-table .business-table__action:focus-visible { outline:var(--partner-ai-border-width) solid var(--partner-ai-focus); outline-offset:var(--partner-ai-focus-control-offset); text-decoration:underline; }
.business-table__track { position:absolute; left:0; right:0; bottom:0; height:var(--partner-ai-scrollbar-size); z-index:4; touch-action:none; user-select:none; overflow:hidden; }
.business-table__thumb { position:absolute; bottom:0; height:calc(var(--partner-ai-scrollbar-size) - var(--partner-ai-scrollbar-safe) * 2); border-radius:var(--partner-ai-scrollbar-radius); background:var(--partner-ai-color-neutral-200); }
.business-table__track:hover .business-table__thumb,.business-table__track.is-dragging .business-table__thumb { height:calc(var(--partner-ai-scrollbar-size) - var(--partner-ai-scrollbar-safe-hover) * 2); background:var(--partner-ai-scrollbar-thumb-hover); }
</style>
