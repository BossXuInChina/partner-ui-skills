<script setup lang="ts">
import { computed, nextTick, onBeforeUnmount, onMounted, onUpdated, ref, watch } from 'vue';
import WorkspaceSmartIcon from './WorkspaceSmartIcon.vue';
import type { IntelligenceLogo, IntelligenceFragment } from './workspaceIntelligence';
const props = withDefaults(defineProps<{ fragments: readonly IntelligenceFragment[]; logo?: IntelligenceLogo; autoFollowHighlight?:boolean }>(),{autoFollowHighlight:true});
const emit = defineEmits<{ activate: []; highlightCenter:[center:{x:number;y:number}] }>();
const tagElement = ref<HTMLButtonElement>(), textElement = ref<HTMLElement>(), resolvedBackground = ref('');
const resolvedStyle = computed(() => resolvedBackground.value ? {'--ov-smart-tag-bg-resolved':resolvedBackground.value} : {});
let resizeObserver:ResizeObserver | undefined, mutationObserver:MutationObserver | undefined, frame = 0, disposed = false;
let defaultBackground = '', defaultCenter:{x:number;y:number} = {x:45.1526,y:49.1071}, lastCenter = '';
function withCenter(background:string,x:number,y:number) {
  const pattern = /^(\s*radial-gradient\(\s*(?:circle|ellipse)\s+[^,]*?\bat\s+)[^,]+/s;
  return background.replace(pattern,(_match,prefix:string) => `${prefix}${Number(x.toFixed(4))}% ${Number(y.toFixed(4))}%`);
}
function sourceBackground(element:HTMLElement) {
  return getComputedStyle(element).getPropertyValue('--partner-ai-smart-tag-bg').trim() || defaultBackground;
}
function notifyCenter(x:number,y:number) {
  const center = {x:Number(x.toFixed(4)),y:Number(y.toFixed(4))}, key = `${center.x}:${center.y}`;
  if (key === lastCenter) return;
  lastCenter = key; emit('highlightCenter',center);
}
function scheduleMeasure() {
  if (disposed || frame || !props.autoFollowHighlight) return;
  frame = requestAnimationFrame(() => { frame = 0; measureHighlight(); });
}
function measureHighlight() {
  const element = tagElement.value, text = textElement.value;
  if (!element || !text || disposed || !props.autoFollowHighlight) return;
  const source = sourceBackground(element);
  if (!defaultBackground) {
    defaultBackground = source;
    const point = source.match(/^\s*radial-gradient\(\s*(?:circle|ellipse)\s+[^,]*?\bat\s+(-?\d*\.?\d+)%\s+(-?\d*\.?\d+)%/s);
    if (point) defaultCenter = {x:Number(point[1]),y:Number(point[2])};
  }
  const box = element.getBoundingClientRect();
  const clip = text.getBoundingClientRect();
  const rects = [...text.querySelectorAll<HTMLElement>('.intelligence-fragment--data')]
    .flatMap(node => [...node.getClientRects()])
    .map(rect => ({left:Math.max(rect.left,clip.left),right:Math.min(rect.right,clip.right),top:Math.max(rect.top,clip.top),bottom:Math.min(rect.bottom,clip.bottom)}))
    .filter(rect => rect.right > rect.left && rect.bottom > rect.top);
  if (box.width <= 0 || box.height <= 0 || !rects.length) {
    resolvedBackground.value = withCenter(source,defaultCenter.x,defaultCenter.y);
    notifyCenter(defaultCenter.x,defaultCenter.y);
    return;
  }
  const left = Math.min(...rects.map(rect => rect.left)), right = Math.max(...rects.map(rect => rect.right));
  const top = Math.min(...rects.map(rect => rect.top)), bottom = Math.max(...rects.map(rect => rect.bottom));
  const x = ((left + right) / 2 - box.left) / box.width * 100;
  const y = ((top + bottom) / 2 - box.top) / box.height * 100;
  resolvedBackground.value = withCenter(source,x,y);
  notifyCenter(x,y);
}
function observeText() {
  if (!resizeObserver || !tagElement.value || !textElement.value) return;
  resizeObserver.disconnect(); resizeObserver.observe(tagElement.value); resizeObserver.observe(textElement.value);
  textElement.value.querySelectorAll('.intelligence-fragment--data').forEach(node => resizeObserver!.observe(node));
}
function onWindowResize() { scheduleMeasure(); }
watch(() => props.autoFollowHighlight,enabled => {
  if (!enabled) { resolvedBackground.value = ''; return; }
  lastCenter = '';
  scheduleMeasure();
},{immediate:true});
onMounted(async () => {
  const element = tagElement.value;
  if (!element) return;
  resizeObserver = new ResizeObserver(scheduleMeasure);
  observeText();
  mutationObserver = new MutationObserver(scheduleMeasure);
  for (let ancestor:HTMLElement | null = element; ancestor; ancestor = ancestor.parentElement) {
    mutationObserver.observe(ancestor,{attributes:true,attributeFilter:['style','class']});
  }
  window.addEventListener('resize',onWindowResize,{passive:true});
  document.fonts?.addEventListener('loadingdone',scheduleMeasure);
  await document.fonts?.ready;
  if (!disposed) scheduleMeasure();
});
onUpdated(() => { void nextTick(() => { observeText(); scheduleMeasure(); }); });
onBeforeUnmount(() => {
  disposed = true; if (frame) cancelAnimationFrame(frame);
  resizeObserver?.disconnect(); mutationObserver?.disconnect();
  window.removeEventListener('resize',onWindowResize);
  document.fonts?.removeEventListener('loadingdone',scheduleMeasure);
});
</script>
<template>
  <!-- REQ-024 uses a native button for activation and keyboard semantics. The
       white paint spot follows rendered data fragments; background opacity is
       independent from text/icon opacity and card/ring paint. -->
  <button ref="tagElement" type="button" class="workspace-smart-tag" :style="resolvedStyle" :aria-label="fragments.map(fragment => fragment.text).join('')" aria-description="激活AI侧边栏" @click="$emit('activate')">
    <span class="workspace-smart-tag__paint" aria-hidden="true" />
    <WorkspaceSmartIcon :logo="logo" />
    <span ref="textElement" class="workspace-smart-tag__text"><span v-for="(fragment, index) in fragments" :key="index" class="intelligence-fragment" :class="fragment.emphasis && `intelligence-fragment--${fragment.emphasis}`">{{ fragment.text }}</span></span>
  </button>
</template>
<style scoped>
.workspace-smart-tag { position:relative; isolation:isolate; display:inline-flex; align-items:center; flex:none; max-width:100%; height:var(--partner-ai-smart-tag-height); padding:0 var(--partner-ai-smart-tag-padding-inline); gap:var(--partner-ai-smart-tag-gap); border:0; border-radius:var(--partner-ai-smart-tag-radius); color:var(--partner-ai-text); font-size:var(--partner-ai-body-size); line-height:var(--partner-ai-body-line); font-weight:var(--partner-ai-body-weight); text-align:left; cursor:pointer; }
.workspace-smart-tag:focus-visible { outline:var(--partner-ai-focus-width) solid var(--partner-ai-focus); outline-offset:var(--partner-ai-focus-control-offset); }
/* A contained, out-of-flow paint layer lets cqw resolve against this tag
   without applying size containment to the naturally content-sized button. */
.workspace-smart-tag__paint { position:absolute; z-index:-1; inset:0; container-type:inline-size; border-radius:inherit; pointer-events:none; }
.workspace-smart-tag__paint::before { content:''; position:absolute; inset:0; border-radius:inherit; background:var(--ov-smart-tag-bg-resolved,var(--partner-ai-smart-tag-bg)); opacity:var(--partner-ai-smart-tag-bg-opacity); pointer-events:none; }
.workspace-smart-tag::after { content:''; position:absolute; inset:0; border:var(--partner-ai-smart-tag-stroke-width) solid var(--partner-ai-smart-tag-stroke); border-radius:inherit; pointer-events:none; }
.workspace-smart-tag__text { min-width:0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
</style>
