import { createApp } from 'vue';
import App from './App.vue';
import './preview/studio.css';
import './workbench-tokens.css';
createApp(App).mount('#app');

// Standalone preview opts into local fonts as the host application.
import './preview/optional-fonts.css';
