import { computed, onBeforeUnmount, onMounted, ref, watch, type Ref } from 'vue';

/** Visible business rectangle, in local viewport coordinates. No guessed nav height. */
export function useHostRegion(region: Ref<HTMLElement | undefined>) {
  const bounds = ref({ left: 0, top: 0, width: 0, height: 0 });
  let observer: ResizeObserver | undefined;
  function measure() {
    const box = region.value?.getBoundingClientRect(), view = window.visualViewport;
    if (!box) { bounds.value = { left: 0, top: 0, width: 0, height: 0 }; return; }
    const left = Math.max(box.left, view?.offsetLeft ?? 0), top = Math.max(box.top, view?.offsetTop ?? 0);
    bounds.value = { left, top,
      width: Math.max(0, Math.min(box.right, (view?.offsetLeft ?? 0) + (view?.width ?? window.innerWidth)) - left),
      height: Math.max(0, Math.min(box.bottom, (view?.offsetTop ?? 0) + (view?.height ?? window.innerHeight)) - top) };
  }
  onMounted(() => {
    observer = new ResizeObserver(measure);
    // Ancestor resizing includes navigation/layout changes that move an unchanged region.
    watch(region, (node, old) => {
      if (old) observer?.disconnect();
      for (let item = node; item; item = item.parentElement ?? undefined) observer?.observe(item);
      measure();
    }, { immediate: true, flush: 'post' });
    window.addEventListener('resize', measure);
    window.addEventListener('scroll', measure, true);
    window.visualViewport?.addEventListener('resize', measure);
    window.visualViewport?.addEventListener('scroll', measure);
  });
  onBeforeUnmount(() => {
    observer?.disconnect();
    window.removeEventListener('resize', measure);
    window.removeEventListener('scroll', measure, true);
    window.visualViewport?.removeEventListener('resize', measure);
    window.visualViewport?.removeEventListener('scroll', measure);
  });
  const style = computed(() => Object.fromEntries(Object.entries(bounds.value).map(([key, value]) => [key, `${value}px`])));
  return { bounds, style, measure };
}
