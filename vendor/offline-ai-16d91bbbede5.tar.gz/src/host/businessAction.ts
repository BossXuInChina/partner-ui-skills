import type { Agreement } from '../adapters/contracts';

/** Runtime UI events; hosts own routing, permissions and business operations. */
export type AgreementBusinessAction = { type: 'open' | 'renew'; agreement: Agreement };
export type WorkspaceNavigation = { target: string; params?: Record<string, string> };
export type BusinessActionMode = 'default' | 'host';
export type BusinessDialogScope = 'region' | 'global';

export function isWorkspaceNavigation(value: unknown): value is WorkspaceNavigation {
  if (!value || typeof value !== 'object') return false;
  const item = value as Record<string, unknown>;
  return typeof item.target === 'string' && !!item.target.trim() &&
    (item.params === undefined || (!!item.params && typeof item.params === 'object' &&
      !Array.isArray(item.params) && Object.values(item.params).every(value => typeof value === 'string')));
}
