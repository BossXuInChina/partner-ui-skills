import type { InjectionKey, Ref } from 'vue';

export interface BusinessOverlayContext {
  target: Ref<HTMLElement | undefined>;
  stack: Ref<symbol[]>;
}
export const businessOverlayKey: InjectionKey<BusinessOverlayContext> = Symbol('partner-business-overlay');
