<script setup lang="ts">
import { onBeforeUnmount, provide, ref, toRef, watch } from 'vue';
import { businessOverlayKey } from './businessOverlay';
import { useHostRegion } from './useHostRegion';
const props = defineProps<{ region?: HTMLElement; layer?: number }>();
const target = ref<HTMLElement>(), stack = ref<symbol[]>([]);
const { style } = useHostRegion(toRef(props, 'region'));
provide(businessOverlayKey, { target, stack });
let restore: (() => void) | undefined;
// REQ-022: native showModal makes the whole document inert. Local modality instead
// blocks only the supplied business region; portals live outside that inert subtree.
// TinyRobot internals and vendor WorkbenchModal are not patched or intercepted.
watch(() => [props.region, stack.value.length] as const, ([region, count]) => {
  restore?.(); restore = undefined;
  if (region && count) { const wasInert = region.inert; region.inert = true; restore = () => { region.inert = wasInert; }; }
}, { flush: 'sync' });
onBeforeUnmount(() => restore?.());
</script>
<template>
  <slot />
  <Teleport to="body"><div ref="target" class="partner-business-overlay-host" :style="{ ...style, zIndex: layer ?? 1000 }" :data-overlay-count="stack.length" /></Teleport>
</template>
<style>
.partner-business-overlay-host { position:fixed; overflow:clip; pointer-events:none; isolation:isolate; }
</style>
