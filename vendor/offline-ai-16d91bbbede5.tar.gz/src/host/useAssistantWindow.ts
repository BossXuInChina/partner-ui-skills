import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch, type Ref } from 'vue';
import type { ChatWindowMode } from '../ui/panel/chatWindow';

const edge = 12;
const floatingWidth = 420;
const defaultHeight = 910;
const resizeHandleHeight = 16;
const minimumMainHeight = 24;
const detachThreshold = 5;
const clamp = (value: number, min: number, max: number) => Math.min(Math.max(value, min), Math.max(min, max));

// REQ-008 / REQ-022, TinyRobot 0.5.1: native floating supports drag/resize and
// instance retention, but has no public handoff for the captured sidebar gesture.
// The type-valid normal-first -> controlled-floating probe ignored geometry seeds
// and corrections; native aria-hidden resize handles provide no keyboard contract.
// Its body Teleport probe also lost focus and ancestor event/style scope, with no
// public workspace bounds/portal target. Keep one consumer wrapper and keyboard
// move/height controls; do not bridge private refs/handles or duplicate engines.
// Recheck these APIs on upgrade; audit/adoption criteria: AssistantHostLayout.vue.
export function useAssistantWindow(workspace: Ref<HTMLElement | undefined>, mode: Ref<ChatWindowMode>, open: Ref<boolean>, fullscreen: Ref<boolean> = ref(false), flow: Ref<boolean> = ref(false)) {
  const bounds = ref({ x: 0, y: 0, width: 0, height: 0 });
  const left = ref(0), top = ref(0), dragging = ref(false), resizing = ref(false);
  // REQ-012 v0.2:910px is the unadjusted preference. Clip the bottom below the
  // current top anchor when workspace space runs out; never overlap host navigation.
  // Manual pixel preference lives only in this mounted host; clamping does not erase
  // it when temporarily embedded in a smaller workspace. No storage/public API change.
  const preferredHeight = ref<number>();
  const contentMinimum = ref(0);
  // Default button-opened windows reserve12px. A dragged-out sidebar starts on the
  // workspace edge: keep0px position inset so the grip never jumps at detachment.
  // Width reserves safe gutters; height yields to small workspaces. The entire window is bounded.
  const positionInset = ref(edge);
  const insetX = computed(() => Math.min(edge, bounds.value.width / 2));
  // Keep the existing 16px minimum safety allowance after removing the painted
  // resize strip. The absolute edge target no longer subtracts from panel layout.
  const comfortableMinimum = computed(() => contentMinimum.value + resizeHandleHeight);
  const insetY = computed(() => Math.min(edge, Math.max(0, (bounds.value.height - comfortableMinimum.value) / 2)));
  const width = computed(() => Math.max(0, Math.floor(Math.min(floatingWidth, bounds.value.width - insetX.value * 2))));
  // Whole CSS pixels keep clamped edges stable under layout subpixel rounding.
  const maximumHeight = computed(() => Math.max(0, Math.floor(bounds.value.y + bounds.value.height - Math.min(positionInset.value, insetY.value) - top.value)));
  const minimumHeight = computed(() => Math.min(comfortableMinimum.value, maximumHeight.value));
  const height = computed(() => Math.floor(clamp(preferredHeight.value ?? defaultHeight, minimumHeight.value, maximumHeight.value)));
  const resizeMaximum = maximumHeight;
  const compact = computed(() => maximumHeight.value < comfortableMinimum.value);
  const style = computed(() => !fullscreen.value && mode.value === 'floating' ? { left: `${left.value}px`, top: `${top.value}px`, width: `${width.value}px`, height: `${height.value}px`, '--assistant-content-min-height': `${contentMinimum.value}px`, '--assistant-resize-handle-height': `${Math.min(resizeHandleHeight, height.value)}px` } : {});
  let positioned = false;
  let detaching = false;
  let observer: ResizeObserver | undefined;
  let gesture: { pointerId: number; target: HTMLElement; x: number; y: number; left: number; top: number; pending: boolean; pointerType: string; kind: 'move' | 'resize'; height: number } | undefined;

  // On workspace resize preserve the top anchor while clipping height. Only yield
  // when a severely shortened workspace cannot show move/resize controls there.
  // Move gestures retain their current window height instead of shrinking while moving.
  function constrain(windowHeight = Math.min(24 + resizeHandleHeight, bounds.value.height)) {
    const x = Math.min(positionInset.value, insetX.value), y = Math.min(positionInset.value, insetY.value);
    left.value = clamp(left.value, bounds.value.x + x, bounds.value.x + bounds.value.width - width.value - x);
    top.value = clamp(top.value, bounds.value.y + y, bounds.value.y + bounds.value.height - windowHeight - y);
  }
  function finish() {
    const previous = gesture;
    gesture = undefined;
    dragging.value = false;
    resizing.value = false;
    window.removeEventListener('pointermove', move);
    window.removeEventListener('pointerup', end);
    window.removeEventListener('pointercancel', end);
    window.removeEventListener('mouseup', mouseEnd);
    window.removeEventListener('blur', finish);
    document.removeEventListener('visibilitychange', visibility);
    previous?.target.removeEventListener('lostpointercapture', end);
    if (previous?.target.hasPointerCapture(previous.pointerId)) previous.target.releasePointerCapture(previous.pointerId);
  }
  function end(event: PointerEvent) { if (event.pointerId === gesture?.pointerId) finish(); }
  function mouseEnd(event: MouseEvent) { if (event.button === 0 && gesture?.pointerType === 'mouse') finish(); }
  function visibility() { if (document.hidden) finish(); }
  // The owned aside is a direct workspace child in both public/demo hosts.
  // Ignore ChatPanels in nested business workspaces when measuring/observing slots.
  function fixedSlots() {
    const panel = workspace.value?.querySelector(':scope > [data-assistant-window]');
    return ['.chat-handle-area', '.chat-header', '.chat-footer'].map(selector => panel?.querySelector(selector));
  }
  function measure() {
    // Fullscreen geometry must not overwrite the remembered floating position/minimum.
    if (fullscreen.value) return;
    const box = workspace.value?.getBoundingClientRect();
    if (!box) return;
    // REQ-017: expanding a draft must shrink main, not increase the window's minimum
    // or cancel its resize gesture. Reserve one editor line + the measured action/
    // padding overhead; the compact viewport still handles impossible workspaces.
    const fixed = fixedSlots().map((node, index) => {
      if (!node) return 0;
      const paint = getComputedStyle(node), height = parseFloat(paint.height) || 0;
      const sender = index === 2 ? node.querySelector<HTMLElement>('.chat-composer') : null;
      return sender ? height - sender.offsetHeight + (parseFloat(paint.getPropertyValue('--composer-min-usable-height')) || 86) : height;
    });
    const nextMinimum = Math.ceil(fixed.reduce((sum, value) => sum + value, 0) + minimumMainHeight);
    if (nextMinimum !== contentMinimum.value) { finish(); contentMinimum.value = nextMinimum; }
    const view = window.visualViewport;
    let scrollport: HTMLElement | null = flow.value ? workspace.value?.parentElement ?? null : null;
    while (scrollport && !/(auto|scroll)/.test(getComputedStyle(scrollport).overflowY)) scrollport = scrollport.parentElement;
    const clip = scrollport?.getBoundingClientRect();
    const x = Math.max(box.left, view?.offsetLeft ?? 0, clip?.left ?? -Infinity), y = Math.max(box.top, view?.offsetTop ?? 0, clip?.top ?? -Infinity);
    const right = Math.min(box.right, (view?.offsetLeft ?? 0) + (view?.width ?? window.innerWidth), clip?.right ?? Infinity);
    const bottom = Math.min(box.bottom, (view?.offsetTop ?? 0) + (view?.height ?? window.innerHeight), clip?.bottom ?? Infinity);
    const next = { x: x - box.left, y: y - box.top, width: Math.max(0, right - x), height: Math.max(0, bottom - y) };
    // A queued ResizeObserver notification with unchanged bounds must not cancel a
    // gesture that just started. Actual viewport/workspace changes end capture.
    if (Object.keys(next).some(key => next[key as keyof typeof next] !== bounds.value[key as keyof typeof next])) { finish(); bounds.value = next; }
    constrain(flow.value && mode.value === 'floating' ? Math.min(preferredHeight.value ?? defaultHeight, Math.max(0, bounds.value.height - insetY.value * 2)) : undefined);
  }
  function move(event: PointerEvent) {
    if (!gesture || event.pointerId !== gesture.pointerId) return;
    const current = gesture;
    const dx = event.clientX - current.x, dy = event.clientY - current.y;
    if (current.kind === 'resize') {
      preferredHeight.value = Math.floor(clamp(current.height + dy, minimumHeight.value, resizeMaximum.value));
      return;
    }
    if (current.pending) {
      if (Math.hypot(dx, dy) <= detachThreshold) return;
      // Seed from the actual dock rectangle and preserve the same pointer capture.
      // Skip only this intentional mode change's cleanup; buttons/close/resize still finish.
      current.pending = false;
      positioned = true;
      positionInset.value = 0;
      left.value = current.left + dx;
      top.value = current.top + dy;
      detaching = true;
      mode.value = 'floating';
      detaching = false;
      if (gesture !== current) return;
      dragging.value = true;
    } else {
      left.value = current.left + dx;
      top.value = current.top + dy;
    }
    constrain(current.height);
  }
  function begin(event: PointerEvent, kind: 'move' | 'resize') {
    if (fullscreen.value) return;
    if (kind === 'resize' && mode.value !== 'floating') return;
    if (!open.value || !event.isPrimary || event.button !== 0 || !(event.currentTarget instanceof HTMLElement)) return;
    finish();
    measure();
    const target = event.currentTarget;
    const panel = target.closest('[data-assistant-window]')?.getBoundingClientRect();
    const host = workspace.value?.getBoundingClientRect();
    if (!panel || !host) return;
    event.preventDefault();
    target.focus({ preventScroll: true });
    // A 480px dock becomes a 420px window. Preserve the normalized grab point
    // (including its centered grip) so the SAME captured gesture remains continuous.
    const anchorCorrection = mode.value === 'sidebar' ? (panel.width - width.value) * clamp((event.clientX - panel.left) / panel.width, 0, 1) : 0;
    gesture = { pointerId: event.pointerId, target, x: event.clientX, y: event.clientY, left: panel.left - host.left + anchorCorrection, top: panel.top - host.top, pending: mode.value === 'sidebar', pointerType: event.pointerType, kind, height: height.value };
    dragging.value = kind === 'move' && !gesture.pending;
    resizing.value = kind === 'resize';
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', end);
    window.addEventListener('pointercancel', end);
    window.addEventListener('mouseup', mouseEnd);
    window.addEventListener('blur', finish);
    document.addEventListener('visibilitychange', visibility);
    target.addEventListener('lostpointercapture', end);
    try { target.setPointerCapture(event.pointerId); } catch { finish(); }
  }
  function start(event: PointerEvent) { begin(event, 'move'); }
  function resizeStart(event: PointerEvent) { begin(event, 'resize'); }
  function resizeKeyboard(event: KeyboardEvent) {
    if (fullscreen.value || !open.value || mode.value !== 'floating' || event.altKey || event.ctrlKey || event.metaKey) return;
    if (event.key === 'Escape' && gesture) { event.preventDefault(); event.stopPropagation(); finish(); return; }
    if (!['ArrowUp', 'ArrowDown', 'Home', 'End'].includes(event.key)) return;
    event.preventDefault();
    finish();
    const step = event.shiftKey ? 40 : 10;
    const next = event.key === 'Home' ? minimumHeight.value : event.key === 'End' ? resizeMaximum.value : height.value + (event.key === 'ArrowUp' ? -step : step);
    preferredHeight.value = Math.floor(clamp(next, minimumHeight.value, resizeMaximum.value));
  }
  function keyboard(event: KeyboardEvent) {
    if (fullscreen.value || !open.value || event.altKey || event.ctrlKey || event.metaKey) return;
    if (event.key === 'Escape' && gesture) { event.preventDefault(); event.stopPropagation(); finish(); return; }
    if (mode.value === 'sidebar') {
      if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); mode.value = 'floating'; }
      return;
    }
    if (!['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(event.key)) return;
    event.preventDefault();
    finish();
    const movingHeight = height.value;
    const step = event.shiftKey ? 40 : 10;
    if (event.key === 'ArrowLeft') left.value -= step;
    if (event.key === 'ArrowRight') left.value += step;
    if (event.key === 'ArrowUp') top.value -= step;
    if (event.key === 'ArrowDown') top.value += step;
    constrain(movingHeight);
  }
  function positionFloating() {
    if (fullscreen.value || mode.value !== 'floating' || positioned) return;
    left.value = bounds.value.x + bounds.value.width - width.value - insetX.value;
    top.value = bounds.value.y + insetY.value;
    positioned = true; constrain();
  }
  watch(mode, (value, previous) => {
    if (flow.value && value === 'floating' && previous === 'sidebar' && !detaching) positioned = false;
    if (!detaching) finish();
    if (fullscreen.value) return;
    measure(); positionFloating();
  }, { flush: 'sync' });
  watch(fullscreen, value => {
    finish();
    if (!value) void nextTick(() => { measure(); positionFloating(); });
  }, { flush: 'sync' });
  watch(open, finish, { flush: 'sync' });
  onMounted(() => {
    measure();
    observer = new ResizeObserver(measure);
    if (workspace.value) {
      observer.observe(workspace.value);
      // Fixed-slot sizes can change with consumer configuration without workspace resize.
      for (const node of fixedSlots()) if (node) observer.observe(node);
    }
    window.addEventListener('resize', measure);
    window.addEventListener('scroll', measure, true);
    positionFloating();
    window.visualViewport?.addEventListener('resize', measure);
    window.visualViewport?.addEventListener('scroll', measure);
  });
  onBeforeUnmount(() => {
    finish(); observer?.disconnect();
    window.removeEventListener('resize', measure);
    window.removeEventListener('scroll', measure, true);
    window.visualViewport?.removeEventListener('resize', measure);
    window.visualViewport?.removeEventListener('scroll', measure);
  });
  return { style, dragging, resizing, compact, height, minimumHeight, resizeMaximum, start, keyboard, resizeStart, resizeKeyboard };
}
