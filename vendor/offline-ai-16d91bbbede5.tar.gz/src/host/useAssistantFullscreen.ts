import { watch, type Ref } from 'vue';

/** Consumer-owned workspace expansion; native menus/dialogs keep Escape priority.
 * Robot 0.5.1 Layout has no workspace fullscreen API. No browser Fullscreen API,
 * dependency DOM hooks or new panel instance; recheck Layout on upgrades. */
export function useAssistantFullscreen(open: Ref<boolean>, fullscreen: Ref<boolean>) {
  watch(open, value => { if (!value) fullscreen.value = false; }, { flush: 'sync' });
  function toggle() { if (open.value) fullscreen.value = !fullscreen.value; }
  // Host capture runs after document popup handlers and before Sender editor
  // keymaps, which can preventDefault on Escape even with no popup.
  function escape(event: KeyboardEvent) {
    if (event.key !== 'Escape' || event.defaultPrevented || !open.value || !fullscreen.value) return false;
    if (document.querySelector('dialog[open],.wb-modal-host,[popover]:popover-open,[role="listbox"]')) return false;
    event.preventDefault(); event.stopPropagation(); fullscreen.value = false;
    return true;
  }
  return { toggle, escape };
}
