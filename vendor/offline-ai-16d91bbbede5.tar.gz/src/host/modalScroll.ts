/** Shared scroll lease for native global UI dialogs and the local Workbench port.
 * Preserve prior inline values/priorities across nested and interrupted dialogs. */
const locks = new WeakMap<Document, { count:number; restore:()=>void }>();
export function lockModalScroll(doc:Document) {
  let lock=locks.get(doc);
  if(!lock) {
    const previous=[doc.body,doc.documentElement].map(node=>({node,value:node.style.getPropertyValue('overflow'),priority:node.style.getPropertyPriority('overflow')}));
    for(const item of previous)item.node.style.setProperty('overflow','hidden');
    lock={count:0,restore:()=>{for(const {node,value,priority} of previous){if(value)node.style.setProperty('overflow',value,priority);else node.style.removeProperty('overflow');}}};locks.set(doc,lock);
  }
  lock.count++;let released=false;
  return ()=>{if(released)return;released=true;if(!--lock!.count){lock!.restore();locks.delete(doc);}};
}
