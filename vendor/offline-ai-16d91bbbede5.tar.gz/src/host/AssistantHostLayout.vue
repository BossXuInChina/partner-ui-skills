<script setup lang="ts">
import { ref, toRef, watch } from 'vue';
import BusinessOverlayHost from './BusinessOverlayHost.vue';
import { useAssistantHostLayout } from './useAssistantHostLayout';
import { useAssistantWindow } from './useAssistantWindow';
import { useAssistantFullscreen } from './useAssistantFullscreen';
import './assistantWindow.css';
import type { ChatSidebarBehavior, ChatWindowMode } from '../ui/panel/chatWindow';
// ChatPanel already reuses public TrLayout normal header/main/footer slots.
// TinyRobot 0.5.1 dock/floating/Container were isolated-tested on 2026-10-15:
// native floating can drag/resize and retain children, but gesture continuity,
// controlled geometry, keyboard controls and Teleport host boundaries differed.
// Container adds viewport chrome without replacing these workspace controls.
// Keep this consumer shell; reassess public APIs on upgrade and adopt only when
// equivalent UX also reduces maintenance. Details: useAssistantWindow.ts and
// .artifacts/tinyrobot-host-layout-experiment-20261015/report.json.
const props = withDefaults(defineProps<{ open: boolean; windowMode?: ChatWindowMode; sidebarBehavior?: ChatSidebarBehavior; fullscreen?: boolean; viewportWidth?: number; overlayLayer?: number; flow?: boolean }>(), { windowMode: 'sidebar', sidebarBehavior:'push', fullscreen: false, viewportWidth: undefined, overlayLayer: 1000, flow: false });
const emit = defineEmits<{ 'update:windowMode': [mode: ChatWindowMode]; 'update:fullscreen': [value: boolean] }>();
const workspace = ref<HTMLElement>(), business = ref<HTMLElement>();
const mode = ref(props.windowMode), open = toRef(props, 'open');
const fullscreen = ref(props.fullscreen);
watch(() => props.fullscreen, value => { fullscreen.value = value; });
watch(fullscreen, value => emit('update:fullscreen', value), { flush: 'sync' });
const expansion = useAssistantFullscreen(open, fullscreen);
watch(() => props.windowMode, value => { mode.value = value; });
watch(mode, value => emit('update:windowMode', value), { flush: 'sync' });
const viewportWidth = toRef(props, 'viewportWidth');
const layout = useAssistantHostLayout(workspace, { open, mode, sidebarBehavior:toRef(props,'sidebarBehavior'), fullscreen, viewportWidth, flow:toRef(props,'flow') });
const floating = useAssistantWindow(workspace, mode, open, fullscreen, toRef(props, 'flow'));
function switchMode() { if (!fullscreen.value) mode.value = mode.value === 'sidebar' ? 'floating' : 'sidebar'; }
</script>
<template>
  <div class="partner-assistant-host" :data-sidebar-behavior="sidebarBehavior" :class="{ 'is-open': open, 'is-fullscreen': fullscreen, 'is-floating': mode === 'floating' && !fullscreen, 'is-compact': floating.compact.value, 'is-flow': flow }" @keydown.capture="expansion.escape">
    <div class="partner-assistant-navigation"><slot name="navigation" /></div>
    <BusinessOverlayHost :region="business" :layer="overlayLayer">
      <div ref="workspace" class="partner-assistant-workspace" :style="layout.workspaceStyle.value">
        <section ref="business" class="partner-assistant-business" :aria-hidden="open && fullscreen || undefined"><slot /></section>
        <!-- One permanently mounted consumer slot preserves streams, drafts and scroll. -->
        <aside data-assistant-window class="partner-assistant-window" :class="{ 'is-moving': floating.dragging.value || floating.resizing.value }" :data-window-mode="mode" :data-fullscreen="fullscreen" :inert="!open" :aria-hidden="!open" :style="{ ...layout.assistantStyle.value, ...floating.style.value }">
          <div class="partner-assistant-window-content"><slot name="assistant" :window-mode="mode" :fullscreen="fullscreen" :toggle-fullscreen="expansion.toggle" :switch-mode="switchMode" :drag-start="floating.start" :drag-keydown="floating.keyboard" /></div>
          <div v-if="mode === 'floating' && !fullscreen" class="partner-assistant-resize" role="separator" tabindex="0" aria-label="调整 AI 悬浮窗高度" aria-orientation="horizontal" :aria-valuemin="floating.minimumHeight.value" :aria-valuemax="floating.resizeMaximum.value" :aria-valuenow="floating.height.value" @pointerdown="floating.resizeStart" @keydown="floating.resizeKeyboard" />
        </aside>
      </div>
    </BusinessOverlayHost>
  </div>
</template>
<style scoped>
/* Same 200ms / easing as the existing consumer demo, with public host overrides.
   Keep the aside mounted through exit and reversal; only captured gestures bypass motion.
   Own direct workspace/window state: nested hosts and product .is-open/.is-floating
   classes must not open or reposition another instance. Slot component roots use
   :deep only for the existing panel-height contract; no Robot DOM adaptation. */
.partner-assistant-host { --partner-host-motion-duration:200ms; --partner-host-motion-easing:cubic-bezier(0.2,0,0,1); --partner-host-shadow:0 0 48px rgba(0,0,0,.16); --partner-host-floating-shadow:0 8px 48px rgba(0,0,0,.16); --partner-host-entry-offset:24px; --partner-host-resize-inset:24px; --partner-host-focus:#191919; --partner-host-focus-width:2px; --partner-host-focus-inset:-2px; display:flex; flex-direction:column; height:100%; min-height:0; overflow:hidden; }
.partner-assistant-host.is-flow { height:auto; overflow:visible; }
.partner-assistant-host.is-flow > .partner-assistant-workspace { align-items:start; margin-bottom:calc(-1 * var(--partner-host-flow-trailing-space, 96px)); }
.partner-assistant-host.is-flow > .partner-assistant-workspace > .partner-assistant-business { overflow:visible; padding-bottom:var(--partner-host-flow-trailing-space, 96px); }
.partner-assistant-navigation { flex:none; position:relative; z-index:30; }
.partner-assistant-workspace { display:grid; position:relative; flex:1; min-height:0; transition:grid-template-columns var(--partner-host-motion-duration) var(--partner-host-motion-easing); }
.partner-assistant-business { min-width:0; min-height:0; position:relative; overflow:auto; }
.partner-assistant-window { position:relative; z-index:25; min-width:0; min-height:0; box-sizing:border-box; display:flex; flex-direction:column; overflow:hidden; box-shadow:var(--partner-host-shadow); visibility:hidden; opacity:0; transform:translateX(calc(var(--partner-host-sidebar-entry-width,0px) + var(--partner-host-entry-offset))); pointer-events:none; transition:transform var(--partner-host-motion-duration) var(--partner-host-motion-easing),opacity var(--partner-host-motion-duration) var(--partner-host-motion-easing),visibility 0s linear var(--partner-host-motion-duration); }
.partner-assistant-host.is-open > .partner-assistant-workspace > .partner-assistant-window { visibility:visible; opacity:1; transform:translateX(0); pointer-events:auto; transition-delay:0s; }
.partner-assistant-window.is-moving { transition:none; transform:none; }
.partner-assistant-window-content { flex:1; min-height:0; overflow:hidden; }
.partner-assistant-window-content > :deep(.agreement-assistant-panel) { height:100%; }
.partner-assistant-host.is-floating > .partner-assistant-workspace > .partner-assistant-window { position:absolute; box-shadow:var(--partner-host-floating-shadow); }
.partner-assistant-host.is-floating > .partner-assistant-workspace > .partner-assistant-window > .partner-assistant-window-content > :deep(.agreement-assistant-panel) { min-height:var(--assistant-content-min-height); }
.partner-assistant-host.is-floating.is-compact > .partner-assistant-workspace > .partner-assistant-window > .partner-assistant-window-content { overflow-y:auto; overscroll-behavior:contain; }
/* Bottom-edge overlay consumes only footer padding; no visible grip/layout strip.
   Keep the existing hook's min/max, capture and accessible keyboard separator. */
.partner-assistant-resize { position:absolute; inset:auto var(--partner-host-resize-inset) 0; height:min(8px,var(--assistant-resize-handle-height)); cursor:ns-resize; touch-action:none; }
.partner-assistant-resize:focus-visible { outline:var(--partner-host-focus-width) solid var(--partner-host-focus); outline-offset:var(--partner-host-focus-inset); }
.partner-assistant-host.is-flow.is-fullscreen > .partner-assistant-workspace > .partner-assistant-window { position:fixed !important; inset:0 !important; width:100vw !important; height:100dvh !important; }
.partner-assistant-host.is-fullscreen > .partner-assistant-workspace { transition:none; }
.partner-assistant-host.is-open.is-fullscreen > .partner-assistant-workspace > .partner-assistant-business { visibility:hidden; }
@media(prefers-reduced-motion:reduce) { .partner-assistant-workspace,.partner-assistant-window { transition:none; transform:none; } }
</style>
