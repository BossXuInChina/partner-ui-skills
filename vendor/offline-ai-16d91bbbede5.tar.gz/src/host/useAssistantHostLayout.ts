import { computed, onBeforeUnmount, onMounted, ref, type CSSProperties, type Ref } from 'vue';
import type { ChatSidebarBehavior, ChatWindowMode } from '../ui/panel/chatWindow';

export interface AssistantHostLayoutOptions {
  open: Ref<boolean>;
  mode: Ref<ChatWindowMode>;
  /** Defaults to push; overlay keeps the business track at its full width. */
  sidebarBehavior?: Ref<ChatSidebarBehavior | undefined>;
  /** Fill this workspace while retaining the underlying window preference. */
  fullscreen?: Ref<boolean>;
  /** Complete product viewport width; optional for constrained/cross-origin embeds. */
  viewportWidth?: Ref<number | undefined>;
  /** Business flows in an ancestor scrollport while the assistant stays visible. */
  flow?: Ref<boolean | undefined>;
}
/** Apply workspaceStyle to the grid, assistantStyle to the permanently mounted aside. */
export function useAssistantHostLayout(workspace: Ref<HTMLElement | undefined>, options: AssistantHostLayoutOptions) {
  const localWidth = ref(0), availableWidth = ref(0);
  let observer: ResizeObserver | undefined;
  function measure() { localWidth.value = window.innerWidth; availableWidth.value = workspace.value?.clientWidth ?? 0; }
  onMounted(() => { measure(); observer = new ResizeObserver(measure); if (workspace.value) observer.observe(workspace.value); window.addEventListener('resize', measure); });
  onBeforeUnmount(() => { observer?.disconnect(); window.removeEventListener('resize', measure); });
  const sidebarWidth = computed(() => Math.min((options.viewportWidth?.value ?? localWidth.value) >= 1920 ? 480 : 420, availableWidth.value));
  const sidebar = computed(() => !options.fullscreen?.value && options.mode.value === 'sidebar');
  const squeezed = computed(() => options.open.value && sidebar.value && options.sidebarBehavior?.value !== 'overlay');
  const workspaceStyle = computed(() => ({ gridTemplateColumns: `minmax(0,1fr) ${squeezed.value ? sidebarWidth.value : 0}px`, '--partner-host-workspace-width':`${availableWidth.value}px` }));
  // Host-owned placement only: the same ChatPanel and existing floating gesture
  // engine remain mounted. Robot0.5.1 drawer/dock support does not provide the
  // captured-gesture/workspace/keyboard handoff documented in AssistantHostLayout.
  const assistantStyle = computed<CSSProperties>(() => ({
    width: options.fullscreen?.value ? '100%' : `${sidebarWidth.value}px`,
    // One right-edge anchor/transform reproduces the original push trajectory
    // (window width + entrance offset) for both policies. Only the business grid
    // squeezes, avoiding a hidden transform animation when changing the policy.
    ...(sidebar.value ? options.flow?.value ? { position:'sticky', top:'0px', height:'var(--partner-host-flow-window-height, 100vh)', '--partner-host-sidebar-entry-width':'0px' } : { position:'absolute', insetBlock:0, insetInlineEnd:0, height:'100%', '--partner-host-sidebar-entry-width':'100%' } : {}),
  }));
  return { sidebarWidth, squeezed, workspaceStyle, assistantStyle };
}
