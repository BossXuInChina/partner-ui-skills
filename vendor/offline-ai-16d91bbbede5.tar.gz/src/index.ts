import '@opentiny/tiny-robot/dist/style.css';
import './styles.css';
// Delivery roles are documented in docs/COMPONENTS.md. Keep the existing export
// order and root/CSS contract; source folders do not imply separate public packages.
// Public AI presentation: consumer-owned data, resources and business handlers.
export { default as AiSummaryCard } from './business/AiSummaryCard.vue';
export { default as WorkspaceSmartIcon } from './business/WorkspaceSmartIcon.vue';
export { default as WorkspaceSmartTag } from './business/WorkspaceSmartTag.vue';
export { default as WorkspaceSmartCard } from './business/WorkspaceSmartCard.vue';
export { default as WorkspaceSmartTabs } from './business/WorkspaceSmartTabs.vue';
export type { WorkspaceSmartTab } from './business/workspaceSmartTabs';
export type { IntelligenceFragment, IntelligenceTag, IntelligenceItem, IntelligenceLogo, WorkspaceAnalysisRequest } from './business/workspaceIntelligence';
export { default as BusinessNavigationCard } from './business/BusinessNavigationCard.vue';
export type { BusinessNavigationTarget, BusinessNavigationEvent } from './business/businessNavigation';
// Public agreement-domain component; demo fixtures are excluded from the product.
export { default as AgreementTable } from './business/AgreementTable.vue';
export { default as BusinessTable } from './business/BusinessTable.vue';
export type { BusinessColumn } from './business/businessTable';
export { default as ConversationHistoryPanel } from './ui/history/ConversationHistoryPanel.vue';
// Generic chat presentation/configuration; transport and session ownership stay
// with the host. Composer/Prompts/Pills remain internal, with no deep-import API.
export { default as ChatPanel } from './ui/panel/ChatPanel.vue';
export { default as AiToast } from './ui/foundation/AiToast.vue';
export type { AiToastProps, AiToastType } from './ui/foundation/aiToast';
export { default as AiAlert } from './ui/messages/AiAlert.vue';
export type { AiAlertProps, AiAlertType } from './ui/messages/aiAlert';
export { resolveChatContent } from './ui/messages/chatContent';
export type { UIMessage, ChatDisplayStopSnapshot } from './ui/messages/chatContent';
export type { ChatWindowMode, ChatSidebarBehavior } from './ui/panel/chatWindow';
export type { ChatToolbarAction } from './ui/panel/chatToolbar';
export type { ComposerModeOption, ComposerRequestContext, WelcomeBusinessEntry } from './ui/composer/composerTypes';
export type { ChatSuggestion, ChatSuggestionCollection, ChatSuggestionPill, MessagePromptsResolver } from './ui/composer/chatSuggestions';
// Existing agreement transport/session composition, not a generic business engine.
export type { Agreement, AgreementAssistantAdapter, AssistantDelta, AssistantPart, AssistantContinuationRequest } from './adapters/contracts';
export { default as AgreementAssistantPanel } from './business/AgreementAssistantPanel.vue';
export type { ConversationHistoryOptions, ConversationStorage, ConversationSnapshot, ConversationRecord, ConversationViewState } from './ui/history/conversationHistory';

// Optional consumer-side layout/overlay adapters; no demo or vendor imports.
export { default as AssistantHostLayout } from './host/AssistantHostLayout.vue';
export { default as BusinessOverlayHost } from './host/BusinessOverlayHost.vue';
export { default as UiDialog } from './ui/foundation/UiDialog.vue';
export { useAssistantHostLayout } from './host/useAssistantHostLayout';
export { useAssistantWindow } from './host/useAssistantWindow';
export type { AssistantHostLayoutOptions } from './host/useAssistantHostLayout';
export type { AgreementBusinessAction, BusinessActionMode, BusinessDialogScope, WorkspaceNavigation } from './host/businessAction';

// Scoped semantic icon replacement; internal resources stay in the consumer app.
export { AiIcon, AiIconProvider, defaultAiIcons } from './ui/foundation/aiIcons';
export type { AiIconName, AiIconMap, AiIconDefinition, AiIconColor } from './ui/foundation/aiIcons';
