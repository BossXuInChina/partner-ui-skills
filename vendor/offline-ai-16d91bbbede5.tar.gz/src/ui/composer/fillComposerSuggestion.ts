import { nextTick } from 'vue';
import type { ChatSuggestion } from './chatSuggestions';
type SuggestionComposer = { appendSuggestion: (query:string) => boolean; focus: () => unknown };
// Product and source examples share the same append/deduplicate/focus path.
// appendSuggestion uses the locked Sender's public editor text transaction,
// preserving existing edits and literal text; this helper never submits.
export function fillComposerSuggestion(item:ChatSuggestion, draft:string, composer:SuggestionComposer|undefined) {
  if (item.disabled) return;
  const query = item.query ?? item.label;
  if (draft !== query && !draft.endsWith(`\n${query}`)) composer?.appendSuggestion(query);
  void nextTick(() => composer?.focus());
}
