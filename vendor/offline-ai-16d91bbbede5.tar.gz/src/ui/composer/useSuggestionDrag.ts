import { onBeforeUnmount, ref, watch, type Ref } from 'vue';

// Mouse-only gesture policy, not visual tokens. Native touch scrolling is untouched.
const holdMs=200, movementThreshold=6;
export function useSuggestionDrag(root:Ref<HTMLElement|undefined>) {
  const phase=ref<'idle'|'armed'|'dragging'>('idle');
  let cancel=()=>{}, cancelGesture=()=>{};
  const unwatch=watch(root,element=>{
    cancel();cancelGesture=()=>{};if(!element)return;
    const win=element.ownerDocument.defaultView!;
    let gesture:{id:number;x:number;y:number;left:number;scale:number;port:HTMLElement;timer:number;blocked:boolean}|undefined;
    let suppressClick=false;
    function end() {
      const current=gesture;gesture=undefined;phase.value='idle';
      if(current){win.clearTimeout(current.timer);if(element!.hasPointerCapture(current.id))element!.releasePointerCapture(current.id);}
      win.removeEventListener('pointermove',move,true);win.removeEventListener('pointerup',up,true);win.removeEventListener('pointercancel',up,true);win.removeEventListener('blur',abort);win.removeEventListener('keydown',key,true);
    }
    function abort(){if(gesture)suppressClick=true;end();}
    function key(event:KeyboardEvent){if(event.key==='Escape'&&gesture){event.preventDefault();event.stopPropagation();abort();}}
    function up(event:PointerEvent){if(event.pointerId===gesture?.id)end();}
    function move(event:PointerEvent) {
      const current=gesture;if(!current||event.pointerId!==current.id)return;
      if(!(event.buttons&1)||!current.port.isConnected){abort();return;}
      const dx=event.clientX-current.x,dy=event.clientY-current.y;
      if(phase.value==='idle'){
        // A quick swipe is neither a long press nor a safe button click.
        if(Math.hypot(dx,dy)>movementThreshold){current.blocked=true;suppressClick=true;win.clearTimeout(current.timer);event.preventDefault();}
        return;
      }
      event.preventDefault();
      if(phase.value==='armed'&&Math.abs(dx)>movementThreshold)phase.value='dragging';
      if(phase.value==='dragging')current.port.scrollLeft=current.left-dx/current.scale;
    }
    function down(event:PointerEvent) {
      end();suppressClick=false;
      if(event.pointerType!=='mouse'||event.button!==0||!event.isPrimary||event.ctrlKey||event.metaKey||event.altKey)return;
      const bounds=element!.getBoundingClientRect();
      if(event.clientY<bounds.top||event.clientY>=bounds.bottom)return;
      // Robot 0.5.1 scrollport is the sole DOM adapter; retain its native scroll owner.
      const port=element!.querySelector<HTMLElement>('.tr-suggestion-pills__container');
      if(!port||port.scrollWidth<=port.clientWidth)return;
      const current={id:event.pointerId,x:event.clientX,y:event.clientY,left:port.scrollLeft,scale:port.getBoundingClientRect().width/port.offsetWidth||1,port,timer:0,blocked:false};
      gesture=current;
      current.timer=win.setTimeout(()=>{
        if(gesture!==current||current.blocked)return;
        if(!element!.isConnected||!element!.getClientRects().length){abort();return;}
        suppressClick=true;phase.value='armed';
        element!.setPointerCapture(current.id);
      },holdMs);
      win.addEventListener('pointermove',move,{capture:true,passive:false});win.addEventListener('pointerup',up,true);win.addEventListener('pointercancel',up,true);win.addEventListener('blur',abort);win.addEventListener('keydown',key,true);
    }
    function click(event:MouseEvent){if(suppressClick&&event.detail>0){suppressClick=false;event.preventDefault();event.stopImmediatePropagation();}}
    function lost(event:PointerEvent){if(event.target===element)abort();}
    cancelGesture=abort;
    element.addEventListener('pointerdown',down,true);element.addEventListener('click',click,true);element.addEventListener('lostpointercapture',lost);
    cancel=()=>{end();element.removeEventListener('pointerdown',down,true);element.removeEventListener('click',click,true);element.removeEventListener('lostpointercapture',lost);};
  },{immediate:true,flush:'post'});
  onBeforeUnmount(()=>{unwatch();cancel();});
  return {dragPhase:phase,cancelDrag:()=>cancelGesture()};
}
