import type { Component } from 'vue';
/** Product-owned configuration; this module contains no demo choices or business calls. */
export interface ComposerRequestContext { aiEnabled: boolean; mode: string }
export interface ComposerModeOption { value: string; label: string; icon?: Component; disabled?: boolean }
export interface WelcomeBusinessEntry { id: string; title: string; description: string; icon?: Component; query?: string; disabled?: boolean }
