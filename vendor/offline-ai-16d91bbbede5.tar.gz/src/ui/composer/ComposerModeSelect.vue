<script lang="ts">
export type { ComposerModeOption } from './composerTypes';
</script>
<script setup lang="ts">
import { vAiTooltip } from '../foundation/aiTooltip';
import { computed, nextTick, onBeforeUnmount, onMounted, ref, useId, watch } from 'vue';
import { AiIcon } from '../foundation/aiIcons';
import type { ComposerModeOption } from './composerTypes';
const props = withDefaults(defineProps<{ modelValue: string; options: ComposerModeOption[]; disabled?: boolean }>(), { disabled: false });
const emit = defineEmits<{ 'update:modelValue': [value: string] }>();
const id = `composer-mode-${useId().replace(/[^a-zA-Z0-9-]/g, '')}`;
const trigger = ref<HTMLButtonElement>(), panel = ref<HTMLElement>();
const open = ref(false), activeIndex = ref(-1);
const panelStyle = ref<Record<string, string>>({});
const selected = computed(() => props.options.find(option => option.value === props.modelValue));
const enabledIndexes = computed(() => props.options.flatMap((option, index) => option.disabled ? [] : [index]));
// REQ-006: no options is a focusable no-op placeholder. Explicit disabled and configured
// all-disabled choices remain unavailable; never open an empty/invalid listbox.
const unavailable = computed(() => props.disabled || (props.options.length > 0 && !enabledIndexes.value.length));

// Robot0.5.1 DropdownMenu items expose only id/text; its clickable li rows have no
// item slot, disabled/selected state or keyboard listbox navigation. Keep this minimal
// combobox; recheck the public API before replacing it on upgrades.
// REQ-003 Sender: self-contained single-select, styled from the local Workbench Select reference
// (demo/vendor/workbench/ui/select/WorkbenchSelectCore.vue), without importing its demo closure.
// A body Teleport escapes Sender/editor overflow. Copy the public AI semantic tokens; position in the
// current document viewport and remeasure on scroll/resize. Upgrade checks: focus and portal bounds.
function positionPanel() {
  if (!open.value || !trigger.value) return;
  const box = trigger.value.getBoundingClientRect();
  const host = trigger.value.closest('[data-assistant-window]') ?? trigger.value.closest('.chat-panel');
  const bounds = host?.getBoundingClientRect();
  const left = Math.max(8, bounds ? bounds.left + 8 : 8);
  const right = Math.min(document.documentElement.clientWidth - 8, bounds ? bounds.right - 8 : Infinity);
  const top = Math.max(8, bounds ? bounds.top + 8 : 8);
  const theme = getComputedStyle(trigger.value);
  const spacing = Number.parseFloat(theme.getPropertyValue('--partner-ai-menu-panel-padding')) || 4;
  // Match the trigger by default; a host may set a larger minimum, subject to bounds.
  const minimumWidth = Number.parseFloat(theme.getPropertyValue('--partner-ai-mode-panel-min-width')) || 0;
  const width = Math.min(Math.max(box.width, minimumWidth), Math.max(0, right - left));
  const desiredHeight = props.options.length * box.height + spacing * 2;
  // Sender menus always open above, including the standalone example. The locked
  // DropdownMenu has neither a placement prop nor an option slot; keep the existing
  // listbox instead of losing its disabled/selected/keyboard contract. Constrain
  // this portal to its host/viewport and scroll upper space; never flip below.
  // Recheck the public menu/placement API and portal geometry on Robot upgrades.
  const above = Math.max(0, box.top - 4 - top);
  if (!trigger.value.getClientRects().length || trigger.value.closest('[inert]') || above < Math.min(desiredHeight, box.height + spacing * 2) || width <= 0) { close(); return; }
  const height = Math.min(desiredHeight, above);
  const style: Record<string, string> = {
    width: `${width}px`, maxHeight: `${height}px`,
    left: `${Math.max(left, Math.min(box.left, right - width))}px`,
    top: `${box.top - height - 4}px`,
  };
  for (let index=0;index<theme.length;index++) { const token=theme[index]!; if(token.startsWith('--partner-ai-'))style[token]=theme.getPropertyValue(token); }
  style.fontFamily = theme.fontFamily;
  panelStyle.value = style;
}
function close(restoreFocus = false) { open.value = false; if (restoreFocus) trigger.value?.focus({ preventScroll: true }); }
async function show(last = false) {
  if (unavailable.value || !enabledIndexes.value.length) return;
  activeIndex.value = enabledIndexes.value.includes(props.options.findIndex(option => option.value === props.modelValue))
    ? props.options.findIndex(option => option.value === props.modelValue)
    : enabledIndexes.value[last ? enabledIndexes.value.length - 1 : 0]!;
  open.value = true; positionPanel(); await nextTick(); revealActive();
}
function revealActive() { panel.value?.querySelector<HTMLElement>(`#${id}-${activeIndex.value}`)?.scrollIntoView({ block: 'nearest' }); }
function choose(index: number) {
  const option = props.options[index];
  if (!option || option.disabled) return;
  emit('update:modelValue', option.value); close(true);
}
function keydown(event: KeyboardEvent) {
  if (event.key === 'Tab') { close(); return; }
  if (event.key === 'Escape' && open.value) { event.preventDefault(); event.stopPropagation(); close(true); return; }
  if (!['ArrowDown', 'ArrowUp', 'Home', 'End', 'Enter', ' '].includes(event.key)) return;
  event.preventDefault(); event.stopPropagation();
  if (!open.value) { void show(event.key === 'ArrowUp' || event.key === 'End'); return; }
  if (event.key === 'Enter' || event.key === ' ') { choose(activeIndex.value); return; }
  const indexes = enabledIndexes.value, current = indexes.indexOf(activeIndex.value);
  activeIndex.value = indexes[event.key === 'Home' ? 0 : event.key === 'End' ? indexes.length - 1 : (current + (event.key === 'ArrowUp' ? -1 : 1) + indexes.length) % indexes.length]!;
  void nextTick(revealActive);
}
function outside(event: Event) {
  if (event.target instanceof Node && !trigger.value?.contains(event.target) && !panel.value?.contains(event.target)) close();
}
watch(() => props.options, () => { if (unavailable.value || !enabledIndexes.value.length) close(); else if (open.value) { activeIndex.value = enabledIndexes.value[0]!; positionPanel(); } }, { deep: true });
watch(unavailable, disabled => { if (disabled) close(); });
onMounted(() => { document.addEventListener('pointerdown', outside, true); document.addEventListener('focusin', outside); window.addEventListener('resize', positionPanel); window.addEventListener('scroll', positionPanel, true); });
onBeforeUnmount(() => { document.removeEventListener('pointerdown', outside, true); document.removeEventListener('focusin', outside); window.removeEventListener('resize', positionPanel); window.removeEventListener('scroll', positionPanel, true); });
</script>
<template>
  <button :id="id" ref="trigger" v-ai-tooltip="{ content: !options.length ? '模式选项尚未配置' : selected?.label ?? '选择模式', disabled: open, overflowOnly: options.length > 0, overflowSelector: '.composer-mode-label' }" type="button" class="composer-mode-trigger" role="combobox" aria-label="切换模式" aria-haspopup="listbox" :aria-expanded="open" :aria-controls="open ? `${id}-list` : undefined" :aria-activedescendant="open ? `${id}-${activeIndex}` : undefined" :disabled="unavailable" @click="open ? close() : show()" @keydown="keydown">
    <component :is="selected.icon" v-if="selected?.icon" class="composer-mode-icon" aria-hidden="true" /><AiIcon v-else name="composer.mode" class="composer-mode-icon" /><span class="composer-mode-label">{{ selected?.label ?? '选择模式' }}</span><AiIcon name="composer.expand" class="composer-mode-arrow" aria-hidden="true" />
  </button>
  <Teleport to="body">
    <div v-if="open" :id="`${id}-list`" ref="panel" class="composer-mode-panel partner-ai-scrollbar-portal" role="listbox" aria-label="问答模式" :style="panelStyle" @keydown="keydown">
      <button v-for="(option,index) in options" :id="`${id}-${index}`" :key="option.value" type="button" role="option" class="composer-mode-option" :class="{ 'is-active': index === activeIndex }" :aria-selected="option.value === modelValue" :disabled="option.disabled" tabindex="-1" @pointermove="!option.disabled && (activeIndex = index)" @click="choose(index)"><span>{{ option.label }}</span><AiIcon v-if="option.value === modelValue" name="composer.selected" aria-hidden="true" /></button>
    </div>
  </Teleport>
</template>
<style scoped>
.composer-mode-trigger { display:inline-flex; align-items:center; height:var(--partner-ai-control-size); gap:var(--partner-ai-gap-sm); padding:0 var(--partner-ai-gap-lg); max-width:var(--partner-ai-mode-max-width); flex:none; border:var(--partner-ai-border-width) solid var(--partner-ai-border); border-radius:var(--partner-ai-mode-radius); background:var(--partner-ai-panel-bg); color:var(--partner-ai-text); font:inherit; cursor:pointer; box-sizing:border-box; }
.composer-mode-trigger:hover:not(:disabled) { border-color:var(--partner-ai-border-hover); }
.composer-mode-trigger:focus-visible { outline:var(--partner-ai-focus-width) solid var(--partner-ai-focus); outline-offset:var(--partner-ai-focus-control-offset); }
.composer-mode-trigger:disabled { opacity:var(--partner-ai-disabled-opacity); cursor:not-allowed; }
/* REQ-006: user explicitly sets the dropdown's functional icon to14px; other action
   SVGs stay24px. The12px chevron and16px selection check retain separate dimensions. */
.composer-mode-trigger :deep(.composer-mode-icon) { width:var(--partner-ai-mode-icon-size); height:var(--partner-ai-mode-icon-size); flex:none; }
/* Preserve existing caller-supplied monochrome icon overrides. */
.composer-mode-trigger :deep(.composer-mode-icon:not([data-ai-icon-color="original"]) [fill="#191919"]) { fill:currentColor; }
/* -180deg to0deg opens clockwise; returning to-180deg closes counterclockwise. */
.composer-mode-trigger :deep(.composer-mode-arrow) { width:var(--partner-ai-arrow-icon-size); height:var(--partner-ai-arrow-icon-size); flex:none; transform:rotate(-180deg); transition:transform 220ms cubic-bezier(.2,.8,.2,1); }
.composer-mode-trigger[aria-expanded="true"] :deep(.composer-mode-arrow) { transform:rotate(0deg); }
@media(prefers-reduced-motion:reduce) { .composer-mode-trigger :deep(.composer-mode-arrow) { transition:none; } }
.composer-mode-label { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.composer-mode-panel { position:fixed; z-index:21000; display:grid; padding:var(--partner-ai-menu-panel-padding); box-sizing:border-box; overflow:auto; overscroll-behavior:contain; border-radius:var(--partner-ai-mode-panel-radius); background:var(--partner-ai-overlay-bg); color:var(--partner-ai-text); box-shadow:var(--partner-ai-mode-panel-shadow); font-size:var(--partner-ai-body-size); line-height:var(--partner-ai-body-line); }
/* Menu rows have their own 4px radius; 6px inline padding fits the default
   four-character mode label and check within the menu surface. */
.composer-mode-option { display:flex; align-items:center; justify-content:space-between; gap:var(--partner-ai-gap-sm); min-width:0; height:var(--partner-ai-control-size); padding:var(--partner-ai-gap-sm) 6px; border:0; border-radius:var(--partner-ai-menu-option-radius); background:transparent; color:inherit; font:inherit; text-align:left; cursor:pointer; }
.composer-mode-option span { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.composer-mode-option:hover:not(:disabled),.composer-mode-option.is-active:not(:disabled) { background:var(--partner-ai-hover-bg); }
.composer-mode-option:disabled { color:var(--partner-ai-disabled-text); cursor:not-allowed; }
.composer-mode-option :deep(svg) { width:var(--partner-ai-small-icon-size); height:var(--partner-ai-small-icon-size); flex:none; }
</style>
