<script lang="ts">
export type { ComposerRequestContext } from './composerTypes';
</script>
<script setup lang="ts">
import { vAiTooltip } from '../foundation/aiTooltip';
import { useDeliveryMode } from '../foundation/deliveryMode';
import { nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue';
import { TrActionButton, TrSender } from '@opentiny/tiny-robot';
import { AiIcon, aiIconVNode } from '../foundation/aiIcons';
import ComposerModeSelect, { type ComposerModeOption } from './ComposerModeSelect.vue';
import type { ComposerRequestContext } from './composerTypes';
import '../foundation/aiTokens.css';
import { useAutoScrollbars } from '../foundation/useAutoScrollbars';
const props = withDefaults(defineProps<{ processing?: boolean; modeOptions?: ComposerModeOption[]; placeholder?: string }>(), { processing: false, modeOptions: () => [], placeholder: '请输入问题或 / 触发快捷操作' });
const draft = defineModel<string>({ default: '' });
const aiEnabled = defineModel<boolean>('aiEnabled', { default: false });
const mode = defineModel<string>('mode', { default: '' });
const emit = defineEmits<{ submit: [query: string, context: ComposerRequestContext]; cancel: [] }>();
const sender = ref<InstanceType<typeof TrSender>>();
const delivery = useDeliveryMode();
const shell = ref<HTMLElement>();
useAutoScrollbars(() => shell.value,[{selector:'.tr-sender-editor-scroll',axis:'y'}]);
// REQ-017: public autoSize=false keeps TrSender/Tiptap input, paste, IME and native
// scrolling intact. Row counts cannot express a total287px cap. Measure natural
// ProseMirror height plus actual padding/gap/footer; only this consumer owns sizing.
// The 0.5.1 editor/scroll/layout selectors need review when upgrading TinyRobot.
let sizeObserver: ResizeObserver | undefined;
let sizeFrame = 0;
function scheduleSize() {
  if (!sizeFrame) sizeFrame = requestAnimationFrame(() => { sizeFrame = 0; measureSize(); });
}
function measureSize() {
  const root = shell.value, surface = root?.querySelector<HTMLElement>('.tr-sender');
  const port = root?.querySelector<HTMLElement>('.tr-sender-editor-scroll');
  const editor = port?.querySelector<HTMLElement>('.ProseMirror');
  const actions = root?.querySelector<HTMLElement>('.tr-sender-footer');
  const layout = root?.querySelector<HTMLElement>('.tr-sender-multi-layout');
  if (!root || !surface || !port || !editor || !actions || !layout) return;
  const paint = getComputedStyle(surface);
  const overhead = parseFloat(paint.paddingTop) + parseFloat(paint.paddingBottom) + actions.offsetHeight + parseFloat(getComputedStyle(layout).rowGap);
  const minimum = overhead + parseFloat(getComputedStyle(editor).lineHeight);
  const footer = root.closest<HTMLElement>('.chat-footer');
  const panel = root.closest<HTMLElement>('.chat-panel');
  let available = 287;
  if (footer && panel) {
    const header = panel.querySelector<HTMLElement>('.tr-layout__header');
    const viewport = panel.closest<HTMLElement>('.company-assistant-viewport');
    const height = Math.min(panel.clientHeight, viewport?.clientHeight ?? Infinity);
    // Keep24px for the independently scrolling main. At physically impossible
    // heights the host's existing compact viewport scrolls the essential controls.
    available = height - (header?.offsetHeight ?? 0) - (footer.offsetHeight - root.offsetHeight) - 24;
  }
  const height = Math.max(minimum, Math.min(287, available, Math.max(132, editor.offsetHeight + overhead)));
  const set = (node: HTMLElement, name: string, value: number) => {
    const pixels = `${value}px`;
    if (node.style.getPropertyValue(name) !== pixels) node.style.setProperty(name, pixels);
  };
  set(root, '--composer-measured-height', height);
  if (footer) {
    set(footer, '--composer-measured-height', height);
    set(footer, '--composer-min-usable-height', minimum);
  }
  // Center the actual native track in the existing16px right safe inset. Extend
  // only the scrollport; subtract its measured occupying gutter from the added
  // padding, keeping the editor's text width identical before/after overflow.
  // No stable gutter, overlay assumption, scroll interception or custom engine.
  const gutter = port.offsetWidth - port.clientWidth;
  const nativeTrack = parseFloat(getComputedStyle(port, '::-webkit-scrollbar').width);
  const track = gutter || (Number.isFinite(nativeTrack) ? nativeTrack : 10);
  set(root, '--composer-scroll-extension', (parseFloat(paint.paddingRight) + track) / 2);
  set(root, '--composer-native-gutter', gutter);
}
watch(draft, async () => { await nextTick(); scheduleSize(); }, { flush: 'post' });
onMounted(() => {
  sizeObserver = new ResizeObserver(scheduleSize);
  for (const node of [shell.value, shell.value?.querySelector('.ProseMirror'), shell.value?.querySelector('.tr-sender-editor-scroll'), shell.value?.closest('.chat-footer'), shell.value?.closest('.chat-panel'), shell.value?.closest('.company-assistant-viewport')]) {
    if (node) sizeObserver.observe(node);
  }
  scheduleSize();
});
onBeforeUnmount(() => { sizeObserver?.disconnect(); cancelAnimationFrame(sizeFrame); });
// Semantic resources use the public ActionButton icon API; geometry and paint
// defaults live in aiIcons. The existing fixed slot still owns send/stop motion.
// TinyRobot 0.5.1 modelValue writes call setContent(string), interpreting plain
// drafts as HTML. Use its public exposed editor's text transaction, matching the
// locked Sender's paste implementation (its schema has no hardBreak node).
// Existing edits/newlines stay intact; recheck editor exposure/paste on upgrades.
function appendSuggestion(query: string) {
  const editor = sender.value?.editor;
  if (!editor) return false;
  const text = `${editor.getText().length ? '\n' : ''}${query}`;
  editor.view.dispatch(editor.state.tr.insertText(text, editor.state.doc.content.size - 1));
  return true;
}
defineExpose({ focus: () => sender.value?.editor?.commands.focus('end'), appendSuggestion });

// REQ-003 Sender: v-models and submit/cancel are public TinyRobot/Vue APIs. AI is off by
// default; each submission snapshots actual AI/mode state for the caller's request routing.
// This component never calls a model, microphone, upload endpoint, or persistent storage.
watch(() => sender.value?.editor, editor => {
  if (editor) editor.setOptions({ editorProps: { ...editor.options.editorProps, attributes: { ...(typeof editor.options.editorProps.attributes === 'object' ? editor.options.editorProps.attributes : {}), role: 'textbox', 'aria-label': '输入问题', 'aria-multiline': 'true' } } });
});
function submit(value: string) {
  // Robot 0.5.1 emits getText() with Tiptap's double-newline block separator.
  // Read the public editor at submit with one newline per paragraph boundary;
  // pasted text/empty paragraphs retain their own whitespace. Recheck on upgrades.
  const query = sender.value?.editor?.getText({ blockSeparator: '\n' }) ?? value;
  if (props.processing || !query.trim()) return;
  emit('submit', query, { aiEnabled: aiEnabled.value, mode: mode.value });
  draft.value = '';
}
// Clicking unused editor space should focus the same public editor without
// intercepting selection, scrolling or footer controls (TinyRobot 0.5.1).
function focusEditorSpace(event: MouseEvent) {
  const target = event.target;
  if (target instanceof HTMLElement && target.matches('.tr-sender-main, .tr-sender-content, .tr-sender-editor-wrapper, .tr-sender-editor-scroll')) sender.value?.editor?.commands.focus('end');
}
function keyboard(event: KeyboardEvent) {
  // Intercept only editor Enter: the switch/select keep their own Enter/Space navigation.
  if (!(event.target instanceof HTMLElement) || !event.target.closest('[contenteditable]')) return;
  if (event.key === 'Enter' && !event.shiftKey && !event.ctrlKey && !event.metaKey && !event.isComposing) { event.preventDefault(); event.stopPropagation(); submit(draft.value); }
}
</script>
<template>
  <div ref="shell" class="chat-composer" @keydown.capture="keyboard" @input="scheduleSize" @compositionend="scheduleSize" @click="focusEditorSpace">
    <TrSender ref="sender" v-model="draft" :loading="processing" mode="multiple" :placeholder="placeholder" stop-text="停止生成" :auto-size="false" :max-length="2000" @submit="submit" @cancel="emit('cancel')">
      <template #footer>
        <!-- Robot 0.5.1 has no public Switch; the existing WorkbenchSwitch is demo-only
             with form/loading dependencies. Keep this native, labelled switch local, adapting
             its track geometry; Space/Enter use button behavior without another key handler. -->
        <button v-show="!delivery" v-ai-tooltip="'开启后由大模型回答'" type="button" role="switch" class="composer-ai-toggle" :class="{ 'is-active':aiEnabled }" aria-label="AI问答" :aria-checked="aiEnabled" @click="aiEnabled = !aiEnabled"><span class="composer-ai-switch-label">AI问答</span><span class="composer-ai-switch-track" aria-hidden="true"><span class="composer-ai-switch-thumb" /></span></button>
        <span v-show="!delivery" class="composer-mode-host"><ComposerModeSelect v-model="mode" :options="modeOptions" /></span>
      </template>
      <template #footer-right>
        <!-- Enabled placeholders intentionally have no side-effect handler: no mic,
             file picker or request is started. Existing send/cancel handlers remain intact. -->
        <TrActionButton v-show="!delivery" v-ai-tooltip="'语音输入尚未接入'" :icon="aiIconVNode('composer.voice')" type="button" class="composer-icon-action" aria-label="语音输入（尚未接入）"></TrActionButton>
        <TrActionButton v-show="!delivery" v-ai-tooltip="'上传图片尚未接入'" :icon="aiIconVNode('composer.image')" type="button" class="composer-icon-action" aria-label="上传图片（尚未接入）"></TrActionButton>
        <span v-show="!delivery" class="composer-action-divider" aria-hidden="true" />
        <!-- REQ-009: public icon slot hosts Vue Transition in a fixed24px wrapper. Keep
             one ActionButton/Tooltip instance so focus and cancel stay available throughout
             rapid icon changes. The required icon prop is the official fallback only. -->
        <TrActionButton v-ai-tooltip="processing ? '停止生成' : '发送消息'" :icon="aiIconVNode('composer.send')" type="button" class="composer-send-action" :aria-label="processing ? '停止生成' : '发送消息'" :disabled="!processing && !draft.trim()" @click="processing ? emit('cancel') : submit(draft)">
          <template #icon>
            <span class="composer-state-icon" aria-hidden="true">
              <Transition name="composer-icon">
                <AiIcon :key="processing ? 'stop' : 'send'" :name="processing ? 'composer.stop' : 'composer.send'" />
              </Transition>
            </span>
          </template>
        </TrActionButton>
      </template>
    </TrSender>
  </div>
</template>
<style scoped>
/* REQ-003: 132px shell, 16px radius, inner padding 12px/16px and a 32px action row.
   #footer/#footer-right are public Sender slots. Radius/padding/divider variables are public
   theme tokens; :deep(.tr-sender-*) adapts 0.5.1 layout/editor DOM to the measured shell.
   On upgrades verify editor scroll, hidden native submit, keyboard focus and action-row height.
   Right-side ActionButton icon/disabled are public APIs; the AI switch is local.
   Native button semantics are retained (0.5.1 SubmitButton is a div). On upgrades recheck
   native attribute/event forwarding and fixed icon sizes.
   Narrow embeds may scroll the action row horizontally; fixed control sizes are not squeezed. */
.chat-composer { position:relative; isolation:isolate; width:100%; height:var(--composer-measured-height,var(--partner-ai-composer-height)); flex:none; min-width:0; overflow:visible; font-size:var(--partner-ai-body-size); line-height:var(--partner-ai-body-line); }
/* REQ-018: Sender exposes a solid box-shadow token, not a six-point blurred shadow.
   This consumer-owned layer reuses REQ-013 paint behind the opaque public Sender
   surface; only the decoration is blurred, with no layout or pointer participation.
   Keep shell/ancestor shadow space and recheck the editor focus hook on Robot upgrades. */
.chat-composer::before { content:''; position:absolute; z-index:-1; inset:0; border-radius:var(--partner-ai-composer-radius); background:var(--partner-ai-composer-stroke-image); filter:blur(var(--partner-ai-composer-focus-glow-blur)); pointer-events:none; opacity:0; transition:opacity var(--partner-ai-control-motion-duration) var(--partner-ai-control-motion-easing); }
.chat-composer:has([contenteditable]:focus)::before { opacity:var(--partner-ai-composer-focus-glow-opacity); }

/* REQ-013: Sender has no public six-point stroke API. A consumer-owned overlay masks
   its padding into an inner token-sized ring, leaving public Sender surface/shadow/layout intact.
   Only editor focus changes this paint layer; button focus retains existing outlines.
   No internal pseudo-element is claimed. Recheck the editor focus selector and shell
   bounds on TinyRobot upgrades; pointer-events:none keeps input/actions reachable. */
.chat-composer::after { content:''; position:absolute; z-index:1; inset:0; box-sizing:border-box; padding:var(--partner-ai-composer-stroke-width); border-radius:var(--partner-ai-composer-radius); background:var(--partner-ai-composer-stroke-image); pointer-events:none; -webkit-mask:linear-gradient(#fff 0 0) content-box,linear-gradient(#fff 0 0); mask:linear-gradient(#fff 0 0) content-box,linear-gradient(#fff 0 0); -webkit-mask-composite:xor; mask-composite:exclude; opacity:var(--partner-ai-composer-stroke-opacity); transition:opacity var(--partner-ai-control-motion-duration) var(--partner-ai-control-motion-easing); }
.chat-composer:has([contenteditable]:focus)::after { opacity:var(--partner-ai-composer-stroke-focus-opacity); }
.chat-composer :deep(.tr-sender.tr-sender--multiple) { height:100%; width:100%; padding:var(--partner-ai-composer-padding-block) var(--partner-ai-composer-padding-inline); box-sizing:border-box; font-family:inherit; min-height:0; --tr-sender-placeholder-color:var(--partner-ai-composer-placeholder-color); --tr-sender-font-size:var(--partner-ai-body-size); --tr-sender-line-height:var(--partner-ai-body-line); --tr-sender-border-radius:var(--partner-ai-composer-radius); --tr-sender-bg-color:var(--partner-ai-composer-bg); --tr-sender-box-shadow:var(--partner-ai-composer-shadow); --tr-sender-header-border-bottom:none; --tr-sender-multi-main-padding:0; --tr-sender-footer-padding:0; --tr-sender-action-gap:0; --tr-sender-footer-gap:var(--partner-ai-gap-md); --tr-sender-gap:var(--partner-ai-gap-md); }
.chat-composer :deep(.tr-sender-multi-layout) { height:100%; display:flex; flex-direction:column; gap:var(--partner-ai-gap-md); min-height:0; padding:0; }
.chat-composer :deep(.tr-sender .tr-sender-main) { flex:1; min-height:0; padding:0; overflow:visible; --tr-sender-multi-main-padding:0; }
.chat-composer :deep(.tr-sender-content),.chat-composer :deep(.tr-sender-editor-wrapper) { min-width:0; height:100%; min-height:0; }
.chat-composer :deep(.tr-sender-editor-scroll) { box-sizing:border-box; flex:none; width:calc(100% + var(--composer-scroll-extension,13px)); margin-right:calc(0px - var(--composer-scroll-extension,13px)); padding-right:calc(var(--composer-scroll-extension,13px) - var(--composer-native-gutter,0px)); height:100%; min-height:0!important; max-height:100%!important; overflow-y:auto; overflow-x:hidden; overscroll-behavior:contain; }
/* REQ-003 v1.5: public Sender font/line tokens also reach paragraph + placeholder pseudo
   elements. Keep Body-M family/weight consistent; recheck upstream paragraph rules on upgrades. */
.chat-composer :deep(.ProseMirror) { height:auto; max-height:none; overflow:visible; transition:none; font-family:inherit; font-size:var(--partner-ai-body-size); line-height:var(--partner-ai-body-line); font-weight:var(--partner-ai-body-weight); letter-spacing:var(--partner-ai-body-letter-spacing); }
.chat-composer :deep(.tr-sender-footer) { height:var(--partner-ai-control-size); min-height:var(--partner-ai-control-size); flex:none; overflow-x:auto; overflow-y:hidden; scrollbar-width:none; }
.chat-composer :deep(.tr-sender-footer-left),.chat-composer :deep(.tr-sender-footer-right) { height:var(--partner-ai-control-size); flex:none; }
/* REQ-003 v1.4: measure AI-module edge to mode-trigger edge, without extra margins. */
.composer-mode-host { display:contents; }
.chat-composer :deep(.tr-sender-footer-left) { gap:var(--partner-ai-mode-control-gap); }
/* Native ActionButton roots are adjacent inside Sender's default action group. The public
   --tr-sender-action-gap above removes its 4px default; zero footer gap plus the divider's
   own left8/right12px margins prevents additive spacing. Recheck the
   forwarded button roots and measured edges when upgrading TinyRobot/Tooltip. */
.chat-composer :deep(.tr-sender-footer-right) { gap:0; }
.chat-composer :deep(.composer-icon-action + .composer-icon-action) { margin-left:var(--partner-ai-gap-sm); }
.chat-composer :deep(.tr-sender-submit-button) { display:none; }
/* REQ-013 v0.2: editor focus already raises the visible gradient ring to0.6. Remove
   our former Sender-level2px Foundation outline (black in light mode), rather than
   stacking two focus indicators. Only this editor replaces the global outline;
   internal buttons retain their keyboard rings. Forced colors needs a system ring
   because the OS can suppress gradient paint; recheck on TinyRobot/UA upgrades. */
.chat-composer :deep([contenteditable]:focus-visible) { outline:none; }
.chat-composer :deep(button) { font:inherit; cursor:pointer; }
.chat-composer :deep(button:disabled) { cursor:not-allowed; opacity:.5; }
.chat-composer :deep(button:focus-visible) { outline:var(--partner-ai-focus-width) solid var(--partner-ai-focus); outline-offset:var(--partner-ai-focus-inset); }
/* REQ-014: keep the existing native action focus rings with the independent Tooltip. */
.chat-composer :deep(.composer-icon-action:focus-visible),.chat-composer :deep(.composer-send-action:focus-visible) { outline:var(--partner-ai-focus-width) solid var(--partner-ai-focus); outline-offset:var(--partner-ai-focus-inset); }
/* REQ-009 v0.2: latest chat correction uses primary text when active and the existing
   default text when off. Workbench Switch's 160ms/ease-out also drives color, thumb and
   two paint layers: opacity crossfade preserves the translucent gradient's exact endpoint.
   Keep native keyboard/focus behavior; decorative layers never intercept input. */
.chat-composer :deep(.composer-ai-toggle) { width:auto; margin:0; display:inline-flex; align-items:center; height:var(--partner-ai-control-size); padding:var(--partner-ai-gap-sm) var(--partner-ai-toggle-padding-inline); gap:var(--partner-ai-gap-sm); flex:none; border:0; border-radius:var(--partner-ai-control-radius); background:transparent; color:var(--partner-ai-switch-label-color); white-space:nowrap; transition:color var(--partner-ai-control-motion-duration) var(--partner-ai-control-motion-easing); }
.chat-composer :deep(.composer-ai-toggle[aria-checked=true]) { color:var(--partner-ai-switch-label-active-color); }
.composer-ai-switch-track { position:relative; display:block; width:var(--partner-ai-switch-width); height:var(--partner-ai-switch-height); flex:none; border-radius:var(--partner-ai-full-radius); background:transparent; }
.composer-ai-switch-track::before,.composer-ai-switch-track::after { content:''; position:absolute; inset:0; border-radius:inherit; pointer-events:none; transition:opacity var(--partner-ai-control-motion-duration) var(--partner-ai-control-motion-easing); }
.composer-ai-switch-track::before { background:var(--partner-ai-switch-off-bg); opacity:1; }
.composer-ai-switch-track::after { background:var(--partner-ai-switch-on-bg); opacity:0; }
.composer-ai-switch-thumb { position:absolute; z-index:1; top:calc((var(--partner-ai-switch-height) - var(--partner-ai-switch-thumb-size)) / 2); left:calc((var(--partner-ai-switch-height) - var(--partner-ai-switch-thumb-size)) / 2); width:var(--partner-ai-switch-thumb-size); height:var(--partner-ai-switch-thumb-size); border-radius:var(--partner-ai-full-radius); background:var(--partner-ai-on-accent); transition:transform var(--partner-ai-control-motion-duration) var(--partner-ai-control-motion-easing); }
.composer-ai-toggle[aria-checked=true] .composer-ai-switch-track::before { opacity:0; }
.composer-ai-toggle[aria-checked=true] .composer-ai-switch-track::after { opacity:1; }
.composer-ai-toggle[aria-checked=true] .composer-ai-switch-thumb { transform:translateX(calc(var(--partner-ai-switch-width) - var(--partner-ai-switch-height))); }
.chat-composer :deep(.composer-icon-action),.chat-composer :deep(.composer-send-action) { display:inline-flex; align-items:center; justify-content:center; width:var(--partner-ai-control-size); height:var(--partner-ai-control-size); padding:var(--partner-ai-gap-sm); border:0; flex:none; }
/* REQ-025: public ActionButton class forwarding scopes the 8px hover container.
   Keep the send/stop action's separate full-radius rule; recheck roots on Robot upgrades. */
.chat-composer :deep(.composer-icon-action) { border-radius:var(--partner-ai-control-radius); background:transparent; color:var(--partner-ai-muted); }
.chat-composer :deep(.composer-icon-action:hover:not(:disabled)) { background:var(--partner-ai-hover-bg); }
.chat-composer .composer-icon-action :deep(svg),.chat-composer .composer-send-action :deep(svg) { width:var(--partner-ai-icon-size); height:var(--partner-ai-icon-size); flex:none; }
/* REQ-009 v0.2: public ActionButton icon/disabled APIs retain the real submit guard.
   Latest generation-state request shares gradient/white paint with the enabled stop action.
   Public hover/active tokens prevent a dark underlay beneath the translucent gradient.
   Locked IconArrowUp uses currentColor; preserve its path and stroke width, without SVG
   fill/stroke rewrites. Recheck icon paint and Tooltip button forwarding on upgrades. */
.chat-composer :deep(.composer-send-action) { border-radius:var(--partner-ai-full-radius); background:var(--partner-ai-send-bg); color:var(--partner-ai-send-icon-color); opacity:var(--partner-ai-send-opacity); transition:opacity var(--partner-ai-control-motion-duration) var(--partner-ai-control-motion-easing); --tr-sender-button-hover-bg:transparent; --tr-sender-button-active-bg:transparent; }
.chat-composer :deep(.composer-send-action:disabled) { opacity:var(--partner-ai-send-disabled-opacity); }
/* Public icon slot: simultaneous enter/leave are absolute inside the fixed slot, never
   layout participants or hit targets. Vue cancels interrupted transitions by keyed state.
   Workbench message entry scale0.9 supplies the subtle zoom; timing follows Switch. */
.composer-state-icon { position:relative; display:block; width:var(--partner-ai-icon-size); height:var(--partner-ai-icon-size); flex:none; pointer-events:none; }
.composer-state-icon :deep(svg) { position:absolute; inset:0; transform-origin:center; }
.composer-state-icon :deep(.composer-icon-enter-active),.composer-state-icon :deep(.composer-icon-leave-active) { transition:opacity var(--partner-ai-control-motion-duration) var(--partner-ai-control-motion-easing),transform var(--partner-ai-control-motion-duration) var(--partner-ai-control-motion-easing); }
.composer-state-icon :deep(.composer-icon-enter-from),.composer-state-icon :deep(.composer-icon-leave-to) { opacity:0; transform:scale(var(--partner-ai-state-icon-entry-scale)); }
.composer-action-divider { margin:0 var(--partner-ai-gap-lg) 0 var(--partner-ai-gap-md); width:1px; height:var(--partner-ai-small-icon-size); background:var(--partner-ai-divider); flex:none; }
@media (forced-colors:active) {
  .chat-composer :deep(.tr-sender:has([contenteditable]:focus-visible)) { outline:var(--partner-ai-focus-width) solid Highlight; outline-offset:var(--partner-ai-focus-offset); }
}
@media (prefers-reduced-motion:reduce) {
  .chat-composer::before,.chat-composer::after { transition:none; }
  .chat-composer :deep(.composer-ai-toggle),.composer-ai-switch-track::before,.composer-ai-switch-track::after,.composer-ai-switch-thumb,.chat-composer :deep(.composer-send-action) { transition:none; }
  .composer-state-icon :deep(.composer-icon-enter-active),.composer-state-icon :deep(.composer-icon-leave-active) { transition:none; }
  .composer-state-icon :deep(.composer-icon-enter-from) { opacity:1; transform:none; }
  .composer-state-icon :deep(.composer-icon-leave-active),.composer-state-icon :deep(.composer-icon-leave-to) { opacity:0; transform:none; }
}
</style>
