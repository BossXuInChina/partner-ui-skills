<script setup lang="ts">
import { computed, nextTick, onBeforeUnmount, onMounted, ref, useId, watch } from 'vue';
import { TrSuggestionPopover, TrSuggestionPillButton } from '@opentiny/tiny-robot';
import { AiIcon } from '../foundation/aiIcons';
import { vAiTooltip } from '../foundation/aiTooltip';
import { useAutoScrollbars } from '../foundation/useAutoScrollbars';
import type { ChatSuggestion, ChatSuggestionCollection } from './chatSuggestions';

const props = withDefaults(defineProps<{ item: ChatSuggestionCollection; disabled: boolean; dragging?: boolean }>(),{dragging:false});
const emit = defineEmits<{ select: [item: ChatSuggestion] }>();
const id = `suggestion-collection-${useId().replace(/[^a-zA-Z0-9-]/g, '')}`;
const open = ref(false), portal = ref<HTMLElement>(), body = ref<HTMLElement>();
const trigger = ref<InstanceType<typeof TrSuggestionPillButton>>();
const theme = ref<Record<string, string>>({});
const unavailable = computed(() => props.disabled || props.item.disabled || !props.item.items.some(item => !item.disabled));
const data = computed(() => props.item.items.map(item => ({ id:item.id, text:item.label })));
let frame = 0;
const anchor = () => trigger.value?.$el as HTMLButtonElement | undefined;
const surface = () => body.value?.closest<HTMLElement>('.partner-ai-suggestion-popover');
useAutoScrollbars(() => portal.value, [{selector:'.suggestion-collection-list',axis:'y'}]);

// TinyRobot 0.5.1 public manual show/data/appendTo/header/body/trigger APIs own
// the popover. Its default clickable li rows lack disabled/keyboard semantics;
// body slots supply native controls. A hidden header slot suppresses its fallback
// title per the Pills annotation; aria-label keeps the collection name accessible.
// Its mobile sheet/backdrop is adapted to an anchored picker in the workspace.
// Recheck forwarded popper attrs and these mobile/close DOM selectors on upgrade.
function position() {
  const button = anchor(); if (!open.value || !button) return;
  const host = button.closest('[data-assistant-window]') ?? button.closest('.chat-panel');
  if (button.closest('[inert]') || !button.getClientRects().length) { close(); return; }
  const box = button.getBoundingClientRect(), bounds = host?.getBoundingClientRect() ?? box;
  const left = Math.max(8, bounds.left + 8), right = Math.min(document.documentElement.clientWidth - 8, bounds.right - 8);
  const top = Math.max(8, bounds.top + 8), above = Math.max(0, box.top - 8 - top);
  const availableWidth = Math.max(0, right - left);
  theme.value['--suggestion-popover-available-width'] = `${availableWidth}px`;
  const panel = surface(), style = getComputedStyle(panel ?? button);
  // CSS max-content measures the longest single-line option with the actual font
  // and padding; the AI max-width token and host bound only cap that natural width.
  const width = Math.min(panel?.getBoundingClientRect().width ?? availableWidth, availableWidth);
  const padding = panel ? Number.parseFloat(style.paddingTop) + Number.parseFloat(style.paddingBottom) : 2 * (Number.parseFloat(style.getPropertyValue('--partner-ai-menu-panel-padding')) || 4);
  const rows = body.value?.querySelectorAll<HTMLButtonElement>('.suggestion-collection-option');
  // Headerless height follows AI padding and actual rows, without the old
  // header allowance. The token estimate is used only before the body mounts.
  const contentHeight = rows?.length ? [...rows].reduce((height, row) => height + row.offsetHeight, 0) : props.item.items.length * (Number.parseFloat(style.getPropertyValue('--partner-ai-suggestion-option-min-height')) || 0);
  const desiredHeight = Math.min(360, padding + contentHeight);
  // User-confirmed direction stays above. Limited upper space scrolls internally;
  // an unusably small workspace closes rather than flipping over Sender.
  if (above < Math.min(96, desiredHeight) || availableWidth < 80) { close(); return; }
  const height = Math.min(desiredHeight, above);
  Object.assign(theme.value, {
    '--suggestion-popover-left':`${Math.min(Math.max(left, box.left), right - width)}px`,
    '--suggestion-popover-top':`${box.top - 8 - height}px`,
    '--suggestion-popover-height':`${height}px`,
  });
}
function follow() { position(); if (open.value) frame = requestAnimationFrame(follow); }
function close(restore = false) {
  open.value = false; cancelAnimationFrame(frame); frame = 0;
  if (restore) anchor()?.focus({preventScroll:true});
}
async function show(last = false) {
  if (unavailable.value || props.dragging || !anchor()) return;
  const style = getComputedStyle(anchor()!);
  const values: Record<string, string> = {fontFamily:style.fontFamily};
  for (let index = 0; index < style.length; index++) {
    const token = style[index]!;
    if (/^--(partner-ai-|wb-|tr-)/.test(token)) values[token] = style.getPropertyValue(token);
  }
  theme.value = values; open.value = true; follow(); await nextTick();
  const buttons = body.value?.querySelectorAll<HTMLButtonElement>('.suggestion-collection-option:not(:disabled)');
  buttons?.[last ? buttons.length - 1 : 0]?.focus({preventScroll:true});
}
function select(item: ChatSuggestion) {
  if (!open.value || unavailable.value || item.disabled) return;
  close(); emit('select', item);
}
function keyboard(event: KeyboardEvent) {
  if (event.key === 'Escape' && open.value) { event.preventDefault(); event.stopPropagation(); close(true); return; }
  if (event.key === 'Tab') { if (open.value) { anchor()?.focus({preventScroll:true}); close(); } return; }
  if (!['ArrowUp','ArrowDown','Home','End'].includes(event.key) || event.altKey || event.ctrlKey || event.metaKey) return;
  event.preventDefault(); event.stopPropagation();
  if (!open.value) { void show(event.key === 'ArrowUp' || event.key === 'End'); return; }
  const buttons = [...(body.value?.querySelectorAll<HTMLButtonElement>('.suggestion-collection-option:not(:disabled)') ?? [])];
  const index = buttons.indexOf(document.activeElement as HTMLButtonElement);
  const next = event.key === 'Home' ? 0 : event.key === 'End' ? buttons.length - 1 : (index + (event.key === 'ArrowUp' ? -1 : 1) + buttons.length) % buttons.length;
  buttons[next]?.focus();
}
function outside(event: Event) {
  if (open.value && event.target instanceof Node && !anchor()?.contains(event.target) && !surface()?.contains(event.target)) close();
}
watch(unavailable, value => { if (value) close(); });
// Close the picker during row dragging without disabling its focused trigger.
watch(()=>props.dragging, value=>{if(value)close();});
watch(() => props.item, () => close(), {deep:true});
onMounted(() => { document.addEventListener('pointerdown', outside, true); document.addEventListener('focusin', outside); });
onBeforeUnmount(() => { close(); document.removeEventListener('pointerdown', outside, true); document.removeEventListener('focusin', outside); });
</script>

<template>
  <Teleport to="body"><div ref="portal" class="partner-ai suggestion-collection-portal" :style="theme" /></Teleport>
  <TrSuggestionPopover v-if="portal" :id="id" class="partner-ai-suggestion-popover" :data="data" :append-to="portal" trigger="manual" :show="open" :title="item.label" role="dialog" :aria-label="item.label" @click-outside="close()" @close="close(true)" @keydown.capture="keyboard">
    <template #trigger>
      <TrSuggestionPillButton ref="trigger" v-ai-tooltip="{content:item.label,disabled:open || dragging,overflowOnly:true,overflowSelector:':scope > span'}" class="composer-suggestion composer-suggestion-collection" :item="{text:item.label}" type="button" :disabled="unavailable" aria-haspopup="dialog" :aria-expanded="open" :aria-controls="open ? id : undefined" @click="open ? close(true) : show()" @keydown="keyboard"><span>{{ item.label }}</span><AiIcon name="composer.expand" aria-hidden="true" /></TrSuggestionPillButton>
    </template>
    <template #header><span hidden /></template>
    <template #body><div ref="body" class="suggestion-collection-list partner-ai-scrollbar-portal"><button v-for="question in item.items" :key="question.id" v-ai-tooltip="{content:question.label,overflowOnly:true}" type="button" class="suggestion-collection-option" :disabled="question.disabled || disabled" @click="select(question)">{{ question.label }}</button></div></template>
  </TrSuggestionPopover>
</template>

<style>
/* Only this owned portal adapts Robot's mobile backdrop/close button. Resolved
   tokens preserve consumer theme/shadow values outside the clipped footer. */
.partner-ai.suggestion-collection-portal { height:0; background:transparent; pointer-events:none; }
.suggestion-collection-portal > .tr-question-popover__backdrop,
.suggestion-collection-portal .partner-ai-suggestion-popover > .tr-question-popover__close { display:none !important; }
.suggestion-collection-portal .partner-ai-suggestion-popover {
  box-sizing:border-box; pointer-events:auto; left:var(--suggestion-popover-left) !important; top:var(--suggestion-popover-top) !important;
  right:auto !important; bottom:auto !important; min-width:0 !important;
  width:max-content !important; max-width:min(var(--partner-ai-suggestion-popover-max-width),var(--suggestion-popover-available-width)) !important;
  height:var(--suggestion-popover-height) !important; max-height:none;
  z-index:21000; padding:var(--partner-ai-menu-panel-padding); border-radius:var(--partner-ai-mode-panel-radius);
  background:var(--partner-ai-overlay-bg); color:var(--partner-ai-text); box-shadow:var(--partner-ai-mode-panel-shadow);
  font-size:var(--partner-ai-body-size); line-height:var(--partner-ai-body-line);
}
.partner-ai-suggestion-popover.mobile { border-radius:var(--partner-ai-mode-panel-radius); }
.suggestion-collection-list { min-width:0; min-height:0; overflow-y:auto; overscroll-behavior:contain; }
.suggestion-collection-option { display:block; width:100%; min-height:var(--partner-ai-suggestion-option-min-height); padding:var(--partner-ai-gap-md); border:0; border-radius:var(--partner-ai-menu-option-radius); background:transparent; color:inherit; font:inherit; text-align:left; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; cursor:pointer; }
.suggestion-collection-option:disabled { color:var(--partner-ai-disabled-text); cursor:not-allowed; }
.suggestion-collection-option:hover:not(:disabled) { background:var(--partner-ai-hover-bg); }
.suggestion-collection-option:focus-visible { outline:var(--partner-ai-focus-width) solid var(--partner-ai-focus); outline-offset:var(--partner-ai-focus-inset); }
/* Override Robot 0.5.1's 18px pill icon rule with the mode selector's shared
   arrow size/motion. aria-expanded keeps every open/close path in sync;
   the up-pointing source rests at-180deg: opening to0deg turns clockwise,
   closing turns counterclockwise. Recheck pill styles on upgrades. */
.composer-suggestion-collection svg[data-ai-icon="composer.expand"] { width:var(--partner-ai-arrow-icon-size); height:var(--partner-ai-arrow-icon-size); flex:none; transform:rotate(-180deg); transition:transform 220ms cubic-bezier(.2,.8,.2,1); }
.composer-suggestion-collection[aria-expanded="true"] svg[data-ai-icon="composer.expand"] { transform:rotate(0deg); }
@media(prefers-reduced-motion:reduce) { .partner-ai-suggestion-popover { transition:none !important; } .composer-suggestion-collection svg[data-ai-icon="composer.expand"] { transition:none; } }
</style>
