<script setup lang="ts">
import { ref, watch } from 'vue';
import { TrSuggestionPills, TrSuggestionPillButton } from '@opentiny/tiny-robot';
import SuggestionCollection from './SuggestionCollection.vue';
import { vAiTooltip } from '../foundation/aiTooltip';
import { useSuggestionShadows } from '../foundation/useSuggestionShadows';
import { useAutoScrollbars } from '../foundation/useAutoScrollbars';
import { useSuggestionDrag } from './useSuggestionDrag';
import type { ChatSuggestion, ChatSuggestionPill } from './chatSuggestions';
import '../foundation/aiTokens.css';
import './suggestionStyles.css';
const props = withDefaults(defineProps<{ items: ChatSuggestionPill[]; disabled?: boolean; scrollbarVisible?: boolean }>(), { disabled:false, scrollbarVisible:false });
const emit = defineEmits<{ select: [item: ChatSuggestion] }>();
const row = ref<HTMLElement>();
const {dragPhase,cancelDrag}=useSuggestionDrag(row);
watch(()=>[props.items,props.disabled],cancelDrag,{deep:true});
// Internal source-only opt-in retains the native bar and its former dwell policy.
// Hidden mode attaches no scrollbar hot-zone listeners. Public panel API is unchanged.
useAutoScrollbars(() => props.scrollbarVisible ? row.value : undefined,[{selector:'.tr-suggestion-pills__container',axis:'x',hoverDelayMs:300}]);
const {suggestionShadows,scheduleSuggestionShadows}=useSuggestionShadows(row,()=>[props.items,props.disabled]);
function select(item: ChatSuggestion) { if (!props.disabled && !item.disabled) emit('select',item); }
// Only vertical wheel input over the visible row is translated. Preserve native
// horizontal/Shift scrolling, zoom gestures and parent scrolling at both ends.
// The Robot 0.5.1 scrollport selector is the only dependency DOM adapter here.
function wheelSuggestions(event: WheelEvent) {
  const bounds=row.value?.getBoundingClientRect();
  if (!bounds || event.defaultPrevented || !event.cancelable || event.ctrlKey || event.metaKey || event.altKey || event.shiftKey || event.deltaX || !event.deltaY || event.clientY<bounds.top || event.clientY>=bounds.bottom) return;
  const port=row.value?.querySelector<HTMLElement>('.tr-suggestion-pills__container');
  if (!port || port.scrollWidth<=port.clientWidth) return;
  const unit=event.deltaMode===1 ? parseFloat(getComputedStyle(port).lineHeight)||bounds.height : event.deltaMode===2 ? port.clientWidth : 1;
  const before=port.scrollLeft;
  port.scrollLeft=Math.max(0,Math.min(port.scrollWidth-port.clientWidth,before+event.deltaY*unit));
  if (port.scrollLeft!==before) event.preventDefault();
}
// Product and source examples share one32px row and the existing shadow painter.
// The owner decides visibility and send handling; shadows do not add layout gap.
// Public Robot controls stay native. Scrollport DOM needs upgrade review.
function scrollSuggestions(event: KeyboardEvent) {
  if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key) || event.altKey || event.ctrlKey || event.metaKey) return;
  const scroll = (event.currentTarget as HTMLElement).querySelector('.tr-suggestion-pills__container');
  if (!scroll) return;
  event.preventDefault();
  if (event.key === 'Home' || event.key === 'End') scroll.scrollTo({ left: event.key === 'Home' ? 0 : scroll.scrollWidth, behavior: 'instant' });
  else scroll.scrollBy({ left: (event.key === 'ArrowRight' ? 1 : -1) * scroll.clientWidth / 2, behavior: 'instant' });
}
</script>
<template>
  <div ref="row" class="composer-suggestion-row" :data-drag-phase="dragPhase" @scroll.capture="scheduleSuggestionShadows" @wheel="wheelSuggestions">
  <div class="composer-suggestion-shadows" aria-hidden="true"><span v-for="shadow in suggestionShadows" :key="shadow.key" :style="shadow.style" /></div>
  <TrSuggestionPills class="composer-suggestions" :data-scrollbar-visibility="scrollbarVisible ? 'visible' : 'hidden'" overflow-mode="scroll" role="group" aria-label="输入建议（左右方向键滚动）" tabindex="0" @keydown="scrollSuggestions">
    <template v-for="item in items" :key="item.id">
      <SuggestionCollection v-if="'items' in item" :item="item" :disabled="disabled" :dragging="dragPhase!=='idle'" @select="select" />
      <TrSuggestionPillButton v-else v-ai-tooltip="{ content: item.label, disabled:dragPhase!=='idle', overflowOnly: true, overflowSelector: ':scope > span' }" class="composer-suggestion" :item="{ text: item.label }" type="button" :disabled="disabled || item.disabled" @click="select(item)" />
    </template>
  </TrSuggestionPills>
  </div>
</template>
