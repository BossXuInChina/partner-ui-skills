import { inject, type InjectionKey } from 'vue';

// The product build always enables phase-one visibility. Local Studio can opt in
// through this internal provider to exercise exactly the same component gates.
export const deliveryPreviewKey: InjectionKey<boolean> = Symbol('phase-one-delivery-preview');
export function useDeliveryMode() {
  const preview = inject(deliveryPreviewKey, false);
  return import.meta.env.VITE_AI_DELIVERY === 'true' || preview;
}
