/* eslint-disable vue/one-component-per-file -- Small SVG render adapters belong to one semantic default map. */
import { computed, createVNode, defineComponent, h, inject, isVNode, provide, type Component, type InjectionKey, type PropType, type Ref } from 'vue';
import { localIcons, LocalWindowModeIcon } from '../../assets/ai-icons/localIcons';
import './aiIcons.css';

/** Trusted, locally imported Vue SVG components only; never SVG text, HTML or URLs.
 * inherit: currentColor ink; original: preserve multicolor; gradient: smart masks only. */
export type AiIconColor = 'inherit' | 'original' | 'gradient';
export interface AiIconDefinition { component: Component; color?: AiIconColor }
// Local SVGs are self-contained; provenance.json records source files and hashes.
// Robot continues to own the public action slots; these adapters own artwork only.
const defaults = {
  'assistant.fallback': { component:localIcons.ai },
  'panel.mode': { component:LocalWindowModeIcon },
  'panel.newConversation': { component:localIcons.newConversation },
  'panel.history': { component:localIcons.history },
  'panel.fullscreen': { component:localIcons.fullscreen },
  'panel.exitFullscreen': { component:localIcons.exitFullscreen },
  'panel.close': { component:localIcons.close },
  'composer.voice': { component:localIcons.voice },
  'composer.image': { component:localIcons.image },
  'composer.send': { component:localIcons.send },
  'composer.stop': { component:localIcons.stop },
  'composer.mode': { component:localIcons.thinking, color:'original' },
  'composer.expand': { component:localIcons.modeArrow },
  'composer.selected': { component:localIcons.check },
  'alert.error': { component:localIcons.error },
  'message.regenerate': { component:localIcons.regenerate },
  'message.copy': { component:localIcons.copy },
  'message.like': { component:localIcons.like },
  'message.dislike': { component:localIcons.dislike },
  'message.bookmark': { component:localIcons.bookmark },
  'message.followUp': { component:localIcons.right },
  'history.clear': { component:localIcons.clear },
  'history.search': { component:localIcons.search },
  'history.clearSearch': { component:localIcons.close },
  'history.pin': { component:localIcons.pin },
  'history.more': { component:localIcons.more },
  'welcome.entry': { component:localIcons.welcomePurple, color:'original' },
  'smart.mark': { component:localIcons.smartFilled, color:'gradient' },
  'business.navigate': { component:localIcons.businessNavigate },
  'business.close': { component:localIcons.close },
  'business.success': { component:localIcons.success, color:'original' },
} satisfies Record<string, AiIconDefinition>;
export type AiIconName = keyof typeof defaults;
export type AiIconMap = Partial<Record<AiIconName, Component | AiIconDefinition>>;
/** Readonly defaults for inspection; consumers override via a scoped map, never mutation. */
for (const entry of Object.values(defaults)) Object.freeze(entry);
export const defaultAiIcons: Readonly<Record<AiIconName, Readonly<AiIconDefinition>>> = Object.freeze(defaults);
type IconScope = Readonly<Ref<AiIconMap>>;
const iconScope: InjectionKey<IconScope> = Symbol('partner-ai-icons');

/** Internal scope adapter shared by panels and the public Provider. No global registry:
 * reactivity follows prop replacement/deep reactive edits, with nearest defined override. */
export function provideAiIcons(local: Readonly<Ref<AiIconMap | undefined>>): IconScope {
  const parent = inject(iconScope, undefined);
  const merged = computed(() => {
    const result: AiIconMap = {...parent?.value};
    for (const [name, value] of Object.entries(local.value ?? {})) if (value != null) result[name as AiIconName] = value;
    return result;
  });
  provide(iconScope, merged);
  return merged;
}
function definition(value: Component | AiIconDefinition, name: AiIconName): AiIconDefinition {
  const entry = typeof value === 'object' && value && 'component' in value ? value as AiIconDefinition : {component:value as Component};
  if (!entry.component || !['object','function'].includes(typeof entry.component) || isVNode(entry.component)) throw new TypeError('AI icons require a trusted Vue component, not markup, URLs or VNodes');
  if (entry.color && !['inherit','original','gradient'].includes(entry.color)) throw new TypeError('Unknown AI icon color policy');
  if (entry.color === 'gradient' && name !== 'smart.mark') throw new TypeError('Gradient icons are supported only for smart.mark');
  return entry;
}
export function useAiIconDefinition(name: AiIconName) {
  const scope = inject(iconScope, undefined);
  return computed(() => definition(scope?.value[name] ?? defaultAiIcons[name], name));
}
/** Public icon slot adapter. A single SVG root preserves TinyRobot's native slot,
 * transitions and sizing selectors. No additional DOM wrapper or event owner. */
export const AiIcon = defineComponent({
  name:'AiIcon', inheritAttrs:false,
  props:{ name:{type:String as PropType<AiIconName>,required:true} },
  setup(props,{attrs}) {
    const scope = inject(iconScope, undefined);
    return () => {
      const entry = definition(scope?.value[props.name] ?? defaultAiIcons[props.name], props.name);
      return h(entry.component, {...attrs, 'aria-hidden':'true', focusable:'false', 'data-ai-icon':props.name, 'data-ai-icon-color':entry.color ?? 'inherit'});
    };
  },
});
export const AiIconProvider = defineComponent({
  name:'AiIconProvider',
  props:{ icons:{type:Object as PropType<AiIconMap>,default:undefined} },
  setup(props,{slots}) {
    provideAiIcons(computed(() => props.icons));
    return () => slots.default?.();
  },
});

/** TinyRobot renders icon/badge VNodes as dynamic components. Keep these detached
 * prop VNodes out of the caller's compiled block: otherwise Vue tracks an unmounted
 * copy there while TinyRobot owns its clone (null emitsOptions on updates).
 * Fresh VNodes + public createVNode isBlockNode prevent reuse/ownership collisions;
 * recheck this adapter with Vue/TinyRobot upgrades. No dependency DOM access. */
export function aiIconVNode(name: AiIconName, attrs: Record<string, unknown> = {}) {
  return createVNode(AiIcon, { ...attrs, name }, null, 0, null, true);
}
