type TooltipOwner = { close: () => void };
const active = new WeakMap<object, TooltipOwner>();
const scopes = new WeakMap<TooltipOwner, object>();

// REQ-014 v0.7: scope to our consumer-owned panel, including host resize grips.
// A body-mounted native popover follows its public aria-controls anchor back to
// that panel. No third-party instances, global popper hiding or host mutations.
function panelScope(trigger: HTMLElement): object {
  const seen = new Set<HTMLElement>();
  let current: HTMLElement | undefined = trigger;
  while (current && !seen.has(current)) {
    seen.add(current);
    const panel = current.closest('.company-ai-sidebar') ?? current.closest('.agreement-assistant-panel') ?? current.closest('.chat-panel') ?? current.closest('.partner-ai');
    if (panel) return panel;
    const popup: Element | null = current.closest('[popover]');
    if (!popup?.id) break;
    const id: string = popup.id;
    current = [...trigger.ownerDocument.querySelectorAll<HTMLElement>('[aria-controls]')].find(el => (el.getAttribute('aria-controls') ?? '').split(/\s+/).includes(id));
  }
  return trigger.ownerDocument;
}

export function claimTooltip(owner: TooltipOwner, trigger: HTMLElement) {
  const scope = panelScope(trigger), previous = active.get(scope);
  if (previous === owner) return;
  releaseTooltip(owner);
  previous?.close();
  active.set(scope, owner); scopes.set(owner, scope);
}

export function releaseTooltip(owner: TooltipOwner) {
  const scope = scopes.get(owner);
  if (scope && active.get(scope) === owner) active.delete(scope);
  scopes.delete(owner);
}
