import { createApp, h, reactive, type Directive, type App } from 'vue';
import AiTooltip from './AiTooltip.vue';

export type AiTooltipOptions = { content: string; placement?: 'top' | 'bottom'; disabled?: boolean; overflowOnly?: boolean; overflowSelector?: string; closeOnPointerLeave?: boolean };
type Value = string | AiTooltipOptions | undefined;
const instances = new WeakMap<HTMLElement, { app: App; options: AiTooltipOptions }>();
let nextId = 0;
const options = (value: Value): AiTooltipOptions => ({ content: '', placement: 'top', disabled: false, overflowOnly: false, overflowSelector: undefined, ...(typeof value === 'string' ? { content: value } : value) });
const triggerOptions = (element: HTMLElement, value: Value) => {
  const result = options(value);
  result.disabled = !!result.disabled || element.matches(':disabled,[aria-disabled="true"]');
  return result;
};

// REQ-014: no TinyRobot 0.5.1 public standalone Tooltip/control API. This thin
// directive mounts the self-contained Workbench port against the existing native
// trigger, with no layout wrapper or upstream instance/DOM access. TrActionButton
// must omit its public tooltip prop; recheck public alternatives on upgrades.
export const vAiTooltip: Directive<HTMLElement, Value> = {
  mounted(element, binding) {
    const state = reactive(triggerOptions(element, binding.value));
    const id = `partner-ai-tooltip-${nextId++}`;
    const app = createApp({ render: () => h(AiTooltip, { trigger: element, id, ...state }) });
    app.mount(document.createElement('div'));
    instances.set(element, { app, options: state });
  },
  updated(element, binding) { Object.assign(instances.get(element)?.options ?? {}, triggerOptions(element, binding.value)); },
  beforeUnmount(element) { instances.get(element)?.app.unmount(); instances.delete(element); },
};
