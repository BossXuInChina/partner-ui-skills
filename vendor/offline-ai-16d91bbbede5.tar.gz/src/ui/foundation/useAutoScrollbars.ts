import { onBeforeUnmount, watch } from 'vue';
import './autoScrollbarStyles.css';

type Surface = { selector:string; axis:'x'|'y'; hoverDelayMs?:number };
// REQ-015 v0.3: Workbench supplies paint and native/overlay track hit geometry,
// but has no idle-hide policy. These consumer choices are NOT upstream defaults.
const idleDelay = 800, fadeDuration = 200;

// Paint-only lifecycle: never writes scrollTop/Left, captures a pointer, or prevents
// wheel/touch/key defaults. Retain each native track's dimensions and existing gutter
// compensation. TinyRobot 0.5.1 selectors are adapters to review on upgrades.
export function useAutoScrollbars(getRoot:() => HTMLElement | undefined, surfaces:Surface[]) {
  let dispose: (() => void) | undefined;
  const unwatch = watch(getRoot, root => {
    dispose?.(); dispose=undefined;
    if (!root) return;
    const win=root.ownerDocument.defaultView!;
    const states=new Map<HTMLElement,{axis:'x'|'y';hot:boolean;inside:boolean;hoverDelay:number;hoverTimer:number;drag:boolean;armed:number;timer:number;frame:number;opacity:number;cleanup:()=>void}>();
    const observed=new Set<Element>();
    const overflow=(node:HTMLElement,axis:'x'|'y')=>axis==='x'?node.scrollWidth-node.clientWidth>1:node.scrollHeight-node.clientHeight>1;
    function paint(node:HTMLElement, opacity:number, state:string) {
      const s=states.get(node);if(!s)return;s.opacity=opacity;
      node.style.setProperty('--ai-auto-scrollbar-opacity',String(opacity));
      node.dataset.aiScrollbarState=state;
      node.dataset.aiScrollbarHot=String(s.hot||s.drag);
    }
    function cancel(node:HTMLElement) { const s=states.get(node)!;win.clearTimeout(s.timer);win.cancelAnimationFrame(s.frame);s.timer=0;s.frame=0; }
    function cancelHover(node:HTMLElement) {const s=states.get(node)!;win.clearTimeout(s.hoverTimer);s.hoverTimer=0;node.dataset.aiScrollbarHoverPending='false';}
    function hideLater(node:HTMLElement) {
      const s=states.get(node)!;cancel(node);if(s.hot||s.drag)return;
      s.timer=win.setTimeout(()=>{
        const start=win.performance.now(),opacity=s.opacity;
        const fade=(time:number)=>{if(!states.has(node))return;const progress=Math.min(1,(time-start)/fadeDuration);paint(node,opacity*(1-progress),progress<1?'fading':'hidden');if(progress<1)s.frame=win.requestAnimationFrame(fade);else s.frame=0;};
        s.frame=win.requestAnimationFrame(fade);
      },idleDelay);
    }
    function reveal(node:HTMLElement) {
      const s=states.get(node)!;if(!overflow(node,s.axis)){cancel(node);paint(node,0,'hidden');return;}
      cancel(node);paint(node,1,s.drag?'dragging':s.hot?'hot':'visible');hideLater(node);
    }
    function hit(node:HTMLElement,event:PointerEvent) {
      const s=states.get(node)!;if(event.pointerType==='touch'||!overflow(node,s.axis))return false;
      const box=node.getBoundingClientRect(),scaleX=box.width/node.offsetWidth||1,scaleY=box.height/node.offsetHeight||1;
      const css=getComputedStyle(node),pseudo=win.CSS.supports('selector(::-webkit-scrollbar)')?getComputedStyle(node,'::-webkit-scrollbar'):undefined;
      const borderX=parseFloat(css.borderLeftWidth)+parseFloat(css.borderRightWidth),borderY=parseFloat(css.borderTopWidth)+parseFloat(css.borderBottomWidth);
      const gutter=s.axis==='x'?node.offsetHeight-node.clientHeight-borderY:node.offsetWidth-node.clientWidth-borderX;
      const size=gutter||parseFloat(s.axis==='x'?pseudo?.height??'':pseudo?.width??'')||parseFloat(css.getPropertyValue('--scrollbar-ai-size'))||parseFloat(css.getPropertyValue('--partner-ai-scrollbar-size'))||10;
      const right=box.right-parseFloat(css.borderRightWidth)*scaleX,bottom=box.bottom-parseFloat(css.borderBottomWidth)*scaleY;
      // Only the existing bottom/right track, not the entire scrolling content.
      return s.axis==='x'
        ?event.clientX>=box.left&&event.clientX<=right&&event.clientY>=bottom-size*scaleY&&event.clientY<=bottom
        :event.clientY>=box.top&&event.clientY<=bottom&&event.clientX>=right-size*scaleX&&event.clientX<=right;
    }
    function attach(node:HTMLElement,axis:'x'|'y',hoverDelayMs=0) {
      if(states.has(node))return;
      const previous={tab:node.getAttribute('tabindex'),opacity:node.style.getPropertyValue('--ai-auto-scrollbar-opacity')};
      const s={axis,hot:false,inside:false,hoverDelay:Math.max(0,hoverDelayMs),hoverTimer:0,drag:false,armed:0,timer:0,frame:0,opacity:0,cleanup:()=>{}};states.set(node,s);node.dataset.aiAutoScrollbar='true';paint(node,0,'hidden');
      // Native list/table ports receive a keyboard entry point; editor/group/dialog
      // keep their existing focus protocol, including UiDialog's focus trap.
      const addedTab=node.matches('.chat-scroll,.table-wrap')&&!node.hasAttribute('tabindex');if(addedTab)node.tabIndex=0;
      const scroll=()=>{if(overflow(node,axis)&&(s.inside||s.hot||s.drag||win.performance.now()<s.armed)){s.armed=win.performance.now()+1500;cancelHover(node);s.hot=s.inside;reveal(node);}};
      const wheel=(event:WheelEvent)=>{s.armed=win.performance.now()+1500;if(!s.hoverDelay&&event.target instanceof Element&&event.target.closest('[data-ai-auto-scrollbar]')===node&&(axis==='x'?(event.deltaX||event.shiftKey&&event.deltaY):event.deltaY))reveal(node);};
      const touch=()=>{s.armed=win.performance.now()+1500;};
      const leave=()=>{s.inside=false;s.hot=false;cancelHover(node);if(!s.drag){if(!s.opacity){cancel(node);paint(node,0,'hidden');}else{paint(node,s.opacity,'visible');hideLater(node);}}};
      // REQ-015 v0.4: only Pills opts into300ms dwell. Passing through the real
      // track never reveals it; actual scroll and pointer down confirm intent at once.
      const move=(event:PointerEvent)=>{const next=hit(node,event);if(next===s.inside)return;if(!next){leave();return;}s.inside=true;if(!s.hoverDelay||s.drag){s.hot=true;reveal(node);return;}cancel(node);cancelHover(node);node.dataset.aiScrollbarHoverPending='true';s.hoverTimer=win.setTimeout(()=>{s.hoverTimer=0;node.dataset.aiScrollbarHoverPending='false';if(s.inside&&overflow(node,axis)){s.hot=true;reveal(node);}},s.hoverDelay);};
      const down=(event:PointerEvent)=>{if(event.button===0&&hit(node,event)){cancelHover(node);s.inside=true;s.hot=true;s.drag=true;s.armed=win.performance.now()+1500;reveal(node);}};
      node.addEventListener('scroll',scroll,{passive:true});node.addEventListener('wheel',wheel,{passive:true});node.addEventListener('touchstart',touch,{passive:true});node.addEventListener('touchmove',touch,{passive:true});node.addEventListener('pointerenter',move);node.addEventListener('pointermove',move);node.addEventListener('pointerleave',leave);node.addEventListener('pointerdown',down);
      s.cleanup=()=>{cancel(node);cancelHover(node);node.removeEventListener('scroll',scroll);node.removeEventListener('wheel',wheel);node.removeEventListener('touchstart',touch);node.removeEventListener('touchmove',touch);node.removeEventListener('pointerenter',move);node.removeEventListener('pointermove',move);node.removeEventListener('pointerleave',leave);node.removeEventListener('pointerdown',down);delete node.dataset.aiAutoScrollbar;delete node.dataset.aiScrollbarState;delete node.dataset.aiScrollbarHot;delete node.dataset.aiScrollbarOverflow;delete node.dataset.aiScrollbarHoverPending;node.style.removeProperty('--ai-auto-scrollbar-opacity');if(previous.opacity)node.style.setProperty('--ai-auto-scrollbar-opacity',previous.opacity);if(addedTab){if(previous.tab===null)node.removeAttribute('tabindex');else node.setAttribute('tabindex',previous.tab);}states.delete(node);};
    }
    function refresh() {
      const nodes=new Set<HTMLElement>();
      for(const surface of surfaces){if(root!.matches(surface.selector)){nodes.add(root!);attach(root!,surface.axis,surface.hoverDelayMs);}for(const node of root!.querySelectorAll<HTMLElement>(surface.selector)){nodes.add(node);attach(node,surface.axis,surface.hoverDelayMs);}}
      const nextObserved=new Set<Element>();
      for(const [node,s] of states){if(!nodes.has(node)){s.cleanup();continue;}nextObserved.add(node);for(const child of node.children)nextObserved.add(child);const has=overflow(node,s.axis);node.dataset.aiScrollbarOverflow=String(has);if(!has){s.hot=false;s.inside=false;s.drag=false;cancelHover(node);cancel(node);paint(node,0,'hidden');}}
      for(const node of observed)if(!nextObserved.has(node)){resize.unobserve(node);observed.delete(node);}
      for(const node of nextObserved)if(!observed.has(node)){resize.observe(node);observed.add(node);}
    }
    const resize=new ResizeObserver(refresh);
    const mutations=new MutationObserver(refresh);mutations.observe(root,{childList:true,subtree:true});
    const key=(event:KeyboardEvent)=>{if(!['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Home','End','PageUp','PageDown',' ','Tab'].includes(event.key)||event.ctrlKey||event.metaKey||event.altKey)return;for(const [node,s] of states){if(event.target instanceof Node&&(node.contains(event.target)||node.matches('.tr-suggestion-pills__container')&&node.parentElement?.contains(event.target))){s.armed=win.performance.now()+1500;reveal(node);}}};
    const release=(event:PointerEvent)=>{for(const [node,s] of states)if(s.drag){cancelHover(node);s.drag=false;s.inside=s.hot=hit(node,event);reveal(node);}};
    const blur=()=>{for(const [node,s] of states){cancelHover(node);s.drag=false;s.inside=false;s.hot=false;paint(node,s.opacity,s.opacity?'visible':'hidden');if(s.opacity)hideLater(node);}};
    root.addEventListener('keydown',key,true);win.addEventListener('pointerup',release,true);win.addEventListener('pointercancel',release,true);win.addEventListener('blur',blur);refresh();
    dispose=()=>{mutations.disconnect();resize.disconnect();root.removeEventListener('keydown',key,true);win.removeEventListener('pointerup',release,true);win.removeEventListener('pointercancel',release,true);win.removeEventListener('blur',blur);for(const s of [...states.values()])s.cleanup();};
  },{immediate:true,flush:'post'});
  onBeforeUnmount(()=>{unwatch();dispose?.();});
}
