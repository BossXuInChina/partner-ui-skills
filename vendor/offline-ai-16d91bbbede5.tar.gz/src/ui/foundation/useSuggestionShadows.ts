import { nextTick, onBeforeUnmount, onMounted, shallowRef, watch, type Ref } from 'vue';

// REQ-015 v0.2: a native scrollbar consumes the Pill viewport's paint gutter. Paint
// the SAME box-shadow outside that clipping node, under the real public Pill buttons.
// This decoration reads geometry only; native scroll/focus/touch remain in TinyRobot.
// Recheck the 0.5.1 container/item DOM adapter when upgrading.
type ShadowPaintOptions = { itemSelector:string; portSelector:string; nativeGutterOnly:boolean };
export function useSuggestionShadows(footer: Ref<HTMLElement | undefined>, source: () => unknown, options?:ShadowPaintOptions) {
  const suggestionShadows = shallowRef<Array<{ key: number; style: Record<string, string> }>>([]);
  const shadowClipStyle = shallowRef<Record<string,string>>({});
  let frame = 0, observer: ResizeObserver | undefined, port: Element | null = null;
  const observedItems=new Set<Element>();
  function measure() {
    frame = 0;
    const root = footer.value;
    if (!root) return;
    const bounds = root.getBoundingClientRect(), scaleX = bounds.width / root.offsetWidth || 1, scaleY = bounds.height / root.offsetHeight || 1;
    const items=[...root.querySelectorAll<HTMLElement>(options?.itemSelector??'.composer-suggestion')];
    suggestionShadows.value = items.flatMap((item, key) => {
      const box = item.getBoundingClientRect(), style = getComputedStyle(item);
      if(options?.nativeGutterOnly && style.boxShadow==='none')return [];
      return [{ key, style: { left:`${(box.left-bounds.left)/scaleX}px`, top:`${(box.top-bounds.top)/scaleY}px`, width:`${box.width/scaleX}px`, height:`${box.height/scaleY}px`, borderRadius:style.borderRadius, opacity:style.opacity,...(options?.nativeGutterOnly?{boxShadow:style.boxShadow}:{}) } }];
    });
    const nextPort = root.querySelector<HTMLElement>(options?.portSelector??'.tr-suggestion-pills__container');
    if (nextPort !== port) { if (port) observer?.unobserve(port); port = nextPort; if (port) observer?.observe(port); }
    // REQ-015 v0.4: native clientWidth excludes its scrollbar's paint slot even when
    // the thumb is transparent. Restore ONLY that missing strip; original shadows
    // stay in the viewport, so content geometry and shadow strength do not change.
    if(options?.nativeGutterOnly){
      const right=nextPort?((nextPort.getBoundingClientRect().left-bounds.left)/scaleX+nextPort.clientLeft+nextPort.clientWidth):root.offsetWidth;
      shadowClipStyle.value={clipPath:`inset(0 0 0 ${Math.min(root.offsetWidth,Math.max(0,right))}px)`};
      for(const item of observedItems)if(!items.includes(item as HTMLElement)){observer?.unobserve(item);observedItems.delete(item);}
      for(const item of items)if(!observedItems.has(item)){observer?.observe(item);observedItems.add(item);}
    }
  }
  function scheduleSuggestionShadows() { if (!frame) frame = requestAnimationFrame(measure); }
  watch(source, async () => { await nextTick(); scheduleSuggestionShadows(); }, { deep:true, flush:'post' });
  onMounted(() => { observer = new ResizeObserver(scheduleSuggestionShadows); if (footer.value) observer.observe(footer.value); scheduleSuggestionShadows(); });
  onBeforeUnmount(() => { observer?.disconnect(); cancelAnimationFrame(frame); });
  return { suggestionShadows, scheduleSuggestionShadows, shadowClipStyle };
}
