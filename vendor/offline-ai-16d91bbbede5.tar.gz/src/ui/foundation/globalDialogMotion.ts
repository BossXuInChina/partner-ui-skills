import { lockModalScroll } from '../../host/modalScroll';

type Frame = { opacity:number; mask:number; x:number };
type Retiring = { resume:()=>Frame };
const retired=new WeakMap<Document,Map<string,Retiring>>();
/** REQ-022 v0.6: true native global modality, Workbench's 200ms opacity motion,
 * retained real DOM and interruption continuity. Native ::backdrop is animated
 * for UiDialog; the local full-screen Workbench shell already contains its mask.
 * Only declared popup controls/registered feedback are moved into the modal,
 * because a body portal outside a native modal is implicitly inert. */
export function createGlobalDialogMotion(surface:HTMLElement, dialog:HTMLDialogElement, key:string, release:(superseded:boolean)=>void, options:{nativeBackdrop?:boolean;drawer?:boolean;feedbackRoots?:()=>HTMLElement[]}={}) {
  const doc=dialog.ownerDocument,win=doc.defaultView!,media=win.matchMedia('(prefers-reduced-motion: reduce)');
  const unlock=lockModalScroll(doc), start=retired.get(doc)?.get(key)?.resume()??{opacity:0,mask:0,x:options.drawer?1:0};
  let animations:Animation[]=[],revision=0,disposed=false,remove:(()=>void)|undefined,retirement:Retiring|undefined,frame=0;
  const portals=new Map<HTMLElement,{parent:Node;next:Node|null}>();
  function adoptPortals() {
    if(!dialog.isConnected||disposed)return;
    const controls=[...dialog.querySelectorAll<HTMLElement>('[aria-controls]')].flatMap(trigger=>(trigger.getAttribute('aria-controls')??'').split(/\s+/).map(id=>doc.getElementById(id))).filter((node):node is HTMLElement=>!!node&&node.matches('[popover],[role="listbox"],[role="menu"],[role="tree"],[role="tooltip"]'));
    for(const node of [...controls,...(options.feedbackRoots?.()??[])]) {
      if(!node.isConnected||dialog.contains(node)||node.contains(dialog)||!node.parentNode)continue;
      if(!portals.has(node))portals.set(node,{parent:node.parentNode,next:node.nextSibling});
      dialog.appendChild(node);
    }
  }
  const observer=new MutationObserver(adoptPortals);
  observer.observe(doc.body,{childList:true,subtree:true,attributes:true,attributeFilter:['aria-controls']});
  function position():Frame {
    const paint=win.getComputedStyle(dialog),matrix=paint.transform;
    return {opacity:Number(paint.opacity),mask:options.nativeBackdrop?Number(win.getComputedStyle(dialog,'::backdrop').opacity):Number(paint.opacity),x:options.drawer?Math.max(0,Math.min(1,(matrix==='none'?0:new win.DOMMatrixReadOnly(matrix).m41)/(dialog.offsetWidth||1))):0};
  }
  function cancel(){revision++;win.cancelAnimationFrame(frame);for(const animation of animations)animation.cancel();animations=[];}
  function finish(superseded=false) {
    if(disposed)return;disposed=true;cancel();observer.disconnect();media.removeEventListener('change', preference);
    if(retired.get(doc)?.get(key)===retirement)retired.get(doc)?.delete(key);
    for(const [node,{parent,next}] of portals)if(node.isConnected&&dialog.contains(node)&&parent.isConnected)parent.insertBefore(node,next?.parentNode===parent?next:null);
    portals.clear();dialog.close();remove?.();unlock();release(superseded);
  }
  function settle(){dialog.style.opacity='1';dialog.style.setProperty('--partner-global-mask-opacity','1');if(options.drawer)dialog.style.transform='none';cancel();surface.dataset.dialogMotion='open';}
  function preference(){if(!media.matches)return;cancel();if(remove)finish();else settle();}
  function animate(from:Frame,to:Frame,complete:()=>void) {
    cancel();const generation=revision,paint=win.getComputedStyle(dialog),value=paint.getPropertyValue('--partner-ai-dialog-motion-duration').trim(),time=/^(\d*\.?\d+)(ms|s)$/.exec(value);
    const base=time?Number(time[1])*(time[2]==='s'?1000:1):200,easing=paint.getPropertyValue('--partner-ai-dialog-motion-easing').trim()||'cubic-bezier(0.2, 0, 0, 1)';
    const distance=Math.max(Math.abs(to.opacity-from.opacity),Math.abs(to.x-from.x)),duration=media.matches?0:base*distance;
    dialog.style.opacity=String(from.opacity);dialog.style.setProperty('--partner-global-mask-opacity',String(from.mask));if(options.drawer)dialog.style.transform=`translateX(${from.x*100}%)`;
    if(duration<1){complete();return;}
    const timing={duration,easing,fill:'both' as const};
    animations=[dialog.animate([{opacity:from.opacity,...(options.drawer?{transform:`translateX(${from.x*100}%)`}:{})},{opacity:to.opacity,...(options.drawer?{transform:`translateX(${to.x*100}%)`}:{})}],timing)];
    if(options.nativeBackdrop) {
      let pseudo:Animation|undefined;
      try {pseudo=dialog.animate([{opacity:from.mask},{opacity:to.mask}],{...timing,pseudoElement:'::backdrop'});if((pseudo.effect as KeyframeEffect).pseudoElement!=='::backdrop')throw new Error('No pseudo-element effect');animations.push(pseudo);}
      catch {pseudo?.cancel();const update=()=>{if(generation!==revision)return;const alpha=Number(win.getComputedStyle(dialog).opacity),progress=Math.max(0,Math.min(1,(alpha-from.opacity)/(to.opacity-from.opacity||1)));dialog.style.setProperty('--partner-global-mask-opacity',String(from.mask+(to.mask-from.mask)*progress));frame=win.requestAnimationFrame(update);};update();}
    }
    void Promise.all(animations.map(animation=>animation.finished)).then(()=>{if(generation===revision)complete();},()=>{/* Superseded entry/exit owns the next frame. */});
  }
  dialog.style.opacity=String(media.matches?1:start.opacity);dialog.style.setProperty('--partner-global-mask-opacity',String(media.matches?1:start.mask));if(options.drawer)dialog.style.transform=media.matches?'none':`translateX(${start.x*100}%)`;
  surface.dataset.dialogMotion='entering';media.addEventListener('change',preference);
  return {
    enter(){if(disposed)return;adoptPortals();animate(media.matches?{opacity:1,mask:1,x:0}:start,{opacity:1,mask:1,x:0},settle);},
    leave(removeNode:()=>void){remove=removeNode;const from=position();dialog.inert=true;dialog.setAttribute('aria-hidden','true');surface.dataset.dialogMotion='leaving';retirement={resume:()=>{const current=position();finish(true);return current;}};const pending=retired.get(doc)??new Map<string,Retiring>();pending.set(key,retirement);retired.set(doc,pending);animate(from,{opacity:0,mask:0,x:options.drawer?1:0},()=>finish());},
  };
}
