/** REQ-022 v0.5: regional Drawer motion matches the existing Workbench Drawer
 * (200ms / cubic-bezier(.2,0,0,1), host opacity + right panel translation).
 * WAAPI starts only after native show(), and retains actual DOM until leave ends.
 * No Robot/vendor DOM or source dependency. Interrupted reopen continues at the
 * painted position; the retiring dialog is inert, its mask shields pointers, and no DOM is cloned. */
type Position = { fraction: number; opacity: number };
type RetiringDrawer = { resume: () => Position };
const retiring = new WeakMap<HTMLElement, Map<string, RetiringDrawer>>();

export function createRegionDrawerMotion(surface: HTMLElement, dialog: HTMLDialogElement, container: HTMLElement, key: string, release: (superseded: boolean) => void) {
  const view = dialog.ownerDocument.defaultView!;
  const media = view.matchMedia('(prefers-reduced-motion: reduce)');
  let animations: Animation[] = [], revision = 0, released = false;
  let remove: (() => void) | undefined;
  let retirement: RetiringDrawer | undefined;
  const old = retiring.get(container)?.get(key);
  const start = old?.resume() ?? { fraction: 1, opacity: 0 };
  function position(): Position {
    const matrix = view.getComputedStyle(dialog).transform;
    const offset = matrix === 'none' ? 0 : new view.DOMMatrixReadOnly(matrix).m41;
    return { fraction: Math.max(0, Math.min(1, offset / (dialog.offsetWidth || 1))), opacity: Number(view.getComputedStyle(surface).opacity) };
  }
  function cancel() { revision++; for (const animation of animations) animation.cancel(); animations = []; }
  function finish(superseded = false) {
    if (released) return;
    released = true; cancel(); media.removeEventListener('change', motionPreference);
    if (retiring.get(container)?.get(key) === retirement) retiring.get(container)?.delete(key);
    dialog.close(); remove?.(); release(superseded);
  }
  function motionPreference() {
    if (!media.matches) return;
    cancel();
    if (remove) finish();
    else { dialog.style.transform = 'translateX(0)'; surface.style.opacity = '1'; surface.dataset.dialogMotion = 'open'; }
  }
  function animate(from: Position, to: Position, complete: () => void) {
    cancel();
    const generation = revision, paint = view.getComputedStyle(surface);
    const value = paint.getPropertyValue('--partner-ai-drawer-motion-duration').trim();
    const time = /^(\d*\.?\d+)(ms|s)$/.exec(value);
    const base = time ? Number(time[1]) * (time[2] === 's' ? 1000 : 1) : 200;
    const easing = paint.getPropertyValue('--partner-ai-drawer-motion-easing').trim() || 'cubic-bezier(0.2, 0, 0, 1)';
    const duration = media.matches ? 0 : base * Math.abs(to.fraction - from.fraction);
    dialog.style.transform = `translateX(${from.fraction * 100}%)`; surface.style.opacity = String(from.opacity);
    if (duration < 1) { complete(); return; }
    const timing = { duration, easing, fill: 'both' as const };
    animations = [dialog.animate([{ transform: `translateX(${from.fraction * 100}%)` }, { transform: `translateX(${to.fraction * 100}%)` }], timing), surface.animate([{ opacity: from.opacity }, { opacity: to.opacity }], timing)];
    void Promise.all(animations.map(animation => animation.finished)).then(() => { if (generation === revision) complete(); }, () => { /* Cancellation belongs to the next entry/leave or reduced-motion state. */ });
  }
  // Set the offscreen first frame BEFORE show(). No display:none -> final-paint jump.
  dialog.style.transform = `translateX(${media.matches ? 0 : start.fraction * 100}%)`;
  surface.style.opacity = String(media.matches ? 1 : start.opacity);
  surface.dataset.dialogMotion = 'entering';
  media.addEventListener('change', motionPreference);
  return {
    enter() { if (released) return; animate(media.matches ? { fraction:0, opacity:1 } : start, { fraction:0, opacity:1 }, () => { dialog.style.transform = 'translateX(0)'; surface.style.opacity = '1'; cancel(); surface.dataset.dialogMotion = 'open'; }); },
    leave(removeNode: () => void) {
      remove = removeNode;
      const from = position();
      // Keep the retiring mask hit-testable so clicks cannot reach an overlapping
      // floating AI. Only the old dialog/controls become inert during this leave.
      dialog.inert = true; surface.inert = false; surface.setAttribute('aria-hidden', 'true'); surface.dataset.dialogMotion = 'leaving';
      retirement = { resume: () => { const current = position(); finish(true); return current; } };
      const pending = retiring.get(container) ?? new Map<string, RetiringDrawer>();
      pending.set(key, retirement); retiring.set(container, pending);
      animate(from, { fraction:1, opacity:0 }, () => finish());
    },
  };
}
