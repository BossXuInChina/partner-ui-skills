<script setup lang="ts">
import { computed, inject, nextTick, onBeforeUnmount, onMounted, ref, setTransitionHooks, type Directive, type TransitionHooks } from 'vue';
import { createRegionDrawerMotion } from './dialogMotion';
import { createGlobalDialogMotion } from './globalDialogMotion';
import { businessOverlayKey } from '../../host/businessOverlay';
import type { BusinessDialogScope } from '../../host/businessAction';
const props = defineProps<{ titleId: string; drawer?: boolean; scope?: BusinessDialogScope; theme?: 'workbench' | 'aurora' }>();
const emit = defineEmits<{ close: [] }>();
const context = inject(businessOverlayKey, undefined);
// REQ-022: opt-in host uses native non-modal show plus regional backdrop/inert.
// Explicit global confirmations keep native top-layer semantics. No Robot private API.
const regional = computed(() => props.scope !== 'global' && !!context);
const identity = Symbol('business-dialog');
const active = computed(() => !regional.value || context?.stack.value.at(-1) === identity);
const level = computed(() => context?.stack.value.indexOf(identity) ?? 0);
const element = ref<HTMLDialogElement>();
const surface = ref<HTMLElement>();
let motion: ReturnType<typeof createRegionDrawerMotion> | ReturnType<typeof createGlobalDialogMotion> | undefined;
let cleaned = false;
let paintedSurface: HTMLElement | undefined;
function release(superseded = false) {
  if (cleaned) return;
  cleaned = true;
  if (context) context.stack.value = context.stack.value.filter(item => item !== identity);
  void nextTick(() => {
    if (superseded || !opener?.isConnected || opener.closest('[inert]')) return;
    // A newer regional dialog owns focus; nested closes may return to their lower dialog.
    if (context?.stack.value.length && !opener.closest('.partner-region-dialog')) return;
    const focus = opener.ownerDocument.activeElement;
    // Do not steal focus back if the user moved to navigation/AI during the exit.
    if (motion && focus && !['BODY', 'HTML'].includes(focus.tagName) && focus !== opener && !paintedSurface?.contains(focus)) return;
    opener.focus({ preventScroll: true });
  });
}
// The caller's v-if destroys this component before an internal <Transition> can
// leave. Vue 3.5's exported renderer transition hook retains this native portal
// surface until WAAPI completes, including saves/programmatic close. Keep this
// narrow adapter checked on Vue upgrades; no private Robot DOM or consumer rewrite.
const vDialogExit: Directive<HTMLElement> = {
  beforeUnmount(_surface, _binding, vnode) {
    if (!motion) return;
    const hooks: TransitionHooks = { mode: undefined, persisted: false, beforeEnter() {}, enter() {}, leave(_node, remove) { motion!.leave(remove); }, clone() { return hooks; } };
    setTransitionHooks(vnode, hooks);
  },
};
const origin = ref<HTMLElement>();
const tokens = ref<Record<string, string>>({});
let opener: HTMLElement | null = null;
onMounted(async () => {
  if (props.scope === 'region' && !context) throw new Error('UiDialog scope="region" requires BusinessOverlayHost.');
  opener = document.activeElement as HTMLElement;
  if (origin.value) {
    const paint = getComputedStyle(origin.value), values: Record<string, string> = {};
    // Preserve consumer semantic overrides across the region's body portal.
    for (let index = 0; index < paint.length; index++) {
      const token = paint[index]!;
      if (token.startsWith('--partner-ai-')) values[token] = paint.getPropertyValue(token);
    }
    // Preserve the origin's computed host family across regional/body portals;
    // only family crosses this boundary, never host font size or line height.
    const family = paint.getPropertyValue('--partner-ai-font-family').trim();
    values['--partner-ai-font-family'] = family && family !== 'inherit' ? family : paint.fontFamily;
    tokens.value = values;
  }
  paintedSurface = surface.value;
  if (regional.value && props.drawer && surface.value && context?.target.value) motion = createRegionDrawerMotion(surface.value, element.value!, context.target.value, props.titleId, release);
  if (!regional.value && surface.value && element.value) motion = createGlobalDialogMotion(surface.value, element.value, props.titleId, release, {nativeBackdrop:true,drawer:props.drawer});
  if (regional.value) { context!.stack.value = [...context!.stack.value, identity]; element.value?.show(); }
  else element.value?.showModal();
  await nextTick(); motion?.enter(); element.value?.querySelector<HTMLElement>('[data-initial-focus]')?.focus({ preventScroll: true });
});
onBeforeUnmount(() => {
  if (motion) return; // The native exit hook closes/releases after the real leave.
  element.value?.close(); release();
});
function trap(event: KeyboardEvent) {
  if (!active.value) return;
  if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); emit('close'); return; }
  if (event.key !== 'Tab') return;
  const focusable = [...(element.value?.querySelectorAll<HTMLElement>('button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea:not(:disabled),a[href],[tabindex="0"]') ?? [])].filter(item => item.getClientRects().length);
  const first = focusable[0]; const last = focusable.at(-1);
  if (!first) { event.preventDefault(); element.value?.focus(); }
  else if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
  else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
}
function backdrop(event: MouseEvent) {
  if (!active.value || event.target !== element.value) return;
  const bounds = element.value.getBoundingClientRect();
  if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) emit('close');
}
</script>
<template>
  <span ref="origin" hidden />
  <Teleport :to="regional ? context?.target.value ?? 'body' : 'body'">
    <div ref="surface" v-dialog-exit class="partner-ai partner-dialog-scope" :class="{ 'partner-region-dialog': regional }" :data-ai-theme="theme ?? 'workbench'" :data-tr-theme="theme ?? 'workbench'" :style="{ ...tokens, ...(regional ? { zIndex: level } : {}) }" :inert="regional && !active" @click.self="active && emit('close')">
      <dialog ref="element" tabindex="-1" :class="['ui-dialog', { 'ui-dialog--drawer': drawer, 'ui-dialog--region': regional }]" :aria-modal="!regional" :aria-labelledby="titleId" @cancel.prevent.stop="emit('close')" @click="backdrop" @keydown="trap"><slot /></dialog>
    </div>
  </Teleport>
</template>
<style>
.partner-dialog-scope:not(.partner-region-dialog) { display:contents; }
/* Native backdrop stays in top layer; its opacity shares the panel lifecycle. */
.partner-dialog-scope .ui-dialog::backdrop { opacity:var(--partner-global-mask-opacity,1); }
.partner-ai.partner-region-dialog { position:absolute; inset:0; display:flex; align-items:center; justify-content:center; pointer-events:auto; background:var(--partner-ai-dialog-scrim); }
.partner-region-dialog[inert] { pointer-events:none; }
.partner-region-dialog .ui-dialog--region { position:relative; margin:auto; width:var(--partner-ai-dialog-width); max-width:calc(100% - var(--partner-ai-dialog-viewport-gutter)); max-height:calc(100% - var(--partner-ai-dialog-viewport-gutter)); }
.partner-region-dialog .ui-dialog--region.ui-dialog--drawer { margin:0 0 0 auto; width:var(--partner-ai-drawer-width); max-width:100%; height:100%; max-height:100%; }
</style>
