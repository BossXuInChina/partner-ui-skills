<script lang="ts">
export type { WelcomeBusinessEntry } from '../composer/composerTypes';
</script>
<script setup lang="ts">
import assistantAvatar from '../../assets/assistantAvatar';
import { vAiTooltip } from '../foundation/aiTooltip';
import { createVNode, h, type Directive } from 'vue';
import { TrWelcome, TrPrompt } from '@opentiny/tiny-robot';
import { aiIconVNode } from '../foundation/aiIcons';
import type { WelcomeBusinessEntry } from '../composer/composerTypes';
import '../foundation/aiTokens.css';
const props = withDefaults(defineProps<{ avatarSrc?: string; fullscreen?: boolean; entries?: WelcomeBusinessEntry[] }>(), { avatarSrc: assistantAvatar, fullscreen: false, entries: () => [] });
const emit = defineEmits<{ select: [entry: WelcomeBusinessEntry] }>();
// Welcome has an icon component API but no title slot/tag API in 0.5.1. Keep level-2
// heading semantics with one DOM attribute adapter; recheck this selector on upgrades.
// Its public prop requires a VNode. Create a fresh one per render: reusing a cached
// VNode in its dynamic component corrupts following siblings when entries update.
const welcomeIcon = () => props.avatarSrc
  ? h('img', { src: props.avatarSrc, alt: 'AI 助手', class: 'chat-welcome-avatar' })
  : h('span', { class: 'chat-welcome-avatar chat-welcome-avatar--fallback', 'aria-hidden': 'true' }, [aiIconVNode('assistant.fallback')]);
const vWelcomeHeading: Directive<HTMLElement> = { mounted(el) { el.querySelector('.tr-welcome__title')?.setAttribute('aria-level', '2'); } };
function select(entry: WelcomeBusinessEntry) { if (!entry.disabled) emit('select', entry); }
</script>
<template>
  <section v-welcome-heading class="chat-welcome" :class="{ 'is-fullscreen': fullscreen }" aria-label="企业AI助手欢迎区">
    <div class="chat-welcome-content">
      <TrWelcome class="chat-welcome-intro" title="企业AI助手" description="我是您的智能客服，欢迎向我提问！" :icon="welcomeIcon()" align="center" />
      <div class="chat-welcome-entries" :class="{ 'is-fullscreen': fullscreen, 'is-fullscreen-grid': fullscreen && entries.length === 3 }">
        <!-- Direct public TrPrompt keeps per-entry ARIA/keyboard attrs declarative. TrPrompts
             0.5.1 has no item slot. Its div root needs button semantics + disabled guard here. -->
        <TrPrompt v-for="entry in entries" :id="entry.id" :key="entry.id" v-ai-tooltip="{ content: `${entry.title}：${entry.description}`, overflowOnly: true, overflowSelector: '.tr-prompt__content-title,.tr-prompt__content-description' }" class="chat-welcome-entry" :label="entry.title" :description="entry.description" :icon="entry.icon ? createVNode(entry.icon, { 'aria-hidden': 'true' }, null, 0, null, true) : aiIconVNode('welcome.entry')" :disabled="entry.disabled" role="button" :tabindex="entry.disabled ? -1 : 0" :aria-disabled="!!entry.disabled" :aria-label="`${entry.title} ${entry.description}`" @click="select(entry)" @keydown.enter.prevent="select(entry)" @keydown.space.prevent @keyup.space.prevent="select(entry)" />
      </div>
    </div>
  </section>
</template>
<style scoped>
/* REQ-003 welcome: the main region starts below the 24px handle + 48px header. Subtract
   those public host-size variables from 122px so the avatar/title origin stays panel-relative.
   Integration must mount this scrolling region directly in main, without chat-scroll padding.
   Product supplies three entries; a title and description each occupy one line with tooltip
   fallback for long copy, keeping 82px cards intact. Icon/text gap12 and line heights40/24
   are conservative candidates where the request did not specify a value. The screenshot's
   red-box identity/greeting group is centered horizontally in the AI panel; cards stay aligned
   to their own panel-relative inset. No business calls. */
.chat-welcome { container:partner-ai-welcome / inline-size; flex:1; min-height:0; min-width:0; height:100%; overflow-y:auto; overflow-x:hidden; overscroll-behavior:contain; scrollbar-width:thin; box-sizing:border-box; padding:max(0px,calc(var(--partner-ai-welcome-origin) - var(--partner-chat-handle-height,var(--partner-ai-handle-area-height)) - var(--partner-chat-toolbar-height,var(--partner-ai-header-height)))) var(--partner-ai-layout-safe-inset,var(--partner-ai-safe-inset,var(--partner-ai-safe-inset-compact))) var(--partner-ai-welcome-padding-block-end); }
/* REQ-015: include an occupying native scrollbar in the unchanged right safe inset;
   measured gutter comes from ChatPanel, keeping388/400px card geometry on macOS. */
.chat-welcome { padding-right:max(0px,calc(var(--partner-ai-layout-safe-inset,var(--partner-ai-safe-inset,var(--partner-ai-safe-inset-compact))) - var(--partner-ai-native-scrollbar-gutter,0px))); }
/* Center the whole fullscreen group in the actual main slot between toolbar and
   Sender. Auto margins yield to0 when content is taller than the available space,
   keeping the first heading reachable and the existing native scrollport intact.
   Owned wrapper only: no Robot DOM adaptation or sidebar/floating origin change. */
.chat-welcome.is-fullscreen { display:flex; flex-direction:column; padding-block:var(--partner-ai-welcome-padding-block-end); }
.chat-welcome.is-fullscreen > .chat-welcome-content { flex:none; width:100%; margin-block:auto; }
/* Public Welcome/Prompt data and icon APIs own content. These scoped 0.5.1 DOM
   overrides preserve REQ-003 geometry/ellipsis; recheck structure on upgrades. */
.chat-welcome .chat-welcome-intro { padding:0; }
.chat-welcome-intro :deep(.tr-welcome__icon) { margin:0; display:flex; flex:none; }
/* Center the intrinsic group with its fractional font width intact; do not globally round metrics. */
.chat-welcome-intro :deep(.tr-welcome__title-wrapper) { display:flex; align-items:center; position:relative; left:50%; transform:translateX(-50%); width:max-content; max-width:100%; gap:var(--partner-ai-gap-lg); min-width:0; }
.chat-welcome-intro :deep(.chat-welcome-avatar) { display:block; width:var(--partner-ai-welcome-avatar-size); height:var(--partner-ai-welcome-avatar-size); flex:none; object-fit:contain; }
.chat-welcome-intro :deep(.chat-welcome-avatar--fallback) { display:grid; place-items:center; border-radius:var(--partner-ai-welcome-avatar-radius); color:var(--partner-ai-on-accent); background:var(--partner-ai-accent); }
.chat-welcome-intro :deep(.chat-welcome-avatar--fallback svg) { width:var(--partner-ai-icon-size); height:var(--partner-ai-icon-size); }
.chat-welcome-intro :deep(.tr-welcome__title) { margin:0; min-width:0; font-size:var(--partner-ai-welcome-title-size); line-height:var(--partner-ai-welcome-title-line); font-weight:var(--partner-ai-heading-weight); color:var(--partner-ai-text); }
.chat-welcome-intro :deep(.tr-welcome__description) { margin:var(--partner-ai-gap-md) 0 0; text-align:center; font-size:var(--partner-ai-welcome-body-size); line-height:var(--partner-ai-welcome-body-line); font-weight:var(--partner-ai-body-weight); color:var(--partner-ai-text); }
/* REQ-003 v1.9: size against this welcome region's actual safe content, so420px
   sidebar/floating fills388px and480px centers400px. TrPrompt keeps its public API
   and existing height/radius/padding adapters; only the containing grid width changes. */
.chat-welcome-entries { display:grid; width:100%; max-width:var(--partner-ai-welcome-card-max-width); gap:var(--partner-ai-welcome-card-gap); margin-top:var(--partner-ai-welcome-entry-gap); margin-inline:auto; }
/* REQ-003 v1.7: official Prompt radius variable keeps homepage16px separate from
   compact follow-ups8px. Existing scoped geometry uses0.5.1 DOM; recheck on upgrades. */
.chat-welcome .chat-welcome-entry { --tr-prompt-border-radius:var(--partner-ai-welcome-card-radius); position:relative; display:flex; align-items:center; gap:var(--partner-ai-gap-lg); width:100%; height:var(--partner-ai-welcome-card-height); padding:var(--partner-ai-welcome-card-padding-block) var(--partner-ai-welcome-card-padding-inline); box-sizing:border-box; min-width:0; border:0; border-radius:var(--tr-prompt-border-radius); background:var(--partner-ai-panel-bg); box-shadow:var(--partner-ai-welcome-card-shadow); text-align:left; font:inherit; cursor:pointer; }
/* Home Prompt hover: reuse the AI multicolor paint in a 1px inset ring. The
   owned pseudo-element preserves Robot's slot geometry and native hit target. */
.chat-welcome-entry::after { content:''; position:absolute; inset:0; box-sizing:border-box; padding:1px; border-radius:inherit; background:var(--partner-ai-composer-stroke-image); pointer-events:none; -webkit-mask:linear-gradient(#fff 0 0) content-box,linear-gradient(#fff 0 0); mask:linear-gradient(#fff 0 0) content-box,linear-gradient(#fff 0 0); -webkit-mask-composite:xor; mask-composite:exclude; opacity:0; transition:opacity var(--partner-ai-control-motion-duration) var(--partner-ai-control-motion-easing); }
.chat-welcome-entry:hover:not(.disabled):not([aria-disabled="true"])::after { opacity:1; }
.chat-welcome-entry:hover:not(.disabled):not([aria-disabled="true"]) { background:var(--partner-ai-panel-bg); box-shadow:var(--partner-ai-welcome-card-hover-shadow); }
.chat-welcome-entry:focus-visible { outline:var(--partner-ai-focus-width) solid var(--partner-ai-focus); outline-offset:var(--partner-ai-focus-inset); }
.chat-welcome-entry.disabled { opacity:var(--partner-ai-disabled-opacity); cursor:not-allowed; }
@media(prefers-reduced-motion:reduce) { .chat-welcome-entry::after { transition:none; } }
.chat-welcome-entry :deep(> svg) { width:var(--partner-ai-icon-size); height:var(--partner-ai-icon-size); flex:none; }
.chat-welcome-entry :deep(.tr-prompt__content) { width:100%; display:flex; flex-direction:column; align-items:stretch; gap:var(--partner-ai-gap-sm); min-width:0; }
.chat-welcome-entry :deep(.tr-prompt__content-title) { font-size:var(--partner-ai-welcome-card-title-size); line-height:var(--partner-ai-welcome-card-title-line); font-weight:var(--partner-ai-heading-weight); color:var(--partner-ai-text); }
.chat-welcome-entry :deep(.tr-prompt__content-description) { font-size:var(--partner-ai-body-size); line-height:var(--partner-ai-body-line); font-weight:var(--partner-ai-body-weight); color:var(--partner-ai-muted); }
.chat-welcome-entry :deep(.tr-prompt__content-title),.chat-welcome-entry :deep(.tr-prompt__content-description) { display:block; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
/* Fullscreen cards retain82px for normal copy; long titles/descriptions grow
   naturally in both the row and stacked fallback. These existing0.5.1 Prompt
   DOM hooks stay local and require an upgrade review. */
.chat-welcome-entries.is-fullscreen .chat-welcome-entry { height:auto; min-height:var(--partner-ai-welcome-card-height); }
.chat-welcome-entries.is-fullscreen .chat-welcome-entry :deep(.tr-prompt__content-title),
.chat-welcome-entries.is-fullscreen .chat-welcome-entry :deep(.tr-prompt__content-description) { white-space:normal; overflow:visible; overflow-wrap:anywhere; text-overflow:clip; }
/* Actual safe content, independent of the800px reply/Sender column: only fit
   3 × 336px + 2 × 16px at1040px. Narrower containers keep the original stack. */
@container partner-ai-welcome (min-width:1040px) {
  .chat-welcome-entries.is-fullscreen-grid { max-width:var(--partner-ai-fullscreen-welcome-max-width,1040px); grid-template-columns:repeat(3,minmax(336px,1fr)); }
}
</style>
