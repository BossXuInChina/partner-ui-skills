<script setup lang="ts">
import { computed, inject, nextTick, onBeforeUnmount, watch, type Component, type VNode } from 'vue';
import type { BubbleContentRendererProps } from '@opentiny/tiny-robot';
import { answerDisplayKey } from './answerDisplay';

defineOptions({inheritAttrs:false});
const props=defineProps<BubbleContentRendererProps & {renderer:Component}>();
const display=inject(answerDisplayKey,undefined);
const ready=computed(()=>!display || display.ready(props.contentIndex));
const signature=computed(()=>JSON.stringify(props.message.content?.[props.contentIndex]));
let animations:Animation[]=[], frame=0, revision=0, entered=false;
// Whole business blocks are retained only after their root has entered; later
// queued blocks must not appear for the first time when stopped history restores.
const unregister=display?.register(props.contentIndex,()=>entered&&Array.isArray(props.message.content)?props.message.content[props.contentIndex]:undefined);
onBeforeUnmount(()=>unregister?.());
function cancel(){revision++;cancelAnimationFrame(frame);animations.forEach(animation=>animation.cancel());animations=[];}
async function acknowledge(){
  const token=revision,value=signature.value;
  await nextTick();
  if(token!==revision || display?.cancelled.value)return;
  frame=requestAnimationFrame(()=>{frame=requestAnimationFrame(()=>{
    if(token===revision && value===signature.value && !display?.cancelled.value)display?.acknowledge(props.contentIndex,value);
  });});
}
function mount(vnode:VNode){
  if(entered || !ready.value)return;
  entered=true;
  // Animate the business root without a wrapper that changes margins, clipping
  // or public renderer events. Recheck root forwarding on dependency upgrades.
  if(display?.live.value && !display.cancelled.value && !window.matchMedia('(prefers-reduced-motion: reduce)').matches){
    // Vue dev templates may have a comment + element Fragment (e.g. Summary).
    // Bound traversal to that VNode's own anchor, never the next content item.
    // This is the only Vue root adapter; recheck subTree/el/anchor on upgrades.
    let root=vnode;
    while(root.component)root=root.component.subTree;
    const elements:HTMLElement[]=[];
    if(root.el instanceof HTMLElement)elements.push(root.el);
    else if(root.anchor)for(let node=root.el?.nextSibling;node && node!==root.anchor;node=node.nextSibling){if(node instanceof HTMLElement)elements.push(node);}
    const token=revision;
    animations=elements.map(element=>{
      const style=getComputedStyle(element),duration=style.getPropertyValue('--partner-ai-control-motion-duration').trim(),easing=style.getPropertyValue('--partner-ai-control-motion-easing').trim();
      const milliseconds=parseFloat(duration)*(duration.endsWith('ms')?1:1000);
      return element.animate([{opacity:0},{opacity:1}],{duration:milliseconds,easing});
    });
    Promise.all(animations.map(animation=>animation.finished)).then(()=>{if(token!==revision)return;animations=[];display?.changed();void acknowledge();},()=>{});
  }else void acknowledge();
  display?.changed();
}
watch(signature,()=>{if(entered && !animations.length)void acknowledge();});
watch(()=>display?.cancelled.value,stopped=>{if(stopped)cancel();});
watch(()=>display?.epoch.value,()=>{cancel();entered=false;});
onBeforeUnmount(cancel);
</script>

<template>
  <component :is="renderer" v-if="ready" :key="display?.epoch.value" v-bind="$attrs" :message="message" :content-index="contentIndex" @vue:mounted="mount" />
</template>
