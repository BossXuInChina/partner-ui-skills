<script setup lang="ts">
import { AiIcon } from '../foundation/aiIcons';
import type { AiAlertProps } from './aiAlert';

// REQ-029: locked TinyRobot 0.5.1 exports no Alert. This native content adapter
// uses no dependency DOM; recheck a public inline Alert API on upgrade.
withDefaults(defineProps<AiAlertProps>(), { type: 'neutral', description: '' });
defineSlots<{ icon?: () => unknown }>();
</script>

<template>
  <!-- One implicit live region owns message + reason; icons never announce separately.
       A host that already announces this content can override role/aria-live natively. -->
  <div class="ai-alert" :class="`ai-alert--${type}`" :role="type === 'error' ? 'alert' : 'status'" aria-atomic="true">
    <span v-if="$slots.icon || type === 'error'" class="ai-alert__icon" aria-hidden="true">
      <slot name="icon"><AiIcon name="alert.error" /></slot>
    </span>
    <div class="ai-alert__content">
      <div class="ai-alert__message">{{ message }}</div>
      <div v-if="description" class="ai-alert__description">{{ description }}</div>
    </div>
  </div>
</template>

<style scoped>
/* Consumer-owned classes only: tokens, public icon slot and inherited scope.
   No background/border/padding: the surrounding TinyRobot Box owns the surface. */
.ai-alert{display:flex;align-items:flex-start;gap:var(--partner-ai-gap-md);min-width:0;margin:0;padding:0;border:0;background:transparent;box-shadow:none;color:var(--partner-ai-muted);font-family:var(--partner-ai-font-family,inherit);font-size:var(--partner-ai-body-size);font-weight:var(--partner-ai-body-weight);line-height:var(--partner-ai-body-line);overflow-wrap:anywhere}
.ai-alert--error{color:var(--partner-ai-error)}
.ai-alert__icon{display:flex;align-items:center;justify-content:center;flex:none;width:var(--partner-ai-small-icon-size);height:var(--partner-ai-body-line)}
.ai-alert__icon :deep(svg){display:block;width:var(--partner-ai-small-icon-size);height:var(--partner-ai-small-icon-size)}
.ai-alert__content{min-width:0}
.ai-alert__description{margin-top:var(--partner-ai-gap-sm);color:var(--partner-ai-muted)}
</style>
