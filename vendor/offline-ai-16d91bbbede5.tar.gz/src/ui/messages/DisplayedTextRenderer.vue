<script setup lang="ts">
import { computed, inject, nextTick, onBeforeUnmount, ref, watch, type Component } from 'vue';
import { BubbleRenderers, type BubbleContentRendererProps } from '@opentiny/tiny-robot';
import { answerDisplayKey } from './answerDisplay';

const props = defineProps<BubbleContentRendererProps & { renderer?: Component }>();
const display = inject(answerDisplayKey, undefined);
const target = computed(() => typeof props.message.content === 'string' ? props.message.content : String(props.message.content?.[props.contentIndex]?.text ?? ''));
const visible = ref(display?.live.value ? '' : target.value);
// Capture Markdown source, not rendered innerText, so formatting and exact visible
// prefixes survive history restoration without exposing text still in the queue.
const unregister=display?.register(props.contentIndex,()=>{
  if(!ready.value || !visible.value)return;
  const source=Array.isArray(props.message.content)?props.message.content[props.contentIndex]:undefined;
  return {...source,type:'text',text:visible.value};
});
onBeforeUnmount(()=>unregister?.());
const ready = computed(() => !display || display.ready(props.contentIndex));
const rendered = computed(() => ({...props.message,content:typeof props.message.content === 'string' ? visible.value : props.message.content?.map((part,index) => index === props.contentIndex ? {...part,text:visible.value} : part)}));
let frame=0, revision=0, lastTime=0, credit=0;
const reduced = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;
function cancel() { revision++; cancelAnimationFrame(frame); frame=0; lastTime=0; credit=0; }
function queueStep(){const token=revision;frame=requestAnimationFrame(now=>{if(token===revision)step(now);});}
async function acknowledge() {
  const token=revision, text=visible.value;
  await nextTick();
  if(token!==revision || text!==target.value || !ready.value || display?.cancelled.value)return;
  frame=requestAnimationFrame(()=>{frame=requestAnimationFrame(()=>{
    frame=0;
    if(token===revision && text===target.value && !display?.cancelled.value)display?.acknowledge(props.contentIndex,text);
  });});
}
function step(now:number) {
  frame=0;
  if(display?.cancelled.value || !ready.value)return;
  // Robot0.5.1 has no display queue. Append real source prefixes to its public
  // Markdown renderer even when transport returns a whole paragraph at once.
  credit += lastTime ? Math.min(now-lastTime,100)*0.09 : 1;
  lastTime=now;
  const count=Math.floor(credit);
  if(count){
    credit-=count;
    visible.value+=Array.from(target.value.slice(visible.value.length)).slice(0,count).join('');
    display?.changed();
  }
  if(visible.value===target.value){lastTime=0;void acknowledge();}
  else queueStep();
}
function update() {
  cancel();
  if(!display?.live.value){visible.value=target.value;void acknowledge();return;}
  // A transport failure preserves its received partial snapshot immediately;
  // explicit user Stop instead freezes exactly the prefix already displayed.
  if(display.failed.value){visible.value=target.value;display.changed();return;}
  if(display.cancelled.value || !ready.value)return;
  if(!target.value.startsWith(visible.value))visible.value='';
  if(reduced()){visible.value=target.value;display.changed();void acknowledge();}
  else if(visible.value===target.value)void acknowledge();
  else queueStep();
}
watch(() => display?.epoch.value,()=>{cancel();visible.value=display?.live.value?'':target.value;update();},{flush:'sync'});
watch([target,ready,()=>display?.cancelled.value],update,{immediate:true,flush:'post'});
onBeforeUnmount(cancel);
</script>

<template>
  <component :is="renderer ?? BubbleRenderers.Markdown" v-if="ready && visible" :message="rendered" :content-index="contentIndex" />
</template>
