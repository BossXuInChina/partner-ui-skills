/** REQ-029: inline reply state, without action ownership or a second card shell. */
export type AiAlertType = 'error' | 'neutral';
export interface AiAlertProps {
  type?: AiAlertType;
  message: string;
  description?: string;
}
