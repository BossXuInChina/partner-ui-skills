import type { BubbleMessage, ChatMessageContentItem } from '@opentiny/tiny-robot';
import type { ComposerRequestContext } from '../composer/composerTypes';
// REQ-029: serializable failure belongs to the reply; recovering is transient UI
// state. Neither field is sent to the model (the engine allowlists role/content).
export type UIMessage<Part extends ChatMessageContentItem = ChatMessageContentItem> = BubbleMessage & { uiParts?: Part[]; /** New streams store the complete display sequence here; content retains transport text. */ uiPartsOrdered?: boolean; renderContent?: ChatMessageContentItem[]; reasoning_content?: string; thinkingStatus?: 'thinking' | 'completed' | 'interrupted'; requestContext?: ComposerRequestContext; replyError?: string; recovering?: boolean };
/** Owner-persisted snapshot when Stop freezes answer presentation after transport.
 * Parts contain JSON-cloned source prefixes and already visible blocks, never DOM/getters. */
export interface ChatDisplayStopSnapshot {
  messageId?: string;
  messageIndex: number;
  parts: ChatMessageContentItem[];
}
function isThinkingEnvelope(part: ChatMessageContentItem): part is ChatMessageContentItem & {type:'unsupported'; originalType:'thinking-content'; content:string; status:'thinking' | 'completed' | 'interrupted'} {
  const item = part as ChatMessageContentItem & {content?:unknown; status?:unknown};
  return part.type === 'unsupported' && part.originalType === 'thinking-content' && typeof item.content === 'string' && ['thinking','completed','interrupted'].includes(String(item.status));
}
export function hasChatOutput(message: UIMessage): boolean {
  return resolveChatContent(message).some(part => part.type === 'thinking-content' ? !!String(part.content??'').trim() : part.type !== 'text' || (typeof part.text === 'string' && !!part.text.trim()));
}
function isThinkingPart(part:ChatMessageContentItem) {
  return isThinkingEnvelope(part) || ['thinking-content','reasoning_content','reasoning','collapsible-text'].includes(part.type);
}
function thinkingStatus(message:UIMessage, saved?:ChatMessageContentItem):'thinking'|'completed'|'interrupted' {
  const completion=message.state?.completion;
  if (completion==='aborted'||completion==='error'||message.replyError) return 'interrupted';
  if (completion==='completed') return 'completed';
  const explicit=message.thinkingStatus??saved?.status;
  if (explicit==='thinking'||explicit==='completed'||explicit==='interrupted') return explicit;
  if (message.loading||message.recovering||message.state?.thinking===true) return 'thinking';
  return 'completed';
}
export function resolveChatContent(message: UIMessage): ChatMessageContentItem[] {
  const content = typeof message.content === 'string' ? [{ type: 'text', text: message.content }] : (message.content ?? []);
  // Normalize native Robot reasoning, prior demo envelopes and legacy persisted
  // collapsible-text once. No legacy renderer DOM or duplicated text survives.
  const allParts=message.uiPartsOrdered ? (message.uiParts??content) : [...content,...(message.uiParts??[])];
  const savedThinking=allParts.find(isThinkingPart);
  const legacyThinking=message.renderContent?.filter(isThinkingPart)??[];
  const source=savedThinking??legacyThinking[0];
  const nativeText=typeof message.reasoning_content==='string'?message.reasoning_content:undefined;
  const savedText=savedThinking?String(savedThinking.content??savedThinking.text??''):legacyThinking.map(part=>String(part.content??part.text??'')).join('');
  const reasoningText=nativeText?.trim()?nativeText:savedText;
  const status=thinkingStatus(message,source);
  const reasoning=reasoningText.trim() || (source&&status==='thinking') ? [{type:'thinking-content',content:reasoningText,status}] : [];
  const parts=[...reasoning,...allParts.filter(part=>!isThinkingPart(part))];
  if(message.uiPartsOrdered || Array.isArray(message.content))return parts;
  // Keep reasoning first, summaries next, and normal business/text order intact.
  return [
    ...parts.filter(part => part.type === 'thinking-content'),
    ...parts.filter(part => part.type === 'ai-summary'),
    ...parts.filter(part => part.type !== 'thinking-content' && part.type !== 'ai-summary'),
  ];
}
