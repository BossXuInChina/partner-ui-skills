<script setup lang="ts">
import { computed } from 'vue';
import type { BubbleContentRendererProps } from '@opentiny/tiny-robot';
import { resolveChatContent } from './chatContent';
const props = defineProps<BubbleContentRendererProps>();
const type = computed(() => { const part = resolveChatContent(props.message)[props.contentIndex]; return part?.type === 'unsupported' ? String(part.originalType) : part?.type ?? 'unknown'; });
</script>
<template><p class="unknown-message" role="status">无法展示消息类型「{{ type }}」。请尝试重新查询或联系消费方维护者。</p></template>
