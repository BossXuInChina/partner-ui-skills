<script setup lang="ts">
import { computed, onBeforeUnmount, ref, useId, watch } from 'vue';
// Pixso 5711:1143: Robot 0.5.1 Feedback only has action/source rows, no
// reason/textarea API. Keep a native form for keyboard/disabled semantics;
// no dependency DOM adaptation. Recheck a public feedback form on upgrades.
const props = withDefaults(defineProps<{ disabled?: boolean }>(), { disabled: false });
const emit = defineEmits<{ submit: [feedback: { reasons: string[]; detail: string }]; cancel: [] }>();
const reasons = ['信息不准确', '功能不好用', '描述不清楚', '响应慢', '其他'];
const selected = ref<string[]>([]), detail = ref('');
const textarea = ref<HTMLTextAreaElement>();
// WorkbenchInput's measured native gutter is part of its 12px right inset.
// Keep this textarea-only adaptation local; no form/search/vendor dependency.
let gutterObserver: ResizeObserver | undefined;
watch(textarea, element => {
  gutterObserver?.disconnect();
  if (!element) return;
  const measure = () => element.style.setProperty('--dislike-input-scrollbar-gutter', `${element.offsetWidth - element.clientWidth}px`);
  gutterObserver = new ResizeObserver(measure);gutterObserver.observe(element);measure();
}, { flush: 'post' });
onBeforeUnmount(() => gutterObserver?.disconnect());
const titleId = `dislike-title-${useId()}`, countId = `${titleId}-count`;
const canSubmit = computed(() => !props.disabled && (selected.value.length > 0 || detail.value.trim().length > 0));
function toggle(reason: string) {
  if (props.disabled) return;
  selected.value = selected.value.includes(reason) ? selected.value.filter(value => value !== reason) : [...selected.value, reason];
}
function submit() {
  if (canSubmit.value) emit('submit', { reasons: reasons.filter(reason => selected.value.includes(reason)), detail: detail.value.trim() });
}
</script>
<template>
  <form class="dislike-feedback-card" :aria-labelledby="titleId" @submit.prevent="submit" @keydown.esc.stop.prevent="!disabled && emit('cancel')">
    <p :id="titleId" class="dislike-feedback-card__title">很抱歉这次服务没让您满意！为了更好为您服务，您能选择最接近您感受的原因吗？</p>
    <div class="dislike-feedback-card__reasons" role="group" aria-label="反馈原因（可多选）">
      <button v-for="reason in reasons" :key="reason" class="dislike-feedback-card__reason" type="button" :aria-pressed="selected.includes(reason)" :disabled="disabled" @click="toggle(reason)">{{ reason }}</button>
    </div>
    <div class="dislike-feedback-card__input">
      <textarea ref="textarea" v-model="detail" rows="3" aria-label="补充反馈" :aria-describedby="countId" maxlength="200" placeholder="可以告诉我们更多关于您的使用细节" :disabled="disabled"></textarea>
      <span :id="countId" class="dislike-feedback-card__count">{{ detail.length }} / 200</span>
    </div>
    <div class="dislike-feedback-card__actions">
      <button class="dislike-feedback-card__submit" type="submit" :disabled="!canSubmit">提交</button>
    </div>
  </form>
</template>
<style scoped>
/* Pixso card/chips; multiline input styling follows the user-requested
   WorkbenchInput.vue + wb-input manifest (88px/4px radius/flow counter).
   Source stays read-only; these styles and gutter measurement are self-contained.
   Host width constrains the card; chips wrap without clipping. */
.dislike-feedback-card{box-sizing:border-box;display:flex;flex-direction:column;gap:var(--partner-ai-spacing-lg);width:var(--partner-ai-feedback-width);max-width:100%;min-width:0;margin:0;padding:var(--partner-ai-spacing-lg);border:0;border-radius:var(--partner-ai-radius-xl);background:var(--partner-ai-feedback-bg);box-shadow:var(--partner-ai-feedback-shadow);color:var(--partner-ai-feedback-text);font-family:inherit;font-weight:var(--partner-ai-body-weight);text-align:left}
/* Beat the chat container's generic paragraph bottom margin: gap alone must
   own the 16px separation in both the local example and the real BubbleList. */
.dislike-feedback-card>.dislike-feedback-card__title:first-child{max-width:var(--partner-ai-feedback-title-max-width);margin:0;font-size:var(--partner-ai-large-body-size);font-weight:var(--partner-ai-body-weight);line-height:var(--partner-ai-large-body-line);overflow-wrap:anywhere}
.dislike-feedback-card__reasons{display:flex;flex-wrap:wrap;gap:var(--partner-ai-spacing-sm);min-width:0}
.dislike-feedback-card button{box-sizing:border-box;flex:none;margin:0;cursor:pointer;font-family:inherit;font-weight:var(--partner-ai-body-weight)}
/* Pixso default and selected both use #777 at 5%; selection adds the stroke.
   Reserve its width transparently in the default state to avoid a layout jump. */
.dislike-feedback-card__reason{height:var(--partner-ai-feedback-reason-height);padding:var(--partner-ai-feedback-reason-padding);border:var(--partner-ai-border-width) solid transparent;border-radius:var(--partner-ai-radius-sm);background:var(--partner-ai-feedback-reason-bg);color:var(--partner-ai-feedback-text);font-size:var(--partner-ai-caption-size);line-height:var(--partner-ai-caption-line);white-space:nowrap}
.dislike-feedback-card__reason[aria-pressed=true]{border-color:var(--partner-ai-feedback-text);color:var(--partner-ai-feedback-selected-text)}
.dislike-feedback-card__input{position:relative;display:flex;flex-direction:column;align-items:stretch;box-sizing:border-box;width:100%;min-width:0;height:var(--partner-ai-feedback-input-height);min-height:var(--partner-ai-feedback-input-height);padding:var(--partner-ai-feedback-input-padding);border:var(--partner-ai-border-width) solid var(--partner-ai-feedback-border);border-radius:var(--partner-ai-radius-sm);background:var(--partner-ai-feedback-bg);color:var(--partner-ai-feedback-text);font-size:var(--partner-ai-body-size);font-weight:var(--partner-ai-body-weight);line-height:var(--partner-ai-body-line);letter-spacing:var(--partner-ai-body-letter-spacing);resize:vertical;overflow:hidden}
.dislike-feedback-card__input textarea{display:block;box-sizing:border-box;flex:1;min-width:0;min-height:0;width:100%;resize:none;overflow-y:auto;scrollbar-gutter:stable;margin:0;padding:0 calc(var(--partner-ai-spacing-md) - var(--dislike-input-scrollbar-gutter,0px)) 0 0;border:0;outline:0;background:transparent;color:inherit;font:inherit}
.dislike-feedback-card__input textarea::placeholder{color:var(--partner-ai-feedback-placeholder);opacity:1}
.dislike-feedback-card__count{flex:none;margin-right:var(--partner-ai-spacing-md);pointer-events:none;text-align:right;color:var(--partner-ai-color-neutral-500);font-size:var(--partner-ai-caption-size);font-weight:var(--partner-ai-body-weight);line-height:var(--partner-ai-feedback-count-line);letter-spacing:var(--partner-ai-body-letter-spacing)}
.dislike-feedback-card__actions{display:flex;justify-content:flex-end;gap:var(--partner-ai-spacing-lg)}
.dislike-feedback-card__actions button{width:var(--partner-ai-feedback-button-width);height:var(--partner-ai-control-size);padding:var(--partner-ai-spacing-xs) var(--partner-ai-spacing-md);border:var(--partner-ai-border-width) solid var(--partner-ai-feedback-border);border-radius:var(--partner-ai-radius-sm);background:var(--partner-ai-feedback-bg);color:var(--partner-ai-feedback-text);font-size:var(--partner-ai-body-size);line-height:var(--partner-ai-body-line)}
.dislike-feedback-card__actions .dislike-feedback-card__submit:enabled{border-color:var(--partner-ai-feedback-submit-bg);border-radius:var(--partner-ai-radius-md);background:var(--partner-ai-feedback-submit-bg);color:var(--partner-ai-color-white)}
/* Pixso's disabled secondary button specifies its own gray fill/text/border;
   reset the shared disabled opacity so these colors are not faded twice. */
.dislike-feedback-card__actions .dislike-feedback-card__submit:disabled{background:var(--partner-ai-feedback-disabled-bg);border-color:var(--partner-ai-feedback-border);color:var(--partner-ai-feedback-disabled-color);opacity:1}
.dislike-feedback-card button:disabled{cursor:default;color:var(--partner-ai-feedback-disabled-color)}
.dislike-feedback-card button:focus-visible{outline:var(--partner-ai-focus-width) solid var(--partner-ai-feedback-text);outline-offset:var(--partner-ai-focus-control-offset)}
.dislike-feedback-card__input:hover,.dislike-feedback-card__input:focus-within{border-color:var(--partner-ai-feedback-text)}
.dislike-feedback-card__input:has(textarea:disabled){resize:none;border-color:var(--partner-ai-feedback-border);background:transparent;color:var(--partner-ai-feedback-disabled-color)}
.dislike-feedback-card__input:has(textarea:disabled) textarea::placeholder,.dislike-feedback-card__input:has(textarea:disabled) .dislike-feedback-card__count{color:var(--partner-ai-feedback-disabled-color)}
/* Native scrollbar paint copied from Workbench's small wb-scrollbar. */
@supports selector(::-webkit-scrollbar){
  .dislike-feedback-card__input textarea{scrollbar-width:auto;scrollbar-color:auto}
  .dislike-feedback-card__input textarea::-webkit-scrollbar{width:var(--partner-ai-scrollbar-small-size);height:var(--partner-ai-scrollbar-small-size)}
  .dislike-feedback-card__input textarea::-webkit-scrollbar-track{background:transparent}
  .dislike-feedback-card__input textarea::-webkit-scrollbar-thumb{background-color:var(--partner-ai-color-neutral-200);border:var(--partner-ai-scrollbar-small-safe) solid transparent;background-clip:padding-box;border-radius:var(--partner-ai-scrollbar-radius)}
  .dislike-feedback-card__input textarea::-webkit-scrollbar-thumb:hover,.dislike-feedback-card__input textarea::-webkit-scrollbar-thumb:active{background-color:var(--partner-ai-color-neutral-400);border-width:var(--partner-ai-scrollbar-small-safe-hover)}
}
@supports not selector(::-webkit-scrollbar){
  .dislike-feedback-card__input textarea{scrollbar-width:thin;scrollbar-color:var(--partner-ai-color-neutral-200) transparent}
  .dislike-feedback-card__input textarea:hover{scrollbar-color:var(--partner-ai-color-neutral-400) transparent}
}
</style>
