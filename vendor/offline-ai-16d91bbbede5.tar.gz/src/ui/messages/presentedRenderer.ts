import { defineComponent, h, markRaw, type Component, type PropType } from 'vue';
import type { BubbleContentRendererProps } from '@opentiny/tiny-robot';
import DisplayedBlockRenderer from './DisplayedBlockRenderer.vue';
import DisplayedTextRenderer from './DisplayedTextRenderer.vue';

const wrappers=new Map<Component,Component<BubbleContentRendererProps>>();
/** Keep public matches, attributes and events while sequencing their paint. */
export function presentedRenderer(renderer:Component<BubbleContentRendererProps>){
  let wrapper=wrappers.get(renderer);
  if(!wrapper){
    wrapper=markRaw(defineComponent({
      inheritAttrs:false,
      props:{message:{type:Object as PropType<BubbleContentRendererProps['message']>,required:true},contentIndex:{type:Number,required:true}},
      setup(props,{attrs}){return()=>h((typeof props.message.content==='string' || props.message.content?.[props.contentIndex]?.type==='text')?DisplayedTextRenderer:DisplayedBlockRenderer,{...attrs,...props,renderer});},
    }));
    wrappers.set(renderer,wrapper);
  }
  return wrapper;
}
