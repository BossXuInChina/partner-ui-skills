export interface XiaolingOrbitOptions {
  /** Restart from the first frame at the end. Default true. */
  loop?: boolean;
  /** Playback rate. Default 1. */
  speed?: number;
  /** Start immediately. Default true. */
  autoplay?: boolean;
  /** Freeze on `posterFrame` when the user asks for reduced motion. Default true. */
  respectReducedMotion?: boolean;
  /** Accessible name. Empty means the SVG is decorative (aria-hidden). */
  label?: string;
  /** Static frame shown for reduced motion. Default 40. */
  posterFrame?: number;
  /** When looping, jump back to this time (seconds) instead of 0. Default 0. */
  loopStart?: number;
  onFrame?: ((time: number, frame: number) => void) | null;
  onEnd?: (() => void) | null;
}

export interface XiaolingOrbitController {
  play(): void;
  pause(): void;
  toggle(): void;
  seek(seconds: number): void;
  setSpeed(speed: number): void;
  setLoop(loop: boolean): void;
  setLoopStart(seconds: number): void;
  getTime(): number;
  getLoopStart(): number;
  isPlaying(): boolean;
  destroy(): void;
}

export function createXiaolingOrbit(
  container: HTMLElement,
  options?: XiaolingOrbitOptions,
): XiaolingOrbitController;
