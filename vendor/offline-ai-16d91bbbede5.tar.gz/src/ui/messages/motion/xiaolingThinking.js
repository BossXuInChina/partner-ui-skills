import { createXiaolingOrbit } from './xiaolingOrbit.js';
import { DURATION, FPS, FRAMES } from './xiaolingOrbitData.js';

/**
 * Frames where the five dots sit exactly on the cross slots:
 * one dot in the centre and four at top / right / bottom / left.
 *
 * 40 is the first cross (the frame whose layout matches the final frame);
 * 100, 160 ... 520 are the fully grown crosses that follow every 60 frames.
 */
export const CROSS_FRAMES = Object.freeze([40, 100, 160, 220, 280, 340, 400, 460, 520]);

/** Tail-loop entry point: the end frame 520 shares this exact layout. */
export const LOOP_START_FRAME = 40;

/** How many frames after a cross still count as "at" that cross. */
export const CROSS_TOLERANCE_FRAMES = 1;

const LAST_FRAME = FRAMES - 1;

/** First cross at or after `frame` (with a one-frame grace for the cross just passed). */
export function nextCrossFrame(frame) {
  for (const cross of CROSS_FRAMES) {
    if (cross >= frame - CROSS_TOLERANCE_FRAMES) return cross;
  }
  return CROSS_FRAMES[CROSS_FRAMES.length - 1];
}

/**
 * Thinking lifecycle on top of the raw orbit player.
 *
 * - start(): begin at frame 0 (one dot), play the intro, then loop 40 → 520.
 * - finish(): continue to the next cross frame, then pause and hold it.
 * - showFinal(): jump to the final cross (520) without playing.
 * - pause()/resume()/seek()/setSpeed() for manual control.
 *
 * State: 'idle' → 'thinking' → 'settling' → 'done'.
 *
 * @param {HTMLElement} container
 * @param {import('./xiaolingThinking.d.ts').XiaolingThinkingOptions} [options]
 * @returns {import('./xiaolingThinking.d.ts').XiaolingThinkingController}
 */
export function createXiaolingThinking(container, options = {}) {
  if (!container) throw new Error('createXiaolingThinking needs a container element');

  let state = 'idle';
  let target = null;

  const player = createXiaolingOrbit(container, {
    autoplay: false,
    loop: true,
    loopStart: LOOP_START_FRAME / FPS,
    speed: options.speed ?? 1,
    respectReducedMotion: options.respectReducedMotion ?? true,
    label: options.label ?? '',
    posterFrame: LOOP_START_FRAME,
    onFrame(time, frame) {
      if (state === 'settling' && target !== null && frame >= target - 0.25) {
        settle(target);
        return;
      }
      options.onFrame?.(time, frame, state, target);
    },
    onEnd() {
      if (state === 'settling' && target !== null) {
        const settled = target;
        target = null;
        state = 'done';
        options.onSettled?.(settled, settled / FPS);
        options.onStateChange?.('done', null);
      } else {
        options.onEnd?.();
      }
    },
  });

  function announce() {
    options.onStateChange?.(state, target);
  }

  function currentFrame() {
    return Math.min(player.getTime() * FPS, LAST_FRAME);
  }

  function settle(frame) {
    const settled = Math.min(Math.max(frame, 0), LAST_FRAME);
    target = null;
    state = 'done';
    player.pause();
    player.setLoop(false);
    player.seek(settled / FPS);
    options.onSettled?.(settled, settled / FPS);
    options.onStateChange?.('done', null);
  }

  function start() {
    target = null;
    state = 'thinking';
    player.setLoop(true);
    player.setLoopStart(LOOP_START_FRAME / FPS);
    player.seek(0);
    player.play();
    announce();
  }

  function finish() {
    if (state === 'idle') {
      showFinal();
      return;
    }
    if (state !== 'thinking') return;

    const frame = currentFrame();
    const cross = nextCrossFrame(frame);

    if (cross <= frame + 0.5) {
      settle(cross);
      return;
    }

    target = cross;
    state = 'settling';
    if (cross >= LAST_FRAME) player.setLoop(false);
    announce();
    if (!player.isPlaying()) player.play();
  }

  function showFinal() {
    target = null;
    state = 'done';
    player.pause();
    player.setLoop(false);
    player.seek(DURATION);
    announce();
  }

  function pause() {
    player.pause();
    announce();
  }

  function resume() {
    if (state === 'thinking' || state === 'settling') player.play();
  }

  function stop() {
    target = null;
    state = 'done';
    player.pause();
    player.setLoop(false);
    announce();
  }

  function seek(seconds) {
    player.seek(seconds);
  }

  function destroy() {
    player.destroy();
    state = 'done';
    target = null;
  }

  return {
    start,
    finish,
    showFinal,
    pause,
    resume,
    stop,
    seek,
    setSpeed: (value) => player.setSpeed(value),
    getTime: () => player.getTime(),
    getFrame: currentFrame,
    getState: () => state,
    getTarget: () => target,
    isPlaying: () => player.isPlaying(),
    destroy,
  };
}
