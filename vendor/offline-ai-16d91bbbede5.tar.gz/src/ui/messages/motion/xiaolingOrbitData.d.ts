export interface XiaolingDot {
  name: 'cyan' | 'pink' | 'yellow' | 'orange' | 'purple';
  color: string;
  x: ReadonlyArray<readonly [frame: number, value: number]>;
  y: ReadonlyArray<readonly [frame: number, value: number]>;
  r: ReadonlyArray<readonly [frame: number, value: number]>;
}

export interface XiaolingSample {
  name: XiaolingDot['name'];
  color: string;
  x: number;
  y: number;
  r: number;
}

export const FPS: number;
export const FRAMES: number;
export const VIEW: number;
export const DURATION: number;
export const DOTS: readonly XiaolingDot[];
export function sampleFrame(frame: number): XiaolingSample[];
export function sample(time: number): XiaolingSample[];
