<script lang="ts">
export type ThinkingMotionStatus = 'thinking' | 'completed' | 'interrupted';
</script>

<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue';
import { createXiaolingThinking, LOOP_START_FRAME } from './xiaolingThinking.js';
import { FPS } from './xiaolingOrbitData.js';
import type { XiaolingThinkingController, XiaolingThinkingState } from './xiaolingThinking.js';

/**
 * 小灵的“思考态”生命周期：
 * - thinking：从中心单点开始播放；17.37 s 后从末尾 520 回到 40，循环 40 → 520。
 * - completed：继续播放到下一个十字帧（40/100/…/520），停住并保持。
 * - interrupted：停在当前帧（首次挂载时停在十字帧 40）。
 *
 * 340 的 viewBox 即源动画的 340 × 340 安全区；默认 32 px 用于思考态图标。
 */
const props = withDefaults(defineProps<{
  status: ThinkingMotionStatus;
  size?: number | string;
  speed?: number;
  label?: string;
  respectReducedMotion?: boolean;
}>(), {
  size: 32,
  speed: 2,
  label: '',
  respectReducedMotion: true,
});

const emit = defineEmits<{
  settled: [frame: number, time: number];
  'state-change': [state: XiaolingThinkingState, target: number | null];
}>();

const host = ref<HTMLSpanElement>();
const cssSize = computed(() => (typeof props.size === 'number' ? `${props.size}px` : props.size));
let controller: XiaolingThinkingController | undefined;
const phase = ref<XiaolingThinkingState>('idle');
const targetFrame = ref<number | null>(null);
let reducedQuery: MediaQueryList | undefined;
function updateReducedMotion() { applyStatus(props.status); }

function prefersReducedMotion() {
  return Boolean(
    props.respectReducedMotion
    && typeof window !== 'undefined'
    && window.matchMedia
    && window.matchMedia('(prefers-reduced-motion: reduce)').matches,
  );
}

function freezeAt(frame: number) {
  controller?.pause();
  controller?.seek(frame / FPS);
}

function applyStatus(status: ThinkingMotionStatus) {
  if (!controller) return;
  controller.setSpeed(props.speed);

  if (status === 'thinking') {
    if (prefersReducedMotion()) freezeAt(LOOP_START_FRAME);
    else controller.start();
    return;
  }

  if (status === 'completed') {
    if (prefersReducedMotion()) controller.showFinal();
    else controller.finish();
    return;
  }

  // interrupted: keep the frame the animation had reached; a freshly mounted
  // interrupted message shows the first cross instead of a lone dot.
  if (controller.getState() === 'idle') freezeAt(LOOP_START_FRAME);
  controller.stop(); // Clear any pending cross target while keeping the current frame.
}

onMounted(() => {
  if (!host.value) return;
  controller = createXiaolingThinking(host.value, {
    speed: props.speed,
    label: props.label,
    respectReducedMotion: props.respectReducedMotion,
    onSettled: (frame, time) => emit('settled', frame, time),
    onStateChange: (state, target) => { phase.value = state; targetFrame.value = target; emit('state-change', state, target); },
  });
  reducedQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
  reducedQuery.addEventListener('change', updateReducedMotion);
  applyStatus(props.status);
});

watch(() => props.status, (status) => applyStatus(status));
watch(() => props.speed, (speed) => controller?.setSpeed(speed));

onBeforeUnmount(() => {
  reducedQuery?.removeEventListener('change', updateReducedMotion);
  controller?.destroy();
  controller = undefined;
});

defineExpose({
  start: () => controller?.start(),
  finish: () => controller?.finish(),
  pause: () => controller?.pause(),
  resume: () => controller?.resume(),
  getFrame: () => controller?.getFrame() ?? 0,
  getState: () => controller?.getState() ?? 'idle',
});
</script>

<template>
  <span
    ref="host"
    class="xiaoling-thinking"
    :data-motion-status="status"
    :data-motion-phase="phase"
    :data-motion-target="targetFrame"
    :style="{ width: cssSize, height: cssSize }"
  />
</template>

<style scoped>
.xiaoling-thinking {
  display: inline-block;
  flex: none;
  line-height: 0;
  vertical-align: middle;
}
.xiaoling-thinking :deep(svg) {
  display: block;
  width: 100%;
  height: 100%;
  overflow: visible;
}
</style>
