import { DOTS, DURATION, FPS, FRAMES, VIEW, sampleFrame } from './xiaolingOrbitData.js';

const SVG_NS = 'http://www.w3.org/2000/svg';

/**
 * Mount the reconstructed 5-dot motion into a container.
 *
 * The player owns one <svg> with five <circle> elements and updates their
 * geometry on requestAnimationFrame. It is dependency-free and only touches
 * five attributes per frame, so it stays cheap even inside long chat lists.
 *
 * @param {HTMLElement} container
 * @param {import('./xiaolingOrbit.d.ts').XiaolingOrbitOptions} [options]
 * @returns {import('./xiaolingOrbit.d.ts').XiaolingOrbitController}
 */
export function createXiaolingOrbit(container, options = {}) {
  if (!container) throw new Error('createXiaolingOrbit needs a container element');

  const config = {
    loop: true,
    speed: 1,
    autoplay: true,
    respectReducedMotion: true,
    label: '',
    posterFrame: 40,
    loopStart: 0,
    onFrame: null,
    onEnd: null,
    ...options,
  };

  const svg = document.createElementNS(SVG_NS, 'svg');
  svg.setAttribute('viewBox', `0 0 ${VIEW} ${VIEW}`);
  svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');
  svg.setAttribute('focusable', 'false');
  svg.style.display = 'block';
  svg.style.width = '100%';
  svg.style.height = '100%';
  svg.style.overflow = 'visible';
  if (config.label) {
    svg.setAttribute('role', 'img');
    svg.setAttribute('aria-label', config.label);
  } else {
    svg.setAttribute('aria-hidden', 'true');
  }

  const circles = DOTS.map((dot) => {
    const circle = document.createElementNS(SVG_NS, 'circle');
    circle.setAttribute('fill', dot.color);
    circle.setAttribute('r', '0');
    circle.setAttribute('shape-rendering', 'geometricPrecision');
    svg.appendChild(circle);
    return circle;
  });
  container.appendChild(svg);

  let time = 0;
  let playing = false;
  let raf = 0;
  let lastNow = 0;
  let speed = Number(config.speed) || 1;
  let loop = Boolean(config.loop);
  let loopStart = Math.min(Math.max(Number(config.loopStart) || 0, 0), DURATION - 1 / FPS);
  const reducedQuery = typeof window !== 'undefined' && window.matchMedia
    ? window.matchMedia('(prefers-reduced-motion: reduce)')
    : null;
  const reduced = Boolean(config.respectReducedMotion && reducedQuery && reducedQuery.matches);

  function draw(seconds) {
    const frame = Math.min(Math.max(seconds, 0) * FPS, FRAMES - 0.001);
    const dots = sampleFrame(frame);
    for (let i = 0; i < dots.length; i += 1) {
      const { x, y, r } = dots[i];
      const circle = circles[i];
      circle.setAttribute('cx', x.toFixed(2));
      circle.setAttribute('cy', y.toFixed(2));
      circle.setAttribute('r', r > 0.02 ? r.toFixed(2) : '0');
    }
    if (config.onFrame) config.onFrame(seconds, frame);
  }

  function frameStep(now) {
    if (!playing) return;
    if (!lastNow) lastNow = now;
    let delta = (now - lastNow) / 1000;
    lastNow = now;
    if (!Number.isFinite(delta) || delta < 0) delta = 0;
    if (delta > 0.25) delta = 0.25;

    time += delta * speed;
    if (loop) {
      if (time >= DURATION) {
        const span = DURATION - loopStart;
        time = span > 0 ? loopStart + ((time - DURATION) % span) : 0;
      }
    } else if (time >= DURATION) {
      time = DURATION;
      playing = false;
      draw(time);
      if (config.onEnd) config.onEnd();
      return;
    }
    draw(time);
    raf = window.requestAnimationFrame(frameStep);
  }

  function play() {
    if (playing) return;
    if (!loop && time >= DURATION) time = 0;
    playing = true;
    lastNow = 0;
    raf = window.requestAnimationFrame(frameStep);
  }

  function pause() {
    playing = false;
    if (raf) window.cancelAnimationFrame(raf);
    raf = 0;
    lastNow = 0;
  }

  function seek(seconds) {
    const next = Number(seconds);
    if (!Number.isFinite(next)) return;
    time = Math.min(Math.max(next, 0), DURATION);
    draw(time);
  }

  function setSpeed(value) {
    const next = Number(value);
    if (Number.isFinite(next) && next > 0) speed = next;
  }

  function setLoop(value) {
    loop = Boolean(value);
  }

  function setLoopStart(seconds) {
    const next = Number(seconds);
    if (!Number.isFinite(next)) return;
    loopStart = Math.min(Math.max(next, 0), DURATION - 1 / FPS);
  }

  function onReducedMotionChange(event) {
    if (!event.matches || !config.respectReducedMotion) return;
    pause();
    time = Math.min(config.posterFrame / FPS, DURATION);
    draw(time);
  }

  if (reducedQuery && reducedQuery.addEventListener) {
    reducedQuery.addEventListener('change', onReducedMotionChange);
  }

  if (reduced) {
    time = Math.min(config.posterFrame / FPS, DURATION);
    draw(time);
  } else {
    draw(0);
    if (config.autoplay) play();
  }

  return {
    play,
    pause,
    toggle() {
      if (playing) pause();
      else play();
    },
    seek,
    setSpeed,
    setLoop,
    setLoopStart,
    getTime: () => time,
    getLoopStart: () => loopStart,
    isPlaying: () => playing,
    destroy() {
      pause();
      if (reducedQuery && reducedQuery.removeEventListener) {
        reducedQuery.removeEventListener('change', onReducedMotionChange);
      }
      if (svg.parentNode === container) container.removeChild(svg);
    },
  };
}
