export type XiaolingThinkingState = 'idle' | 'thinking' | 'settling' | 'done';

export interface XiaolingThinkingOptions {
  speed?: number;
  respectReducedMotion?: boolean;
  label?: string;
  /** Called on every animation frame after the lifecycle check. */
  onFrame?: (time: number, frame: number, state: XiaolingThinkingState, target: number | null) => void;
  /** Called when a non-looping playback reaches the last frame. */
  onEnd?: () => void;
  /** Called when the animation has settled on a cross frame. */
  onSettled?: (frame: number, time: number) => void;
  /** Called whenever the lifecycle state or settle target changes. */
  onStateChange?: (state: XiaolingThinkingState, target: number | null) => void;
}

export interface XiaolingThinkingController {
  /** Start from frame 0 (a single dot); after the end, loop 40 → 520. */
  start(): void;
  /** Play until the next cross frame, then pause and hold it. */
  finish(): void;
  /** Jump to the final cross (frame 520) and hold it, without playing. */
  showFinal(): void;
  pause(): void;
  resume(): void;
  stop(): void;
  seek(seconds: number): void;
  setSpeed(speed: number): void;
  getTime(): number;
  getFrame(): number;
  getState(): XiaolingThinkingState;
  getTarget(): number | null;
  isPlaying(): boolean;
  destroy(): void;
}

export const CROSS_FRAMES: readonly number[];
export const LOOP_START_FRAME: number;
export const CROSS_TOLERANCE_FRAMES: number;

export function nextCrossFrame(frame: number): number;

export function createXiaolingThinking(
  container: HTMLElement,
  options?: XiaolingThinkingOptions,
): XiaolingThinkingController;
