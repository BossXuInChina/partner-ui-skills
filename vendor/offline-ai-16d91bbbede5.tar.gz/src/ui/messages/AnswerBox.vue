<script setup lang="ts">
import { vAiTooltip } from '../foundation/aiTooltip';
import { useDeliveryMode } from '../foundation/deliveryMode';
import { computed, nextTick, onBeforeUnmount, provide, ref, watch } from 'vue';
import { TrActionButton, BubbleRenderers, type ChatMessageContentItem, type BubbleBoxRendererProps } from '@opentiny/tiny-robot';
import { aiIconVNode } from '../foundation/aiIcons';
import AiAlert from './AiAlert.vue';
import DislikeFeedbackCard from './DislikeFeedbackCard.vue';
import AiToast from '../foundation/AiToast.vue';
import type { AiToastType } from '../foundation/aiToast';
import ThinkingContent, { type ThinkingStatus } from './ThinkingContent.vue';
import { answerDisplayKey } from './answerDisplay';
defineOptions({inheritAttrs:false});
const props=withDefaults(defineProps<BubbleBoxRendererProps & {replyKey:string;busy:boolean;loading:boolean;progressText?:string;stopped?:boolean;hasOutput?:boolean;failure?:string;canContinue?:boolean;active?:boolean;completion?:string;thinking?:{content:string;status:ThinkingStatus};expectedParts?:{index:number;signature:string}[]}>(),{failure:'',canContinue:false,stopped:false,hasOutput:true,progressText:'',placement:'start',shape:'rounded',active:false,completion:'',thinking:undefined,expectedParts:()=>[]});
const emit=defineEmits<{regenerate:[];continue:[];displayBusy:[value:boolean,capture?:()=>ChatMessageContentItem[]];displayChange:[];feedback:[value:{reasons:string[];detail:string}]}>();
// One persistent ThinkingContent bridges initial wait, reasoning and final answer.
// Private acknowledgements/getters stay in this Box; only an explicit Stop
// captures serializable visible parts for the message owner to persist.
const displayed = ref<Record<number,string>>({});
const captures=new Map<number,()=>ChatMessageContentItem|undefined>();
const captureDisplay=()=>[...captures].sort(([a],[b])=>a-b).flatMap(([,capture])=>{const part=capture();return part?[part]:[];});
const live = ref(props.active || props.loading), epoch=ref(0), outputStarted=ref(false);
const retainedThinking=ref(props.thinking);
watch(()=>props.thinking,value=>{if(value)retainedThinking.value=value;});
const cancelled=computed(()=>!!(props.stopped||props.failure));
const displayDone = ref(!props.active && props.completion === 'completed');
let paintFrame = 0, paintRevision = 0;
provide(answerDisplayKey, {
  register:(index,capture)=>{captures.set(index,capture);return()=>{if(captures.get(index)===capture)captures.delete(index);};},
  live,epoch,cancelled,failed:computed(()=>!!props.failure),
  ready:index=>!live.value || !!props.failure || props.expectedParts.filter(part=>part.index<index).every(part=>displayed.value[part.index]===part.signature),
  acknowledge:(index,signature)=>{displayed.value={...displayed.value,[index]:signature};},
  changed:()=>{outputStarted.value=true;emit('displayChange');},
});
function cancelPaint() { paintRevision++; cancelAnimationFrame(paintFrame); }
watch(() => [props.replyKey,props.active] as const, ([key,active],[beforeKey,beforeActive]) => {
  if(key!==beforeKey || (active&&!beforeActive)){
    cancelPaint();
    // Continuing an existing partial reply keeps every already shown prefix/block.
    // Regeneration clears expectedParts first, so it still starts a fresh epoch.
    const continuing=key===beforeKey && active && props.expectedParts.length>0;
    displayed.value=continuing?Object.fromEntries([...captures].flatMap(([index,capture])=>{
      const part=capture();if(!part)return [];
      const signature=part.type==='text'?String(part.text??''):JSON.stringify(part);
      return props.expectedParts.some(expected=>expected.index===index && expected.signature===signature)?[[index,signature]]:[];
    })):{};
    live.value=active||props.loading;displayDone.value=!live.value&&props.completion==='completed';outputStarted.value=continuing&&Object.keys(displayed.value).length>0;retainedThinking.value=props.thinking;
    if(!continuing)epoch.value++;
  }
}, {flush:'pre'});
watch(() => [props.active,props.completion,props.stopped,props.failure,props.expectedParts,displayed.value] as const, async () => {
  cancelPaint();
  if (props.stopped || props.failure || props.active || props.completion !== 'completed') { displayDone.value=false; return; }
  if (!live.value) { displayDone.value=true;return; }
  if (!props.expectedParts.every(part => displayed.value[part.index] === part.signature)) {displayDone.value=false;return;}
  if (displayDone.value) return;
  const token = paintRevision;
  await nextTick();
  if (token !== paintRevision) return;
  // Also covers business blocks/no-text replies after the final Vue render.
  paintFrame=requestAnimationFrame(()=>{paintFrame=requestAnimationFrame(()=>{
    if(token===paintRevision && !props.active && !props.stopped && !props.failure) displayDone.value=true;
  });});
}, {flush:'post',immediate:true});
const motionStatus = computed<ThinkingStatus>(() => props.stopped || props.failure || props.thinking?.status === 'interrupted' ? 'interrupted' : displayDone.value ? 'completed' : 'thinking');
const presenting=computed(()=>live.value&&!cancelled.value&&!displayDone.value);
watch(presenting,value=>emit('displayBusy',value,captureDisplay),{immediate:true});
const thinkingStatus=computed<ThinkingStatus>(()=>cancelled.value?'interrupted':retainedThinking.value?.status??(props.active&&!outputStarted.value?'thinking':'completed'));
onBeforeUnmount(()=>{cancelPaint();emit('displayBusy',false);});

const delivery = useDeliveryMode();
const content=ref<HTMLElement>();
const vote=ref<'like'|'dislike'|null>(null),saved=ref(false);
const notification=ref({visible:false,message:'',type:'success' as AiToastType,revision:0});
function notify(message:string,type:AiToastType='success'){notification.value={visible:true,message,type,revision:notification.value.revision+1};}
const feedbackOpen=ref(false),feedbackTooltipSuppressed=ref(false);
const reply=ref<HTMLElement>();
let revealFrame=0;
let feedbackTrigger:HTMLElement|undefined;
watch(()=>props.replyKey,()=>{vote.value=null;saved.value=false;notification.value.visible=false;feedbackOpen.value=false;feedbackTooltipSuppressed.value=false;});
watch(()=>props.loading,loading=>{if(loading){vote.value=null;saved.value=false;notification.value.visible=false;feedbackOpen.value=false;feedbackTooltipSuppressed.value=false;}});
function rate(value:'like'|'dislike',event:MouseEvent){
  vote.value=vote.value===value?null:value;feedbackOpen.value=vote.value==='dislike';
  if(value==='dislike' && event.currentTarget instanceof HTMLElement)feedbackTrigger=event.currentTarget;
  if(value==='like')notify(vote.value==='like'?'感谢您的反馈！':'已取消点赞');
}
// Restore keyboard focus silently. Re-arm this hint only after a fresh pointer
// move or blur/refocus; layout changes under a stationary pointer must not open it.
function closeFeedback(){feedbackTooltipSuppressed.value=true;feedbackOpen.value=false;void nextTick(()=>feedbackTrigger?.focus({preventScroll:true}));}
function submitFeedback(value:{reasons:string[];detail:string}){emit('feedback',value);closeFeedback();notify('已提交，非常感谢您的支持！');}
// A host may capture Escape before native form handlers (the overview scene
// does). Capture only while this card is open and focus is inside its reply,
// so Escape dismisses the feedback before an enclosing host layer.
function escapeFeedback(event:KeyboardEvent){
  if(event.key!=='Escape' || !(event.target instanceof Node) || !feedbackTrigger?.closest('.answer-reply')?.contains(event.target))return;
  event.preventDefault();event.stopPropagation();
  if(!props.busy&&!props.loading&&!presenting.value)closeFeedback();
}
// Reveal once after the expanded card has layout. Scroll only its nearest
// scrolling ancestor so the sidebar's footer, sibling panels and page stay put.
// The source-only overview example has no local scrollport; there the document
// owns scrolling. No focus/selection changes or persistent bottom-follow flag.
function revealFeedback(){
  revealFrame=0;
  const card=reply.value?.querySelector<HTMLElement>('.dislike-feedback-card');
  if(!feedbackOpen.value||!card)return;
  const behavior=matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth';
  for(let port=card.parentElement;port&&port!==document.body;port=port.parentElement){
    if(!/(auto|scroll)/.test(getComputedStyle(port).overflowY)||port.scrollHeight<=port.clientHeight)continue;
    const bounds=port.getBoundingClientRect(),box=card.getBoundingClientRect();
    const top=Math.max(bounds.top+port.clientTop,0)+16;
    const bottom=Math.min(bounds.top+port.clientTop+port.clientHeight,innerHeight)-16;
    const delta=box.height>bottom-top?box.top-top:box.bottom>bottom?box.bottom-bottom:box.top<top?box.top-top:0;
    if(Math.abs(delta)>1)port.scrollBy({top:delta,behavior});
    return;
  }
  card.scrollIntoView({block:'nearest',inline:'nearest',behavior});
}
watch(feedbackOpen,open=>{
  cancelAnimationFrame(revealFrame);revealFrame=0;
  if(open){window.addEventListener('keydown',escapeFeedback,true);revealFrame=requestAnimationFrame(revealFeedback);}
  else window.removeEventListener('keydown',escapeFeedback,true);
},{flush:'post'});
onBeforeUnmount(()=>{window.removeEventListener('keydown',escapeFeedback,true);cancelAnimationFrame(revealFrame);});
// Copy rendered slot text, excluding this footer; no Markdown source or business-specific field extraction.
async function copy(){
  try{
    const body=content.value;
    const text=body?.querySelector('.answer-progress,.answer-stopped,.answer-failure')
      ? Array.from(body.children).filter(node=>!node.matches('.answer-progress,.answer-stopped,.answer-failure')).map(node=>(node as HTMLElement).innerText).join('\n')
      : body?.innerText ?? '';
    await navigator.clipboard.writeText(text);notify('复制成功');
  }
  catch{notify('复制失败，请检查浏览器剪贴板权限','error');}
}
</script>
<template>
  <!-- This unpainted column keeps feedback below the native agent Box. Forward
       renderer/native attributes to Box so its role, shape and styles stay intact. -->
  <div ref="reply" class="answer-reply">
  <component :is="BubbleRenderers.Box" v-bind="$attrs" class="answer-box" :placement="placement" :shape="shape" :data-reply-key="replyKey">
    <div ref="content" class="answer-content">
      <ThinkingContent v-if="retainedThinking || live || completion==='completed' || stopped || failure" :key="replyKey" :show-empty-interrupted="true" :class="{'answer-progress':!retainedThinking,'has-output':!retainedThinking && !loading}" :role="retainedThinking ? undefined : 'status'" :content="retainedThinking?.content ?? ''" :status="thinkingStatus" :motion-status="motionStatus" />
      <slot v-if="stopped || failure ? hasOutput : !loading || !progressText" />
      <AiAlert v-if="failure" class="answer-failure" :class="{'has-output':hasOutput}" type="error" :message="hasOutput ? '生成中断，已保留以上内容' : '本次回答生成失败，请重试。'" :description="failure !== '本次回答生成失败，请重试。' && failure !== '生成中断，已保留以上内容' ? failure : ''" />
      <!-- REQ-010: cancellation is auxiliary reply content, not another Box or a success result.
           Keep valid streamed content; an empty stop suppresses the dependency's empty slot. -->
      <AiAlert v-else-if="stopped" class="answer-stopped" :class="{'has-output':hasOutput}" type="neutral" message="已停止生成" />
    </div>
    <!-- Keep business handlers and per-action disabled/pressed states here: 0.5.1 Feedback
         cannot express them. ActionButton reuses its public native button/icon APIs; the independent Tooltip
         retains focus/Escape. Its built-in tooltip prop is intentionally omitted;
         verify attribute forwarding, 36px/24px geometry and keyboard behavior on upgrades. -->
    <footer v-if="!stopped && !loading && !active && !presenting" class="reply-actions" aria-label="回复信息操作">
      <!-- REQ-029: 0.5.1 ActionButton requires an icon and has no text API.
           This one native text action fills that gap; review a public text-button API on upgrade. -->
      <button v-if="canContinue" class="reply-continue" type="button" :disabled="busy||loading||presenting" @click="emit('continue')">继续生成</button>
      <TrActionButton v-ai-tooltip="failure && !hasOutput ? '重试' : '重新生成答案'" :icon="aiIconVNode('message.regenerate')" size="36" type="button" :aria-label="failure && !hasOutput ? '重试' : '重新生成答案'" :disabled="busy||loading||presenting" @click="emit('regenerate')"></TrActionButton>
      <TrActionButton v-if="hasOutput" v-ai-tooltip="'复制'" :icon="aiIconVNode('message.copy')" size="36" type="button" aria-label="复制回复" :disabled="busy||loading||presenting" @click="copy"></TrActionButton>
      <TrActionButton v-if="hasOutput" v-ai-tooltip="'点赞'" :icon="aiIconVNode('message.like', { active: vote==='like' })" size="36" type="button" aria-label="点赞" :aria-pressed="vote==='like'" :disabled="busy||loading||presenting" @click="rate('like',$event)"></TrActionButton>
      <TrActionButton v-if="hasOutput" v-ai-tooltip="{content:'点踩',disabled:feedbackOpen||feedbackTooltipSuppressed}" :icon="aiIconVNode('message.dislike', { active: vote==='dislike' })" size="36" type="button" aria-label="点踩" :aria-pressed="vote==='dislike'" :aria-expanded="feedbackOpen" :disabled="busy||loading||presenting" @click="rate('dislike',$event)" @pointermove="feedbackTooltipSuppressed=false" @blur="feedbackTooltipSuppressed=false"></TrActionButton>
      <TrActionButton v-if="hasOutput" v-show="!delivery" v-ai-tooltip="'收藏'" :icon="aiIconVNode('message.bookmark', { active: saved })" size="36" type="button" aria-label="收藏" :aria-pressed="saved" :disabled="busy||loading||presenting" @click="saved=!saved"></TrActionButton>
    </footer>
  </component>
  <DislikeFeedbackCard v-if="feedbackOpen && !stopped && hasOutput" :disabled="busy||loading||presenting" @cancel="closeFeedback" @submit="submitFeedback" />
  <AiToast :key="notification.revision" v-model="notification.visible" :message="notification.message" :type="notification.type" />
  </div>
</template>
<style scoped>
.answer-reply{display:flex;flex-direction:column;gap:var(--partner-ai-reply-feedback-gap);width:100%;min-width:0}
/* Consumer overrides may retain the legacy #191919 paint; local SVGs already
   use currentColor. Keep the existing override color contract on Robot upgrades. */
.reply-actions :deep(svg[data-ai-icon-color="inherit"] [fill="#191919"]) { fill:currentColor; }
</style>
