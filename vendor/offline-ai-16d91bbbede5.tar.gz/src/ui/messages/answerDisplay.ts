import type { ChatMessageContentItem } from '@opentiny/tiny-robot';
import type { ComputedRef, InjectionKey, Ref } from 'vue';

// Private per-Box acknowledgement: a transport terminal state alone cannot stop
// motion before the final text renderer has committed and painted its revision.
export interface AnswerDisplay {
  live: Ref<boolean>;
  epoch: Ref<number>;
  cancelled: ComputedRef<boolean>;
  failed: ComputedRef<boolean>;
  ready(index: number): boolean;
  acknowledge(index: number, signature: string): void;
  changed(): void;
  register(index: number, capture: () => ChatMessageContentItem | undefined): () => void;
}
export const answerDisplayKey: InjectionKey<AnswerDisplay> = Symbol('answer-display');
