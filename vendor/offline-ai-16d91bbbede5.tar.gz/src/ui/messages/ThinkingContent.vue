<script setup lang="ts">
import { computed, nextTick, onMounted, ref, watch } from 'vue';
import '../foundation/scrollbarStyles.css';
import XiaolingThinking from './motion/XiaolingThinking.vue';
import { localIcons } from '../../assets/ai-icons/localIcons';

export type ThinkingStatus = 'thinking' | 'completed' | 'interrupted';

const props = withDefaults(defineProps<{
  content: string;
  status: ThinkingStatus;
  expanded?: boolean;
  /** Motion stays active through final-answer display; body status is independent. */
  motionStatus?: ThinkingStatus;
  /** Compatibility image URL; scripted SVG uses the default inline motion. */
  motionAsset?: string;
  /** Preserve the progress row after interruption even before reasoning text arrives. */
  showEmptyInterrupted?: boolean;
}>(), { motionAsset: '', motionStatus: undefined, expanded: undefined, showEmptyInterrupted:false });
const emit = defineEmits<{ 'update:expanded': [value: boolean] }>();

const localExpanded = ref(false);
const isExpanded = computed(() => props.status === 'thinking' || props.status === 'interrupted' || (props.status === 'completed' && (props.expanded ?? localExpanded.value)));
const paragraphs = computed(() => props.content.split(/\r?\n[\t ]*\r?\n+/).map(paragraph => paragraph.trim()).filter(Boolean));
const body = ref<HTMLElement>();
const followingBottom = ref(true);

function updateBottomIntent() {
  const element = body.value;
  if (element) followingBottom.value = element.scrollHeight - element.scrollTop - element.clientHeight <= 2;
}

function alignScrollbarToInset() {
  const element = body.value;
  const shell = element?.parentElement;
  if (!element || !shell) return;
  const rightInset = parseFloat(getComputedStyle(shell).paddingRight) || 12;
  const gutter = element.offsetWidth - element.clientWidth;
  const nativeTrack = parseFloat(getComputedStyle(element, '::-webkit-scrollbar').width);
  const tokenTrack = parseFloat(getComputedStyle(element).getPropertyValue('--partner-ai-scrollbar-small-size'));
  const track = gutter || (Number.isFinite(nativeTrack) ? nativeTrack : tokenTrack || 10);
  element.style.setProperty('--thinking-scroll-extension', `${(rightInset + track) / 2}px`);
  element.style.setProperty('--thinking-native-gutter', `${gutter}px`);
}

watch(() => props.content, async () => {
  if (props.status !== 'thinking' || !followingBottom.value) return;
  await nextTick();
  const element = body.value;
  if (element && props.status === 'thinking' && followingBottom.value) element.scrollTop = element.scrollHeight;
});
watch(() => props.status, status => {
  if (status !== 'thinking') { localExpanded.value = false; emit('update:expanded', false); }
  else { followingBottom.value = true; void nextTick().then(alignScrollbarToInset); }
});
watch(body, element => { if (element) void nextTick().then(alignScrollbarToInset); }, { flush:'post' });
onMounted(alignScrollbarToInset);

function toggle() {
  if (props.status === 'completed') {
    const value = !isExpanded.value;
    localExpanded.value = value;
    emit('update:expanded', value);
  }
}

// Animate the owned body instead of Robot internals; streaming keeps its existing
// height/scroll contract. Cancellation handles rapid toggles without stale styles.
const bodyMotion = new WeakMap<HTMLElement, Animation>();
function stopBodyMotion(element: Element) {
  bodyMotion.get(element as HTMLElement)?.cancel();
}
function animateBody(element: Element, done: () => void, opening: boolean) {
  const node = element as HTMLElement;
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) { done(); return; }
  const paint = getComputedStyle(node);
  const expanded = { height: `${node.getBoundingClientRect().height}px`, opacity: '1', marginTop: paint.marginTop, paddingTop: paint.paddingTop, paddingBottom: paint.paddingBottom };
  const collapsed = { height: '0px', opacity: '0', marginTop: '0px', paddingTop: '0px', paddingBottom: '0px' };
  const previousOverflow = node.style.overflow;
  node.style.overflow = 'hidden';
  const animation = node.animate(opening ? [collapsed, expanded] : [expanded, collapsed], { duration: 220, easing: 'cubic-bezier(.2,.8,.2,1)' });
  bodyMotion.set(node, animation);
  void animation.finished.catch(() => undefined).then(() => {
    if (bodyMotion.get(node) === animation) { bodyMotion.delete(node); node.style.overflow = previousOverflow; }
    done();
  });
}
const expandBody = (element: Element, done: () => void) => animateBody(element, done, true);
const collapseBody = (element: Element, done: () => void) => animateBody(element, done, false);
</script>

<template>
  <section v-if="content.trim() || status !== 'interrupted' || showEmptyInterrupted" class="thinking-content" :data-status="status" :data-expanded="isExpanded">
    <div class="thinking-content__row">
      <span class="thinking-content__motion" aria-hidden="true">
        <img v-if="motionAsset" :src="motionAsset" alt="" width="32" height="32">
        <XiaolingThinking v-else :status="motionStatus ?? status" />
      </span>
      <button
        v-if="status === 'completed'"
        class="thinking-content__toggle"
        type="button"
        :aria-expanded="isExpanded"
        @click="toggle"
      >
        <span>已完成思考</span>
        <component :is="localIcons.thinkingExpand" class="thinking-content__chevron" :class="{ 'is-open': isExpanded }" width="12" height="12" aria-hidden="true" />
      </button>
      <span v-else class="thinking-content__label" :data-interrupted="status === 'interrupted'">
        {{ status === 'thinking' ? '正在思考中...' : '思考已中断' }}
      </span>
    </div>
    <Transition :css="false" @enter="expandBody" @leave="collapseBody" @enter-cancelled="stopBodyMotion" @leave-cancelled="stopBodyMotion">
    <div v-if="isExpanded && content.trim()" class="thinking-content__body" :class="{ 'is-streaming': status === 'thinking' }" :data-testid="status === 'thinking' ? 'thinking-body' : 'thinking-body-expanded'">
      <div ref="body" class="thinking-content__viewport partner-ai-scrollbar-portal" :class="{ 'is-streaming': status === 'thinking' }" :data-testid="status === 'thinking' ? 'thinking-scroll' : 'thinking-viewport-expanded'" @scroll="updateBottomIntent">
        <p v-for="(paragraph,index) in paragraphs" :key="index" class="thinking-content__paragraph">{{ paragraph }}</p>
      </div>
    </div>
    </Transition>
  </section>
</template>

<style scoped>
/* REQ: standalone reasoning presentation. Keep this previewable API independent
   of chat renderers; only approved motion artwork may replace the placeholder. */
.thinking-content { color:var(--partner-ai-text); }
.thinking-content__row { min-height:32px; display:flex; align-items:center; gap:8px; }
.thinking-content__motion { display:grid; place-items:center; width:32px; height:32px; flex:none; }
.thinking-content__motion img { display:block; width:32px; height:32px; object-fit:contain; }
.thinking-content__label,.thinking-content__toggle { color:var(--partner-ai-text); font-size:14px; line-height:20px; font-weight:600; }
.thinking-content__toggle { display:inline-flex; align-items:center; gap:4px; border:0; padding:0; background:transparent; font-family:inherit; cursor:pointer; }
.thinking-content__toggle:focus-visible { outline:2px solid var(--partner-ai-accent); outline-offset:3px; border-radius:3px; }
.thinking-content__chevron { width:12px; height:12px; flex:none; transition:transform 220ms cubic-bezier(.2,.8,.2,1); }
.thinking-content__chevron.is-open { transform:rotate(180deg); }
.thinking-content__body { box-sizing:border-box; margin-top:8px; padding:12px; border-radius:12px; background:var(--partner-ai-page-bg); color:var(--partner-ai-muted); }
.thinking-content__viewport { color:inherit; font-size:var(--partner-ai-caption-size); font-weight:var(--partner-ai-body-weight); line-height:var(--partner-ai-caption-line); letter-spacing:var(--partner-ai-caption-letter-spacing); overflow-wrap:anywhere; }
.thinking-content__paragraph { margin:0; white-space:pre-wrap; }
/* The demo host applies a broad .tr-bubble__content p margin; keep its 8px
   paragraph rhythm out of this padded card so the final inset remains12px. */
.thinking-content__body .thinking-content__paragraph { margin-bottom:0!important; }
.thinking-content__paragraph+.thinking-content__paragraph { margin-top:var(--partner-ai-gap-lg)!important; }
.thinking-content__body.is-streaming { max-height:204px; overflow:hidden; }
.thinking-content__viewport.is-streaming { box-sizing:border-box; width:calc(100% + var(--thinking-scroll-extension,11px)); margin-right:calc(0px - var(--thinking-scroll-extension,11px)); padding-right:calc(var(--thinking-scroll-extension,11px) - var(--thinking-native-gutter,0px)); max-height:180px; overflow-x:hidden; overflow-y:auto; overscroll-behavior:contain; }
@media(prefers-reduced-motion:reduce) { .thinking-content__chevron { transition:none; } }
</style>
