<script setup lang="ts">
import { TrPrompt } from '@opentiny/tiny-robot';
import { aiIconVNode } from '../foundation/aiIcons';
import { vAiTooltip } from '../foundation/aiTooltip';
import type { ChatSuggestion } from '../composer/chatSuggestions';
import '../foundation/aiTokens.css';
import './promptStyles.css';
const props = withDefaults(defineProps<{ items: ChatSuggestion[]; disabled?: boolean }>(), { disabled:false });
const emit = defineEmits<{ select: [item: ChatSuggestion] }>();
const arrow = () => aiIconVNode('message.followUp', {class:'message-prompt-arrow'});
function select(item: ChatSuggestion, event?: KeyboardEvent) {
  if (!props.disabled && !item.disabled && !event?.repeat) emit('select',item);
}
// Internal presentation only: ChatPanel owns completion eligibility and direct send.
// Robot 0.5.1 Prompts has no item slot; Prompt's div root needs these per-item
// keyboard/ARIA guards. Public Prompt/badge APIs stay intact; review on upgrade.
</script>
<template>
  <div class="message-prompts" role="group" aria-label="推荐追问">
    <TrPrompt v-for="item in items" :id="item.id" :key="item.id" v-ai-tooltip="{ content: item.label, overflowOnly: true, overflowSelector: '.tr-prompt__content-title' }" class="message-prompt" :label="item.label" :badge="arrow()" :disabled="disabled || item.disabled" role="button" :tabindex="disabled || item.disabled ? -1 : 0" :aria-disabled="disabled || !!item.disabled" :aria-label="item.label" @click="select(item)" @keydown.enter.prevent="select(item, $event)" @keydown.space.prevent @keyup.space.prevent="select(item, $event)" />
  </div>
</template>
