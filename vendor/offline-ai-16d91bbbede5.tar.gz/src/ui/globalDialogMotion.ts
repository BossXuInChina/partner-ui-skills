// Internal compatibility seam for the read-only demo vendor; not a package export.
export { createGlobalDialogMotion } from './foundation/globalDialogMotion';
