import type { UIMessage } from '../messages/chatContent';
import type { ComposerRequestContext } from '../composer/composerTypes';
import type { HistoryGroup } from '@opentiny/tiny-robot';

export interface ConversationViewState extends ComposerRequestContext {
  draft: string;
  scrollTop: number;
  followBottom: boolean;
}
export interface ConversationRecord {
  id: string;
  title: string;
  updatedAt: number;
  pinned: boolean;
  messages: UIMessage[];
  view: ConversationViewState;
  lastQuery: string;
  error: string;
  requestContext: ComposerRequestContext;
}
export interface ConversationSnapshot { version: 1; activeId: string; conversations: ConversationRecord[] }
// REQ-016: the storage promise must resolve only after the write is durable. Consumers
// may supply a server/IndexedDB adapter; neither kit.clear() nor global storage.clear() is used.
export interface ConversationStorage {
  read(namespace: string): Promise<ConversationSnapshot | null>;
  write(namespace: string, snapshot: ConversationSnapshot): Promise<void>;
}
export interface ConversationHistoryOptions { namespace?: string; storage?: ConversationStorage }
export const defaultHistoryNamespace = 'partner-ai:agreement-history:v1';
export const emptyConversationView = (): ConversationViewState => ({ draft:'', aiEnabled:false, mode:'', scrollTop:0, followBottom:true });
export const browserConversationStorage: ConversationStorage = {
  async read(namespace) { const value = localStorage.getItem(namespace); return value ? JSON.parse(value) : null; },
  async write(namespace, snapshot) { localStorage.setItem(namespace, JSON.stringify(snapshot)); },
};
export function validateConversationSnapshot(value: ConversationSnapshot): ConversationSnapshot {
  if (value.version !== 1 || !Array.isArray(value.conversations) || typeof value.activeId !== 'string') throw new Error('历史数据格式不兼容');
  const ids = new Set<string>();
  for (const item of value.conversations) {
    if (!item || typeof item.id !== 'string' || !item.id || ids.has(item.id) || typeof item.title !== 'string' || !Number.isFinite(item.updatedAt) || typeof item.pinned !== 'boolean' || !Array.isArray(item.messages) || !item.view || typeof item.view.draft !== 'string' || typeof item.view.aiEnabled !== 'boolean' || typeof item.view.mode !== 'string' || !Number.isFinite(item.view.scrollTop) || typeof item.view.followBottom !== 'boolean' || typeof item.lastQuery !== 'string' || typeof item.error !== 'string' || !item.requestContext || typeof item.requestContext.aiEnabled !== 'boolean' || typeof item.requestContext.mode !== 'string') throw new Error('历史数据损坏');
    ids.add(item.id);
    for (const message of item.messages) {
      if (!message || (typeof message.content !== 'string' && !Array.isArray(message.content))) throw new Error('历史消息格式不兼容');
      // A reload cannot resume a network stream. Preserve its partial output and stamp
      // the same per-reply aborted state consumed by AnswerBox, without resending anything.
      if (message.recovering || message.loading || ((!message.role || message.role.startsWith('assistant')) && !message.state?.completion)) { message.loading = false; message.recovering = false; message.role ||= 'assistant'; message.state = { ...message.state, completion:'aborted' }; }
    }
  }
  return value;
}
// Rolling elapsed days in UTC milliseconds: [now-7d, now], [now-30d, now-7d),
// then <now-30d. Inclusive cutoffs are deterministic across timezone/DST changes.
export function groupConversationHistory(records: ConversationRecord[], query: string, earlier: boolean, now = Date.now()): HistoryGroup<ConversationRecord>[] {
  const needle = query.trim().toLocaleLowerCase();
  const filtered = records.filter(item => (item.messages.length || item.view.draft) && item.title.toLocaleLowerCase().includes(needle)).sort((a,b) => b.updatedAt-a.updatedAt || a.id.localeCompare(b.id));
  const groups: HistoryGroup<ConversationRecord>[] = [
    { group:'置顶', items:filtered.filter(item => item.pinned) },
    { group:'近7天', items:filtered.filter(item => !item.pinned && item.updatedAt >= now-7*86400000) },
    { group:'7到30天', items:filtered.filter(item => !item.pinned && item.updatedAt < now-7*86400000 && item.updatedAt >= now-30*86400000) },
  ];
  if (earlier || needle) groups.push({ group:'更早', items:filtered.filter(item => !item.pinned && item.updatedAt < now-30*86400000) });
  return groups.filter(group => group.items.length);
}
