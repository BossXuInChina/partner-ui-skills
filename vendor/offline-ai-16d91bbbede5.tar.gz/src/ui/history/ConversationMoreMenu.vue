<script setup lang="ts">
import { nextTick, onBeforeUnmount, onMounted, ref, useId, watch } from 'vue';
import { TrDropdownMenu, type DropdownMenuItem } from '@opentiny/tiny-robot';
import { AiIcon } from '../foundation/aiIcons';
import { vAiTooltip } from '../foundation/aiTooltip';
const props=defineProps<{ title:string; recordId:string; open:boolean; parentOpen:boolean; disabled:boolean }>();
const emit=defineEmits<{toggle:[];close:[];action:[action:DropdownMenuItem]}>();
const trigger=ref<HTMLButtonElement>(),portal=ref<HTMLElement>();
const id=`history-more-${useId().replace(/[^a-zA-Z0-9-]/g,'')}`;
// REQ-016 v0.4: public DropdownMenu items/manual show/appendTo/event contracts.
// Keep an extensible action array; actual deletion always goes through product confirmation.
const actions:DropdownMenuItem[]=[{id:'delete',text:'删除对话'}];
let observer:MutationObserver|undefined;
function close(restore=false){emit('close');if(restore)trigger.value?.focus({preventScroll:true});}
function menuItems(){return [...(portal.value?.querySelectorAll<HTMLElement>('.tr-dropdown-menu__list-item')??[])];}
function bounds(){
  const panel=trigger.value?.closest<HTMLElement>('.conversation-history-panel');
  const rect=panel?.getBoundingClientRect();
  if(!portal.value||!rect)return;
  for(const [key,value] of Object.entries({'min-top':Math.max(8,rect.top+8),'max-bottom':Math.min(innerHeight-8,rect.bottom-8),'min-left':Math.max(8,rect.left+8),'max-right':Math.min(innerWidth-8,rect.right-8)}))portal.value.style.setProperty(`--tr-dropdown-menu-${key}`,`${value}px`);
}
function adapt(){
  // 0.5.1 has no item slot or keyboard menu semantics. This small DOM adapter
  // supplies roles/tabindex on its rendered ul/li, while activation remains the
  // public item-click event. Review these selectors when upgrading; no private refs.
  const menu=portal.value?.querySelector<HTMLElement>('.tr-dropdown-menu__list');
  if(!menu)return;menu.id=id;menu.setAttribute('role','menu');menu.setAttribute('aria-label','会话更多操作');
  for(const item of menuItems()){item.setAttribute('role','menuitem');item.tabIndex=-1;}
  if(props.open && !portal.value?.contains(document.activeElement))menuItems()[0]?.focus({preventScroll:true});
}
function keydown(event:KeyboardEvent){
  if(!props.open)return;
  const items=menuItems(),index=items.indexOf(document.activeElement as HTMLElement);
  if(event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();close(true);return;}
  if(event.key==='Tab'){close();return;}
  if(['ArrowDown','ArrowUp','Home','End'].includes(event.key)){
    event.preventDefault();event.stopPropagation();
    items[event.key==='Home'?0:event.key==='End'?items.length-1:(index+(event.key==='ArrowUp'?-1:1)+items.length)%items.length]?.focus();
  }else if(event.key==='Enter'||event.key===' '){event.preventDefault();event.stopPropagation();if(!props.disabled)items[index]?.click();}
}
function outside(event:PointerEvent){if(props.open && event.target instanceof Node && !portal.value?.contains(event.target)&&!trigger.value?.contains(event.target))close();}
function onFocus(event:FocusEvent){if(props.open && event.target instanceof Node && !portal.value?.contains(event.target)&&!trigger.value?.contains(event.target))close();}
function onScroll(event:Event){
  // Streaming auto-follow in the chat is unrelated to this menu. Only its own
  // history-list scroll invalidates the anchor; viewport scroll updates bounds.
  if(!props.open)return;
  if(event.target===trigger.value?.closest('.history-list'))close();
  else if(event.target===document)bounds();
}
function act(action:DropdownMenuItem){if(props.disabled)return;emit('action',action);close();}
async function sync(){
  if(!portal.value)return;
  if(props.open&&props.parentOpen){bounds();if(!portal.value.matches(':popover-open'))portal.value.showPopover();await nextTick();adapt();}
  else if(portal.value.matches(':popover-open'))portal.value.hidePopover();
}
onMounted(()=>{
  observer=new MutationObserver(adapt);if(portal.value)observer.observe(portal.value,{childList:true,subtree:true});
  document.addEventListener('keydown',keydown,true);document.addEventListener('pointerdown',outside,true);document.addEventListener('focusin',onFocus);
  window.addEventListener('scroll',onScroll,true);window.addEventListener('resize',bounds);void sync();
});
watch(()=>[props.open,props.parentOpen],sync,{flush:'post'});
onBeforeUnmount(()=>{observer?.disconnect();document.removeEventListener('keydown',keydown,true);document.removeEventListener('pointerdown',outside,true);document.removeEventListener('focusin',onFocus);window.removeEventListener('scroll',onScroll,true);window.removeEventListener('resize',bounds);});
</script>
<template>
  <span class="history-row-menu">
    <!-- Independent native top layer escapes the list's overflow and the main
         menu's animated transform. Public appendTo keeps Robot's own fixed placement. -->
    <span ref="portal" popover="manual" class="history-more-portal" @click.stop />
      <TrDropdownMenu v-if="portal" :append-to="portal" :items="actions" trigger="manual" :show="open && parentOpen" @item-click="act" @click-outside="close()">
        <template #trigger><button ref="trigger" v-ai-tooltip="{content:'更多操作',disabled:!parentOpen || open,closeOnPointerLeave:true}" class="history-more" type="button" :data-record-id="recordId" :aria-label="`更多操作：${title}`" aria-haspopup="menu" :aria-expanded="open && parentOpen" :aria-controls="open? id:undefined" :disabled="disabled" @click.stop="emit('toggle')" @keydown.down.prevent.stop="!open && emit('toggle')"><AiIcon name="history.more" aria-hidden="true" /></button></template>
      </TrDropdownMenu>
  </span>
</template>
<style scoped>
.history-row-menu { display:inline-flex; align-items:center; flex:none; color:var(--partner-ai-icon-secondary); }
/* The trigger remains in the row; the zero-size top-layer portal carries only
   Robot's fixed popper and never adds a page-sized hit surface. */
.history-more-portal { position:fixed; inset:0 auto auto 0; width:0; height:0; margin:0; padding:0; border:0; overflow:visible; background:transparent; color:var(--partner-ai-text); --tr-dropdown-menu-bg-color:var(--partner-ai-overlay-bg); --tr-dropdown-menu-box-shadow:var(--partner-ai-overlay-shadow); --tr-dropdown-menu-min-width:var(--partner-ai-history-menu-min-width); --tr-dropdown-menu-item-color:var(--partner-ai-text); --tr-dropdown-menu-item-hover-bg-color:var(--partner-ai-hover-bg); --tr-dropdown-menu-item-font-weight:var(--partner-ai-body-weight); }
.history-more-portal::backdrop { background:transparent; pointer-events:none; }
/* REQ-025: the local trigger owns its 8px container; public DropdownMenu's
   portal/list paint and the existing upgrade-sensitive menu adapter stay separate. */
.history-more { position:relative; display:flex; align-items:center; justify-content:center; width:var(--partner-ai-control-size); height:var(--partner-ai-control-size); padding:var(--partner-ai-gap-sm); border:0; border-radius:var(--partner-ai-control-radius); background:transparent; color:inherit; cursor:pointer; }
/* Keep the 32px trigger while limiting hover paint to the 24px icon area. */
.history-more::before { content:''; position:absolute; width:var(--partner-ai-icon-size); height:var(--partner-ai-icon-size); border-radius:var(--partner-ai-control-radius); pointer-events:none; }
.history-more :deep(svg) { position:relative; width:var(--partner-ai-icon-size); height:var(--partner-ai-icon-size); }
.history-more:hover:not(:disabled)::before { background:var(--partner-ai-hover-bg); }
.history-more:focus-visible { outline:var(--partner-ai-focus-width) solid var(--partner-ai-focus); outline-offset:var(--partner-ai-focus-near-offset); }
.history-more:disabled { opacity:var(--partner-ai-disabled-opacity); cursor:not-allowed; }
.history-more-portal :deep(.tr-dropdown-menu__list-item:focus-visible) { background:var(--partner-ai-hover-bg); outline:var(--partner-ai-focus-width) solid var(--partner-ai-focus); outline-offset:calc(0px - var(--partner-ai-border-width)); }
@media(prefers-reduced-motion:reduce) { .history-more-portal :deep(.tr-dropdown-menu-enter-active),.history-more-portal :deep(.tr-dropdown-menu-leave-active) { transition:none; } }
</style>
