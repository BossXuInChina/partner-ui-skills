# design-requirement-canvas 1.1.1-preview.20261112.1 安装说明

本包是独立 Skill，不需要维护仓库或同级 Skill。解压后，将直接包含 SKILL.md 的 design-requirement-canvas 文件夹放入所用 AI 客户端的 Skill 目录，再按客户端要求重新加载。不要只复制 SKILL.md。

## 环境

需 Python 3.9+ 和 Node.js 20+。校验、画布生成和交接使用 Python 标准库；图片裁剪需要 Pillow，DOM 和浏览器检查需要相应 Node 依赖及 Playwright Chromium。

macOS 通常使用 python3；Windows 可使用 python 或 py -3 运行文档中的 Python 命令。路径包含空格或中文时请加引号。联网安装依赖及浏览器仅在相关功能需要时进行。

详见 SKILL.md、README.md 与 references/。画布对特定设计系统的组件映射还需要对应的组件契约；通用画布功能不要求安装其他 Skill。

本包为预览候选，校验和来源以同批 release-manifest.json 和 SHA256SUMS 为准；通过基础冒烟检查不代表真实项目、人工视觉或生产资格已验收。
