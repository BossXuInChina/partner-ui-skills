import { renderless, api } from '@opentiny/vue-renderless/virtual-scroll-box/vue';
import { defineComponent, props, setup } from '@opentiny/vue-common';
import { openBlock, createElementBlock, normalizeStyle, createElementVNode, renderSlot } from 'vue';

function _createForOfIteratorHelperLoose(r, e) {
  var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (t) return (t = t.call(r)).next.bind(t);
  if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
    t && (r = t);
    var o = 0;
    return function() {
      return o >= r.length ? { done: true } : { done: false, value: r[o++] };
    };
  }
  throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return _arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
  }
}
function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}
var _export_sfc = function _export_sfc2(sfc, props) {
  var target = sfc.__vccOpts || sfc;
  for (var _iterator = _createForOfIteratorHelperLoose(props), _step; !(_step = _iterator()).done; ) {
    var _step$value = _step.value, key = _step$value[0], val = _step$value[1];
    target[key] = val;
  }
  return target;
};

var _sfc_main = defineComponent({
  emits: ["change"],
  props: [].concat(props, ["width", "height", "rowBuffer", "columnBuffer", "scrollbarSize", "columns", "columnSizes", "rows", "rowSizes", "fixedRows", "fixedColumns", "spanConfig"]),
  setup: function setup$1(props2, context) {
    return setup({
      props: props2,
      context,
      renderless,
      api
    });
  }
});
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock(
    "div",
    {
      class: "tiny-virtual-scroll-box",
      style: normalizeStyle(_ctx.state.ctx.boxStyle),
      onScroll: _cache[0] || (_cache[0] = function() {
        return _ctx.onScroll && _ctx.onScroll.apply(_ctx, arguments);
      })
    },
    [createElementVNode(
      "div",
      {
        class: "tiny-virtual-scroll-box__x-axis",
        style: normalizeStyle(_ctx.state.ctx.xAxisStyle)
      },
      null,
      4
      /* STYLE */
    ), createElementVNode(
      "div",
      {
        class: "tiny-virtual-scroll-box__y-axis",
        style: normalizeStyle(_ctx.state.ctx.yAxisStyle)
      },
      null,
      4
      /* STYLE */
    ), createElementVNode(
      "div",
      {
        class: "tiny-virtual-scroll-box__view",
        style: normalizeStyle(_ctx.state.ctx.viewStyle)
      },
      [renderSlot(_ctx.$slots, "default", {
        params: _ctx.state.slotParams
      })],
      4
      /* STYLE */
    )],
    36
    /* STYLE, NEED_HYDRATION */
  );
}
var pc = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);

export { pc as default };
