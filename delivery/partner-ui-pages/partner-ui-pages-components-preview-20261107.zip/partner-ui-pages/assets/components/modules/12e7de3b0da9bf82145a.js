import { defineComponent, setup, $prefix, hooks, isVue2, appProperties } from '@opentiny/vue-common';
import { renderless, api } from '@opentiny/vue-renderless/query-builder/vue';
import { random } from '@opentiny/utils';
import Button from '@opentiny/vue-button';
import { resolveComponent, openBlock, createBlock, mergeProps, withCtx, createElementBlock, Fragment, renderList, createCommentVNode, resolveDynamicComponent, createVNode, normalizeClass, toHandlers, withDirectives, vModelDynamic, createElementVNode, normalizeStyle, createTextVNode, toDisplayString, normalizeProps, guardReactiveProps, renderSlot } from 'vue';
import Select from '@opentiny/vue-select';
import Option from '@opentiny/vue-option';
import OptionGroup from '@opentiny/vue-option-group';
import Checkbox from '@opentiny/vue-checkbox';
import { IconNodeOpen, IconEditorEraser, IconPlus, IconDel, IconNode } from '@opentiny/vue-icon';
import Input$1 from '@opentiny/vue-input';
import Numeric from '@opentiny/vue-numeric';
import DatePicker from '@opentiny/vue-date-picker';
import TimePicker from '@opentiny/vue-time-picker';
import Radio from '@opentiny/vue-radio';
import '@opentiny/vue-theme/query-builder/index.css';

function _createForOfIteratorHelperLoose(r, e) {
  var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (t) return (t = t.call(r)).next.bind(t);
  if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
    t && (r = t);
    var o = 0;
    return function() {
      return o >= r.length ? { done: true } : { done: false, value: r[o++] };
    };
  }
  throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return _arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
  }
}
function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}
var _export_sfc = function _export_sfc2(sfc, props) {
  var target = sfc.__vccOpts || sfc;
  for (var _iterator = _createForOfIteratorHelperLoose(props), _step; !(_step = _iterator()).done; ) {
    var _step$value = _step.value, key = _step$value[0], val = _step$value[1];
    target[key] = val;
  }
  return target;
};

var _excluded = ["operator", "value", "handleOnChange", "title", "className", "type", "inputType", "values", "listsAsArrays", "parseNumbers", "fieldData", "disabled", "separator", "skipHook", "testID", "selectorComponent"], _excluded2 = ["controlClassnames", "controlElements", "debugMode", "enableDragAndDrop", "enableMountQueryChange", "translations"];
function _objectWithoutPropertiesLoose(r3, e) {
  if (null == r3) return {};
  var t = {};
  for (var n in r3) if ({}.hasOwnProperty.call(r3, n)) {
    if (-1 !== e.indexOf(n)) continue;
    t[n] = r3[n];
  }
  return t;
}
function _extends() {
  return _extends = Object.assign ? Object.assign.bind() : function(n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r3 in t) ({}).hasOwnProperty.call(t, r3) && (n[r3] = t[r3]);
    }
    return n;
  }, _extends.apply(null, arguments);
}
var _classLoophandler = function classLoophandler(data4) {
  if (Array.isArray(data4)) {
    return data4.filter(Boolean).map(function(item) {
      return _classLoophandler(item);
    }).filter(Boolean).join(" ");
  } else if (typeof data4 === "object") {
    var arr = Object.keys(data4).map(function(key) {
      return data4[key] && key;
    });
    return _classLoophandler(arr);
  } else {
    return data4;
  }
};
var clsx = function clsx2() {
  for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
    args[_key] = arguments[_key];
  }
  var className = _classLoophandler(args);
  return className;
};
var useContext = function useContext2(inject) {
  return inject;
};
var useMemo = function useMemo2(fn) {
  var _hooks$computed;
  return (_hooks$computed = hooks.computed(fn)) == null ? void 0 : _hooks$computed.value;
};
var useCallback = function useCallback2(fn) {
  return fn;
};
var useRef = function useRef2(refName, context) {
  var vm = context || this;
  return {
    current: vm == null ? void 0 : vm.$refs[refName]
  };
};
var HookPassive = (
  /*   */
  4
);
var currentlyRenderingFiber = null;
var workInProgressHook = null;
var currentHook = null;
function scheduleUpdateOnFiber(wip) {
  currentlyRenderingFiber.alternate = _extends({}, currentlyRenderingFiber);
  renderHooks(wip);
  currentlyRenderingFiber.update();
}
function renderHooks(wip) {
  currentlyRenderingFiber = wip;
  currentlyRenderingFiber.memorizedState = null;
  workInProgressHook = null;
}
function updateWorkInProgressHook() {
  var instance = hooks.getCurrentInstance();
  if (isVue2) {
    instance = instance.proxy;
  }
  if (!currentlyRenderingFiber || currentlyRenderingFiber.uid !== instance.uid) {
    renderHooks(instance);
  }
  var current = currentlyRenderingFiber.alternate;
  var hook;
  if (current) {
    currentlyRenderingFiber.memorizedState = current.memorizedState;
    if (workInProgressHook) {
      hook = workInProgressHook = workInProgressHook.next;
      currentHook = currentHook.next;
    } else {
      hook = workInProgressHook = current.memorizedState;
      currentHook = current.memorizedState;
    }
  } else {
    currentHook = null;
    hook = {
      memorizedState: null,
      next: null
    };
    if (workInProgressHook) {
      workInProgressHook = workInProgressHook.next = hook;
    } else {
      workInProgressHook = currentlyRenderingFiber.memorizedState = hook;
    }
  }
  return hook;
}
function useState(initalState) {
  return useReducer(null, initalState);
}
function useReducer(reducer, initalState) {
  var hook = updateWorkInProgressHook();
  if (!currentlyRenderingFiber.alternate) {
    hook.memorizedState = initalState;
  }
  var dispatch = dispatchReducerAction.bind(null, currentlyRenderingFiber, hook, reducer);
  return [hook.memorizedState, dispatch];
}
function dispatchReducerAction(fiber, hook, reducer, action) {
  hook.memorizedState = reducer ? reducer(hook.memorizedState, action) : action;
  scheduleUpdateOnFiber(fiber);
}
function updateEffectImp(hookFlags, create, deps) {
  var hook = updateWorkInProgressHook();
  if (currentHook) {
    var prevEffect = currentHook.memorizedState;
    if (deps) {
      var prevDeps = prevEffect.deps;
      if (areHookInputsEqual(deps, prevDeps)) {
        return;
      }
    }
  }
  var effect = {
    hookFlags,
    create,
    deps
  };
  hook.memorizedState = effect;
  invokeHooks(hookFlags, hook);
}
function useEffect(create, deps) {
  return updateEffectImp(HookPassive, create, deps);
}
function areHookInputsEqual(nextDeps, prevDeps) {
  if (prevDeps === null) {
    return false;
  }
  for (var i = 0; i < prevDeps.length && i < nextDeps.length; i++) {
    if (Object.is(nextDeps[i], prevDeps[i])) {
      continue;
    }
    return false;
  }
  return true;
}
function invokeHooks(hookFlags, hook) {
  {
    postMessage(hook.memorizedState.create);
  }
}
var postMessage = function postMessage2(create) {
  var _MessageChannel = new MessageChannel(), port1 = _MessageChannel.port1, port2 = _MessageChannel.port2;
  port1.onmessage = function() {
    create();
  };
  port2.postMessage(null);
};
var placeholderName = "~";
var placeholderLabel = "------";
var defaultPlaceholderFieldName = placeholderName;
var defaultPlaceholderFieldLabel = placeholderLabel;
var defaultPlaceholderFieldGroupLabel = placeholderLabel;
var defaultPlaceholderOperatorName = placeholderName;
var defaultPlaceholderOperatorLabel = placeholderLabel;
var defaultPlaceholderOperatorGroupLabel = placeholderLabel;
var defaultJoinChar = ",";
var defaultTranslations = {
  fields: {
    title: "字段",
    placeholderName: defaultPlaceholderFieldName,
    placeholderLabel: defaultPlaceholderFieldLabel,
    placeholderGroupLabel: defaultPlaceholderFieldGroupLabel
  },
  operators: {
    title: "操作符",
    placeholderName: defaultPlaceholderOperatorName,
    placeholderLabel: defaultPlaceholderOperatorLabel,
    placeholderGroupLabel: defaultPlaceholderOperatorGroupLabel
  },
  value: {
    title: "值"
  },
  removeRule: {
    label: "x",
    title: "移除规则"
  },
  clearData: {
    label: "",
    title: "清除数据"
  },
  removeGroup: {
    label: "x",
    title: "移除条件组"
  },
  addRule: {
    label: "添加规则",
    title: "添加规则"
  },
  addGroup: {
    label: "新增子条件组",
    title: "新增子条件组"
  },
  combinators: {
    title: "Combinators"
  },
  notToggle: {
    label: "Not",
    title: "反转条件组"
  },
  cloneRule: {
    label: "⧉",
    title: "复制规则"
  },
  cloneRuleGroup: {
    label: "⧉",
    title: "复制条件组"
  },
  dragHandle: {
    label: "⁞⁞",
    title: "拖拽"
  },
  lockRule: {
    label: "🔓",
    title: "锁定规则"
  },
  lockGroup: {
    label: "🔓",
    title: "锁定条件组"
  },
  lockRuleDisabled: {
    label: "🔒",
    title: "解锁规则"
  },
  lockGroupDisabled: {
    label: "🔒",
    title: "解锁条件组"
  },
  valueSourceSelector: {
    title: "数据来源"
  }
};
var defaultOperators = [{
  name: "=",
  label: "="
}, {
  name: "!=",
  label: "!="
}, {
  name: "<=",
  label: "<="
}, {
  name: ">=",
  label: ">="
}, {
  name: "<",
  label: "<"
}, {
  name: ">",
  label: ">"
}, {
  name: "doesNotContain",
  label: "does not contain"
}, {
  name: "doesNotBeginWith",
  label: "does not begin with"
}, {
  name: "doesNotEndWith",
  label: "does not end with"
}, {
  name: "contains",
  label: "contains"
}, {
  name: "beginsWith",
  label: "begins with"
}, {
  name: "endsWith",
  label: "ends with"
}, {
  name: "in",
  label: "in"
}, {
  name: "notIn",
  label: "not in"
}, {
  name: "null",
  label: "is null"
}, {
  name: "notNull",
  label: "is not null"
}, {
  name: "between",
  label: "between"
}, {
  name: "notBetween",
  label: "not between"
}];
var defaultCombinators = [{
  name: "and",
  label: "且"
}, {
  name: "or",
  label: "或"
}];
var groupButtonClass = " group-button";
var standardClassnames = {
  ruleGroup: "ruleGroup",
  queryBuilder: "queryBuilder",
  header: "ruleGroup-header",
  combinators: "ruleGroup-combinators",
  body: "ruleGroup-body",
  addRule: "ruleGroup-addRule" + groupButtonClass,
  addGroup: "ruleGroup-addGroup" + groupButtonClass,
  cloneRule: "rule-cloneRule" + groupButtonClass,
  cloneGroup: "ruleGroup-cloneGroup" + groupButtonClass,
  removeGroup: "ruleGroup-remove" + groupButtonClass,
  notToggle: "ruleGroup-notToggle",
  rule: "query-builder-rule",
  fields: "rule-fields",
  operators: "rule-operators",
  value: "rule-value",
  removeRule: "rule-remove" + groupButtonClass,
  clearData: "clear-data" + groupButtonClass,
  betweenRules: "betweenRules",
  valid: "queryBuilder-valid",
  invalid: "queryBuilder-invalid",
  dndDragging: "dndDragging",
  dndOver: "dndOver",
  dndCopy: "dndCopy",
  dragHandle: "queryBuilder-dragHandle",
  disabled: "queryBuilder-disabled",
  lockRule: "rule-lock",
  lockGroup: "ruleGroup-lock",
  valueSource: "rule-valueSource",
  valueListItem: "rule-value-list-item",
  branches: "queryBuilder-branches",
  displayOnlyField: "display-only-field",
  bindProps: "bind-props"
};
var defaultControlClassnames = {
  ruleGroup: "",
  queryBuilder: "",
  header: "",
  addRule: "",
  body: "",
  combinators: "",
  cloneGroup: "",
  addGroup: "",
  removeGroup: "",
  cloneRule: "",
  rule: "",
  notToggle: "",
  operators: "",
  fields: "",
  value: "",
  clearData: "",
  lockRule: "",
  dragHandle: "",
  lockGroup: "",
  valueSource: "",
  removeRule: ""
};
var groupInvalidReasons = {
  empty: "empty",
  invalidCombinator: "invalid combinator",
  invalidIndependentCombinators: "invalid independent combinators"
};
var TestID = {
  rule: "rule",
  inlineCombinator: "inline-combinator",
  ruleGroup: "rule-group",
  addGroup: "add-group",
  cloneGroup: "clone-group",
  removeGroup: "remove-group",
  cloneRule: "clone-rule",
  addRule: "add-rule",
  combinators: "combinators",
  clearData: "clear-data",
  fields: "fields",
  removeRule: "remove-rule",
  operators: "operators",
  notToggle: "not-toggle",
  valueEditor: "value-editor",
  lockRule: "lock-rule",
  dragHandle: "drag-handle",
  valueSourceSelector: "value-source-selector",
  lockGroup: "lock-group"
};
var LogType = {
  parentPathDisabled: "action aborted: parent path disabled",
  pathDisabled: "action aborted: path is disabled",
  onAddRuleFalse: "onAddRule callback returned false",
  onAddGroupFalse: "onAddGroup callback returned false",
  onRemoveFalse: "onRemove callback returned false",
  add: "rule or group added",
  remove: "rule or group removed",
  update: "rule or group updated",
  move: "rule or group moved"
};
var splitBy = function splitBy2(str, splitChar) {
  if (splitChar === void 0) {
    splitChar = defaultJoinChar;
  }
  return typeof str === "string" ? str.split("\\" + splitChar).map(function(c) {
    return c.split(splitChar);
  }).reduce(function(prev, curr, idx) {
    if (idx === 0) {
      return curr;
    }
    return [].concat(prev.slice(0, prev.length - 1), ["" + prev[prev.length - 1] + splitChar + curr[0]], curr.slice(1));
  }, []) : [];
};
var joinWith = function joinWith2(strArr, joinChar) {
  if (joinChar === void 0) {
    joinChar = defaultJoinChar;
  }
  return strArr.map(function(str) {
    return ("" + (str != null ? str : "")).replace(new RegExp(joinChar, "g"), "\\" + joinChar);
  }).join(joinChar);
};
var trimIfString = function trimIfString2(val) {
  return typeof val === "string" ? val.trim() : val;
};
var toArray = function toArray2(v) {
  return Array.isArray(v) ? v.map(trimIfString) : typeof v === "string" ? splitBy(v, defaultJoinChar).filter(function(s) {
    return !/^\s*$/.test(s);
  }).map(function(s) {
    return s.trim();
  }) : typeof v === "number" ? [v] : [];
};
var processRuleOrStringOrRuleGroupIC = function processRuleOrStringOrRuleGroupIC2(r3) {
  return typeof r3 === "object" && "rules" in r3 ? generateRuleGroupICWithConsistentCombinators(r3) : r3;
};
var generateRuleGroupICWithConsistentCombinators = function generateRuleGroupICWithConsistentCombinators2(rg3) {
  var returnArr = [];
  var push = function push2(r3) {
    return returnArr.push(processRuleOrStringOrRuleGroupIC(r3));
  };
  var startIndex = 0;
  for (var i = 0; i < rg3.rules.length; i += 2) {
    if (rg3.rules.length === 1) {
      push(rg3.rules[0]);
    } else if (rg3.rules[i + 1] === "and") {
      startIndex = i;
      var j = 1;
      while (rg3.rules[startIndex + j] === "and") {
        i += 2;
        j += 2;
      }
      returnArr.push({
        // @ts-expect-error TS can't keep track of odd/even indexes here
        rules: rg3.rules.slice(startIndex, i + 1).map(processRuleOrStringOrRuleGroupIC)
      });
      i -= 2;
    } else if (rg3.rules[i + 1] === "or") {
      if (i === rg3.rules.length - 3 || i === 0) {
        if (rg3.rules[i - 1] === "or" || i === 0) {
          push(rg3.rules[i]);
        }
        push(rg3.rules[i + 1]);
        if (i === rg3.rules.length - 3) {
          push(rg3.rules[i + 2]);
        }
      } else {
        if (rg3.rules[i - 1] === "and") {
          push(rg3.rules[i + 1]);
        } else {
          push(rg3.rules[i]);
          push(rg3.rules[i + 1]);
        }
      }
    }
  }
  if (
    // @ts-expect-error TS still thinks returnArr has length 0
    returnArr.length === 1 && typeof returnArr[0] === "object" && "rules" in returnArr[0]
  ) {
    return _extends({}, rg3, returnArr[0]);
  }
  return _extends({}, rg3, {
    rules: returnArr
  });
};
var _convertFromIC = function convertFromIC(rg3) {
  var processedRG = generateRuleGroupICWithConsistentCombinators(rg3);
  var rulesAsMixedList = processedRG.rules.map(function(r3) {
    return typeof r3 === "string" || !("rules" in r3) ? r3 : _convertFromIC(r3);
  });
  var combinator = rulesAsMixedList.length < 2 ? "and" : rulesAsMixedList[1];
  var rules = rulesAsMixedList.filter(function(r3) {
    return typeof r3 !== "string";
  });
  return _extends({}, processedRG, {
    combinator,
    rules
  });
};
var defaultValidator = function defaultValidator2(query, validateRule) {
  var result = {};
  var _validateGroup = function validateGroup(rg3) {
    var reasons = [];
    if (rg3.rules.length === 0) {
      reasons.push(groupInvalidReasons.empty);
    } else if (!("combinator" in rg3)) {
      var invalidICs = false;
      for (var i = 0; !invalidICs && i < rg3.rules.length; i++) {
        if (typeof rg3.rules[i] === "string" && i % 2 === 0 || typeof rg3.rules[i] !== "string" && i % 2 === 1 || typeof rg3.rules[i] === "string" && i % 2 === 1 && !defaultCombinators.map(function(c) {
          return c.name;
        }).includes(rg3.rules[i])) {
          invalidICs = true;
        }
      }
      if (invalidICs) {
        reasons.push(groupInvalidReasons.invalidIndependentCombinators);
      }
    }
    if ("combinator" in rg3 && !defaultCombinators.map(function(c) {
      return c.name;
    }).includes(rg3.combinator) && rg3.rules.length > 1) {
      reasons.push(groupInvalidReasons.invalidCombinator);
    }
    if (rg3.id) {
      if (reasons.length) {
        result[rg3.id] = {
          valid: false,
          reasons
        };
      } else {
        result[rg3.id] = true;
      }
    }
    rg3.rules.forEach(function(r3) {
      if (typeof r3 === "string") ;
      else if ("rules" in r3) {
        _validateGroup(r3);
      } else if (typeof validateRule === "function") {
        result[r3.id] = validateRule(r3)[0];
      }
    });
  };
  _validateGroup(query);
  return result;
};
var numericRegex = /^\s*[+-]?(\d+|\d*\.\d+|\d+\.\d*)([Ee][+-]?\d+)?\s*$/;
var isPojo = function isPojo2(obj) {
  return obj === null || typeof obj !== "object" ? false : Object.getPrototypeOf(obj) === Object.prototype;
};
var _numerifyValues = function numerifyValues(rg3) {
  return _extends({}, rg3, {
    // @ts-expect-error TS can't keep track of odd/even indexes here
    rules: rg3.rules.map(function(r3) {
      if (typeof r3 === "string") {
        return r3;
      } else if ("rules" in r3) {
        return _numerifyValues(r3);
      }
      var value2 = r3.value;
      if (typeof value2 === "string" && numericRegex.test(value2)) {
        value2 = parseFloat(value2);
      }
      return _extends({}, r3, {
        value: value2
      });
    })
  });
};
var isValidValue = function isValidValue2(v) {
  return typeof v === "string" && v.length > 0 || typeof v === "number" && !isNaN(v) || typeof v !== "string" && typeof v !== "number";
};
var shouldRenderAsNumber = function shouldRenderAsNumber2(v, parseNumbers) {
  return !!parseNumbers && (typeof v === "number" || typeof v === "bigint" || typeof v === "string" && numericRegex.test(v));
};
var isValueProcessorLegacy = function isValueProcessorLegacy2(vp) {
  return vp.length >= 3;
};
var defaultValueProcessorByRule = function defaultValueProcessorByRule2(_ref, _temp) {
  var operator = _ref.operator, value2 = _ref.value, valueSource = _ref.valueSource;
  var _ref2 = _temp === void 0 ? {} : _temp, escapeQuotes = _ref2.escapeQuotes, parseNumbers = _ref2.parseNumbers;
  var escapeSingleQuotes = function escapeSingleQuotes2(v) {
    return typeof v !== "string" || !escapeQuotes ? v : v.replace(/'/g, "''");
  };
  var valueIsField = valueSource === "field";
  var operatorLowerCase = operator.toLowerCase();
  if (operatorLowerCase === "null" || operatorLowerCase === "notnull") {
    return "";
  } else if (operatorLowerCase === "in" || operatorLowerCase === "notin") {
    var valueAsArray = toArray(value2);
    if (valueAsArray.length > 0) {
      return "(" + valueAsArray.map(function(v) {
        return valueIsField || shouldRenderAsNumber(v, parseNumbers) ? "" + trimIfString(v) : "'" + escapeSingleQuotes(v) + "'";
      }).join(", ") + ")";
    }
    return "";
  } else if (operatorLowerCase === "between" || operatorLowerCase === "notbetween") {
    var _valueAsArray = toArray(value2);
    if (_valueAsArray.length >= 2 && isValidValue(_valueAsArray[0]) && isValidValue(_valueAsArray[1])) {
      var first = _valueAsArray[0], second = _valueAsArray[1];
      return valueIsField || shouldRenderAsNumber(first, parseNumbers) && shouldRenderAsNumber(second, parseNumbers) ? trimIfString(first) + " and " + trimIfString(second) : "'" + escapeSingleQuotes(first) + "' and '" + escapeSingleQuotes(second) + "'";
    }
    return "";
  } else if (operatorLowerCase === "contains" || operatorLowerCase === "doesnotcontain") {
    return valueIsField ? "'%' || " + value2 + " || '%'" : "'%" + escapeSingleQuotes(value2) + "%'";
  } else if (operatorLowerCase === "beginswith" || operatorLowerCase === "doesnotbeginwith") {
    return valueIsField ? value2 + " || '%'" : "'" + escapeSingleQuotes(value2) + "%'";
  } else if (operatorLowerCase === "endswith" || operatorLowerCase === "doesnotendwith") {
    return valueIsField ? "'%' || " + value2 : "'%" + escapeSingleQuotes(value2) + "'";
  } else if (typeof value2 === "boolean") {
    return ("" + value2).toUpperCase();
  }
  return valueIsField || shouldRenderAsNumber(value2, parseNumbers) ? "" + trimIfString(value2) : "'" + escapeSingleQuotes(value2) + "'";
};
var convertOperator = function convertOperator2(op) {
  return op.replace(/^(=)$/, "$1=").replace(/^notNull$/i, "!=").replace(/^null$/i, "==");
};
var negateIfNotOp = function negateIfNotOp2(op, jsonRule) {
  return /^(does)?not/i.test(op) ? {
    "!": jsonRule
  } : jsonRule;
};
var defaultRuleProcessorJsonLogic = function defaultRuleProcessorJsonLogic2(_ref3, _temp2) {
  var field = _ref3.field, operator = _ref3.operator, value2 = _ref3.value, valueSource = _ref3.valueSource;
  var _ref4 = _temp2 === void 0 ? {} : _temp2, parseNumbers = _ref4.parseNumbers;
  var valueIsField = valueSource === "field";
  var fieldObject = {
    var: field
  };
  var fieldOrNumberRenderer = function fieldOrNumberRenderer2(v) {
    return valueIsField ? {
      var: "" + v
    } : shouldRenderAsNumber(v, parseNumbers) ? parseFloat(v) : v;
  };
  if (operator === "<" || operator === "<=" || operator === "=" || operator === "!=" || operator === ">" || operator === ">=") {
    var _ref5;
    return _ref5 = {}, _ref5[convertOperator(operator)] = [fieldObject, fieldOrNumberRenderer(value2)], _ref5;
  } else if (operator === "null" || operator === "notNull") {
    var _ref6;
    return _ref6 = {}, _ref6[(operator === "notNull" ? "!" : "=") + "="] = [fieldObject, null], _ref6;
  } else if (operator === "in" || operator === "notIn") {
    var valueAsArray = toArray(value2).map(fieldOrNumberRenderer);
    if (valueAsArray.length > 0) {
      var jsonRule = {
        in: [fieldObject, valueAsArray]
      };
      return negateIfNotOp(operator, jsonRule);
    }
    return false;
  } else if (operator === "between" || operator === "notBetween") {
    var _valueAsArray2 = toArray(value2);
    if (_valueAsArray2.length >= 2 && isValidValue(_valueAsArray2[0]) && isValidValue(_valueAsArray2[1])) {
      var first = _valueAsArray2[0], second = _valueAsArray2[1];
      if (!valueIsField && shouldRenderAsNumber(first, true) && shouldRenderAsNumber(second, true)) {
        var firstNum = parseFloat(first);
        var secondNum = parseFloat(second);
        if (secondNum < firstNum) {
          var tempNum = secondNum;
          second = firstNum;
          first = tempNum;
        } else {
          first = firstNum;
          second = secondNum;
        }
      } else if (valueIsField) {
        first = {
          var: first
        };
        second = {
          var: second
        };
      }
      var _jsonRule = {
        "<=": [first, fieldObject, second]
      };
      return negateIfNotOp(operator, _jsonRule);
    }
    return false;
  } else if (operator === "contains" || operator === "doesNotContain") {
    var _jsonRule2 = {
      in: [fieldOrNumberRenderer(value2), fieldObject]
    };
    return negateIfNotOp(operator, _jsonRule2);
  } else if (operator === "beginsWith" || operator === "doesNotBeginWith") {
    var _jsonRule3 = {
      startsWith: [fieldObject, fieldOrNumberRenderer(value2)]
    };
    return negateIfNotOp(operator, _jsonRule3);
  } else if (operator === "endsWith" || operator === "doesNotEndWith") {
    var _jsonRule4 = {
      endsWith: [fieldObject, fieldOrNumberRenderer(value2)]
    };
    return negateIfNotOp(operator, _jsonRule4);
  }
  return false;
};
var isValidationResult = function isValidationResult2(vrs) {
  return isPojo(vrs) && typeof vrs.valid === "boolean";
};
var isRuleOrGroupValid = function isRuleOrGroupValid2(rg3, validationResults, validator) {
  if (typeof validationResults === "boolean") {
    return validationResults;
  }
  if (isValidationResult(validationResults)) {
    return validationResults.valid;
  }
  if (!("rules" in rg3) && typeof validator === "function") {
    var vrs = validator(rg3);
    if (typeof vrs === "boolean") {
      return vrs;
    }
    if (isValidationResult(vrs)) {
      return vrs.valid;
    }
  }
  return true;
};
var uniqByName = function uniqByName2(originalArray) {
  var newArray = [];
  var name = /* @__PURE__ */ new Set();
  originalArray.forEach(function(el) {
    if (!name.has(el.name)) {
      name.add(el.name);
      newArray.push(el);
    }
  });
  return newArray;
};
var uniqOptGroups = function uniqOptGroups2(originalArray) {
  var label = /* @__PURE__ */ new Set();
  var name = /* @__PURE__ */ new Set();
  var newArray = [];
  originalArray.forEach(function(el) {
    if (!label.has(el.label)) {
      label.add(el.label);
      var optionsForThisGroup = [];
      el.options.forEach(function(opt) {
        if (!name.has(opt.name)) {
          name.add(opt.name);
          optionsForThisGroup.push(opt);
        }
      });
      newArray.push(_extends({}, el, {
        options: optionsForThisGroup
      }));
    }
  });
  return newArray;
};
function formatQuery(ruleGroup2, options) {
  if (options === void 0) {
    options = {};
  }
  var format = "json";
  var valueProcessorInternal = defaultValueProcessorByRule;
  var ruleProcessorInternal = null;
  var validator = function validator2() {
    return true;
  };
  var fields = [];
  var validationMap = {};
  var fallbackExpression = "";
  var parseNumbers = false;
  var placeholderFieldName = defaultPlaceholderFieldName;
  var placeholderOperatorName = defaultPlaceholderOperatorName;
  if (typeof options === "string") {
    format = options.toLowerCase();
    if (format === "jsonlogic") {
      ruleProcessorInternal = defaultRuleProcessorJsonLogic;
    }
  } else {
    var _options$format, _ruleProcessorInterna, _options$validator, _options$fields, _options$fallbackExpr, _options$paramPrefix, _options$placeholderF, _options$placeholderO;
    format = ((_options$format = options.format) != null ? _options$format : "json").toLowerCase();
    var _options = options, _options$valueProcess = _options.valueProcessor, valueProcessor = _options$valueProcess === void 0 ? null : _options$valueProcess, _options$ruleProcesso = _options.ruleProcessor, ruleProcessor = _options$ruleProcesso === void 0 ? null : _options$ruleProcesso;
    if (typeof ruleProcessor === "function") {
      ruleProcessorInternal = ruleProcessor;
    }
    valueProcessorInternal = typeof valueProcessor === "function" ? function(r3, opts) {
      return isValueProcessorLegacy(valueProcessor) ? valueProcessor(r3.field, r3.operator, r3.value, r3.valueSource) : valueProcessor(r3, opts);
    } : format === "jsonlogic" ? (_ruleProcessorInterna = ruleProcessorInternal) != null ? _ruleProcessorInterna : defaultRuleProcessorJsonLogic : defaultValueProcessorByRule;
    if (Array.isArray(options.quoteFieldNamesWith)) {
      options.quoteFieldNamesWith;
    } else if (typeof options.quoteFieldNamesWith === "string") {
      [options.quoteFieldNamesWith, options.quoteFieldNamesWith];
    }
    validator = (_options$validator = options.validator) != null ? _options$validator : function() {
      return true;
    };
    fields = (_options$fields = options.fields) != null ? _options$fields : [];
    fallbackExpression = (_options$fallbackExpr = options.fallbackExpression) != null ? _options$fallbackExpr : "";
    (_options$paramPrefix = options.paramPrefix) != null ? _options$paramPrefix : ":";
    parseNumbers = !!options.parseNumbers;
    placeholderFieldName = (_options$placeholderF = options.placeholderFieldName) != null ? _options$placeholderF : defaultPlaceholderFieldName;
    placeholderOperatorName = (_options$placeholderO = options.placeholderOperatorName) != null ? _options$placeholderO : defaultPlaceholderOperatorName;
  }
  if (!fallbackExpression) {
    fallbackExpression = "(1 = 1)";
  }
  if (format === "json" || format === "json_without_ids") {
    var rg3 = parseNumbers ? _numerifyValues(ruleGroup2) : ruleGroup2;
    if (format === "json") {
      return JSON.stringify(rg3, null, 2);
    } else {
      return JSON.stringify(rg3, ["rules", "field", "value", "operator", "combinator", "not", "valueSource"]);
    }
  } else {
    if (typeof validator === "function") {
      var validationResults = validator(ruleGroup2);
      if (typeof validationResults === "boolean") {
        if (validationResults === false) {
          return format === "jsonlogic" ? false : fallbackExpression;
        }
      } else {
        validationMap = validationResults;
      }
    }
    var validatorMap = {};
    var uniqueFields = uniqByName(fields);
    uniqueFields.forEach(function(fd) {
      if (typeof fd.validator === "function") {
        validatorMap[fd.name] = fd.validator;
      }
    });
    var validateRule = function validateRule2(rule) {
      var validationResults2;
      var fieldValidator;
      if (rule.id) {
        validationResults2 = validationMap[rule.id];
      }
      if (fields.length) {
        var fieldArrs = fields.filter(function(f) {
          return f.name === rule.field;
        });
        if (fieldArrs.length) {
          var field = fieldArrs[0];
          if (typeof field.validator === "function") {
            fieldValidator = field.validator;
          }
        }
      }
      return [validationResults2, fieldValidator];
    };
    if (format === "jsonlogic") {
      var query = "combinator" in ruleGroup2 ? ruleGroup2 : _convertFromIC(ruleGroup2);
      var _processRuleGroup = function processRuleGroup(rg4) {
        var _rg$id, _ref7;
        if (!isRuleOrGroupValid(rg4, validationMap[(_rg$id = rg4.id) != null ? _rg$id : (
          /* istanbul ignore next */
          ""
        )])) {
          return false;
        }
        var processedRules = rg4.rules.map(function(rule) {
          var _ruleProcessorInterna2;
          if ("rules" in rule) {
            return _processRuleGroup(rule);
          }
          var _validateRule = validateRule(rule), validationResult = _validateRule[0], fieldValidator = _validateRule[1];
          if (!isRuleOrGroupValid(rule, validationResult, fieldValidator) || rule.field === placeholderFieldName || rule.operator === placeholderOperatorName) {
            return false;
          }
          return ((_ruleProcessorInterna2 = ruleProcessorInternal) != null ? _ruleProcessorInterna2 : valueProcessorInternal)(rule, {
            parseNumbers
          });
        }).filter(Boolean);
        if (processedRules.length === 0) {
          return false;
        }
        var jsonRuleGroup = processedRules.length === 1 ? processedRules[0] : (_ref7 = {}, _ref7[rg4.combinator] = processedRules, _ref7);
        return rg4.not ? {
          "!": jsonRuleGroup
        } : jsonRuleGroup;
      };
      return _processRuleGroup(query);
    } else {
      return "";
    }
  }
}
var getValidationClassNames = function getValidationClassNames2(validationResult) {
  var valid = typeof validationResult === "boolean" ? validationResult : typeof validationResult === "object" && validationResult !== null ? validationResult.valid : null;
  return typeof valid === "boolean" ? valid ? standardClassnames.valid : standardClassnames.invalid : "";
};
var getValueSourcesUtil = function getValueSourcesUtil2(fieldData, operator, getValueSources) {
  var fd = fieldData != null ? fieldData : (
    /* istanbul ignore else */
    {}
  );
  if (fd.valueSources) {
    if (typeof fd.valueSources === "function") {
      return fd.valueSources(operator);
    }
    return fd.valueSources;
  }
  if (getValueSources) {
    var vals = getValueSources(fd.name, operator);
    if (vals) return vals;
  }
  return ["value"];
};
var cryptoModule = globalThis.crypto;
var generateID = function generateID2() {
  return "00-0-4-2-000".replace(/[^-]/g, function(s) {
    return ((random() + ~~s) * 65536 >> s).toString(16).padStart(4, "0");
  });
};
if (cryptoModule) {
  if (typeof cryptoModule.randomUUID === "function") {
    generateID = function generateID3() {
      return cryptoModule.randomUUID();
    };
  } else if (typeof cryptoModule.getRandomValues === "function") {
    var template = [
      "".padEnd(8, "x"),
      "".padEnd(4, "x"),
      // third section starts with the UUID version
      "4".padEnd(4, "x"),
      // First character of fourth section is limited to four specific characters
      "y".padEnd(4, "x"),
      "".padEnd(12, "x")
    ].join("-");
    var position19vals = ["8", "9", "a", "b"];
    var re = /[xy]/g;
    var container = new Uint32Array(32);
    generateID = function generateID3() {
      cryptoModule.getRandomValues(container);
      var i = -1;
      return template.replace(re, function(char) {
        i++;
        return char === "y" ? position19vals[container[i] % 4] : (container[i] % 16).toString(16);
      });
    };
  }
}
var usePrevious = function usePrevious2(value2, context) {
  var ref = useRef(null, context);
  useEffect(function() {
    ref.current = value2;
  }, [value2]);
  return ref.current;
};
var useControlledOrUncontrolled = function useControlledOrUncontrolled2(_ref8) {
  var defaultQuery = _ref8.defaultQuery, queryProp = _ref8.queryProp, isFirstRender = _ref8.isFirstRender;
  var prevQueryPresent = usePrevious(!!queryProp);
  useEffect(function() {
  }, [defaultQuery, prevQueryPresent, queryProp, isFirstRender]);
};
var useDeprecatedProps = function useDeprecatedProps2(type, newPropPresent) {
  useEffect(function() {
  }, [newPropPresent, type]);
};
var getVm = function getVm2() {
  return hooks.inject("queryBuilderRoot");
};
var QueryBuilderContext = function QueryBuilderContext2(name) {
  var queryBuilderRoot = getVm();
  if (!queryBuilderRoot._provideData) {
    queryBuilderRoot._provideData = hooks.reactive({});
  }
  var value2 = name ? queryBuilderRoot._provideData[name] : queryBuilderRoot._provideData;
  return value2;
};
var isOptionGroupArray = function isOptionGroupArray2(arr) {
  return Array.isArray(arr) && arr.length > 0 && "options" in arr[0];
};
var getOption = function getOption2(arr, name) {
  return (isOptionGroupArray(arr) ? arr.flatMap(function(og) {
    return og.options;
  }) : arr).find(function(op) {
    return op.name === name;
  });
};
var getFirstOption = function getFirstOption2(arr) {
  return !Array.isArray(arr) || arr.length === 0 ? null : isOptionGroupArray(arr) ? arr[0].options[0].name : arr[0].name;
};
var _sfc_main$e = defineComponent({
  components: {
    TinySelect: Select,
    TinyOption: Option,
    TinyOptionGroup: OptionGroup
  },
  props: ["className", "handleOnChange", "options", "title", "value", "multiple", "listsAsArrays", "disabled", "testID", "bindProps"],
  setup: function setup() {
    return {
      isOptionGroupArray
    };
  },
  computed: {
    valueSelector: function valueSelector() {
      var handleOnChange = this.handleOnChange, value2 = this.value, multiple = this.multiple, listsAsArrays = this.listsAsArrays;
      return useValueSelector({
        handleOnChange,
        listsAsArrays,
        multiple,
        value: value2
      });
    },
    selectElementChangeHandler: function selectElementChangeHandler() {
      var onChange = this.valueSelector.onChange;
      var multiple = this.multiple;
      return useSelectElementChangeHandler({
        multiple,
        onChange
      });
    }
  },
  methods: {
    isSelected: function isSelected(data4, value2) {
      return Array.isArray(data4) ? data4.includes(value2) : data4 === value2;
    }
  }
});
function _sfc_render$e(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_tiny_option = resolveComponent("tiny-option");
  var _component_tiny_option_group = resolveComponent("tiny-option-group");
  var _component_tiny_select = resolveComponent("tiny-select");
  return openBlock(), createBlock(_component_tiny_select, mergeProps({
    "data-testid": _ctx.testID,
    class: _ctx.className + " query-builder-select",
    modelValue: _ctx.valueSelector.val,
    "onUpdate:modelValue": _cache[0] || (_cache[0] = function($event) {
      return _ctx.valueSelector.val = $event;
    }),
    value: _ctx.valueSelector.val,
    title: _ctx.title,
    disabled: _ctx.disabled,
    multiple: !!_ctx.multiple
  }, _ctx.bindProps, {
    onChange: _ctx.selectElementChangeHandler,
    "hover-expand": ""
  }), {
    default: withCtx(function() {
      return [_ctx.isOptionGroupArray(_ctx.options) ? (openBlock(true), createElementBlock(
        Fragment,
        {
          key: 0
        },
        renderList(_ctx.options, function(og) {
          return openBlock(), createBlock(_component_tiny_option_group, {
            key: og.label,
            label: og.label
          }, {
            default: withCtx(function() {
              return [(openBlock(true), createElementBlock(
                Fragment,
                null,
                renderList(og.options, function(opt) {
                  return openBlock(), createBlock(_component_tiny_option, {
                    key: opt.name,
                    value: opt.name,
                    label: opt.label,
                    selected: _ctx.isSelected(_ctx.value, opt.name)
                  }, null, 8, ["value", "label", "selected"]);
                }),
                128
                /* KEYED_FRAGMENT */
              ))];
            }),
            _: 2
            /* DYNAMIC */
          }, 1032, ["label"]);
        }),
        128
        /* KEYED_FRAGMENT */
      )) : (openBlock(), createElementBlock(
        Fragment,
        {
          key: 1
        },
        [Array.isArray(_ctx.options) ? (openBlock(true), createElementBlock(
          Fragment,
          {
            key: 0
          },
          renderList(_ctx.options, function(opt) {
            return openBlock(), createBlock(_component_tiny_option, {
              key: opt.name,
              value: opt.name,
              label: opt.label
            }, null, 8, ["value", "label"]);
          }),
          128
          /* KEYED_FRAGMENT */
        )) : createCommentVNode("v-if", true)],
        64
        /* STABLE_FRAGMENT */
      ))];
    }),
    _: 1
    /* STABLE */
  }, 16, ["data-testid", "class", "modelValue", "value", "title", "disabled", "multiple", "onChange"]);
}
var ValueSelector = /* @__PURE__ */ _export_sfc(_sfc_main$e, [["render", _sfc_render$e]]);
var _sfc_main$d = defineComponent({
  props: ["component", "independentCombinators", "rules", "options", "value", "handleOnChange", "className", "path", "level", "title", "disabled", "context", "validation", "testID", "schema"],
  setup: function setup2() {
    return {
      standardClassnames,
      TestID
    };
  },
  computed: {
    otherProps: function otherProps() {
      var otherProps2 = _extends({}, this.$props);
      delete otherProps2.component;
      delete otherProps2.independentCombinators;
      return otherProps2;
    },
    CombinatorSelectorComponent: function CombinatorSelectorComponent() {
      return ValueSelector;
    }
  }
});
var _hoisted_1$8 = ["data-testid"];
function _sfc_render$d(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", {
    class: normalizeClass(_ctx.standardClassnames.betweenRules),
    "data-testid": _ctx.TestID.inlineCombinator
  }, [(openBlock(), createBlock(resolveDynamicComponent(_ctx.CombinatorSelectorComponent), mergeProps(_ctx.otherProps, {
    "test-i-d": _ctx.TestID.combinators
  }), null, 16, ["test-i-d"]))], 10, _hoisted_1$8);
}
var InlineCombinator = /* @__PURE__ */ _export_sfc(_sfc_main$d, [["render", _sfc_render$d]]);
var _sfc_main$c = defineComponent({
  components: {
    TinyCheckbox: Checkbox
  },
  props: {
    className: {
      type: String
    },
    handleOnChange: {
      type: Function
    },
    title: {
      type: String,
      default: ""
    },
    label: {
      type: String
    },
    checked: {
      type: Boolean,
      default: false
    },
    disabled: {
      type: Boolean,
      default: false
    },
    testID: {
      type: String
    }
  },
  setup: function setup3(props) {
    return {
      value: props.checked
    };
  },
  watch: {
    checked: function checked() {
      this.value = this.checked;
    }
  }
});
function _sfc_render$c(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_tiny_checkbox = resolveComponent("tiny-checkbox");
  return openBlock(), createBlock(_component_tiny_checkbox, {
    modelValue: _ctx.value,
    "onUpdate:modelValue": _cache[0] || (_cache[0] = function($event) {
      return _ctx.value = $event;
    }),
    disabled: _ctx.disabled,
    "data-testid": _ctx.testID,
    class: normalizeClass(_ctx.className),
    title: _ctx.title,
    onChange: _cache[1] || (_cache[1] = function($event) {
      return _ctx.handleOnChange(_ctx.value);
    })
  }, {
    default: withCtx(function() {
      return [createTextVNode(
        toDisplayString(_ctx.label),
        1
        /* TEXT */
      )];
    }),
    _: 1
    /* STABLE */
  }, 8, ["modelValue", "disabled", "data-testid", "class", "title"]);
}
var NotToggle = /* @__PURE__ */ _export_sfc(_sfc_main$c, [["render", _sfc_render$c]]);
var RulePropsParam$1 = ["rule", "field", "operator", "value", "valueSource", "id", "path", "parentDisabled", "translations", "schema", "actions", "disabled", "context", "isDragging", "dragMonitorId", "isOver", "dropMonitorId", "dragRef", "dndRef", "dropEffect"];
var UseRuleProps = ["classNames", "cloneRule", "fieldData", "generateOnChangeHandler", "hideValueControls", "inputType", "operators", "outerClassName", "removeRule", "clearData", "toggleLockRule", "validationResult", "valueEditorSeparator", "valueEditorType", "values", "valueSourceOptions", "onlyOne", "valueSources"];
var _sfc_main$b = defineComponent({
  name: "RuleComponents",
  components: {
    IconNodeOpen: IconNodeOpen(),
    IconEditorEraser: IconEditorEraser()
  },
  inject: ["queryBuilderRoot"],
  props: [].concat(RulePropsParam$1, UseRuleProps),
  // :RuleComponents
  setup: function setup4() {
    return {
      TestID
    };
  },
  computed: {
    r: function r() {
      return _extends({}, this.$props);
    },
    controls: function controls() {
      var _this$r$schema$contro = this.r.schema.controls, dragHandle = _this$r$schema$contro.dragHandle, fieldSelector = _this$r$schema$contro.fieldSelector, operatorSelector = _this$r$schema$contro.operatorSelector, valueSourceSelector = _this$r$schema$contro.valueSourceSelector, valueEditor = _this$r$schema$contro.valueEditor, cloneRuleAction = _this$r$schema$contro.cloneRuleAction, lockRuleAction = _this$r$schema$contro.lockRuleAction, clearRuleAction = _this$r$schema$contro.clearRuleAction, removeRuleAction = _this$r$schema$contro.removeRuleAction, clearDataAction = _this$r$schema$contro.clearDataAction;
      return {
        dragHandle,
        fieldSelector,
        operatorSelector,
        valueSourceSelector,
        valueEditor,
        cloneRuleAction,
        lockRuleAction,
        clearRuleAction,
        removeRuleAction,
        clearDataAction
      };
    }
  },
  data: function data() {
    var zero = "zeroOperator";
    var two = "twoOperator";
    return {
      lastOperator: "",
      operatorMap: {
        "null": zero,
        "notNull": zero,
        "between": two,
        "notBetween": two
      }
    };
  },
  methods: {
    sameTypeOperator: function sameTypeOperator(val) {
      return this.operatorMap[this.lastOperator] === this.operatorMap[val];
    },
    operatorChangeHandler: function operatorChangeHandler() {
      return this.r.generateOnChangeHandler("operator");
    },
    operatorChange: function operatorChange(val) {
      this.r.generateOnChangeHandler("operator")(val);
      if (!this.sameTypeOperator(val)) {
        this.r.generateOnChangeHandler("value")("");
      }
      this.lastOperator = val;
    }
  },
  mounted: function mounted() {
    this.lastOperator = this.r.rule.operator;
  }
});
var _hoisted_1$7 = {
  class: "rule--wrap"
};
var _hoisted_2$3 = /* @__PURE__ */ createElementVNode(
  "span",
  {
    class: "btn-font"
  },
  "⧉",
  -1
  /* HOISTED */
);
var _hoisted_3$2 = /* @__PURE__ */ createElementVNode(
  "span",
  {
    class: "btn-font"
  },
  "🔓",
  -1
  /* HOISTED */
);
function _sfc_render$b(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_IconEditorEraser = resolveComponent("IconEditorEraser");
  var _component_IconNodeOpen = resolveComponent("IconNodeOpen");
  return openBlock(), createElementBlock("div", _hoisted_1$7, [_ctx.r.schema.enableDragAndDrop ? (openBlock(), createBlock(resolveDynamicComponent(_ctx.controls.dragHandle), {
    key: 0,
    ref: _ctx.r.dragRef,
    "test-i-d": _ctx.TestID.dragHandle,
    level: _ctx.r.path.length,
    path: _ctx.r.path,
    title: _ctx.r.translations.dragHandle.title,
    label: _ctx.r.translations.dragHandle.label,
    "class-name": _ctx.r.classNames.dragHandle,
    disabled: _ctx.r.disabled,
    context: _ctx.r.context,
    validation: _ctx.r.validationResult,
    schema: _ctx.r.schema
  }, null, 8, ["test-i-d", "level", "path", "title", "label", "class-name", "disabled", "context", "validation", "schema"])) : createCommentVNode("v-if", true), (openBlock(), createBlock(resolveDynamicComponent(_ctx.controls.fieldSelector), {
    "test-i-d": _ctx.TestID.fields,
    options: _ctx.r.schema.fields,
    title: _ctx.r.translations.fields.title,
    value: _ctx.r.rule.field,
    operator: _ctx.r.rule.operator,
    "class-name": _ctx.r.classNames.fields,
    "handle-on-change": _ctx.r.generateOnChangeHandler("field"),
    level: _ctx.r.path.length,
    path: _ctx.r.path,
    disabled: _ctx.r.disabled,
    context: _ctx.r.context,
    validation: _ctx.r.validationResult,
    schema: _ctx.r.schema,
    "bind-props": _ctx.r.schema.bindProps && _ctx.r.schema.bindProps.leftSelect || {}
  }, null, 8, ["test-i-d", "options", "title", "value", "operator", "class-name", "handle-on-change", "level", "path", "disabled", "context", "validation", "schema", "bind-props"])), _ctx.r.schema.autoSelectField || _ctx.r.rule.field !== _ctx.r.translations.fields.placeholderName ? (openBlock(), createBlock(resolveDynamicComponent(_ctx.controls.operatorSelector), {
    key: 1,
    "test-i-d": _ctx.TestID.operators,
    field: _ctx.r.rule.field,
    "field-data": _ctx.r.fieldData,
    title: _ctx.r.translations.operators.title,
    options: _ctx.r.operators,
    value: _ctx.r.rule.operator,
    "class-name": _ctx.r.classNames.operators,
    "handle-on-change": _ctx.operatorChange,
    level: _ctx.r.path.length,
    path: _ctx.r.path,
    disabled: _ctx.r.disabled,
    context: _ctx.r.context,
    validation: _ctx.r.validationResult,
    schema: _ctx.r.schema,
    bindProps: _ctx.r.schema.bindProps && _ctx.r.schema.bindProps.midSelect || {}
  }, null, 8, ["test-i-d", "field", "field-data", "title", "options", "value", "class-name", "handle-on-change", "level", "path", "disabled", "context", "validation", "schema", "bindProps"])) : createCommentVNode("v-if", true), (_ctx.r.schema.autoSelectOperator || _ctx.r.rule.operator !== _ctx.r.translations.operators.placeholderName) && !_ctx.r.hideValueControls ? (openBlock(), createElementBlock(
    Fragment,
    {
      key: 2
    },
    [!["null", "notNull"].includes(_ctx.r.rule.operator) && _ctx.r.valueSources.length > 1 ? (openBlock(), createBlock(resolveDynamicComponent(_ctx.controls.valueSourceSelector), {
      key: 0,
      "test-i-d": _ctx.TestID.valueSourceSelector,
      field: _ctx.r.rule.field,
      "field-data": _ctx.r.fieldData,
      title: _ctx.r.translations.valueSourceSelector.title,
      options: _ctx.r.valueSourceOptions,
      value: _ctx.r.rule.valueSource === void 0 || null ? "value" : _ctx.r.rule.valueSource,
      "class-name": _ctx.r.classNames.valueSource,
      "handle-on-change": _ctx.r.generateOnChangeHandler("valueSource"),
      level: _ctx.r.path.length,
      path: _ctx.r.path,
      disabled: _ctx.r.disabled,
      context: _ctx.r.context,
      validation: _ctx.r.validationResult,
      schema: _ctx.r.schema,
      "bind-props": _ctx.r.schema.bindProps && _ctx.r.schema.bindProps.select || {}
    }, null, 8, ["test-i-d", "field", "field-data", "title", "options", "value", "class-name", "handle-on-change", "level", "path", "disabled", "context", "validation", "schema", "bind-props"])) : createCommentVNode("v-if", true), (openBlock(), createBlock(resolveDynamicComponent(_ctx.controls.valueEditor), {
      "test-i-d": _ctx.TestID.valueEditor,
      field: _ctx.r.rule.field,
      "field-data": _ctx.r.fieldData,
      title: _ctx.r.translations.title,
      operator: _ctx.r.rule.operator,
      value: _ctx.r.rule.value,
      "value-source": _ctx.r.rule.valueSource === void 0 || null ? "value" : _ctx.r.rule.valueSource,
      type: _ctx.r.valueEditorType,
      "input-type": _ctx.r.inputType,
      values: _ctx.r.values,
      "lists-as-arrays": _ctx.r.schema.listsAsArrays,
      "parse-numbers": _ctx.r.schema.parseNumbers,
      separator: _ctx.r.valueEditorSeparator,
      "class-name": _ctx.r.classNames.value,
      "handle-on-change": _ctx.r.generateOnChangeHandler("value"),
      level: _ctx.r.path.length,
      path: _ctx.r.path,
      disabled: _ctx.r.disabled,
      context: _ctx.r.context,
      validation: _ctx.r.validationResult,
      schema: _ctx.r.schema
    }, null, 8, ["test-i-d", "field", "field-data", "title", "operator", "value", "value-source", "type", "input-type", "values", "lists-as-arrays", "parse-numbers", "separator", "class-name", "handle-on-change", "level", "path", "disabled", "context", "validation", "schema"]))],
    64
    /* STABLE_FRAGMENT */
  )) : createCommentVNode("v-if", true), _ctx.r.schema.showCloneButtons ? (openBlock(), createBlock(resolveDynamicComponent(_ctx.controls.cloneRuleAction), {
    key: 3,
    "test-i-d": _ctx.TestID.cloneRule,
    label: _ctx.r.translations.cloneRule.label,
    title: _ctx.r.translations.cloneRule.title,
    "class-name": _ctx.r.classNames.cloneRule,
    "handle-on-click": _ctx.r.cloneRule,
    level: _ctx.r.path.length,
    path: _ctx.r.path,
    disabled: _ctx.r.disabled,
    context: _ctx.r.context,
    validation: _ctx.r.validationResult,
    "rule-or-group": _ctx.r.rule,
    schema: _ctx.r.schema
  }, {
    default: withCtx(function() {
      return [_hoisted_2$3];
    }),
    _: 1
    /* STABLE */
  }, 8, ["test-i-d", "label", "title", "class-name", "handle-on-click", "level", "path", "disabled", "context", "validation", "rule-or-group", "schema"])) : createCommentVNode("v-if", true), _ctx.r.schema.showLockButtons ? (openBlock(), createBlock(resolveDynamicComponent(_ctx.controls.lockRuleAction), {
    key: 4,
    "test-i-d": _ctx.TestID.lockRule,
    label: _ctx.r.translations.lockRule.label,
    title: _ctx.r.translations.lockRule.title,
    "class-name": _ctx.r.classNames.lockRule,
    "handle-on-click": _ctx.r.toggleLockRule,
    level: _ctx.r.path.length,
    path: _ctx.r.path,
    disabled: _ctx.r.disabled,
    "disabled-translation": _ctx.r.parentDisabled ? void 0 : _ctx.r.translations.lockRuleDisabled,
    context: _ctx.r.context,
    validation: _ctx.r.validationResult,
    "rule-or-group": _ctx.r.rule,
    schema: _ctx.r.schema
  }, {
    default: withCtx(function() {
      return [_hoisted_3$2];
    }),
    _: 1
    /* STABLE */
  }, 8, ["test-i-d", "label", "title", "class-name", "handle-on-click", "level", "path", "disabled", "disabled-translation", "context", "validation", "rule-or-group", "schema"])) : createCommentVNode("v-if", true), _ctx.queryBuilderRoot.showClearBtn ? (openBlock(), createBlock(resolveDynamicComponent(_ctx.controls.clearDataAction), {
    key: 5,
    "test-i-d": _ctx.TestID.clearData,
    label: _ctx.r.translations.clearData.label,
    title: _ctx.r.translations.clearData.title,
    "class-name": _ctx.r.classNames.clearData,
    "handle-on-click": _ctx.r.clearData,
    level: _ctx.r.path.length,
    path: _ctx.r.path,
    disabled: _ctx.r.disabled,
    context: _ctx.r.context,
    validation: _ctx.r.validationResult,
    "rule-or-group": _ctx.r.rule,
    schema: _ctx.r.schema
  }, {
    default: withCtx(function() {
      return [createVNode(_component_IconEditorEraser, {
        class: "btn-icon"
      })];
    }),
    _: 1
    /* STABLE */
  }, 8, ["test-i-d", "label", "title", "class-name", "handle-on-click", "level", "path", "disabled", "context", "validation", "rule-or-group", "schema"])) : (openBlock(), createBlock(resolveDynamicComponent(_ctx.controls.removeRuleAction), {
    key: 6,
    "test-i-d": _ctx.TestID.removeRule,
    label: _ctx.r.translations.removeRule.label,
    title: _ctx.r.translations.removeRule.title,
    "class-name": _ctx.r.classNames.removeRule,
    "handle-on-click": _ctx.r.removeRule,
    level: _ctx.r.path.length,
    path: _ctx.r.path,
    disabled: _ctx.r.disabled,
    context: _ctx.r.context,
    validation: _ctx.r.validationResult,
    "rule-or-group": _ctx.r.rule,
    schema: _ctx.r.schema
  }, {
    default: withCtx(function() {
      return [createVNode(_component_IconNodeOpen, {
        class: "btn-icon"
      })];
    }),
    _: 1
    /* STABLE */
  }, 8, ["test-i-d", "label", "title", "class-name", "handle-on-click", "level", "path", "disabled", "context", "validation", "rule-or-group", "schema"]))]);
}
var RuleComponents = /* @__PURE__ */ _export_sfc(_sfc_main$b, [["render", _sfc_render$b]]);
var RulePropsParam = ["rule", "field", "operator", "value", "valueSource", "id", "path", "parentDisabled", "translations", "schema", "actions", "disabled", "context", "isDragging", "dragMonitorId", "isOver", "dropMonitorId", "dragRef", "dndRef", "onlyOne", "dropEffect"];
var _sfc_main$a = defineComponent({
  name: "Rule",
  components: {
    RuleComponents
  },
  props: [].concat(RulePropsParam),
  // :RuleProps
  setup: function setup5() {
    return {
      TestID
    };
  },
  computed: {
    r: function r2() {
      return _extends({}, this.$props, useRule(this.$props));
    },
    RuleComponentProps: function RuleComponentProps() {
      var r3 = this.r;
      var _map = [r3.cloneRule, r3.toggleLockRule, r3.removeRule, r3.clearData].map(function(f) {
        return function(event) {
          event.preventDefault();
          event.stopPropagation();
          f();
        };
      }), cloneRule = _map[0], toggleLockRule = _map[1], removeRule = _map[2], clearData = _map[3];
      return _extends({}, this.r, {
        cloneRule,
        toggleLockRule,
        removeRule,
        clearData
      });
    }
  }
});
var _hoisted_1$6 = ["data-testid", "data-dragmonitorid", "data-dropmonitorid", "data-rule-id", "data-level", "data-path"];
function _sfc_render$a(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_RuleComponents = resolveComponent("RuleComponents");
  return openBlock(), createElementBlock("div", {
    ref: _ctx.r.dndRef,
    "data-testid": _ctx.TestID.rule,
    "data-dragmonitorid": _ctx.r.dragMonitorId,
    "data-dropmonitorid": _ctx.r.dropMonitorId,
    class: normalizeClass(_ctx.r.outerClassName),
    "data-rule-id": _ctx.r.id,
    "data-level": _ctx.r.path.length,
    "data-path": JSON.stringify(_ctx.r.path)
  }, [createVNode(
    _component_RuleComponents,
    normalizeProps(guardReactiveProps(_ctx.RuleComponentProps)),
    null,
    16
    /* FULL_PROPS */
  )], 10, _hoisted_1$6);
}
var Rule = /* @__PURE__ */ _export_sfc(_sfc_main$a, [["render", _sfc_render$a]]);
var RuleGroupProps$1 = ["ruleGroup", "combinator", "rules", "not", "id", "path", "parentDisabled", "translations", "schema", "actions", "disabled", "context", "isDragging", "dragMonitorId", "isOver", "dropMonitorId", "previewRef", "dragRef", "dropRef", "dropEffect", "addGroup", "addRule", "classNames", "cloneGroup", "onCombinatorChange", "onGroupAdd", "onIndependentCombinatorChange", "onNotToggleChange", "outerClassName", "removeGroup", "toggleLockGroup", "validationClassName", "onlyOne", "validationResult"];
var _sfc_main$9 = defineComponent({
  name: "RuleGroupBodyComponents",
  props: [].concat(RuleGroupProps$1),
  // :RuleGroupProps
  setup: function setup6() {
    return {
      TestID
    };
  },
  computed: {
    rg: function rg() {
      return _extends({}, this.$props);
    },
    controls: function controls2() {
      var _this$rg$schema$contr = this.rg.schema.controls, inlineCombinator = _this$rg$schema$contr.inlineCombinator, ruleGroup2 = _this$rg$schema$contr.ruleGroup, rule = _this$rg$schema$contr.rule;
      return {
        inlineCombinator,
        ruleGroup: ruleGroup2,
        rule
      };
    },
    getFields: function getFields() {
      var _this = this;
      return this.rg.ruleGroup.rules.map(function(r3, idx) {
        var rg3 = _this.rg;
        var thisPath = [].concat(rg3.path, [idx]);
        var thisPathDisabled = rg3.disabled || typeof r3 !== "string" && r3.disabled || rg3.schema.disabledPaths.some(function(p) {
          return pathsAreEqual(thisPath, p);
        });
        var key = typeof r3 === "string" ? [].concat(thisPath, [r3]).join("-") : r3.id;
        return {
          thisPathDisabled,
          key,
          thisPath
        };
      });
    }
  }
});
function _sfc_render$9(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock(
    "div",
    {
      class: normalizeClass(_ctx.rg.classNames.body)
    },
    [(openBlock(true), createElementBlock(
      Fragment,
      null,
      renderList(_ctx.rg.ruleGroup.rules, function(r3, idx) {
        return openBlock(), createElementBlock("div", {
          key: _ctx.getFields[idx].key
        }, [idx > 0 && !_ctx.rg.schema.independentCombinators && _ctx.rg.schema.showCombinatorsBetweenRules ? (openBlock(), createBlock(resolveDynamicComponent(_ctx.controls.inlineCombinator), {
          key: 0,
          options: _ctx.rg.schema.combinators,
          value: _ctx.rg.combinator,
          title: _ctx.rg.translations.combinators.title,
          "class-name": _ctx.rg.classNames.combinators,
          "handle-on-change": _ctx.rg.onCombinatorChange,
          rules: _ctx.rg.ruleGroup.rules,
          level: _ctx.rg.path.length,
          context: _ctx.rg.context,
          validation: _ctx.rg.validationResult,
          component: _ctx.controls.combinatorSelector,
          path: _ctx.getFields[idx].thisPath,
          disabled: _ctx.rg.disabled,
          "independent-combinators": _ctx.rg.schema.independentCombinators,
          schema: _ctx.rg.schema
        }, null, 8, ["options", "value", "title", "class-name", "handle-on-change", "rules", "level", "context", "validation", "component", "path", "disabled", "independent-combinators", "schema"])) : createCommentVNode("v-if", true), typeof r3 === "string" ? (openBlock(), createBlock(resolveDynamicComponent(_ctx.controls.inlineCombinator), {
          key: 1,
          options: _ctx.rg.schema.combinators,
          value: r3,
          title: _ctx.rg.translations.combinators.title,
          "class-name": _ctx.rg.classNames.combinators,
          "handle-on-change": function handleOnChange(val) {
            return _ctx.rg.onIndependentCombinatorChange(val, idx);
          },
          rules: _ctx.rg.ruleGroup.rules,
          level: _ctx.rg.path.length,
          context: _ctx.rg.context,
          validation: _ctx.rg.validationResult,
          component: _ctx.CombinatorSelectorControlElement,
          path: _ctx.getFields[idx].thisPath,
          disabled: _ctx.getFields[idx].thisPathDisabled,
          "independent-combinators": _ctx.rg.schema.independentCombinators,
          schema: _ctx.rg.schema
        }, null, 8, ["options", "value", "title", "class-name", "handle-on-change", "rules", "level", "context", "validation", "component", "path", "disabled", "independent-combinators", "schema"])) : "rules" in r3 ? (openBlock(), createBlock(resolveDynamicComponent(_ctx.controls.ruleGroup), {
          key: 2,
          id: r3.id,
          schema: _ctx.rg.schema,
          actions: _ctx.rg.actions,
          path: _ctx.getFields[idx].thisPath,
          translations: _ctx.rg.translations,
          "rule-group": r3,
          rules: r3.rules,
          combinator: "combinator" in r3 ? r3.combinator : void 0,
          not: !!r3.not,
          disabled: _ctx.getFields[idx].thisPathDisabled,
          "parent-disabled": _ctx.rg.parentDisabled || _ctx.rg.disabled,
          context: _ctx.rg.context
        }, null, 8, ["id", "schema", "actions", "path", "translations", "rule-group", "rules", "combinator", "not", "disabled", "parent-disabled", "context"])) : (openBlock(), createBlock(resolveDynamicComponent(_ctx.controls.rule), {
          key: 3,
          id: r3.id,
          rule: r3,
          field: r3.field,
          operator: r3.operator,
          value: r3.value,
          "value-source": r3.valueSource,
          schema: _ctx.rg.schema,
          actions: _ctx.rg.actions,
          path: _ctx.getFields[idx].thisPath,
          disabled: _ctx.getFields[idx].thisPathDisabled,
          "parent-disabled": _ctx.rg.parentDisabled || _ctx.rg.disabled,
          translations: _ctx.rg.translations,
          context: _ctx.rg.context,
          "only-one": _ctx.onlyOne
        }, null, 8, ["id", "rule", "field", "operator", "value", "value-source", "schema", "actions", "path", "disabled", "parent-disabled", "translations", "context", "only-one"]))]);
      }),
      128
      /* KEYED_FRAGMENT */
    ))],
    2
    /* CLASS */
  );
}
var RuleGroupBodyComponents = /* @__PURE__ */ _export_sfc(_sfc_main$9, [["render", _sfc_render$9]]);
var RuleGroupProps = ["ruleGroup", "combinator", "rules", "not", "id", "path", "parentDisabled", "translations", "schema", "actions", "disabled", "context", "isDragging", "dragMonitorId", "isOver", "dropMonitorId", "previewRef", "dragRef", "dropRef", "dropEffect", "addGroup", "addRule", "classNames", "cloneGroup", "onCombinatorChange", "onGroupAdd", "onIndependentCombinatorChange", "onNotToggleChange", "outerClassName", "removeGroup", "toggleLockGroup", "validationClassName", "validationResult"];
var _sfc_main$8 = defineComponent({
  name: "RuleGroup",
  components: {
    TinyButton: Button,
    RuleGroupBodyComponents,
    IconPlus,
    IconDel: IconDel(),
    IconNodeOpen: IconNodeOpen(),
    IconNode: IconNode()
  },
  props: [].concat(RuleGroupProps),
  // :RuleGroupProps
  setup: function setup7() {
    return {
      TestID,
      IconPlus
    };
  },
  computed: {
    rg: function rg2() {
      return _extends({}, this.$props, useRuleGroup(this.$props));
    },
    subComponentProps: function subComponentProps() {
      var rg3 = this.rg;
      var _map2 = [rg3.addRule, rg3.addGroup, rg3.cloneGroup, rg3.toggleLockGroup, rg3.removeGroup].map(function(f) {
        return function(event, context) {
          event.preventDefault();
          event.stopPropagation();
          f(event, context);
        };
      }), addRule = _map2[0], addGroup = _map2[1], cloneGroup = _map2[2], toggleLockGroup = _map2[3], removeGroup = _map2[4];
      return _extends({}, this.rg, {
        addRule,
        addGroup,
        cloneGroup,
        toggleLockGroup,
        removeGroup,
        onlyOne: this.onlyOne
      });
    },
    controls: function controls3() {
      var _this$rg$schema$contr2 = this.rg.schema.controls, dragHandle = _this$rg$schema$contr2.dragHandle, combinatorSelector = _this$rg$schema$contr2.combinatorSelector, notToggle = _this$rg$schema$contr2.notToggle, addRuleAction = _this$rg$schema$contr2.addRuleAction, addGroupAction = _this$rg$schema$contr2.addGroupAction, cloneGroupAction = _this$rg$schema$contr2.cloneGroupAction, lockGroupAction = _this$rg$schema$contr2.lockGroupAction, removeGroupAction = _this$rg$schema$contr2.removeGroupAction;
      return {
        dragHandle,
        combinatorSelector,
        notToggle,
        addRuleAction,
        addGroupAction,
        cloneGroupAction,
        lockGroupAction,
        removeGroupAction
      };
    },
    onlyOne: function onlyOne() {
      return this.rg.ruleGroup.rules.length <= 1;
    }
  }
});
var _hoisted_1$5 = ["data-testid", "data-dragmonitorid", "data-dropmonitorid", "data-rule-group-id", "data-level", "data-path"];
var _hoisted_2$2 = {
  class: "group-rule-branches"
};
var _hoisted_3$1 = {
  class: "group-rule-body"
};
var _hoisted_4$1 = {
  class: "rule-group--wrap"
};
var _hoisted_5$1 = /* @__PURE__ */ createElementVNode(
  "span",
  {
    class: "btn-icon"
  },
  "⧉",
  -1
  /* HOISTED */
);
var _hoisted_6$1 = /* @__PURE__ */ createElementVNode(
  "div",
  {
    class: "group-rule-action"
  },
  null,
  -1
  /* HOISTED */
);
function _sfc_render$8(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_RuleGroupBodyComponents = resolveComponent("RuleGroupBodyComponents");
  var _component_tiny_button = resolveComponent("tiny-button");
  var _component_IconDel = resolveComponent("IconDel");
  return openBlock(), createElementBlock("div", {
    ref: _ctx.rg.previewRef,
    class: normalizeClass(_ctx.rg.outerClassName + (_ctx.onlyOne ? " .only-one" : "")),
    "data-testid": _ctx.TestID.ruleGroup,
    "data-dragmonitorid": _ctx.rg.dragMonitorId,
    "data-dropmonitorid": _ctx.rg.dropMonitorId,
    "data-rule-group-id": _ctx.rg.id,
    "data-level": _ctx.rg.path.length,
    "data-path": JSON.stringify(_ctx.rg.path)
  }, [createElementVNode("div", _hoisted_2$2, [!_ctx.rg.schema.showCombinatorsBetweenRules && !_ctx.rg.schema.independentCombinators && !_ctx.onlyOne ? (openBlock(), createBlock(resolveDynamicComponent(_ctx.controls.combinatorSelector), {
    key: 0,
    "test-i-d": _ctx.TestID.combinators,
    options: _ctx.rg.schema.combinators,
    value: _ctx.rg.combinator,
    title: _ctx.rg.translations.combinators.title,
    "class-name": _ctx.rg.classNames.combinators,
    "handle-on-change": _ctx.rg.onCombinatorChange,
    rules: _ctx.rg.ruleGroup.rules,
    level: _ctx.rg.path.length,
    path: _ctx.rg.path,
    disabled: _ctx.rg.disabled,
    context: _ctx.rg.context,
    validation: _ctx.rg.validationResult,
    schema: _ctx.rg.schema
  }, null, 8, ["test-i-d", "options", "value", "title", "class-name", "handle-on-change", "rules", "level", "path", "disabled", "context", "validation", "schema"])) : createCommentVNode("v-if", true)]), createElementVNode("div", _hoisted_3$1, [createVNode(
    _component_RuleGroupBodyComponents,
    normalizeProps(guardReactiveProps(_ctx.subComponentProps)),
    null,
    16
    /* FULL_PROPS */
  ), createElementVNode(
    "div",
    {
      ref: _ctx.rg.dropRef,
      class: normalizeClass(_ctx.rg.classNames.header)
    },
    [createElementVNode("div", _hoisted_4$1, [_ctx.rg.path.length > 0 && _ctx.rg.schema.enableDragAndDrop ? (openBlock(), createBlock(resolveDynamicComponent(_ctx.controls.dragHandle), {
      key: 0,
      ref: _ctx.rg.dragRef,
      "test-i-d": _ctx.TestID.dragHandle,
      level: _ctx.rg.path.length,
      path: _ctx.rg.path,
      title: _ctx.rg.translations.dragHandle.title,
      label: _ctx.rg.translations.dragHandle.label,
      "class-name": _ctx.rg.classNames.dragHandle,
      disabled: _ctx.rg.disabled,
      context: _ctx.rg.context,
      validation: _ctx.rg.validationResult,
      schema: _ctx.rg.schema
    }, null, 8, ["test-i-d", "level", "path", "title", "label", "class-name", "disabled", "context", "validation", "schema"])) : createCommentVNode("v-if", true), _ctx.rg.schema.showNotToggle ? (openBlock(), createBlock(resolveDynamicComponent(_ctx.controls.notToggle), {
      key: 1,
      "test-i-d": _ctx.TestID.notToggle,
      "class-name": _ctx.rg.classNames.notToggle,
      title: _ctx.rg.translations.notToggle.title,
      label: _ctx.rg.translations.notToggle.label,
      checked: _ctx.rg.ruleGroup.not,
      "handle-on-change": _ctx.rg.onNotToggleChange,
      level: _ctx.rg.path.length,
      disabled: _ctx.rg.disabled,
      path: _ctx.rg.path,
      context: _ctx.rg.context,
      validation: _ctx.rg.validationResult,
      schema: _ctx.rg.schema
    }, null, 8, ["test-i-d", "class-name", "title", "label", "checked", "handle-on-change", "level", "disabled", "path", "context", "validation", "schema"])) : createCommentVNode("v-if", true), _ctx.rg.schema.showNewRule ? (openBlock(), createBlock(resolveDynamicComponent(_ctx.controls.addRuleAction), {
      key: 2,
      "test-i-d": _ctx.TestID.addRule,
      label: _ctx.rg.translations.addRule.label,
      title: _ctx.rg.translations.addRule.title,
      "class-name": _ctx.rg.classNames.addRule,
      "handle-on-click": _ctx.rg.addRule,
      rules: _ctx.rg.ruleGroup.rules,
      level: _ctx.rg.path.length,
      path: _ctx.rg.path,
      disabled: _ctx.rg.disabled,
      context: _ctx.rg.context,
      validation: _ctx.rg.validationResult,
      "rule-or-group": _ctx.rg.ruleGroup,
      schema: _ctx.rg.schema
    }, {
      default: withCtx(function() {
        return [createVNode(_component_tiny_button, {
          type: "text",
          icon: _ctx.IconPlus(),
          text: _ctx.$t("ui.queryBuilder.addItem"),
          disabled: _ctx.rg.disabled || _ctx.rg.schema.isRuleDisable || _ctx.rg.schema.ruleLimit !== void 0 && _ctx.rg.ruleGroup.rules.length >= _ctx.rg.schema.ruleLimit
        }, null, 8, ["icon", "text", "disabled"])];
      }),
      _: 1
      /* STABLE */
    }, 8, ["test-i-d", "label", "title", "class-name", "handle-on-click", "rules", "level", "path", "disabled", "context", "validation", "rule-or-group", "schema"])) : createCommentVNode("v-if", true), _ctx.rg.schema.showNewGroup ? (openBlock(), createBlock(resolveDynamicComponent(_ctx.controls.addGroupAction), {
      key: 3,
      "test-i-d": _ctx.TestID.addGroup,
      label: _ctx.rg.translations.addGroup.label,
      title: _ctx.rg.translations.addGroup.title,
      "class-name": _ctx.rg.classNames.addGroup,
      "handle-on-click": _ctx.rg.addGroup,
      rules: _ctx.rg.ruleGroup.rules,
      level: _ctx.rg.path.length,
      path: _ctx.rg.path,
      disabled: _ctx.rg.disabled,
      context: _ctx.rg.context,
      validation: _ctx.rg.validationResult,
      "rule-or-group": _ctx.rg.ruleGroup,
      schema: _ctx.rg.schema
    }, {
      default: withCtx(function() {
        return [createVNode(_component_tiny_button, {
          type: "text",
          icon: _ctx.IconPlus(),
          text: _ctx.$t("ui.queryBuilder.addGroup"),
          disabled: _ctx.rg.disabled || _ctx.rg.schema.isGroupDisable || _ctx.rg.schema.groupLimit !== void 0 && _ctx.rg.path.length > _ctx.rg.schema.groupLimit
        }, null, 8, ["icon", "text", "disabled"])];
      }),
      _: 1
      /* STABLE */
    }, 8, ["test-i-d", "label", "title", "class-name", "handle-on-click", "rules", "level", "path", "disabled", "context", "validation", "rule-or-group", "schema"])) : createCommentVNode("v-if", true), _ctx.rg.path.length >= 1 ? (openBlock(), createBlock(resolveDynamicComponent(_ctx.controls.removeGroupAction), {
      key: 4,
      "test-i-d": _ctx.TestID.removeGroup,
      label: _ctx.rg.translations.removeGroup.label,
      title: _ctx.rg.translations.removeGroup.title,
      "class-name": _ctx.rg.classNames.removeGroup,
      "handle-on-click": _ctx.rg.removeGroup,
      rules: _ctx.rg.ruleGroup.rules,
      level: _ctx.rg.path.length,
      path: _ctx.rg.path,
      disabled: _ctx.rg.disabled,
      context: _ctx.rg.context,
      validation: _ctx.rg.validationResult,
      "rule-or-group": _ctx.rg.ruleGroup,
      schema: _ctx.rg.schema
    }, {
      default: withCtx(function() {
        return [createVNode(_component_IconDel, {
          class: "primary-svg"
        }), createTextVNode(
          " " + toDisplayString(_ctx.$t("ui.queryBuilder.removeGroup")),
          1
          /* TEXT */
        )];
      }),
      _: 1
      /* STABLE */
    }, 8, ["test-i-d", "label", "title", "class-name", "handle-on-click", "rules", "level", "path", "disabled", "context", "validation", "rule-or-group", "schema"])) : createCommentVNode("v-if", true), _ctx.rg.schema.showCloneButtons && _ctx.rg.path.length >= 1 ? (openBlock(), createBlock(resolveDynamicComponent(_ctx.controls.cloneGroupAction), {
      key: 5,
      "test-i-d": _ctx.TestID.cloneGroup,
      label: _ctx.rg.translations.cloneRuleGroup.label,
      title: _ctx.rg.translations.cloneRuleGroup.title,
      "class-name": _ctx.rg.classNames.cloneGroup,
      "handle-on-click": _ctx.rg.cloneGroup,
      rules: _ctx.rg.ruleGroup.rules,
      level: _ctx.rg.path.length,
      path: _ctx.rg.path,
      disabled: _ctx.rg.disabled,
      context: _ctx.rg.context,
      validation: _ctx.rg.validationResult,
      "rule-or-group": _ctx.rg.ruleGroup,
      schema: _ctx.rg.schema
    }, {
      default: withCtx(function() {
        return [_hoisted_5$1];
      }),
      _: 1
      /* STABLE */
    }, 8, ["test-i-d", "label", "title", "class-name", "handle-on-click", "rules", "level", "path", "disabled", "context", "validation", "rule-or-group", "schema"])) : createCommentVNode("v-if", true), _ctx.rg.schema.showLockButtons ? (openBlock(), createBlock(resolveDynamicComponent(_ctx.controls.lockGroupAction), {
      key: 6,
      "test-i-d": _ctx.TestID.lockGroup,
      label: _ctx.rg.translations.lockGroup.label,
      title: _ctx.rg.translations.lockGroup.title,
      "class-name": _ctx.rg.classNames.lockGroup,
      "handle-on-click": _ctx.rg.toggleLockGroup,
      rules: _ctx.rg.ruleGroup.rules,
      level: _ctx.rg.path.length,
      path: _ctx.rg.path,
      disabled: _ctx.rg.disabled,
      "disabled-translation": _ctx.rg.parentDisabled ? void 0 : _ctx.rg.translations.lockGroupDisabled,
      context: _ctx.rg.context,
      validation: _ctx.rg.validationResult,
      "rule-or-group": _ctx.rg.ruleGroup,
      schema: _ctx.rg.schema
    }, null, 8, ["test-i-d", "label", "title", "class-name", "handle-on-click", "rules", "level", "path", "disabled", "disabled-translation", "context", "validation", "rule-or-group", "schema"])) : createCommentVNode("v-if", true)])],
    2
    /* CLASS */
  )]), _hoisted_6$1], 10, _hoisted_1$5);
}
var RuleGroup = /* @__PURE__ */ _export_sfc(_sfc_main$8, [["render", _sfc_render$8]]);
var _sfc_main$7 = defineComponent({
  components: {
    TinyButton: Button
  },
  props: {
    props: Object,
    // 自定义属性，优先级高，可覆盖其他已设置属性
    className: {
      type: String
    },
    handleOnClick: {
      type: Function,
      default: function _default() {
      }
    },
    label: {
      type: String
    },
    title: {
      type: String,
      default: ""
    },
    disabled: {
      type: Boolean,
      default: false
    },
    disabledTranslation: {
      type: Object || void 0
    },
    testID: {
      type: String
    }
  },
  setup: function setup8(props, context) {
    return setup({
      props,
      context,
      renderless,
      api
    });
  },
  computed: {
    allProps: function allProps() {
      var className = this.className, title = this.title, disabled = this.disabled, disabledTranslation = this.disabledTranslation, testID = this.testID, props = this.props;
      var commonClass = "query-builder-button";
      return _extends({
        class: className ? commonClass + " " + commonClass : commonClass,
        type: "text",
        title: disabledTranslation && disabled ? disabledTranslation.title : title,
        disabled: disabled && !disabledTranslation,
        disabledTranslation,
        testID
      }, props);
    }
  }
});
function _sfc_render$7(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_tiny_button = resolveComponent("tiny-button");
  return openBlock(), createBlock(_component_tiny_button, mergeProps(_ctx.allProps, {
    onClick: _ctx.handleOnClick
  }), {
    default: withCtx(function() {
      return [renderSlot(_ctx.$slots, "default", {}, function() {
        return [createTextVNode(
          toDisplayString(_ctx.disabledTranslation && _ctx.disabled ? _ctx.disabledTranslation.label : _ctx.label),
          1
          /* TEXT */
        )];
      })];
    }),
    _: 3
    /* FORWARDED */
  }, 16, ["onClick"]);
}
var ActionElement = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["render", _sfc_render$7]]);
var _sfc_main$6 = defineComponent({
  components: {
    TinyInput: Input$1,
    TinyNumeric: Numeric,
    TinyDatePicker: DatePicker,
    TinyTimePicker: TimePicker,
    TinyCheckbox: Checkbox,
    TinyRadio: Radio
  },
  emits: ["update:modelValue"],
  props: {
    value: {},
    type: {
      type: String,
      default: "text"
    },
    props: Object,
    events: Object,
    schema: Object
  },
  computed: {
    inputProps: function inputProps() {
      var _this$schema$bindProp;
      var inputProp = ((_this$schema$bindProp = this.schema.bindProps) == null ? void 0 : _this$schema$bindProp.input) || {};
      return _extends({}, this.props, inputProp);
    },
    numericProps: function numericProps() {
      var _this$schema$bindProp2;
      var numericProp = ((_this$schema$bindProp2 = this.schema.bindProps) == null ? void 0 : _this$schema$bindProp2.numeric) || {};
      return _extends({}, this.props, numericProp);
    },
    dateProps: function dateProps() {
      var _this$schema$bindProp3;
      var dateProp = ((_this$schema$bindProp3 = this.schema.bindProps) == null ? void 0 : _this$schema$bindProp3.date) || {};
      return _extends({}, this.props, dateProp);
    },
    timeProps: function timeProps() {
      var _this$schema$bindProp4;
      var timeProp = ((_this$schema$bindProp4 = this.schema.bindProps) == null ? void 0 : _this$schema$bindProp4.time) || {};
      return _extends({}, this.props, timeProp);
    },
    radioProps: function radioProps() {
      var _this$schema$bindProp5;
      var radioProp = ((_this$schema$bindProp5 = this.schema.bindProps) == null ? void 0 : _this$schema$bindProp5.radio) || {};
      return _extends({}, this.props, radioProp);
    },
    checkboxProps: function checkboxProps() {
      var _this$schema$bindProp6;
      var checkboxProp = ((_this$schema$bindProp6 = this.schema.bindProps) == null ? void 0 : _this$schema$bindProp6.checkbox) || {};
      return _extends({}, this.props, checkboxProp);
    }
  },
  data: function data2() {
    return {
      modelValue: this.value
    };
  },
  watch: {
    value: function value(_value) {
      this.modelValue = _value;
    }
  },
  methods: {
    update: function update() {
      this.$emit("update:modelValue", this.modelValue);
    }
  }
});
var _hoisted_1$4 = ["type"];
function _sfc_render$6(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_tiny_input = resolveComponent("tiny-input");
  var _component_tiny_numeric = resolveComponent("tiny-numeric");
  var _component_tiny_date_picker = resolveComponent("tiny-date-picker");
  var _component_tiny_time_picker = resolveComponent("tiny-time-picker");
  var _component_tiny_radio = resolveComponent("tiny-radio");
  var _component_tiny_checkbox = resolveComponent("tiny-checkbox");
  return ["text", "textarea"].includes(_ctx.type) ? (openBlock(), createBlock(_component_tiny_input, mergeProps({
    key: 0,
    type: _ctx.type,
    modelValue: _ctx.modelValue,
    "onUpdate:modelValue": _cache[0] || (_cache[0] = function($event) {
      return _ctx.modelValue = $event;
    })
  }, _ctx.inputProps, toHandlers(_ctx.events), {
    "onUpdate:modelValue": _ctx.update
  }), null, 16, ["type", "modelValue", "onUpdate:modelValue"])) : _ctx.type === "number" ? (openBlock(), createBlock(_component_tiny_numeric, mergeProps({
    key: 1,
    modelValue: _ctx.modelValue,
    "onUpdate:modelValue": _cache[1] || (_cache[1] = function($event) {
      return _ctx.modelValue = $event;
    })
  }, _ctx.numericProps, toHandlers(_ctx.events), {
    "onUpdate:modelValue": _ctx.update
  }), null, 16, ["modelValue", "onUpdate:modelValue"])) : ["date", "datetime-local"].includes(_ctx.type) ? (openBlock(), createBlock(_component_tiny_date_picker, mergeProps({
    key: 2,
    modelValue: _ctx.modelValue,
    "onUpdate:modelValue": _cache[2] || (_cache[2] = function($event) {
      return _ctx.modelValue = $event;
    }),
    "value-format": _ctx.dateProps.valueFormat || "yyyy-MM-dd"
  }, _ctx.dateProps, toHandlers(_ctx.events), {
    "onUpdate:modelValue": _ctx.update
  }), null, 16, ["modelValue", "value-format", "onUpdate:modelValue"])) : _ctx.type === "time" ? (openBlock(), createBlock(_component_tiny_time_picker, mergeProps({
    key: 3,
    modelValue: _ctx.modelValue,
    "onUpdate:modelValue": _cache[3] || (_cache[3] = function($event) {
      return _ctx.modelValue = $event;
    }),
    format: _ctx.timeProps.format || "hh:mm",
    "value-format": _ctx.timeProps.valueFormat || "shortTime"
  }, _ctx.timeProps, toHandlers(_ctx.events), {
    "onUpdate:modelValue": _ctx.update
  }), null, 16, ["modelValue", "format", "value-format", "onUpdate:modelValue"])) : _ctx.type === "radio" ? (openBlock(), createBlock(_component_tiny_radio, mergeProps({
    key: 4,
    modelValue: _ctx.modelValue,
    "onUpdate:modelValue": _cache[4] || (_cache[4] = function($event) {
      return _ctx.modelValue = $event;
    })
  }, _ctx.radioProps, toHandlers(_ctx.events), {
    "onUpdate:modelValue": _ctx.update
  }), null, 16, ["modelValue", "onUpdate:modelValue"])) : _ctx.type === "checkbox" ? (openBlock(), createBlock(_component_tiny_checkbox, mergeProps({
    key: 5,
    modelValue: _ctx.modelValue,
    "onUpdate:modelValue": _cache[5] || (_cache[5] = function($event) {
      return _ctx.modelValue = $event;
    })
  }, _ctx.checkboxProps, toHandlers(_ctx.events), {
    "onUpdate:modelValue": _ctx.update
  }), null, 16, ["modelValue", "onUpdate:modelValue"])) : withDirectives((openBlock(), createElementBlock("input", mergeProps({
    key: 6,
    type: _ctx.type,
    "onUpdate:modelValue": _cache[6] || (_cache[6] = function($event) {
      return _ctx.modelValue = $event;
    })
  }, _ctx.inputProps, toHandlers(_ctx.events, true), {
    onInput: _cache[7] || (_cache[7] = function() {
      return _ctx.update && _ctx.update.apply(_ctx, arguments);
    })
  }), null, 16, _hoisted_1$4)), [[vModelDynamic, _ctx.modelValue]]);
}
var Input = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["render", _sfc_render$6]]);
var _sfc_main$5 = defineComponent({
  components: {
    CustomInput: Input
  },
  props: {
    field: String,
    id: String,
    operator: String,
    value: {},
    valueSource: {},
    fieldData: {},
    type: {
      type: String,
      default: "text"
    },
    inputType: {
      type: String,
      default: "text"
    },
    values: {
      type: Array,
      default: function _default2() {
        return [];
      }
    },
    listsAsArrays: {},
    parseNumbers: {},
    separator: {},
    selectorComponent: {},
    skipHook: {},
    handleOnChange: {},
    className: {},
    path: {},
    level: {},
    title: {},
    disabled: {},
    context: {},
    validation: {},
    testID: {},
    schema: {}
  },
  // :ValueEditorProps
  setup: function setup9(props) {
    var getProps = function getProps2(options) {
      return options.props || {};
    };
    return {
      standardClassnames,
      getFirstOption,
      parseNumber,
      modelValue: {
        from: "",
        to: ""
      },
      getProps
    };
  },
  computed: {
    allProps: function allProps2() {
      var _fieldData$placeholde;
      var _this$$props = this.$props, operator = _this$$props.operator, value2 = _this$$props.value, handleOnChange = _this$$props.handleOnChange, title = _this$$props.title, className = _this$$props.className, _this$$props$type = _this$$props.type, type = _this$$props$type === void 0 ? "text" : _this$$props$type, _this$$props$inputTyp = _this$$props.inputType, inputType = _this$$props$inputTyp === void 0 ? "text" : _this$$props$inputTyp, _this$$props$values = _this$$props.values, values = _this$$props$values === void 0 ? [] : _this$$props$values, listsAsArrays = _this$$props.listsAsArrays, parseNumbers = _this$$props.parseNumbers, fieldData = _this$$props.fieldData, disabled = _this$$props.disabled, _this$$props$separato = _this$$props.separator, separator = _this$$props$separato === void 0 ? null : _this$$props$separato, _this$$props$skipHook = _this$$props.skipHook, skipHook = _this$$props$skipHook === void 0 ? false : _this$$props$skipHook, testID = _this$$props.testID, _this$$props$selector = _this$$props.selectorComponent, SelectorComponent = _this$$props$selector === void 0 ? ValueSelector : _this$$props$selector, props = _objectWithoutPropertiesLoose(_this$$props, _excluded);
      var _useValueEditor = useValueEditor({
        skipHook,
        handleOnChange,
        inputType,
        operator,
        value: value2,
        listsAsArrays,
        parseNumbers,
        values
      }), valueAsArray = _useValueEditor.valueAsArray, multiValueHandler = _useValueEditor.multiValueHandler;
      var placeHolderText = (_fieldData$placeholde = fieldData == null ? void 0 : fieldData.placeholder) != null ? _fieldData$placeholde : "";
      var inputTypeCoerced = ["textarea", "switch", "checkbox"].includes(type) ? type : ["in", "notIn"].includes(operator) ? "text" : inputType || "text";
      if (Array.isArray(valueAsArray)) {
        this.modelValue.from = valueAsArray[0];
        this.modelValue.to = valueAsArray[1];
      } else {
        this.modelValue.from = "";
        this.modelValue.to = "";
      }
      return {
        operator,
        value: value2,
        handleOnChange,
        title,
        className,
        type,
        inputType,
        values,
        listsAsArrays,
        parseNumbers,
        fieldData,
        disabled,
        separator,
        skipHook,
        testID,
        SelectorComponent,
        props,
        multiValueHandler,
        placeHolderText,
        inputTypeCoerced
      };
    },
    show: function show() {
      return !["null", "notNull"].includes(this.operator);
    }
  },
  methods: {
    change: function change(e) {
      var _e$target2;
      if (["textarea", "radio"].includes(this.type)) {
        var _e$target;
        return this.handleOnChange((e == null ? void 0 : (_e$target = e.target) == null ? void 0 : _e$target.value) || e);
      }
      return this.handleOnChange(parseNumber((e == null ? void 0 : (_e$target2 = e.target) == null ? void 0 : _e$target2.value) || e, {
        parseNumbers: this.parseNumbers
      }));
    },
    change1: function change1(i) {
      var _this2 = this;
      return function(e) {
        var _e$target3;
        return _this2.allProps.multiValueHandler((e == null ? void 0 : (_e$target3 = e.target) == null ? void 0 : _e$target3.value) || e, i);
      };
    }
  }
});
var _hoisted_1$3 = {
  key: 0,
  style: {
    "display": "none"
  }
};
var _hoisted_2$1 = ["data-testid", "title"];
var _hoisted_3 = ["data-testid", "title"];
var _hoisted_4 = {
  key: 4,
  class: "custom-rule-value-editor"
};
var _hoisted_5 = {
  key: 0,
  class: "custom-rule-value-editor_multi"
};
var _hoisted_6 = {
  key: 5,
  class: "rule-value-editor"
};
function _sfc_render$5(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_custom_input = resolveComponent("custom-input");
  return !_ctx.show ? (openBlock(), createElementBlock("div", _hoisted_1$3)) : ["text", "select"].includes(_ctx.type) && ["between", "notBetween"].includes(_ctx.operator) ? (openBlock(), createElementBlock("span", {
    key: 1,
    "data-testid": _ctx.testID,
    class: normalizeClass(_ctx.className + " rule-value-editor"),
    title: _ctx.title
  }, [(openBlock(), createElementBlock(
    Fragment,
    null,
    renderList(["from", "to"], function(key, i) {
      return createElementVNode("div", {
        key: i
      }, [_ctx.type === "text" ? (openBlock(), createBlock(_component_custom_input, {
        key: 0,
        type: _ctx.allProps.inputTypeCoerced,
        value: _ctx.modelValue[key],
        schema: _ctx.schema,
        props: {
          key,
          placeholder: _ctx.allProps.placeHolderText,
          class: _ctx.standardClassnames.valueListItem,
          disabled: _ctx.disabled
        },
        events: {
          change: _ctx.change1(i)
        }
      }, null, 8, ["type", "value", "schema", "props", "events"])) : (openBlock(), createBlock(resolveDynamicComponent(_ctx.allProps.SelectorComponent), mergeProps({
        key,
        ref_for: true
      }, _ctx.otherProps, {
        class: _ctx.standardClassnames.valueListItem,
        disabled: _ctx.disabled,
        "bind-props": _ctx.schema.bindProps && _ctx.schema.bindProps.select || {}
      }), null, 16, ["class", "disabled", "bind-props"])), i === 0 ? (openBlock(), createBlock(resolveDynamicComponent(_ctx.separator), {
        key: 2
      })) : createCommentVNode("v-if", true)]);
    }),
    64
    /* STABLE_FRAGMENT */
  ))], 10, _hoisted_2$1)) : ["select", "multiselect"].includes(_ctx.type) ? (openBlock(), createBlock(resolveDynamicComponent(_ctx.allProps.SelectorComponent), mergeProps({
    key: 2
  }, _ctx.allProps.props, {
    "test-i-d": _ctx.testID,
    "class-name": _ctx.className,
    title: _ctx.title,
    "handle-on-change": _ctx.handleOnChange,
    disabled: _ctx.disabled,
    value: _ctx.value,
    options: _ctx.values,
    multiple: _ctx.type === "multiselect",
    "lists-as-arrays": _ctx.listsAsArrays,
    "bind-props": _ctx.schema.bindProps && _ctx.schema.bindProps.select || {}
  }), null, 16, ["test-i-d", "class-name", "title", "handle-on-change", "disabled", "value", "options", "multiple", "lists-as-arrays", "bind-props"])) : _ctx.type === "radio" ? (openBlock(), createElementBlock("span", {
    key: 3,
    "data-testid": _ctx.testID,
    class: normalizeClass(_ctx.className + " rule-radio"),
    title: _ctx.title
  }, [(openBlock(true), createElementBlock(
    Fragment,
    null,
    renderList(_ctx.values, function(v, key) {
      return openBlock(), createBlock(_component_custom_input, {
        key,
        type: _ctx.type,
        value: _ctx.value,
        schema: _ctx.schema,
        props: {
          label: v.name,
          text: v.label,
          disabled: _ctx.disabled
        },
        events: {
          change: _ctx.change
        }
      }, null, 8, ["type", "value", "schema", "props", "events"]);
    }),
    128
    /* KEYED_FRAGMENT */
  ))], 10, _hoisted_3)) : _ctx.type === "custom" && _ctx.allProps.fieldData.component ? (openBlock(), createElementBlock("span", _hoisted_4, [["between", "notBetween"].includes(_ctx.operator) ? (openBlock(), createElementBlock("div", _hoisted_5, [(openBlock(), createElementBlock(
    Fragment,
    null,
    renderList(["from", "to"], function(key, i) {
      return createElementVNode("div", {
        key,
        class: "custom-rule-value-editor_multi-item"
      }, [(openBlock(), createBlock(resolveDynamicComponent(_ctx.allProps.fieldData.component), mergeProps({
        ref_for: true
      }, _ctx.getProps(_ctx.allProps.fieldData), {
        "data-id": _ctx.id,
        "field-name": _ctx.field,
        modelValue: _ctx.value[i],
        key,
        "onUpdate:modelValue": _ctx.change,
        onChange: _ctx.change,
        operator: _ctx.operator,
        path: _ctx.path
      }), null, 16, ["data-id", "field-name", "modelValue", "onUpdate:modelValue", "onChange", "operator", "path"]))]);
    }),
    64
    /* STABLE_FRAGMENT */
  ))])) : (openBlock(), createBlock(resolveDynamicComponent(_ctx.allProps.fieldData.component), mergeProps({
    key: 1
  }, _ctx.getProps(_ctx.allProps.fieldData), {
    "data-id": _ctx.id,
    "field-name": _ctx.field,
    modelValue: _ctx.value,
    "onUpdate:modelValue": _ctx.change,
    onChange: _ctx.change,
    operator: _ctx.operator,
    path: _ctx.path
  }), null, 16, ["data-id", "field-name", "modelValue", "onUpdate:modelValue", "onChange", "operator", "path"]))])) : (openBlock(), createElementBlock("span", _hoisted_6, [createVNode(_component_custom_input, {
    type: _ctx.allProps.inputTypeCoerced,
    value: _ctx.type === "checkbox" ? !!_ctx.value : _ctx.value,
    schema: _ctx.schema,
    props: {
      "data-testid": _ctx.testID,
      placeholder: _ctx.allProps.placeHolderText,
      title: _ctx.title,
      class: _ctx.className,
      disabled: _ctx.disabled
    },
    events: {
      change: _ctx.change
    }
  }, null, 8, ["type", "value", "schema", "props", "events"])]));
}
var ValueEditor = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["render", _sfc_render$5]]);
var _sfc_main$4 = defineComponent({
  components: {
    TinySelect: Select
  },
  props: ["className", "handleOnChange", "options", "title", "value", "multiple", "listsAsArrays", "disabled", "testID", "schema", "bindProps"],
  setup: function setup10() {
    return {
      isOptionGroupArray
    };
  },
  computed: {
    valueSelector: function valueSelector2() {
      var handleOnChange = this.handleOnChange, value2 = this.value, multiple = this.multiple, listsAsArrays = this.listsAsArrays;
      return useValueSelector({
        handleOnChange,
        listsAsArrays,
        multiple,
        value: value2
      });
    },
    selectElementChangeHandler: function selectElementChangeHandler2() {
      var onChange = this.valueSelector.onChange;
      var multiple = this.multiple;
      return useSelectElementChangeHandler({
        multiple,
        onChange,
        field: "name"
      });
    },
    treeOp: function treeOp() {
      var data4 = this.formatField(this.options);
      return {
        nodeKey: "name",
        data: data4
      };
    }
  },
  methods: {
    formatField: function formatField(options) {
      var _this3 = this;
      if (options === void 0) {
        options = [];
      }
      options.forEach(function(option) {
        var children = option.children;
        if (children && children.length) {
          option.disabled = true;
          option.children = _this3.formatField(children);
        }
      });
      return options;
    },
    isSelected: function isSelected2(data4, value2) {
      return Array.isArray(data4) ? data4.includes(value2) : data4 === value2;
    }
  }
});
function _sfc_render$4(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_tiny_select = resolveComponent("tiny-select");
  return openBlock(), createBlock(_component_tiny_select, mergeProps({
    "data-testid": _ctx.testID,
    class: _ctx.className + " query-builder-select",
    modelValue: _ctx.valueSelector.val,
    "onUpdate:modelValue": _cache[0] || (_cache[0] = function($event) {
      return _ctx.valueSelector.val = $event;
    }),
    "value-field": "name",
    "text-field": "label",
    "render-type": "tree",
    "tree-op": _ctx.treeOp,
    title: _ctx.title,
    disabled: _ctx.disabled,
    multiple: !!_ctx.multiple
  }, _ctx.bindProps, {
    onChange: _ctx.selectElementChangeHandler,
    "hover-expand": ""
  }), null, 16, ["data-testid", "class", "modelValue", "tree-op", "title", "disabled", "multiple", "onChange"]);
}
var FieldSelector = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["render", _sfc_render$4]]);
var _sfc_main$3 = defineComponent({
  name: "Combinator",
  components: {},
  props: ["className", "handleOnChange", "options", "title", "value", "multiple", "listsAsArrays", "disabled", "testID"],
  computed: {
    selectOption: function selectOption() {
      var _this4 = this;
      return this.options.filter(function(item) {
        return item.name === _this4.value;
      }).shift() || {};
    }
  },
  methods: {
    clickHandler: function clickHandler() {
      var _this5 = this;
      var value2 = this.options.filter(function(item) {
        return item.name !== _this5.value;
      }).map(function(item) {
        return item.name;
      }).shift();
      this.handleOnChange(value2);
    }
  }
});
var _hoisted_1$2 = {
  class: "group-combinator-box"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "div",
  {
    class: "combinator-branches"
  },
  null,
  -1
  /* HOISTED */
);
function _sfc_render$3(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", _hoisted_1$2, [_hoisted_2, createElementVNode(
    "div",
    {
      class: normalizeClass(["combinator-btn", {
        "is-disabled": _ctx.disabled
      }]),
      onClick: _cache[0] || (_cache[0] = function() {
        return _ctx.clickHandler && _ctx.clickHandler.apply(_ctx, arguments);
      })
    },
    toDisplayString(_ctx.selectOption.label),
    3
    /* TEXT, CLASS */
  )]);
}
var Combinator = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["render", _sfc_render$3]]);
var _sfc_main$2 = defineComponent({
  props: {
    className: {
      type: String
    },
    label: {
      type: String
    },
    title: {
      type: String
    },
    testID: {
      type: String
    },
    dragRef: {
      type: Object
    }
  },
  setup: function setup11(props, context) {
    return setup({
      props,
      context,
      renderless,
      api
    });
  }
});
var _hoisted_1$1 = ["data-testid", "title"];
function _sfc_render$2(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("span", {
    ref: _ctx.dragRef,
    class: normalizeClass(_ctx.className),
    "data-testid": _ctx.testID,
    title: _ctx.title
  }, toDisplayString(_ctx.label), 11, _hoisted_1$1);
}
var DragHandle = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["render", _sfc_render$2]]);
var defaultControlElements = {
  addGroupAction: ActionElement,
  removeGroupAction: ActionElement,
  cloneGroupAction: ActionElement,
  cloneRuleAction: ActionElement,
  addRuleAction: ActionElement,
  clearDataAction: ActionElement,
  removeRuleAction: ActionElement,
  combinatorSelector: Combinator,
  inlineCombinator: InlineCombinator,
  operatorSelector: ValueSelector,
  fieldSelector: FieldSelector,
  valueEditor: ValueEditor,
  ruleGroup: RuleGroup,
  notToggle: NotToggle,
  lockRuleAction: ActionElement,
  rule: Rule,
  dragHandle: DragHandle,
  valueSourceSelector: ValueSelector,
  lockGroupAction: ActionElement
};
var mergeClassnames = function mergeClassnames2() {
  for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
    args[_key2] = arguments[_key2];
  }
  var joinClassnamesByName = function joinClassnamesByName2(name) {
    return clsx(args.filter(Boolean).map(function(c) {
      return clsx(c[name]);
    }));
  };
  return {
    queryBuilder: joinClassnamesByName("queryBuilder"),
    ruleGroup: joinClassnamesByName("ruleGroup"),
    header: joinClassnamesByName("header"),
    body: joinClassnamesByName("body"),
    combinators: joinClassnamesByName("combinators"),
    addRule: joinClassnamesByName("addRule"),
    addGroup: joinClassnamesByName("addGroup"),
    cloneRule: joinClassnamesByName("cloneRule"),
    cloneGroup: joinClassnamesByName("cloneGroup"),
    removeGroup: joinClassnamesByName("removeGroup"),
    rule: joinClassnamesByName("rule"),
    fields: joinClassnamesByName("fields"),
    operators: joinClassnamesByName("operators"),
    value: joinClassnamesByName("value"),
    removeRule: joinClassnamesByName("removeRule"),
    clearData: joinClassnamesByName("clearData"),
    notToggle: joinClassnamesByName("notToggle"),
    dragHandle: joinClassnamesByName("dragHandle"),
    lockRule: joinClassnamesByName("lockRule"),
    lockGroup: joinClassnamesByName("lockGroup"),
    valueSource: joinClassnamesByName("valueSource")
  };
};
var objectKeys = function objectKeys2(obj) {
  return Object.keys(obj);
};
var preferPropDefaultTrue = function preferPropDefaultTrue2(prop, context) {
  return prop === false ? false : prop ? true : context !== false;
};
var preferPropDefaultFalse = function preferPropDefaultFalse2(prop, context) {
  return prop ? true : prop === false ? false : !!context;
};
var preferProp = function preferProp2(def, prop, context) {
  return def ? preferPropDefaultTrue(prop, context) : preferPropDefaultFalse(prop, context);
};
var usePreferProp = function usePreferProp2(def, prop, context) {
  return useMemo(function() {
    return preferProp(def, prop, context);
  });
};
var useMergedContext = function useMergedContext2(props) {
  var rqbContext = useContext(QueryBuilderContext());
  var enableMountQueryChange = usePreferProp(true, props.enableMountQueryChange, rqbContext.enableMountQueryChange);
  var enableDragAndDrop = usePreferProp(false, props.enableDragAndDrop, rqbContext.enableDragAndDrop) && rqbContext.enableDragAndDrop !== false;
  var debugMode = usePreferProp(false, props.debugMode, rqbContext.debugMode);
  var controlClassnames = useMemo(function() {
    return mergeClassnames(defaultControlClassnames, rqbContext.controlClassnames, props.controlClassnames);
  }, [rqbContext.controlClassnames, props.controlClassnames]);
  var controlElements = useMemo(function() {
    return _extends({}, defaultControlElements, rqbContext.controlElements, props.controlElements);
  }, [props.controlElements, rqbContext.controlElements]);
  var translations = useMemo(function() {
    var translationsTemp = {};
    objectKeys(props.translations).forEach(function(t) {
      var contextTranslations = rqbContext.translations;
      translationsTemp[t] = _extends({}, defaultTranslations[t], contextTranslations, props.translations[t]);
    });
    return _extends({}, defaultTranslations, translationsTemp);
  }, [rqbContext.translations, props.translations]);
  rqbContext.controlClassnames; rqbContext.controlElements; rqbContext.debugMode; rqbContext.enableDragAndDrop; rqbContext.enableMountQueryChange; rqbContext.translations; var otherContext = _objectWithoutPropertiesLoose(rqbContext, _excluded2);
  return _extends({
    controlClassnames,
    controlElements,
    debugMode,
    enableDragAndDrop,
    enableMountQueryChange,
    translations
  }, otherContext);
};
var filterFieldsByComparator = function filterFieldsByComparator2(field, fields, operator) {
  if (!field.comparator) {
    var filterOutSameName = function filterOutSameName2(fd) {
      return fd.name !== field.name;
    };
    if (isOptionGroupArray(fields)) {
      return fields.map(function(ogs) {
        return _extends({}, ogs, {
          options: ogs.options.filter(filterOutSameName)
        });
      });
    }
    return fields.filter(filterOutSameName);
  }
  var filterByComparator = function filterByComparator2(fieldToCompare) {
    if (field.name === fieldToCompare.name) {
      return false;
    }
    if (typeof field.comparator === "string") {
      return field[field.comparator] === fieldToCompare[field.comparator];
    }
    return field.comparator(fieldToCompare, operator);
  };
  if (isOptionGroupArray(fields)) {
    return fields.map(function(ogs) {
      return _extends({}, ogs, {
        options: ogs.options.filter(filterByComparator)
      });
    }).filter(function(ogs) {
      return ogs.options.length > 0;
    });
  }
  return fields.filter(filterByComparator);
};
var parseNumber = function parseNumber2(v, _ref9) {
  var parseNumbers = _ref9.parseNumbers;
  if (typeof v === "bigint" || typeof v === "number") {
    return v;
  }
  return parseNumbers && (parseNumbers === "native" || numericRegex.test(v)) ? parseFloat(v) : v;
};
var findPath = function findPath2(path, query) {
  var level = 0;
  var target = query;
  while (target && level < path.length && "rules" in target) {
    var t = target.rules[path[level]];
    if (typeof t === "string") {
      target = null;
    } else {
      target = t;
    }
    level++;
  }
  return target;
};
var getParentPath = function getParentPath2(path) {
  return path.slice(0, path.length - 1);
};
var pathsAreEqual = function pathsAreEqual2(path1, path2) {
  return path1.every(function(val, idx) {
    return val === path2[idx];
  }) && path1.length === path2.length;
};
var getCommonAncestorPath = function getCommonAncestorPath2(path1, path2) {
  var parentPath1 = getParentPath(path1);
  var parentPath2 = getParentPath(path2);
  var commonAncestorPath = [];
  var i = 0;
  while (parentPath1[i] === parentPath2[i] && i < parentPath1.length && i < parentPath2.length) {
    commonAncestorPath.push(parentPath2[i]);
    i++;
  }
  return commonAncestorPath;
};
var pathIsDisabled = function pathIsDisabled2(path, query) {
  var level = 0;
  var disabled = !!query.disabled;
  var target = query;
  while ("rules" in target && level < path.length && !disabled) {
    var t = target.rules[path[level]];
    if (isPojo(t) && ("field" in t || "rules" in t)) {
      disabled = !!t.disabled;
      target = t;
    }
    level++;
  }
  return disabled;
};
var produce = function produce2(state, cb) {
  return cb(state) || state;
};
var prepareRule = function prepareRule2(rule, _temp3) {
  var _ref0 = _temp3 === void 0 ? {} : _temp3, _ref0$idGenerator = _ref0.idGenerator, idGenerator = _ref0$idGenerator === void 0 ? generateID : _ref0$idGenerator;
  return produce(rule, function(draft) {
    if (!draft.id) {
      draft.id = idGenerator();
    }
  });
};
var _prepareRuleGroup = function prepareRuleGroup(queryObject, _temp4) {
  var _ref1 = _temp4 === void 0 ? {} : _temp4, _ref1$idGenerator = _ref1.idGenerator, idGenerator = _ref1$idGenerator === void 0 ? generateID : _ref1$idGenerator;
  return produce(queryObject, function(draft) {
    if (!draft.id) {
      draft.id = idGenerator();
    }
    draft.rules = draft.rules.map(function(r3) {
      return typeof r3 === "string" ? r3 : "rules" in r3 ? _prepareRuleGroup(r3, {
        idGenerator
      }) : prepareRule(r3, {
        idGenerator
      });
    });
  });
};
var prepareRuleOrGroup = function prepareRuleOrGroup2(rg3, _temp5) {
  var _ref10 = _temp5 === void 0 ? {} : _temp5, _ref10$idGenerator = _ref10.idGenerator, idGenerator = _ref10$idGenerator === void 0 ? generateID : _ref10$idGenerator;
  return "rules" in rg3 ? _prepareRuleGroup(rg3, {
    idGenerator
  }) : prepareRule(rg3, {
    idGenerator
  });
};
var regenerateID = function regenerateID2(rule, _temp6) {
  var _ref11 = _temp6 === void 0 ? {} : _temp6, _ref11$idGenerator = _ref11.idGenerator, idGenerator = _ref11$idGenerator === void 0 ? generateID : _ref11$idGenerator;
  return JSON.parse(JSON.stringify(_extends({}, rule, {
    id: idGenerator()
  })));
};
var _regenerateIDs = function regenerateIDs(ruleOrGroup, _temp7) {
  var _ref12 = _temp7 === void 0 ? {} : _temp7, _ref12$idGenerator = _ref12.idGenerator, idGenerator = _ref12$idGenerator === void 0 ? generateID : _ref12$idGenerator;
  if (!isPojo(ruleOrGroup)) return ruleOrGroup;
  if (!("rules" in ruleOrGroup)) {
    return JSON.parse(JSON.stringify(_extends({}, ruleOrGroup, {
      id: idGenerator()
    })));
  }
  if ("combinator" in ruleOrGroup) {
    var rules2 = ruleOrGroup.rules.map(function(r3) {
      return isPojo(r3) && "rules" in r3 ? _regenerateIDs(r3, {
        idGenerator
      }) : regenerateID(r3, {
        idGenerator
      });
    });
    return _extends({}, ruleOrGroup, {
      id: idGenerator(),
      rules: rules2
    });
  }
  var rules = ruleOrGroup.rules.map(function(r3) {
    return typeof r3 === "string" ? r3 : isPojo(r3) && "rules" in r3 ? _regenerateIDs(r3, {
      idGenerator
    }) : regenerateID(r3, {
      idGenerator
    });
  });
  return _extends({}, ruleOrGroup, {
    id: idGenerator(),
    rules
  });
};
var add = function add2(query, ruleOrGroup, parentPath, _temp8) {
  var _ref13 = _temp8 === void 0 ? {} : _temp8, _ref13$combinators = _ref13.combinators, combinators = _ref13$combinators === void 0 ? defaultCombinators : _ref13$combinators, combinatorPreceding = _ref13.combinatorPreceding, _ref13$idGenerator = _ref13.idGenerator, idGenerator = _ref13$idGenerator === void 0 ? generateID : _ref13$idGenerator;
  return produce(query, function(draft) {
    var parent = findPath(parentPath, draft);
    if (!parent || !("rules" in parent)) return;
    if (!("combinator" in parent) && parent.rules.length > 0) {
      var prevCombinator = parent.rules[parent.rules.length - 2];
      parent.rules.push(
        // @ts-expect-error This is technically a type violation until the next push
        // to the rules array, but that happens immediately and unconditionally so
        // there's no significant risk.
        combinatorPreceding != null ? combinatorPreceding : typeof prevCombinator === "string" ? prevCombinator : getFirstOption(combinators)
      );
    }
    parent.rules.push(prepareRuleOrGroup(ruleOrGroup, {
      idGenerator
    }));
  });
};
var update2 = function update3(query, prop, value2, path, _temp9) {
  var _ref14 = _temp9 === void 0 ? {} : _temp9, _ref14$resetOnFieldCh = _ref14.resetOnFieldChange, resetOnFieldChange = _ref14$resetOnFieldCh === void 0 ? true : _ref14$resetOnFieldCh, _ref14$resetOnOperato = _ref14.resetOnOperatorChange, resetOnOperatorChange = _ref14$resetOnOperato === void 0 ? false : _ref14$resetOnOperato, _ref14$getRuleDefault = _ref14.getRuleDefaultOperator, getRuleDefaultOperator = _ref14$getRuleDefault === void 0 ? function() {
    return "=";
  } : _ref14$getRuleDefault, _ref14$getValueSource = _ref14.getValueSources, getValueSources = _ref14$getValueSource === void 0 ? function() {
    return ["value"];
  } : _ref14$getValueSource, _ref14$getRuleDefault2 = _ref14.getRuleDefaultValue, getRuleDefaultValue = _ref14$getRuleDefault2 === void 0 ? function() {
    return "";
  } : _ref14$getRuleDefault2;
  return produce(query, function(draft) {
    if (prop === "combinator" && !("combinator" in draft)) {
      var parentRules = findPath(getParentPath(path), draft).rules;
      if (path[path.length - 1] % 2 === 1) {
        parentRules[path[path.length - 1]] = value2;
      }
      return;
    }
    var ruleOrGroup = findPath(path, draft);
    if (!ruleOrGroup) return;
    var isGroup = "rules" in ruleOrGroup;
    if (ruleOrGroup[prop] === value2) return;
    if (prop !== "valueSource") {
      if (isVue2 && !(prop in ruleOrGroup)) {
        appProperties().$set(ruleOrGroup, prop, value2);
      } else {
        ruleOrGroup[prop] = value2;
      }
    }
    if (isGroup) return;
    var resetValueSource = false;
    var resetValue = false;
    if (resetOnFieldChange && prop === "field") {
      ruleOrGroup.operator = getRuleDefaultOperator(value2);
      resetValueSource = true;
      resetValue = true;
    }
    if (resetOnOperatorChange && prop === "operator") {
      resetValue = true;
      resetValueSource = true;
    }
    var defaultValueSource = getValueSources(ruleOrGroup.field, ruleOrGroup.operator)[0];
    if (resetValueSource && ruleOrGroup.valueSource && defaultValueSource !== ruleOrGroup.valueSource || prop === "valueSource" && value2 !== ruleOrGroup.valueSource) {
      resetValue = !!ruleOrGroup.valueSource || !ruleOrGroup.valueSource && value2 !== defaultValueSource;
      ruleOrGroup.valueSource = resetValueSource ? defaultValueSource : value2;
    }
    if (resetValue) {
      ruleOrGroup.value = getRuleDefaultValue(ruleOrGroup);
    }
  });
};
var remove = function remove2(query, path) {
  if (
    // Can't remove the root group
    path.length === 0 || // Can't independently remove independent combinators
    !("combinator" in query) && !findPath(path, query)
  ) {
    return query;
  }
  return produce(query, function(draft) {
    var index = path[path.length - 1];
    var parent = findPath(getParentPath(path), draft);
    if (parent && "rules" in parent) {
      if (!("combinator" in parent) && parent.rules.length > 1) {
        var idxStartDelete = index === 0 ? 0 : index - 1;
        parent.rules.splice(idxStartDelete, 2);
      } else {
        parent.rules.splice(index, 1);
      }
    }
  });
};
var move = function move2(query, oldPath, newPath, _temp0) {
  var _ref15 = _temp0 === void 0 ? {} : _temp0, _ref15$clone = _ref15.clone, clone = _ref15$clone === void 0 ? false : _ref15$clone, _ref15$combinators = _ref15.combinators, combinators = _ref15$combinators === void 0 ? defaultCombinators : _ref15$combinators, _ref15$idGenerator = _ref15.idGenerator, idGenerator = _ref15$idGenerator === void 0 ? generateID : _ref15$idGenerator;
  if (pathsAreEqual(oldPath, newPath) || !findPath(getParentPath(newPath), query)) {
    return query;
  }
  var ruleOrGroupOriginal = findPath(oldPath, query);
  if (!ruleOrGroupOriginal) {
    return query;
  }
  var ruleOrGroup = clone ? "rules" in ruleOrGroupOriginal ? _regenerateIDs(ruleOrGroupOriginal, {
    idGenerator
  }) : regenerateID(ruleOrGroupOriginal, {
    idGenerator
  }) : ruleOrGroupOriginal;
  return produce(query, function(draft) {
    var independentCombinators = !("combinator" in draft);
    var parentOfRuleToRemove = findPath(getParentPath(oldPath), draft);
    var ruleToRemoveIndex = oldPath[oldPath.length - 1];
    var oldPrevCombinator = ruleToRemoveIndex > 0 && independentCombinators ? parentOfRuleToRemove.rules[ruleToRemoveIndex - 1] : null;
    var oldNextCombinator = ruleToRemoveIndex < parentOfRuleToRemove.rules.length - 1 && independentCombinators ? parentOfRuleToRemove.rules[ruleToRemoveIndex + 1] : null;
    if (!clone) {
      var idxStartDelete = independentCombinators ? Math.max(0, ruleToRemoveIndex - 1) : ruleToRemoveIndex;
      var deleteLength = independentCombinators ? 2 : 1;
      parentOfRuleToRemove.rules.splice(idxStartDelete, deleteLength);
    }
    var newNewPath = [].concat(newPath);
    var commonAncestorPath = getCommonAncestorPath(oldPath, newPath);
    if (!clone && oldPath.length === commonAncestorPath.length + 1 && newPath[commonAncestorPath.length] > oldPath[commonAncestorPath.length]) {
      newNewPath[commonAncestorPath.length] -= independentCombinators ? 2 : 1;
    }
    var newNewParentPath = getParentPath(newNewPath);
    var parentToInsertInto = findPath(newNewParentPath, draft);
    var newIndex = newNewPath[newNewPath.length - 1];
    var insertRuleOrGroup = function insertRuleOrGroup2() {
      var _parentToInsertInto$r;
      for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
        args[_key3] = arguments[_key3];
      }
      return (_parentToInsertInto$r = parentToInsertInto.rules).splice.apply(_parentToInsertInto$r, [newIndex, 0].concat(args));
    };
    if (parentToInsertInto.rules.length === 0 || !independentCombinators) {
      insertRuleOrGroup(ruleOrGroup);
    } else {
      if (newIndex === 0) {
        if (oldNextCombinator && ruleToRemoveIndex === 0) {
          insertRuleOrGroup(ruleOrGroup, oldNextCombinator);
        } else {
          var newNextCombinator = parentToInsertInto.rules[1] || getFirstOption(combinators) || oldPrevCombinator;
          insertRuleOrGroup(ruleOrGroup, newNextCombinator);
        }
      } else {
        if (oldPrevCombinator) {
          insertRuleOrGroup(oldPrevCombinator, ruleOrGroup);
        } else {
          var newPrevCombinator = parentToInsertInto.rules[newIndex - 2] || getFirstOption(combinators) || oldNextCombinator;
          insertRuleOrGroup(newPrevCombinator, ruleOrGroup);
        }
      }
    }
  });
};
var noop = function noop2() {
};
var useQueryBuilder = function useQueryBuilder2(props, context) {
  var defaultQuery = props.defaultQuery, bindProps = props.bindProps, queryProp = props.query, fieldsPropOriginal = props.fields, _props$operators = props.operators, operators = _props$operators === void 0 ? defaultOperators : _props$operators, _props$combinators = props.combinators, combinators = _props$combinators === void 0 ? defaultCombinators : _props$combinators, _props$translations = props.translations, translationsProp = _props$translations === void 0 ? defaultTranslations : _props$translations, _props$enableMountQue = props.enableMountQueryChange, enableMountQueryChangeProp = _props$enableMountQue === void 0 ? true : _props$enableMountQue, controlClassnamesProp = props.controlClassnames, controlElementsProp = props.controlElements, getDefaultField = props.getDefaultField, getDefaultOperator = props.getDefaultOperator, getDefaultValue = props.getDefaultValue, getOperators = props.getOperators, getValueEditorType = props.getValueEditorType, _props$getValueEditor = props.getValueEditorSeparator, getValueEditorSeparator = _props$getValueEditor === void 0 ? function() {
    return null;
  } : _props$getValueEditor, getValueSources = props.getValueSources, getInputType = props.getInputType, getValues = props.getValues, _props$getRuleClassna = props.getRuleClassname, getRuleClassname = _props$getRuleClassna === void 0 ? function() {
    return "";
  } : _props$getRuleClassna, _props$getRuleGroupCl = props.getRuleGroupClassname, getRuleGroupClassname = _props$getRuleGroupCl === void 0 ? function() {
    return "";
  } : _props$getRuleGroupCl, _props$onAddRule = props.onAddRule, onAddRule = _props$onAddRule === void 0 ? function(r3) {
    return r3;
  } : _props$onAddRule, _props$onAddGroup = props.onAddGroup, onAddGroup = _props$onAddGroup === void 0 ? function(rg3) {
    return rg3;
  } : _props$onAddGroup, _props$onRemove = props.onRemove, onRemove = _props$onRemove === void 0 ? function() {
    return true;
  } : _props$onRemove, _props$onQueryChange = props.onQueryChange, onQueryChange = _props$onQueryChange === void 0 ? noop : _props$onQueryChange, _props$showCombinator = props.showCombinatorsBetweenRules, showCombinatorsBetweenRules = _props$showCombinator === void 0 ? false : _props$showCombinator, _props$showNotToggle = props.showNotToggle, showNotToggle = _props$showNotToggle === void 0 ? false : _props$showNotToggle, _props$showCloneButto = props.showCloneButtons, showCloneButtons = _props$showCloneButto === void 0 ? false : _props$showCloneButto, _props$showNewGroup = props.showNewGroup, showNewGroup = _props$showNewGroup === void 0 ? true : _props$showNewGroup, _props$showNewRule = props.showNewRule, showNewRule = _props$showNewRule === void 0 ? true : _props$showNewRule, _props$isGroupDisable = props.isGroupDisable, isGroupDisable = _props$isGroupDisable === void 0 ? false : _props$isGroupDisable, _props$isRuleDisable = props.isRuleDisable, isRuleDisable = _props$isRuleDisable === void 0 ? false : _props$isRuleDisable, _props$groupLimit = props.groupLimit, groupLimit = _props$groupLimit === void 0 ? Infinity : _props$groupLimit, _props$ruleLimit = props.ruleLimit, ruleLimit = _props$ruleLimit === void 0 ? Infinity : _props$ruleLimit, _props$allowDelAll = props.allowDelAll, allowDelAll = _props$allowDelAll === void 0 ? false : _props$allowDelAll, _props$showLockButton = props.showLockButtons, showLockButtons = _props$showLockButton === void 0 ? false : _props$showLockButton, _props$showBranches = props.showBranches, showBranches = _props$showBranches === void 0 ? true : _props$showBranches, _props$resetOnFieldCh = props.resetOnFieldChange, resetOnFieldChange = _props$resetOnFieldCh === void 0 ? true : _props$resetOnFieldCh, _props$resetOnOperato = props.resetOnOperatorChange, resetOnOperatorChange = _props$resetOnOperato === void 0 ? false : _props$resetOnOperato, _props$autoSelectFiel = props.autoSelectField, autoSelectField = _props$autoSelectFiel === void 0 ? true : _props$autoSelectFiel, _props$autoSelectOper = props.autoSelectOperator, autoSelectOperator = _props$autoSelectOper === void 0 ? true : _props$autoSelectOper, _props$addRuleToNewGr = props.addRuleToNewGroups, addRuleToNewGroups = _props$addRuleToNewGr === void 0 ? true : _props$addRuleToNewGr, enableDragAndDropProp = props.enableDragAndDrop, independentCombinators = props.independentCombinators, _props$listsAsArrays = props.listsAsArrays, listsAsArrays = _props$listsAsArrays === void 0 ? false : _props$listsAsArrays, _props$parseNumbers = props.parseNumbers, parseNumbers = _props$parseNumbers === void 0 ? false : _props$parseNumbers, _props$disabled = props.disabled, disabled = _props$disabled === void 0 ? false : _props$disabled, _props$displayOnlyFie = props.displayOnlyField, displayOnlyField = _props$displayOnlyFie === void 0 ? false : _props$displayOnlyFie, validator = props.validator, _props$debugMode = props.debugMode, debugModeProp = _props$debugMode === void 0 ? false : _props$debugMode, _props$onLog = props.onLog, onLog = _props$onLog === void 0 ? console.log : _props$onLog, _props$idGenerator = props.idGenerator, idGenerator = _props$idGenerator === void 0 ? generateID : _props$idGenerator;
  var rqbContext = useMergedContext({
    controlClassnames: controlClassnamesProp,
    controlElements: controlElementsProp,
    debugMode: debugModeProp,
    enableDragAndDrop: enableDragAndDropProp,
    enableMountQueryChange: enableMountQueryChangeProp,
    translations: translationsProp
  });
  var controlClassnames = rqbContext.controlClassnames, controlElements = rqbContext.controlElements, debugMode = rqbContext.debugMode, enableDragAndDrop = rqbContext.enableDragAndDrop, enableMountQueryChange = rqbContext.enableMountQueryChange, translations = rqbContext.translations;
  var defaultField = useMemo(function() {
    return {
      id: translations.fields.placeholderName,
      name: translations.fields.placeholderName,
      label: translations.fields.placeholderLabel
    };
  }, [translations.fields.placeholderLabel, translations.fields.placeholderName]);
  var fieldsProp = useMemo(function() {
    return fieldsPropOriginal != null ? fieldsPropOriginal : [defaultField];
  });
  var fields = useMemo(function() {
    var f = Array.isArray(fieldsProp) ? fieldsProp : objectKeys(fieldsProp).map(function(fld) {
      return _extends({}, fieldsProp[fld], {
        name: fld
      });
    }).sort(function(a, b) {
      return a.label.localeCompare(b.label);
    });
    if (isOptionGroupArray(f)) {
      if (autoSelectField) {
        return uniqOptGroups(f);
      } else {
        return uniqOptGroups([{
          label: translations.fields.placeholderGroupLabel,
          options: [defaultField]
        }].concat(f));
      }
    } else {
      if (autoSelectField) {
        return uniqByName(f);
      } else {
        return uniqByName([defaultField].concat(f));
      }
    }
  }, [autoSelectField, defaultField, fieldsProp, translations.fields.placeholderGroupLabel]);
  var fieldMap = useMemo(function() {
    if (!Array.isArray(fieldsProp)) {
      var fp = {};
      objectKeys(fieldsProp).forEach(function(f) {
        return fp[f] = _extends({}, fieldsProp[f], {
          name: f
        });
      });
      if (autoSelectField) {
        return fp;
      } else {
        var _extends2;
        return _extends({}, fp, (_extends2 = {}, _extends2[translations.fields.placeholderName] = defaultField, _extends2));
      }
    }
    var fm = {};
    if (isOptionGroupArray(fields)) {
      fields.forEach(function(f) {
        return f.options.forEach(function(opt) {
          return fm[opt.name] = opt;
        });
      });
    } else {
      fields.forEach(function(f) {
        return fm[f.name] = f;
      });
    }
    return fm;
  }, [autoSelectField, defaultField, fields, fieldsProp, translations.fields.placeholderName]);
  var defaultOperator = useMemo(function() {
    return {
      id: translations.operators.placeholderName,
      name: translations.operators.placeholderName,
      label: translations.operators.placeholderLabel
    };
  }, [translations.operators.placeholderLabel, translations.operators.placeholderName]);
  var getOperatorsMain = useCallback(function(field) {
    var fieldData = fieldMap[field];
    var opsFinal = operators;
    if (fieldData != null && fieldData.operators) {
      opsFinal = fieldData.operators;
    } else if (getOperators) {
      var ops = getOperators(field);
      if (ops) {
        opsFinal = ops;
      }
    }
    if (!autoSelectOperator) {
      if (isOptionGroupArray(opsFinal)) {
        opsFinal = [{
          label: translations.operators.placeholderGroupLabel,
          options: [defaultOperator]
        }].concat(opsFinal);
      } else {
        opsFinal = [defaultOperator].concat(opsFinal);
      }
    }
    return isOptionGroupArray(opsFinal) ? uniqOptGroups(opsFinal) : uniqByName(opsFinal);
  }, [autoSelectOperator, defaultOperator, fieldMap, getOperators, operators, translations.operators.placeholderGroupLabel]);
  var getRuleDefaultOperator = useCallback(function(field) {
    var _getOperatorsMain, _getFirstOption;
    var fieldData = fieldMap[field];
    if (fieldData != null && fieldData.defaultOperator) {
      return fieldData.defaultOperator;
    }
    if (getDefaultOperator) {
      if (typeof getDefaultOperator === "function") {
        return getDefaultOperator(field);
      } else {
        return getDefaultOperator;
      }
    }
    var ops = (_getOperatorsMain = getOperatorsMain(field)) != null ? _getOperatorsMain : (
      /* istanbul ignore next */
      []
    );
    return ops.length ? (_getFirstOption = getFirstOption(ops)) != null ? _getFirstOption : (
      /* istanbul ignore next */
      ""
    ) : (
      /* istanbul ignore next */
      ""
    );
  });
  var getValueEditorTypeMain = useCallback(function(field, operator) {
    if (getValueEditorType) {
      var vet = getValueEditorType(field, operator);
      if (vet) return vet;
    }
    return "text";
  });
  var getValueSourcesMain = useCallback(function(field, operator) {
    return getValueSourcesUtil(fieldMap[field], operator, getValueSources);
  });
  var getValuesMain = useCallback(function(field, operator) {
    var fieldData = fieldMap[field];
    if (fieldData != null && fieldData.values) {
      return fieldData.values;
    }
    if (getValues) {
      var vals = getValues(field, operator);
      if (vals) return vals;
    }
    return [];
  });
  var getRuleDefaultValue = useCallback(function(rule) {
    var fieldData = fieldMap[rule.field];
    if ((fieldData == null ? void 0 : fieldData.defaultValue) !== void 0 && fieldData.defaultValue !== null) {
      return fieldData.defaultValue;
    } else if (getDefaultValue) {
      return getDefaultValue(rule);
    }
    var value2 = "";
    var values = getValuesMain(rule.field, rule.operator);
    var getFirstOptionsFrom = function getFirstOptionsFrom2(opts) {
      var firstOption = getFirstOption(opts);
      if (rule.operator === "between" || rule.operator === "notBetween") {
        var valueAsArray = [firstOption, firstOption];
        return listsAsArrays ? valueAsArray : joinWith(valueAsArray.map(function(v) {
          return v != null ? v : (
            /* istanbul ignore next */
            ""
          );
        }), ",");
      } else {
        return firstOption;
      }
    };
    if (rule.valueSource === "field") {
      var filteredFields = filterFieldsByComparator(fieldData, fields, rule.operator);
      if (filteredFields.length > 0) {
        value2 = getFirstOptionsFrom(filteredFields);
      } else {
        value2 = "";
      }
    } else if (values.length) {
      value2 = getFirstOptionsFrom(values);
    } else {
      var editorType = getValueEditorTypeMain(rule.field, rule.operator);
      if (editorType === "checkbox") {
        value2 = false;
      }
    }
    return value2;
  });
  var getInputTypeMain = useCallback(function(field, operator) {
    if (getInputType) {
      var inputType = getInputType(field, operator);
      if (inputType) return inputType;
    }
    return "text";
  });
  var createRule = useCallback(function() {
    var _getValueSourcesMain$;
    var field = "";
    if ((fields == null ? void 0 : fields.length) > 0 && fields[0]) {
      var _getFirstOption2;
      field = (_getFirstOption2 = getFirstOption(fields)) != null ? _getFirstOption2 : (
        /* istanbul ignore next */
        ""
      );
    }
    if (getDefaultField) {
      if (typeof getDefaultField === "function") {
        field = getDefaultField(fields);
      } else {
        field = getDefaultField;
      }
    }
    var operator = getRuleDefaultOperator(field);
    var valueSource = (_getValueSourcesMain$ = getValueSourcesMain(field, operator)[0]) != null ? _getValueSourcesMain$ : "value";
    var newRule = {
      id: idGenerator(),
      field,
      operator,
      valueSource,
      value: ""
    };
    var value2 = getRuleDefaultValue(newRule);
    return _extends({}, newRule, {
      value: value2
    });
  });
  var createRuleGroup = useCallback(function() {
    var _getFirstOption3;
    if (independentCombinators) {
      return {
        id: idGenerator(),
        rules: addRuleToNewGroups ? [createRule()] : [],
        not: false
      };
    }
    return {
      id: idGenerator(),
      rules: addRuleToNewGroups ? [createRule()] : [],
      combinator: (_getFirstOption3 = getFirstOption(combinators)) != null ? _getFirstOption3 : (
        /* istanbul ignore next */
        ""
      ),
      not: false
    };
  });
  var isFirstRender = useRef(true, context);
  var _useState = useState(defaultQuery ? _prepareRuleGroup(defaultQuery, {
    idGenerator
  }) : createRuleGroup()), queryState = _useState[0], setQueryState = _useState[1];
  var query = queryProp ? isFirstRender.current ? _prepareRuleGroup(queryProp, {
    idGenerator
  }) : queryProp : queryState;
  useControlledOrUncontrolled({
    defaultQuery,
    queryProp,
    isFirstRender: isFirstRender.current
  });
  isFirstRender.current = false;
  useEffect(function() {
    if (enableMountQueryChange) {
      onQueryChange(query);
    }
  }, []);
  var uncontrolled = !queryProp;
  var dispatch = useCallback(function(newQuery) {
    if (uncontrolled) {
      setQueryState(newQuery);
    }
    onQueryChange(newQuery);
  });
  var queryDisabled = useMemo(function() {
    return disabled === true || Array.isArray(disabled) && disabled.some(function(p) {
      return p.length === 0;
    });
  });
  var disabledPaths = useMemo(function() {
    return Array.isArray(disabled) && disabled || [];
  });
  var onRuleAdd = function onRuleAdd2(rule, parentPath, context2) {
    var _newRule$combinatorPr;
    if (pathIsDisabled(parentPath, query) || queryDisabled) {
      if (debugMode) {
        onLog({
          type: LogType.parentPathDisabled,
          rule,
          parentPath,
          query
        });
      }
      return;
    }
    var newRule = onAddRule(rule, parentPath, query, context2);
    if (!newRule) {
      if (debugMode) {
        onLog({
          type: LogType.onAddRuleFalse,
          rule,
          parentPath,
          query
        });
      }
      return;
    }
    var newQuery = add(query, newRule, parentPath, {
      combinators,
      combinatorPreceding: (_newRule$combinatorPr = newRule.combinatorPreceding) != null ? _newRule$combinatorPr : void 0
    });
    if (debugMode) {
      onLog({
        type: LogType.add,
        query,
        newQuery,
        newRule,
        parentPath
      });
    }
    dispatch(newQuery);
  };
  var onGroupAdd = function onGroupAdd2(ruleGroup2, parentPath, context2) {
    var _newGroup$combinatorP;
    if (pathIsDisabled(parentPath, query) || queryDisabled) {
      if (debugMode) {
        onLog({
          type: LogType.parentPathDisabled,
          ruleGroup: ruleGroup2,
          parentPath,
          query
        });
      }
      return;
    }
    var newGroup = onAddGroup(ruleGroup2, parentPath, query, context2);
    if (!newGroup) {
      if (debugMode) {
        onLog({
          type: LogType.onAddGroupFalse,
          ruleGroup: ruleGroup2,
          parentPath,
          query
        });
      }
      return;
    }
    var newQuery = add(query, newGroup, parentPath, {
      combinators,
      combinatorPreceding: (_newGroup$combinatorP = newGroup.combinatorPreceding) != null ? _newGroup$combinatorP : void 0
    });
    if (debugMode) {
      onLog({
        type: LogType.add,
        query,
        newQuery,
        newGroup,
        parentPath
      });
    }
    dispatch(newQuery);
  };
  var onPropChange = function onPropChange2(prop, value2, path) {
    if (pathIsDisabled(path, query) && prop !== "disabled" || queryDisabled) {
      if (debugMode) {
        onLog({
          type: LogType.pathDisabled,
          path,
          prop,
          value: value2,
          query
        });
      }
      return;
    }
    var newQuery = update2(query, prop, value2, path, {
      resetOnFieldChange,
      resetOnOperatorChange,
      getRuleDefaultOperator,
      getValueSources: getValueSourcesMain,
      getRuleDefaultValue
    });
    if (debugMode) {
      onLog({
        type: LogType.update,
        query,
        newQuery,
        prop,
        value: value2,
        path
      });
    }
    dispatch(newQuery);
  };
  var onRuleOrGroupRemove = function onRuleOrGroupRemove2(path, context2) {
    if (pathIsDisabled(path, query) || queryDisabled) {
      if (debugMode) {
        onLog({
          type: LogType.pathDisabled,
          path,
          query
        });
      }
      return;
    }
    var ruleOrGroup = findPath(path, query);
    if (ruleOrGroup) {
      if (onRemove(ruleOrGroup, path, query, context2)) {
        var newQuery = remove(query, path);
        if (debugMode) {
          onLog({
            type: LogType.remove,
            query,
            newQuery,
            path,
            ruleOrGroup
          });
        }
        dispatch(newQuery);
      } else {
        if (debugMode) {
          onLog({
            type: LogType.onRemoveFalse,
            ruleOrGroup,
            path,
            query
          });
        }
      }
    }
  };
  var moveRule = function moveRule2(oldPath, newPath, clone) {
    if (pathIsDisabled(oldPath, query) || queryDisabled) {
      if (debugMode) {
        onLog({
          type: LogType.pathDisabled,
          oldPath,
          newPath,
          query
        });
      }
      return;
    }
    var newQuery = move(query, oldPath, newPath, {
      clone,
      combinators
    });
    if (debugMode) {
      onLog({
        type: LogType.move,
        query,
        newQuery,
        oldPath,
        newPath,
        clone
      });
    }
    dispatch(newQuery);
  };
  var _useMemo = useMemo(function() {
    var validationResult2 = typeof validator === "function" ? validator(query) : {};
    var validationMap2 = typeof validationResult2 === "object" ? validationResult2 : {};
    return {
      validationResult: validationResult2,
      validationMap: validationMap2
    };
  }), validationResult = _useMemo.validationResult, validationMap = _useMemo.validationMap;
  var schema = useMemo(function() {
    return {
      fields,
      fieldMap,
      combinators,
      classNames: controlClassnames,
      createRule,
      createRuleGroup,
      controls: controlElements,
      getOperators: getOperatorsMain,
      getValueEditorType: getValueEditorTypeMain,
      getValueSources: getValueSourcesMain,
      getInputType: getInputTypeMain,
      getValues: getValuesMain,
      getValueEditorSeparator,
      getRuleClassname,
      getRuleGroupClassname,
      showCombinatorsBetweenRules,
      showNotToggle,
      showCloneButtons,
      showNewGroup,
      showNewRule,
      isGroupDisable,
      isRuleDisable,
      groupLimit,
      ruleLimit,
      allowDelAll,
      showLockButtons,
      autoSelectField,
      autoSelectOperator,
      addRuleToNewGroups,
      enableDragAndDrop,
      independentCombinators: !!independentCombinators,
      listsAsArrays,
      parseNumbers,
      validationMap,
      disabledPaths,
      bindProps
    };
  });
  var actions = {
    onRuleAdd,
    onGroupAdd,
    onRuleRemove: onRuleOrGroupRemove,
    onGroupRemove: onRuleOrGroupRemove,
    onPropChange,
    moveRule
  };
  var wrapperClassName = useMemo(function() {
    var _clsx;
    return clsx(standardClassnames.queryBuilder, clsx(controlClassnames.queryBuilder), (_clsx = {}, _clsx[standardClassnames.branches] = showBranches, _clsx[standardClassnames.disabled] = query.disabled || queryDisabled, _clsx[standardClassnames.displayOnlyField] = displayOnlyField, _clsx[standardClassnames.valid] = typeof validationResult === "boolean" && validationResult, _clsx[standardClassnames.invalid] = typeof validationResult === "boolean" && !validationResult, _clsx));
  }, [controlClassnames.queryBuilder, queryDisabled, query.disabled, validationResult]);
  return {
    actions,
    query,
    queryDisabled,
    rqbContext,
    schema,
    translations,
    wrapperClassName
  };
};
var useRule = function useRule2(props) {
  var _fieldData$inputType, _fieldData$valueSourc, _ref16, _fieldData$values, _validationMap, _clsx2;
  var id = props.id, path = props.path, ruleProp = props.rule, schema = props.schema, actions = props.actions, disabledProp = props.disabled, parentDisabled = props.parentDisabled, fieldProp = props.field, operatorProp = props.operator, valueProp = props.value, valueSourceProp = props.valueSource, _props$dragMonitorId = props.dragMonitorId, dragMonitorId = _props$dragMonitorId === void 0 ? "" : _props$dragMonitorId, _props$dropMonitorId = props.dropMonitorId, dropMonitorId = _props$dropMonitorId === void 0 ? "" : _props$dropMonitorId, _props$dndRef = props.dndRef, dndRef = _props$dndRef === void 0 ? null : _props$dndRef, _props$dragRef = props.dragRef, dragRef = _props$dragRef === void 0 ? null : _props$dragRef, _props$isDragging = props.isDragging, isDragging = _props$isDragging === void 0 ? false : _props$isDragging, _props$isOver = props.isOver, isOver = _props$isOver === void 0 ? false : _props$isOver, onlyOne2 = props.onlyOne;
  var classNamesProp = schema.classNames, fields = schema.fields, fieldMap = schema.fieldMap, getInputType = schema.getInputType, getOperators = schema.getOperators, getValueEditorType = schema.getValueEditorType, getValueEditorSeparator = schema.getValueEditorSeparator, getValueSources = schema.getValueSources, getValues = schema.getValues, validationMap = schema.validationMap, getRuleClassname = schema.getRuleClassname;
  var moveRule = actions.moveRule, onPropChange = actions.onPropChange, onRuleRemove = actions.onRuleRemove;
  var disabled = !!parentDisabled || !!disabledProp;
  var rule = ruleProp || {
    field: fieldProp,
    operator: operatorProp,
    value: valueProp,
    valueSource: valueSourceProp
  };
  var field = rule.field, operator = rule.operator, value2 = rule.value, valueSource = rule.valueSource;
  useDeprecatedProps("rule", !!ruleProp);
  var classNames = useMemo(function() {
    return {
      dragHandle: clsx(standardClassnames.dragHandle, classNamesProp.dragHandle),
      fields: clsx(standardClassnames.fields, classNamesProp.fields),
      operators: clsx(standardClassnames.operators, classNamesProp.operators),
      valueSource: clsx(standardClassnames.valueSource, classNamesProp.valueSource),
      value: clsx(standardClassnames.value, classNamesProp.value),
      cloneRule: clsx(standardClassnames.cloneRule, classNamesProp.cloneRule),
      lockRule: clsx(standardClassnames.lockRule, classNamesProp.lockRule),
      removeRule: clsx(standardClassnames.removeRule, classNamesProp.removeRule),
      clearData: clsx(standardClassnames.clearData, classNamesProp.clearData)
    };
  }, [classNamesProp.dragHandle, classNamesProp.fields, classNamesProp.operators, classNamesProp.valueSource, classNamesProp.value, classNamesProp.cloneRule, classNamesProp.lockRule, classNamesProp.removeRule, classNamesProp.clearData]);
  var generateOnChangeHandler = function generateOnChangeHandler2(prop) {
    return function(value22) {
      if (!disabled) {
        onPropChange(prop, value22, path);
      }
    };
  };
  var cloneRule = function cloneRule2(_event) {
    if (!disabled) {
      var newPath = [].concat(getParentPath(path), [path[path.length - 1] + 1]);
      moveRule(path, newPath, true);
    }
  };
  var toggleLockRule = function toggleLockRule2(_event) {
    onPropChange("disabled", !disabled, path);
  };
  var removeRule = function removeRule2(_event) {
    if (!disabled) {
      if (schema.allowDelAll) {
        onRuleRemove(path);
      } else {
        onRuleRemove(onlyOne2 ? path.slice(0, -1) : path);
      }
    }
  };
  var clearData = function clearData2(_event) {
    onPropChange("value", "", path);
    onPropChange("field", "", path);
  };
  var findFieldData = function findFieldData2(field2, fieldList) {
    var len = fieldList.length;
    for (var i = 0; i < len; i++) {
      var rules = fieldList[i];
      if (rules.name === field2) {
        return rules;
      }
      if (!(rules.children && rules.children.length)) {
        continue;
      }
      var clen = rules.children.length;
      for (var j = 0; j < clen; j++) {
        var rule2 = rules.children[j];
        if (rule2.name === field2) {
          return rule2;
        }
      }
    }
    return {
      name: field2,
      label: field2
    };
  };
  var fieldData = fieldMap != null && fieldMap[field] ? fieldMap[field] : findFieldData(field, fields);
  var inputType = (_fieldData$inputType = fieldData.inputType) != null ? _fieldData$inputType : getInputType(field, operator);
  var operators = getOperators(field);
  var operatorObject = getOption(operators, operator);
  var arity = operatorObject == null ? void 0 : operatorObject.arity;
  var hideValueControls = typeof arity === "string" && arity === "unary" || typeof arity === "number" && arity < 2;
  var valueSources = typeof fieldData.valueSources === "function" ? fieldData.valueSources(operator) : (_fieldData$valueSourc = fieldData.valueSources) != null ? _fieldData$valueSourc : getValueSources(field, operator);
  var valueEditorType = valueSource === "field" ? "select" : (_ref16 = typeof fieldData.valueEditorType === "function" ? fieldData.valueEditorType(operator) : fieldData.valueEditorType) != null ? _ref16 : getValueEditorType(field, operator);
  var valueEditorSeparator = getValueEditorSeparator(field, operator);
  var values = valueSource === "field" ? filterFieldsByComparator(fieldData, fields, operator) : (_fieldData$values = fieldData.values) != null ? _fieldData$values : getValues(field, operator);
  var valueSourceOptions = valueSources.map(function(vs) {
    return {
      name: vs,
      label: vs
    };
  });
  var validationResult = (_validationMap = validationMap[id != null ? id : (
    /* istanbul ignore next */
    ""
  )]) != null ? _validationMap : typeof fieldData.validator === "function" ? fieldData.validator({
    id,
    field,
    operator,
    value: value2
  }) : null;
  var validationClassName = getValidationClassNames(validationResult);
  var fieldBasedClassName = useMemo(function() {
    var _fieldData$className;
    return (_fieldData$className = fieldData == null ? void 0 : fieldData.className) != null ? _fieldData$className : "";
  }, [fieldData == null ? void 0 : fieldData.className]);
  var operatorBasedClassName = useMemo(function() {
    var _operatorObject$class;
    return (_operatorObject$class = operatorObject == null ? void 0 : operatorObject.className) != null ? _operatorObject$class : "";
  }, [operatorObject == null ? void 0 : operatorObject.className]);
  var outerClassName = clsx(getRuleClassname(rule), fieldBasedClassName, operatorBasedClassName, standardClassnames.rule, classNamesProp.rule, (_clsx2 = {}, _clsx2[standardClassnames.disabled] = disabled, _clsx2[standardClassnames.dndDragging] = isDragging, _clsx2[standardClassnames.dndOver] = isOver, _clsx2), validationClassName);
  return {
    classNames,
    cloneRule,
    disabled,
    dndRef,
    dragMonitorId,
    dragRef,
    dropMonitorId,
    fieldData,
    generateOnChangeHandler,
    hideValueControls,
    inputType,
    operators,
    outerClassName,
    removeRule,
    clearData,
    rule,
    toggleLockRule,
    validationResult,
    valueEditorSeparator,
    valueEditorType,
    values,
    valueSourceOptions,
    valueSources
  };
};
var useRuleGroup = function useRuleGroup2(props) {
  var _clsx4;
  var id = props.id, path = props.path, ruleGroupProp = props.ruleGroup, schema = props.schema, actions = props.actions, disabledProp = props.disabled, parentDisabled = props.parentDisabled, combinatorProp = props.combinator, rulesProp = props.rules, notProp = props.not, _props$dragMonitorId2 = props.dragMonitorId, dragMonitorId = _props$dragMonitorId2 === void 0 ? "" : _props$dragMonitorId2, _props$dropMonitorId2 = props.dropMonitorId, dropMonitorId = _props$dropMonitorId2 === void 0 ? "" : _props$dropMonitorId2, _props$previewRef = props.previewRef, previewRef = _props$previewRef === void 0 ? null : _props$previewRef, _props$dragRef2 = props.dragRef, dragRef = _props$dragRef2 === void 0 ? null : _props$dragRef2, _props$dropRef = props.dropRef, dropRef = _props$dropRef === void 0 ? null : _props$dropRef, _props$isDragging2 = props.isDragging, isDragging = _props$isDragging2 === void 0 ? false : _props$isDragging2, _props$isOver2 = props.isOver, isOver = _props$isOver2 === void 0 ? false : _props$isOver2;
  var classNamesProp = schema.classNames, combinators = schema.combinators, createRule = schema.createRule, createRuleGroup = schema.createRuleGroup, independentCombinators = schema.independentCombinators, validationMap = schema.validationMap, _schema$getRuleGroupC = schema.getRuleGroupClassname, getRuleGroupClassname = _schema$getRuleGroupC === void 0 ? function() {
    return "";
  } : _schema$getRuleGroupC;
  var onGroupAdd = actions.onGroupAdd, onGroupRemove = actions.onGroupRemove, onPropChange = actions.onPropChange, onRuleAdd = actions.onRuleAdd, moveRule = actions.moveRule;
  var disabled = !!parentDisabled || !!disabledProp;
  var ruleGroup2 = ruleGroupProp ? _extends({}, ruleGroupProp) : {
    rules: rulesProp,
    not: notProp
  };
  var firstCombinator = getFirstOption(combinators);
  var combinator = ruleGroupProp && "combinator" in ruleGroupProp ? ruleGroupProp.combinator : !ruleGroupProp ? combinatorProp != null ? combinatorProp : firstCombinator : firstCombinator;
  if (!independentCombinators) {
    ruleGroup2.combinator = combinator;
  }
  useDeprecatedProps("ruleGroup", !!ruleGroupProp);
  var classNames = useMemo(function() {
    var _clsx3;
    return {
      header: clsx(standardClassnames.header, classNamesProp.header, (_clsx3 = {}, _clsx3[standardClassnames.dndOver] = isOver, _clsx3)),
      dragHandle: clsx(standardClassnames.dragHandle, classNamesProp.dragHandle),
      combinators: clsx(standardClassnames.combinators, classNamesProp.combinators),
      notToggle: clsx(standardClassnames.notToggle, classNamesProp.notToggle),
      addRule: clsx(standardClassnames.addRule, classNamesProp.addRule),
      addGroup: clsx(standardClassnames.addGroup, classNamesProp.addGroup),
      cloneGroup: clsx(standardClassnames.cloneGroup, classNamesProp.cloneGroup),
      lockGroup: clsx(standardClassnames.lockGroup, classNamesProp.lockGroup),
      removeGroup: clsx(standardClassnames.removeGroup, classNamesProp.removeGroup),
      body: clsx(standardClassnames.body, classNamesProp.body)
    };
  }, [classNamesProp.addGroup, classNamesProp.addRule, classNamesProp.body, classNamesProp.cloneGroup, classNamesProp.combinators, classNamesProp.dragHandle, classNamesProp.header, classNamesProp.lockGroup, classNamesProp.notToggle, classNamesProp.removeGroup, isOver]);
  var onCombinatorChange = function onCombinatorChange2(value2) {
    if (!disabled) {
      onPropChange("combinator", value2, path);
    }
  };
  var onIndependentCombinatorChange = function onIndependentCombinatorChange2(value2, index) {
    if (!disabled) {
      onPropChange("combinator", value2, path.concat([index]));
    }
  };
  var onNotToggleChange = function onNotToggleChange2(checked2) {
    if (!disabled) {
      onPropChange("not", checked2, path);
    }
  };
  var addRule = function addRule2(_event, context) {
    if (!disabled) {
      var newRule = createRule();
      onRuleAdd(newRule, path, context);
    }
  };
  var addGroup = function addGroup2(_event, context) {
    if (!disabled) {
      var newGroup = createRuleGroup();
      onGroupAdd(newGroup, path, context);
    }
  };
  var cloneGroup = function cloneGroup2(_event) {
    if (!disabled) {
      var newPath = [].concat(getParentPath(path), [path[path.length - 1] + 1]);
      moveRule(path, newPath, true);
    }
  };
  var toggleLockGroup = function toggleLockGroup2(_event) {
    onPropChange("disabled", !disabled, path);
  };
  var removeGroup = function removeGroup2(_event) {
    if (!disabled) {
      onGroupRemove(path);
    }
  };
  var validationResult = validationMap[id != null ? id : (
    /* istanbul ignore next */
    ""
  )];
  var validationClassName = getValidationClassNames(validationResult);
  var combinatorBasedClassName = useMemo(function() {
    var _getOption$className, _getOption;
    return independentCombinators ? null : (_getOption$className = (_getOption = getOption(combinators, combinator)) == null ? void 0 : _getOption.className) != null ? _getOption$className : "";
  });
  var outerClassName = clsx(getRuleGroupClassname(ruleGroup2), combinatorBasedClassName, standardClassnames.ruleGroup, classNamesProp.ruleGroup, (_clsx4 = {}, _clsx4[standardClassnames.disabled] = disabled, _clsx4[standardClassnames.dndDragging] = isDragging, _clsx4), validationClassName);
  return {
    addGroup,
    addRule,
    classNames,
    cloneGroup,
    combinator,
    disabled,
    dragMonitorId,
    dragRef,
    dropMonitorId,
    dropRef,
    isDragging,
    isOver,
    onCombinatorChange,
    onGroupAdd,
    onIndependentCombinatorChange,
    onNotToggleChange,
    outerClassName,
    parentDisabled,
    previewRef,
    removeGroup,
    ruleGroup: ruleGroup2,
    toggleLockGroup,
    validationClassName,
    validationResult
  };
};
var useSelectElementChangeHandler = function useSelectElementChangeHandler2(_ref17) {
  var multiple = _ref17.multiple, onChange = _ref17.onChange, field = _ref17.field;
  var selectElementChangeHandler3 = useMemo(function() {
    return multiple ? function(e) {
      onChange(Array.from(e).map(function(o) {
        return o;
      }));
    } : function(value2) {
      return onChange(field && typeof value2 === "object" ? value2[field] : value2);
    };
  });
  return selectElementChangeHandler3;
};
var useValueEditor = function useValueEditor2(_ref18) {
  var handleOnChange = _ref18.handleOnChange, inputType = _ref18.inputType, operator = _ref18.operator, value2 = _ref18.value, listsAsArrays = _ref18.listsAsArrays, parseNumbers = _ref18.parseNumbers, values = _ref18.values, skipHook = _ref18.skipHook;
  useEffect(function() {
    if (skipHook) return;
    if (inputType === "number" && !["between", "notBetween", "in", "notIn"].includes(operator) && (typeof value2 === "string" && value2.includes(",") || Array.isArray(value2))) {
      var _toArray$;
      handleOnChange((_toArray$ = toArray(value2)[0]) != null ? _toArray$ : "");
    }
  }, [handleOnChange, inputType, operator, skipHook, value2]);
  var valueAsArray = useMemo(function() {
    return toArray(value2);
  });
  var multiValueHandler = useCallback(function(v, i) {
    var val = produce(valueAsArray, function(va) {
      va[i] = parseNumber(v, {
        parseNumbers
      });
      if (i === 0 && (operator === "between" || operator === "notBetween") && !va[1]) {
        va[1] = getFirstOption(values);
      }
    });
    handleOnChange(listsAsArrays ? val : joinWith(val, ","));
  });
  return {
    /**
     * Array of values for when the main value represents a list, e.g. when operator
     * is "between" or "in".
     */
    valueAsArray,
    /**
     * A handler for a series of editors, e.g. when operator is "between".
     * @param {string} val The new value for the editor
     * @param {number} idx The index of the editor
     */
    multiValueHandler
  };
};
var useValueSelector = function useValueSelector2(_ref19) {
  var handleOnChange = _ref19.handleOnChange, _ref19$listsAsArrays = _ref19.listsAsArrays, listsAsArrays = _ref19$listsAsArrays === void 0 ? false : _ref19$listsAsArrays, _ref19$multiple = _ref19.multiple, multiple = _ref19$multiple === void 0 ? false : _ref19$multiple, value2 = _ref19.value;
  var onChange = useCallback(function(v) {
    if (multiple) {
      var valueAsArray = toArray(v);
      handleOnChange(listsAsArrays ? valueAsArray : joinWith(valueAsArray, ","));
    } else {
      handleOnChange(v);
    }
  });
  var val = useMemo(function() {
    return multiple ? toArray(value2) : value2;
  });
  return {
    /**
     * Memoized change handler for value selectors
     */
    onChange,
    /**
     * The value as provided or, if appropriate, as an array
     */
    val
  };
};
var _sfc_main$1 = defineComponent({
  name: "QueryBuilder",
  props: ["defaultQuery", "query", "combinator", "rules", "not", "path", "id", "disabled", "field", "operator", "value", "valueSource", "combinatorPreceding", "independentCombinators", "onLog", "fields", "operators", "combinators", "getDefaultField", "getDefaultOperator", "getDefaultValue", "getOperators", "getValueEditorType", "getValueEditorSeparator", "getValueSources", "getInputType", "getValues", "getRuleClassname", "getRuleGroupClassname", "onAddRule", "onAddGroup", "onRemove", "onQueryChange", "showCombinatorsBetweenRules", "showNotToggle", "showNewGroup", "showNewRule", "isGroupDisable", "isRuleDisable", "groupLimit", "ruleLimit", "showCloneButtons", "showLockButtons", "allowDelAll", "resetOnFieldChange", "resetOnOperatorChange", "autoSelectField", "autoSelectOperator", "addRuleToNewGroups", "listsAsArrays", "parseNumbers", "validateQuery", "validator", "idGenerator", "context", "displayOnlyField", "showBranches", "bindProps"],
  // :QueryBuilderProps
  computed: {
    qb: function qb() {
      return _extends({}, this.$props, useQueryBuilder(this.$props, this));
    },
    ruleGroup: function ruleGroup() {
      var _this$qb$schema, _this$qb$schema$contr;
      return (_this$qb$schema = this.qb.schema) == null ? void 0 : (_this$qb$schema$contr = _this$qb$schema.controls) == null ? void 0 : _this$qb$schema$contr.ruleGroup;
    }
  }
});
var _hoisted_1 = ["data-dnd", "data-inlinecombinators"];
function _sfc_render$1(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", {
    key: _ctx.qb.schema.enableDragAndDrop ? "dnd" : "no-dnd"
  }, [createElementVNode("div", {
    class: normalizeClass(_ctx.qb.wrapperClassName),
    "data-dnd": _ctx.qb.schema.enableDragAndDrop ? "enabled" : "disabled",
    "data-inlinecombinators": _ctx.qb.schema.independentCombinators || _ctx.qb.schema.showCombinatorsBetweenRules ? "enabled" : "disabled"
  }, [(openBlock(), createBlock(resolveDynamicComponent(_ctx.ruleGroup), {
    translations: _ctx.qb.translations,
    "rule-group": _ctx.query,
    rules: _ctx.query.rules,
    combinator: "combinator" in _ctx.query ? _ctx.query.combinator : void 0,
    not: !!_ctx.query.not,
    schema: _ctx.qb.schema,
    actions: _ctx.qb.actions,
    id: _ctx.query.id,
    path: [],
    disabled: !!_ctx.query.disabled || _ctx.qb.queryDisabled,
    "parent-disabled": _ctx.qb.queryDisabled,
    context: _ctx.qb.context
  }, null, 8, ["translations", "rule-group", "rules", "combinator", "not", "schema", "actions", "id", "disabled", "parent-disabled", "context"]))], 10, _hoisted_1)]);
}
var QueryBuilder$1 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render$1]]);
var getFormatQueryString = function getFormatQueryString2(query, options) {
  var formatQueryResult = formatQuery(query, options);
  if (options.format === "json_without_ids") {
    var result;
    try {
      result = JSON.stringify(JSON.parse(formatQueryResult), null, 2);
    } catch (e) {
      result = formatQueryResult;
      console.error(options.format, e);
    }
    return result;
  } else if (options.format === "parameterized" || options.format === "parameterized_named" || options.format === "jsonlogic") {
    return JSON.stringify(formatQueryResult, null, 2);
  }
  return formatQueryResult;
};
var _sfc_main = defineComponent({
  inheritAttrs: false,
  name: $prefix + "QueryBuilder",
  components: {
    QueryBuilder: QueryBuilder$1
  },
  provide: function provide() {
    return {
      queryBuilderRoot: this
    };
  },
  props: {
    config: Object,
    query: Object,
    onQueryChange: Function,
    maxHeight: String
  },
  data: function data3() {
    return {
      getFormatQuery: getFormatQueryString,
      validator: null
    };
  },
  computed: {
    showClearBtn: function showClearBtn() {
      var _this$query;
      var rules = ((_this$query = this.query) == null ? void 0 : _this$query.rules) || [];
      return !this.config.allowDelAll && this.getRuleTotal(rules) <= 1;
    },
    style: function style() {
      return !this.maxHeight ? {} : {
        maxHeight: isNaN(Number(this.maxHeight)) ? this.maxHeight : this.maxHeight + "px",
        overflow: "auto"
      };
    }
  },
  watch: {
    "config.validateQuery": function configValidateQuery(val, oldVal) {
      if (val !== oldVal) {
        this.validator = val && (this.config.validator || defaultValidator);
      }
    }
  },
  setup: function setup12(props, context) {
    return setup({
      props,
      context,
      renderless,
      api,
      mono: true
    });
  },
  methods: {
    getRuleTotal: function getRuleTotal(rules) {
      if (rules === void 0) {
        rules = [];
      }
      var len = rules.length;
      if (len === 1 && rules[0].rules) {
        return this.getRuleTotal(rules[0].rules);
      }
      return len;
    }
  }
});
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_query_builder = resolveComponent("query-builder");
  return openBlock(), createElementBlock(
    "div",
    {
      class: "tiny-query-builder",
      style: normalizeStyle(_ctx.style)
    },
    [createVNode(_component_query_builder, mergeProps({
      key: "queryIC"
    }, _ctx.config, {
      "independent-combinators": "",
      query: _ctx.query,
      validator: _ctx.validator,
      "on-query-change": _ctx.onQueryChange
    }), null, 16, ["query", "validator", "on-query-change"])],
    4
    /* STYLE */
  );
}
var QueryBuilder = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
var version = "3.undefined";
QueryBuilder.model = {
  prop: "modelValue",
  event: "update:modelValue"
};
QueryBuilder.install = function(Vue) {
  Vue.component(QueryBuilder.name, QueryBuilder);
};
QueryBuilder.version = version;

export { QueryBuilder as default };
