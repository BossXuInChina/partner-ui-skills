import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  viewBox: "0 0 24 24",
  xmlns: "http://www.w3.org/2000/svg"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "g",
  {
    "clip-path": "url(#customs-clearance-form_svg__clip131_1880)"
  },
  [/* @__PURE__ */ createElementVNode("path", {
    d: "M16 2H6a3 3 0 0 0-3 3v14a3 3 0 0 0 3 3h5.893A7 7 0 0 1 19 9.937V5a3 3 0 0 0-3-3ZM6 5.25h7.5c.42 0 .75.33.75.75s-.33.75-.75.75H6c-.42 0-.75-.33-.75-.75s.33-.75.75-.75Zm0 3.5h2c.42 0 .75.33.75.75s-.33.75-.75.75H6c-.42 0-.75-.33-.75-.75s.33-.75.75-.75ZM10 16a5.5 5.5 0 1 1 11 0 5.5 5.5 0 0 1-11 0Zm3.466-2.5a2 2 0 1 1 2.777 1.844V16H17c.42 0 .75.33.75.75s-.33.75-.75.75h-.757v1.166a3.212 3.212 0 0 0 .922-.375 3.25 3.25 0 0 0 1.171-1.202.742.742 0 0 1 1.021-.287.743.743 0 0 1 .287 1.021 4.793 4.793 0 0 1-1.228 1.427 4.758 4.758 0 0 1-2.128.935 4.786 4.786 0 0 1-2.623-.303 4.765 4.765 0 0 1-2.309-2.059.743.743 0 0 1 .287-1.021.743.743 0 0 1 1.02.287 3.247 3.247 0 0 0 1.17 1.203 3.212 3.212 0 0 0 .91.371V17.5H14c-.42 0-.75-.33-.75-.75s.33-.75.75-.75h.743v-.635a2.001 2.001 0 0 1-1.277-1.865Zm1.5 0a.5.5 0 1 1 1 0 .5.5 0 0 1-1 0Z",
    "fill-rule": "evenodd"
  })],
  -1
  /* HOISTED */
);
var _hoisted_3 = [_hoisted_2];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_3));
}
var CustomsClearanceForm = {
  render
};
var customsClearanceForm = function customsClearanceForm2() {
  return svg({
    name: "IconCustomsClearanceForm",
    component: CustomsClearanceForm,
    filledComponent: CustomsClearanceForm
  })();
};
export {
  customsClearanceForm as default
};
