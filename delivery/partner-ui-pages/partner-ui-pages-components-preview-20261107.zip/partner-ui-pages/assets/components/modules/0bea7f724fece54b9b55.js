function _extends() {
  return _extends = Object.assign ? Object.assign.bind() : function(n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends.apply(null, arguments);
}
import { defineComponent, $props, $setup, $prefix } from "@opentiny/vue-common";
import PcTemplate from "./pc.js";
import "@opentiny/vue-theme/bulletin-board/index.css";
var template = function template2(mode) {
  var _process$env;
  typeof process === "object" ? (_process$env = process.env) == null ? void 0 : _process$env.TINY_MODE : null;
  return PcTemplate;
};
var BulletinBoard = defineComponent({
  name: $prefix + "BulletinBoard",
  props: _extends({}, $props, {
    title: String,
    icon: [Object, String],
    showMore: {
      type: Boolean,
      default: true
    },
    moreLink: {
      type: Object,
      default: function _default() {
      }
    },
    tabTitle: {
      type: Array,
      required: true,
      validator: function validator(value) {
        return Array.isArray(value) && value.length > 0;
      }
    },
    activeName: {
      type: String,
      default: "1"
    },
    data: {
      type: Array,
      required: true
    }
  }),
  setup: function setup(props, context) {
    return $setup({
      props,
      context,
      template
    });
  }
});
var version = "3.undefined";
BulletinBoard.install = function(Vue) {
  Vue.component(BulletinBoard.name, BulletinBoard);
};
BulletinBoard.version = version;
export {
  BulletinBoard as default
};
