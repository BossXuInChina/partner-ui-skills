function _extends() {
  return _extends = Object.assign ? Object.assign.bind() : function(n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends.apply(null, arguments);
}
import { defineComponent, $props, $setup, $prefix } from "@opentiny/vue-common";
import PcTemplate from "./pc.js";
import MobileFirstTemplate from "./mobile-first.js";
var template = function template2(mode) {
  var _process$env;
  var tinyMode = typeof process === "object" ? (_process$env = process.env) == null ? void 0 : _process$env.TINY_MODE : null;
  if ("pc" === (tinyMode || mode)) {
    return PcTemplate;
  }
  if ("mobile-first" === (tinyMode || mode)) {
    return MobileFirstTemplate;
  }
  return PcTemplate;
};
var Sticky = defineComponent({
  name: $prefix + "Sticky",
  props: _extends({}, $props, {
    zIndex: {
      type: [Number, String],
      default: function _default() {
        return 100;
      }
    },
    target: String,
    offset: {
      type: [Number, String],
      default: function _default2() {
        return 0;
      }
    },
    position: {
      type: String,
      values: ["top", "bottom"],
      default: function _default3() {
        return "top";
      }
    }
  }),
  setup: function setup(props, context) {
    return $setup({
      props,
      context,
      template
    });
  }
});
var version = "3.undefined";
Sticky.install = function(Vue) {
  Vue.component(Sticky.name, Sticky);
};
Sticky.version = version;
export {
  Sticky as default
};
