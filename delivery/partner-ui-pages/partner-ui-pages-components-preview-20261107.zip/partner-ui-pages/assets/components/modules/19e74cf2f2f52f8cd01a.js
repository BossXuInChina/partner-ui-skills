import * as P0 from "@workbench/ui-vue3"; window['P0']=P0;
import * as P1 from "huawei-partner-ai-ui"; window['P1']=P1;
import * as P2 from "@opentiny/tiny-robot"; window['P2']=P2;
import * as P3 from "partner-ui/chat"; window['P3']=P3;
import * as P4 from "partner-ui/overlays"; window['P4']=P4;
import * as Vue from 'vue';window.Vue=Vue;