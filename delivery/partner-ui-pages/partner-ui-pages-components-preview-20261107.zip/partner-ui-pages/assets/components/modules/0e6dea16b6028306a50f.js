import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 24 24",
  "xml:space": "preserve"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    class: "panel-normal_svg__st0",
    d: "M14 10H4v10h10v-8H4v-2h10zM4 8h10c.9 0 2 1.1 2 2v10c0 .9-1 2-2 2H4c-.9 0-2-1.1-2-2V10c0-.9 1.1-2 2-2z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    class: "panel-normal_svg__st0",
    d: "M10 8H8V4c0-.9 1.1-2 2-2h10c.9 0 2 1.1 2 2v10c0 .9-1 2-2 2h-4v-2h4V6H10V4h10-10v4z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_4 = [_hoisted_2, _hoisted_3];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_4));
}
var PanelNormal = {
  render
};
var panelNormal = function panelNormal2() {
  return svg({
    name: "IconPanelNormal",
    component: PanelNormal,
    filledComponent: PanelNormal
  })();
};
export {
  panelNormal as default
};
