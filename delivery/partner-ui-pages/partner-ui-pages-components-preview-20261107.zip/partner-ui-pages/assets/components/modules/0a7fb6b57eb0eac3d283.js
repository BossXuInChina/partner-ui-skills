import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  width: "16",
  height: "16",
  viewBox: "0 0 16 16",
  fill: "none",
  xmlns: "http://www.w3.org/2000/svg"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    d: "M4 16h8c2.2 0 4-1.8 4-4V4c0-2.21-1.8-4-4-4H4C1.79 0 0 1.79 0 4v8c0 2.2 1.79 4 4 4Zm3.26-4.38 5.99-6.43a.6.6 0 1 0-.88-.82L6.8 10.35 3.6 7.19a.6.6 0 1 0-.84.86l3.64 3.59c.28.28.57.26.86-.02Z",
    fill: "currentColor",
    "fill-rule": "evenodd"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    d: "M13.25 5.17 7.26 11.6c-.29.29-.58.3-.86.02L2.76 8.03a.6.6 0 0 1-.01-.85c.24-.24.61-.24.85 0l3.2 3.15 5.57-5.98a.6.6 0 0 1 .85-.02c.24.22.26.6.03.84Z",
    fill: "#FFF",
    "fill-rule": "evenodd"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_4 = [_hoisted_2, _hoisted_3];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_4));
}
var CheckedSur = {
  render
};
var checkedSur = function checkedSur2() {
  return svg({
    name: "IconCheckedSur",
    component: CheckedSur,
    filledComponent: CheckedSur
  })();
};
export {
  checkedSur as default
};
