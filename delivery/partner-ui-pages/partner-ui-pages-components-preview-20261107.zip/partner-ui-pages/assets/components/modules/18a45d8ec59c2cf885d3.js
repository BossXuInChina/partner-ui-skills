function _extends() {
  return _extends = Object.assign ? Object.assign.bind() : function(n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends.apply(null, arguments);
}
import { defineComponent, $props, $setup, $prefix } from "@opentiny/vue-common";
import PcTemplate from "./pc.js";
import MobileFirstTemplate from "./mobile-first.js";
var template = function template2(mode) {
  var _process$env;
  var tinyMode = typeof process === "object" ? (_process$env = process.env) == null ? void 0 : _process$env.TINY_MODE : null;
  if ("pc" === (tinyMode || mode)) {
    return PcTemplate;
  }
  if ("mobile-first" === (tinyMode || mode)) {
    return MobileFirstTemplate;
  }
  return PcTemplate;
};
var $constants = {
  MAX: "aria-valuemax",
  MIN: "aria-valuemin",
  VALUENOW: "aria-valuenow",
  DISABLED: "aria-disabled",
  KEY: "role",
  VALUE: "spinbutton",
  EVENT_NAME: {
    blur: "form.blur",
    change: "form.change"
  },
  COMPONENT_NAME: "FormItem",
  FILTER_OPTION: ["ui.numeric.equalTo", "ui.numeric.notEqualTo", "ui.numeric.moreThan", "ui.numeric.moreThanOrEqualTo", "ui.numeric.lessThan", "ui.numeric.lessThanOrEqualTo", "ui.numeric.empty", "ui.numeric.nonEmpty"]
};
var numericProps = _extends({}, $props, {
  _constants: {
    type: Object,
    default: function _default() {
      return $constants;
    }
  },
  allowEmpty: {
    type: Boolean,
    default: false
  },
  emptyValue: {
    default: void 0
  },
  circulate: Boolean,
  controls: {
    type: Boolean,
    default: true
  },
  controlsPosition: {
    type: String,
    default: "",
    validator: function validator(value) {
      return ["", "right"].includes(value);
    }
  },
  disabled: Boolean,
  format: [Object, String],
  hideUnit: {
    type: Boolean,
    default: false
  },
  holdZero: {
    type: Boolean,
    default: true
  },
  label: String,
  max: {
    type: [Number, String],
    default: Infinity
  },
  min: {
    type: [Number, String],
    default: -Infinity
  },
  modelTruncation: {
    type: Boolean,
    default: true
  },
  modelValue: [Number, String],
  mouseWheel: Boolean,
  name: String,
  placeholder: String,
  plugin: Function,
  precision: {
    type: Number,
    validator: function validator2(val) {
      return val >= 0 && val === parseInt(val, 10);
    }
  },
  size: String,
  step: {
    type: [Number, String, Object],
    default: 1
  },
  stepStrictly: {
    type: Boolean,
    default: false
  },
  strictInput: {
    type: Boolean,
    default: false
  },
  stringMode: Boolean,
  tabindex: {
    type: String,
    default: "1"
  },
  theme: {
    type: String,
    default: ""
  },
  unit: String,
  unitCenter: {
    type: Boolean,
    default: false
  },
  validateEvent: {
    type: Boolean,
    default: true
  },
  displayOnly: {
    type: Boolean,
    default: false
  },
  showLeft: {
    type: Boolean,
    default: false
  },
  showEmptyValue: {
    type: Boolean,
    default: false
  },
  title: {
    type: String,
    default: ""
  },
  tip: String,
  shape: String,
  clearable: {
    type: Boolean,
    default: true
  },
  filter: {
    type: Boolean,
    default: true
  },
  blank: {
    type: Boolean,
    default: true
  },
  changeCompat: {
    type: Boolean,
    default: false
  },
  parseInput: {
    type: Function
  }
});
var Numeric = defineComponent({
  name: $prefix + "Numeric",
  props: numericProps,
  setup: function setup(props, context) {
    return $setup({
      props,
      context,
      template
    });
  }
});
var version = "3.undefined";
Numeric.model = {
  prop: "modelValue",
  event: "update:modelValue"
};
Numeric.install = function(Vue) {
  Vue.component(Numeric.name, Numeric);
};
Numeric.version = version;
export {
  Numeric as default
};
