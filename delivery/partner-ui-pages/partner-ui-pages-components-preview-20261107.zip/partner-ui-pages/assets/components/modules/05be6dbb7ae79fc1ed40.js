import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  version: "1.1",
  id: "right-frozen_svg__图层_1",
  xmlns: "http://www.w3.org/2000/svg",
  x: "0",
  y: "0",
  viewBox: "0 0 16 16",
  style: {
    "enable-background": "new 0 0 16 16"
  },
  "xml:space": "preserve"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    id: "right-frozen_svg__形状结合",
    class: "right-frozen_svg__st0",
    d: "M8.9 1.3c2.1 0 3.8 1.7 3.8 3.8v.7c1.1.3 1.9 1.2 1.9 2.4v4.1c0 1.4-1.1 2.5-2.5 2.5H5.7c-1.4 0-2.5-1.1-2.5-2.5V8.2c0-1.2.8-2.1 1.9-2.4v-.7c0-2.1 1.7-3.8 3.8-3.8zm3.2 5.4H5.7c-.8 0-1.5.7-1.5 1.5v4.1c0 .8.7 1.5 1.5 1.5h6.4c.8 0 1.5-.7 1.5-1.5V8.2c0-.8-.6-1.5-1.5-1.5zM8.9 8.8c.3 0 .5.2.5.5v1.8c0 .3-.2.5-.5.5s-.5-.2-.5-.5V9.3c0-.2.3-.5.5-.5zm0-6.5c-1.6 0-2.8 1.3-2.8 2.8v.6h5.6v-.6c0-1.6-1.2-2.8-2.8-2.8z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    class: "right-frozen_svg__st0",
    d: "M2.3 14.1c0 .3-.2.5-.5.5s-.5-.2-.5-.5v-12c0-.3.2-.5.5-.5s.5.2.5.5v12z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_4 = [_hoisted_2, _hoisted_3];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_4));
}
var RightFrozen = {
  render
};
var rightFrozen = function rightFrozen2() {
  return svg({
    name: "IconRightFrozen",
    component: RightFrozen,
    filledComponent: RightFrozen
  })();
};
export {
  rightFrozen as default
};
