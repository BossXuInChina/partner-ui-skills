import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createStaticVNode } from "vue";
var _hoisted_1 = {
  viewBox: "0 0 9 17",
  xmlns: "http://www.w3.org/2000/svg"
};
var _hoisted_2 = /* @__PURE__ */ createStaticVNode('<g fill-rule="evenodd"><path d="M4 0h1v17H4V0zm0 8.5h1v6H4v-6zm0-6h1v6H4v-6z" opacity=".5"></path><path d="M0 9h9v5H0z"></path><path opacity=".4" d="M1 4h7v3H1z"></path><path d="M1 4v3h7V4H1zM0 3h9v5H0V3z"></path></g>', 1);
var _hoisted_3 = [_hoisted_2];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_3));
}
var AlignFlexCenter = {
  render
};
var alignFlexCenter = function alignFlexCenter2() {
  return svg({
    name: "IconAlignFlexCenter",
    component: AlignFlexCenter,
    filledComponent: AlignFlexCenter
  })();
};
export {
  alignFlexCenter as default
};
