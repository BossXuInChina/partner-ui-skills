function _extends() {
  return _extends = Object.assign ? Object.assign.bind() : function(n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends.apply(null, arguments);
}
import { defineComponent, $props, $setup, $prefix } from "@opentiny/vue-common";
import PcTemplate from "./pc.js";
import MobileFirstTemplate from "./mobile-first.js";
var template = function template2(mode) {
  var _process$env;
  var tinyMode = typeof process === "object" ? (_process$env = process.env) == null ? void 0 : _process$env.TINY_MODE : null;
  if ("pc" === (tinyMode || mode)) {
    return PcTemplate;
  }
  if ("mobile-first" === (tinyMode || mode)) {
    return MobileFirstTemplate;
  }
  return PcTemplate;
};
var $constants = {
  FORM_ITEM: "FormItem",
  FORM_CHANGE: "form.change"
};
var CheckboxGroup = defineComponent({
  name: $prefix + "CheckboxGroup",
  componentName: "CheckboxGroup",
  emits: ["change", "update:modelValue"],
  props: _extends({}, $props, {
    _constants: {
      type: Object,
      default: function _default() {
        return $constants;
      }
    },
    modelValue: {},
    disabled: Boolean,
    min: Number,
    max: Number,
    size: String,
    fill: String,
    textColor: String,
    vertical: Boolean,
    options: {
      type: Array,
      default: function _default2() {
        return [];
      }
    },
    type: {
      type: String,
      default: "checkbox"
    },
    displayOnly: {
      type: Boolean,
      default: false
    },
    iconPosition: String,
    shape: {
      type: String,
      default: ""
    }
  }),
  setup: function setup(props, context) {
    return $setup({
      props,
      context,
      template
    });
  }
});
var version = "3.undefined";
CheckboxGroup.model = {
  prop: "modelValue",
  event: "update:modelValue"
};
CheckboxGroup.install = function(Vue) {
  Vue.component(CheckboxGroup.name, CheckboxGroup);
};
CheckboxGroup.version = version;
export {
  CheckboxGroup as default
};
