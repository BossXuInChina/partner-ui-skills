function _extends() {
  return _extends = Object.assign ? Object.assign.bind() : function(n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends.apply(null, arguments);
}
import { renderless } from "@opentiny/vue-renderless/tab-item-mf/vue";
import { defineComponent, $props, h, setup as _setup } from "@opentiny/vue-common";
var _sfc_main = defineComponent({
  props: _extends({}, $props, {
    title: String,
    name: String,
    selected: Boolean,
    renderTitle: Function,
    renderSetting: Function,
    lazy: Boolean
  }),
  setup: function setup(props, context) {
    return _setup({
      props,
      context,
      renderless,
      api: null
    });
  },
  render: function render() {
    return h("div", {
      attrs: {
        "data-tag": "tab-item-" + this.name
      }
    });
  }
});
export {
  _sfc_main as default
};
