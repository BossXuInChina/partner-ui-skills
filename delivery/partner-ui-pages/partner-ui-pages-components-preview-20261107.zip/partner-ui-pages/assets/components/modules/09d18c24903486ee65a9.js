import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 24 24",
  "xml:space": "preserve"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    class: "defined-filtration_svg__st0",
    d: "M18.8 3.2c-.3-.7-1-1.2-1.8-1.2H2.9c-.7 0-1.4.5-1.8 1.2s-.1 1.6.5 2.2L8 11.7V18c0 .2.1.4.2.6l2.9 3.1c.2.2.4.3.6.3.1 0 .2 0 .3-.1.3-.1.5-.4.5-.8v-9.5l5.8-6.3c.7-.5.8-1.3.5-2.1zm-1.9 1.2-5.8 6.4c-.2.2-.2.4-.2.6V19l-1.2-1.4v-6.2c0-.2-.1-.4-.2-.6L3.1 4.4C3 4.3 3 4.2 3 4.2c0-.1.1-.2.2-.2h13.5c.2 0 .3.1.3.2 0 0 0 .1-.1.2zM17.2 16.4l4.2-4.2c.4-.4 1-.4 1.4 0 .4.4.4 1 0 1.4l-4.2 4.2c-.4.4-1 .4-1.4 0-.4-.4-.4-1 0-1.4zM16 19h6c.6 0 1 .4 1 1s-.4 1-1 1h-6c-.6 0-1-.4-1-1s.4-1 1-1z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = [_hoisted_2];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_3));
}
var DefinedFiltration = {
  render
};
var definedFiltration = function definedFiltration2() {
  return svg({
    name: "IconDefinedFiltration",
    component: DefinedFiltration,
    filledComponent: DefinedFiltration
  })();
};
export {
  definedFiltration as default
};
