function _extends() {
  return _extends = Object.assign ? Object.assign.bind() : function(n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends.apply(null, arguments);
}
import { defineComponent, $setup, $prefix } from "@opentiny/vue-common";
import { iconClose } from "@opentiny/vue-icon";
import { api } from "@opentiny/vue-renderless/picker/vue";
import PcTemplate from "./pc.js";
import "@opentiny/vue-theme/date-picker/index.css";
var template = function template2(mode) {
  var _process$env;
  typeof process === "object" ? (_process$env = process.env) == null ? void 0 : _process$env.TINY_MODE : null;
  return PcTemplate;
};
var currentYear = (/* @__PURE__ */ new Date()).getFullYear();
var $constants = {
  MonthDay: 32,
  Minutes: 59,
  Hours: 23,
  TotalMonth: 12,
  Max: "max",
  Min: "min",
  Hour: "hour",
  Minute: "minute",
  CapYear: "Year",
  CapMonth: "Month",
  CapDate: "Date",
  CapHour: "Hour",
  CapMinute: "Minute",
  YearMonth: "year-month",
  DateTime: "datetime",
  Date: "date",
  HookMounted: "hook-mounted",
  Hidden: "hidden",
  Year: "year",
  Day: "day"
};
var validator = function validator2(value) {
  var result = value === null || value === void 0 || typeof value === "string" || value instanceof String || Array.isArray(value) && value.length === 2 && value.every(function(item) {
    return typeof item === "string" || item instanceof String;
  });
  return result;
};
var $props = {
  "tiny_mode": String,
  "tiny_mode_root": Boolean,
  "tiny_template": [Function, Object],
  "tiny_renderless": Function,
  "tiny_theme": String,
  "tiny_chart_theme": Object
};
var datePickerProps = _extends({}, $props, {
  tabindex: {
    type: String,
    default: "0"
  },
  timeFormat: String,
  suffixIcon: Object,
  label: String,
  shape: String,
  tip: String,
  changeOnConfirm: {
    type: Boolean,
    default: false
  },
  popperAppendToBody: {
    type: Boolean,
    default: true
  },
  isutc8: {
    type: Boolean,
    default: false
  },
  dbTimezone: Number,
  timezoneOffset: Number,
  iso8601: Boolean,
  autoFormat: {
    type: Boolean,
    default: false
  },
  title: String,
  blank: {
    type: Boolean,
    default: false
  },
  type: {
    type: String,
    default: "date"
  },
  _constants: {
    type: Object,
    default: function _default() {
      return $constants;
    }
  },
  timeArrowControl: Boolean,
  timeEditable: {
    type: Boolean,
    default: true
  },
  size: String,
  format: String,
  valueFormat: String,
  readonly: Boolean,
  placeholder: String,
  startPlaceholder: String,
  endPlaceholder: String,
  prefixIcon: Object,
  clearIcon: {
    type: Object,
    default: function _default2() {
      return iconClose();
    }
  },
  name: {
    default: "",
    validator
  },
  disabled: Boolean,
  clearable: {
    type: Boolean,
    default: true
  },
  id: {
    default: "",
    validator
  },
  popperClass: String,
  editable: {
    type: Boolean,
    default: true
  },
  align: {
    type: String,
    default: "left"
  },
  modelValue: {},
  defaultValue: {},
  defaultTime: {},
  rangeSeparator: {
    type: [Object, String],
    default: "-"
  },
  pickerOptions: {},
  unlinkPanels: Boolean,
  validateEvent: {
    type: Boolean,
    default: true
  },
  isRange: Boolean,
  arrowControl: Boolean,
  timezoneData: {},
  showTimezone: {
    type: Boolean,
    default: false
  },
  defaultTimezone: {},
  visible: Boolean,
  minDate: {
    type: Date,
    default: function _default3() {
      return new Date(currentYear - 10, 0, 1);
    },
    validator: function validator3(val) {
      return Object.prototype.toString.call(val) === "[object Date]" && !isNaN(val.getTime());
    }
  },
  maxDate: {
    type: Date,
    default: function _default4() {
      return new Date(currentYear + 10, 11, 31);
    },
    validator: function validator4(val) {
      return Object.prototype.toString.call(val) === "[object Date]" && !isNaN(val.getTime());
    }
  },
  formatter: {
    type: Function,
    default: function _default5(type, value) {
      return value;
    }
  },
  componentName: {
    type: String,
    default: "DatePicker"
  },
  displayOnly: {
    type: Boolean,
    default: false
  },
  step: {
    type: Object,
    default: function _default6() {
      return {
        hour: 1,
        minute: 1,
        second: 1
      };
    }
  },
  showWeekNumber: {
    type: Boolean,
    default: false
  },
  formatWeeks: Function,
  changeCompat: {
    type: Boolean,
    default: false
  },
  nowClick: {
    type: Function
  }
});
var getWrapFunc = function getWrapFunc2(name) {
  return function() {
    var picker = this.$refs.modeTemplate;
    if (picker && picker[name]) {
      return picker[name].apply(picker, arguments);
    }
  };
};
var DatePicker = defineComponent({
  name: $prefix + "DatePicker",
  props: datePickerProps,
  created: function created() {
    var _this = this;
    api.filter(function(item) {
      return item !== "state";
    }).forEach(function(method) {
      if (!_this[method]) {
        _this[method] = getWrapFunc(method);
      }
    });
  },
  setup: function setup(props, context) {
    return $setup({
      props,
      context,
      template
    });
  }
});
var version = "3.undefined";
DatePicker.model = {
  prop: "modelValue",
  event: "update:modelValue"
};
DatePicker.install = function(Vue) {
  Vue.component(DatePicker.name, DatePicker);
};
DatePicker.version = version;
export {
  DatePicker as default
};
