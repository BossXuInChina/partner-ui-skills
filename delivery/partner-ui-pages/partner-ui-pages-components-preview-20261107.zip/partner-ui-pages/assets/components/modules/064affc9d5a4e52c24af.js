import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  viewBox: "0 0 30 30",
  xmlns: "http://www.w3.org/2000/svg"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "g",
  null,
  [/* @__PURE__ */ createElementVNode("rect", {
    width: "30",
    height: "30",
    rx: "2"
  }), /* @__PURE__ */ createElementVNode("path", {
    d: "M13.851 22v-5.395c.67.129 1.267.193 1.787.193.953 0 1.796-.185 2.53-.556a4.1 4.1 0 0 0 1.716-1.595c.41-.693.616-1.503.616-2.432 0-1.366-.458-2.41-1.373-3.132S16.892 8 15.167 8H11.5v14h2.351Zm1.354-7.048c-.313 0-.765-.049-1.354-.145v-4.97h1.28c.99 0 1.74.19 2.251.57.511.38.767 1.003.767 1.866 0 .851-.25 1.51-.752 1.978-.502.467-1.232.7-2.192.7Z",
    fill: "#FFF"
  })],
  -1
  /* HOISTED */
);
var _hoisted_3 = [_hoisted_2];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_3));
}
var PptType = {
  render
};
var pptType = function pptType2() {
  return svg({
    name: "IconPptType",
    component: PptType,
    filledComponent: PptType
  })();
};
export {
  pptType as default
};
