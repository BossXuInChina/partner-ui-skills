import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  viewBox: "0 0 24 24",
  xmlns: "http://www.w3.org/2000/svg"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    d: "M15.107 5.75a3.143 3.143 0 0 1 3.138 2.965l.005.178-.001 7.857h3.001a.75.75 0 0 1 .102 1.493l-.102.007h-3.001v3a.75.75 0 0 1-1.492.102l-.007-.102V8.893c0-.86-.66-1.565-1.501-1.637l-.142-.006H9a.75.75 0 0 1-.102-1.493l.102-.007h6.106ZM6.5 2a.75.75 0 0 1 .743.648l.007.102V6.5l-.001.014v8.594c0 .86.66 1.564 1.501 1.636l.142.006H15a.75.75 0 0 1 .102 1.493L15 18.25H8.89a3.14 3.14 0 0 1-3.136-2.964l-.005-.178-.001-7.858H2.75a.75.75 0 0 1-.102-1.493l.102-.007h2.999v-3A.75.75 0 0 1 6.5 2Z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = [_hoisted_2];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_3));
}
var Crop = {
  render
};
var crop = function crop2() {
  return svg({
    name: "IconCrop",
    component: Crop,
    filledComponent: Crop
  })();
};
export {
  crop as default
};
