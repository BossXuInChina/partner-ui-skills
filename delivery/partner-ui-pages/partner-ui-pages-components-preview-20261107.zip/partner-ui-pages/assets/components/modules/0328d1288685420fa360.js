import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  viewBox: "0 0 24 24",
  xmlns: "http://www.w3.org/2000/svg"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "g",
  {
    "clip-path": "url(#wait-for-delivery-o_svg__clip131_1873)"
  },
  [/* @__PURE__ */ createElementVNode("path", {
    d: "m14.074 17.102-3.147.005a4.001 4.001 0 0 0-7.856.012l-.97.001c-.608 0-1.1-.478-1.101-1.069V4.2c0-.59.492-1.067 1.099-1.068l9.682-.011.13.007c.547.062.972.514.972 1.061v8.62c0 .442.37.8.825.8.456-.001.825-.36.825-.803V6.803l.01-.105a.655.655 0 0 1 .652-.536l2.952.006c.387.04.741.24.97.55l3.522 4.087.094.14c.174.287.267.615.267.95v3.357l-.006.153a1.873 1.873 0 0 1-1.102 1.54 4.002 4.002 0 0 0-7.818.157ZM6.75 6v2.325l2.627 1.527a.743.743 0 0 1 .271 1.025.743.743 0 0 1-1.025.271l-3-1.743a.738.738 0 0 1-.273-.275.738.738 0 0 1-.1-.374V6c0-.42.33-.75.75-.75s.75.33.75.75ZM7 14.87a3 3 0 1 0 0 6 3 3 0 0 0 0-6Zm8 3a3 3 0 1 1 6 0 3 3 0 0 1-6 0Z",
    "fill-rule": "evenodd"
  })],
  -1
  /* HOISTED */
);
var _hoisted_3 = [_hoisted_2];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_3));
}
var WaitForDeliveryO = {
  render
};
var waitForDeliveryO = function waitForDeliveryO2() {
  return svg({
    name: "IconWaitForDeliveryO",
    component: WaitForDeliveryO,
    filledComponent: WaitForDeliveryO
  })();
};
export {
  waitForDeliveryO as default
};
