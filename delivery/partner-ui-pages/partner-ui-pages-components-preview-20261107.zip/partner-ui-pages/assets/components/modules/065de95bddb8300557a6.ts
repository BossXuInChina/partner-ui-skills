import { defineComponent as _defineComponent } from 'vue'
import { resolveDynamicComponent as _resolveDynamicComponent, openBlock as _openBlock, createBlock as _createBlock, createCommentVNode as _createCommentVNode, unref as _unref, toDisplayString as _toDisplayString, createElementVNode as _createElementVNode, createVNode as _createVNode, createElementBlock as _createElementBlock, withDirectives as _withDirectives, renderList as _renderList, Fragment as _Fragment, normalizeClass as _normalizeClass, normalizeStyle as _normalizeStyle, Teleport as _Teleport } from "vue"

const _hoisted_1 = ["aria-expanded", "aria-controls", "aria-activedescendant", "disabled"]
const _hoisted_2 = { class: "composer-mode-label" }
const _hoisted_3 = ["id"]
const _hoisted_4 = ["id", "aria-selected", "disabled", "onPointermove", "onClick"]

import { vAiTooltip } from '../foundation/aiTooltip';
import { computed, nextTick, onBeforeUnmount, onMounted, ref, useId, watch } from 'vue';
import { AiIcon } from '../foundation/aiIcons';
import type { ComposerModeOption } from './composerTypes';

export type { ComposerModeOption } from './composerTypes';

const __sfc_main__ = /*@__PURE__*/_defineComponent({
  __name: 'ComposerModeSelect',
  props: {
    modelValue: {},
    options: {},
    disabled: { type: Boolean, default: false }
  },
  emits: ["update:modelValue"],
  setup(__props: any, { emit: __emit }) {

const props = __props;
const emit = __emit;
const id = `composer-mode-${useId().replace(/[^a-zA-Z0-9-]/g, '')}`;
const trigger = ref<HTMLButtonElement>(), panel = ref<HTMLElement>();
const open = ref(false), activeIndex = ref(-1);
const panelStyle = ref<Record<string, string>>({});
const selected = computed(() => props.options.find(option => option.value === props.modelValue));
const enabledIndexes = computed(() => props.options.flatMap((option, index) => option.disabled ? [] : [index]));
// REQ-006: no options is a focusable no-op placeholder. Explicit disabled and configured
// all-disabled choices remain unavailable; never open an empty/invalid listbox.
const unavailable = computed(() => props.disabled || (props.options.length > 0 && !enabledIndexes.value.length));

// Robot0.5.1 DropdownMenu items expose only id/text; its clickable li rows have no
// item slot, disabled/selected state or keyboard listbox navigation. Keep this minimal
// combobox; recheck the public API before replacing it on upgrades.
// REQ-003 Sender: self-contained single-select, styled from the local Workbench Select reference
// (demo/vendor/workbench/ui/select/WorkbenchSelectCore.vue), without importing its demo closure.
// A body Teleport escapes Sender/editor overflow. Copy the public AI semantic tokens; position in the
// current document viewport and remeasure on scroll/resize. Upgrade checks: focus and portal bounds.
function positionPanel() {
  if (!open.value || !trigger.value) return;
  const box = trigger.value.getBoundingClientRect();
  const host = trigger.value.closest('[data-assistant-window]') ?? trigger.value.closest('.chat-panel');
  const bounds = host?.getBoundingClientRect();
  const left = Math.max(8, bounds ? bounds.left + 8 : 8);
  const right = Math.min(document.documentElement.clientWidth - 8, bounds ? bounds.right - 8 : Infinity);
  const top = Math.max(8, bounds ? bounds.top + 8 : 8);
  const theme = getComputedStyle(trigger.value);
  const spacing = Number.parseFloat(theme.getPropertyValue('--partner-ai-menu-panel-padding')) || 4;
  // Match the trigger by default; a host may set a larger minimum, subject to bounds.
  const minimumWidth = Number.parseFloat(theme.getPropertyValue('--partner-ai-mode-panel-min-width')) || 0;
  const width = Math.min(Math.max(box.width, minimumWidth), Math.max(0, right - left));
  const desiredHeight = props.options.length * box.height + spacing * 2;
  // Sender menus always open above, including the standalone example. The locked
  // DropdownMenu has neither a placement prop nor an option slot; keep the existing
  // listbox instead of losing its disabled/selected/keyboard contract. Constrain
  // this portal to its host/viewport and scroll upper space; never flip below.
  // Recheck the public menu/placement API and portal geometry on Robot upgrades.
  const above = Math.max(0, box.top - 4 - top);
  if (!trigger.value.getClientRects().length || trigger.value.closest('[inert]') || above < Math.min(desiredHeight, box.height + spacing * 2) || width <= 0) { close(); return; }
  const height = Math.min(desiredHeight, above);
  const style: Record<string, string> = {
    width: `${width}px`, maxHeight: `${height}px`,
    left: `${Math.max(left, Math.min(box.left, right - width))}px`,
    top: `${box.top - height - 4}px`,
  };
  for (let index=0;index<theme.length;index++) { const token=theme[index]!; if(token.startsWith('--partner-ai-'))style[token]=theme.getPropertyValue(token); }
  style.fontFamily = theme.fontFamily;
  panelStyle.value = style;
}
function close(restoreFocus = false) { open.value = false; if (restoreFocus) trigger.value?.focus({ preventScroll: true }); }
async function show(last = false) {
  if (unavailable.value || !enabledIndexes.value.length) return;
  activeIndex.value = enabledIndexes.value.includes(props.options.findIndex(option => option.value === props.modelValue))
    ? props.options.findIndex(option => option.value === props.modelValue)
    : enabledIndexes.value[last ? enabledIndexes.value.length - 1 : 0]!;
  open.value = true; positionPanel(); await nextTick(); revealActive();
}
function revealActive() { panel.value?.querySelector<HTMLElement>(`#${id}-${activeIndex.value}`)?.scrollIntoView({ block: 'nearest' }); }
function choose(index: number) {
  const option = props.options[index];
  if (!option || option.disabled) return;
  emit('update:modelValue', option.value); close(true);
}
function keydown(event: KeyboardEvent) {
  if (event.key === 'Tab') { close(); return; }
  if (event.key === 'Escape' && open.value) { event.preventDefault(); event.stopPropagation(); close(true); return; }
  if (!['ArrowDown', 'ArrowUp', 'Home', 'End', 'Enter', ' '].includes(event.key)) return;
  event.preventDefault(); event.stopPropagation();
  if (!open.value) { void show(event.key === 'ArrowUp' || event.key === 'End'); return; }
  if (event.key === 'Enter' || event.key === ' ') { choose(activeIndex.value); return; }
  const indexes = enabledIndexes.value, current = indexes.indexOf(activeIndex.value);
  activeIndex.value = indexes[event.key === 'Home' ? 0 : event.key === 'End' ? indexes.length - 1 : (current + (event.key === 'ArrowUp' ? -1 : 1) + indexes.length) % indexes.length]!;
  void nextTick(revealActive);
}
function outside(event: Event) {
  if (event.target instanceof Node && !trigger.value?.contains(event.target) && !panel.value?.contains(event.target)) close();
}
watch(() => props.options, () => { if (unavailable.value || !enabledIndexes.value.length) close(); else if (open.value) { activeIndex.value = enabledIndexes.value[0]!; positionPanel(); } }, { deep: true });
watch(unavailable, disabled => { if (disabled) close(); });
onMounted(() => { document.addEventListener('pointerdown', outside, true); document.addEventListener('focusin', outside); window.addEventListener('resize', positionPanel); window.addEventListener('scroll', positionPanel, true); });
onBeforeUnmount(() => { document.removeEventListener('pointerdown', outside, true); document.removeEventListener('focusin', outside); window.removeEventListener('resize', positionPanel); window.removeEventListener('scroll', positionPanel, true); });

return (_ctx: any,_cache: any) => {
  return (_openBlock(), _createElementBlock(_Fragment, null, [
    _withDirectives((_openBlock(), _createElementBlock("button", {
      id: id,
      ref_key: "trigger",
      ref: trigger,
      type: "button",
      class: "composer-mode-trigger",
      role: "combobox",
      "aria-label": "切换模式",
      "aria-haspopup": "listbox",
      "aria-expanded": open.value,
      "aria-controls": open.value ? `${id}-list` : undefined,
      "aria-activedescendant": open.value ? `${id}-${activeIndex.value}` : undefined,
      disabled: unavailable.value,
      onClick: _cache[0] || (_cache[0] = ($event: any) => (open.value ? close() : show())),
      onKeydown: keydown
    }, [
      (selected.value?.icon)
        ? (_openBlock(), _createBlock(_resolveDynamicComponent(selected.value.icon), {
            key: 0,
            class: "composer-mode-icon",
            "aria-hidden": "true"
          }))
        : (_openBlock(), _createBlock(_unref(AiIcon), {
            key: 1,
            name: "composer.mode",
            class: "composer-mode-icon"
          })),
      _createElementVNode("span", _hoisted_2, _toDisplayString(selected.value?.label ?? '选择模式'), 1 /* TEXT */),
      _createVNode(_unref(AiIcon), {
        name: "composer.expand",
        class: "composer-mode-arrow",
        "aria-hidden": "true"
      })
    ], 40 /* PROPS, NEED_HYDRATION */, _hoisted_1)), [
      [_unref(vAiTooltip), { content: !__props.options.length ? '模式选项尚未配置' : selected.value?.label ?? '选择模式', disabled: open.value, overflowOnly: __props.options.length > 0, overflowSelector: '.composer-mode-label' }]
    ]),
    (_openBlock(), _createBlock(_Teleport, { to: "body" }, [
      (open.value)
        ? (_openBlock(), _createElementBlock("div", {
            key: 0,
            id: `${id}-list`,
            ref_key: "panel",
            ref: panel,
            class: "composer-mode-panel partner-ai-scrollbar-portal",
            role: "listbox",
            "aria-label": "问答模式",
            style: _normalizeStyle(panelStyle.value),
            onKeydown: keydown
          }, [
            (_openBlock(true), _createElementBlock(_Fragment, null, _renderList(__props.options, (option, index) => {
              return (_openBlock(), _createElementBlock("button", {
                id: `${id}-${index}`,
                key: option.value,
                type: "button",
                role: "option",
                class: _normalizeClass(["composer-mode-option", { 'is-active': index === activeIndex.value }]),
                "aria-selected": option.value === __props.modelValue,
                disabled: option.disabled,
                tabindex: "-1",
                onPointermove: ($event: any) => (!option.disabled && (activeIndex.value = index)),
                onClick: ($event: any) => (choose(index))
              }, [
                _createElementVNode("span", null, _toDisplayString(option.label), 1 /* TEXT */),
                (option.value === __props.modelValue)
                  ? (_openBlock(), _createBlock(_unref(AiIcon), {
                      key: 0,
                      name: "composer.selected",
                      "aria-hidden": "true"
                    }))
                  : _createCommentVNode("v-if", true)
              ], 42 /* CLASS, PROPS, NEED_HYDRATION */, _hoisted_4))
            }), 128 /* KEYED_FRAGMENT */))
          ], 44 /* STYLE, PROPS, NEED_HYDRATION */, _hoisted_3))
        : _createCommentVNode("v-if", true)
    ]))
  ], 64 /* STABLE_FRAGMENT */))
}
}

})
export default /* @__PURE__ */ Object.assign(__sfc_main__,{__scopeId:"data-v-065de95b"});