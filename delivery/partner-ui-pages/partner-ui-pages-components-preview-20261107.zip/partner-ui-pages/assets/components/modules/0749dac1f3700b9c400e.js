import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  viewBox: "0 0 24 24",
  xmlns: "http://www.w3.org/2000/svg"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "g",
  {
    "clip-path": "url(#process-plan-requirements_svg__clip131_1890)"
  },
  [/* @__PURE__ */ createElementVNode("path", {
    d: "M15.5 2h-7a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1h7a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1ZM6 3.5c-.041.16 0 .327 0 .5v.5a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V4c0-.173-.022-.34-.063-.5C19.594 3.5 21 4.843 21 6.5V19a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6.5a3 3 0 0 1 3-3Zm3.748 10.782c-.232-.716-.276-1.389-.135-2.02.149-.66.502-1.275 1.061-1.842.589-.598 1.224-.967 1.904-1.106.636-.128 1.323-.059 2.039.213.133.05.175.143.125.278l-1.288 1.336c-.296.3-.441.598-.438.894.004.282.142.561.416.84.256.26.518.396.785.408.28.012.565-.112.856-.372l1.302-1.317c.1-.103.201-.103.303-.002.27.737.39 1.51.256 2.162-.14.681-.504 1.328-1.085 1.918-.57.58-1.188.943-1.853 1.089-.623.137-1.287.083-1.992-.16a3.98 3.98 0 0 1-.155-.058L9.617 18.81a1.47 1.47 0 0 1-.484.332 1.453 1.453 0 0 1-.563.108c-.203 0-.39-.036-.564-.108a1.47 1.47 0 0 1-.483-.332C7.174 18.456 7 18.102 7 17.748c0-.354.174-.708.523-1.062l2.261-2.297a3.938 3.938 0 0 1-.036-.107Z",
    "fill-rule": "evenodd"
  })],
  -1
  /* HOISTED */
);
var _hoisted_3 = [_hoisted_2];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_3));
}
var ProcessPlanRequirements = {
  render
};
var processPlanRequirements = function processPlanRequirements2() {
  return svg({
    name: "IconProcessPlanRequirements",
    component: ProcessPlanRequirements,
    filledComponent: ProcessPlanRequirements
  })();
};
export {
  processPlanRequirements as default
};
