function _extends() {
  return _extends = Object.assign ? Object.assign.bind() : function(n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends.apply(null, arguments);
}
import { defineComponent, $props, $setup, $prefix } from "@opentiny/vue-common";
import PcTemplate from "./pc.js";
import RecycleScroller from "@opentiny/vue-recycle-scroller";
var template = function template2(mode) {
  var _process$env;
  typeof process === "object" ? (_process$env = process.env) == null ? void 0 : _process$env.TINY_MODE : null;
  return PcTemplate;
};
var DynamicScroller = defineComponent({
  name: $prefix + "DynamicScroller",
  props: _extends({}, $props, {
    items: {
      type: Array,
      required: true
    },
    keyField: {
      type: String,
      default: "id"
    },
    direction: {
      type: String,
      default: "vertical",
      validator: function validator(value) {
        return ["vertical", "horizontal"].includes(value);
      }
    },
    listTag: {
      type: String,
      default: "div"
    },
    itemTag: {
      type: String,
      default: "div"
    },
    minItemSize: {
      type: [Number, String],
      required: true
    }
  }),
  setup: function setup(props, context) {
    return $setup({
      props,
      context,
      template
    });
  }
});
var version = "3.undefined";
DynamicScroller.IdState = RecycleScroller.IdState;
DynamicScroller.install = function(Vue) {
  Vue.component(DynamicScroller.name, DynamicScroller);
};
DynamicScroller.version = version;
export {
  DynamicScroller as default
};
