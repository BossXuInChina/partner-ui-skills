import { defineComponent as _defineComponent } from 'vue'
import { withModifiers as _withModifiers, createElementVNode as _createElementVNode, unref as _unref, createVNode as _createVNode, withKeys as _withKeys, openBlock as _openBlock, createElementBlock as _createElementBlock, withDirectives as _withDirectives, withCtx as _withCtx, createBlock as _createBlock, createCommentVNode as _createCommentVNode } from "vue"

const _hoisted_1 = { class: "history-row-menu" }
const _hoisted_2 = ["data-record-id", "aria-label", "aria-expanded", "aria-controls", "disabled"]

import { nextTick, onBeforeUnmount, onMounted, ref, useId, watch } from 'vue';
import {default as TrDropdownMenu} from "robot/packages/components/src/dropdown-menu/index.ts";
import { AiIcon } from '../foundation/aiIcons';
import { vAiTooltip } from '../foundation/aiTooltip';

const __sfc_main__ = /*@__PURE__*/_defineComponent({
  __name: 'ConversationMoreMenu',
  props: {
    title: {},
    recordId: {},
    open: { type: Boolean },
    parentOpen: { type: Boolean },
    disabled: { type: Boolean }
  },
  emits: ["toggle", "close", "action"],
  setup(__props: any, { emit: __emit }) {

const props=__props;
const emit=__emit;
const trigger=ref<HTMLButtonElement>(),portal=ref<HTMLElement>();
const id=`history-more-${useId().replace(/[^a-zA-Z0-9-]/g,'')}`;
// REQ-016 v0.4: public DropdownMenu items/manual show/appendTo/event contracts.
// Keep an extensible action array; actual deletion always goes through product confirmation.
const actions:DropdownMenuItem[]=[{id:'delete',text:'删除对话'}];
let observer:MutationObserver|undefined;
function close(restore=false){emit('close');if(restore)trigger.value?.focus({preventScroll:true});}
function menuItems(){return [...(portal.value?.querySelectorAll<HTMLElement>('.tr-dropdown-menu__list-item')??[])];}
function bounds(){
  const panel=trigger.value?.closest<HTMLElement>('.conversation-history-panel');
  const rect=panel?.getBoundingClientRect();
  if(!portal.value||!rect)return;
  for(const [key,value] of Object.entries({'min-top':Math.max(8,rect.top+8),'max-bottom':Math.min(innerHeight-8,rect.bottom-8),'min-left':Math.max(8,rect.left+8),'max-right':Math.min(innerWidth-8,rect.right-8)}))portal.value.style.setProperty(`--tr-dropdown-menu-${key}`,`${value}px`);
}
function adapt(){
  // 0.5.1 has no item slot or keyboard menu semantics. This small DOM adapter
  // supplies roles/tabindex on its rendered ul/li, while activation remains the
  // public item-click event. Review these selectors when upgrading; no private refs.
  const menu=portal.value?.querySelector<HTMLElement>('.tr-dropdown-menu__list');
  if(!menu)return;menu.id=id;menu.setAttribute('role','menu');menu.setAttribute('aria-label','会话更多操作');
  for(const item of menuItems()){item.setAttribute('role','menuitem');item.tabIndex=-1;}
  if(props.open && !portal.value?.contains(document.activeElement))menuItems()[0]?.focus({preventScroll:true});
}
function keydown(event:KeyboardEvent){
  if(!props.open)return;
  const items=menuItems(),index=items.indexOf(document.activeElement as HTMLElement);
  if(event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();close(true);return;}
  if(event.key==='Tab'){close();return;}
  if(['ArrowDown','ArrowUp','Home','End'].includes(event.key)){
    event.preventDefault();event.stopPropagation();
    items[event.key==='Home'?0:event.key==='End'?items.length-1:(index+(event.key==='ArrowUp'?-1:1)+items.length)%items.length]?.focus();
  }else if(event.key==='Enter'||event.key===' '){event.preventDefault();event.stopPropagation();if(!props.disabled)items[index]?.click();}
}
function outside(event:PointerEvent){if(props.open && event.target instanceof Node && !portal.value?.contains(event.target)&&!trigger.value?.contains(event.target))close();}
function onFocus(event:FocusEvent){if(props.open && event.target instanceof Node && !portal.value?.contains(event.target)&&!trigger.value?.contains(event.target))close();}
function onScroll(event:Event){
  // Streaming auto-follow in the chat is unrelated to this menu. Only its own
  // history-list scroll invalidates the anchor; viewport scroll updates bounds.
  if(!props.open)return;
  if(event.target===trigger.value?.closest('.history-list'))close();
  else if(event.target===document)bounds();
}
function act(action:DropdownMenuItem){if(props.disabled)return;emit('action',action);close();}
async function sync(){
  if(!portal.value)return;
  if(props.open&&props.parentOpen){bounds();if(!portal.value.matches(':popover-open'))portal.value.showPopover();await nextTick();adapt();}
  else if(portal.value.matches(':popover-open'))portal.value.hidePopover();
}
onMounted(()=>{
  observer=new MutationObserver(adapt);if(portal.value)observer.observe(portal.value,{childList:true,subtree:true});
  document.addEventListener('keydown',keydown,true);document.addEventListener('pointerdown',outside,true);document.addEventListener('focusin',onFocus);
  window.addEventListener('scroll',onScroll,true);window.addEventListener('resize',bounds);void sync();
});
watch(()=>[props.open,props.parentOpen],sync,{flush:'post'});
onBeforeUnmount(()=>{observer?.disconnect();document.removeEventListener('keydown',keydown,true);document.removeEventListener('pointerdown',outside,true);document.removeEventListener('focusin',onFocus);window.removeEventListener('scroll',onScroll,true);window.removeEventListener('resize',bounds);});

return (_ctx: any,_cache: any) => {
  return (_openBlock(), _createElementBlock("span", _hoisted_1, [
    _createElementVNode("span", {
      ref_key: "portal",
      ref: portal,
      popover: "manual",
      class: "history-more-portal",
      onClick: _cache[0] || (_cache[0] = _withModifiers(() => {}, ["stop"]))
    }, null, 512 /* NEED_PATCH */),
    (portal.value)
      ? (_openBlock(), _createBlock(_unref(TrDropdownMenu), {
          key: 0,
          "append-to": portal.value,
          items: actions,
          trigger: "manual",
          show: __props.open && __props.parentOpen,
          onItemClick: act,
          onClickOutside: _cache[3] || (_cache[3] = ($event: any) => (close()))
        }, {
          trigger: _withCtx(() => [
            _withDirectives((_openBlock(), _createElementBlock("button", {
              ref_key: "trigger",
              ref: trigger,
              class: "history-more",
              type: "button",
              "data-record-id": __props.recordId,
              "aria-label": `更多操作：${__props.title}`,
              "aria-haspopup": "menu",
              "aria-expanded": __props.open && __props.parentOpen,
              "aria-controls": __props.open? id:undefined,
              disabled: __props.disabled,
              onClick: _cache[1] || (_cache[1] = _withModifiers(($event: any) => (emit('toggle')), ["stop"])),
              onKeydown: _cache[2] || (_cache[2] = _withKeys(_withModifiers(($event: any) => (!__props.open && emit('toggle')), ["prevent","stop"]), ["down"]))
            }, [
              _createVNode(_unref(AiIcon), {
                name: "history.more",
                "aria-hidden": "true"
              })
            ], 40 /* PROPS, NEED_HYDRATION */, _hoisted_2)), [
              [_unref(vAiTooltip), {content:'更多操作',disabled:!__props.parentOpen || __props.open,closeOnPointerLeave:true}]
            ])
          ]),
          _: 1 /* STABLE */
        }, 8 /* PROPS */, ["append-to", "show"]))
      : _createCommentVNode("v-if", true)
  ]))
}
}

})
export default /* @__PURE__ */ Object.assign(__sfc_main__,{__scopeId:"data-v-149db70b"});