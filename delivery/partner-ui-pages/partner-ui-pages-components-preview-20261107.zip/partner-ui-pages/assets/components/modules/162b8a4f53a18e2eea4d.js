import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 16 16",
  style: {
    "enable-background": "new 0 0 16 16"
  },
  "xml:space": "preserve"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "rect",
  {
    style: {
      "fill": "none"
    }
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    class: "discount-sup_svg__st1",
    d: "M13 5.6h-.7l.7-.8c.3-.3.4-.7.4-1.1s-.2-.8-.4-1.1l-.4-.4c-.6-.6-1.5-.6-2.1 0L8 4.9 5.4 2.4c-.6-.6-1.5-.6-2.1 0l-.3.3c-.6.6-.6 1.5 0 2.1l.8.8H3c-.8 0-1.5.7-1.5 1.5v6.1c0 .8.7 1.5 1.5 1.5h10c.8 0 1.5-.7 1.5-1.5V7.1c0-.8-.7-1.5-1.5-1.5zm-1.7-2.5c.2-.2.5-.2.7 0l.4.4c.1.1.1.2.1.4 0 .1-.1.3-.1.4l-1.5 1.5H8.7l2.6-2.7zm-7.6 1c-.2-.2-.2-.5 0-.7l.3-.3c.2-.2.5-.2.7 0l2.5 2.5H5.1L3.7 4.1zm-1.2 9.1V7.1c0-.3.2-.5.5-.5h4.5v7.1H3c-.3 0-.5-.2-.5-.5zm11 0c0 .3-.2.5-.5.5H8.5V6.6H13c.3 0 .5.2.5.5v6.1z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_4 = [_hoisted_2, _hoisted_3];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_4));
}
var DiscountSup = {
  render
};
var discountSup = function discountSup2() {
  return svg({
    name: "IconDiscountSup",
    component: DiscountSup,
    filledComponent: DiscountSup
  })();
};
export {
  discountSup as default
};
