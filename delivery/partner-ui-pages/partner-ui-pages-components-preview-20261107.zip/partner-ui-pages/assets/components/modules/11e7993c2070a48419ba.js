import { defineComponent, $prefix, setup } from '@opentiny/vue-common';
import { renderless, api } from '@opentiny/vue-renderless/area/vue';
import Select from '@opentiny/vue-select';
import Option from '@opentiny/vue-option';
import { resolveComponent, openBlock, createElementBlock, createVNode, mergeProps, withCtx, Fragment, renderList, createBlock } from 'vue';

function _createForOfIteratorHelperLoose(r, e) {
  var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (t) return (t = t.call(r)).next.bind(t);
  if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
    t && (r = t);
    var o = 0;
    return function() {
      return o >= r.length ? { done: true } : { done: false, value: r[o++] };
    };
  }
  throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return _arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
  }
}
function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}
var _export_sfc = function _export_sfc2(sfc, props) {
  var target = sfc.__vccOpts || sfc;
  for (var _iterator = _createForOfIteratorHelperLoose(props), _step; !(_step = _iterator()).done; ) {
    var _step$value = _step.value, key = _step$value[0], val = _step$value[1];
    target[key] = val;
  }
  return target;
};

var _sfc_main = defineComponent({
  name: $prefix + "Area",
  components: {
    TinySelect: Select,
    TinyOption: Option
  },
  emits: ["update:modelValue", "change-office", "change-jcr", "change-region", "change-rep"],
  props: {
    modelValue: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    placeholder: {
      type: String,
      default: ""
    },
    size: String,
    disabled: {
      type: Boolean,
      default: false
    },
    props: {
      type: Object,
      default: function _default2() {
        return {
          label: "name_cn",
          value: "org_id"
        };
      }
    },
    fetchJcr: {
      type: Function
    },
    fetchRegion: {
      type: Function
    },
    fetchRep: {
      type: Function
    },
    fetchOffice: {
      type: Function
    },
    popperClass: String,
    popperAppendToBody: {
      type: Boolean,
      default: true
    }
  },
  setup: function setup$1(props, context) {
    return setup({
      props,
      context,
      renderless,
      api
    });
  }
});
var _hoisted_1 = {
  class: "tiny-area"
};
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_tiny_option = resolveComponent("tiny-option");
  var _component_tiny_select = resolveComponent("tiny-select");
  return openBlock(), createElementBlock("div", _hoisted_1, [createVNode(_component_tiny_select, mergeProps({
    "popper-class": "tiny-area-jcr" + (_ctx.popperClass ? " " + _ctx.popperClass : ""),
    "popper-append-to-body": _ctx.popperAppendToBody,
    size: _ctx.size,
    modelValue: _ctx.state.jcr,
    "onUpdate:modelValue": _cache[0] || (_cache[0] = function($event) {
      return _ctx.state.jcr = $event;
    }),
    placeholder: _ctx.placeholder,
    onChange: _ctx.getRegion,
    disabled: _ctx.disabled,
    ref: "refInstance"
  }, _ctx.a(_ctx.$attrs, ["^on[A-Z]"]), {
    onClear: _cache[1] || (_cache[1] = function($event) {
      return _ctx.$emit("clear");
    }),
    onVisibleChange: _cache[2] || (_cache[2] = function($event) {
      return _ctx.$emit("visible-change", $event);
    })
  }), {
    default: withCtx(function() {
      return [(openBlock(true), createElementBlock(
        Fragment,
        null,
        renderList(_ctx.state.jcrData, function(item) {
          return openBlock(), createBlock(_component_tiny_option, {
            key: item[_ctx.props.value],
            label: item[_ctx.props.label],
            value: item[_ctx.props.value]
          }, null, 8, ["label", "value"]);
        }),
        128
        /* KEYED_FRAGMENT */
      ))];
    }),
    _: 1
    /* STABLE */
  }, 16, ["popper-class", "popper-append-to-body", "size", "modelValue", "placeholder", "onChange", "disabled"]), createVNode(_component_tiny_select, mergeProps({
    "popper-class": "tiny-area-region" + (_ctx.popperClass ? " " + _ctx.popperClass : ""),
    "popper-append-to-body": _ctx.popperAppendToBody,
    size: _ctx.size,
    modelValue: _ctx.state.region,
    "onUpdate:modelValue": _cache[3] || (_cache[3] = function($event) {
      return _ctx.state.region = $event;
    }),
    placeholder: _ctx.placeholder,
    onChange: _ctx.getRep,
    disabled: _ctx.disabled
  }, _ctx.a(_ctx.$attrs, ["^on[A-Z]"]), {
    onClear: _cache[4] || (_cache[4] = function($event) {
      return _ctx.$emit("clear");
    }),
    onVisibleChange: _cache[5] || (_cache[5] = function($event) {
      return _ctx.$emit("visible-change", $event);
    })
  }), {
    default: withCtx(function() {
      return [(openBlock(true), createElementBlock(
        Fragment,
        null,
        renderList(_ctx.state.regionData, function(item) {
          return openBlock(), createBlock(_component_tiny_option, {
            key: item[_ctx.props.value],
            label: item[_ctx.props.label],
            value: item[_ctx.props.value]
          }, null, 8, ["label", "value"]);
        }),
        128
        /* KEYED_FRAGMENT */
      ))];
    }),
    _: 1
    /* STABLE */
  }, 16, ["popper-class", "popper-append-to-body", "size", "modelValue", "placeholder", "onChange", "disabled"]), createVNode(_component_tiny_select, mergeProps({
    "popper-class": "tiny-area-rep" + (_ctx.popperClass ? " " + _ctx.popperClass : ""),
    "popper-append-to-body": _ctx.popperAppendToBody,
    size: _ctx.size,
    modelValue: _ctx.state.rep,
    "onUpdate:modelValue": _cache[6] || (_cache[6] = function($event) {
      return _ctx.state.rep = $event;
    }),
    placeholder: _ctx.placeholder,
    onChange: _ctx.getOffice,
    disabled: _ctx.disabled
  }, _ctx.a(_ctx.$attrs, ["^on[A-Z]"]), {
    onClear: _cache[7] || (_cache[7] = function($event) {
      return _ctx.$emit("clear");
    }),
    onVisibleChange: _cache[8] || (_cache[8] = function($event) {
      return _ctx.$emit("visible-change", $event);
    })
  }), {
    default: withCtx(function() {
      return [(openBlock(true), createElementBlock(
        Fragment,
        null,
        renderList(_ctx.state.repData, function(item) {
          return openBlock(), createBlock(_component_tiny_option, {
            key: item[_ctx.props.value],
            label: item[_ctx.props.label],
            value: item[_ctx.props.value]
          }, null, 8, ["label", "value"]);
        }),
        128
        /* KEYED_FRAGMENT */
      ))];
    }),
    _: 1
    /* STABLE */
  }, 16, ["popper-class", "popper-append-to-body", "size", "modelValue", "placeholder", "onChange", "disabled"]), createVNode(_component_tiny_select, mergeProps({
    "popper-class": "tiny-area-office" + (_ctx.popperClass ? " " + _ctx.popperClass : ""),
    "popper-append-to-body": _ctx.popperAppendToBody,
    size: _ctx.size,
    modelValue: _ctx.state.office,
    "onUpdate:modelValue": _cache[9] || (_cache[9] = function($event) {
      return _ctx.state.office = $event;
    }),
    placeholder: _ctx.placeholder,
    disabled: _ctx.disabled,
    onChange: _ctx.changeOffice
  }, _ctx.a(_ctx.$attrs, ["^on[A-Z]"]), {
    onClear: _cache[10] || (_cache[10] = function($event) {
      return _ctx.$emit("clear");
    }),
    onVisibleChange: _cache[11] || (_cache[11] = function($event) {
      return _ctx.$emit("visible-change", $event);
    })
  }), {
    default: withCtx(function() {
      return [(openBlock(true), createElementBlock(
        Fragment,
        null,
        renderList(_ctx.state.officeData, function(item) {
          return openBlock(), createBlock(_component_tiny_option, {
            key: item[_ctx.props.value],
            label: item[_ctx.props.label],
            value: item[_ctx.props.value]
          }, null, 8, ["label", "value"]);
        }),
        128
        /* KEYED_FRAGMENT */
      ))];
    }),
    _: 1
    /* STABLE */
  }, 16, ["popper-class", "popper-append-to-body", "size", "modelValue", "placeholder", "disabled", "onChange"])]);
}
var pc = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);

export { pc as default };
