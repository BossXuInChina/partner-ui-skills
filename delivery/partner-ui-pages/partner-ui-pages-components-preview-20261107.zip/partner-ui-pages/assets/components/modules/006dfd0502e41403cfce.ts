import { normalizeClass as _normalizeClass, openBlock as _openBlock, createBlock as _createBlock } from "vue"

import WorkbenchIcon from '../icons/WorkbenchIcon.vue';


const __sfc_main__ = {
  __name: 'TopNavDisclosureArrow',
  props: {
  name: { type: String, default: 'WB-TOP-NAV/action/account-arrow' },
  size: { type: Number, default: 12 },
  expanded: { type: Boolean, default: false },
},
  setup(__props) {



return (_ctx, _cache) => {
  return (_openBlock(), _createBlock(WorkbenchIcon, {
    class: _normalizeClass(["wb-top-nav-disclosure-arrow", { 'is-expanded': __props.expanded }]),
    name: __props.name,
    size: __props.size
  }, null, 8 /* PROPS */, ["class", "name", "size"]))
}
}

}
export default /* @__PURE__ */ Object.assign(__sfc_main__,{__scopeId:"data-v-006dfd05"});