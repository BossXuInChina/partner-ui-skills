import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  viewBox: "0 0 24 24",
  xmlns: "http://www.w3.org/2000/svg",
  width: "24",
  height: "24",
  fill: "none"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    fill: "none",
    d: "M0 0h24v24H0z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = /* @__PURE__ */ createElementVNode(
  "rect",
  {
    width: "20",
    height: "22",
    x: "2",
    y: "1",
    rx: "3",
    stroke: "#000",
    "stroke-width": "1.5"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_4 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    d: "M6 18h12M18 11V6M11.5 13.5l-3-2.5M13 6h5M6 14.536 8.5 11M11.5 13.5 17 7",
    stroke: "#000",
    "stroke-linecap": "round",
    "stroke-width": "1.5"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_5 = [_hoisted_2, _hoisted_3, _hoisted_4];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_5));
}
var Performance = {
  render
};
var performance = function performance2() {
  return svg({
    name: "IconPerformance",
    component: Performance,
    filledComponent: Performance
  })();
};
export {
  performance as default
};
