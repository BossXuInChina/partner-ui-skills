import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 24 24",
  "xml:space": "preserve"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    class: "minus-circle_svg__st0",
    d: "M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.6 0 12 0zm7.1 19.1c-.9.9-2 1.6-3.2 2.1-1.2.5-2.5.8-3.9.8s-2.7-.3-3.9-.8c-1.2-.5-2.3-1.2-3.2-2.1-.9-.9-1.6-2-2.1-3.2-.5-1.2-.8-2.5-.8-3.9s.3-2.7.8-3.9C3.3 6.9 4 5.8 4.9 4.9c.9-.9 2-1.6 3.2-2.1C9.3 2.3 10.6 2 12 2s2.7.3 3.9.8c1.2.5 2.3 1.2 3.2 2.1.9.9 1.6 2 2.1 3.2.5 1.2.8 2.5.8 3.9s-.3 2.7-.8 3.9c-.5 1.2-1.2 2.3-2.1 3.2zm-.9-6.1H5.8c-.4 0-.8-.4-.8-1s.4-1 .8-1h12.4c.4 0 .8.4.8 1s-.4 1-.8 1z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = [_hoisted_2];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_3));
}
var MinusCircle = {
  render
};
var minusCircle = function minusCircle2() {
  return svg({
    name: "IconMinusCircle",
    component: MinusCircle,
    filledComponent: MinusCircle
  })();
};
export {
  minusCircle as default
};
