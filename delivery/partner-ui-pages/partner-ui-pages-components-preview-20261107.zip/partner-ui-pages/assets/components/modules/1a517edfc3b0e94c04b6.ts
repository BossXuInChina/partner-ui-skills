import { defineComponent as _defineComponent } from 'vue'
import { createElementVNode as _createElementVNode, toDisplayString as _toDisplayString, openBlock as _openBlock, createElementBlock as _createElementBlock, createCommentVNode as _createCommentVNode, Fragment as _Fragment, unref as _unref, createVNode as _createVNode, withDirectives as _withDirectives, vModelText as _vModelText, createTextVNode as _createTextVNode, withModifiers as _withModifiers, withCtx as _withCtx, createBlock as _createBlock, vShow as _vShow, normalizeClass as _normalizeClass, normalizeStyle as _normalizeStyle } from "vue"

const _hoisted_1 = ["aria-labelledby"]
const _hoisted_2 = ["id"]
const _hoisted_3 = { class: "history-delete-title" }
const _hoisted_4 = { key: 0 }
const _hoisted_5 = {
  key: 1,
  class: "history-error",
  role: "alert"
}
const _hoisted_6 = { class: "history-confirm-actions" }
const _hoisted_7 = ["disabled"]
const _hoisted_8 = ["disabled"]
const _hoisted_9 = ["id"]
const _hoisted_10 = {
  key: 0,
  class: "history-error",
  role: "alert"
}
const _hoisted_11 = { class: "history-confirm-actions" }
const _hoisted_12 = ["disabled"]
const _hoisted_13 = ["disabled"]
const _hoisted_14 = { class: "history-browse" }
const _hoisted_15 = { class: "history-heading" }
const _hoisted_16 = ["id"]
const _hoisted_17 = ["disabled"]
const _hoisted_18 = { class: "history-search-core" }
const _hoisted_19 = {
  key: 0,
  class: "history-hint"
}
const _hoisted_20 = {
  key: 1,
  class: "history-error",
  role: "alert"
}
const _hoisted_21 = ["disabled"]
const _hoisted_22 = ["aria-busy"]
const _hoisted_23 = ["aria-label", "aria-pressed", "disabled", "onClick"]
const _hoisted_24 = ["aria-label", "aria-current", "disabled", "onClick"]
const _hoisted_25 = {
  key: 1,
  class: "history-empty"
}
const _hoisted_26 = ["aria-expanded"]

import { vAiTooltip } from '../foundation/aiTooltip';
import { useDeliveryMode } from '../foundation/deliveryMode';
import { computed, nextTick, onBeforeUnmount, onMounted, ref, useId, watch } from 'vue';
import {default as TrHistory} from "robot/packages/components/src/history/index.ts";
import { AiIcon } from '../foundation/aiIcons';
import { useAutoScrollbars } from '../foundation/useAutoScrollbars';
import ConversationMoreMenu from './ConversationMoreMenu.vue';
import { groupConversationHistory, type ConversationRecord } from './conversationHistory';

const __sfc_main__ = /*@__PURE__*/_defineComponent({
  __name: 'ConversationHistoryPanel',
  props: {
    anchor: {},
    open: { type: Boolean },
    records: {},
    selected: {},
    busy: { type: Boolean },
    error: {},
    readFailed: { type: Boolean },
    blocked: { type: Boolean },
    clear: { type: Function },
    remove: { type: Function },
    select: { type: Function }
  },
  emits: ["close", "closed", "pin", "reload"],
  setup(__props: any, { emit: __emit }) {

const props=__props;
const emit=__emit;
const delivery=useDeliveryMode();
const id=`history-${useId().replace(/[^a-zA-Z0-9-]/g,'')}`;
let changingPane=false;
const visible=ref(false),moreId=ref(''),deleting=ref<HistoryItem>(),deleteFailure=ref('');
const query=ref(''), earlier=ref(false), confirming=ref(false), style=ref<Record<string,string>>({});
const search=ref<HTMLInputElement>(), cancel=ref<HTMLButtonElement>(), clearButton=ref<HTMLButtonElement>();
const content=ref<HTMLElement>(), list=ref<HTMLElement>();
useAutoScrollbars(() => content.value,[{selector:'.history-list',axis:'y'}]);
const now=ref(Date.now());
const groups=computed(()=>groupConversationHistory(props.records,query.value,earlier.value,now.value));
const hasRecords=computed(()=>props.records.some(item=>item.messages.length||item.view.draft));
const hasEarlier=computed(()=>props.records.some(item=>!item.pinned && item.updatedAt<now.value-30*86400000 && (item.messages.length||item.view.draft)));
let observer:ResizeObserver|undefined;
let frame=0, enterFrame=0, leaveTimer=0;
// REQ-016 v0.2: dialog.showModal blocked the page. Use the native non-modal top
// layer for this anchored menu; Robot0.5.1 offers no generic popup body. Keep its
// public TrHistory slots/tokens, and reuse REQ-015's scrollbar lifecycle on the LIST.
function position() {
  const hostElement=props.anchor.closest('.chat-panel');
  const host=hostElement?.getBoundingClientRect()??props.anchor.getBoundingClientRect();
  const box=props.anchor.getBoundingClientRect(), viewportWidth=document.documentElement.clientWidth, viewportHeight=document.documentElement.clientHeight;
  const width=Math.max(0,Math.min(300,host.width-24,viewportWidth-24));
  const left=Math.max(12,host.left+12,Math.min(box.right-width,host.right-width-12,viewportWidth-width-12));
  const top=Math.max(12,Math.min(box.bottom+8,viewportHeight-100));
  // Keep the composer reachable when the history list has enough room above it.
  const composerTop=hostElement?.querySelector('.composer')?.getBoundingClientRect().top;
  const bottom=Math.min(host.bottom-12,viewportHeight-12,composerTop && composerTop-top>=80 ? composerTop-8 : Infinity);
  const next={left:`${left}px`,top:`${top}px`,width:`${width}px`,maxHeight:`${Math.min(520,Math.max(80,bottom-top))}px`};
  const port=list.value;
  if(port){
    const gutter=port.offsetWidth-port.clientWidth;
    const nativeTrack=parseFloat(getComputedStyle(port,'::-webkit-scrollbar').width);
    const track=gutter||(Number.isFinite(nativeTrack)?nativeTrack:14);
    // Same measured native-gutter compensation as Sender: center track in the
    // right16px inset, without borrowing content width or assuming OS overlay mode.
    Object.assign(next,{'--history-scroll-extension':`${(16+track)/2}px`,'--history-native-gutter':`${gutter}px`});
  }
  if(JSON.stringify(style.value)!==JSON.stringify(next))style.value=next;
}
// ResizeObserver cannot see the host's translate/entry animation; track its anchor
// while this one panel is open, also covering drag transforms without global listeners.
function followAnchor() { position(); frame=requestAnimationFrame(followAnchor); }
function close(restore=true) { if (!props.open || props.busy) return; if(deleting.value)void cancelDelete();else if(moreId.value)moreId.value='';else if (confirming.value) void cancelClear(); else { if(restore)props.anchor.focus({preventScroll:true}); emit('close'); } }
function outside(event:PointerEvent) { if(!props.open)return; if(event.target instanceof Node && !content.value?.contains(event.target) && !props.anchor.contains(event.target)) { if(props.busy)return; if(content.value?.contains(document.activeElement))props.anchor.focus({preventScroll:true});emit('close'); } }
function focusOutside(event:FocusEvent) { if(!props.open || changingPane)return; if(event.target instanceof Node && !content.value?.contains(event.target) && !props.anchor.contains(event.target) && !props.busy)emit('close'); }
function escape(event:KeyboardEvent) { if(props.open && event.key==='Escape' && !document.querySelector('dialog[open]')) { event.preventDefault(); event.stopPropagation(); close(); } }
async function requestDelete(item:HistoryItem){
  if(!item.id||props.busy||props.blocked)return;
  changingPane=true;moreId.value='';deleteFailure.value='';deleting.value=item;await nextTick();cancel.value?.focus();changingPane=false;
}
async function cancelDelete(){
  changingPane=true;const recordId=deleting.value?.id;deleting.value=undefined;deleteFailure.value='';await nextTick();
  const trigger=[...(content.value?.querySelectorAll<HTMLButtonElement>('.history-more')??[])].find(button=>button.dataset.recordId===recordId);
  (trigger??search.value)?.focus({preventScroll:true});changingPane=false;
}
async function deleteOne(){
  const item=deleting.value;if(!item?.id||props.busy||props.blocked)return;
  if(await props.remove(item.id)){deleting.value=undefined;deleteFailure.value='';await nextTick();search.value?.focus();}
  else deleteFailure.value='删除失败，对话仍保留，请重试。';
}
async function confirmClear() { if (props.blocked||props.busy) return; confirming.value=true; await nextTick(); cancel.value?.focus(); }
async function cancelClear() { confirming.value=false; await nextTick(); clearButton.value?.focus(); }
async function clearAll() { if (!props.blocked && await props.clear()) { confirming.value=false; await nextTick(); search.value?.focus(); } }
async function choose(item:HistoryItem) { if (!item.id || props.busy||props.blocked) return; if (await props.select(item.id)) emit('close'); }
onMounted(async()=>{
  if(!props.open){emit('closed');return;}
  position(); content.value?.showPopover();
  // Keep this node mounted through leave. Reopening cancels the close timer and
  // reverses its CSS transition from the current opacity/position, with no remount.
  if(content.value)void content.value.offsetHeight;
  enterFrame=requestAnimationFrame(()=>{visible.value=props.open;});
  props.anchor.setAttribute('aria-controls',id);
  document.addEventListener('pointerdown',outside,true);document.addEventListener('focusin',focusOutside);document.addEventListener('keydown',escape,true);
  followAnchor(); observer=new ResizeObserver(position); const host=props.anchor.closest('.chat-panel'); if(host)observer.observe(host);
  window.addEventListener('resize',position); window.addEventListener('scroll',position,true);
  await nextTick();search.value?.focus({preventScroll:true});
});
function finishLeave(event?:TransitionEvent) {
  if(event && (event.target!==content.value || event.propertyName!=='opacity'))return;
  if(!props.open){window.clearTimeout(leaveTimer);emit('closed');}
}
watch(()=>props.open,open=>{
  cancelAnimationFrame(enterFrame);window.clearTimeout(leaveTimer);visible.value=open;
  if(!open){
    moreId.value='';
    const duration=content.value?parseFloat(getComputedStyle(content.value).transitionDuration)*1000:0;
    leaveTimer=window.setTimeout(()=>finishLeave(),duration+20);
  }else void nextTick(()=>search.value?.focus({preventScroll:true}));
});
onBeforeUnmount(()=>{
  cancelAnimationFrame(frame);cancelAnimationFrame(enterFrame);window.clearTimeout(leaveTimer);observer?.disconnect();window.removeEventListener('resize',position);window.removeEventListener('scroll',position,true);
  document.removeEventListener('pointerdown',outside,true);document.removeEventListener('focusin',focusOutside);document.removeEventListener('keydown',escape,true);
  if(content.value?.contains(document.activeElement))props.anchor.focus({preventScroll:true});
  if(props.anchor.getAttribute('aria-controls')===id)props.anchor.removeAttribute('aria-controls');
  // Native top layer removal happens only after the local leave has completed.
});

return (_ctx: any,_cache: any) => {
  return (_openBlock(), _createElementBlock("section", {
    id: id,
    ref_key: "content",
    ref: content,
    popover: "manual",
    class: _normalizeClass(["conversation-history-panel history-content", {'is-visible':visible.value}]),
    role: "dialog",
    "aria-modal": "false",
    "aria-labelledby": `${id}-${deleting.value || confirming.value ? 'title' : 'browse-title'}`,
    style: _normalizeStyle(style.value),
    onTransitionend: finishLeave
  }, [
    (deleting.value)
      ? (_openBlock(), _createElementBlock(_Fragment, { key: 0 }, [
          _createElementVNode("h2", {
            id: `${id}-title`
          }, "删除这条对话？", 8 /* PROPS */, _hoisted_2),
          _createElementVNode("p", _hoisted_3, "「" + _toDisplayString(deleting.value.title) + "」", 1 /* TEXT */),
          _cache[4] || (_cache[4] = _createElementVNode("p", null, "将永久删除这条对话的全部消息和输入草稿，无法撤销。", -1 /* CACHED */)),
          (deleting.value.id===__props.selected)
            ? (_openBlock(), _createElementBlock("p", _hoisted_4, "删除当前对话后将回到新对话；正在生成的回复将停止。"))
            : _createCommentVNode("v-if", true),
          (deleteFailure.value)
            ? (_openBlock(), _createElementBlock("p", _hoisted_5, _toDisplayString(deleteFailure.value), 1 /* TEXT */))
            : _createCommentVNode("v-if", true),
          _createElementVNode("div", _hoisted_6, [
            _createElementVNode("button", {
              ref_key: "cancel",
              ref: cancel,
              class: "button button--quiet",
              disabled: __props.busy,
              onClick: cancelDelete
            }, "取消", 8 /* PROPS */, _hoisted_7),
            _createElementVNode("button", {
              class: "button button--primary",
              disabled: __props.busy || __props.blocked,
              onClick: deleteOne
            }, _toDisplayString(__props.busy?'删除中…':'确认删除'), 9 /* TEXT, PROPS */, _hoisted_8)
          ])
        ], 64 /* STABLE_FRAGMENT */))
      : (confirming.value)
        ? (_openBlock(), _createElementBlock(_Fragment, { key: 1 }, [
            _createElementVNode("h2", {
              id: `${id}-title`
            }, "清空全部历史对话？", 8 /* PROPS */, _hoisted_9),
            _cache[5] || (_cache[5] = _createElementVNode("p", null, "将删除本产品全部历史对话，包含置顶会话、所有消息和输入草稿。此操作无法撤销。", -1 /* CACHED */)),
            (__props.error)
              ? (_openBlock(), _createElementBlock("p", _hoisted_10, _toDisplayString(__props.error), 1 /* TEXT */))
              : _createCommentVNode("v-if", true),
            _createElementVNode("div", _hoisted_11, [
              _createElementVNode("button", {
                ref_key: "cancel",
                ref: cancel,
                class: "button button--quiet",
                disabled: __props.busy,
                onClick: cancelClear
              }, "取消", 8 /* PROPS */, _hoisted_12),
              _createElementVNode("button", {
                class: "button button--primary",
                disabled: __props.busy || __props.blocked,
                onClick: clearAll
              }, _toDisplayString(__props.busy?'清空中…':'确认清空'), 9 /* TEXT, PROPS */, _hoisted_13)
            ])
          ], 64 /* STABLE_FRAGMENT */))
        : _createCommentVNode("v-if", true),
    _withDirectives(_createElementVNode("div", _hoisted_14, [
      _createElementVNode("header", _hoisted_15, [
        _createElementVNode("h2", {
          id: `${id}-browse-title`
        }, "历史对话", 8 /* PROPS */, _hoisted_16),
        _withDirectives((_openBlock(), _createElementBlock("button", {
          ref_key: "clearButton",
          ref: clearButton,
          class: "history-clear",
          type: "button",
          "aria-label": "清空历史",
          disabled: __props.busy || __props.blocked || !hasRecords.value,
          onClick: confirmClear
        }, [
          _createVNode(_unref(AiIcon), {
            name: "history.clear",
            "aria-hidden": "true"
          })
        ], 8 /* PROPS */, _hoisted_17)), [
          [_unref(vAiTooltip), { content: '清空历史', disabled: !__props.open, closeOnPointerLeave: true }]
        ])
      ]),
      _createElementVNode("div", _hoisted_18, [
        _createVNode(_unref(AiIcon), {
          name: "history.search",
          class: "history-search-icon",
          "aria-hidden": "true"
        }),
        _withDirectives(_createElementVNode("input", {
          ref_key: "search",
          ref: search,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event: any) => ((query).value = $event)),
          class: "history-search",
          type: "search",
          "aria-label": "搜索历史对话标题",
          placeholder: "搜索历史对话",
          autocomplete: "off"
        }, null, 512 /* NEED_PATCH */), [
          [_vModelText, query.value]
        ]),
        (query.value)
          ? _withDirectives((_openBlock(), _createElementBlock("button", {
              key: 0,
              class: "history-search-clear",
              "aria-label": "清除搜索",
              type: "button",
              onClick: _cache[1] || (_cache[1] = ($event: any) => {query.value='';search.value?.focus()})
            }, [
              _createVNode(_unref(AiIcon), {
                name: "history.clearSearch",
                "aria-hidden": "true"
              })
            ])), [
              [_unref(vAiTooltip), { content: '清除搜索', disabled: !__props.open, closeOnPointerLeave: true }]
            ])
          : _createCommentVNode("v-if", true)
      ]),
      (__props.blocked)
        ? (_openBlock(), _createElementBlock("p", _hoisted_19, "请先完成或取消当前业务编辑。"))
        : _createCommentVNode("v-if", true),
      (__props.error)
        ? (_openBlock(), _createElementBlock("p", _hoisted_20, [
            _createTextVNode(_toDisplayString(__props.error) + " ", 1 /* TEXT */),
            _createElementVNode("button", {
              class: "text-button",
              disabled: __props.busy,
              onClick: _cache[2] || (_cache[2] = ($event: any) => (emit('reload')))
            }, _toDisplayString(__props.readFailed?'重新读取':'重试保存'), 9 /* TEXT, PROPS */, _hoisted_21)
          ]))
        : _createCommentVNode("v-if", true),
      _createElementVNode("div", {
        ref_key: "list",
        ref: list,
        class: "history-list",
        "aria-busy": __props.busy
      }, [
        (groups.value.length)
          ? (_openBlock(), _createBlock(_unref(TrHistory), {
              key: 0,
              data: groups.value,
              selected: __props.selected,
              "menu-items": [],
              onItemClick: choose
            }, {
              "item-prefix": _withCtx(({item}) => [
                (!_unref(delivery))
                  ? _withDirectives((_openBlock(), _createElementBlock("button", {
                      key: 0,
                      class: "history-pin",
                      "aria-label": `${item.pinned?'取消置顶':'置顶'}：${item.title}`,
                      "aria-pressed": item.pinned,
                      disabled: __props.busy,
                      onClick: _withModifiers(($event: any) => (item.id && emit('pin',item.id)), ["stop"])
                    }, [
                      _createVNode(_unref(AiIcon), {
                        name: "history.pin",
                        "aria-hidden": "true"
                      })
                    ], 8 /* PROPS */, _hoisted_23)), [
                      [_unref(vAiTooltip), { content: item.pinned ? '取消置顶' : '置顶', disabled: !__props.open, closeOnPointerLeave: true }]
                    ])
                  : _createCommentVNode("v-if", true),
                _createVNode(ConversationMoreMenu, {
                  title: item.title,
                  "record-id": item.id ?? '',
                  open: moreId.value===item.id,
                  "parent-open": __props.open,
                  disabled: __props.busy || __props.blocked,
                  onToggle: ($event: any) => (moreId.value=moreId.value===item.id?'':item.id ?? ''),
                  onClose: ($event: any) => (moreId.value===item.id && (moreId.value='')),
                  onAction: action=>action.id==='delete' && requestDelete(item)
                }, null, 8 /* PROPS */, ["title", "record-id", "open", "parent-open", "disabled", "onToggle", "onClose", "onAction"])
              ]),
              "item-title": _withCtx(({item}) => [
                _withDirectives((_openBlock(), _createElementBlock("button", {
                  class: "history-title",
                  "aria-label": `切换会话：${item.title}`,
                  "aria-current": item.id===__props.selected?'true':undefined,
                  disabled: __props.busy || __props.blocked,
                  onClick: _withModifiers(($event: any) => (choose(item)), ["stop"])
                }, [
                  _createElementVNode("span", null, _toDisplayString(item.title), 1 /* TEXT */)
                ], 8 /* PROPS */, _hoisted_24)), [
                  [_unref(vAiTooltip), { content: item.title, overflowOnly: true, overflowSelector: 'span', disabled: !__props.open }]
                ])
              ]),
              _: 1 /* STABLE */
            }, 8 /* PROPS */, ["data", "selected"]))
          : (_openBlock(), _createElementBlock("p", _hoisted_25, _toDisplayString(query.value.trim()?'未找到匹配的历史对话':'暂无历史对话'), 1 /* TEXT */)),
        (hasEarlier.value && !query.value.trim())
          ? (_openBlock(), _createElementBlock("button", {
              key: 2,
              class: "history-earlier text-button",
              "aria-expanded": earlier.value,
              onClick: _cache[3] || (_cache[3] = ($event: any) => (earlier.value=!earlier.value))
            }, _toDisplayString(earlier.value?'收起更早对话':'查看更早对话'), 9 /* TEXT, PROPS */, _hoisted_26))
          : _createCommentVNode("v-if", true)
      ], 8 /* PROPS */, _hoisted_22)
    ], 512 /* NEED_PATCH */), [
      [_vShow, !confirming.value && !deleting.value]
    ])
  ], 46 /* CLASS, STYLE, PROPS, NEED_HYDRATION */, _hoisted_1))
}
}

})
export default /* @__PURE__ */ Object.assign(__sfc_main__,{__scopeId:"data-v-1a517edf"});