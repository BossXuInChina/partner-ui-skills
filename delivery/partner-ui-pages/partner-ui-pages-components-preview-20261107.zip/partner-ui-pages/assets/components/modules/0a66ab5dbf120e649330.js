function _extends() {
  return _extends = Object.assign ? Object.assign.bind() : function(n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends.apply(null, arguments);
}
import { defineComponent, $props, $setup, $prefix } from "@opentiny/vue-common";
import PcTemplate from "./pc.js";
var template = function template2(mode) {
  var _process$env;
  typeof process === "object" ? (_process$env = process.env) == null ? void 0 : _process$env.TINY_MODE : null;
  return PcTemplate;
};
var $constants = {
  PROCESS_DONE_CLS: "process-done",
  PROCESS_CUR_CLS: "process-current",
  PROCESS_WAIT_CLS: "process-wait",
  PROCESS_DISABLED_CLS: "process-disabled",
  PROCESS_ERROR_CLS: "process-error",
  STACK_NODES_MAX: 7,
  LIMITED_STACK_NODES: 3
};
var timelineItemProps = _extends({}, $props, {
  node: {
    type: Object,
    default: {}
  },
  _constants: {
    type: Object,
    default: function _default() {
      return $constants;
    }
  },
  space: {
    type: [String, Number],
    default: ""
  },
  lineWidth: {
    type: [String, Number],
    default: ""
  },
  autoColorField: {
    type: String,
    default: "autoColor"
  }
});
var TimelineItem = defineComponent({
  name: $prefix + "TimelineItem",
  props: timelineItemProps,
  setup: function setup(props, context) {
    return $setup({
      props,
      context,
      template
    });
  }
});
var version = "3.undefined";
TimelineItem.install = function(Vue) {
  Vue.component(TimelineItem.name, TimelineItem);
};
TimelineItem.version = version;
export {
  TimelineItem as default
};
