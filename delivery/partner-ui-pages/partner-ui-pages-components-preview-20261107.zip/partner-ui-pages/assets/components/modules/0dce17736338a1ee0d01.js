import { renderless, api } from '@opentiny/vue-renderless/slider/vue';
import { defineComponent, props, setup } from '@opentiny/vue-common';
import { openBlock, createElementBlock, createElementVNode, renderSlot, createTextVNode, toDisplayString, normalizeClass, normalizeStyle, createCommentVNode, withDirectives, vShow, Fragment, renderList, vModelText } from 'vue';

function _createForOfIteratorHelperLoose(r, e) {
  var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (t) return (t = t.call(r)).next.bind(t);
  if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
    t && (r = t);
    var o = 0;
    return function() {
      return o >= r.length ? { done: true } : { done: false, value: r[o++] };
    };
  }
  throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return _arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
  }
}
function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}
var _export_sfc = function _export_sfc2(sfc, props) {
  var target = sfc.__vccOpts || sfc;
  for (var _iterator = _createForOfIteratorHelperLoose(props), _step; !(_step = _iterator()).done; ) {
    var _step$value = _step.value, key = _step$value[0], val = _step$value[1];
    target[key] = val;
  }
  return target;
};

var _sfc_main = defineComponent({
  emits: ["update:modelValue", "change", "start", "stop"],
  props: [].concat(props, ["modelValue", "disabled", "max", "min", "step", "numPages", "showTip", "showInput", "height", "range", "formatTooltip", "showSteps", "showLabel", "formatLabel", "vertical", "unit", "changeCompat"]),
  setup: function setup$1(props2, context) {
    return setup({
      props: props2,
      context,
      renderless,
      api
    });
  }
});
var _hoisted_1 = {
  "data-tag": "tiny-slider",
  class: "relative flex h-auto flex-row w-full"
};
var _hoisted_2 = {
  "data-tag": "tiny-slider-left",
  class: "self-center mr-2 block sm:hidden text-sm"
};
var _hoisted_3 = ["aria-label", "aria-valuenow", "aria-valuemin", "aria-valuemax", "aria-valuetext", "aria-orientation", "aria-disabled"];
var _hoisted_4 = ["aria-valuenow", "aria-valuemin", "aria-valuemax", "aria-valuetext", "aria-orientation", "aria-disabled"];
var _hoisted_5 = {
  key: 2,
  "data-tag": "tiny-slider-showsteps"
};
var _hoisted_6 = {
  key: 3,
  "data-tag": "tiny-slider-label",
  class: "hidden sm:block w-full h-4 mt-4"
};
var _hoisted_7 = {
  "data-tag": "tiny-slider-right",
  class: "self-center ml-2 block text-sm sm:hidden"
};
var _hoisted_8 = {
  key: 0,
  "data-tag": "tiny-slider-isdouble",
  class: "relative flex justify-between items-center ml-5"
};
var _hoisted_9 = ["disabled"];
var _hoisted_10 = ["disabled"];
var _hoisted_11 = {
  class: "ml-2"
};
var _hoisted_12 = {
  key: 1,
  "data-tag": "tiny-slider-active-value",
  class: "ml-5 self-center"
};
var _hoisted_13 = ["disabled"];
var _hoisted_14 = {
  class: "ml-2"
};
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", _hoisted_1, [createElementVNode("div", _hoisted_2, [renderSlot(_ctx.$slots, "left", {}, function() {
    return [createTextVNode(
      toDisplayString(_ctx.min),
      1
      /* TEXT */
    )];
  })]), createElementVNode(
    "div",
    {
      ref: "slider",
      class: normalizeClass(["relative w-full h-1 flex-1 my-4 mx-0 bg-color-none-disabled", [_ctx.state.disabled ? "cursor-default" : "cursor-pointe"]]),
      onTouchstart: _cache[10] || (_cache[10] = function() {
        return _ctx.bindMouseDown && _ctx.bindMouseDown.apply(_ctx, arguments);
      }),
      onMousedown: _cache[11] || (_cache[11] = function() {
        return _ctx.bindMouseDown && _ctx.bindMouseDown.apply(_ctx, arguments);
      })
    },
    [createElementVNode(
      "div",
      {
        "data-tag": "tiny-slider-range",
        class: normalizeClass(["absolute rounded left-0 h-1", [_ctx.state.disabled ? "bg-color-none" : "bg-color-brand"]]),
        style: normalizeStyle(_ctx.state.barStyle),
        "aria-hidden": "true"
      },
      null,
      6
      /* CLASS, STYLE */
    ), _ctx.state.leftBtnShow ? (openBlock(), createElementBlock("div", {
      key: 0,
      "data-tag": "tiny-slider-handle",
      role: "slider",
      "aria-label": _ctx.state.isDouble ? "左滑块，当前值 " + _ctx.state.leftBtnValue : "滑块，当前值 " + _ctx.state.leftBtnValue,
      "aria-valuenow": _ctx.state.leftBtnValue,
      "aria-valuemin": _ctx.min,
      "aria-valuemax": _ctx.state.isDouble ? _ctx.state.rightBtnValue : _ctx.max,
      "aria-valuetext": "" + _ctx.state.leftBtnValue + _ctx.unit,
      "aria-orientation": _ctx.vertical ? "vertical" : "horizontal",
      "aria-disabled": _ctx.state.disabled ? "true" : "false",
      tabindex: "0",
      class: normalizeClass(["absolute w-6 h-6 sm:w-5 sm:h-5 box-border shadow-xsm rounded-full bg-color-bg-1 -translate-x-2.5 -translate-y-1/2 left-0 top-0.5", [_ctx.state.disabled ? "border-color-none-hover cursor-not-allowed" : "cursor-grab hover:border-color-brand-hover hover:border-solid hover:border-2 active:border-2 active:border-solid active:border-color-brand-active", _ctx.state.activeIndex === 0 ? "z-20" : "z-10"]]),
      style: normalizeStyle(_ctx.state.leftBtnStyle),
      onMouseenter: _cache[0] || (_cache[0] = function() {
        return _ctx.displayTip && _ctx.displayTip.apply(_ctx, arguments);
      }),
      onMouseleave: _cache[1] || (_cache[1] = function() {
        return _ctx.hideTip && _ctx.hideTip.apply(_ctx, arguments);
      }),
      onTouchstart: _cache[2] || (_cache[2] = function() {
        return _ctx.displayTip && _ctx.displayTip.apply(_ctx, arguments);
      }),
      onTouchend: _cache[3] || (_cache[3] = function() {
        return _ctx.hideTip && _ctx.hideTip.apply(_ctx, arguments);
      }),
      onKeydown: _cache[4] || (_cache[4] = function() {
        return _ctx.bindKeyDown && _ctx.bindKeyDown.apply(_ctx, arguments);
      })
    }, null, 46, _hoisted_3)) : createCommentVNode("v-if", true), _ctx.state.rightBtnShow ? (openBlock(), createElementBlock("div", {
      key: 1,
      "data-tag": "tiny-slider-handle",
      role: "slider",
      "aria-label": "右滑块",
      "aria-valuenow": _ctx.state.rightBtnValue,
      "aria-valuemin": _ctx.state.isDouble ? _ctx.state.leftBtnValue : _ctx.min,
      "aria-valuemax": _ctx.max,
      "aria-valuetext": "" + _ctx.state.rightBtnValue + _ctx.unit,
      "aria-orientation": _ctx.vertical ? "vertical" : "horizontal",
      "aria-disabled": _ctx.state.disabled ? "true" : "false",
      tabindex: "0",
      class: normalizeClass(["absolute w-6 h-6 sm:w-5 sm:h-5 box-border shadow-xsm rounded-full bg-color-bg-1 -translate-x-2.5 -translate-y-1/2 left-0 top-0.5", [_ctx.state.disabled ? "border-color-none-hover cursor-not-allowed" : "cursor-grab hover:border-color-brand-hover hover:border-solid hover:border-2 active:border-2 active:border-solid active:border-color-brand-active", _ctx.state.activeIndex === 1 ? "z-20" : "z-10"]]),
      style: normalizeStyle(_ctx.state.rightBtnStyle),
      onMouseenter: _cache[5] || (_cache[5] = function() {
        return _ctx.displayTip && _ctx.displayTip.apply(_ctx, arguments);
      }),
      onMouseleave: _cache[6] || (_cache[6] = function() {
        return _ctx.hideTip && _ctx.hideTip.apply(_ctx, arguments);
      }),
      onTouchstart: _cache[7] || (_cache[7] = function() {
        return _ctx.displayTip && _ctx.displayTip.apply(_ctx, arguments);
      }),
      onTouchend: _cache[8] || (_cache[8] = function() {
        return _ctx.hideTip && _ctx.hideTip.apply(_ctx, arguments);
      }),
      onKeydown: _cache[9] || (_cache[9] = function() {
        return _ctx.bindKeyDown && _ctx.bindKeyDown.apply(_ctx, arguments);
      })
    }, null, 46, _hoisted_4)) : createCommentVNode("v-if", true), withDirectives(createElementVNode(
      "div",
      {
        ref: "sliderTip",
        "data-tag": "tiny-slider-showtips",
        class: normalizeClass(["absolute bottom-6 px-4 py-1.5 bg-color-bg-1 shadow-lg rounded select-none z-10 whitespace-nowrap text-sm sm:text-xs", "after:content-[''] after:absolute after:left-1/2 after:-bottom-2 after:-translate-x-1/2 after:w-0 after:h-2", "after:border-t-8 after:border-r-8 after:border-l-8 after:border-t-color-bg-1 after:border-x-transparent"]),
        style: normalizeStyle(_ctx.state.tipStyle)
      },
      toDisplayString(_ctx.state.tipValue),
      5
      /* TEXT, STYLE */
    ), [[vShow, _ctx.showTip && _ctx.state.showTip]]), _ctx.showSteps ? (openBlock(), createElementBlock("div", _hoisted_5, [(openBlock(true), createElementBlock(
      Fragment,
      null,
      renderList(_ctx.state.points, function(p, i) {
        return openBlock(), createElementBlock(
          "div",
          {
            "data-tag": "tiny-slider-points",
            class: normalizeClass(["w-0.5 h-0.5 rounded-full sm:rounded absolute sm:h-1 bottom-1.5 sm:bottom-1", [p.value >= Math.min(_ctx.state.rightBtnValue, _ctx.state.leftBtnValue) && p.value <= Math.max(_ctx.state.rightBtnValue, _ctx.state.leftBtnValue) ? "bg-color-brand" : "bg-color-bg-3", _ctx.state.disabled ? "bg-color-border-disabled" : ""]]),
            key: p.position + i,
            style: normalizeStyle({
              "left": p.position
            })
          },
          null,
          6
          /* CLASS, STYLE */
        );
      }),
      128
      /* KEYED_FRAGMENT */
    ))])) : createCommentVNode("v-if", true), _ctx.showLabel ? (openBlock(), createElementBlock("div", _hoisted_6, [(openBlock(true), createElementBlock(
      Fragment,
      null,
      renderList(_ctx.state.labels, function(p, i) {
        return openBlock(), createElementBlock(
          "div",
          {
            class: normalizeClass(["absolute -translate-x-1/2 first:translate-x-0 last:-translate-x-full", [_ctx.state.disabled ? "text-color-text-disabled" : "text-color-text-primary"]]),
            key: p.position + i,
            style: normalizeStyle({
              "left": p.position,
              "max-width": "calc( " + _ctx.max / _ctx.step + "% - 20px )"
            })
          },
          toDisplayString(p.label),
          7
          /* TEXT, CLASS, STYLE */
        );
      }),
      128
      /* KEYED_FRAGMENT */
    ))])) : createCommentVNode("v-if", true)],
    34
    /* CLASS, NEED_HYDRATION */
  ), createElementVNode("div", _hoisted_7, [renderSlot(_ctx.$slots, "right", {}, function() {
    return [createTextVNode(
      toDisplayString(_ctx.max),
      1
      /* TEXT */
    )];
  })]), _ctx.showInput ? (openBlock(), createElementBlock(
    Fragment,
    {
      key: 0
    },
    [_ctx.state.isDouble ? (openBlock(), createElementBlock("div", _hoisted_8, [renderSlot(_ctx.$slots, "default", {
      slotScope: _ctx.state.inputValue
    }, function() {
      return [withDirectives(createElementVNode("input", {
        type: "text",
        "onUpdate:modelValue": _cache[12] || (_cache[12] = function($event) {
          return _ctx.state.inputValue[0] = $event;
        }),
        disabled: _ctx.state.disabled,
        onChange: _cache[13] || (_cache[13] = function($event) {
          return _ctx.inputValueChange($event, "left");
        }),
        class: "h-8 w-12 outline-0 px-2 py-0 text-center border border-color-bg-3 hover:border-color-border-hover focus:border-color-brand-focus disabled:border-color-border rounded"
      }, null, 40, _hoisted_9), [[vModelText, _ctx.state.inputValue[0]]]), createElementVNode(
        "div",
        {
          class: normalizeClass(["h-px w-4 mx-2 my-0", [_ctx.state.disabled ? "bg-color-border-disabled" : "bg-color-text-primary"]])
        },
        null,
        2
        /* CLASS */
      ), withDirectives(createElementVNode("input", {
        type: "text",
        "onUpdate:modelValue": _cache[14] || (_cache[14] = function($event) {
          return _ctx.state.inputValue[1] = $event;
        }),
        disabled: _ctx.state.disabled,
        onChange: _cache[15] || (_cache[15] = function($event) {
          return _ctx.inputValueChange($event, "right");
        }),
        class: "h-8 w-12 outline-0 px-2 py-0 text-center border border-color-bg-3 hover:border-color-border-hover focus:border-color-brand-focus disabled:border-color-border rounded"
      }, null, 40, _hoisted_10), [[vModelText, _ctx.state.inputValue[1]]]), createElementVNode(
        "span",
        _hoisted_11,
        toDisplayString(_ctx.unit),
        1
        /* TEXT */
      )];
    })])) : (openBlock(), createElementBlock("div", _hoisted_12, [renderSlot(_ctx.$slots, "default", {
      slotScope: _ctx.state.activeValue
    }, function() {
      return [withDirectives(createElementVNode("input", {
        type: "text",
        "onUpdate:modelValue": _cache[16] || (_cache[16] = function($event) {
          return _ctx.state.activeValue = $event;
        }),
        onChange: _cache[17] || (_cache[17] = function() {
          return _ctx.inputOnChange && _ctx.inputOnChange.apply(_ctx, arguments);
        }),
        class: "h-8 w-12 outline-0 px-2 py-0 text-center border border-color-bg-3 hover:border-color-border-hover focus:border-color-brand-focus disabled:border-color-border rounded",
        disabled: _ctx.state.disabled
      }, null, 40, _hoisted_13), [[vModelText, _ctx.state.activeValue]]), createElementVNode(
        "span",
        _hoisted_14,
        toDisplayString(_ctx.unit),
        1
        /* TEXT */
      )];
    })]))],
    64
    /* STABLE_FRAGMENT */
  )) : createCommentVNode("v-if", true)]);
}
var mobileFirst = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);

export { mobileFirst as default };
