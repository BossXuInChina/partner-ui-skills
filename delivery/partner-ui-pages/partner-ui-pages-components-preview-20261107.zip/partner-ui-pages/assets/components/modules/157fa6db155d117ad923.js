import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 24 24",
  "xml:space": "preserve"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    class: "arrow-up_svg__st0",
    d: "m11 6.3-5.4 5.4c-.4.4-1 .4-1.4 0-.4-.4-.4-1 0-1.4l7.1-7.1c.4-.4 1-.4 1.4 0l7.1 7.1c.4.4.4 1 0 1.4-.4.4-1 .4-1.4 0L13 6.3V20c0 .6-.4 1-1 1s-1-.4-1-1V6.3z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = [_hoisted_2];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_3));
}
var ArrowUp = {
  render
};
var arrowUp = function arrowUp2() {
  return svg({
    name: "IconArrowUp",
    component: ArrowUp,
    filledComponent: ArrowUp
  })();
};
export {
  arrowUp as default
};
