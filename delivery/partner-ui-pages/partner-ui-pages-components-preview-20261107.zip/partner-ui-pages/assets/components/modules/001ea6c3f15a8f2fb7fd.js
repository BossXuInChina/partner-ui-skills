import Tooltip from "@opentiny/vue-tooltip";
import { hooks, createComponent, h } from "@opentiny/vue-common";
import { isServer, on, getScrollContainer, throttle, isEqual, once } from "@opentiny/utils";
var MISTAKE_VALUE = 2;
var globalTooltip = {
  value: null
};
var tooltipContent = hooks.ref("");
var isEllipsis = function isEllipsis2(currentTarget) {
  var content = getRealContent(currentTarget);
  if (!content) return false;
  return currentTarget.scrollWidth > currentTarget.clientWidth || currentTarget.scrollHeight - currentTarget.clientHeight > MISTAKE_VALUE;
};
var getRealContent = function getRealContent2(currentTarget) {
  return "content" in currentTarget.boundingValue ? currentTarget.boundingValue.content : currentTarget.textContent;
};
var isAlwaysShowTip = function isAlwaysShowTip2(currentTarget) {
  var _currentTarget$boundi;
  return Boolean(currentTarget == null ? void 0 : (_currentTarget$boundi = currentTarget.boundingValue) == null ? void 0 : _currentTarget$boundi.always);
};
var isDarkTheme = function isDarkTheme2(currentTarget) {
  var _currentTarget$boundi2;
  return Boolean((currentTarget == null ? void 0 : (_currentTarget$boundi2 = currentTarget.boundingValue) == null ? void 0 : _currentTarget$boundi2.effect) === "dark");
};
var getPlacement = function getPlacement2(currentTarget) {
  var _currentTarget$boundi3;
  return ((_currentTarget$boundi3 = currentTarget.boundingValue) == null ? void 0 : _currentTarget$boundi3.placement) || "top";
};
var oldPopperClass = [];
var getPopperClass = function getPopperClass2(currentTarget) {
  var _currentTarget$boundi4;
  var cls = ((_currentTarget$boundi4 = currentTarget.boundingValue) == null ? void 0 : _currentTarget$boundi4.popperClass) || "";
  return cls.split(" ").filter(function(c) {
    return c;
  });
};
var mouseenterHandler = function mouseenterHandler2(e) {
  var currentTarget = e.currentTarget;
  if (!currentTarget.boundingValue) {
    return;
  }
  if (isAlwaysShowTip(currentTarget) || isEllipsis(currentTarget)) {
    var _tooltip$state$popper;
    if (!globalTooltip.value) {
      tooltipContent.value = getRealContent(currentTarget);
      globalTooltip.value = createComponent({
        el: document.createElement("div"),
        propsData: {
          renderContent: function renderContent() {
            return h("span", {
              class: "tiny-directive-tip__content"
            }, tooltipContent.value);
          },
          placement: getPlacement(currentTarget),
          effect: isDarkTheme(currentTarget) ? "dark" : "light",
          popperClass: getPopperClass(currentTarget).join(" ")
        },
        component: Tooltip
      });
      oldPopperClass = getPopperClass(currentTarget);
    }
    var tooltip = globalTooltip.value;
    var popperElm = tooltip.state.popperElm;
    tooltipContent.value = getRealContent(currentTarget);
    tooltip.state.referenceElm = currentTarget;
    tooltip.state.currentPlacement = getPlacement(currentTarget);
    if (popperElm) {
      var _popperElm$classList, _popperElm$classList2;
      popperElm.classList.replace("is-" + (isDarkTheme(currentTarget) ? "light" : "dark"), "is-" + (isDarkTheme(currentTarget) ? "dark" : "light"));
      (_popperElm$classList = popperElm.classList).remove.apply(_popperElm$classList, oldPopperClass);
      oldPopperClass = getPopperClass(currentTarget);
      (_popperElm$classList2 = popperElm.classList).add.apply(_popperElm$classList2, oldPopperClass);
    }
    tooltip.show();
    if ((_tooltip$state$popper = tooltip.state.popperJS) != null && _tooltip$state$popper._options) {
      tooltip.state.popperJS._options.placement = getPlacement(currentTarget);
    }
    tooltip.updatePopper();
  }
};
var mouseleaveHandler = function mouseleaveHandler2() {
  globalTooltip.value && globalTooltip.value.hide();
};
var bind$2 = function bind$22(el, _ref) {
  var _el$boundingValue;
  var value = _ref.value;
  var resultValue = value === void 0 ? {} : value;
  if (typeof resultValue === "boolean" && resultValue) {
    resultValue = {};
  }
  el.boundingValue = resultValue;
  if (resultValue && !((_el$boundingValue = el.boundingValue) != null && _el$boundingValue.listened)) {
    el.addEventListener("mouseenter", mouseenterHandler);
    el.addEventListener("mouseleave", mouseleaveHandler);
    el.boundingValue.listened = true;
  }
};
var unbind$2 = function unbind$22(el) {
  var _el$boundingValue2;
  if ((_el$boundingValue2 = el.boundingValue) != null && _el$boundingValue2.listened) {
    var tooltip = globalTooltip.value;
    if (tooltip && el === tooltip.state.referenceElm && tooltip.state.showPopper) {
      tooltip.hide();
    }
    el.removeEventListener("mouseenter", mouseenterHandler);
    el.removeEventListener("mouseleave", mouseleaveHandler);
  }
};
var autoTip = {
  bind: bind$2,
  unbind: unbind$2,
  update: bind$2,
  beforeMount: bind$2,
  unmounted: unbind$2,
  updated: bind$2
};
var nodeList = [];
var nameSpace = "@@clickoutsideContext";
var startClick;
var startClickPath;
var seed = 0;
if (!isServer) {
  on(document, "mousedown", function(event) {
    startClick = event;
    startClickPath = event.composedPath ? event.composedPath() : [event.target];
    nodeList.filter(function(node) {
      return node[nameSpace].mousedownTrigger;
    }).forEach(function(node) {
      return node[nameSpace].documentHandler(event, startClick, startClickPath);
    });
  });
  on(document, "mouseup", function(event) {
    nodeList.filter(function(node) {
      return !node[nameSpace].mousedownTrigger;
    }).forEach(function(node) {
      var _node$nameSpace;
      var isMouseupTrigger = (_node$nameSpace = node[nameSpace]) == null ? void 0 : _node$nameSpace.mouseupTrigger;
      node[nameSpace].documentHandler(
        event,
        isMouseupTrigger ? event : startClick,
        // mouseupTrigger 模式下 mousedown 参数即当前派发中的 mouseup 事件，路径仍有效；
        // 否则 mousedown 已派发完毕，必须使用派发时缓存的路径
        isMouseupTrigger ? null : startClickPath
      );
    });
    startClick = null;
    startClickPath = null;
  });
}
var createDocumentHandler = function createDocumentHandler2(el, binding, vnode) {
  return function(mouseup, mousedown, cachedMousedownPath) {
    var _mousedown, _mousedown2, _mouseup, _mouseup2, _mousedown3, _mouseup3;
    if (mouseup === void 0) {
      mouseup = {};
    }
    if (mousedown === void 0) {
      mousedown = {};
    }
    var popperElm = vnode.context.popperElm || vnode.context.state && vnode.context.state.popperElm;
    var mousedownPath = cachedMousedownPath && cachedMousedownPath.length ? cachedMousedownPath : ((_mousedown = mousedown) == null ? void 0 : _mousedown.composedPath == null ? void 0 : _mousedown.composedPath()) || [(_mousedown2 = mousedown) == null ? void 0 : _mousedown2.target];
    var mouseupPath = ((_mouseup = mouseup) == null ? void 0 : _mouseup.composedPath == null ? void 0 : _mouseup.composedPath()) || [(_mouseup2 = mouseup) == null ? void 0 : _mouseup2.target];
    var isClickInEl = mousedownPath.includes(el) || mouseupPath.includes(el);
    var isClickInPopper = popperElm && (mousedownPath.includes(popperElm) || mouseupPath.includes(popperElm));
    if (!((_mousedown3 = mousedown) != null && _mousedown3.target) || !((_mouseup3 = mouseup) != null && _mouseup3.target) || isClickInEl || isClickInPopper) {
      return;
    }
    if (binding.expression && el[nameSpace].methodName && vnode.context[el[nameSpace].methodName]) {
      vnode.context[el[nameSpace].methodName]();
    } else {
      el[nameSpace].bindingFn && el[nameSpace].bindingFn();
    }
  };
};
var clickoutside = {
  bind: function bind(el, binding, vnode) {
    nodeList.push(el);
    var id = seed++;
    var modifiers = binding.modifiers, expression = binding.expression, value = binding.value;
    var _ref2 = modifiers || {}, _ref2$mousedown = _ref2.mousedown, mousedown = _ref2$mousedown === void 0 ? false : _ref2$mousedown, _ref2$mouseup = _ref2.mouseup, mouseup = _ref2$mouseup === void 0 ? false : _ref2$mouseup;
    el[nameSpace] = {
      id,
      documentHandler: createDocumentHandler(el, binding, vnode),
      methodName: expression,
      bindingFn: value,
      mousedownTrigger: mousedown,
      mouseupTrigger: mouseup
    };
  },
  update: function update(el, binding, vnode) {
    var modifiers = binding.modifiers, expression = binding.expression, value = binding.value;
    var _ref3 = modifiers || {}, _ref3$mousedown = _ref3.mousedown, mousedown = _ref3$mousedown === void 0 ? false : _ref3$mousedown, _ref3$mouseup = _ref3.mouseup, mouseup = _ref3$mouseup === void 0 ? false : _ref3$mouseup;
    el[nameSpace].documentHandler = createDocumentHandler(el, binding, vnode);
    el[nameSpace].methodName = expression;
    el[nameSpace].bindingFn = value;
    el[nameSpace].mousedownTrigger = mousedown;
    el[nameSpace].mouseupTrigger = mouseup;
  },
  unbind: function unbind(el) {
    if (el.nodeType !== Node.ELEMENT_NODE) {
      return;
    }
    var len = nodeList.length;
    for (var i = 0; i < len; i++) {
      if (nodeList[i][nameSpace].id === el[nameSpace].id) {
        nodeList.splice(i, 1);
        break;
      }
    }
    if (nodeList.length === 0 && startClick) {
      startClick = null;
      startClickPath = null;
    }
    delete el[nameSpace];
  }
};
function walk(el, filter) {
  var walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
  var matchNodes = [];
  while (walker.nextNode()) {
    var node = walker.currentNode;
    filter(node) && matchNodes.push(node);
  }
  return matchNodes;
}
function editNodes(el, nodes, query) {
  nodes.forEach(function(node) {
    var content = node.textContent;
    var start = content.indexOf(query);
    var startText = content.substring(0, start);
    var endText = content.substring(start + query.length);
    node.textContent = startText;
    var span = document.createElement("span");
    span.classList.add("tiny-hl-query-node");
    span.textContent = query;
    var end = document.createTextNode(endText);
    node.after(span, end);
  });
  if (nodes.length) {
    edit(el, query);
  }
}
function restoreNodes(nodes) {
  var parents = /* @__PURE__ */ new Set();
  nodes.forEach(function(node) {
    var _node$parentElement;
    return parents.add((_node$parentElement = node.parentElement) == null ? void 0 : _node$parentElement.parentElement);
  });
  parents.forEach(function(node) {
    node.innerText = node.textContent;
  });
}
function edit(el, query) {
  if (query) {
    var matchNodes = walk(el, function(node) {
      if (node.parentElement.classList.contains("tiny-hl-query-node")) {
        return false;
      }
      var content = node.textContent || "";
      return content.includes(query);
    });
    editNodes(el, matchNodes, query);
  }
}
function restore(el) {
  var matchNodes = walk(el, function(node) {
    return node.parentElement.classList.contains("tiny-hl-query-node");
  });
  restoreNodes(matchNodes);
}
var mounted = function mounted2(el, binding) {
  el.classList.toggle("tiny-hl-query", true);
  var query = binding.value;
  edit(el, query);
};
var beforeUpdate = function beforeUpdate2(el) {
  restore(el);
};
var updated = function updated2(el, binding) {
  var query = binding.value;
  edit(el, query);
};
var highlightQuery = {
  mounted,
  beforeUpdate,
  updated,
  // vue2周期
  inserted: mounted,
  update: beforeUpdate,
  componentUpdated: updated
};
var CONTEXT_KEY$1 = "@@infinitescrollContext";
var OBSERVER_CHECK_INTERVAL = 50;
var ATTR_DEFAULT_DELAY = 200;
var ATTR_DEFAULT_DISTANCE = 0;
var attrs = {
  delay: {
    type: Number,
    default: ATTR_DEFAULT_DELAY
  },
  disabled: {
    type: Boolean,
    default: false
  },
  distance: {
    type: Number,
    default: ATTR_DEFAULT_DISTANCE
  },
  immediate: {
    type: Boolean,
    default: true
  }
};
var isNull = function isNull2(val) {
  return val === null;
};
var parseAttrValue = function parseAttrValue2(attrVal, type, defaultVal) {
  if (isNull(attrVal)) return defaultVal;
  if (type === Boolean) {
    return attrVal !== "false";
  } else if (type === Number) {
    return Number(attrVal);
  }
};
var computeScrollOptions = function computeScrollOptions2(el, instance) {
  return Object.entries(attrs).reduce(function(accumulator, _ref4) {
    var name = _ref4[0], option = _ref4[1];
    var type = option.type, defaultValue = option.default;
    var attrKey = "infinite-scroll-" + name;
    var $attrValue = instance != null && instance.$el && typeof instance.$el.getAttribute === "function" ? instance.$el.getAttribute(attrKey) : null;
    var attrValue = el.getAttribute(attrKey);
    var value;
    if (isNull(attrValue) && isNull($attrValue) || !isNull(attrValue)) {
      value = parseAttrValue(attrValue, type, defaultValue);
    }
    if (isNull(attrValue) && !isNull($attrValue)) {
      value = parseAttrValue($attrValue, type, defaultValue);
    }
    accumulator[name] = Number.isNaN(value) ? defaultValue : value;
    return accumulator;
  }, {});
};
var stopObserver = function stopObserver2(el) {
  var observer = el[CONTEXT_KEY$1].observer;
  if (observer) {
    observer.disconnect();
    delete el[CONTEXT_KEY$1].observer;
  }
};
var accumOffsetTop = function accumOffsetTop2(el) {
  var totalOffset = 0;
  var parent = el;
  while (parent) {
    totalOffset += parent.offsetTop;
    parent = parent.offsetParent;
  }
  return totalOffset;
};
var distanceOffsetTop = function distanceOffsetTop2(el, containerEl) {
  return Math.abs(accumOffsetTop(el) - accumOffsetTop(containerEl));
};
var scroller = function scroller2(el, cb) {
  var _el$CONTEXT_KEY$ = el[CONTEXT_KEY$1], container = _el$CONTEXT_KEY$.container, containerEl = _el$CONTEXT_KEY$.containerEl, instance = _el$CONTEXT_KEY$.instance, observer = _el$CONTEXT_KEY$.observer, lastScrollTop = _el$CONTEXT_KEY$.lastScrollTop;
  var _computeScrollOptions = computeScrollOptions(el, instance), disabled = _computeScrollOptions.disabled, distance = _computeScrollOptions.distance;
  var clientHeight = containerEl.clientHeight, scrollHeight = containerEl.scrollHeight, scrollTop = containerEl.scrollTop;
  var deltaTop = scrollTop - lastScrollTop;
  el[CONTEXT_KEY$1].lastScrollTop = scrollTop;
  if (observer || disabled || deltaTop < 0) return;
  var isTrigger = false;
  if (container === el) {
    isTrigger = scrollHeight - (clientHeight + scrollTop) <= distance;
  } else {
    var clientTop = el.clientTop, height = el.scrollHeight;
    var offsetTop = distanceOffsetTop(el, containerEl);
    isTrigger = scrollTop + clientHeight >= offsetTop + clientTop + height - distance;
  }
  if (isTrigger) {
    cb.call(instance);
  }
};
function observerChecker(el, cb) {
  var _el$CONTEXT_KEY$2 = el[CONTEXT_KEY$1], containerEl = _el$CONTEXT_KEY$2.containerEl, instance = _el$CONTEXT_KEY$2.instance;
  var _computeScrollOptions2 = computeScrollOptions(el, instance), disabled = _computeScrollOptions2.disabled;
  if (disabled || containerEl.clientHeight === 0) return;
  if (containerEl.scrollHeight <= containerEl.clientHeight) {
    cb.call(instance);
  } else {
    stopObserver(el);
  }
}
var bind$1 = function bind$12(el, binding, vnode) {
  var instance = binding.instance || vnode.context;
  var cb = binding.value;
  if (typeof cb !== "function") {
    throw new TypeError('[TINY Error][InfiniteScroll] "v-infinite-scroll" binding value must be a function');
  }
  instance.$nextTick(function() {
    var _computeScrollOptions3 = computeScrollOptions(el, instance), delay = _computeScrollOptions3.delay, immediate = _computeScrollOptions3.immediate;
    var container = getScrollContainer(el, true);
    var containerEl = container === window ? document.documentElement : container;
    var onScroll = throttle(delay, scroller.bind(null, el, cb));
    if (!container) return;
    el[CONTEXT_KEY$1] = {
      instance,
      container,
      containerEl,
      delay,
      cb,
      onScroll,
      lastScrollTop: containerEl.scrollTop
    };
    if (immediate) {
      var observer = new MutationObserver(throttle(OBSERVER_CHECK_INTERVAL, observerChecker.bind(null, el, cb)));
      el[CONTEXT_KEY$1].observer = observer;
      observer.observe(el, {
        childList: true,
        subtree: true
      });
      observerChecker(el, cb);
    }
    container.addEventListener("scroll", onScroll);
  });
};
var update$1 = function update$12(el, binding, vnode) {
  if (!el[CONTEXT_KEY$1]) {
    var instance = binding.instance || vnode.context;
    return instance.$nextTick();
  } else {
    var _el$CONTEXT_KEY$3 = el[CONTEXT_KEY$1], containerEl = _el$CONTEXT_KEY$3.containerEl, cb = _el$CONTEXT_KEY$3.cb, observer = _el$CONTEXT_KEY$3.observer;
    if (containerEl.clientHeight && observer) {
      observerChecker(el, cb);
    }
  }
};
var unbind$1 = function unbind$12(el) {
  var _el$CONTEXT_KEY$4 = el[CONTEXT_KEY$1], container = _el$CONTEXT_KEY$4.container, onScroll = _el$CONTEXT_KEY$4.onScroll;
  if (container) container.removeEventListener("scroll", onScroll);
  stopObserver(el);
};
var infiniteScroll = {
  bind: bind$1,
  update: update$1,
  unbind: unbind$1,
  beforeMount: bind$1,
  updated: update$1,
  unmounted: unbind$1
};
var CONTEXT_KEY = "@@observevisibilityContext";
var processOptions = function processOptions2(value) {
  var options;
  if (typeof value === "function") {
    options = {
      callback: value
    };
  } else {
    options = value;
  }
  return options;
};
var createObserver = function createObserver2(_ref5) {
  var options = _ref5.options, instance = _ref5.instance, state = _ref5.state;
  if (state.observer) {
    destroyObserver(state);
  }
  if (state.frozen) return;
  state.options = processOptions(options);
  state.callback = function(result, entry) {
    state.options.callback(result, entry);
    if (result && state.options.once) {
      state.frozen = true;
      destroyObserver(state);
    }
  };
  if (state.callback && state.options.throttle) {
    state.callback = throttle(state.options.throttleDelay || 20, state.callback);
  }
  state.observer = new IntersectionObserver(function(entries) {
    var entry = entries[0];
    if (entries.length > 1) {
      var intersectingEntry = entries.find(function(e) {
        return e.isIntersecting;
      });
      if (intersectingEntry) {
        entry = intersectingEntry;
      }
    }
    if (state.callback) {
      state.callback(entry.isIntersecting, entry);
    }
  }, state.options.intersection);
  instance.$nextTick(function() {
    if (state.observer) {
      state.observer.observe(state.el);
    }
  });
};
var destroyObserver = function destroyObserver2(state) {
  if (state.observer) {
    state.observer.disconnect();
    state.observer = null;
  }
  if (state.callback) {
    state.callback = null;
  }
};
var createVisibilityState = function createVisibilityState2(_ref6) {
  var el = _ref6.el, options = _ref6.options, instance = _ref6.instance;
  var state = {
    el,
    observer: null,
    frozen: false
  };
  createObserver({
    options,
    instance,
    state
  });
  return state;
};
var bind2 = function bind3(el, _ref7, _ref8) {
  var value = _ref7.value, instance = _ref7.instance;
  var context = _ref8.context;
  if (!value) return;
  if (typeof IntersectionObserver === "undefined") {
    throw new TypeError("[TINY Error][ObserveVisibility] IntersectionObserver API is not available in your browser");
  } else {
    instance = instance || context;
    el[CONTEXT_KEY] = createVisibilityState({
      el,
      options: value,
      instance
    });
  }
};
var update2 = function update3(el, _ref9, _ref0) {
  var value = _ref9.value, oldValue = _ref9.oldValue, instance = _ref9.instance;
  var context = _ref0.context;
  if (isEqual(value, oldValue)) return;
  var state = el[CONTEXT_KEY];
  if (!value) {
    unbind2(el);
    return;
  }
  instance = instance || context;
  if (state) {
    createObserver({
      options: value,
      instance,
      state
    });
  } else {
    bind2(el, {
      value,
      instance
    }, {
      context
    });
  }
};
var unbind2 = function unbind3(el) {
  var state = el[CONTEXT_KEY];
  if (state) {
    destroyObserver(state);
    delete el[CONTEXT_KEY];
  }
};
var ObserveVisibility = {
  bind: bind2,
  update: update2,
  unbind: unbind2,
  beforeMount: bind2,
  updated: update2,
  unmounted: unbind2
};
var repeatClick = function repeatClick2(el, binding) {
  var LONG_PRESS_INTERVAL = 200;
  var interval = null;
  var startTime;
  var handler = function handler2() {
    typeof binding.value === "function" && binding.value.apply();
  };
  var clear = function clear2() {
    if (Date.now() - startTime < LONG_PRESS_INTERVAL) {
      handler();
    }
    clearInterval(interval);
    interval = null;
  };
  on(el, "mousedown", function(e) {
    if (e.button !== 0) {
      return;
    }
    startTime = Date.now();
    once(document, "mouseup", clear);
    clearInterval(interval);
    interval = setInterval(handler, LONG_PRESS_INTERVAL);
  });
};
export {
  autoTip as AutoTip,
  clickoutside as Clickoutside,
  highlightQuery as HighlightQuery,
  infiniteScroll as InfiniteScroll,
  ObserveVisibility,
  repeatClick as RepeatClick
};
