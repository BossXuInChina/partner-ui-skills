import { renderless, api } from '@opentiny/vue-renderless/select-wrapper/vue';
import { defineComponent, $prefix, $props, setup } from '@opentiny/vue-common';
import BaseSelect from '@opentiny/vue-base-select';
import TreeSelect from '@opentiny/vue-tree-select';
import GridSelect from '@opentiny/vue-grid-select';
import '@opentiny/vue-theme/select/index.css';
import { openBlock, createBlock, resolveDynamicComponent, mergeProps, toHandlers, createSlots, withCtx, renderSlot, normalizeProps, renderList, guardReactiveProps } from 'vue';

function _createForOfIteratorHelperLoose(r, e) {
  var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (t) return (t = t.call(r)).next.bind(t);
  if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
    t && (r = t);
    var o = 0;
    return function() {
      return o >= r.length ? { done: true } : { done: false, value: r[o++] };
    };
  }
  throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return _arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
  }
}
function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}
var _export_sfc = function _export_sfc2(sfc, props) {
  var target = sfc.__vccOpts || sfc;
  for (var _iterator = _createForOfIteratorHelperLoose(props), _step; !(_step = _iterator()).done; ) {
    var _step$value = _step.value, key = _step$value[0], val = _step$value[1];
    target[key] = val;
  }
  return target;
};

function _extends() {
  return _extends = Object.assign ? Object.assign.bind() : function(n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends.apply(null, arguments);
}
var $constants = {
  TYPE: {
    Grid: "grid",
    Tree: "tree"
  }
};
var _sfc_main = defineComponent({
  name: $prefix + "SelectWrapper",
  inheritAttrs: false,
  components: {
    TinyBaseSelect: BaseSelect,
    TinyTreeSelect: TreeSelect,
    TinyGridSelect: GridSelect
  },
  props: _extends({}, $props, {
    _constants: {
      type: Object,
      default: function _default() {
        return $constants;
      }
    },
    id: [Number, String],
    name: String,
    size: String,
    remote: Boolean,
    remoteConfig: {
      type: Object,
      default: function _default2() {
        return {
          showIcon: false,
          clearData: false,
          autoSearch: false
        };
      }
    },
    title: String,
    shape: String,
    tip: String,
    label: String,
    loading: Boolean,
    disabled: Boolean,
    options: Array,
    dataset: Object,
    textField: {
      type: String,
      default: "label"
    },
    tabindex: {
      type: String,
      default: "1"
    },
    valueField: {
      type: String,
      default: "value"
    },
    placement: {
      type: String,
      default: "bottom-start"
    },
    showCheck: {
      type: Boolean,
      default: true
    },
    showAlloption: {
      type: Boolean,
      default: true
    },
    multiple: Boolean,
    clearable: Boolean,
    noDataText: String,
    filterable: Boolean,
    loadingText: String,
    noMatchText: String,
    popperClass: String,
    allowCreate: Boolean,
    collapseTags: Boolean,
    remoteMethod: Function,
    filterMethod: Function,
    reserveKeyword: Boolean,
    automaticDropdown: Boolean,
    defaultFirstOption: Boolean,
    modelValue: {},
    valueKey: {
      type: String,
      default: "value"
    },
    placeholder: String,
    searchPlaceholder: String,
    autocomplete: {
      type: String,
      default: "off"
    },
    multipleLimit: {
      type: Number,
      default: 0
    },
    popperAppendToBody: {
      type: Boolean,
      default: true
    },
    hideDrop: {
      type: Boolean,
      default: false
    },
    copyable: {
      type: Boolean,
      default: false
    },
    renderType: String,
    gridOp: {
      type: Object,
      default: function _default3() {
        return {};
      }
    },
    treeOp: {
      type: Object,
      default: function _default4() {
        return {};
      }
    },
    delay: {
      type: Number,
      default: 200
    },
    readonly: Boolean,
    dropStyle: {
      type: Object,
      default: function _default5() {
        return {};
      }
    },
    cacheOp: Object,
    isDropInheritWidth: Boolean,
    tagSelectable: {
      type: Boolean,
      default: false
    },
    selectConfig: {
      type: Object,
      default: function _default6() {
        return {
          checkMethod: function checkMethod() {
            return true;
          }
        };
      }
    },
    radioConfig: {
      type: Object,
      default: function _default7() {
        return {
          checkMethod: function checkMethod() {
            return true;
          }
        };
      }
    },
    allowCopy: {
      type: Boolean,
      default: false
    },
    textSplit: {
      type: String,
      default: ","
    },
    autoClose: Boolean,
    queryDebounce: Number,
    ignoreEnter: {
      type: Boolean,
      default: false
    },
    dropdownIcon: {
      type: [Object, String],
      default: ""
    },
    disabledTooltipContent: String,
    hoverExpand: {
      type: Boolean,
      default: false
    },
    optimization: [Boolean, Object],
    displayOnly: {
      type: Boolean,
      default: false
    },
    initQuery: Function,
    extraQueryParams: {
      type: [Object, String, Boolean, Array, Number],
      default: ""
    },
    updateDelay: {
      type: Number,
      default: 0
    },
    showTips: {
      type: Boolean,
      default: true
    },
    closeByMask: {
      type: Boolean,
      default: true
    },
    keepFocus: {
      type: Boolean,
      default: false
    },
    popperOptions: {
      type: Object,
      default: function _default8() {
        return {
          gpuAcceleration: false,
          boundariesPadding: 0
        };
      }
    },
    trim: {
      type: Boolean,
      default: false
    },
    topCreate: {
      type: Boolean,
      default: false
    },
    topCreateText: String,
    initLabel: {
      type: String,
      default: ""
    },
    blank: {
      type: Boolean,
      default: false
    },
    tooltipConfig: {
      type: Object,
      default: function _default9() {
        return {};
      }
    },
    showEmptyValue: Boolean,
    dropdownHeight: {
      type: String,
      default: "initial"
    },
    stopPropagation: {
      type: Boolean,
      default: void 0
    },
    searchable: {
      type: Boolean,
      default: false
    },
    showEmptyImage: {
      type: Boolean,
      default: false
    },
    inputBoxType: {
      type: String,
      default: "normal",
      validator: function validator(value) {
        return ["normal", "underline"].includes(value);
      }
    },
    tagType: String,
    clearNoMatchValue: {
      type: Boolean,
      default: false
    },
    showLimitText: {
      type: Boolean,
      default: false
    },
    showProportion: {
      type: Boolean,
      default: false
    },
    clickExpand: {
      type: Boolean,
      default: false
    },
    maxVisibleRows: {
      type: Number,
      default: 1
    },
    allText: String,
    showAllTextTag: {
      type: Boolean,
      default: false
    },
    maxTagWidth: {
      type: [String, Number],
      default: null
    },
    autoSelect: {
      type: Boolean,
      default: false
    }
  }),
  setup: function setup$1(props, context) {
    var components = {
      TinyBaseSelect: BaseSelect,
      TinyTreeSelect: TreeSelect,
      TinyGridSelect: GridSelect
    };
    return setup({
      props,
      context,
      renderless,
      api,
      extendOptions: {
        components
      }
    });
  }
});
function _sfc_render(_ctx, _cache, $props2, $setup, $data, $options) {
  return openBlock(), createBlock(
    resolveDynamicComponent(_ctx.resolvedComponent),
    mergeProps({
      ref: "childComponent"
    }, _ctx.mergedProps, toHandlers(_ctx.listeners)),
    createSlots({
      default: withCtx(function(slotProps) {
        return [_ctx.hasScopedDefault ? renderSlot(_ctx.$slots, "default", normalizeProps(mergeProps({
          key: 0
        }, slotProps))) : renderSlot(_ctx.$slots, "default", {
          key: 1
        })];
      }),
      _: 2
      /* DYNAMIC */
    }, [renderList(_ctx.slotNames, function(slotName) {
      return {
        name: slotName,
        fn: withCtx(function(slotProps) {
          return [renderSlot(_ctx.$slots, slotName, normalizeProps(guardReactiveProps(slotProps)))];
        })
      };
    })]),
    1040
    /* FULL_PROPS, DYNAMIC_SLOTS */
  );
}
var pc = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);

export { pc as default };
