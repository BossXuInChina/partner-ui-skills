import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  viewBox: "0 0 8 8",
  xmlns: "http://www.w3.org/2000/svg"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "circle",
  {
    cx: "18",
    cy: "8",
    r: "3.5",
    transform: "translate(-14 -4)",
    fill: "#FEE7E8",
    stroke: "#E02128",
    "fill-rule": "evenodd"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = [_hoisted_2];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_3));
}
var ExceptionMiniO = {
  render
};
var exceptionMiniO = function exceptionMiniO2() {
  return svg({
    name: "IconExceptionMiniO",
    component: ExceptionMiniO,
    filledComponent: ExceptionMiniO
  })();
};
export {
  exceptionMiniO as default
};
