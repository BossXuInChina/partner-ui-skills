import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 24 24",
  "xml:space": "preserve"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    class: "sent_svg__st0",
    d: "m2 4 8.9 6.1c.7.5 1.6.5 2.3 0L22.1 4"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    class: "sent_svg__st1",
    d: "M21 3H3c-.9 0-2 1.1-2 2v14c0 .9 1.1 2 2 2h9c.5 0 1-.5 1-1s-.5-1-1-1H3V5h18v7c0 .5.5 1 1 1s1-.5 1-1V5c0-.9-1.1-2-2-2z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_4 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    class: "sent_svg__st1",
    d: "m16.9 18.9 4.2-4.2c.4-.4 1-.4 1.4 0 .4.4.4 1 0 1.4L17.7 21c-.4.4-1 .4-1.4 0l-2.8-2.8c-.5-.4-.5-1-.1-1.4.4-.4 1-.4 1.4 0l2.1 2.1z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_5 = [_hoisted_2, _hoisted_3, _hoisted_4];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_5));
}
var Sent = {
  render
};
var sent = function sent2() {
  return svg({
    name: "IconSent",
    component: Sent,
    filledComponent: Sent
  })();
};
export {
  sent as default
};
