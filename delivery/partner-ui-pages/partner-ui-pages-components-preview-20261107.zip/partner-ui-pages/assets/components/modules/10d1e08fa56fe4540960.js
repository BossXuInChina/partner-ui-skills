import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  viewBox: "0 0 24 24",
  xmlns: "http://www.w3.org/2000/svg"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "g",
  {
    "fill-rule": "nonzero"
  },
  [/* @__PURE__ */ createElementVNode("path", {
    d: "M18.52 7.879a1 1 0 0 0-1.32-.084l-.093.084-6.365 6.363-3.535-3.535a1 1 0 0 0-1.497 1.32l.083.094 4.243 4.243a1 1 0 0 0 1.32.083l.094-.083 7.07-7.071a1 1 0 0 0 0-1.414Z",
    fill: "#FFF"
  }), /* @__PURE__ */ createElementVNode("path", {
    d: "M19 2a3 3 0 0 1 3 3v14a3 3 0 0 1-3 3H5a3 3 0 0 1-3-3V5a3 3 0 0 1 3-3h14Zm-.48 5.879a1 1 0 0 0-1.32-.084l-.093.084-6.365 6.363-3.535-3.535a1 1 0 0 0-1.497 1.32l.083.094 4.243 4.243a1 1 0 0 0 1.32.083l.094-.083 7.07-7.071a1 1 0 0 0 0-1.414Z"
  })],
  -1
  /* HOISTED */
);
var _hoisted_3 = [_hoisted_2];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_3));
}
var MobileCheckboxSelected = {
  render
};
var mobileCheckboxSelected = function mobileCheckboxSelected2() {
  return svg({
    name: "IconMobileCheckboxSelected",
    component: MobileCheckboxSelected,
    filledComponent: MobileCheckboxSelected
  })();
};
export {
  mobileCheckboxSelected as default
};
