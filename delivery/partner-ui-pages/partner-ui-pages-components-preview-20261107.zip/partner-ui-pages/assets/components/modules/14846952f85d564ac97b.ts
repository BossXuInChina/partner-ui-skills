import { defineComponent as _defineComponent } from 'vue'
import { renderSlot as _renderSlot } from "vue"

import { ActionGroupItemProps } from './index.type'


const __sfc_main__ = /*@__PURE__*/_defineComponent({
  __name: 'ActionGroupItem',
  props: {
    name: {},
    label: {}
  },
  setup(__props: any) {



return (_ctx: any,_cache: any) => {
  return _renderSlot(_ctx.$slots, "default")
}
}

})
export default /* @__PURE__ */ Object.assign(__sfc_main__,{});