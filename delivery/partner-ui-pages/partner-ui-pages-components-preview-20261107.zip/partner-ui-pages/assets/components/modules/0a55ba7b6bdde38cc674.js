import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  viewBox: "0 0 16 16",
  xmlns: "http://www.w3.org/2000/svg"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    d: "M8.54 2.6c0-.28-.22-.5-.5-.5s-.5.22-.5.5v8.359l-2.02-2.01c-.19-.199-.51-.199-.71 0-.19.19-.19.51 0 .701l2.83 2.83c.2.2.51.2.71 0l2.83-2.83a.502.502 0 0 0 0-.7l-.07-.061a.492.492 0 0 0-.64.06l-1.93 1.93v-8.28ZM14 10.5c.27 0 .5.219.5.5v1.28c0 1.22-1 2.22-2.22 2.22H3.71c-1.22 0-2.21-1-2.21-2.22V11a.501.501 0 0 1 1 0v1.28c0 .67.54 1.22 1.21 1.22h8.57c.67 0 1.22-.55 1.22-1.22V11c0-.281.22-.5.5-.5Z",
    "clip-rule": "evenodd",
    "fill-rule": "evenodd"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = [_hoisted_2];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_3));
}
var Download = {
  render
};
var download = function download2() {
  return svg({
    name: "IconDownload",
    component: Download,
    filledComponent: Download
  })();
};
export {
  download as default
};
