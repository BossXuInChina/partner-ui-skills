import { renderless, api } from '@opentiny/vue-renderless/currency/vue';
import { defineComponent, props, setup } from '@opentiny/vue-common';
import SelectMobile from '@opentiny/vue-select-mobile';
import { resolveComponent, openBlock, createBlock, mergeProps } from 'vue';

function _createForOfIteratorHelperLoose(r, e) {
  var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (t) return (t = t.call(r)).next.bind(t);
  if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
    t && (r = t);
    var o = 0;
    return function() {
      return o >= r.length ? { done: true } : { done: false, value: r[o++] };
    };
  }
  throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return _arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
  }
}
function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}
var _export_sfc = function _export_sfc2(sfc, props) {
  var target = sfc.__vccOpts || sfc;
  for (var _iterator = _createForOfIteratorHelperLoose(props), _step; !(_step = _iterator()).done; ) {
    var _step$value = _step.value, key = _step$value[0], val = _step$value[1];
    target[key] = val;
  }
  return target;
};

var _sfc_main = defineComponent({
  inheritAttrs: false,
  components: {
    TinySelectMobile: SelectMobile
  },
  emits: ["update:modelValue", "change", "clear", "visible-change", "update:visible"],
  props: [].concat(props, ["visible", "modelValue", "title", "mode", "multiple", "searchConfig", "fetchCurrency", "fields", "placeholder", "currency"]),
  setup: function setup$1(props2, context) {
    return setup({
      props: props2,
      context,
      renderless,
      api
    });
  }
});
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_tiny_select_mobile = resolveComponent("tiny-select-mobile");
  return openBlock(), createBlock(_component_tiny_select_mobile, mergeProps({
    "data-tag": "tiny-currency"
  }, _ctx.a(_ctx.$attrs, ["^on[A-Z]"]), {
    mode: _ctx.mode,
    "model-value": _ctx.state.selectedValue,
    "onUpdate:modelValue": _cache[0] || (_cache[0] = function($event) {
      return _ctx.$emit("update:modelValue", $event);
    }),
    menus: _ctx.state.options,
    "value-field": "value",
    "text-field": "label",
    title: _ctx.title || _ctx.t("ui.currency.chooseCurrency"),
    placeholder: _ctx.placeholder,
    multiple: _ctx.multiple,
    visible: _ctx.visible,
    "search-config": _ctx.state.searchConfig,
    "onUpdate:visible": _ctx.visibleChange
  }), null, 16, ["mode", "model-value", "menus", "title", "placeholder", "multiple", "visible", "search-config", "onUpdate:visible"]);
}
var mobileFirst = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);

export { mobileFirst as default };
