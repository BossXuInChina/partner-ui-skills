const freeGlobal = typeof global === "object" && global !== null && global.Object === Object && global;
const freeGlobalThis = typeof globalThis === "object" && globalThis !== null && globalThis.Object == Object && globalThis;
const freeSelf = typeof self === "object" && self !== null && self.Object === Object && self;
const root = freeGlobalThis || freeGlobal || freeSelf || new Function("return this")();
function compareArray(arr1, arr2) {
  if (arr1.length !== arr2.length) {
    return false;
  }
  for (let i = 0; i < arr1.length; i++) {
    if (arr1[i] !== arr2[i]) {
      return false;
    }
  }
  return true;
}
function compareObject(object1, object2) {
  const o1keys = Object.keys(object1);
  const o2keys = Object.keys(object2);
  if (o2keys.length !== o1keys.length) return false;
  for (let i = 0; i <= o1keys.length - 1; i++) {
    const key = o1keys[i];
    if (!o2keys.includes(key)) return false;
    if (!compare(object2[key], object1[key])) return false;
  }
  return true;
}
function compare(value, other) {
  if (value === other) {
    return true;
  }
  if (Array.isArray(value) && Array.isArray(other)) {
    return compareArray(value, other);
  }
  if (value instanceof Function || other instanceof Function) {
    return false;
  }
  if (value instanceof Object && other instanceof Object) {
    return compareObject(value, other);
  }
  return false;
}
function unshiftString(str, targetLength, addString) {
  targetLength = targetLength > 0 ? targetLength : 0;
  addString = String(typeof addString !== "undefined" && typeof addString !== "object" ? addString : " ");
  str = str === void 0 || str === null ? "" : String(str);
  if (str.length >= targetLength) {
    return String(str);
  } else {
    targetLength = targetLength - str.length;
    if (targetLength > addString.length) {
      addString += addString.repeat(targetLength / addString.length);
    }
    return addString.slice(0, targetLength) + String(str);
  }
}
export {
  compare,
  compareArray,
  compareObject,
  root,
  unshiftString
};
//# sourceMappingURL=method.es.js.map
