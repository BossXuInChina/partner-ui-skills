import { renderless, api } from '@opentiny/vue-renderless/image/vue';
import { defineComponent, Teleport, props, setup } from '@opentiny/vue-common';
import ImageViewer from '@opentiny/vue-image-viewer';
import imageError from '@opentiny/vue-theme/images/image-error.jpg';
import { resolveComponent, openBlock, createElementBlock, normalizeClass, normalizeStyle, renderSlot, createElementVNode, mergeProps, createBlock, Teleport as Teleport$1, withCtx, createCommentVNode } from 'vue';

function _createForOfIteratorHelperLoose(r, e) {
  var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (t) return (t = t.call(r)).next.bind(t);
  if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
    t && (r = t);
    var o = 0;
    return function() {
      return o >= r.length ? { done: true } : { done: false, value: r[o++] };
    };
  }
  throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return _arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
  }
}
function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}
var _export_sfc = function _export_sfc2(sfc, props) {
  var target = sfc.__vccOpts || sfc;
  for (var _iterator = _createForOfIteratorHelperLoose(props), _step; !(_step = _iterator()).done; ) {
    var _step$value = _step.value, key = _step$value[0], val = _step$value[1];
    target[key] = val;
  }
  return target;
};

var _sfc_main = defineComponent({
  components: {
    ImageViewer,
    Teleport
  },
  emits: ["load", "error", "delete", "change-index"],
  props: [].concat(props, ["src", "fit", "lazy", "scrollContainer", "previewSrcList", "zIndex", "showIndex", "showHover", "previewVisible", "round", "imageSize", "keepStyle", "appendToBody"]),
  setup: function setup$1(props2, context) {
    return setup({
      props: props2,
      context,
      renderless,
      api,
      extendOptions: {
        images: {
          imageError
        }
      }
    });
  }
});
var _hoisted_1 = /* @__PURE__ */ createElementVNode(
  "div",
  {
    class: "w-full h-full"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_2 = ["src"];
var _hoisted_3 = ["src"];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_image_viewer = resolveComponent("image-viewer");
  return openBlock(), createElementBlock(
    "div",
    {
      "data-tag": "tiny-image",
      class: normalizeClass(["relative inline-block overflow-hidden w-full rounded", {
        "rounded-full": _ctx.round
      }]),
      style: normalizeStyle({
        "width": (!_ctx.lazy ? _ctx.imageSize : "") + "px",
        "height": (!_ctx.lazy ? _ctx.imageSize : "") + "px"
      })
    },
    [_ctx.state.loading ? renderSlot(_ctx.$slots, "placeholder", {
      key: 0,
      dataTag: "tiny-image-loading"
    }, function() {
      return [_hoisted_1];
    }) : _ctx.state.error ? renderSlot(_ctx.$slots, "error", {
      key: 1,
      dataTag: "tiny-image-error"
    }, function() {
      return [createElementVNode("img", {
        class: "flex justify-center items-center text-sm align-middle text-color-bg-3 bg-no-repeat bg-center",
        src: _ctx.state.images.imageError,
        alt: ""
      }, null, 8, _hoisted_2)];
    }) : (openBlock(), createElementBlock("img", mergeProps({
      key: 2
    }, _ctx.$attrs, {
      onClick: _cache[0] || (_cache[0] = function() {
        return _ctx.clickHandler && _ctx.clickHandler.apply(_ctx, arguments);
      }),
      src: _ctx.state.src,
      style: _ctx.state.getImageStyle,
      class: ["align-top w-full h-full rounded cursor-pointer", {
        "relative left-1/2 top-1/2 -translate-y-1/2 -translate-x-1/2 block": _ctx.state.getAlignCenter
      }]
    }), null, 16, _hoisted_3)), createElementVNode(
      "div",
      {
        "data-tag": "tiny-image-showhover",
        class: normalizeClass(["inline-block w-full h-full hover:bg-color-text-disabled absolute top-0 left-0 cursor-pointer", _ctx.showHover ? "block" : "hidden"])
      },
      null,
      2
      /* CLASS */
    ), (openBlock(), createBlock(Teleport$1, {
      disabled: !_ctx.appendToBody,
      to: "body"
    }, [_ctx.state.getPreview && _ctx.state.showViewer ? (openBlock(), createBlock(_component_image_viewer, {
      key: 0,
      "z-index": _ctx.zIndex,
      "on-switch": _ctx.handleSwitch,
      "on-close": _ctx.closeViewer,
      "url-list": _ctx.previewSrcList,
      "show-index": _ctx.showIndex,
      "keep-style": _ctx.keepStyle,
      onDelete: _ctx.deleteHander
    }, {
      count: withCtx(function(slotScoped) {
        return [renderSlot(_ctx.$slots, "count", {
          index: slotScoped.index
        })];
      }),
      _: 3
      /* FORWARDED */
    }, 8, ["z-index", "on-switch", "on-close", "url-list", "show-index", "keep-style", "onDelete"])) : createCommentVNode("v-if", true)], 8, ["disabled"]))],
    6
    /* CLASS, STYLE */
  );
}
var mobileFirst = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);

export { mobileFirst as default };
