import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createStaticVNode } from "vue";
var _hoisted_1 = {
  viewBox: "0 0 155 126",
  xmlns: "http://www.w3.org/2000/svg"
};
var _hoisted_2 = /* @__PURE__ */ createStaticVNode('<g fill="none" fill-rule="evenodd"><path d="M0 0h155v126H0z"></path><g fill-rule="nonzero"><g transform="translate(83.562 20.562)"><path d="M58.876 55.25v26.94c0 .465-.189.887-.494 1.192a1.68 1.68 0 0 1-1.192.494H1.686a1.68 1.68 0 0 1-1.192-.494A1.68 1.68 0 0 1 0 82.19V55.25h58.876Z" stroke="#818181" stroke-width="1.124" fill="var(--tv-color-no-data-gary-2, #FFFFFF)"></path><path stroke="#818181" stroke-width="1.124" fill="var(--tv-color-no-data-gary-2, #FFFFFF)" d="M0 27.625h58.876v28.626H0z"></path><path d="M57.19 0c.465 0 .887.189 1.192.494.305.305.494.727.494 1.192v26.94H0V1.686C0 1.221.189.8.494.494A1.68 1.68 0 0 1 1.686 0H57.19Z" stroke="#818181" stroke-width="1.124" fill="var(--tv-color-no-data-gary-2, #FFFFFF)"></path><circle fill="#1467FF" cx="44.938" cy="13.938" r="2.5"></circle><circle fill="var(--tv-color-no-data-gary-1, #F0F0F0)" cx="44.938" cy="41.938" r="2.5"></circle><circle fill="var(--tv-color-no-data-gary-1, #F0F0F0)" cx="44.938" cy="69.938" r="2.5"></circle><path fill="var(--tv-color-no-data-gary-1, #F0F0F0)" d="M17.438 13.438h21v1h-21zM17.438 41.438h21v1h-21zM17.438 69.438h21v1h-21z"></path></g><path d="M3.444 104.021h147.112a.444.444 0 1 1 0 .888H3.444a.444.444 0 0 1 0-.888Z" fill="#818181"></path><g stroke="#818181" stroke-width=".964"><path d="M109.414 31.482c.931 0 1.775.377 2.385.988.61.61.988 1.454.988 2.385v61.014H14.213V34.855c0-.931.378-1.775.988-2.385a3.363 3.363 0 0 1 2.385-.988h91.828Z" fill="var(--tv-color-no-data-gary-1, #F0F0F0)"></path><path d="m120.036 95.871.482 4.324a4.31 4.31 0 0 1-1.266 3.057 4.31 4.31 0 0 1-3.057 1.266H10.805a4.31 4.31 0 0 1-3.057-1.266 4.31 4.31 0 0 1-1.266-3.057v-3.842l113.554-.482Z" fill="var(--tv-color-no-data-gary-2, #FFFFFF)"></path><path d="m78.817 95.871-.537 2.004a1.182 1.182 0 0 1-1.143.877H50.829a1.182 1.182 0 0 1-1.143-.877l-.537-2.004h29.668Z" fill="var(--tv-color-no-data-gary-1, #F0F0F0)"></path><path d="M106.512 35.326c.665 0 1.268.27 1.704.706.436.436.705 1.038.705 1.703V95.87H18.08V37.735c0-.665.27-1.267.705-1.703a2.402 2.402 0 0 1 1.704-.706h86.024Z" fill="var(--tv-color-no-data-gary-2, #FFFFFF)"></path></g><path d="M43.86 53.611c-6.892 0-12.5 5.608-12.5 12.5 0 6.893 5.608 12.5 12.5 12.5s12.5-5.607 12.5-12.5c0-6.892-5.608-12.5-12.5-12.5" fill="#1467FF"></path><path d="M44.195 59.714c.531 0 .962.431.962.963v7.547a.963.963 0 1 1-1.925 0v-7.547c0-.532.431-.963.963-.963M44.195 73.524a1.284 1.284 0 1 1 0-2.567 1.284 1.284 0 0 1 0 2.567" fill="#FFF"></path><g fill="#818181"><path d="M66.857 52.143h4.837a.48.48 0 0 1 0 .96h-4.837a.48.48 0 1 1 0-.96ZM77.487 52.143h17.668a.48.48 0 1 1 0 .96H77.487a.48.48 0 1 1 0-.96ZM66.857 58.87h28.147a.48.48 0 1 1 0 .961H66.857a.48.48 0 1 1 0-.96ZM66.857 65.597h28.147a.48.48 0 1 1 0 .961H66.857a.48.48 0 1 1 0-.96ZM66.857 72.325h28.147a.48.48 0 1 1 0 .96H66.857a.48.48 0 1 1 0-.96ZM66.857 79.052h4.837a.48.48 0 0 1 0 .961h-4.837a.48.48 0 0 1 0-.961ZM76.04 79.052h7.731v1h-7.73z"></path></g></g></g>', 1);
var _hoisted_3 = [_hoisted_2];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_3));
}
var PageServererror = {
  render
};
var pageServererror = function pageServererror2() {
  return svg({
    name: "IconPageServererror",
    component: PageServererror,
    filledComponent: PageServererror
  })();
};
export {
  pageServererror as default
};
