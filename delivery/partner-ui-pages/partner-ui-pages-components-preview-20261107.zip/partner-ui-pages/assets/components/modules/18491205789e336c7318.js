import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 24 24",
  "xml:space": "preserve"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    class: "refres_svg__st0",
    d: "M12.2 22.9c.5-.1.8-.5.7-1-.1-.5-.5-.8-1-.7-.4.1-.9.1-1.4.1-2.4 0-4.6-1-6.2-2.7S1.7 14.5 1.7 12s.9-4.8 2.6-6.5 3.9-2.7 6.2-2.7 4.6 1 6.2 2.7 2.6 4.1 2.6 6.5v.3l-1.9-2c-.3-.3-.9-.3-1.2 0-.3.3-.3.9 0 1.2l3.2 3.3c.3.3.9.3 1.2 0l3.2-3.3c.3-.3.3-.9 0-1.2-.3-.3-.9-.3-1.2 0L21 11.9c0-1.5-.3-2.9-.8-4.2-.5-1.3-1.3-2.5-2.2-3.5s-2.1-1.8-3.3-2.4c-1.4-.5-2.8-.8-4.2-.8s-2.8.3-4.1.9C5.2 2.4 4 3.2 3.1 4.2c-1 1-1.7 2.2-2.2 3.5C.3 9.1 0 10.5 0 12s.3 2.9.8 4.3c.5 1.3 1.3 2.5 2.2 3.5 1 1 2.1 1.8 3.3 2.4 1.3.6 2.7.9 4.1.9.7-.1 1.2-.1 1.8-.2z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = [_hoisted_2];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_3));
}
var Refres = {
  render
};
var refres = function refres2() {
  return svg({
    name: "IconRefres",
    component: Refres,
    filledComponent: Refres
  })();
};
export {
  refres as default
};
