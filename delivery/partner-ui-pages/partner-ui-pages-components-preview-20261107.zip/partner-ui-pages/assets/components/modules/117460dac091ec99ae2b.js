import { defineComponent, $prefix, setup } from '@opentiny/vue-common';
import { renderless, api } from '@opentiny/vue-renderless/locales/vue';
import { use, zhCN, enUS } from '@opentiny/vue-locale';
import Popover from '@opentiny/vue-popover';
import { IconChevronUp, IconChevronDown } from '@opentiny/vue-icon';
import { resolveComponent, openBlock, createElementBlock, toDisplayString, createBlock, withCtx, createElementVNode, createTextVNode, withDirectives, createVNode, vShow, Fragment, renderList, normalizeClass } from 'vue';
import '@opentiny/vue-theme/locales/index.css';

function _createForOfIteratorHelperLoose(r, e) {
  var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (t) return (t = t.call(r)).next.bind(t);
  if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
    t && (r = t);
    var o = 0;
    return function() {
      return o >= r.length ? { done: true } : { done: false, value: r[o++] };
    };
  }
  throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return _arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
  }
}
function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}
var _export_sfc = function _export_sfc2(sfc, props) {
  var target = sfc.__vccOpts || sfc;
  for (var _iterator = _createForOfIteratorHelperLoose(props), _step; !(_step = _iterator()).done; ) {
    var _step$value = _step.value, key = _step$value[0], val = _step$value[1];
    target[key] = val;
  }
  return target;
};

var _sfc_main = defineComponent({
  name: $prefix + "Locales",
  components: {
    TinyPopover: Popover,
    IconChevronUp: IconChevronUp(),
    IconChevronDown: IconChevronDown()
  },
  props: {
    local: {
      type: Boolean,
      default: false
    },
    changeLang: Function,
    getLocale: Function,
    getDomain: Function,
    getCurrentLocale: Function,
    getChangeLocaleUrl: Function,
    fetchSsoUpdate: Function,
    popperClass: String,
    popperAppendToBody: {
      type: Boolean,
      default: true
    }
  },
  setup: function setup$1(props, context) {
    var constants = {
      GLOBAL: "global"
    };
    return setup({
      props,
      context,
      renderless,
      api,
      mono: true,
      extendOptions: {
        use,
        zhCN,
        enUS,
        constants
      }
    });
  }
});
var _hoisted_1 = {
  class: "tiny-locales"
};
var _hoisted_2 = {
  key: 0
};
var _hoisted_3 = {
  class: "tiny-locales__text"
};
var _hoisted_4 = {
  class: "tiny-locales__icon"
};
var _hoisted_5 = {
  class: "poplist"
};
var _hoisted_6 = ["onClick"];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_IconChevronDown = resolveComponent("IconChevronDown");
  var _component_IconChevronUp = resolveComponent("IconChevronUp");
  var _component_tiny_popover = resolveComponent("tiny-popover");
  return openBlock(), createElementBlock("div", _hoisted_1, [_ctx.state.locales.length === 1 ? (openBlock(), createElementBlock(
    "span",
    _hoisted_2,
    toDisplayString(_ctx.state.text && _ctx.t(_ctx.state.text)),
    1
    /* TEXT */
  )) : _ctx.state.locales.length === 2 ? (openBlock(), createElementBlock(
    "span",
    {
      key: 1,
      onClick: _cache[0] || (_cache[0] = function() {
        return _ctx.switchLanguage && _ctx.switchLanguage.apply(_ctx, arguments);
      })
    },
    toDisplayString(_ctx.state.text && _ctx.t(_ctx.state.text)),
    1
    /* TEXT */
  )) : (openBlock(), createBlock(_component_tiny_popover, {
    key: 2,
    trigger: "hover",
    "visible-arrow": false,
    onShow: _cache[1] || (_cache[1] = function($event) {
      return _ctx.state.visible = true;
    }),
    onHide: _cache[2] || (_cache[2] = function($event) {
      return _ctx.state.visible = false;
    }),
    placement: "bottom-start",
    "popper-class": "tiny-locales__popper" + (_ctx.popperClass ? " " + _ctx.popperClass : ""),
    "append-to-body": _ctx.popperAppendToBody
  }, {
    reference: withCtx(function() {
      return [createElementVNode("span", _hoisted_3, [createTextVNode(
        toDisplayString(_ctx.state.text && _ctx.t(_ctx.state.text)) + " ",
        1
        /* TEXT */
      ), createElementVNode("span", _hoisted_4, [withDirectives(createVNode(
        _component_IconChevronDown,
        null,
        null,
        512
        /* NEED_PATCH */
      ), [[vShow, !_ctx.state.visible]]), withDirectives(createVNode(
        _component_IconChevronUp,
        {
          class: "chevron-up"
        },
        null,
        512
        /* NEED_PATCH */
      ), [[vShow, _ctx.state.visible]])])])];
    }),
    default: withCtx(function() {
      return [createElementVNode("div", _hoisted_5, [(openBlock(true), createElementBlock(
        Fragment,
        null,
        renderList(_ctx.state.locales, function(lang) {
          return openBlock(), createElementBlock("li", {
            key: lang,
            class: normalizeClass({
              selected: _ctx.state.current === lang
            }),
            onClick: function onClick($event) {
              return _ctx.switchLanguage(lang);
            }
          }, toDisplayString(_ctx.t(lang)), 11, _hoisted_6);
        }),
        128
        /* KEYED_FRAGMENT */
      ))])];
    }),
    _: 1
    /* STABLE */
  }, 8, ["popper-class", "append-to-body"]))]);
}
var Locales = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
var version = "3.undefined";
Locales.install = function(Vue) {
  Vue.component(Locales.name, Locales);
};
Locales.version = version;

export { Locales as default };
