import { createVNode, resolveComponent } from "vue";
import { api, renderless } from "@opentiny/vue-renderless/tag/vue";
import { defineComponent, props, setup as _setup, h } from "@opentiny/vue-common";
import { iconClose } from "@opentiny/vue-icon";
var _sfc_main = /* @__PURE__ */ defineComponent({
  components: {
    IconClose: iconClose()
  },
  emits: ["click", "close"],
  props: [].concat(props, [
    "text",
    "closable",
    "type",
    "hit",
    //  hit 只保留类名供aui使用， tinyvue 这边的border是随着规范走，取决于css var中的border色值
    "disabled",
    "color",
    "size",
    "effect",
    "value",
    "beforeDelete",
    "onlyIcon",
    "maxWidth",
    "round"
  ]),
  setup: function setup(props2, context) {
    return _setup({
      props: props2,
      context,
      renderless,
      api,
      h
    });
  },
  render: function render() {
    var type = this.type, size = this.size, hit = this.hit, effect = this.effect, slots = this.slots, closable = this.closable, color = this.color, handleClose = this.handleClose, handleClick = this.handleClick, disabled = this.disabled, state = this.state, value = this.value, onlyIcon = this.onlyIcon, maxWidth = this.maxWidth, round = this.round;
    var styles = {};
    var classes = ["tiny-tag", type ? "tiny-tag--" + type : "", size ? "tiny-tag--" + size : "", effect ? "tiny-tag--" + effect : "", hit && "is-hit", disabled ? "is-disabled" : "", onlyIcon ? "tiny-tag--only-icon" : "", round && "is-round"];
    if (color) {
      if (Array.isArray(color)) {
        styles = {
          background: color[0],
          color: color[1]
        };
      } else if (["red", "orange", "green", "blue", "purple", "brown", "grey", "gold"].includes(color)) {
        classes.push("tiny-tag--" + color);
      } else {
        styles = {
          background: color
        };
      }
    }
    if (maxWidth) {
      styles.maxWidth = maxWidth;
    }
    var tagElement = value || slots.default && slots.default() ? createVNode("span", {
      "data-tag": "tiny-tag",
      "class": classes,
      "style": styles,
      "onClick": handleClick
    }, [value ? createVNode("span", {
      "style": {
        overflow: "hidden",
        textOverflow: "ellipsis",
        whiteSpace: "nowrap"
      }
    }, [value]) : slots.default && createVNode("span", {
      "style": {
        overflow: "hidden",
        textOverflow: "ellipsis",
        whiteSpace: "nowrap"
      }
    }, [slots.default()]), closable && createVNode(resolveComponent("icon-close"), {
      "class": "tiny-svg-size tiny-tag__close",
      "onClick": handleClose
    }, null)]) : createVNode("span", null, null);
    return tagElement;
  }
});
export {
  _sfc_main as default
};
