import "../chunk-G2ADBYYC.js";
import { play, formattedValue, onFinish } from "./index";
const api = ["state", "play", "formattedValue", "onFinish"];
const renderless = (props, { onMounted, computed, reactive }, { emit }) => {
  const api2 = {};
  const state = reactive({
    animating: true,
    value: props.from,
    showValue: computed(() => api2.formattedValue(state, props))
  });
  onMounted(() => {
    if (props.active) {
      api2.play(props, state);
    }
  });
  Object.assign(api2, {
    state,
    play: play({ props, state, api: api2 }),
    formattedValue: formattedValue({ state, props }),
    onFinish: onFinish({ emit, props, state })
  });
  return api2;
};
export {
  api,
  renderless
};
