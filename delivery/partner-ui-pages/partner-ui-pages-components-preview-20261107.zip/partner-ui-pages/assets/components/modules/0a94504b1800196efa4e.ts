const __sfc_main__ = {};
import { renderSlot as _renderSlot, createElementVNode as _createElementVNode, openBlock as _openBlock, createElementBlock as _createElementBlock } from "vue"
import _imports_0 from '../../assets/loading.webp'


const _hoisted_1 = { class: "tr-question__loading-wrapper" }

export function render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock("div", _hoisted_1, [
    _renderSlot(_ctx.$slots, "default", {}, () => [
      _cache[0] || (_cache[0] = _createElementVNode("img", {
        class: "tr-question__loading",
        src: _imports_0
      }, null, -1 /* CACHED */)),
      _cache[1] || (_cache[1] = _createElementVNode("span", { class: "tr-question__loading-text" }, "正在加载", -1 /* CACHED */))
    ])
  ]))
}
export default /* @__PURE__ */ Object.assign(__sfc_main__,{render,__scopeId:"data-v-0a94504b"});