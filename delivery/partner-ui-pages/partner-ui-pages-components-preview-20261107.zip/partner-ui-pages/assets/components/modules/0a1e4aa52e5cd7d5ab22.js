function _extends() {
  return _extends = Object.assign ? Object.assign.bind() : function(n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends.apply(null, arguments);
}
import { defineComponent, $props, $setup, $prefix } from "@opentiny/vue-common";
import PcTemplate from "./pc.js";
import "@opentiny/vue-theme/container/index.css";
var template = function template2(mode) {
  var _process$env;
  typeof process === "object" ? (_process$env = process.env) == null ? void 0 : _process$env.TINY_MODE : null;
  return PcTemplate;
};
var $constants = {
  DEFAULT: "default",
  SIMPLE: "simple",
  LEGEND: "legend",
  CLASSIC: "classic",
  FASHION: "fashion"
};
var Container = defineComponent({
  name: $prefix + "Container",
  props: _extends({}, $props, {
    _constants: {
      type: Object,
      default: function _default() {
        return $constants;
      }
    },
    pattern: {
      type: String,
      default: "default",
      validator: function validator(value) {
        return !!$constants[value.toUpperCase()];
      }
    },
    headerHeight: {
      type: [Number, String],
      default: 60
    },
    asideWidth: {
      type: [Number, String],
      default: 200
    },
    footerHeight: {
      type: [Number, String],
      default: 60
    },
    // mobile
    leftWidth: {
      type: [Number, String],
      default: 60
    },
    rightWidth: {
      type: [Number, String],
      default: 44
    }
  }),
  setup: function setup(props, context) {
    return $setup({
      props,
      context,
      template
    });
  }
});
var version = "3.undefined";
Container.install = function(Vue) {
  Vue.component(Container.name, Container);
};
Container.version = version;
export {
  Container as default
};
