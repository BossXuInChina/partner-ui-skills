import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 16 16",
  style: {
    "enable-background": "new 0 0 16 16"
  },
  "xml:space": "preserve"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "rect",
  {
    style: {
      "fill": "none"
    }
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    class: "up-ward_svg__st1",
    d: "M12.43 10.84a.62.62 0 0 1-.44-.18L8 6.66l-3.99 3.99c-.24.24-.63.24-.88 0s-.24-.63 0-.88l4.43-4.43c.23-.23.64-.23.88 0l4.43 4.43c.24.24.24.63 0 .88-.12.13-.28.19-.44.19z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_4 = [_hoisted_2, _hoisted_3];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_4));
}
var UpWard = {
  render
};
var upWard = function upWard2() {
  return svg({
    name: "IconUpWard",
    component: UpWard,
    filledComponent: UpWard
  })();
};
export {
  upWard as default
};
