import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 576.352 375.897",
  "xml:space": "preserve"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    d: "M525.503 0H50.845C22.805 0 0 21.077 0 46.988v281.92c0 25.912 22.805 46.989 50.845 46.989h474.658c28.019 0 50.849-21.077 50.849-46.989V46.988C576.352 21.077 553.494 0 525.503 0zM33.906 328.908V53.002l149.732 138.33h-.152l-149.58 138.23v-.654zM58.388 31.326h459.548L288.188 243.631 58.388 31.326zm149.108 182.082 80.667 74.554 81.041-74.902L511.57 344.599H65.558l141.938-131.191zm186.192-22.076h-.977l149.732-138.33v275.783L393.688 191.332zm0 0"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = [_hoisted_2];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_3));
}
var MailContent = {
  render
};
var mailContent = function mailContent2() {
  return svg({
    name: "IconMailContent",
    component: MailContent,
    filledComponent: MailContent
  })();
};
export {
  mailContent as default
};
