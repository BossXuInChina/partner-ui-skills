import { renderless, api } from '@opentiny/vue-renderless/option/vue';
import { defineComponent, $prefix, props, setup } from '@opentiny/vue-common';
import { AutoTip } from '@opentiny/vue-directive';
import '@opentiny/vue-theme/option/index.css';
import { IconCheck, IconCheckedSur, IconFinish } from '@opentiny/vue-icon';
import { resolveDirective, withDirectives, openBlock, createElementBlock, withModifiers, normalizeClass, createBlock, resolveDynamicComponent, createCommentVNode, createElementVNode, renderSlot, createTextVNode, toDisplayString, vShow } from 'vue';

function _createForOfIteratorHelperLoose(r, e) {
  var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (t) return (t = t.call(r)).next.bind(t);
  if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
    t && (r = t);
    var o = 0;
    return function() {
      return o >= r.length ? { done: true } : { done: false, value: r[o++] };
    };
  }
  throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return _arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
  }
}
function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}
var _export_sfc = function _export_sfc2(sfc, props) {
  var target = sfc.__vccOpts || sfc;
  for (var _iterator = _createForOfIteratorHelperLoose(props), _step; !(_step = _iterator()).done; ) {
    var _step$value = _step.value, key = _step$value[0], val = _step$value[1];
    target[key] = val;
  }
  return target;
};

var _sfc_main = defineComponent({
  name: $prefix + "Option",
  componentName: "Option",
  directives: {
    AutoTip
  },
  components: {
    IconCheck: IconCheck(),
    IconCheckedSur: IconCheckedSur(),
    IconFinish: IconFinish()
  },
  props: [].concat(props, ["value", "label", "created", "disabled", "events", "visible", "highlightClass", "required", "icon"]),
  setup: function setup$1(props2, context) {
    return setup({
      props: props2,
      context,
      renderless,
      api
    });
  }
});
var _hoisted_1 = ["data-index", "aria-label", "aria-selected"];
var _hoisted_2 = {
  key: 0,
  class: "tiny-option__checkbox-wrap tiny-select-dropdown__item-checkbox"
};
var _hoisted_3 = {
  class: "tiny-option-label"
};
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  var _directive_auto_tip = resolveDirective("auto-tip");
  return withDirectives((openBlock(), createElementBlock("li", {
    ref: "option",
    onMouseenter: _cache[0] || (_cache[0] = function() {
      return _ctx.hoverItem && _ctx.hoverItem.apply(_ctx, arguments);
    }),
    onClick: _cache[1] || (_cache[1] = withModifiers(function() {
      return _ctx.selectOptionClick && _ctx.selectOptionClick.apply(_ctx, arguments);
    }, ["stop"])),
    onMousedown: _cache[2] || (_cache[2] = withModifiers(function() {
    }, ["stop"])),
    "data-tag": "tiny-option",
    "data-index": _ctx.state.index,
    class: normalizeClass(["tiny-option tiny-select-dropdown__item", [{
      selected: _ctx.state.itemSelected,
      "is-disabled": _ctx.disabled || _ctx.state.groupDisabled || _ctx.state.limitReached,
      hover: _ctx.state.hover && !_ctx.state.limitReached,
      "is-required": _ctx.required
    }, _ctx.highlightClass]]),
    role: "option",
    "aria-label": _ctx.state.currentLabel,
    "aria-selected": _ctx.state.itemSelected
  }, [_ctx.state.selectMultiple ? (openBlock(), createElementBlock("span", _hoisted_2, [(openBlock(), createBlock(resolveDynamicComponent("icon-" + _ctx.state.selectCls), {
    class: normalizeClass("tiny-svg-size " + _ctx.state.selectCls)
  }, null, 8, ["class"]))])) : createCommentVNode("v-if", true), _ctx.icon ? (openBlock(), createBlock(resolveDynamicComponent(_ctx.icon), {
    key: 1,
    class: "tiny-option__icon"
  })) : createCommentVNode("v-if", true), createElementVNode(
    "div",
    {
      class: normalizeClass(["tiny-option-wrapper", _ctx.state.selectMultiple ? "calc-width" : "full-width"])
    },
    [renderSlot(_ctx.$slots, "default", {}, function() {
      return [withDirectives((openBlock(), createElementBlock("span", _hoisted_3, [createTextVNode(
        toDisplayString(_ctx.state.currentLabel),
        1
        /* TEXT */
      )])), [[_directive_auto_tip, {
        placement: "right"
      }]])];
    })],
    2
    /* CLASS */
  )], 42, _hoisted_1)), [[vShow, _ctx.visible && _ctx.state.visible]]);
}
var pc = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);

export { pc as default };
