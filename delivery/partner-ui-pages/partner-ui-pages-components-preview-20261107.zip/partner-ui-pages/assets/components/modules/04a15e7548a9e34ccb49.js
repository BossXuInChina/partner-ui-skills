import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 16 16",
  style: {
    "enable-background": "new 0 0 16 16"
  },
  "xml:space": "preserve"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "rect",
  {
    style: {
      "fill": "none"
    }
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    class: "search_svg__st1",
    d: "M7.22 1.67c3.04 0 5.5 2.46 5.5 5.5 0 1.33-.47 2.55-1.25 3.49l2.73 2.69c.19.19.19.51 0 .7s-.51.19-.7 0l-2.73-2.68c-.96.81-2.19 1.3-3.54 1.3-3.04 0-5.5-2.46-5.5-5.5s2.46-5.5 5.49-5.5zm0 1.01a4.5 4.5 0 1 0 0 9 4.5 4.5 0 0 0 0-9z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_4 = [_hoisted_2, _hoisted_3];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_4));
}
var Search = {
  render
};
var search = function search2() {
  return svg({
    name: "IconSearch",
    component: Search,
    filledComponent: Search
  })();
};
export {
  search as default
};
