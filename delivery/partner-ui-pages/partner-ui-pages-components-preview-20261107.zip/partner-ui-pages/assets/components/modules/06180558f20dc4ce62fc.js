import { renderless, api } from '@opentiny/vue-renderless/toggle-menu/vue';
import { defineComponent, props, setup } from '@opentiny/vue-common';
import Input from '@opentiny/vue-input';
import Tree from '@opentiny/vue-tree';
import { iconSearch, iconChevronLeft, iconChevronRight } from '@opentiny/vue-icon';
import { resolveComponent, openBlock, createElementBlock, normalizeClass, createVNode, createElementVNode, createCommentVNode, createBlock, withCtx, resolveDynamicComponent, renderSlot, createTextVNode, toDisplayString } from 'vue';

function _createForOfIteratorHelperLoose(r, e) {
  var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (t) return (t = t.call(r)).next.bind(t);
  if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
    t && (r = t);
    var o = 0;
    return function() {
      return o >= r.length ? { done: true } : { done: false, value: r[o++] };
    };
  }
  throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return _arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
  }
}
function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}
var _export_sfc = function _export_sfc2(sfc, props) {
  var target = sfc.__vccOpts || sfc;
  for (var _iterator = _createForOfIteratorHelperLoose(props), _step; !(_step = _iterator()).done; ) {
    var _step$value = _step.value, key = _step$value[0], val = _step$value[1];
    target[key] = val;
  }
  return target;
};

var _sfc_main = defineComponent({
  props: [].concat(props, ["accordion", "showCheckbox", "defaultCheckedKeys", "automaticFiltering", "data", "ellipsis", "expandOnClickNode", "draggable", "defaultExpandAll", "icon", "placeholder", "props", "showFilter", "wrap", "getMenuDataSync", "getMenuDataAsync"]),
  components: {
    TinyTree: Tree,
    TinyInput: Input,
    TinyIconSearch: iconSearch(),
    TinyIconChevronLeft: iconChevronLeft(),
    TinyIconChevronRight: iconChevronRight()
  },
  setup: function setup$1(props2, context) {
    return setup({
      props: props2,
      context,
      renderless,
      api
    });
  }
});
var _hoisted_1 = {
  key: 0,
  class: "tiny-toggle-menu__filter"
};
var _hoisted_2 = {
  class: "tiny-toggle-menu__filter-search"
};
var _hoisted_3 = {
  class: "tiny-toggle-menu__wrap"
};
var _hoisted_4 = {
  class: "tiny-toggle-menu__link tiny-tree-node__label"
};
var _hoisted_5 = ["title", "onClick"];
var _hoisted_6 = {
  class: "tiny-toggle-menu__name"
};
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_tiny_input = resolveComponent("tiny-input");
  var _component_tiny_icon_search = resolveComponent("tiny-icon-search");
  var _component_tiny_icon_chevron_left = resolveComponent("tiny-icon-chevron-left");
  var _component_tiny_icon_chevron_right = resolveComponent("tiny-icon-chevron-right");
  var _component_tiny_tree = resolveComponent("tiny-tree");
  return openBlock(), createElementBlock(
    "div",
    {
      class: normalizeClass(["tiny-toggle-menu", {
        "is-toggle-right": !_ctx.state.toggleIcon && !_ctx.state.showNode ? true : false
      }])
    },
    [_ctx.showFilter ? (openBlock(), createElementBlock("div", _hoisted_1, [createVNode(_component_tiny_input, {
      placeholder: _ctx.state.placeholder,
      modelValue: _ctx.state.filterText,
      "onUpdate:modelValue": _cache[0] || (_cache[0] = function($event) {
        return _ctx.state.filterText = $event;
      })
    }, null, 8, ["placeholder", "modelValue"]), createElementVNode("span", _hoisted_2, [createVNode(_component_tiny_icon_search, {
      onClick: _ctx.searchNodeText
    }, null, 8, ["onClick"])])])) : createCommentVNode("v-if", true), createElementVNode("div", _hoisted_3, [createElementVNode(
      "div",
      {
        class: normalizeClass(["tiny-toggle-menu__toggle", {
          "tiny-toggle-menu__toggle-right": !_ctx.state.toggleIcon && !_ctx.state.showNode ? true : false
        }]),
        onClick: _cache[1] || (_cache[1] = function() {
          return _ctx.hideNodeText && _ctx.hideNodeText.apply(_ctx, arguments);
        })
      },
      [_ctx.state.toggleIcon ? (openBlock(), createBlock(_component_tiny_icon_chevron_left, {
        key: 0
      })) : (openBlock(), createBlock(_component_tiny_icon_chevron_right, {
        key: 1
      }))],
      2
      /* CLASS */
    ), createVNode(_component_tiny_tree, {
      class: normalizeClass({
        "is-wrap": !_ctx.ellipsis ? _ctx.wrap : false,
        "is-overflow": _ctx.ellipsis,
        "is-node-hide": !_ctx.state.showNode
      }),
      "show-checkbox": _ctx.showCheckbox,
      data: _ctx.state.datas,
      "node-key": "id",
      accordion: _ctx.accordion,
      "default-checked-keys": _ctx.defaultCheckedKeys,
      icon: _ctx.icon,
      props: _ctx.props,
      "default-expand-all": _ctx.defaultExpandAll,
      draggable: _ctx.draggable,
      "expand-on-click-node": _ctx.expandOnClickNode,
      "filter-node-method": _ctx.filterNode,
      onNodeClick: _ctx.nodeClick,
      onNodeExpand: _ctx.nodeExpand,
      onNodeCollapse: _ctx.nodeCollapse,
      onNodeDragEnd: _ctx.nodeDragEnd,
      onNodeDragEnter: _ctx.nodeDragEnter,
      onNodeDragLeave: _ctx.nodeDragLeave,
      onNodeDragOver: _ctx.nodeDragOver,
      onNodeDragStart: _ctx.nodeDragStart,
      onNodeDrop: _ctx.nodeDrop,
      ref: "tree"
    }, {
      default: withCtx(function(_ref) {
        var data = _ref.data;
        return [createElementVNode("div", _hoisted_4, [(openBlock(), createBlock(resolveDynamicComponent(data.icons), {
          class: "tiny-tree-node__expand-icon"
        })), createElementVNode("a", {
          class: "tiny-toggle-menu__body",
          title: data[_ctx.props.label],
          onClick: function onClick($event) {
            return _ctx.clickA(data.url);
          }
        }, [createElementVNode("span", _hoisted_6, [renderSlot(_ctx.$slots, "node", {
          data,
          label: data[_ctx.props.label]
        }, function() {
          return [createTextVNode(
            toDisplayString(data[_ctx.props.label]),
            1
            /* TEXT */
          )];
        })])], 8, _hoisted_5)])];
      }),
      _: 3
      /* FORWARDED */
    }, 8, ["class", "show-checkbox", "data", "accordion", "default-checked-keys", "icon", "props", "default-expand-all", "draggable", "expand-on-click-node", "filter-node-method", "onNodeClick", "onNodeExpand", "onNodeCollapse", "onNodeDragEnd", "onNodeDragEnter", "onNodeDragLeave", "onNodeDragOver", "onNodeDragStart", "onNodeDrop"])])],
    2
    /* CLASS */
  );
}
var pc = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);

export { pc as default };
