import { defineComponent as _defineComponent } from 'vue'
import { unref as _unref, resolveDynamicComponent as _resolveDynamicComponent, normalizeProps as _normalizeProps, guardReactiveProps as _guardReactiveProps, openBlock as _openBlock, createBlock as _createBlock } from "vue"

import { computed } from 'vue'
import { setupBubbleEventFn, useBubbleContentRenderer } from './composables'
import type { BubbleContentRendererProps, BubbleEvent } from './index.type'


const __sfc_main__ = /*@__PURE__*/_defineComponent({
  __name: 'BubbleContentWrapper',
  props: {
    message: {},
    contentIndex: {}
  },
  emits: ["state-change", "bubble-event"],
  setup(__props: any, { emit: __emit }) {

const props = __props

const renderer = useBubbleContentRenderer(() => props.message, props.contentIndex)
const componentProps = computed(() => ({
  ...renderer.value.attributes,
  message: props.message,
  contentIndex: props.contentIndex,
}))

const emit = __emit

const handleBubbleEvent = (event: BubbleEvent) => {
  emit('bubble-event', {
    ...event,
    contentIndex: props.contentIndex,
  })

  if (event.name === 'state:update') {
    const payload = event.payload
    if (
      !payload ||
      typeof payload !== 'object' ||
      !('key' in payload) ||
      typeof payload.key !== 'string' ||
      !('value' in payload)
    ) {
      return
    }

    emit('state-change', {
      key: payload.key,
      value: payload.value,
      contentIndex: props.contentIndex,
    })
  }
}

setupBubbleEventFn(handleBubbleEvent)

return (_ctx: any,_cache: any) => {
  return (_openBlock(), _createBlock(_resolveDynamicComponent(_unref(renderer).renderer), _normalizeProps(_guardReactiveProps(componentProps.value)), null, 16 /* FULL_PROPS */))
}
}

})
export default /* @__PURE__ */ Object.assign(__sfc_main__,{});