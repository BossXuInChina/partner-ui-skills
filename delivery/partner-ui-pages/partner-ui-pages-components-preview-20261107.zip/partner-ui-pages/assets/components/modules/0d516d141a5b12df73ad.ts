import { defineComponent as _defineComponent } from 'vue'
import { renderList as _renderList, Fragment as _Fragment, openBlock as _openBlock, createElementBlock as _createElementBlock, unref as _unref, createVNode as _createVNode, toDisplayString as _toDisplayString, normalizeClass as _normalizeClass, createElementVNode as _createElementVNode, normalizeStyle as _normalizeStyle, createCommentVNode as _createCommentVNode, Transition as _Transition, withCtx as _withCtx, createBlock as _createBlock } from "vue"

const _hoisted_1 = ["onMouseenter", "onClick"]
const _hoisted_2 = { class: "suggestion-list__text" }

import { ref, watch, toRaw } from 'vue'
import { IconAssociate } from '@opentiny/tiny-robot-svgs'
import { processHighlights } from './utils/highlight'
import type { SenderSuggestionItem } from './types'

/**
 * 建议列表组件 Props
 */
export interface Props {
  /**
   * 是否显示
   */
  show: boolean

  /**
   * 建议项列表
   */
  suggestions: SenderSuggestionItem[]

  /**
   * 弹窗样式
   */
  popupStyle: Record<string, string | number>

  /**
   * 键盘选中的索引
   */
  activeKeyboardIndex: number

  /**
   * 鼠标悬停的索引
   */
  activeMouseIndex: number

  /**
   * 用户输入的文本
   */
  inputValue: string

  /**
   * 选择回调函数
   */
  onSelect?: (item: SenderSuggestionItem) => void

  /**
   * 鼠标进入回调函数
   */
  onMouseEnter?: (index: number) => void

  /**
   * 鼠标离开回调函数
   */
  onMouseLeave?: () => void
}


const __sfc_main__ = /*@__PURE__*/_defineComponent({
  __name: 'suggestion-list',
  props: {
    show: { type: Boolean },
    suggestions: {},
    popupStyle: {},
    activeKeyboardIndex: {},
    activeMouseIndex: {},
    inputValue: {},
    onSelect: { type: Function },
    onMouseEnter: { type: Function },
    onMouseLeave: { type: Function }
  },
  setup(__props: any) {

const props = __props

const suggestionsListRef = ref<HTMLElement | null>(null)

/**
 * 检查项是否高亮
 */
const isItemHighlighted = (index: number): boolean => {
  return index === props.activeKeyboardIndex || index === props.activeMouseIndex
}

/**
 * 处理项鼠标进入
 */
const handleItemHover = (index: number) => {
  props.onMouseEnter?.(index)
}

/**
 * 处理项鼠标离开
 */
const handleItemLeave = () => {
  props.onMouseLeave?.()
}

/**
 * 处理项选择
 */
const handleSelect = (index: number) => {
  const item = props.suggestions[index]
  if (item) {
    props.onSelect?.(toRaw(item))
  }
}

/**
 * 监听键盘选中索引变化，自动滚动到视图
 */
watch(
  () => props.activeKeyboardIndex,
  (newIndex) => {
    if (newIndex !== -1 && suggestionsListRef.value) {
      const itemElement = suggestionsListRef.value.children[newIndex] as HTMLElement | undefined
      if (itemElement) {
        itemElement.scrollIntoView({ block: 'nearest' })
      }
    }
  },
)

return (_ctx: any,_cache: any) => {
  return (_openBlock(), _createBlock(_Transition, { name: "suggestion-slide-up" }, {
    default: _withCtx(() => [
      (props.show && props.suggestions.length)
        ? (_openBlock(), _createElementBlock("div", {
            key: 0,
            ref_key: "suggestionsListRef",
            ref: suggestionsListRef,
            class: "suggestion-list",
            style: _normalizeStyle(props.popupStyle)
          }, [
            (_openBlock(true), _createElementBlock(_Fragment, null, _renderList(props.suggestions, (item, index) => {
              return (_openBlock(), _createElementBlock("div", {
                key: index,
                class: _normalizeClass(["suggestion-list__item", { highlighted: isItemHighlighted(index) }]),
                onMouseenter: ($event: any) => (handleItemHover(index)),
                onMouseleave: handleItemLeave,
                onClick: ($event: any) => (handleSelect(index))
              }, [
                _createVNode(_unref(IconAssociate), { class: "suggestion-list__icon" }),
                _createElementVNode("span", _hoisted_2, [
                  (_openBlock(true), _createElementBlock(_Fragment, null, _renderList(_unref(processHighlights)(item, props.inputValue), (part, partIndex) => {
                    return (_openBlock(), _createElementBlock("span", {
                      key: partIndex,
                      class: _normalizeClass({
              'suggestion-list__text--match': part.isMatch,
              'suggestion-list__text--normal': !part.isMatch,
            })
                    }, _toDisplayString(part.text), 3 /* TEXT, CLASS */))
                  }), 128 /* KEYED_FRAGMENT */))
                ])
              ], 42 /* CLASS, PROPS, NEED_HYDRATION */, _hoisted_1))
            }), 128 /* KEYED_FRAGMENT */))
          ], 4 /* STYLE */))
        : _createCommentVNode("v-if", true)
    ]),
    _: 1 /* STABLE */
  }))
}
}

})
export default /* @__PURE__ */ Object.assign(__sfc_main__,{__scopeId:"data-v-0d516d14"});