import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 24 24",
  "xml:space": "preserve"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    class: "delta-right_svg__st0",
    d: "M6 2v20l13-10z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = [_hoisted_2];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_3));
}
var DeltaRight = {
  render
};
var deltaRight = function deltaRight2() {
  return svg({
    name: "IconDeltaRight",
    component: DeltaRight,
    filledComponent: DeltaRight
  })();
};
export {
  deltaRight as default
};
