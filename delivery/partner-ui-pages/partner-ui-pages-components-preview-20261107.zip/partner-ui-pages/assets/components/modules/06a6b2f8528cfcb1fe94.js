import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 24 24",
  "xml:space": "preserve"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    class: "pause_svg__st0",
    d: "M17 4c-.6 0-1 .5-1 1v14c0 .5.5 1 1 1s1-.5 1-1V5c0-.5-.4-1-1-1zM7 4c-.6 0-1 .5-1 1v14c0 .5.5 1 1 1s1-.5 1-1V5c0-.5-.4-1-1-1z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = [_hoisted_2];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_3));
}
var Pause = {
  render
};
var pause = function pause2() {
  return svg({
    name: "IconPause",
    component: Pause,
    filledComponent: Pause
  })();
};
export {
  pause as default
};
