import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 24 24",
  "xml:space": "preserve"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    class: "unknown_svg__st0",
    d: "M12 24C5.4 24 0 18.6 0 12S5.4 0 12 0s12 5.4 12 12-5.4 12-12 12zm4-15.6c.1-1.1-.3-2.2-1-3-.8-.9-1.9-1.4-3-1.4s-2.1.5-2.8 1.3C8.4 6.1 8 7.2 8 8.4c0 .5.4.9.8.9s.8-.4.8-.9c0-1.4 1.1-2.6 2.4-2.6.7 0 1.3.3 1.8.8.4.5.6 1.1.6 1.7 0 .5 0 1-1.5 2.6-.9 1-1.7 2-1.8 3.2 0 .5.3.9.7 1h.1c.4 0 .8-.3.8-.8.1-.6.6-1.2 1.4-2.1 1.5-1.8 1.8-2.7 1.9-3.8zM12 19c.6 0 1-.4 1-1s-.4-1-1-1-1 .4-1 1 .4 1 1 1z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = [_hoisted_2];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_3));
}
var Unknown = {
  render
};
var unknown = function unknown2() {
  return svg({
    name: "IconUnknown",
    component: Unknown,
    filledComponent: Unknown
  })();
};
export {
  unknown as default
};
