import { renderless, api } from '@opentiny/vue-renderless/user-head-group/vue';
import { defineComponent, props, setup } from '@opentiny/vue-common';
import UserHead from '@opentiny/vue-user-head';
import { resolveComponent, openBlock, createElementBlock, normalizeStyle, normalizeClass, Fragment, createElementVNode, createVNode, renderList, toDisplayString } from 'vue';

function _createForOfIteratorHelperLoose(r, e) {
  var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (t) return (t = t.call(r)).next.bind(t);
  if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
    t && (r = t);
    var o = 0;
    return function() {
      return o >= r.length ? { done: true } : { done: false, value: r[o++] };
    };
  }
  throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return _arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
  }
}
function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}
var _export_sfc = function _export_sfc2(sfc, props) {
  var target = sfc.__vccOpts || sfc;
  for (var _iterator = _createForOfIteratorHelperLoose(props), _step; !(_step = _iterator()).done; ) {
    var _step$value = _step.value, key = _step$value[0], val = _step$value[1];
    target[key] = val;
  }
  return target;
};

var _sfc_main = defineComponent({
  components: {
    TinyUserHead: UserHead
  },
  emits: ["click", "mouseenter"],
  props: [].concat(props, ["groupSize", "list", "horizontal", "showMax", "color", "backgroundColor"]),
  setup: function setup$1(props2, context) {
    return setup({
      props: props2,
      context,
      renderless,
      api
    });
  }
});
var _hoisted_1 = {
  "data-tag": "tiny-user-head-group",
  class: "inline-block"
};
var _hoisted_2 = {
  class: "leading-[0] mb-px",
  "data-tag": "tiny-user-head-group-first"
};
var _hoisted_3 = {
  class: "flex items-center justify-around",
  "data-tag": "tiny-user-head-group-center"
};
var _hoisted_4 = {
  key: 1,
  "data-tag": "tiny-user-head-group-nothorizontal",
  class: "flex items-center cursor-pointer"
};
var _hoisted_5 = ["round", "type"];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_tiny_user_head = resolveComponent("tiny-user-head");
  return openBlock(), createElementBlock("div", _hoisted_1, [!_ctx.horizontal ? (openBlock(), createElementBlock(
    "div",
    {
      key: 0,
      style: normalizeStyle({
        "width": _ctx.state.width + "px",
        "min-height": _ctx.state.minHeight + "px"
      }),
      class: normalizeClass([_ctx.state.list.length === 3 ? "block text-center" : "flex items-center justify-around flex-wrap"]),
      "data-tag": "tiny-user-head-group-horizontal"
    },
    [_ctx.state.list.length === 3 ? (openBlock(), createElementBlock(
      Fragment,
      {
        key: 0
      },
      [createElementVNode("div", _hoisted_2, [createVNode(_component_tiny_user_head, {
        "background-color": _ctx.state.list[0].backgroundColor,
        color: _ctx.state.list[0].color,
        round: _ctx.state.list[0].round,
        type: _ctx.state.list[0].type,
        modelValue: _ctx.state.list[0].modelValue,
        "onUpdate:modelValue": _cache[0] || (_cache[0] = function($event) {
          return _ctx.state.list[0].modelValue = $event;
        })
      }, null, 8, ["background-color", "color", "round", "type", "modelValue"])]), createElementVNode("div", _hoisted_3, [(openBlock(true), createElementBlock(
        Fragment,
        null,
        renderList(_ctx.state.list.slice(1, 3), function(item, i) {
          return openBlock(), createElementBlock("div", {
            key: i,
            class: "inline-block leading-[0]"
          }, [createVNode(_component_tiny_user_head, {
            "background-color": item.backgroundColor,
            color: item.color,
            round: item.round,
            type: item.type,
            modelValue: item.modelValue,
            "onUpdate:modelValue": function onUpdateModelValue($event) {
              return item.modelValue = $event;
            }
          }, null, 8, ["background-color", "color", "round", "type", "modelValue", "onUpdate:modelValue"])]);
        }),
        128
        /* KEYED_FRAGMENT */
      ))])],
      64
      /* STABLE_FRAGMENT */
    )) : (openBlock(true), createElementBlock(
      Fragment,
      {
        key: 1
      },
      renderList(_ctx.state.list.slice(0, 4), function(item, i) {
        return openBlock(), createElementBlock("div", {
          "data-tag": "tiny-user-head-group-all",
          key: i,
          class: "leading-[0]"
        }, [createVNode(_component_tiny_user_head, {
          "background-color": item.backgroundColor,
          color: item.color,
          round: item.round,
          type: item.type,
          modelValue: item.modelValue,
          "onUpdate:modelValue": function onUpdateModelValue($event) {
            return item.modelValue = $event;
          }
        }, null, 8, ["background-color", "color", "round", "type", "modelValue", "onUpdate:modelValue"])]);
      }),
      128
      /* KEYED_FRAGMENT */
    ))],
    6
    /* CLASS, STYLE */
  )) : (openBlock(), createElementBlock("div", _hoisted_4, [(openBlock(true), createElementBlock(
    Fragment,
    null,
    renderList(_ctx.state.list.slice(0, _ctx.state.list.length > 4 ? _ctx.showMax ? _ctx.state.list.length > 6 ? 5 : _ctx.state.list.length : 3 : _ctx.state.list.length), function(item, index) {
      return openBlock(), createElementBlock(
        "div",
        {
          "data-tag": "tiny-user-head-group-maxitem",
          key: index,
          style: normalizeStyle({
            "margin-left": index !== 0 && -_ctx.state.horizontalLeft + "px"
          }),
          class: "leading-[0]"
        },
        [createVNode(_component_tiny_user_head, {
          class: "rounded-full border border-color-bg-1 border-solid",
          round: item.round,
          type: item.type,
          modelValue: item.modelValue,
          "onUpdate:modelValue": function onUpdateModelValue($event) {
            return item.modelValue = $event;
          },
          onClick: _ctx.handleClick,
          onMouseenter: _ctx.mouseEnter
        }, null, 8, ["round", "type", "modelValue", "onUpdate:modelValue", "onClick", "onMouseenter"])],
        4
        /* STYLE */
      );
    }),
    128
    /* KEYED_FRAGMENT */
  )), createElementVNode(
    "div",
    {
      "data-tag": "tiny-user-head-group-maxitem",
      style: normalizeStyle({
        "margin-left": -_ctx.state.horizontalLeft + "px"
      }),
      class: normalizeClass(["leading-[0] z-10", _ctx.state.list.length > 4 ? _ctx.showMax ? _ctx.state.list.length <= 6 && "hidden" : "block" : "hidden"])
    },
    [createElementVNode("div", {
      "data-tag": "tiny-user-head-group-size",
      class: "rounded-full border border-color-bg-1 border-solid flex justify-center items-center text-color-text-primary bg-color-border-separator box-content",
      style: normalizeStyle({
        "height": _ctx.groupSize + "px",
        "width": _ctx.groupSize + "px",
        "lineHeight": _ctx.groupSize + "px"
      }),
      round: _ctx.state.list[_ctx.state.list.length - 1].round,
      type: _ctx.state.list[_ctx.state.list.length - 1].type,
      onClick: _cache[1] || (_cache[1] = function() {
        return _ctx.handleClick && _ctx.handleClick.apply(_ctx, arguments);
      }),
      onMouseenter: _cache[2] || (_cache[2] = function() {
        return _ctx.mouseEnter && _ctx.mouseEnter.apply(_ctx, arguments);
      })
    }, toDisplayString("+" + (_ctx.state.list.length - (_ctx.showMax ? 6 : 3))), 45, _hoisted_5)],
    6
    /* CLASS, STYLE */
  )]))]);
}
var mobileFirst = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);

export { mobileFirst as default };
