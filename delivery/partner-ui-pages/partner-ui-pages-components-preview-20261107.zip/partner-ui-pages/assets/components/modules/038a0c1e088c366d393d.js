function _extends() {
  return _extends = Object.assign ? Object.assign.bind() : function(n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends.apply(null, arguments);
}
import { defineComponent, $props, $setup, $prefix } from "@opentiny/vue-common";
import PcTemplate from "./pc.js";
import MobileFirstTemplate from "./mobile-first.js";
import "@opentiny/vue-theme/file-upload/index.css";
var template = function template2(mode) {
  var _process$env;
  var tinyMode = typeof process === "object" ? (_process$env = process.env) == null ? void 0 : _process$env.TINY_MODE : null;
  if ("pc" === (tinyMode || mode)) {
    return PcTemplate;
  }
  if ("mobile-first" === (tinyMode || mode)) {
    return MobileFirstTemplate;
  }
  return PcTemplate;
};
var $constants = {
  FILE_UPLOAD_INNER_TEMPLATE: "file-upload-inner-template",
  UPLOAD_INNER: "upload-inner",
  UPLOAD_INNER_TEMPLATE: "upload-inner-template",
  UPLOAD_LIST_INNER: "upload-list-inner",
  UPLOAD_LIST_INNER_TEMPLATE: "upload-list-inner-template",
  ONLY_SUPPORT: "ui.fileUpload.onlySupport",
  COMMA: "ui.base.comma",
  FILE_NOT_LESS_THAN: "ui.fileUpload.fileNotLessThan",
  FILE_NOT_MORE_THAN: "ui.fileUpload.fileNotMoreThan",
  FILE_SIZE_RANGE: "ui.fileUpload.fileSizeRange",
  NUMBER_LIMIT: "ui.fileUpload.numberLimit",
  FILE_STATUS: {
    READY: "ready",
    SUCESS: "success",
    UPLOADING: "uploading",
    FAIL: "fail",
    DOWNLOADING: "downloading"
  },
  LIST_TYPE: {
    TEXT: "text",
    PICTURE_CARD: "picture-card",
    PICTURE: "picture",
    THUMB: "thumb",
    PICTURE_SINGLE: "picture-single",
    DRAG_SINGLE: "drag-single",
    SAAS: "saas"
  },
  EDM: {
    CHUNKINIT: "chunkInit",
    FILESIZE: "fileSize",
    CHUNKS: "chunks",
    FILENAME: "fileName",
    ISCHECKCODE: "isCheckCode",
    CHECKCODE: "checkCode",
    MULTIPART: "multipartFile",
    DOCID: "docId",
    CHUNK: "chunk",
    SINGLEUPLOAD: "uploadFile",
    LOWERNAME: "filename",
    FOLDERKEY: "ui.fileUpload.folder",
    FORMAT: "docFormat=wm&",
    WATER: "usageScenes=water&wmType=wm&",
    SOURCE: "usageScenes=source&",
    URLCONTS: "&type=doc&pageNum=1&docVersion=",
    EDMTOKEN: "EDM-Authorization",
    TRACEID: "x-trace-id",
    TEXT: "edm-text",
    JSLIB: "./jslib/",
    I18NKEY: "ui.fileUpload.token",
    LARGEFILEKEY: "ui.fileUpload.largefile",
    EXCEED: "ui.fileUpload.exceed",
    SIZE: "ui.fileUpload.fileSize",
    SIZE_17G: 17 * 1024 * 1024,
    SIZE_2G: 2 * 1024 * 1024,
    // 单位（KB）
    SIZE_64M: 64 * 1024,
    SIZE_32M: 32 * 1024,
    SIZE_20M: 20 * 1024,
    SIZE_16M: 16 * 1024,
    SIZE_8M: 8 * 1024,
    SIZE_4M: 4 * 1024,
    SIZE_2M: 2 * 1024,
    SIZE_0M: 0 * 1024,
    FILEEMPTY: "ui.fileUpload.empty",
    KIASCANTIP: "ui.fileUpload.kiaScanTip",
    FILENAMEEXCEEDS: "ui.fileUpload.fileNameExceeds",
    THEFILENAME: "ui.fileUpload.fileName",
    CALCHASH: "ui.fileUpload.calcHash",
    KIASTATUS: 12079,
    NumberExceed: "ui.fileUpload.numberExceed",
    notSupport: "ui.fileUpload.notSupport",
    NOT_SUPPORT_NO_SUFFIX: "ui.fileUpload.notSupportNoSuffix",
    STATUS_SPECIAL_CHARACTERS: 11005,
    NOT_SUPPORT_SPECIAL_CHARACTERS: "ui.fileUpload.notSupportSpecialCharacters",
    DOC_PREVIEW: "ui.fileUpload.docPreview"
  },
  IMAGE_TYPE: "image/*",
  FILE_TYPE: {
    EXCEL: "xls/xlsx",
    FILE: "file",
    PDF: "pdf",
    PICTURE: "png/jpg/jpeg/gif/svg/webp/bmp/tif/pjp/apng/xbm/jxl/svgz/ico/tiff/jfif/pjpeg/avif",
    PPT: "ppt/pptx",
    TEXT: "txt",
    WORD: "doc/docx",
    ZIP: "zip/rar/arj/z/jar/lzh",
    VIDEO: "mp4/m4v/3gp/mpg/flv/f4v/swf/avi/wmv/rmvb/mov/mts/m2t/ogg/webm/mkv",
    AUDIO: "mp3/aac/ape/flac/wav/wma/amr/mid/pcm"
  },
  SOURCE_TYPE: {
    SOURCE_VIDEO: "video",
    SOURCE_AUDIO: "audio",
    SOURCE_PICTURE: "picture"
  },
  MODE: {
    BUBBLE: "bubble"
  }
};
var fileUploadProps = _extends({}, $props, {
  _constants: {
    type: Object,
    default: function _default() {
      return $constants;
    }
  },
  accept: String,
  action: String,
  autoUpload: {
    type: Boolean,
    default: function _default2() {
      return true;
    }
  },
  beforeRemove: Function,
  beforeUpload: Function,
  data: Object,
  disabled: Boolean,
  display: {
    type: Boolean,
    default: function _default3() {
      return true;
    }
  },
  drag: Boolean,
  dragger: Boolean,
  edm: {
    type: Object,
    default: function _default4() {
      return {};
    }
  },
  fileIconList: {
    type: Array,
    default: function _default5() {
      return [];
    }
  },
  fileList: {
    type: Array,
    default: function _default6() {
      return [];
    }
  },
  fileSize: {
    type: [Number, Array],
    validator: function validator(value) {
      return Array.isArray(value) ? value[0] < value[1] : typeof value === "number";
    }
  },
  fileTitle: {
    type: String,
    default: function _default7() {
      return "附件";
    }
  },
  headerShow: {
    type: Boolean,
    default: function _default8() {
      return true;
    }
  },
  headers: {
    type: Object,
    default: function _default9() {
      return {};
    }
  },
  httpRequest: Function,
  limit: Number,
  listType: {
    type: String,
    default: function _default10() {
      return "text";
    },
    validator: function validator2(value) {
      return !!$constants.LIST_TYPE[value.toUpperCase().replace("-", "_")];
    }
  },
  mergeService: {
    type: Boolean,
    default: function _default11() {
      return false;
    }
  },
  multiple: Boolean,
  name: {
    type: String,
    default: function _default12() {
      return "file";
    }
  },
  openDownloadFile: {
    type: Boolean,
    default: function _default13() {
      return false;
    }
  },
  showFileList: {
    type: Boolean,
    default: function _default14() {
      return true;
    }
  },
  size: String,
  successStatistics: {
    type: Boolean,
    default: function _default15() {
      return true;
    }
  },
  thumbOption: {
    type: Object,
    default: function _default16() {
      return {
        popperClass: "",
        width: 270,
        showDownload: false,
        downloadFile: Function,
        showDel: false,
        icon: "icon-attachment",
        showTooltip: false
      };
    }
  },
  type: {
    type: String,
    default: function _default17() {
      return "select";
    }
  },
  uploadIcon: {
    type: Boolean,
    default: function _default18() {
      return true;
    }
  },
  withCredentials: {
    type: Boolean,
    default: function _default19() {
      return true;
    }
  },
  isFolderTitle: {
    type: Boolean,
    default: false
  },
  listOption: {
    type: Object,
    default: function _default20() {
      return {
        showUpdate: true,
        showDel: true
      };
    }
  },
  maxNameLength: {
    type: Number,
    default: 0
  },
  scale: {
    type: [Number, String],
    default: 1
  },
  showName: {
    type: Boolean,
    default: false
  },
  sourceType: {
    type: String,
    default: "picture",
    validator: function validator3(val) {
      return val.split("/").every(function(type) {
        return ["picture", "video", "audio"].includes(type);
      });
    }
  },
  showTitle: {
    type: Boolean,
    default: true
  },
  title: {
    type: String,
    default: ""
  },
  displayOnly: {
    type: Boolean,
    default: false
  },
  customClass: [String, Object, Array],
  hwh5: Object,
  mode: {
    type: String,
    default: "",
    validator: function validator4(val) {
      return ["", "bubble"].includes(val);
    }
  },
  cacheToken: {
    type: Boolean,
    default: true
  },
  lockScroll: {
    type: Boolean,
    default: true
  },
  compact: {
    type: Boolean,
    default: false
  },
  beforeAddFile: Function,
  encryptConfig: {
    type: Object,
    default: function _default21() {
      return {
        enabled: false,
        encrypt: false,
        watermark: ""
      };
    }
  },
  promptTip: {
    type: Boolean,
    default: false
  },
  isHidden: {
    type: Boolean,
    default: false
  },
  pasteUpload: {
    type: Boolean,
    default: false
  },
  reUploadable: Boolean,
  reUploadTip: Function,
  imageBgColor: String
  // mobile-first新增
});
var FileUpload = defineComponent({
  name: $prefix + "FileUpload",
  props: fileUploadProps,
  setup: function setup(props, context) {
    return $setup({
      props,
      context,
      template,
      extend: {
        ref: "file-upload-inner-template"
      }
    });
  }
});
var version = "3.undefined";
FileUpload.install = function(Vue) {
  Vue.component(FileUpload.name, FileUpload);
};
FileUpload.version = version;
export {
  FileUpload as default
};
