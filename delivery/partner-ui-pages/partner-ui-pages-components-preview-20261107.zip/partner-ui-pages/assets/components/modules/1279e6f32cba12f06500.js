import { renderless, api } from '@opentiny/vue-renderless/checkbox-group/vue';
import { defineComponent, props, setup } from '@opentiny/vue-common';
import Checkbox from '@opentiny/vue-checkbox';
import CheckboxButton from '@opentiny/vue-checkbox-button';
import '@opentiny/vue-theme/checkbox-group/index.css';
import { resolveComponent, openBlock, createElementBlock, normalizeClass, renderSlot, Fragment, renderList, createBlock, mergeProps, createCommentVNode } from 'vue';

function _createForOfIteratorHelperLoose(r, e) {
  var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (t) return (t = t.call(r)).next.bind(t);
  if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
    t && (r = t);
    var o = 0;
    return function() {
      return o >= r.length ? { done: true } : { done: false, value: r[o++] };
    };
  }
  throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return _arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
  }
}
function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}
var _export_sfc = function _export_sfc2(sfc, props) {
  var target = sfc.__vccOpts || sfc;
  for (var _iterator = _createForOfIteratorHelperLoose(props), _step; !(_step = _iterator()).done; ) {
    var _step$value = _step.value, key = _step$value[0], val = _step$value[1];
    target[key] = val;
  }
  return target;
};

var _sfc_main = /* @__PURE__ */ defineComponent({
  components: {
    Checkbox,
    CheckboxButton
  },
  props: [].concat(props, ["modelValue", "type", "options", "disabled", "min", "max", "size", "fill", "textColor", "vertical", "displayOnly", "shape"]),
  setup: function setup$1(props2, context) {
    return setup({
      props: props2,
      context,
      renderless,
      api
    });
  }
});
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_checkbox = resolveComponent("checkbox");
  var _component_checkbox_button = resolveComponent("checkbox-button");
  return openBlock(), createElementBlock(
    "div",
    {
      class: normalizeClass(["tiny-checkbox-group", _ctx.vertical ? "is-vertical" : ""]),
      role: "group",
      "aria-label": "checkbox-group"
    },
    [renderSlot(_ctx.$slots, "default", {}, function() {
      return [_ctx.type === "checkbox" ? (openBlock(true), createElementBlock(
        Fragment,
        {
          key: 0
        },
        renderList(_ctx.options, function(item, index) {
          return openBlock(), createBlock(
            _component_checkbox,
            mergeProps({
              key: index,
              ref_for: true
            }, item),
            null,
            16
            /* FULL_PROPS */
          );
        }),
        128
        /* KEYED_FRAGMENT */
      )) : createCommentVNode("v-if", true), _ctx.type === "button" ? (openBlock(true), createElementBlock(
        Fragment,
        {
          key: 1
        },
        renderList(_ctx.options, function(item, index) {
          return openBlock(), createBlock(
            _component_checkbox_button,
            mergeProps({
              key: index,
              ref_for: true
            }, item),
            null,
            16
            /* FULL_PROPS */
          );
        }),
        128
        /* KEYED_FRAGMENT */
      )) : createCommentVNode("v-if", true)];
    })],
    2
    /* CLASS */
  );
}
var pc = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);

export { pc as default };
