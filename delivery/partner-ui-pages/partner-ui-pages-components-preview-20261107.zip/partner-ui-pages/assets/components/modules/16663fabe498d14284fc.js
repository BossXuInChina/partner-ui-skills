import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 24 24",
  "xml:space": "preserve"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    class: "select_svg__st0",
    d: "M21 1H3c-.9 0-2 1.1-2 2v18c0 .9 1.1 2 2 2h12c.5 0 1-.5 1-1s-.5-1-1-1H3V3h18v12c0 .5.5 1 1 1s1-.5 1-1V3c0-.9-1.1-2-2-2z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    class: "select_svg__st0",
    d: "M17 12h-3.5l7.2 7.3c.4.4.4 1 0 1.4-.4.4-1 .4-1.4 0L12 13.3V17c0 .6-.4 1-1 1s-1-.4-1-1v-6c0-.6.4-1 1-1h6c.5 0 1 .4 1 1s-.4 1-1 1z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_4 = [_hoisted_2, _hoisted_3];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_4));
}
var Select = {
  render
};
var select = function select2() {
  return svg({
    name: "IconSelect",
    component: Select,
    filledComponent: Select
  })();
};
export {
  select as default
};
