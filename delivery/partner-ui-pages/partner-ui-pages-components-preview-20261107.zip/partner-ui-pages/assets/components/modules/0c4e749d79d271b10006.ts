import { defineComponent as _defineComponent } from 'vue'
import { normalizeProps as _normalizeProps, guardReactiveProps as _guardReactiveProps, renderSlot as _renderSlot, toDisplayString as _toDisplayString, createTextVNode as _createTextVNode, unref as _unref, openBlock as _openBlock, createElementBlock as _createElementBlock } from "vue"

import { computed } from 'vue'
import { useLayoutAsideContext } from './composables/useLayoutContext'
import type { LayoutAsideToggleProps } from './index.type'


const __sfc_main__ = /*@__PURE__*/_defineComponent({
  ...{
  name: 'LayoutAsideToggle',
},
  __name: 'LayoutAsideToggle',
  props: {
    side: {}
  },
  setup(__props: any) {



const props = __props

const { isOpen, toggle } = useLayoutAsideContext(props.side)

const slotProps = computed(() => ({
  isOpen: isOpen.value,
}))

const fallbackTexts = {
  left: {
    expanded: 'Collapse navigation',
    collapsed: 'Expand navigation',
  },
  right: {
    expanded: 'Hide side panel',
    collapsed: 'Show side panel',
  },
} as const

const fallbackText = computed(() => {
  const text = fallbackTexts[props.side]
  return isOpen.value ? text.expanded : text.collapsed
})

return (_ctx: any,_cache: any) => {
  return (_openBlock(), _createElementBlock("button", {
    class: "tr-layout-aside-toggle",
    type: "button",
    onClick: _cache[0] || (_cache[0] = 
//@ts-ignore
(...args) => (_unref(toggle) && _unref(toggle)(...args)))
  }, [
    _renderSlot(_ctx.$slots, "default", _normalizeProps(_guardReactiveProps(slotProps.value)), () => [
      _createTextVNode(_toDisplayString(fallbackText.value), 1 /* TEXT */)
    ])
  ]))
}
}

})
export default /* @__PURE__ */ Object.assign(__sfc_main__,{__scopeId:"data-v-0c4e749d"});