import { renderless, api } from '@opentiny/vue-renderless/user/vue';
import { defineComponent, props, setup } from '@opentiny/vue-common';
import Select from '@opentiny/vue-select';
import Option from '@opentiny/vue-option';
import { iconUser, iconGroup } from '@opentiny/vue-icon';
import { resolveComponent, openBlock, createElementBlock, normalizeClass, createVNode, mergeProps, createSlots, withCtx, createElementVNode, createBlock, Fragment, renderList, renderSlot, toDisplayString } from 'vue';

function _createForOfIteratorHelperLoose(r, e) {
  var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (t) return (t = t.call(r)).next.bind(t);
  if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
    t && (r = t);
    var o = 0;
    return function() {
      return o >= r.length ? { done: true } : { done: false, value: r[o++] };
    };
  }
  throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return _arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
  }
}
function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}
var _export_sfc = function _export_sfc2(sfc, props) {
  var target = sfc.__vccOpts || sfc;
  for (var _iterator = _createForOfIteratorHelperLoose(props), _step; !(_step = _iterator()).done; ) {
    var _step$value = _step.value, key = _step$value[0], val = _step$value[1];
    target[key] = val;
  }
  return target;
};

var _sfc_main = defineComponent({
  components: {
    TinySelect: Select,
    TinyOption: Option,
    IconUser: iconUser(),
    IconGroup: iconGroup()
  },
  inheritAttrs: false,
  emits: ["blur", "focus", "change", "error", "visible-change", "update:modelValue"],
  props: [].concat(props, ["modelValue", "multiple", "size", "displayOnly", "disabled", "sortable", "valueSplit", "textSplit", "valueField", "textField", "collapseTags", "hoverExpand", "showOverflowTooltip", "placeholder", "cache", "delay", "suggestLength", "cacheFields", "cacheKey", "UserCache", "fetchW3Accounts", "fetchUserByUserId", "fetchSuggestUser", "sortByFetchData", "popperClass", "popperAppendToBody", "tabindex", "tagSelectable", "copyable", "batch", "allowCopy", "noDataText", "loadingText", "autoClose", "queryDebounce", "hideSelected", "ignoreEnter", "showTips", "maxWidth", "keepFocus", "changeCompat", "multiLineDrag", "multipleLimit", "autoSelect", "showEmptyValue", "showTooltip"]),
  setup: function setup$1(props2, context) {
    return setup({
      props: props2,
      context,
      renderless,
      api
    });
  }
});
var _hoisted_1 = {
  class: "tiny-user_select left"
};
var _hoisted_2 = {
  class: "tiny-user_select right"
};
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_icon_group = resolveComponent("icon-group");
  var _component_icon_user = resolveComponent("icon-user");
  var _component_tiny_option = resolveComponent("tiny-option");
  var _component_tiny_select = resolveComponent("tiny-select");
  return openBlock(), createElementBlock(
    "div",
    {
      class: normalizeClass(["tiny-user", _ctx.multiLineDrag ? "draggableClass" : ""]),
      onMouseover: _cache[3] || (_cache[3] = function() {
        return _ctx.useSortable && _ctx.useSortable.apply(_ctx, arguments);
      })
    },
    [createVNode(_component_tiny_select, mergeProps({
      ref: "select",
      "popper-class": "tiny-user" + (_ctx.popperClass ? " " + _ctx.popperClass : ""),
      "popper-append-to-body": _ctx.popperAppendToBody,
      onBlur: _ctx.handleBlur,
      onFocus: _cache[0] || (_cache[0] = function($event) {
        return _ctx.$emit("focus", $event);
      }),
      class: "tiny-user__select",
      modelValue: _ctx.state.user,
      "onUpdate:modelValue": _cache[1] || (_cache[1] = function($event) {
        return _ctx.state.user = $event;
      })
    }, _ctx.a(_ctx.$attrs, ["^on[A-Z]"]), {
      "display-only": _ctx.displayOnly,
      disabled: _ctx.disabled,
      "show-overflow-tooltip": _ctx.showOverflowTooltip,
      "hide-drop": !_ctx.state.visible,
      size: _ctx.size,
      placeholder: _ctx.placeholder,
      "collapse-tags": _ctx.collapseTags,
      "hover-expand": _ctx.hoverExpand,
      multiple: _ctx.multiple,
      multipleLimit: _ctx.multipleLimit,
      onChange: _ctx.userChange,
      loading: _ctx.state.loading,
      filterable: "",
      clearable: "",
      remote: "",
      "remote-method": _ctx.searchMethod,
      onVisibleChange: _ctx.visibleChange,
      onClear: _cache[2] || (_cache[2] = function($event) {
        return _ctx.$parent.$emit("clear");
      }),
      tabindex: _ctx.tabindex,
      "tag-selectable": _ctx.tagSelectable,
      copyable: _ctx.copyable,
      "allow-copy": _ctx.allowCopy,
      "text-split": _ctx.textSplit,
      "loading-text": _ctx.loadingText,
      "no-data-text": _ctx.noDataText,
      "auto-close": _ctx.autoClose,
      "query-debounce": _ctx.queryDebounce,
      "ignore-enter": _ctx.ignoreEnter,
      "show-tips": _ctx.showTips,
      "keep-focus": _ctx.keepFocus
    }), createSlots({
      prefix: withCtx(function() {
        return [createElementVNode("div", null, [_ctx.multiple ? (openBlock(), createBlock(_component_icon_group, {
          key: 0,
          class: "tiny-svg-size"
        })) : (openBlock(), createBlock(_component_icon_user, {
          key: 1,
          class: "tiny-svg-size"
        }))])];
      }),
      default: withCtx(function() {
        return [(openBlock(true), createElementBlock(
          Fragment,
          null,
          renderList(_ctx.filter(), function(option) {
            return openBlock(), createBlock(_component_tiny_option, {
              class: "tiny-user__select-dropdown",
              title: option[_ctx.state.textField] + (option.dept ? " " + option.dept : ""),
              visible: option._show,
              key: option[_ctx.state.valueField],
              label: option[_ctx.state.textField],
              value: option[_ctx.state.valueField]
            }, {
              default: withCtx(function() {
                return [renderSlot(_ctx.$slots, "options", {
                  slotScope: option
                }, function() {
                  return [createElementVNode(
                    "span",
                    _hoisted_1,
                    toDisplayString(option[_ctx.state.textField]),
                    1
                    /* TEXT */
                  ), createElementVNode(
                    "span",
                    _hoisted_2,
                    toDisplayString(option.dept),
                    1
                    /* TEXT */
                  )];
                })];
              }),
              _: 2
              /* DYNAMIC */
            }, 1032, ["title", "visible", "label", "value"]);
          }),
          128
          /* KEYED_FRAGMENT */
        ))];
      }),
      _: 2
      /* DYNAMIC */
    }, [_ctx.slots.label ? {
      name: "label",
      fn: withCtx(function(_ref) {
        var item = _ref.item;
        return [renderSlot(_ctx.$slots, "label", {
          user: item
        })];
      }),
      key: "0"
    } : void 0]), 1040, ["popper-class", "popper-append-to-body", "onBlur", "modelValue", "display-only", "disabled", "show-overflow-tooltip", "hide-drop", "size", "placeholder", "collapse-tags", "hover-expand", "multiple", "multipleLimit", "onChange", "loading", "remote-method", "onVisibleChange", "tabindex", "tag-selectable", "copyable", "allow-copy", "text-split", "loading-text", "no-data-text", "auto-close", "query-debounce", "ignore-enter", "show-tips", "keep-focus"])],
    34
    /* CLASS, NEED_HYDRATION */
  );
}
var pc = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);

export { pc as default };
