import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  viewBox: "0 0 16 16",
  xmlns: "http://www.w3.org/2000/svg"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    d: "M13.5 12.833a.5.5 0 0 1 .068.996l-.068.004h-11a.5.5 0 0 1-.068-.995l.068-.005h11ZM2.167 5.598c0-.297.358-.446.569-.236l2.26 2.261a.532.532 0 0 1 0 .754l-2.26 2.261a.333.333 0 0 1-.57-.235ZM13.5 9.278a.5.5 0 0 1 .068.995l-.068.005H6.833a.5.5 0 0 1-.068-.995l.068-.005H13.5Zm0-3.556a.5.5 0 0 1 .068.996l-.068.004H6.833a.5.5 0 0 1-.068-.995l.068-.005H13.5Zm0-3.555a.5.5 0 0 1 .068.995l-.068.005h-11a.5.5 0 0 1-.068-.996l.068-.004h11Z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = [_hoisted_2];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_3));
}
var EditorMenuRight = {
  render
};
var editorMenuRight = function editorMenuRight2() {
  return svg({
    name: "IconEditorMenuRight",
    component: EditorMenuRight,
    filledComponent: EditorMenuRight
  })();
};
export {
  editorMenuRight as default
};
