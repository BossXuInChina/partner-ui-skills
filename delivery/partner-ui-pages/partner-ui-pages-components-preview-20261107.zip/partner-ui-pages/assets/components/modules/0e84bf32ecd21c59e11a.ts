import { defineComponent as _defineComponent } from 'vue'
import { unref as _unref, renderSlot as _renderSlot, normalizeProps as _normalizeProps, guardReactiveProps as _guardReactiveProps, withCtx as _withCtx, createSlots as _createSlots, openBlock as _openBlock, createBlock as _createBlock, createCommentVNode as _createCommentVNode, normalizeClass as _normalizeClass, createElementBlock as _createElementBlock } from "vue"

import { SenderProps, SenderEmits } from './index.type'
import { useSenderCore } from './composables/useSenderCore'
import SingleLineLayout from './components/layouts/SingleLineLayout.vue'
import MultiLineLayout from './components/layouts/MultiLineLayout.vue'

export type SenderPropsWithDefaults = typeof props


const __sfc_main__ = /*@__PURE__*/_defineComponent({
  __name: 'index',
  props: {
    modelValue: {},
    defaultValue: {},
    placeholder: { default: '请输入内容...' },
    disabled: { type: Boolean },
    loading: { type: Boolean },
    autofocus: { type: Boolean },
    enterkeyhint: { default: 'send' },
    mode: { default: 'single' },
    autoSize: { type: [Boolean, Object], default: () => ({ minRows: 1, maxRows: 5 }) },
    maxLength: {},
    showWordLimit: { type: Boolean },
    clearable: { type: Boolean },
    hasExternalContent: { type: Boolean, default: false },
    extensions: { default: () => [] },
    size: { default: 'normal' },
    stopText: {},
    defaultActions: {},
    submitType: { default: 'enter' }
  },
  emits: ["update:modelValue", "submit", "focus", "blur", "clear", "cancel", "input"],
  setup(__props: any, { expose: __expose, emit: __emit }) {

const props = __props

const emit = __emit

const { context, expose } = useSenderCore(props, emit)

__expose(expose)

return (_ctx: any,_cache: any) => {
  return (_openBlock(), _createElementBlock("div", {
    class: _normalizeClass([
      'tr-sender',
      `tr-sender--${_unref(context).mode.value}`,
      `tr-sender--${_unref(context).size.value}`,
      {
        'is-auto-switching': _unref(context).isAutoSwitching.value,
        'is-disabled': _unref(context).disabled.value,
      },
    ])
  }, [
    (_unref(context).mode.value === 'single')
      ? (_openBlock(), _createBlock(SingleLineLayout, { key: 0 }, _createSlots({ _: 2 /* DYNAMIC */ }, [
          (_ctx.$slots.header)
            ? {
                name: "header",
                fn: _withCtx(() => [
                  _renderSlot(_ctx.$slots, "header")
                ]),
                key: "0"
              }
            : undefined,
          (_ctx.$slots.prefix)
            ? {
                name: "prefix",
                fn: _withCtx(() => [
                  _renderSlot(_ctx.$slots, "prefix")
                ]),
                key: "1"
              }
            : undefined,
          (_ctx.$slots.content)
            ? {
                name: "content",
                fn: _withCtx((slotProps) => [
                  _renderSlot(_ctx.$slots, "content", _normalizeProps(_guardReactiveProps(slotProps)))
                ]),
                key: "2"
              }
            : undefined,
          (_ctx.$slots['actions-inline'])
            ? {
                name: "actions-inline",
                fn: _withCtx(() => [
                  _renderSlot(_ctx.$slots, "actions-inline")
                ]),
                key: "3"
              }
            : undefined
        ]), 1024 /* DYNAMIC_SLOTS */))
      : (_openBlock(), _createBlock(MultiLineLayout, { key: 1 }, _createSlots({ _: 2 /* DYNAMIC */ }, [
          (_ctx.$slots.header)
            ? {
                name: "header",
                fn: _withCtx(() => [
                  _renderSlot(_ctx.$slots, "header")
                ]),
                key: "0"
              }
            : undefined,
          (_ctx.$slots.prefix)
            ? {
                name: "prefix",
                fn: _withCtx(() => [
                  _renderSlot(_ctx.$slots, "prefix")
                ]),
                key: "1"
              }
            : undefined,
          (_ctx.$slots.content)
            ? {
                name: "content",
                fn: _withCtx((slotProps) => [
                  _renderSlot(_ctx.$slots, "content", _normalizeProps(_guardReactiveProps(slotProps)))
                ]),
                key: "2"
              }
            : undefined,
          (_ctx.$slots.footer)
            ? {
                name: "footer",
                fn: _withCtx(() => [
                  _renderSlot(_ctx.$slots, "footer")
                ]),
                key: "3"
              }
            : undefined,
          (_ctx.$slots['footer-right'])
            ? {
                name: "footer-right",
                fn: _withCtx(() => [
                  _renderSlot(_ctx.$slots, "footer-right")
                ]),
                key: "4"
              }
            : undefined
        ]), 1024 /* DYNAMIC_SLOTS */))
  ], 2 /* CLASS */))
}
}

})
export default /* @__PURE__ */ Object.assign(__sfc_main__,{__scopeId:"data-v-0e84bf32"});