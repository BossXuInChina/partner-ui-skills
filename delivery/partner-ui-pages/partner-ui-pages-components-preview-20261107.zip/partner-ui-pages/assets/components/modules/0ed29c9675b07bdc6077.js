import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  viewBox: "0 0 16 16",
  xmlns: "http://www.w3.org/2000/svg"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    d: "M4.498 8.498c-.644 0-1.166.523-1.166 1.167v2.5c0 .644.522 1.167 1.166 1.167h5.664a1.17 1.17 0 0 0 1.17-1.167v-2.5a1.17 1.17 0 0 0-1.17-1.167ZM1.835 2.672a.5.5 0 0 0-.492.41l-.008.09v9.656a.5.5 0 0 0 .992.09l.008-.09V3.172a.5.5 0 0 0-.5-.5Zm2.663 6.826h5.664a.17.17 0 0 1 .17.167v2.5a.17.17 0 0 1-.17.167H4.498a.167.167 0 0 1-.166-.167v-2.5c0-.092.074-.167.166-.167Zm0-6.83c-.644 0-1.166.523-1.166 1.167v2.5c0 .644.522 1.167 1.166 1.167h8.997a1.17 1.17 0 0 0 1.17-1.167v-2.5a1.17 1.17 0 0 0-1.17-1.167Zm-.006 1h9.003a.17.17 0 0 1 .17.167v2.5a.17.17 0 0 1-.17.167H4.492a.167.167 0 0 1-.167-.167v-2.5c0-.092.075-.167.167-.167Z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = [_hoisted_2];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_3));
}
var EditorAlignLeft = {
  render
};
var editorAlignLeft = function editorAlignLeft2() {
  return svg({
    name: "IconEditorAlignLeft",
    component: EditorAlignLeft,
    filledComponent: EditorAlignLeft
  })();
};
export {
  editorAlignLeft as default
};
