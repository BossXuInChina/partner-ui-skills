import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 24 24"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    d: "M13 20h-2v-7H4v7H2V4h2v7h7V4h2v16Zm9-12v8h1.5v2H22v2h-2v-2h-5.5v-1.34l5-8.66H22Zm-2 3.133L17.19 16H20v-4.867Z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = [_hoisted_2];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_3));
}
var RichTextH4 = {
  render
};
var richTextH4 = function richTextH42() {
  return svg({
    name: "IconRichTextH4",
    component: RichTextH4,
    filledComponent: RichTextH4
  })();
};
export {
  richTextH4 as default
};
