function _extends() {
  return _extends = Object.assign ? Object.assign.bind() : function(n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends.apply(null, arguments);
}
import { defineComponent, $props, $setup, $prefix } from "@opentiny/vue-common";
import PcTemplate from "./pc.js";
import "@opentiny/vue-theme/breadcrumb-item/index.css";
var template = function template2(mode) {
  var _process$env;
  typeof process === "object" ? (_process$env = process.env) == null ? void 0 : _process$env.TINY_MODE : null;
  return PcTemplate;
};
var breadcrumbItemProps = _extends({}, $props, {
  to: Object,
  replace: {
    type: Boolean,
    default: false
  },
  size: {
    type: String,
    default: "",
    validator: function validator(val) {
      return [
        /* 'large', */
        "medium",
        /* 'small', 'mini',  */
        ""
      ].includes(val);
    }
  },
  option: {
    type: Object,
    default: function _default() {
      return {};
    }
  }
});
var BreadcrumbItem = defineComponent({
  name: $prefix + "BreadcrumbItem",
  props: breadcrumbItemProps,
  setup: function setup(props, context) {
    return $setup({
      props,
      context,
      template
    });
  }
});
var version = "3.undefined";
BreadcrumbItem.install = function(Vue) {
  Vue.component(BreadcrumbItem.name, BreadcrumbItem);
};
BreadcrumbItem.version = version;
export {
  BreadcrumbItem as default
};
