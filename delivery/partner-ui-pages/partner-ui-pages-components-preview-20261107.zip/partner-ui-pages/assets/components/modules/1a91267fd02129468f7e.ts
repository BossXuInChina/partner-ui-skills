import { defineComponent as _defineComponent } from 'vue'
import { unref as _unref, renderSlot as _renderSlot, resolveDynamicComponent as _resolveDynamicComponent, mergeProps as _mergeProps, withCtx as _withCtx, openBlock as _openBlock, createBlock as _createBlock } from "vue"

import { useBubbleBoxRenderer } from './composables'
import type { BubbleMessage, BubbleProps } from './index.type'


const __sfc_main__ = /*@__PURE__*/_defineComponent({
  __name: 'BubbleBoxWrapper',
  props: {
    role: {},
    placement: {},
    shape: {},
    messages: {},
    contentIndex: {}
  },
  setup(__props: any) {

const props = __props

const renderer = useBubbleBoxRenderer(() => props.messages, props.contentIndex)

return (_ctx: any,_cache: any) => {
  return (_openBlock(), _createBlock(_resolveDynamicComponent(_unref(renderer).renderer), _mergeProps(_unref(renderer).attributes, {
    "data-role": props.role,
    "data-placement": props.placement,
    "data-shape": props.shape
  }), {
    default: _withCtx(() => [
      _renderSlot(_ctx.$slots, "default")
    ]),
    _: 3 /* FORWARDED */
  }, 16 /* FULL_PROPS */, ["data-role", "data-placement", "data-shape"]))
}
}

})
export default /* @__PURE__ */ Object.assign(__sfc_main__,{});