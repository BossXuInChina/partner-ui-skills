function _extends() {
  return _extends = Object.assign ? Object.assign.bind() : function(n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends.apply(null, arguments);
}
import { defineComponent, $props, $setup, $prefix } from "@opentiny/vue-common";
import PcTemplate from "./pc.js";
import MobileFirstTemplate from "./mobile-first.js";
var template = function template2(mode) {
  var _process$env;
  var tinyMode = typeof process === "object" ? (_process$env = process.env) == null ? void 0 : _process$env.TINY_MODE : null;
  if ("pc" === (tinyMode || mode)) {
    return PcTemplate;
  }
  if ("mobile-first" === (tinyMode || mode)) {
    return MobileFirstTemplate;
  }
  return PcTemplate;
};
var $constants = {
  FORM_ITEM: "FormItem",
  FORM_CHANGE: "form.change",
  CHECKBOX: $prefix + "Checkbox",
  CHECKBOX_GROUP: "CheckboxGroup"
};
var checkboxProps = _extends({}, $props, {
  _constants: {
    type: Object,
    default: function _default() {
      return $constants;
    }
  },
  modelValue: {
    type: [String, Number, Boolean],
    // Tiny新增，因为类型有Boolean类型，所以默认值需要显示设置成 undefined 才可以保持逻辑正确
    default: void 0
  },
  label: {
    type: [String, Number, Boolean],
    default: ""
  },
  indeterminate: Boolean,
  disabled: Boolean,
  checked: Boolean,
  name: String,
  trueLabel: [String, Number],
  falseLabel: [String, Number],
  /*
   * 当indeterminate为真时，为controls提供相关连的checkbox的id，表明元素间的控制关系
   */
  id: String,
  /*
   * 当indeterminate为真时，为controls提供相关连的checkbox的id，表明元素间的控制关系
   */
  controls: {
    type: String,
    default: ""
  },
  border: Boolean,
  size: String,
  text: String,
  customClass: [String, Object, Array],
  validateEvent: {
    type: Boolean,
    default: true
  },
  events: {
    type: Object,
    default: function _default2() {
      return {};
    }
  },
  displayOnly: {
    type: Boolean,
    default: false
  },
  iconPosition: String,
  shape: {
    type: String,
    default: ""
  },
  tabindex: {
    type: String,
    default: "0"
  }
});
var Checkbox = defineComponent({
  name: $prefix + "Checkbox",
  props: checkboxProps,
  setup: function setup(props, context) {
    return $setup({
      props,
      context,
      template
    });
  }
});
var version = "3.undefined";
Checkbox.model = {
  prop: "modelValue",
  event: "update:modelValue"
};
Checkbox.install = function(Vue) {
  Vue.component(Checkbox.name, Checkbox);
};
Checkbox.version = version;
export {
  Checkbox as default
};
