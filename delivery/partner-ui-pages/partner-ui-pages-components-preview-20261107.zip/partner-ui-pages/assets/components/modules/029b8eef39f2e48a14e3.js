function _extends() {
  return _extends = Object.assign ? Object.assign.bind() : function(n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends.apply(null, arguments);
}
import { defineComponent, $props, $setup, $prefix } from "@opentiny/vue-common";
import PcTemplate from "./pc.js";
var template = function template2(mode) {
  var _process$env;
  typeof process === "object" ? (_process$env = process.env) == null ? void 0 : _process$env.TINY_MODE : null;
  return PcTemplate;
};
var $constants = {
  ISCHECKED: "is-checked",
  DROPPANEL: ".tiny-transfer-panel__list",
  TRANSFERPANEL: ".tiny-transfer-panel__item"
};
var transferProps = _extends({}, $props, {
  _constants: {
    type: Object,
    default: function _default() {
      return $constants;
    }
  },
  buttonTexts: {
    type: Array,
    default: function _default2() {
      return [];
    }
  },
  columns: Array,
  leftColumns: Array,
  rightColumns: Array,
  data: {
    type: Array,
    default: function _default3() {
      return [];
    }
  },
  dropConfig: Object,
  filterMethod: Function,
  filterPlaceholder: {
    type: String,
    default: ""
  },
  filterable: Boolean,
  format: {
    type: Object,
    default: function _default4() {
      return {};
    }
  },
  leftDefaultChecked: {
    type: Array,
    default: function _default5() {
      return [];
    }
  },
  modelValue: {
    type: Array,
    default: function _default6() {
      return [];
    }
  },
  pagerOp: {
    type: Object,
    default: function _default7() {
      return {
        mode: "fixed",
        pageVO: {
          currentPage: 1,
          pageSize: 10
        }
      };
    }
  },
  props: {
    type: Object,
    default: function _default8() {
      return {
        label: "label",
        key: "key",
        disabled: "disabled"
      };
    }
  },
  render: Object,
  renderContent: Function,
  renderType: String,
  rightDefaultChecked: {
    type: Array,
    default: function _default9() {
      return [];
    }
  },
  showAllBtn: Boolean,
  showPager: {
    type: Boolean,
    default: false
  },
  targetOrder: {
    type: String,
    default: "original"
  },
  titles: {
    type: Array,
    default: function _default10() {
      return [];
    }
  },
  toLeftDisable: {
    type: Boolean,
    default: true
  },
  toRightDisable: {
    type: Boolean,
    default: true
  },
  treeOp: Object,
  beforeTransfer: Function,
  panelStyle: Object,
  panelBodyStyle: Object,
  panelTableHeight: String
});
var Transfer = defineComponent({
  name: $prefix + "Transfer",
  props: transferProps,
  setup: function setup(props, context) {
    return $setup({
      props,
      context,
      template
    });
  }
});
var version = "3.undefined";
Transfer.model = {
  prop: "modelValue",
  event: "update:modelValue"
};
Transfer.install = function(Vue) {
  Vue.component(Transfer.name, Transfer);
};
Transfer.version = version;
export {
  Transfer as default
};
