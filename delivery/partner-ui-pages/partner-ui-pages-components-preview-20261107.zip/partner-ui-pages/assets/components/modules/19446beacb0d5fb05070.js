import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  viewBox: "0 0 1024 1024",
  xmlns: "http://www.w3.org/2000/svg"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    d: "m408.992 168.992-256 256L131.008 448l21.984 23.008 256 256 46.016-46.016L254.016 480H672c88.16 0 160 71.84 160 160v224h64V640c0-123.04-100.96-224-224-224H253.984l201.024-200.992-46.048-46.048z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = [_hoisted_2];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_3));
}
var Undo = {
  render
};
var undo = function undo2() {
  return svg({
    name: "IconUndo",
    component: Undo,
    filledComponent: Undo
  })();
};
export {
  undo as default
};
