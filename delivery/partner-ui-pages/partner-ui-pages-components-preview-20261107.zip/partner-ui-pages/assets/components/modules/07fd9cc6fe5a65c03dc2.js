import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 24 24",
  "xml:space": "preserve"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    class: "start-circle_svg__st0",
    d: "M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.6 0 12 0zm7.1 19.1c-.9.9-2 1.6-3.2 2.1-1.2.5-2.5.8-3.9.8s-2.7-.3-3.9-.8c-1.2-.5-2.3-1.2-3.2-2.1-.9-.9-1.6-2-2.1-3.2-.5-1.2-.8-2.5-.8-3.9s.3-2.7.8-3.9C3.3 6.9 4 5.8 4.9 4.9c.9-.9 2-1.6 3.2-2.1C9.3 2.3 10.6 2 12 2s2.7.3 3.9.8c1.2.5 2.3 1.2 3.2 2.1.9.9 1.6 2 2.1 3.2.5 1.2.8 2.5.8 3.9s-.3 2.7-.8 3.9c-.5 1.2-1.2 2.3-2.1 3.2zm-2.3-7.4-7-5.6c0-.1-.1-.1-.3-.1-.2 0-.5.2-.5.4v11.1c0 .3.3.5.5.5.1 0 .2 0 .3-.1l7-5.6c.3-.2.3-.4 0-.6z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = [_hoisted_2];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_3));
}
var StartCircle = {
  render
};
var startCircle = function startCircle2() {
  return svg({
    name: "IconStartCircle",
    component: StartCircle,
    filledComponent: StartCircle
  })();
};
export {
  startCircle as default
};
