import { renderless, api } from '@opentiny/vue-renderless/checkbox/vue';
import { defineComponent, props, setup } from '@opentiny/vue-common';
import { iconHalfselect, iconCheckedSur, iconCheck } from '@opentiny/vue-icon';
import { resolveComponent, openBlock, createElementBlock, mergeProps, createElementVNode, normalizeClass, createVNode, withDirectives, withModifiers, vModelCheckbox, renderSlot, createTextVNode, toDisplayString, Fragment, createCommentVNode } from 'vue';

function _createForOfIteratorHelperLoose(r, e) {
  var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (t) return (t = t.call(r)).next.bind(t);
  if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
    t && (r = t);
    var o = 0;
    return function() {
      return o >= r.length ? { done: true } : { done: false, value: r[o++] };
    };
  }
  throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return _arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
  }
}
function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}
var _export_sfc = function _export_sfc2(sfc, props) {
  var target = sfc.__vccOpts || sfc;
  for (var _iterator = _createForOfIteratorHelperLoose(props), _step; !(_step = _iterator()).done; ) {
    var _step$value = _step.value, key = _step$value[0], val = _step$value[1];
    target[key] = val;
  }
  return target;
};

var _sfc_main = defineComponent({
  inheritAttrs: false,
  emits: ["update:modelValue", "change", "complete"],
  props: [].concat(props, ["modelValue", "text", "events", "label", "indeterminate", "disabled", "checked", "name", "trueLabel", "falseLabel", "id", "controls", "size", "border", "validateEvent", "customClass", "displayOnly"]),
  components: {
    IconHalfselect: iconHalfselect(),
    IconCheckedSur: iconCheckedSur(),
    IconCheck: iconCheck()
  },
  setup: function setup$1(props2, context) {
    return setup({
      props: props2,
      context,
      renderless,
      api
    });
  }
});
var _hoisted_1 = ["id", "aria-checked", "aria-disabled", "aria-label"];
var _hoisted_2 = ["role", "aria-checked"];
var _hoisted_3 = {
  tabindex: "1"
};
var _hoisted_4 = ["aria-hidden", "name", "disabled", "true-value", "false-value"];
var _hoisted_5 = ["aria-hidden", "disabled", "value", "name"];
var _hoisted_6 = {
  key: 0,
  class: "text-color-text-primary cursor-default"
};
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_icon_check = resolveComponent("icon-check");
  var _component_icon_halfselect = resolveComponent("icon-halfselect");
  var _component_icon_checked_sur = resolveComponent("icon-checked-sur");
  return openBlock(), createElementBlock("label", mergeProps({
    "data-tag": "tiny-checkbox",
    class: _ctx.m("inline-flex sm:items-center text-sm leading-5 cursor-pointer", _ctx.state.size !== "mini" ? "sm:text-sm" : "sm:text-xs", {
      "sm:py-2": _ctx.state.vertical
    }, _ctx.state.isDisplayOnly || _ctx.state.isGroupDisplayOnly ? _ctx.state.isChecked ? "cursor-default after:content-[';'] after:inline-block last:after:content-['']" : "hidden" : "", _ctx.state.showLabel ? "inline-flex" : "", _ctx.customClass),
    id: _ctx.id,
    tabindex: "-1",
    role: "checkbox",
    "aria-checked": _ctx.indeterminate ? "mixed" : _ctx.state.isChecked,
    "aria-disabled": _ctx.state.isDisabled || _ctx.state.isDisplayOnly,
    "aria-label": _ctx.text || _ctx.label
  }, _ctx.a(_ctx.$attrs, ["class", "style", "onClick"], true)), [createElementVNode("span", {
    class: normalizeClass(["relative w-7 h-7 mr-2 sm:mr-0 sm:p-0", _ctx.state.size === "medium" ? "sm:w-6 sm:h-6" : "sm:h-4 sm:w-4", _ctx.state.isDisplayOnly || _ctx.state.isGroupDisplayOnly ? "hidden" : ""]),
    role: _ctx.indeterminate ? "checkbox" : false,
    "aria-checked": _ctx.indeterminate ? "mixed" : false
  }, [createElementVNode("span", _hoisted_3, [createVNode(_component_icon_check, {
    "data-tag": "icon-check",
    class: normalizeClass(_ctx.m("w-5 h-5 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-0", _ctx.state.size === "medium" ? "sm:w-6 sm:h-6" : "sm:w-4 sm:h-4", _ctx.state.isDisabled ? "[&_path:nth-of-type(2)]:fill-color-icon-disabled [&_path:nth-of-type(1)]:fill-color-bg-3 cursor-not-allowed" : "[&_path:nth-of-type(2)]:fill-color-none-hover"))
  }, null, 8, ["class"]), createVNode(_component_icon_halfselect, {
    "data-tag": "icon-halfselect",
    class: normalizeClass(_ctx.m("w-5 h-5 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 transition-all [&_path:nth-of-type(2)]:fill-color-icon-inverse", _ctx.indeterminate ? "opacity-100 scale-100 z-10" : "opacity-0 scale-0 z-0", _ctx.state.isDisabled ? "[&_path:nth-of-type(1)]:fill-color-brand-disabled cursor-not-allowed" : "[&_path:nth-of-type(1)]:fill-color-brand [&_path:nth-of-type(1)]:shadow-xsm", _ctx.state.size === "medium" ? "sm:w-6 sm:h-6" : "sm:w-4 sm:h-4"))
  }, null, 8, ["class"]), createVNode(_component_icon_checked_sur, {
    "data-tag": "icon-checked-sur",
    class: normalizeClass(_ctx.m("w-5 h-5", _ctx.state.size === "medium" ? "sm:w-6 sm:h-6" : "sm:w-4 sm:h-4", "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 transition-all [&_path:nth-of-type(2)]:fill-color-icon-inverse", _ctx.state.isChecked && !_ctx.indeterminate ? "opacity-100 scale-100 z-10" : "opacity-0 scale-0 z-0", _ctx.state.isDisabled ? "[&_path:nth-of-type(1)]:fill-color-brand-disabled cursor-not-allowed" : "[&_path:nth-of-type(1)]:fill-color-brand [&_path:nth-of-type(2)]:shadow-xsm"))
  }, null, 8, ["class"])]), _ctx.trueLabel || _ctx.falseLabel ? withDirectives((openBlock(), createElementBlock("input", {
    key: 0,
    class: "absolute left-0 right-0 top-0 bottom-0 w-0 h-0 -z-10 opacity-0",
    type: "checkbox",
    "aria-hidden": _ctx.indeterminate ? "true" : "false",
    name: _ctx.name,
    disabled: _ctx.state.inputDisabled,
    "true-value": _ctx.trueLabel,
    "false-value": _ctx.falseLabel,
    "onUpdate:modelValue": _cache[0] || (_cache[0] = function($event) {
      return _ctx.state.model = $event;
    }),
    onChange: _cache[1] || (_cache[1] = withModifiers(function() {
      return _ctx.handleChange && _ctx.handleChange.apply(_ctx, arguments);
    }, ["stop"])),
    onFocus: _cache[2] || (_cache[2] = function($event) {
      return _ctx.state.focus = true;
    }),
    onBlur: _cache[3] || (_cache[3] = function($event) {
      return _ctx.state.focus = false;
    }),
    onClick: _cache[4] || (_cache[4] = withModifiers(function() {
    }, ["stop"]))
  }, null, 40, _hoisted_4)), [[vModelCheckbox, _ctx.state.model]]) : withDirectives((openBlock(), createElementBlock("input", {
    key: 1,
    class: "absolute left-0 right-0 top-0 bottom-0 w-0 h-0 -z-10 opacity-0",
    type: "checkbox",
    "aria-hidden": _ctx.indeterminate ? "true" : "false",
    disabled: _ctx.state.inputDisabled,
    value: _ctx.label,
    name: _ctx.name,
    "onUpdate:modelValue": _cache[5] || (_cache[5] = function($event) {
      return _ctx.state.model = $event;
    }),
    onChange: _cache[6] || (_cache[6] = withModifiers(function() {
      return _ctx.handleChange && _ctx.handleChange.apply(_ctx, arguments);
    }, ["stop"])),
    onFocus: _cache[7] || (_cache[7] = function($event) {
      return _ctx.state.focus = true;
    }),
    onBlur: _cache[8] || (_cache[8] = function($event) {
      return _ctx.state.focus = false;
    }),
    onClick: _cache[9] || (_cache[9] = withModifiers(function() {
    }, ["stop"]))
  }, null, 40, _hoisted_5)), [[vModelCheckbox, _ctx.state.model]])], 10, _hoisted_2), _ctx.slots.default && _ctx.slots.default() || _ctx.text || _ctx.label ? (openBlock(), createElementBlock(
    "span",
    {
      key: 0,
      ref: "label",
      class: normalizeClass(_ctx.m("py-0 pl-0 sm:pl-2 mr-5 flex-1 leading-7 sm:leading-none", _ctx.state.isDisabled ? "cursor-not-allowed text-color-text-secondary" : "text-color-text-primary", _ctx.state.isDisplayOnly || _ctx.state.isGroupDisplayOnly ? "p-0 sm:p-0 m-0 text-color-text-primary cursor-default" : ""))
    },
    [renderSlot(_ctx.$slots, "default", {}, function() {
      return [createTextVNode(
        toDisplayString(_ctx.text || _ctx.label),
        1
        /* TEXT */
      )];
    })],
    2
    /* CLASS */
  )) : (openBlock(), createElementBlock(
    Fragment,
    {
      key: 1
    },
    [_ctx.state.isDisplayOnly ? (openBlock(), createElementBlock(
      "span",
      _hoisted_6,
      toDisplayString(_ctx.state.displayLabel),
      1
      /* TEXT */
    )) : createCommentVNode("v-if", true)],
    64
    /* STABLE_FRAGMENT */
  ))], 16, _hoisted_1);
}
var mobileFirst = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);

export { mobileFirst as default };
