function _extends() {
  return _extends = Object.assign ? Object.assign.bind() : function(n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends.apply(null, arguments);
}
import { defineComponent, $props, $setup, $prefix } from "@opentiny/vue-common";
import PcTemplate from "./pc.js";
import "@opentiny/vue-theme/statistic/index.css";
var template = function template2(mode) {
  var _process$env;
  typeof process === "object" ? (_process$env = process.env) == null ? void 0 : _process$env.TINY_MODE : null;
  return PcTemplate;
};
var $constants = {
  PREFIX: "tiny-statistic"
};
var statisticProps = _extends({}, $props, {
  _constants: {
    type: Object,
    default: function _default() {
      return $constants;
    }
  },
  precision: Number,
  formatter: Function,
  value: {
    type: [Number, String],
    default: 0
  },
  prefix: String,
  suffix: String,
  title: [String, Object],
  valueStyle: {
    type: [Object, Array]
  },
  groupSeparator: {
    type: String,
    default: ","
  },
  duration: {
    type: Number,
    default: 2e3
  },
  startValue: {
    type: Number,
    default: 0
  },
  useAnimation: {
    type: Boolean,
    default: false
  }
});
var Statistic = defineComponent({
  name: $prefix + "Statistic",
  props: statisticProps,
  setup: function setup(props, context) {
    return $setup({
      props,
      context,
      template
    });
  }
});
var version = "3.undefined";
Statistic.model = {
  prop: "modelValue",
  event: "update:modelValue"
};
Statistic.install = function(Vue) {
  Vue.component(Statistic.name, Statistic);
};
Statistic.version = version;
export {
  Statistic as default
};
