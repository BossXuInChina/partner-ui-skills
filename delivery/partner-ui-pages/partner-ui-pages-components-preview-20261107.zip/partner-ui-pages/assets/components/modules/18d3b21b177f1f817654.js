import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  viewBox: "0 0 16 16",
  xmlns: "http://www.w3.org/2000/svg"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    d: "M2.8 2.496a.5.5 0 0 1 .492.41l.008.09v10a.5.5 0 0 1-.992.09l-.008-.09v-10a.5.5 0 0 1 .5-.5ZM8.8 2.496a.5.5 0 0 1 .492.41l.008.09v10a.5.5 0 0 1-.992.09l-.008-.09v-10a.5.5 0 0 1 .5-.5Z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    d: "M8.8 7.5a.5.5 0 0 1 .09.992L8.8 8.5h-6a.5.5 0 0 1-.09-.992L2.8 7.5h6Z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_4 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    fill: "#fff",
    d: "m11.178 8.78 1.7-.942v5.238"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_5 = [_hoisted_2, _hoisted_3, _hoisted_4];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_5));
}
var EditorTitle = {
  render
};
var editorTitle = function editorTitle2() {
  return svg({
    name: "IconEditorTitle",
    component: EditorTitle,
    filledComponent: EditorTitle
  })();
};
export {
  editorTitle as default
};
