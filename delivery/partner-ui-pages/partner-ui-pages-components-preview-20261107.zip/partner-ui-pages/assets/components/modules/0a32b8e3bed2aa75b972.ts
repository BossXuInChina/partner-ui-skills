import { createVNode as _createVNode, openBlock as _openBlock, createElementBlock as _createElementBlock, createCommentVNode as _createCommentVNode, Fragment as _Fragment, toDisplayString as _toDisplayString, normalizeClass as _normalizeClass, createBlock as _createBlock } from "vue"

const _hoisted_1 = ["data-action-type", "disabled", "aria-label", "aria-describedby", "aria-expanded", "aria-haspopup", "aria-controls", "aria-pressed"]
const _hoisted_2 = {
  key: 0,
  class: "wb-top-nav-action__pending-label"
}
const _hoisted_3 = { key: 1 }

import { computed, useId } from 'vue';
import WorkbenchIcon from '../icons/WorkbenchIcon.vue';
import WorkbenchBadge from '../badge/WorkbenchBadge.vue';
import WorkbenchAvatar from '../avatar/WorkbenchAvatar.vue';
import TopNavDisclosureArrow from './TopNavDisclosureArrow.vue';


const __sfc_main__ = {
  __name: 'TopNavAction',
  props: {
  type: { type: String, required: true },
  label: { type: String, default: '' },
  badge: { type: [Number, String, Boolean], default: 0 },
  initial: { type: String, default: 'M' },
  avatarUrl: { type: String, default: '' },
  compact: { type: Boolean, default: false },
  disabled: { type: Boolean, default: false },
  expanded: { type: Boolean, default: undefined },
  pressed: { type: Boolean, default: undefined },
  controls: { type: String, default: undefined },
},
  emits: ['click', 'keydown'],
  setup(__props) {

const props = __props;

const badgeDescriptionId = `wb-top-nav-action-${useId()}`;
const account = computed(() => ['certified', 'pending'].includes(props.type));
const labels = {
  search: '搜索',
  language: '切换语言',
  'login-register': '我的入口',
  certified: '我的入口',
  pending: '我的入口',
  favorite: '收藏',
  help: '帮助',
  message: '通知',
  assistant: '智能助手',
  menu: '打开业务导航',
  close: '关闭',
  login: '登录',
  register: '注册',
};
const accessibleLabel = computed(() => props.label || labels[props.type] || props.type);
const iconName = computed(() => {
  if (account.value && props.compact) return 'account';
  if (props.type === 'login-register') return 'account';
  if (props.type === 'menu' && props.expanded) return 'close';
  return props.type;
});
const iconSize = computed(() =>
  iconName.value === 'assistant' ? 32 : iconName.value === 'close' ? 18 : 20,
);
const badgeValue = computed(() => {
  const value =
    typeof props.badge === 'string'
      ? props.badge === '99+'
        ? 100
        : Number(props.badge)
      : props.badge;
  return Number.isInteger(value) ? value : undefined;
});
const showBadge = computed(() => props.badge === true || badgeValue.value > 0);
const badgeDescription = computed(() =>
  props.badge === true
    ? '有未读消息'
    : props.badge === '99+'
      ? '超过99条未读消息'
      : `${badgeValue.value}条未读消息`,
);

return (_ctx, _cache) => {
  return (_openBlock(), _createElementBlock("button", {
    class: _normalizeClass(["wb-top-nav-action", {
      'is-account': account.value && !__props.compact,
      'is-pending': __props.type === 'pending' && !__props.compact,
      'is-primary': __props.type === 'login',
      'is-text': __props.type === 'register',
    }]),
    "data-action-type": __props.type,
    type: "button",
    disabled: __props.disabled,
    "aria-label": accessibleLabel.value,
    "aria-describedby": showBadge.value ? badgeDescriptionId : undefined,
    "aria-expanded": __props.expanded,
    "aria-haspopup": __props.expanded !== undefined ? 'menu' : undefined,
    "aria-controls": __props.controls,
    "aria-pressed": __props.pressed,
    onClick: _cache[0] || (_cache[0] = $event => (_ctx.$emit('click', $event))),
    onKeydown: _cache[1] || (_cache[1] = $event => (_ctx.$emit('keydown', $event)))
  }, [
    (account.value && !__props.compact)
      ? (_openBlock(), _createElementBlock(_Fragment, { key: 0 }, [
          _createVNode(WorkbenchAvatar, {
            class: "wb-top-nav__avatar",
            size: 24,
            text: __props.initial,
            src: __props.avatarUrl,
            "aria-hidden": "true"
          }, null, 8 /* PROPS */, ["text", "src"]),
          (__props.type === 'pending')
            ? (_openBlock(), _createElementBlock("span", _hoisted_2, "待认证"))
            : _createCommentVNode("v-if", true),
          _createVNode(TopNavDisclosureArrow, {
            class: "wb-top-nav-action__arrow",
            name: `WB-TOP-NAV/action/${__props.type === 'pending' ? 'pending-arrow' : 'account-arrow'}`,
            size: __props.type === 'pending' ? 14 : 12,
            expanded: __props.expanded
          }, null, 8 /* PROPS */, ["name", "size", "expanded"])
        ], 64 /* STABLE_FRAGMENT */))
      : (__props.type === 'login' || __props.type === 'register')
        ? (_openBlock(), _createElementBlock("span", _hoisted_3, _toDisplayString(labels[__props.type]), 1 /* TEXT */))
        : (_openBlock(), _createBlock(WorkbenchIcon, {
            key: 2,
            class: _normalizeClass({
        'wb-top-nav__user-icon': iconName.value === 'account',
        'wb-top-nav-action__language': iconName.value === 'language',
      }),
            name: `WB-TOP-NAV/action/${iconName.value}`,
            size: iconName.value === 'language' ? undefined : iconSize.value
          }, null, 8 /* PROPS */, ["class", "name", "size"])),
    (showBadge.value)
      ? (_openBlock(), _createBlock(WorkbenchBadge, {
          key: 3,
          class: "wb-top-nav-action__badge",
          variant: __props.badge === true ? 'dot' : 'number',
          value: badgeValue.value,
          "aria-label": badgeDescription.value,
          placement: "inline",
          "aria-hidden": "true"
        }, null, 8 /* PROPS */, ["variant", "value", "aria-label"]))
      : _createCommentVNode("v-if", true),
    (showBadge.value)
      ? (_openBlock(), _createElementBlock("span", {
          key: 4,
          id: badgeDescriptionId,
          class: "wb-top-nav-action__sr-only"
        }, _toDisplayString(badgeDescription.value), 1 /* TEXT */))
      : _createCommentVNode("v-if", true)
  ], 42 /* CLASS, PROPS, NEED_HYDRATION */, _hoisted_1))
}
}

}
export default /* @__PURE__ */ Object.assign(__sfc_main__,{__scopeId:"data-v-0a32b8e3"});