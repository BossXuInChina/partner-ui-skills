import "../../../chunk-G2ADBYYC.js";
import isNullType from "./isNull";
import isUndefinedType from "./isUndefined";
const eqNull = (object) => isNullType(object) || isUndefinedType(object);
var eqNull_default = eqNull;
export {
  eqNull_default as default
};
