import { defineComponent as _defineComponent } from 'vue'
import { renderList as _renderList, Fragment as _Fragment, openBlock as _openBlock, createElementBlock as _createElementBlock, mergeProps as _mergeProps, createBlock as _createBlock, normalizeClass as _normalizeClass, createElementVNode as _createElementVNode, renderSlot as _renderSlot } from "vue"

const _hoisted_1 = { class: "tr-prompts" }

import { toRaw } from 'vue'
import { PromptProps, PromptsEvents, PromptsProps, PromptsSlots } from './index.type'
import Prompt from './prompt.vue'


const __sfc_main__ = /*@__PURE__*/_defineComponent({
  __name: 'prompts',
  props: {
    items: {},
    itemStyle: {},
    itemClass: {},
    vertical: { type: Boolean },
    wrap: { type: Boolean }
  },
  emits: ["item-click"],
  setup(__props: any, { emit: __emit }) {

const props = __props

const emit = __emit



const handleClick = (ev: MouseEvent, item: PromptProps) => {
  emit('item-click', ev, toRaw(item))
}

return (_ctx: any,_cache: any) => {
  return (_openBlock(), _createElementBlock("div", _hoisted_1, [
    _createElementVNode("div", {
      class: _normalizeClass(['tr-prompts__list-container', { wrap: props.wrap, vertical: props.vertical }])
    }, [
      (_openBlock(true), _createElementBlock(_Fragment, null, _renderList(props.items, (item, index) => {
        return (_openBlock(), _createBlock(Prompt, _mergeProps({
          key: item.id || index
        }, { ref_for: true }, item, {
          style: props.itemStyle,
          class: props.itemClass,
          onClick: ($event: any) => (handleClick($event, item))
        }), null, 16 /* FULL_PROPS */, ["style", "class", "onClick"]))
      }), 128 /* KEYED_FRAGMENT */))
    ], 2 /* CLASS */),
    _renderSlot(_ctx.$slots, "footer")
  ]))
}
}

})
export default /* @__PURE__ */ Object.assign(__sfc_main__,{__scopeId:"data-v-0daef8dd"});