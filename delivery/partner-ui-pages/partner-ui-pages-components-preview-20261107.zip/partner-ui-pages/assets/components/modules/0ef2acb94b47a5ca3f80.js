function _extends() {
  return _extends = Object.assign ? Object.assign.bind() : function(n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends.apply(null, arguments);
}
import { defineComponent, $props, $setup, $prefix } from "@opentiny/vue-common";
import PcTemplate from "./pc.js";
import MobileFirstTemplate from "./mobile-first.js";
import { defaultToolbar } from "@opentiny/vue-renderless/fluent-editor/options";
var template = function template2(mode) {
  var _process$env;
  var tinyMode = typeof process === "object" ? (_process$env = process.env) == null ? void 0 : _process$env.TINY_MODE : null;
  if ("pc" === (tinyMode || mode)) {
    return PcTemplate;
  }
  if ("mobile-first" === (tinyMode || mode)) {
    return MobileFirstTemplate;
  }
  return PcTemplate;
};
var $constants = {
  PIC_PREVIEW_OPTIONS: {
    zIndex: Number.POSITIVE_INFINITY,
    urlList: null
  },
  EDITOR_FULLSCREEN_OPTIONS: Number.POSITIVE_INFINITY
};
var fluentEditorProps = _extends({}, $props, {
  _constants: {
    type: Object,
    default: function _default() {
      return $constants;
    }
  },
  content: String,
  disabled: {
    type: Boolean,
    default: false
  },
  fileUpload: Object,
  globalOptions: {
    type: Object,
    required: false,
    default: function _default2() {
      return {};
    }
  },
  imageUpload: Object,
  mentionObj: {
    type: Object,
    required: false,
    default: function _default3() {
      return {};
    }
  },
  modelValue: String,
  options: {
    type: Object,
    required: false,
    default: function _default4() {
      return {};
    }
  },
  picPreview: [Object, Boolean],
  dataType: {
    type: Boolean,
    default: true
  },
  dataUpgrade: {
    type: Boolean,
    default: true
  },
  zIndex: {
    type: Number,
    default: $constants.EDITOR_FULLSCREEN_OPTIONS
  },
  imagePasteFailCallback: {
    type: Function,
    default: function _default5() {
    }
  },
  beforeEditorInit: {
    type: Function,
    default: function _default6() {
    }
  },
  beforeLinkOpen: {
    type: Function,
    default: null
  }
});
var FluentEditor = defineComponent({
  name: $prefix + "FluentEditor",
  props: fluentEditorProps,
  setup: function setup(props, context) {
    return $setup({
      props,
      context,
      template
    });
  }
});
var version = "3.undefined";
FluentEditor.model = {
  prop: "modelValue",
  event: "update:modelValue"
};
FluentEditor.install = function(Vue) {
  Vue.component(FluentEditor.name, FluentEditor);
};
FluentEditor.version = version;
export {
  FluentEditor as default,
  defaultToolbar
};
