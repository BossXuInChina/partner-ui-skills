function _extends() {
  return _extends = Object.assign ? Object.assign.bind() : function(n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends.apply(null, arguments);
}
import { defineComponent, $props, $setup, $prefix } from "@opentiny/vue-common";
import PcTemplate from "./pc.js";
import MobileFirstTemplate from "./mobile-first.js";
import "@opentiny/vue-theme/popover/index.css";
var template = function template2(mode) {
  var _process$env;
  var tinyMode = typeof process === "object" ? (_process$env = process.env) == null ? void 0 : _process$env.TINY_MODE : null;
  if ("pc" === (tinyMode || mode)) {
    return PcTemplate;
  }
  if ("mobile-first" === (tinyMode || mode)) {
    return MobileFirstTemplate;
  }
  return PcTemplate;
};
var popoverProps = _extends({}, $props, {
  appendToBody: {
    type: Boolean,
    default: true
  },
  arrowOffset: {
    type: Number,
    default: 0
  },
  boundariesPadding: {
    type: Number,
    default: 5
  },
  closeDelay: {
    type: Number,
    default: 200
  },
  content: String,
  disabled: Boolean,
  modelValue: Boolean,
  offset: {
    default: 0
  },
  openDelay: {
    type: Number,
    default: 0
  },
  placement: {
    type: String,
    default: "bottom"
  },
  popper: {},
  popperClass: String,
  popperOptions: {
    type: Object,
    default: function _default() {
      return {
        gpuAcceleration: false
      };
    }
  },
  reference: {},
  tabindex: {
    type: Number,
    default: 0
  },
  title: String,
  transition: {
    type: String,
    default: "fade-in-linear"
  },
  trigger: {
    type: String,
    default: "click",
    validator: function validator(value) {
      return Boolean(~["click", "focus", "hover", "manual"].indexOf(value));
    }
  },
  visibleArrow: {
    default: true
  },
  width: {
    type: [String, Number]
  },
  height: {
    type: [String, Number]
  },
  maxHeight: {
    type: [String, Number]
  },
  listData: [Object, Array],
  genArrowByHtml: {
    type: Boolean,
    default: function _default2() {
      return true;
    }
  }
});
var Popover = defineComponent({
  inheritAttrs: true,
  name: $prefix + "Popover",
  props: popoverProps,
  setup: function setup(props, context) {
    return $setup({
      props,
      context,
      template
    });
  }
});
var version = "3.undefined";
Popover.install = function(Vue) {
  Vue.component(Popover.name, Popover);
};
Popover.model = {
  prop: "modelValue",
  event: "update:modelValue"
};
Popover.version = version;
export {
  Popover as default
};
