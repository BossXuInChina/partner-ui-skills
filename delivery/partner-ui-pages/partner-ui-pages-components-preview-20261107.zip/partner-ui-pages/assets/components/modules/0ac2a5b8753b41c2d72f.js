function _extends() {
  return _extends = Object.assign ? Object.assign.bind() : function(n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends.apply(null, arguments);
}
import { defineComponent, $props, $setup, $prefix } from "@opentiny/vue-common";
import PcTemplate from "./pc.js";
import "@opentiny/vue-theme/user-account/index.css";
var template = function template2(mode) {
  var _process$env;
  typeof process === "object" ? (_process$env = process.env) == null ? void 0 : _process$env.TINY_MODE : null;
  return PcTemplate;
};
var UserAccount = defineComponent({
  name: $prefix + "UserAccount",
  props: _extends({}, $props, {
    getLangData: Function,
    getUserInfo: Function,
    getUserImageUrl: Function,
    getLogoutUrl: Function,
    redirectUrl: String,
    isLocal: Boolean,
    network: Function,
    isMock: Boolean,
    isGuestUser: Function,
    showLogin: Function,
    showArrow: {
      type: Boolean,
      default: false
    },
    popperClass: String,
    popperAppendToBody: {
      type: Boolean,
      default: true
    },
    beforeLogout: Function
  }),
  setup: function setup(props, context) {
    return $setup({
      props,
      context,
      template
    });
  }
});
var version = "3.undefined";
UserAccount.install = function(Vue) {
  Vue.component(UserAccount.name, UserAccount);
};
UserAccount.version = version;
export {
  UserAccount as default
};
