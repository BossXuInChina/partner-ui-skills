import Quill from "quill";
import { splitWithBreak, omit } from "../../../config/editor.utils.es.js";
import { rowId, cellId, TableViewWrapper } from "../formats/table.es.js";
import { CELL_MIN_WIDTH } from "../table-config.es.js";
const Delta = Quill.imports.delta;
const InlineBlot = Quill.imports.parchment.InlineBlot;
function matchTableCell(node, delta) {
  if (node.style.height.indexOf("pt")) {
    node.removeAttribute("style");
  }
  const row = node.parentNode;
  let rowId$1 = row.dataset.row;
  if (!rowId$1) {
    rowId$1 = row.dataset.row = rowId();
  }
  let cellId$1 = node.dataset.cell;
  if (!cellId$1 || cellId$1 === "undefined") {
    cellId$1 = cellId();
  }
  const colspan = node.getAttribute("colspan") || 1;
  const rowspan = node.getAttribute("rowspan") || 1;
  if (delta.length() === 0) {
    delta = new Delta().insert("\n", {
      "table-cell-line": { row: rowId$1, cell: cellId$1, rowspan, colspan }
    });
    return delta;
  }
  delta = delta.reduce((newDelta, op) => {
    if (op.insert && typeof op.insert === "string") {
      const lines = splitWithBreak(op.insert);
      lines.forEach((text) => {
        if (text === "\n") {
          let attributes = {};
          const cellAttributes = {
            row: rowId$1,
            cell: cellId$1,
            rowspan,
            colspan
          };
          if (op.attributes.table) {
            delete op.attributes.table;
          }
          switch (true) {
            case !!op.attributes.header:
              attributes = Object.assign(op.attributes.header, cellAttributes);
              break;
            case !!op.attributes.list:
              attributes = { list: Object.assign(op.attributes.list, cellAttributes) };
              break;
            default:
              attributes = { "table-cell-line": cellAttributes };
          }
          if (op.attributes.background && attributes["table-cell-line"]) {
            attributes["table-cell-line"].tdBgColor = op.attributes.background;
          }
          newDelta.insert("\n", Object.assign(op.attributes, attributes));
        } else {
          newDelta.insert(text, omit(op.attributes, ["table", "table-cell-line", "header", "list"]));
        }
      });
    } else {
      newDelta.insert(op.insert, op.attributes);
    }
    return newDelta;
  }, new Delta());
  const regexp = /^[\n]+$/;
  const firstDelta = delta.ops[0];
  if (delta.ops.length >= 3) {
    const lastDelta = delta.ops[delta.ops.length - 1];
    if (regexp.test(firstDelta.insert) && firstDelta.attributes["table-cell-line"]) {
      delta.ops.splice(0, 1);
    }
    if (regexp.test(lastDelta.insert) && lastDelta.attributes["table-cell-line"]) {
      delta.ops[delta.ops.length - 1].insert = "\n";
    }
  } else if (delta.ops.length === 1 && regexp.test(firstDelta.insert) && firstDelta.attributes["table-cell-line"]) {
    delta.ops[0].insert = "\n";
  }
  return delta;
}
function matchTableHeader(node, delta, _scroll) {
  const row = node.parentNode;
  const cells = Array.from(row.querySelectorAll("th"));
  let rowId$1 = row.dataset.row;
  if (!rowId$1) {
    rowId$1 = row.dataset.row = rowId();
  }
  const cellId2 = cells.indexOf(node) + 1;
  const colspan = node.getAttribute("colspan") || false;
  const rowspan = node.getAttribute("rowspan") || false;
  if (delta.length() === 0) {
    delta = new Delta().insert("\n", {
      "table-cell-line": { row: rowId$1, cell: cellId2, rowspan, colspan }
    });
    return delta;
  }
  delta = delta.reduce((newDelta, op) => {
    if (op.insert && typeof op.insert === "string") {
      const lines = splitWithBreak(op.insert);
      if (lines[lines.length - 1] !== "\n") {
        lines.push("\n");
      }
      lines.forEach((text) => {
        text === "\n" ? newDelta.insert("\n", { "table-cell-line": { row: rowId$1, cell: cellId2, rowspan, colspan } }) : newDelta.insert(text, op.attributes);
      });
    } else {
      newDelta.insert(op.insert, op.attributes);
    }
    return newDelta;
  }, new Delta());
  delta = delta.reduce((newDelta, op) => {
    if (op.insert && typeof op.insert === "string" && op.insert.startsWith("\n")) {
      newDelta.insert(op.insert, { "table-cell-line": { row: rowId$1, cell: cellId2, rowspan, colspan } });
    } else {
      newDelta.insert(op.insert, { ...omit(op.attributes, ["table", "table-cell-line"]) });
    }
    return newDelta;
  }, new Delta());
  return delta;
}
function matchTable(node, delta, scroll) {
  const isWordTable = node.children.length === 1;
  if (!(node instanceof Element)) {
    return;
  }
  const getMaxColNumber = (tds) => {
    if (isWordTable) {
      return tds.length;
    }
    let colsNumber2 = 0;
    tds.forEach((td) => {
      colsNumber2 += td.colSpan;
    });
    return Math.max(tds.length, colsNumber2);
  };
  const checkMinWidth = (width) => {
    if (Number.isNaN(width)) {
      return { "table-col": { width: "auto" } };
    } else if (width < CELL_MIN_WIDTH) {
      return { "table-col": true };
    } else {
      return { "table-col": { width } };
    }
  };
  const rows = node.querySelectorAll("tr");
  const topRow = rows[0];
  const onlyEmptyTr = rows.length === 1 && !topRow.querySelector("td");
  if (!topRow || onlyEmptyTr) {
    return new Delta().insert("\n");
  }
  const colsNumber = node.querySelectorAll("col").length;
  let maxCellsNumber = 0;
  let maxCells;
  Array.prototype.slice.call(rows).forEach((row) => {
    const tds = row.querySelectorAll("td");
    maxCellsNumber = Math.max(getMaxColNumber(tds), maxCellsNumber);
    maxCells = tds;
  });
  let colCount = 0;
  delta = delta.reduce((newDelta, op) => {
    if (colCount === colsNumber) {
      const fillNumber = maxCellsNumber - colCount;
      const outset = colCount;
      for (let i = 0; i < fillNumber; i++) {
        const index = outset + i;
        const colWidth = Number.parseInt(
          index < maxCells.length ? maxCells[index].width : maxCells[maxCells.length - 1].width,
          10
        );
        newDelta.insert("\n", checkMinWidth(colWidth));
        colCount++;
      }
    }
    const attr = op.attributes || {};
    switch (true) {
      case !!attr["table-col"]:
        if (colCount < maxCellsNumber) {
          const insert = op.insert.slice(0, maxCellsNumber);
          const colWidth = Number.parseInt(attr["table-col"].width, 10);
          newDelta.insert(insert, checkMinWidth(colWidth));
          colCount += insert.length;
        }
        break;
      case !!attr.notFilled: {
        const rowId$1 = rowId();
        for (let x = 0; x < maxCellsNumber; x++) {
          newDelta.insert("\n", { "table-cell-line": { row: rowId$1, cell: cellId(), rowspan: 1, colspan: 1 } });
        }
        break;
      }
      default:
        newDelta.insert(op.insert, op.attributes);
    }
    return newDelta;
  }, new Delta());
  const tableItem = node.closest(".quill-better-table-wrapper") || node;
  const prevBlot = tableItem.previousElementSibling && scroll.query(tableItem.previousElementSibling);
  const nextBlot = tableItem.nextElementSibling && scroll.query(tableItem.nextElementSibling);
  if (!nextBlot || nextBlot.prototype instanceof InlineBlot) {
    delta = delta.insert("\n");
  }
  if (!prevBlot || prevBlot.prototype instanceof InlineBlot) {
    const newLine = new Delta().insert("\n");
    delta = newLine.concat(delta);
  }
  if (nextBlot === TableViewWrapper) {
    delta = delta.insert("\n");
  }
  return delta;
}
function matchTableRow(_node, delta) {
  if (delta.ops.length === 1 && !delta.ops[0].attributes) {
    delta = new Delta().insert("\n", { notFilled: true });
  }
  return delta;
}
function matchHeader(node, delta) {
  const newDelta = new Delta();
  const fontSize = node.style.fontSize;
  delta.forEach((op) => {
    newDelta.insert(
      op.insert,
      Object.assign({}, op.attributes, {
        size: fontSize
      })
    );
  });
  return newDelta;
}
function matchList(node, delta) {
  const value = node.tagName === "UL" ? "bullet" : "ordered";
  delta.forEach((op) => {
    if (typeof op.attributes.list === "string") {
      delete op.attributes.list;
    } else if (typeof op.attributes.list === "object" && !op.attributes.list.value) {
      op.attributes.list.value = value;
    }
  });
  return delta;
}
function matchInline(node, delta, scroll) {
  const quill = Quill.find(scroll.domNode.parentNode);
  const currentRange = quill.getSelection();
  const formats = currentRange && quill.getFormat(currentRange);
  if (formats && formats["table-cell-line"] && node.nextElementSibling) {
    const match = scroll.query(node);
    const nodeHtml = node.nextElementSibling.innerHTML;
    const nodeText = node.nextElementSibling.textContent;
    if (match && match.prototype instanceof InlineBlot || node.tagName === "P" && nodeHtml !== nodeText) {
      delta.forEach((op) => {
        op.insert += "\n";
      });
    }
  }
  return delta;
}
function matchWordShapeImage(node, delta) {
  var _a;
  if (node) {
    const imageUrl = (_a = node.attributes.src) == null ? void 0 : _a.nodeValue;
    if (!imageUrl) {
      return delta;
    }
    delta = new Delta().insert({ image: imageUrl });
  }
  return delta;
}
function matchMentionLink(node, delta, scroll) {
  const name = node.dataset.mentionId;
  if (name) {
    const quill = Quill.find(scroll.domNode.parentNode);
    const mention = quill.getModule("mention");
    if (mention) {
      mention.options.search(name).then((res) => {
        const [item] = res;
        if (item) {
          mention.options.select(item);
        }
      });
    }
  }
  return delta;
}
export {
  matchHeader,
  matchInline,
  matchList,
  matchMentionLink,
  matchTable,
  matchTableCell,
  matchTableHeader,
  matchTableRow,
  matchWordShapeImage
};
//# sourceMappingURL=node-matchers.es.js.map
