import { renderless, api } from '@opentiny/vue-renderless/user-account/vue';
import { defineComponent, props, setup } from '@opentiny/vue-common';
import UserContact from '@opentiny/vue-user-contact';
import Logout from '@opentiny/vue-logout';
import { resolveComponent, openBlock, createElementBlock, createVNode, withCtx, createElementVNode, renderSlot } from 'vue';

function _createForOfIteratorHelperLoose(r, e) {
  var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (t) return (t = t.call(r)).next.bind(t);
  if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
    t && (r = t);
    var o = 0;
    return function() {
      return o >= r.length ? { done: true } : { done: false, value: r[o++] };
    };
  }
  throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return _arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
  }
}
function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}
var _export_sfc = function _export_sfc2(sfc, props) {
  var target = sfc.__vccOpts || sfc;
  for (var _iterator = _createForOfIteratorHelperLoose(props), _step; !(_step = _iterator()).done; ) {
    var _step$value = _step.value, key = _step$value[0], val = _step$value[1];
    target[key] = val;
  }
  return target;
};

var _sfc_main = defineComponent({
  components: {
    UserContact,
    Logout
  },
  props: [].concat(props, ["showArrow", "guestRole", "getUserInfo", "getLangData", "getUserImageUrl", "getLogoutUrl", "redirectUrl", "isLocal", "network", "isMock", "isGuestUser", "showLogin", "popperClass", "popperAppendToBody", "beforeLogout"]),
  setup: function setup$1(props2, context) {
    return setup({
      props: props2,
      context,
      renderless,
      api
    });
  }
});
var _hoisted_1 = {
  class: "tiny-user-account"
};
var _hoisted_2 = {
  class: "user-account-pop"
};
var _hoisted_3 = {
  class: "user-account-custom"
};
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_logout = resolveComponent("logout");
  var _component_user_contact = resolveComponent("user-contact");
  return openBlock(), createElementBlock("div", _hoisted_1, [createVNode(_component_user_contact, {
    data: _ctx.state,
    "show-arrow": _ctx.showArrow,
    "popper-class": "tiny-user-account" + (_ctx.popperClass ? " " + _ctx.popperClass : ""),
    "popper-append-to-body": _ctx.popperAppendToBody
  }, {
    default: withCtx(function() {
      return [createElementVNode("div", _hoisted_2, [createElementVNode("div", _hoisted_3, [renderSlot(_ctx.$slots, "default")]), createVNode(_component_logout, {
        "guest-role": _ctx.guestRole,
        "get-logout-url": _ctx.getLogoutUrl,
        "is-local": _ctx.isLocal,
        "redirect-url": _ctx.redirectUrl,
        network: _ctx.network,
        "is-mock": _ctx.isMock,
        "is-guest-user": _ctx.isGuestUser,
        "show-login": _ctx.showLogin,
        "before-logout": _ctx.beforeLogout
      }, null, 8, ["guest-role", "get-logout-url", "is-local", "redirect-url", "network", "is-mock", "is-guest-user", "show-login", "before-logout"])])];
    }),
    _: 3
    /* FORWARDED */
  }, 8, ["data", "show-arrow", "popper-class", "popper-append-to-body"])]);
}
var pc = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);

export { pc as default };
