import { renderless, api } from '@opentiny/vue-renderless/standard-list-item/vue';
import { defineComponent, $prefix, setup, $props } from '@opentiny/vue-common';
import Dropdown from '@opentiny/vue-dropdown';
import DropdownMenu from '@opentiny/vue-dropdown-menu';
import DropdownItem from '@opentiny/vue-dropdown-item';
import Tooltip from '@opentiny/vue-tooltip';
import UserHead from '@opentiny/vue-user-head';
import TagGroup from '@opentiny/vue-tag-group';
import { iconEllipsis } from '@opentiny/vue-icon';
import { resolveComponent, openBlock, createElementBlock, normalizeClass, renderSlot, createBlock, resolveDynamicComponent, normalizeStyle, createCommentVNode, createElementVNode, withModifiers, toDisplayString, createVNode, withCtx, Fragment, renderList } from 'vue';

function _createForOfIteratorHelperLoose(r, e) {
  var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (t) return (t = t.call(r)).next.bind(t);
  if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
    t && (r = t);
    var o = 0;
    return function() {
      return o >= r.length ? { done: true } : { done: false, value: r[o++] };
    };
  }
  throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return _arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
  }
}
function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}
var _export_sfc = function _export_sfc2(sfc, props) {
  var target = sfc.__vccOpts || sfc;
  for (var _iterator = _createForOfIteratorHelperLoose(props), _step; !(_step = _iterator()).done; ) {
    var _step$value = _step.value, key = _step$value[0], val = _step$value[1];
    target[key] = val;
  }
  return target;
};

function _extends() {
  return _extends = Object.assign ? Object.assign.bind() : function(n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends.apply(null, arguments);
}
var _sfc_main = defineComponent({
  name: $prefix + "StandardListItem",
  emits: ["icon-click", "click"],
  components: {
    TinyTooltip: Tooltip,
    TinyUserHead: UserHead,
    TinyTagGroup: TagGroup,
    TinyDropdown: Dropdown,
    TinyDropdownMenu: DropdownMenu,
    TinyDropdownItem: DropdownItem,
    IconEllipsis: iconEllipsis()
  },
  props: _extends({}, $props, {
    data: {
      type: Object,
      default: function _default() {
        return {};
      }
    },
    tag: {
      type: Object,
      default: function _default2() {
        return {};
      }
    },
    selected: {
      type: Boolean,
      default: false
    },
    showImage: {
      type: Boolean,
      default: false
    },
    icon: {
      type: Object,
      default: function _default3() {
        return {};
      }
    },
    userHead: {
      type: Object,
      default: function _default4() {
        return {};
      }
    },
    options: {
      type: Array,
      default: function _default5() {
        return [];
      }
    },
    iconMore: {
      type: [Object, String],
      default: function _default6() {
        return iconEllipsis();
      }
    },
    type: {
      type: String,
      default: "list"
    },
    titleOption: {
      type: Object,
      default: function _default7() {
        return {};
      }
    },
    customClass: {
      type: String,
      default: ""
    }
  }),
  setup: function setup$1(props, context) {
    return setup({
      props,
      context,
      renderless,
      api,
      mono: true
    });
  }
});
var _hoisted_1 = {
  "data-tag": "tiny-standard-list-item-title",
  class: "text-left overflow-auto flex-auto mx-0 my-auto leading-5"
};
var _hoisted_2 = {
  class: "text-sm flex items-center"
};
var _hoisted_3 = {
  class: "text-color-text-secondary shrink-0"
};
var _hoisted_4 = {
  key: 0,
  class: "mt-2 text-xs line-clamp-2 sm:line-clamp-1 text-color-text-primary"
};
var _hoisted_5 = {
  key: 1,
  "data-tag": "tiny-standard-list-item-operate",
  class: "w-auto pr-0 pl-6 h-auto flex items-center justify-center shrink-0 text-color-text-primary"
};
var _hoisted_6 = ["onClick"];
var _hoisted_7 = {
  key: 0,
  class: "ml-1 align-middle"
};
var _hoisted_8 = {
  key: 0,
  class: "ml-1 align-middle"
};
var _hoisted_9 = {
  key: 1,
  "data-tag": "tiny-standard-list-item-selficon",
  class: "h-4 hidden sm:block"
};
var _hoisted_10 = {
  key: 0,
  class: "ml-1 text-color-text-primary"
};
var _hoisted_11 = ["onClick"];
var _hoisted_12 = {
  key: 0
};
var _hoisted_13 = {
  key: 2,
  "data-tag": "tiny-standard-list-item-selficon",
  class: "block sm:hidden"
};
var _hoisted_14 = ["onClick"];
var _hoisted_15 = {
  key: 0
};
function _sfc_render(_ctx, _cache, $props2, $setup, $data, $options) {
  var _component_tiny_user_head = resolveComponent("tiny-user-head");
  var _component_tiny_tag_group = resolveComponent("tiny-tag-group");
  var _component_tiny_tooltip = resolveComponent("tiny-tooltip");
  var _component_tiny_dropdown_item = resolveComponent("tiny-dropdown-item");
  var _component_tiny_dropdown_menu = resolveComponent("tiny-dropdown-menu");
  var _component_tiny_dropdown = resolveComponent("tiny-dropdown");
  return openBlock(), createElementBlock(
    "div",
    {
      "data-tag": "tiny-standard-list-item",
      class: normalizeClass(["flex w-full min-h-[theme(spacing.11)] sm:min-h-[theme(spacing.12)] text-xs", _ctx.m(_ctx.type === "card" ? "p-3 border-0.5 hover:shadow sm:border rounded border-color-border-separator mb-2 [&:last-child]:mb-0" : "px-0 py-3 border-b-0.5 sm:border-b-px border-b-color-border-separator [&:last-child]:border-none", _ctx.type === "card" && _ctx.selected ? "border border-color-brand" : "", _ctx.customClass)]),
      onClick: _cache[5] || (_cache[5] = function($event) {
        return _ctx.$emit("click", $event);
      })
    },
    [_ctx.showImage || _ctx.slots.image && _ctx.slots.image() ? (openBlock(), createElementBlock(
      "div",
      {
        key: 0,
        "data-tag": "tiny-standard-list-item-image",
        class: normalizeClass(["float-left items-center mr-2.5 shrink-0", [_ctx.icon.name ? "block" : "block sm:flex"]])
      },
      [renderSlot(_ctx.$slots, "image", {}, function() {
        return [_ctx.icon.name ? (openBlock(), createBlock(resolveDynamicComponent(_ctx.icon.name), {
          key: 0,
          class: "w-5 h-5",
          style: normalizeStyle({
            fill: _ctx.icon.color
          })
        }, null, 8, ["style"])) : (openBlock(), createBlock(_component_tiny_user_head, {
          key: 1,
          type: _ctx.userHead.type || "icon",
          modelValue: _ctx.userHead.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = function($event) {
            return _ctx.userHead.value = $event;
          }),
          min: _ctx.userHead.min,
          round: _ctx.userHead.round,
          color: _ctx.userHead.color,
          "background-color": _ctx.userHead.backgroundColor,
          size: _ctx.userHead.size
        }, null, 8, ["type", "modelValue", "min", "round", "color", "background-color", "size"]))];
      })],
      2
      /* CLASS */
    )) : createCommentVNode("v-if", true), createElementVNode("div", _hoisted_1, [renderSlot(_ctx.$slots, "default", {}, function() {
      return [createElementVNode("div", _hoisted_2, [renderSlot(_ctx.$slots, "title", {}, function() {
        return [createElementVNode(
          "span",
          {
            class: normalizeClass(_ctx.m("mr-3 shrink-0 text-color-text-primary leading-5.5", _ctx.titleOption.role === "a" && "cursor-pointer text-color-brand", _ctx.titleOption.class || "")),
            onClick: _cache[1] || (_cache[1] = withModifiers(function() {
              return _ctx.handleTitleClick && _ctx.handleTitleClick.apply(_ctx, arguments);
            }, ["stop"]))
          },
          toDisplayString(_ctx.data.title || ""),
          3
          /* TEXT, CLASS */
        )];
      }), createElementVNode(
        "span",
        _hoisted_3,
        toDisplayString(_ctx.data.subTitle || ""),
        1
        /* TEXT */
      ), renderSlot(_ctx.$slots, "tag", {}, function() {
        return [_ctx.tag ? (openBlock(), createBlock(_component_tiny_tag_group, {
          key: 0,
          class: "inline-block ml-3 text-xs [&_span]:whitespace-nowrap",
          data: _ctx.tag.data,
          size: _ctx.tag.size,
          effect: _ctx.tag.effect
        }, null, 8, ["data", "size", "effect"])) : createCommentVNode("v-if", true)];
      })]), createVNode(_component_tiny_tooltip, {
        effect: "light",
        content: _ctx.state.descTooltip,
        placement: "top",
        onMouseenter: _ctx.handleEnterDesc
      }, {
        default: withCtx(function() {
          return [_ctx.data.desc ? (openBlock(), createElementBlock(
            "p",
            _hoisted_4,
            toDisplayString(_ctx.data.desc),
            1
            /* TEXT */
          )) : createCommentVNode("v-if", true)];
        }),
        _: 1
        /* STABLE */
      }, 8, ["content", "onMouseenter"])];
    })]), _ctx.state.effectOptions.length || _ctx.slots.operate && _ctx.slots.operate() ? (openBlock(), createElementBlock("div", _hoisted_5, [renderSlot(_ctx.$slots, "operate", {}, function() {
      return [(openBlock(true), createElementBlock(
        Fragment,
        null,
        renderList(_ctx.state.effectOptions.slice(0, _ctx.state.sliceNum), function(item, index) {
          return openBlock(), createElementBlock("div", {
            class: normalizeClass(["cursor-pointer mr-5 hidden sm:block", [item.disabled ? "text-color-text-disabled cursor-not-allowed" : ""]]),
            key: item.text + index,
            onClick: withModifiers(function($event) {
              return _ctx.handelIconClick(item, index, $event);
            }, ["stop"])
          }, [(openBlock(), createBlock(resolveDynamicComponent(item.icon), {
            class: normalizeClass(["w-4 h-4", [item.disabled ? "fill-color-icon-disabled" : ""]])
          }, null, 8, ["class"])), item.text ? (openBlock(), createElementBlock(
            "span",
            _hoisted_7,
            toDisplayString(item.text),
            1
            /* TEXT */
          )) : createCommentVNode("v-if", true)], 10, _hoisted_6);
        }),
        128
        /* KEYED_FRAGMENT */
      )), _ctx.state.effectOptions.length === _ctx.state.iconNum ? (openBlock(), createElementBlock(
        "div",
        {
          key: 0,
          class: normalizeClass(["cursor-pointer hidden sm:block", [_ctx.state.effectOptions[_ctx.state.sliceNum].disabled ? "text-color-text-disabled cursor-not-allowed" : ""]]),
          onClick: _cache[2] || (_cache[2] = withModifiers(function($event) {
            return _ctx.handelIconClick(_ctx.state.effectOptions[_ctx.state.sliceNum], _ctx.state.sliceNum, $event);
          }, ["stop"]))
        },
        [(openBlock(), createBlock(resolveDynamicComponent(_ctx.state.effectOptions[_ctx.state.sliceNum].icon), {
          class: normalizeClass(["w-4 h-4", [_ctx.state.effectOptions[_ctx.state.sliceNum].disabled ? "fill-color-icon-disabled" : ""]])
        }, null, 8, ["class"])), _ctx.state.effectOptions[_ctx.state.sliceNum].text ? (openBlock(), createElementBlock(
          "span",
          _hoisted_8,
          toDisplayString(_ctx.state.effectOptions[_ctx.state.sliceNum].text),
          1
          /* TEXT */
        )) : createCommentVNode("v-if", true)],
        2
        /* CLASS */
      )) : createCommentVNode("v-if", true), _ctx.state.effectOptions.length > _ctx.state.iconNum ? (openBlock(), createElementBlock("div", _hoisted_9, [createVNode(_component_tiny_dropdown, {
        "show-self-icon": "",
        onClick: _cache[3] || (_cache[3] = withModifiers(function() {
        }, ["stop"]))
      }, {
        dropdown: withCtx(function() {
          return [createVNode(_component_tiny_dropdown_menu, {
            placement: "bottom"
          }, {
            default: withCtx(function() {
              return [(openBlock(true), createElementBlock(
                Fragment,
                null,
                renderList(_ctx.state.effectOptions.slice(_ctx.state.sliceNum), function(item, index) {
                  return openBlock(), createBlock(
                    _component_tiny_dropdown_item,
                    {
                      key: item.text + index
                    },
                    {
                      default: withCtx(function() {
                        return [createElementVNode("div", {
                          onClick: withModifiers(function($event) {
                            return _ctx.handelIconClick(item, index + _ctx.state.sliceNum, $event);
                          }, ["stop"]),
                          class: normalizeClass([item.disabled ? "text-color-text-disabled cursor-not-allowed" : ""])
                        }, [(openBlock(), createBlock(resolveDynamicComponent(item.icon), {
                          class: normalizeClass(["w-4 h-4", [item.disabled ? "fill-color-icon-disabled" : ""]])
                        }, null, 8, ["class"])), item.text ? (openBlock(), createElementBlock(
                          "span",
                          _hoisted_12,
                          toDisplayString(item.text),
                          1
                          /* TEXT */
                        )) : createCommentVNode("v-if", true)], 10, _hoisted_11)];
                      }),
                      _: 2
                      /* DYNAMIC */
                    },
                    1024
                    /* DYNAMIC_SLOTS */
                  );
                }),
                128
                /* KEYED_FRAGMENT */
              ))];
            }),
            _: 1
            /* STABLE */
          })];
        }),
        default: withCtx(function() {
          return [(openBlock(), createBlock(resolveDynamicComponent(_ctx.iconMore), {
            class: "w-4 h-4"
          })), _ctx.state.effectOptions[0].text ? (openBlock(), createElementBlock(
            "span",
            _hoisted_10,
            toDisplayString(_ctx.t("ui.base.more")),
            1
            /* TEXT */
          )) : createCommentVNode("v-if", true)];
        }),
        _: 1
        /* STABLE */
      })])) : createCommentVNode("v-if", true), _ctx.state.effectOptions.length ? (openBlock(), createElementBlock("div", _hoisted_13, [createVNode(_component_tiny_dropdown, {
        "show-self-icon": "",
        onClick: _cache[4] || (_cache[4] = withModifiers(function() {
        }, ["stop"]))
      }, {
        dropdown: withCtx(function() {
          return [createVNode(_component_tiny_dropdown_menu, {
            placement: "bottom"
          }, {
            default: withCtx(function() {
              return [(openBlock(true), createElementBlock(
                Fragment,
                null,
                renderList(_ctx.state.effectOptions, function(item, index) {
                  return openBlock(), createBlock(
                    _component_tiny_dropdown_item,
                    {
                      key: item.text + index
                    },
                    {
                      default: withCtx(function() {
                        return [createElementVNode("div", {
                          onClick: withModifiers(function($event) {
                            return _ctx.handelIconClick(item, index, $event);
                          }, ["stop"]),
                          class: normalizeClass([item.disabled ? "text-color-text-disabled cursor-not-allowed" : ""])
                        }, [(openBlock(), createBlock(resolveDynamicComponent(item.icon), {
                          class: normalizeClass(["w-4 h-4", [item.disabled ? "fill-color-icon-disabled" : ""]])
                        }, null, 8, ["class"])), item.text ? (openBlock(), createElementBlock(
                          "span",
                          _hoisted_15,
                          toDisplayString(item.text),
                          1
                          /* TEXT */
                        )) : createCommentVNode("v-if", true)], 10, _hoisted_14)];
                      }),
                      _: 2
                      /* DYNAMIC */
                    },
                    1024
                    /* DYNAMIC_SLOTS */
                  );
                }),
                128
                /* KEYED_FRAGMENT */
              ))];
            }),
            _: 1
            /* STABLE */
          })];
        }),
        default: withCtx(function() {
          return [(openBlock(), createBlock(resolveDynamicComponent(_ctx.iconMore), {
            class: "w-4 h-4"
          }))];
        }),
        _: 1
        /* STABLE */
      })])) : createCommentVNode("v-if", true)];
    })])) : createCommentVNode("v-if", true)],
    2
    /* CLASS */
  );
}
var StandardListItem = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
var version = "3.undefined";
StandardListItem.install = function(Vue) {
  Vue.component(StandardListItem.name, StandardListItem);
};
StandardListItem.version = version;

export { StandardListItem as default };
