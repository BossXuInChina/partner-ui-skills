import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  viewBox: "0 0 16 16",
  xmlns: "http://www.w3.org/2000/svg"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    d: "M8 15c.27 0 .5-.23.5-.5 0-.28-.23-.5-.5-.5H4.69C3.75 14 3 13.33 3 12.5v-9C3 2.66 3.75 2 4.69 2h6.61c.94 0 1.7.66 1.7 1.5v2.66c0 .28.22.5.5.5.27 0 .5-.22.5-.5V3.5C14 2.11 12.78 1 11.3 1H4.69C3.21 1 2 2.11 2 3.5v9C2 13.88 3.21 15 4.69 15H8ZM5.5 5c-.28 0-.5.22-.5.5 0 .27.22.5.5.5h5c.27 0 .5-.23.5-.5 0-.28-.23-.5-.5-.5h-5Zm9.88 7.74.03 1.04c0 .57-.48 1.05-1.07 1.05h-4.25c-.58 0-1.06-.48-1.06-1.05v-1.04c0-.64.47-1.18 1.08-1.31l.55-.11c-.08-.13-.14-.25-.18-.39 0 0-.04-.09-.04-.1l-.03-.14c-.01-.13-.02-.2-.02-.28v-.73l.01-.1c0-.02.02-.16.02-.17.24-.83.96-1.36 1.76-1.36 1 0 1.82.79 1.82 1.77v.59c0 .33-.09.64-.25.91l.53.11c.63.13 1.08.67 1.1 1.31ZM5.5 8.16h3c.27 0 .5.22.5.5 0 .27-.23.5-.5.5h-3c-.28 0-.5-.23-.5-.5 0-.28.22-.5.5-.5Zm8.65 4.16c.19.03.35.21.35.42l.03 1.04c0 .08-.07.14-.15.14h-4.25c-.1 0-.16-.06-.16-.14v-1.04c0-.21.14-.39.36-.42l1.39-.3c.18-.03.33-.19.35-.37.01-.19-.08-.39-.25-.47a.865.865 0 0 1-.47-.55l-.02-.12v-.78l.02-.13c.11-.37.48-.64.89-.64.51 0 .92.38.92.87v.58c0 .33-.19.62-.5.77a.472.472 0 0 0-.25.47c.01.18.16.34.34.37l1.4.3Z",
    "clip-rule": "evenodd",
    "fill-rule": "evenodd"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = [_hoisted_2];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_3));
}
var Agency = {
  render
};
var agency = function agency2() {
  return svg({
    name: "IconAgency",
    component: Agency,
    filledComponent: Agency
  })();
};
export {
  agency as default
};
