import { renderless, api } from '@opentiny/vue-renderless/drop-roles/vue';
import { defineComponent, props, setup } from '@opentiny/vue-common';
import Select from '@opentiny/vue-select';
import Option from '@opentiny/vue-option';
import { IconAdministrator } from '@opentiny/vue-icon';
import { resolveComponent, openBlock, createBlock, mergeProps, withCtx, createElementBlock, Fragment, renderList, createElementVNode, toDisplayString, createVNode } from 'vue';

function _createForOfIteratorHelperLoose(r, e) {
  var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (t) return (t = t.call(r)).next.bind(t);
  if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
    t && (r = t);
    var o = 0;
    return function() {
      return o >= r.length ? { done: true } : { done: false, value: r[o++] };
    };
  }
  throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return _arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
  }
}
function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}
var _export_sfc = function _export_sfc2(sfc, props) {
  var target = sfc.__vccOpts || sfc;
  for (var _iterator = _createForOfIteratorHelperLoose(props), _step; !(_step = _iterator()).done; ) {
    var _step$value = _step.value, key = _step$value[0], val = _step$value[1];
    target[key] = val;
  }
  return target;
};

var _sfc_main = defineComponent({
  components: {
    TinySelect: Select,
    TinyOption: Option,
    IconAdministrator: IconAdministrator()
  },
  props: [].concat(props, ["size", "modelValue", "placeholder", "fetchRole", "fetchCurrentRole", "fields", "popperClass", "popperAppendToBody", "displayOnly"]),
  emits: ["change", "render", "update:modelValue"],
  setup: function setup$1(props2, context) {
    return setup({
      props: props2,
      context,
      renderless,
      api
    });
  }
});
var _hoisted_1 = {
  style: {
    "float": "left"
  }
};
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_icon_administrator = resolveComponent("icon-administrator");
  var _component_tiny_option = resolveComponent("tiny-option");
  var _component_tiny_select = resolveComponent("tiny-select");
  return openBlock(), createBlock(_component_tiny_select, mergeProps({
    size: _ctx.size,
    modelValue: _ctx.state.selectedValue,
    "onUpdate:modelValue": _cache[0] || (_cache[0] = function($event) {
      return _ctx.state.selectedValue = $event;
    }),
    placeholder: _ctx.placeholder
  }, _ctx.f(_ctx.state.attrs), {
    "display-only": _ctx.displayOnly,
    "popper-class": "tiny-drop-roles" + (_ctx.popperClass ? " " + _ctx.popperClass : ""),
    "popper-append-to-body": _ctx.popperAppendToBody,
    onChange: _ctx.change
  }), {
    default: withCtx(function() {
      return [(openBlock(true), createElementBlock(
        Fragment,
        null,
        renderList(_ctx.state.options, function(item) {
          return openBlock(), createBlock(_component_tiny_option, {
            key: item.value,
            label: item.label,
            value: item.value
          }, {
            default: withCtx(function() {
              return [createElementVNode(
                "span",
                _hoisted_1,
                toDisplayString(item.label),
                1
                /* TEXT */
              ), createVNode(_component_icon_administrator, {
                class: "user-icon tiny-svg-size"
              })];
            }),
            _: 2
            /* DYNAMIC */
          }, 1032, ["label", "value"]);
        }),
        128
        /* KEYED_FRAGMENT */
      ))];
    }),
    _: 1
    /* STABLE */
  }, 16, ["size", "modelValue", "placeholder", "display-only", "popper-class", "popper-append-to-body", "onChange"]);
}
var pc = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);

export { pc as default };
