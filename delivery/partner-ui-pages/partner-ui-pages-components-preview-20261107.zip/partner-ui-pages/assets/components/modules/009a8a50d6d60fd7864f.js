import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 24 24",
  "xml:space": "preserve"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    class: "express-search_svg__st0",
    d: "M6 5h7c.6 0 1 .4 1 1s-.4 1-1 1H6c-.6 0-1-.4-1-1s.4-1 1-1zM6 9h5c.6 0 1 .4 1 1s-.4 1-1 1H6c-.6 0-1-.4-1-1s.4-1 1-1z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    class: "express-search_svg__st0",
    d: "M18 1H4c-.9 0-2 1.1-2 2v18c0 .9 1.1 2 2 2h5c.5 0 1-.5 1-1s-.5-1-1-1H4V3h14v6c0 .5.5 1 1 1s1-.5 1-1V3c0-.9-1.1-2-2-2zM20.1 19.2l2.1 2.1c.4.4.4 1 0 1.4-.4.4-1 .4-1.4 0l-2.1-2.1c-.4-.4-.4-1 0-1.4.4-.4 1.1-.4 1.4 0z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_4 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    class: "express-search_svg__st0",
    d: "M16 21c-2.8 0-5-2.2-5-5s2.2-5 5-5 5 2.2 5 5-2.2 5-5 5zm0-2c1.7 0 3-1.3 3-3s-1.3-3-3-3-3 1.3-3 3 1.3 3 3 3z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_5 = [_hoisted_2, _hoisted_3, _hoisted_4];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_5));
}
var ExpressSearch = {
  render
};
var expressSearch = function expressSearch2() {
  return svg({
    name: "IconExpressSearch",
    component: ExpressSearch,
    filledComponent: ExpressSearch
  })();
};
export {
  expressSearch as default
};
