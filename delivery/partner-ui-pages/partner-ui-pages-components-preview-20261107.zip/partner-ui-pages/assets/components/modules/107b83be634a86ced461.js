import { renderless, api } from '@opentiny/vue-renderless/progress/vue';
import { defineComponent, props, setup } from '@opentiny/vue-common';
import { iconClose, iconSuccess, iconError, iconYes, iconWarning } from '@opentiny/vue-icon';
import '@opentiny/vue-theme/progress/index.css';
import { openBlock, createElementBlock, normalizeClass, createElementVNode, normalizeStyle, createVNode, Transition, withCtx, toDisplayString, createCommentVNode, Fragment, createTextVNode, renderSlot, createBlock, resolveDynamicComponent } from 'vue';

function _createForOfIteratorHelperLoose(r, e) {
  var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (t) return (t = t.call(r)).next.bind(t);
  if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
    t && (r = t);
    var o = 0;
    return function() {
      return o >= r.length ? { done: true } : { done: false, value: r[o++] };
    };
  }
  throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return _arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
  }
}
function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}
var _export_sfc = function _export_sfc2(sfc, props) {
  var target = sfc.__vccOpts || sfc;
  for (var _iterator = _createForOfIteratorHelperLoose(props), _step; !(_step = _iterator()).done; ) {
    var _step$value = _step.value, key = _step$value[0], val = _step$value[1];
    target[key] = val;
  }
  return target;
};

function _extends() {
  return _extends = Object.assign ? Object.assign.bind() : function(n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends.apply(null, arguments);
}
var _sfc_main = defineComponent({
  props: [].concat(props, ["type", "percentage", "status", "strokeWidth", "textInside", "width", "showText", "color", "format"]),
  components: {
    IconClose: iconClose(),
    IconSuccess: iconSuccess(),
    IconError: iconError(),
    IconYes: iconYes(),
    IconWarning: iconWarning()
  },
  setup: function setup$1(props2, context) {
    return setup({
      props: props2,
      context,
      renderless,
      api
    });
  }
});
var _hoisted_1 = ["aria-valuenow"];
var _hoisted_2 = {
  key: 0,
  class: "tiny-progress-bar"
};
var _hoisted_3 = {
  key: 0,
  class: "tiny-progress-bar__innerText"
};
var _hoisted_4 = {
  viewBox: "0 0 100 100"
};
var _hoisted_5 = ["d", "stroke-width"];
var _hoisted_6 = ["d", "stroke", "stroke-width"];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return openBlock(), createElementBlock("div", {
    class: normalizeClass(["tiny-progress", ["tiny-progress--" + _ctx.type, _ctx.status ? "is-" + _ctx.status : "", {
      "tiny-progress--without-text": !_ctx.showText,
      "tiny-progress--text-inside": _ctx.textInside
    }]]),
    role: "progressbar",
    "aria-valuenow": _ctx.percentage,
    "aria-valuemin": "0",
    "aria-valuemax": "100"
  }, [_ctx.type === "line" ? (openBlock(), createElementBlock("div", _hoisted_2, [createElementVNode(
    "div",
    {
      class: "tiny-progress-bar__outer",
      style: normalizeStyle({
        height: _ctx.state.strokeWidth + "px",
        borderRadius: _ctx.state.strokeWidth / 2 + "px"
      })
    },
    [createVNode(Transition, {
      appear: "",
      "appear-class": "custom-appear-class",
      onBeforeAppear: _ctx.customBeforeAppearHook,
      onAppear: _ctx.customAppearHook,
      onAfterAppear: _ctx.customAfterAppearHook
    }, {
      default: withCtx(function() {
        return [createElementVNode(
          "div",
          {
            class: "tiny-progress-bar__inner",
            style: normalizeStyle(_extends({}, _ctx.state.barStyle, {
              borderRadius: _ctx.state.strokeWidth / 2 + "px"
            }))
          },
          [_ctx.showText && _ctx.textInside ? (openBlock(), createElementBlock(
            "div",
            _hoisted_3,
            toDisplayString(_ctx.state.content),
            1
            /* TEXT */
          )) : createCommentVNode("v-if", true)],
          4
          /* STYLE */
        )];
      }),
      _: 1
      /* STABLE */
    }, 8, ["onBeforeAppear", "onAppear", "onAfterAppear"])],
    4
    /* STYLE */
  )])) : (openBlock(), createElementBlock(
    "div",
    {
      key: 1,
      class: "tiny-progress-circle",
      style: normalizeStyle({
        height: _ctx.state.width + "px",
        width: _ctx.state.width + "px"
      })
    },
    [(openBlock(), createElementBlock("svg", _hoisted_4, [createElementVNode("path", {
      class: "tiny-progress-circle__track",
      d: _ctx.state.trackPath,
      stroke: "#e5e9f2",
      "stroke-width": _ctx.state.relativeStrokeWidth,
      fill: "none",
      style: normalizeStyle(_ctx.state.trailPathStyle)
    }, null, 12, _hoisted_5), createVNode(Transition, {
      appear: "",
      "appear-class": "custom-appear-class",
      onBeforeAppear: _ctx.customBeforeAppearHook,
      onAppear: _ctx.customAppearHook,
      onAfterAppear: _ctx.customAfterAppearHook
    }, {
      default: withCtx(function() {
        return [createElementVNode("path", {
          class: "tiny-progress-circle__path",
          d: _ctx.state.trackPath,
          stroke: _ctx.state.stroke,
          fill: "none",
          "stroke-linecap": "round",
          "stroke-width": _ctx.percentage ? _ctx.state.relativeStrokeWidth : 0,
          style: normalizeStyle(_ctx.state.circlePathStyle)
        }, null, 12, _hoisted_6)];
      }),
      _: 1
      /* STABLE */
    }, 8, ["onBeforeAppear", "onAppear", "onAfterAppear"])]))],
    4
    /* STYLE */
  )), _ctx.showText && !_ctx.textInside ? (openBlock(), createElementBlock(
    "div",
    {
      key: 2,
      class: "tiny-progress__text",
      style: normalizeStyle({
        fontSize: _ctx.state.progressTextSize + "px"
      })
    },
    [!_ctx.status ? (openBlock(), createElementBlock(
      Fragment,
      {
        key: 0
      },
      [createTextVNode(
        toDisplayString(_ctx.state.content),
        1
        /* TEXT */
      )],
      64
      /* STABLE_FRAGMENT */
    )) : renderSlot(_ctx.$slots, _ctx.status + "Icon", {
      key: 1
    }, function() {
      return [(openBlock(), createBlock(resolveDynamicComponent(_ctx.state.iconClass), {
        class: "tiny-svg-size"
      }))];
    })],
    4
    /* STYLE */
  )) : createCommentVNode("v-if", true)], 10, _hoisted_1);
}
var pc = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);

export { pc as default };
