import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  viewBox: "0 0 30 30",
  xmlns: "http://www.w3.org/2000/svg"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "g",
  null,
  [/* @__PURE__ */ createElementVNode("rect", {
    width: "30",
    height: "30",
    rx: "2"
  }), /* @__PURE__ */ createElementVNode("path", {
    d: "m12.077 21.5 2.174-7.532c.155-.527.287-1.009.397-1.446.11-.437.224-.937.343-1.5a27.753 27.753 0 0 0 .74 3l2.21 7.478h2.299L24 8.5h-2.237l-2.076 8.044a34.23 34.23 0 0 0-.561 2.29c-.095-.653-.291-1.46-.588-2.424L16.185 8.5h-2.317l-2.236 7.82c-.19.634-.404 1.472-.642 2.514a22.638 22.638 0 0 0-.517-2.37L8.353 8.5H6l3.805 13h2.272Z",
    fill: "#FFF"
  })],
  -1
  /* HOISTED */
);
var _hoisted_3 = [_hoisted_2];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_3));
}
var WordType = {
  render
};
var wordType = function wordType2() {
  return svg({
    name: "IconWordType",
    component: WordType,
    filledComponent: WordType
  })();
};
export {
  wordType as default
};
