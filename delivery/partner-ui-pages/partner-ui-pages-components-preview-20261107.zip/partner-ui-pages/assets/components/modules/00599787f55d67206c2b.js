import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  xmlns: "http://www.w3.org/2000/svg",
  viewBox: "0 0 24 24",
  "xml:space": "preserve"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    class: "smile-o_svg__st0",
    d: "M12 24C5.4 24 0 18.6 0 12S5.4 0 12 0s12 5.4 12 12-5.4 12-12 12zM6.5 11c.8 0 1.5-.7 1.5-1.5S7.3 8 6.5 8 5 8.7 5 9.5 5.7 11 6.5 11zm11 0c.8 0 1.5-.7 1.5-1.5S18.3 8 17.5 8 16 8.7 16 9.5s.7 1.5 1.5 1.5zm-2.4 3c-.5 0-.9.4-.9.9 0 1.3-1 2.3-2.2 2.3s-2.2-1-2.2-2.3c0-.5-.4-.9-.9-.9s-.9.4-.9.9c0 2.3 1.8 4.1 4 4.1s4-1.8 4-4.1c0-.5-.4-.9-.9-.9z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = [_hoisted_2];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_3));
}
var SmileO = {
  render
};
var smileO = function smileO2() {
  return svg({
    name: "IconSmileO",
    component: SmileO,
    filledComponent: SmileO
  })();
};
export {
  smileO as default
};
