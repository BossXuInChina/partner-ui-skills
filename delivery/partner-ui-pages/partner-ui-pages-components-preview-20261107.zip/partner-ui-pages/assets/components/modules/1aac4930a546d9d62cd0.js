import { svg } from "@opentiny/vue-common";
import { openBlock, createElementBlock, createElementVNode } from "vue";
var _hoisted_1 = {
  viewBox: "0 0 24 24",
  xmlns: "http://www.w3.org/2000/svg",
  width: "24",
  height: "24",
  fill: "none"
};
var _hoisted_2 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    fill: "none",
    d: "M0 0h24v24H0z"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_3 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    d: "M5.507 2.159h.437c.277 0 .478.43.478.707a.696.696 0 0 1-.696.696h-.219a2.084 2.084 0 0 0-1.146.338v.001a2.11 2.11 0 0 0-.958 1.765V20.52a2.107 2.107 0 0 0 .34 1.147c.079.122.171.235.276.34q.157.157.338.276l.003.001.001.002a2.095 2.095 0 0 0 .667.284h.002c.155.036.314.054.477.054H18.5c.163 0 .323-.018.477-.054h.003a2.081 2.081 0 0 0 1.008-.562 2.11 2.11 0 0 0 .563-1.011c.036-.155.054-.314.054-.477V5.666a2.106 2.106 0 0 0-.34-1.147 2.106 2.106 0 0 0-1.765-.957h-.218a.696.696 0 0 1-.697-.696c0-.277.202-.707.479-.707h.436a3.483 3.483 0 0 1 1.365.276q.293.123.554.294l.013.009c.196.13.379.279.548.448q.255.255.45.55a3.497 3.497 0 0 1 .578 1.93V20.52a3.506 3.506 0 0 1-.579 1.93 3.51 3.51 0 0 1-1.563 1.301q-.297.126-.607.194h-.002a3.504 3.504 0 0 1-.757.082H5.507a3.503 3.503 0 0 1-1.931-.579A3.514 3.514 0 0 1 2 20.52V5.666a3.505 3.505 0 0 1 .579-1.931 3.508 3.508 0 0 1 .997-.997l.013-.009q.261-.17.553-.294c.199-.084.401-.149.608-.195h.002c.246-.054.498-.081.755-.081Z",
    fill: "#000",
    "fill-rule": "evenodd"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_4 = /* @__PURE__ */ createElementVNode(
  "rect",
  {
    width: "11.163",
    height: "3.721",
    x: "6.422",
    y: "1",
    rx: "1.395",
    stroke: "#000",
    "stroke-width": "1.395"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_5 = /* @__PURE__ */ createElementVNode(
  "path",
  {
    d: "m7.353 13.591 3.288 3.29M10.642 16.88l6.577-6.578",
    stroke: "#000",
    "stroke-linecap": "round",
    "stroke-width": "1.395"
  },
  null,
  -1
  /* HOISTED */
);
var _hoisted_6 = [_hoisted_2, _hoisted_3, _hoisted_4, _hoisted_5];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1, [].concat(_hoisted_6));
}
var Acceptance = {
  render
};
var acceptance = function acceptance2() {
  return svg({
    name: "IconAcceptance",
    component: Acceptance,
    filledComponent: Acceptance
  })();
};
export {
  acceptance as default
};
