import { off as b, PopupManager as I, isDisplayNone as $, isServer as N, PopperJS as T, on as v } from "@opentiny/utils";
const x = (t) => t.stopPropagation(), E = ({ state: t, props: l, vm: n, slots: d }) => {
  let a = t.referenceElm || l.reference || n.$refs.reference && n.$refs.reference.$el || n.$refs.reference;
  return !a && d.reference && d.reference()[0] && (t.referenceElm = d.reference()[0].elm || d.reference()[0].el, a = t.referenceElm), a;
}, R = (t) => {
  if (!t || !t.nodeType) return;
  let l = (a) => parseInt(window.getComputedStyle(a).zIndex, 10) || 0, n = l(t), d;
  do {
    if (t = t.parentNode, t && t instanceof ShadowRoot && t.host && (t = t.host), t)
      d = l(t);
    else
      break;
    n = d > n ? d : n;
  } while (t !== document.body);
  return n + 1 + "";
}, k = (t) => {
  const {
    parent: l,
    emit: n,
    nextTick: d,
    onBeforeUnmount: a,
    onDeactivated: J,
    props: p,
    watch: y,
    reactive: g,
    vm: f,
    slots: w,
    toRefs: h,
    popperVmRef: A
  } = t, e = g({
    popperJS: null,
    appended: !1,
    // arrow 是否添加
    popperElm: null,
    showPopper: p.manual ? !!p.modelValue : !1,
    referenceElm: null,
    currentPlacement: ""
  }), B = (o) => {
    if (e.appended)
      return;
    e.appended = !0;
    const r = document.createElement("div");
    r.setAttribute("x-arrow", ""), r.className = "popper__arrow", o.appendChild(r);
  }, S = (o) => {
    const { followReferenceHide: r = !0 } = (p == null ? void 0 : p.popperOptions) || {}, { _popper: c, _reference: s } = o;
    r && $(s) && (c.style.display = "none");
  }, P = (o) => p.zIndex === "relative" ? R(o) : I.nextZIndex(), _ = (o) => {
    if (N || (e.currentPlacement = e.currentPlacement || p.placement, !/^(top|bottom|left|right)(-start|-end)?$/g.test(e.currentPlacement)))
      return;
    const r = p.popperOptions || { gpuAcceleration: !1 };
    e.popperElm = e.popperElm || p.popper || f.$refs.popper || A.popper || o;
    const c = e.popperElm;
    let s = E({ state: e, props: p, vm: f, slots: w });
    !c || !s || s.nodeType !== Node.ELEMENT_NODE || (p.visibleArrow && B(c), p.appendToBody || p.popperAppendToBody ? document.body.appendChild(e.popperElm) : (l && l.$el && l.$el.appendChild(e.popperElm), r.forceAbsolute = !0), r.placement = e.currentPlacement, r.offset = p.offset || 0, r.arrowOffset = p.arrowOffset || 0, r.adjustArrow = p.adjustArrow || !1, r.appendToBody = p.appendToBody || p.popperAppendToBody, e.popperJS = new T(s, c, r), n("created", e), typeof r.onUpdate == "function" && e.popperJS.onUpdate(r.onUpdate), e.popperJS._popper.style.zIndex = P(e.popperJS._reference), S(e.popperJS), v(e.popperElm, "click", x));
  }, i = (o) => {
    o && o !== !0 && (e.popperElm = o);
    const r = e.popperJS;
    r ? (r._reference = E({ state: e, props: p, vm: f, slots: w }), r.update(), r._popper && o !== !0 && (r._popper.style.zIndex = P(r._reference), S(e.popperJS))) : _(o && o !== !0 ? o : void 0);
  }, u = (o) => {
    !e.popperJS || e.showPopper && !o || (e.popperJS.destroy(), e.popperJS = null);
  }, m = (o) => {
    o && e.popperElm && e.popperElm.parentNode === document.body && (b(e.popperElm, "click", x), e.popperElm.remove());
  };
  return y(
    () => e.showPopper,
    (o) => {
      p.disabled || (o && d(i), p.trigger === "manual" && n("update:modelValue", o));
    }
  ), y(
    () => p.placement,
    (o) => {
      var r;
      e.currentPlacement = o, (r = e.popperJS) == null || r.setOptions({ placement: o }), !p.disabled && (o && d(i), p.trigger === "manual" && n("update:modelValue", o));
    }
  ), a(() => {
    d(() => {
      u(!0), (p.appendToBody || p.popperAppendToBody) && m("remove");
    });
  }), J(() => {
    u(!0), (p.appendToBody || p.popperAppendToBody) && m("remove");
  }), { updatePopper: i, destroyPopper: m, doDestroy: u, ...h(e) };
};
export {
  k as userPopper
};
