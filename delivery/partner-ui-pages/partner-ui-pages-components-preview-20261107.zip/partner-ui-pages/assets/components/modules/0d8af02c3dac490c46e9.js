function _extends() {
  return _extends = Object.assign ? Object.assign.bind() : function(n) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
    }
    return n;
  }, _extends.apply(null, arguments);
}
import { defineComponent, $props, $setup, $prefix } from "@opentiny/vue-common";
import MobileFirstTemplate from "./mobile-first.js";
var template = function template2(mode) {
  var _process$env;
  typeof process === "object" ? (_process$env = process.env) == null ? void 0 : _process$env.TINY_MODE : null;
  return MobileFirstTemplate;
};
var floatingButtonProps = _extends({}, $props, {
  position: {
    type: String,
    default: "right"
  },
  backgroundColor: {
    type: String,
    default: ""
  },
  icon: {
    type: [Object, String],
    default: "icon-plus"
  },
  resetTime: {
    type: [String, Number],
    default: 0
  },
  animated: {
    type: Boolean,
    default: false
  },
  expandList: {
    type: Array,
    default: function _default() {
      return [];
    }
  },
  isExpand: {
    type: Boolean,
    default: false
  },
  vague: {
    type: Boolean,
    default: false
  },
  mask: {
    type: Boolean,
    default: false
  },
  elementSelector: {
    type: String,
    default: ""
  }
});
var FloatingButton = defineComponent({
  name: $prefix + "FloatingButton",
  props: floatingButtonProps,
  setup: function setup(props, context) {
    return $setup({
      props,
      context,
      template
    });
  }
});
var version = "3.undefined";
FloatingButton.install = function(Vue) {
  Vue.component(FloatingButton.name, FloatingButton);
};
FloatingButton.version = version;
export {
  FloatingButton as default
};
